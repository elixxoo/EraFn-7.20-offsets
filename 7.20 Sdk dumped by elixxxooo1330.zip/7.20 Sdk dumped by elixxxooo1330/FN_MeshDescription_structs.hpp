#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class EComputeNTBsOptions : uint8_t
{
    None = 0,
    Normals = 1,
    Tangents = 2,
    WeightedNTBs = 4,
    EComputeNTBsOptions_MAX = 5
};struct FElementID
{
	public:
	    int IDValue; // 0x0 Size: 0x4

};

struct FVertexInstanceID : public FElementID
{
	public:
	    char UnknownData0[0x4];

};

struct FMeshTriangle
{
	public:
	    struct FVertexInstanceID VertexInstanceID0; // 0x0 Size: 0x4
	    struct FVertexInstanceID VertexInstanceID1; // 0x4 Size: 0x4
	    struct FVertexInstanceID VertexInstanceID2; // 0x8 Size: 0x4

};

struct FPolygonID : public FElementID
{
	public:
	    char UnknownData0[0x4];

};

struct FPolygonGroupID : public FElementID
{
	public:
	    char UnknownData0[0x4];

};

struct FEdgeID : public FElementID
{
	public:
	    char UnknownData0[0x4];

};

struct FVertexID : public FElementID
{
	public:
	    char UnknownData0[0x4];

};


}