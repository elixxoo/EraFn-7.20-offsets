#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FPropertyPathSegment
{
	public:
	    FName Name; // 0x0 Size: 0x8
	    int ArrayIndex; // 0x8 Size: 0x4
	    char UnknownData0[0x4]; // 0xc
	    class UStruct* Struct; // 0x10 Size: 0x8
	    class UField* Field; // 0x18 Size: 0x8

};


}