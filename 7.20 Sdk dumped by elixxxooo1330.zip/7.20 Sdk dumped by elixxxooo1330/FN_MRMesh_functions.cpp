#include "../SDK.hpp"

void UMeshReconstructorBase::StopReconstruction()
{
    static auto fn = UObject::FindObject("/Script/MRMesh.MeshReconstructorBase:StopReconstruction");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UMeshReconstructorBase::StartReconstruction()
{
    static auto fn = UObject::FindObject("/Script/MRMesh.MeshReconstructorBase:StartReconstruction");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UMeshReconstructorBase::PauseReconstruction()
{
    static auto fn = UObject::FindObject("/Script/MRMesh.MeshReconstructorBase:PauseReconstruction");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


bool UMeshReconstructorBase::IsReconstructionStarted()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MRMesh.MeshReconstructorBase:IsReconstructionStarted");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UMeshReconstructorBase::IsReconstructionPaused()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MRMesh.MeshReconstructorBase:IsReconstructionPaused");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UMeshReconstructorBase::DisconnectMRMesh()
{
    static auto fn = UObject::FindObject("/Script/MRMesh.MeshReconstructorBase:DisconnectMRMesh");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UMeshReconstructorBase::ConnectMRMesh(class UMRMeshComponent* Mesh)
{
	struct {
            class UMRMeshComponent* Mesh;
	} params{ Mesh };

    static auto fn = UObject::FindObject("/Script/MRMesh.MeshReconstructorBase:ConnectMRMesh");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

bool UMRMeshComponent::IsConnected()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MRMesh.MRMeshComponent:IsConnected");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UMRMeshComponent::ForceNavMeshUpdate()
{
    static auto fn = UObject::FindObject("/Script/MRMesh.MRMeshComponent:ForceNavMeshUpdate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UMRMeshComponent::Clear()
{
    static auto fn = UObject::FindObject("/Script/MRMesh.MRMeshComponent:Clear");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

