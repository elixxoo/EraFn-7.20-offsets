#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class ESoundwaveSampleRateSettings : uint8_t
{
    Max = 0,
    High = 1,
    Medium = 2,
    Low = 3,
    Min = 4,
    MatchDevice = 5
};struct FPlatformRuntimeAudioCompressionOverrides
{
	public:
	    bool bOverrideCompressionTimes; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float DurationThreshold; // 0x4 Size: 0x4
	    int MaxNumRandomBranches; // 0x8 Size: 0x4
	    int SoundCueQualityIndex; // 0xc Size: 0x4

};


}