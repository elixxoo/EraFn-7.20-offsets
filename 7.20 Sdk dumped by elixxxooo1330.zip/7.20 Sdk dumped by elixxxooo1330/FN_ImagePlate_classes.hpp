#pragma once

#include "../SDK.hpp"

namespace SDK {


class AImagePlate : public AActor
{
	public:
	    class UImagePlateComponent* ImagePlate; // 0x330 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ImagePlate.ImagePlate");
			return (class UClass*)ptr;
		};

};

class UImagePlateComponent : public UPrimitiveComponent
{
	public:
	    struct FImagePlateParameters Plate; // 0x570 Size: 0x38
	    char UnknownData0[0x5a8]; // 0x5a8
	    void SetImagePlate(struct FImagePlateParameters Plate); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnRenderTextureChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    struct FImagePlateParameters GetPlate(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-79a1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ImagePlate.ImagePlateComponent");
			return (class UClass*)ptr;
		};

};

class UImagePlateSettings : public UObject
{
	public:
	    struct FString ProxyName; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ImagePlate.ImagePlateSettings");
			return (class UClass*)ptr;
		};

};

class UImagePlateFileSequence : public UObject
{
	public:
	    struct FDirectoryPath SequencePath; // 0x28 Size: 0x10
	    struct FString FileWildcard; // 0x38 Size: 0x10
	    float FrameRate; // 0x48 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ImagePlate.ImagePlateFileSequence");
			return (class UClass*)ptr;
		};

};

class UImagePlateFrustumComponent : public UPrimitiveComponent
{
	public:
	    char UnknownData0[0x570];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ImagePlate.ImagePlateFrustumComponent");
			return (class UClass*)ptr;
		};

};

class UMovieSceneImagePlateSection : public UMovieSceneSection
{
	public:
	    class UImagePlateFileSequence* FileSequence; // 0xe0 Size: 0x8
	    bool bReuseExistingTexture; // 0xe8 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ImagePlate.MovieSceneImagePlateSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneImagePlateTrack : public UMovieScenePropertyTrack
{
	public:
	    char UnknownData0[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ImagePlate.MovieSceneImagePlateTrack");
			return (class UClass*)ptr;
		};

};


}