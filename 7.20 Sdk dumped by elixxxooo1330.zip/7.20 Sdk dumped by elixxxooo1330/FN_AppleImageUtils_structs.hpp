#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class EAppleTextureType : uint8_t
{
    Unknown = 0,
    Image = 1,
    PixelBuffer = 2,
    Surface = 3,
    MetalTexture = 4,
    EAppleTextureType_MAX = 5
};

enum class ETextureRotationDirection : uint8_t
{
    None = 0,
    Left = 1,
    Right = 2,
    Down = 3,
    ETextureRotationDirection_MAX = 4
};
}