#pragma once

#include "../SDK.hpp"

namespace SDK {


class AEsportsCameraClient : public AActor
{
	public:
	    char UnknownData0[0x10];
	    class AWebCamReader* WebCamReader; // 0x340 Size: 0x8
	    class AWebCamViewer* WebCamViewer; // 0x348 Size: 0x8
	    class AM3U8MovieViewer* M3U8MovieViewer; // 0x350 Size: 0x8
	    char UnknownData1[0x358]; // 0x358
	    void SetDynamicMaterial(class UMaterialInstanceDynamic* MaterialInstanceDynamic); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool IsPlayingWebMovie(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool IsPlatformEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool HasDynamicMaterial(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7c71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EsportsCameraClient.EsportsCameraClient");
			return (class UClass*)ptr;
		};

};

class UEsportsCameraStatusBase : public UCommonUserWidget
{
	public:
	    void FollowedPlayerChanged(class AEsportsCameraClient* InEsportsCameraClient); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7db1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EsportsCameraClient.EsportsCameraStatusBase");
			return (class UClass*)ptr;
		};

};

class AWebCamBase : public AActor
{
	public:
	    char UnknownData0[0x8];
	    class UTexture2D* DynamicTexture; // 0x338 Size: 0x8
	    class UMaterialInstanceDynamic* MaterialInstanceDynamic; // 0x340 Size: 0x8
	    TArray<char> DynamicColors; // 0x348 Size: 0x10
	    char UnknownData1[0x20];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EsportsCameraClient.WebCamBase");
			return (class UClass*)ptr;
		};

};

class AM3U8MovieViewer : public AWebCamBase
{
	public:
	    char UnknownData0[0x28];
	    class UAudioComponent* AudioComponent; // 0x3a0 Size: 0x8
	    class UMySoundWave* MySoundWave; // 0x3a8 Size: 0x8
	    char UnknownData1[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EsportsCameraClient.M3U8MovieViewer");
			return (class UClass*)ptr;
		};

};

class UMySoundWave : public USoundWaveProcedural
{
	public:
	    char UnknownData0[0x270];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EsportsCameraClient.MySoundWave");
			return (class UClass*)ptr;
		};

};

class AWebCamReader : public AWebCamBase
{
	public:
	    char UnknownData0[0x378];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EsportsCameraClient.WebCamReader");
			return (class UClass*)ptr;
		};

};

class AWebCamViewer : public AWebCamBase
{
	public:
	    char UnknownData0[0x380];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EsportsCameraClient.WebCamViewer");
			return (class UClass*)ptr;
		};

};


}