#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FGeometry
{
	public:
	    char UnknownData0[0x38];

};



enum class ECheckBoxState : uint8_t
{
    Unchecked = 0,
    Checked = 1,
    Undetermined = 2,
    ECheckBoxState_MAX = 3
};

enum class EWidgetClipping : uint8_t
{
    Inherit = 0,
    ClipToBounds = 1,
    ClipToBoundsWithoutIntersecting = 2,
    ClipToBoundsAlways = 3,
    OnDemand = 4,
    EWidgetClipping_MAX = 5
};

enum class ESlateBrushImageType : uint8_t
{
    NoImage = 0,
    FullColor = 1,
    Linear = 2,
    ESlateBrushImageType_MAX = 3
};

enum class ESlateBrushMirrorType : uint8_t
{
    NoMirror = 0,
    Horizontal = 1,
    Vertical = 2,
    Both = 3,
    ESlateBrushMirrorType_MAX = 4
};

enum class ESlateBrushTileType : uint8_t
{
    NoTile = 0,
    Horizontal = 1,
    Vertical = 2,
    Both = 3,
    ESlateBrushTileType_MAX = 4
};

enum class ESlateBrushDrawType : uint8_t
{
    NoDrawType = 0,
    Box = 1,
    Border = 2,
    Image = 3,
    ESlateBrushDrawType_MAX = 4
};struct FSlateColor
{
	public:
	    struct FLinearColor SpecifiedColor; // 0x0 Size: 0x10
	    char ColorUseRule; // 0x10 Size: 0x1
	    char UnknownData0[0x17];

};



enum class ESlateColorStylingMode : uint8_t
{
    UseColor_Specified = 0,
    UseColor_Specified_Link = 1,
    UseColor_Foreground = 2,
    UseColor_Foreground_Subdued = 3,
    UseColor_MAX = 4
};struct FMargin
{
	public:
	    float Left; // 0x0 Size: 0x4
	    float Top; // 0x4 Size: 0x4
	    float Right; // 0x8 Size: 0x4
	    float Bottom; // 0xc Size: 0x4

};

struct FSlateBrush
{
	public:
	    struct FVector2D ImageSize; // 0x8 Size: 0x8
	    struct FMargin Margin; // 0x10 Size: 0x10
	    struct FSlateColor TintColor; // 0x20 Size: 0x28
	    class UObject* ResourceObject; // 0x48 Size: 0x8
	    FName ResourceName; // 0x50 Size: 0x8
	    struct FBox2D UVRegion; // 0x58 Size: 0x14
	    char DrawAs; // 0x6c Size: 0x1
	    char Tiling; // 0x6d Size: 0x1
	    char Mirroring; // 0x6e Size: 0x1
	    char ImageType; // 0x6f Size: 0x1
	    bool bIsDynamicallyLoaded; // 0x80 Size: 0x1
	    bool bHasUObject; // 0x80 Size: 0x1
	    char UnknownData0[0x16];

};

struct FInputEvent
{
	public:
	    char UnknownData0[0x18];

};

struct FPointerEvent : public FInputEvent
{
	public:
	    char UnknownData0[0x70];

};



enum class EUINavigationRule : uint8_t
{
    Escape = 0,
    Explicit = 1,
    Wrap = 2,
    Stop = 3,
    Custom = 4,
    CustomBoundary = 5,
    Invalid = 6,
    EUINavigationRule_MAX = 7
};

enum class EUINavigation : uint8_t
{
    Left = 0,
    Right = 1,
    Up = 2,
    Down = 3,
    Next = 4,
    Previous = 5,
    Num = 6,
    Invalid = 7,
    EUINavigation_MAX = 8
};struct FCharacterEvent : public FInputEvent
{
	public:
	    char UnknownData0[0x20];

};

struct FKeyEvent : public FInputEvent
{
	public:
	    char UnknownData0[0x38];

};

struct FNavigationEvent : public FInputEvent
{
	public:
	    char UnknownData0[0x20];

};

struct FAnalogInputEvent : public FKeyEvent
{
	public:
	    char UnknownData0[0x40];

};



enum class ESelectInfo : uint8_t
{
    OnKeyPress = 0,
    OnNavigation = 1,
    OnMouseClick = 2,
    Direct = 3,
    ESelectInfo_MAX = 4
};struct FFontOutlineSettings
{
	public:
	    int OutlineSize; // 0x0 Size: 0x4
	    bool bSeparateFillAlpha; // 0x4 Size: 0x1
	    bool bApplyOutlineToDropShadows; // 0x5 Size: 0x1
	    char UnknownData0[0x2]; // 0x6
	    class UObject* OutlineMaterial; // 0x8 Size: 0x8
	    struct FLinearColor OutlineColor; // 0x10 Size: 0x10

};

struct FSlateFontInfo
{
	public:
	    class UObject* FontObject; // 0x0 Size: 0x8
	    class UObject* FontMaterial; // 0x8 Size: 0x8
	    struct FFontOutlineSettings OutlineSettings; // 0x10 Size: 0x20
	    char UnknownData0[0x10]; // 0x30
	    FName TypefaceFontName; // 0x40 Size: 0x8
	    int Size; // 0x48 Size: 0x4
	    char UnknownData1[0x4];

};

struct FSlateWidgetStyle
{
	public:
	    char UnknownData0[0x8];

};

struct FTableRowStyle : public FSlateWidgetStyle
{
	public:
	    struct FSlateBrush SelectorFocusedBrush; // 0x8 Size: 0x88
	    struct FSlateBrush ActiveHoveredBrush; // 0x90 Size: 0x88
	    struct FSlateBrush ActiveBrush; // 0x118 Size: 0x88
	    struct FSlateBrush InactiveHoveredBrush; // 0x1a0 Size: 0x88
	    struct FSlateBrush InactiveBrush; // 0x228 Size: 0x88
	    struct FSlateBrush EvenRowBackgroundHoveredBrush; // 0x2b0 Size: 0x88
	    struct FSlateBrush EvenRowBackgroundBrush; // 0x338 Size: 0x88
	    struct FSlateBrush OddRowBackgroundHoveredBrush; // 0x3c0 Size: 0x88
	    struct FSlateBrush OddRowBackgroundBrush; // 0x448 Size: 0x88
	    struct FSlateColor TextColor; // 0x4d0 Size: 0x28
	    struct FSlateColor SelectedTextColor; // 0x4f8 Size: 0x28
	    struct FSlateBrush DropIndicator_Above; // 0x520 Size: 0x88
	    struct FSlateBrush DropIndicator_Onto; // 0x5a8 Size: 0x88
	    struct FSlateBrush DropIndicator_Below; // 0x630 Size: 0x88

};

struct FSlateSound
{
	public:
	    class UObject* ResourceObject; // 0x0 Size: 0x8
	    char UnknownData0[0x10];

};

struct FButtonStyle : public FSlateWidgetStyle
{
	public:
	    struct FSlateBrush Normal; // 0x8 Size: 0x88
	    struct FSlateBrush Hovered; // 0x90 Size: 0x88
	    struct FSlateBrush Pressed; // 0x118 Size: 0x88
	    struct FSlateBrush Disabled; // 0x1a0 Size: 0x88
	    struct FMargin NormalPadding; // 0x228 Size: 0x10
	    struct FMargin PressedPadding; // 0x238 Size: 0x10
	    struct FSlateSound PressedSlateSound; // 0x248 Size: 0x18
	    struct FSlateSound HoveredSlateSound; // 0x260 Size: 0x18

};

struct FComboButtonStyle : public FSlateWidgetStyle
{
	public:
	    struct FButtonStyle ButtonStyle; // 0x8 Size: 0x278
	    struct FSlateBrush DownArrowImage; // 0x280 Size: 0x88
	    struct FSlateBrush MenuBorderBrush; // 0x308 Size: 0x88
	    struct FMargin MenuBorderPadding; // 0x390 Size: 0x10

};

struct FComboBoxStyle : public FSlateWidgetStyle
{
	public:
	    struct FComboButtonStyle ComboButtonStyle; // 0x8 Size: 0x3a0
	    struct FSlateSound PressedSlateSound; // 0x3a8 Size: 0x18
	    struct FSlateSound SelectionChangeSlateSound; // 0x3c0 Size: 0x18

};



enum class ETextCommit : uint8_t
{
    Default = 0,
    OnEnter = 1,
    OnUserMovedFocus = 2,
    OnCleared = 3,
    ETextCommit_MAX = 4
};

enum class ETextShapingMethod : uint8_t
{
    Auto = 0,
    KerningOnly = 1,
    FullShaping = 2,
    ETextShapingMethod_MAX = 3
};struct FEditableTextStyle : public FSlateWidgetStyle
{
	public:
	    struct FSlateFontInfo Font; // 0x8 Size: 0x50
	    struct FSlateColor ColorAndOpacity; // 0x58 Size: 0x28
	    struct FSlateBrush BackgroundImageSelected; // 0x80 Size: 0x88
	    struct FSlateBrush BackgroundImageComposing; // 0x108 Size: 0x88
	    struct FSlateBrush CaretImage; // 0x190 Size: 0x88

};

struct FScrollBarStyle : public FSlateWidgetStyle
{
	public:
	    struct FSlateBrush HorizontalBackgroundImage; // 0x8 Size: 0x88
	    struct FSlateBrush VerticalBackgroundImage; // 0x90 Size: 0x88
	    struct FSlateBrush VerticalTopSlotImage; // 0x118 Size: 0x88
	    struct FSlateBrush HorizontalTopSlotImage; // 0x1a0 Size: 0x88
	    struct FSlateBrush VerticalBottomSlotImage; // 0x228 Size: 0x88
	    struct FSlateBrush HorizontalBottomSlotImage; // 0x2b0 Size: 0x88
	    struct FSlateBrush NormalThumbImage; // 0x338 Size: 0x88
	    struct FSlateBrush HoveredThumbImage; // 0x3c0 Size: 0x88
	    struct FSlateBrush DraggedThumbImage; // 0x448 Size: 0x88

};

struct FEditableTextBoxStyle : public FSlateWidgetStyle
{
	public:
	    struct FSlateBrush BackgroundImageNormal; // 0x8 Size: 0x88
	    struct FSlateBrush BackgroundImageHovered; // 0x90 Size: 0x88
	    struct FSlateBrush BackgroundImageFocused; // 0x118 Size: 0x88
	    struct FSlateBrush BackgroundImageReadOnly; // 0x1a0 Size: 0x88
	    struct FMargin Padding; // 0x228 Size: 0x10
	    struct FSlateFontInfo Font; // 0x238 Size: 0x50
	    struct FSlateColor ForegroundColor; // 0x288 Size: 0x28
	    struct FSlateColor BackgroundColor; // 0x2b0 Size: 0x28
	    struct FSlateColor ReadOnlyForegroundColor; // 0x2d8 Size: 0x28
	    struct FMargin HScrollBarPadding; // 0x300 Size: 0x10
	    struct FMargin VScrollBarPadding; // 0x310 Size: 0x10
	    struct FScrollBarStyle ScrollBarStyle; // 0x320 Size: 0x4d0

};

struct FTextBlockStyle : public FSlateWidgetStyle
{
	public:
	    struct FSlateFontInfo Font; // 0x8 Size: 0x50
	    struct FSlateColor ColorAndOpacity; // 0x58 Size: 0x28
	    struct FVector2D ShadowOffset; // 0x80 Size: 0x8
	    struct FLinearColor ShadowColorAndOpacity; // 0x88 Size: 0x10
	    struct FSlateColor SelectedBackgroundColor; // 0x98 Size: 0x28
	    struct FLinearColor HighlightColor; // 0xc0 Size: 0x10
	    struct FSlateBrush HighlightShape; // 0xd0 Size: 0x88
	    struct FSlateBrush UnderlineBrush; // 0x158 Size: 0x88

};

struct FSpinBoxStyle : public FSlateWidgetStyle
{
	public:
	    struct FSlateBrush BackgroundBrush; // 0x8 Size: 0x88
	    struct FSlateBrush HoveredBackgroundBrush; // 0x90 Size: 0x88
	    struct FSlateBrush ActiveFillBrush; // 0x118 Size: 0x88
	    struct FSlateBrush InactiveFillBrush; // 0x1a0 Size: 0x88
	    struct FSlateBrush ArrowsImage; // 0x228 Size: 0x88
	    struct FSlateColor ForegroundColor; // 0x2b0 Size: 0x28
	    struct FMargin TextPadding; // 0x2d8 Size: 0x10

};



enum class EHorizontalAlignment : uint8_t
{
    HAlign_Fill = 0,
    HAlign_Left = 1,
    HAlign_Center = 2,
    HAlign_Right = 3,
    HAlign_MAX = 4
};

enum class EVerticalAlignment : uint8_t
{
    VAlign_Fill = 0,
    VAlign_Top = 1,
    VAlign_Center = 2,
    VAlign_Bottom = 3,
    VAlign_MAX = 4
};struct FFocusEvent
{
	public:
	    char UnknownData0[0x8];

};

struct FMotionEvent : public FInputEvent
{
	public:
	    char UnknownData0[0x48];

};



enum class EFontLayoutMethod : uint8_t
{
    Metrics = 0,
    BoundingBox = 1,
    EFontLayoutMethod_MAX = 2
};

enum class EFontLoadingPolicy : uint8_t
{
    LazyLoad = 0,
    Stream = 1,
    Inline = 2,
    EFontLoadingPolicy_MAX = 3
};

enum class EFontHinting : uint8_t
{
    Default = 0,
    Auto = 1,
    AutoLight = 2,
    Monochrome = 3,
    None = 4,
    EFontHinting_MAX = 5
};

enum class EFocusCause : uint8_t
{
    Mouse = 0,
    Navigation = 1,
    SetDirectly = 2,
    Cleared = 3,
    OtherWidgetLostFocus = 4,
    WindowActivate = 5,
    EFocusCause_MAX = 6
};

enum class EColorVisionDeficiency : uint8_t
{
    NormalVision = 0,
    Deuteranope = 1,
    Protanope = 2,
    Tritanope = 3,
    EColorVisionDeficiency_MAX = 4
};

enum class ESlateDebuggingFocusEvent : uint8_t
{
    FocusChanging = 0,
    FocusLost = 1,
    FocusReceived = 2,
    ESlateDebuggingFocusEvent_MAX = 3
};

enum class ESlateDebuggingStateChangeEvent : uint8_t
{
    MouseCaptureGained = 0,
    MouseCaptureLost = 1,
    ESlateDebuggingStateChangeEvent_MAX = 2
};

enum class ESlateDebuggingInputEvent : uint8_t
{
    MouseMove = 0,
    MouseEnter = 1,
    MouseLeave = 2,
    MouseButtonDown = 3,
    MouseButtonUp = 4,
    MouseButtonDoubleClick = 5,
    MouseWheel = 6,
    TouchStart = 7,
    TouchEnd = 8,
    DragDetected = 9,
    DragEnter = 10,
    DragLeave = 11,
    DragOver = 12,
    DragDrop = 13,
    DropMessage = 14,
    KeyDown = 15,
    KeyUp = 16,
    KeyChar = 17,
    AnalogInput = 18,
    TouchGesture = 19,
    COUNT = 20,
    ESlateDebuggingInputEvent_MAX = 21
};

enum class EScrollDirection : uint8_t
{
    Scroll_Down = 0,
    Scroll_Up = 1,
    Scroll_MAX = 2
};

enum class EOrientation : uint8_t
{
    Orient_Horizontal = 0,
    Orient_Vertical = 1,
    Orient_MAX = 2
};

enum class EMenuPlacement : uint8_t
{
    MenuPlacement_BelowAnchor = 0,
    MenuPlacement_CenteredBelowAnchor = 1,
    MenuPlacement_BelowRightAnchor = 2,
    MenuPlacement_ComboBox = 3,
    MenuPlacement_ComboBoxRight = 4,
    MenuPlacement_MenuRight = 5,
    MenuPlacement_AboveAnchor = 6,
    MenuPlacement_CenteredAboveAnchor = 7,
    MenuPlacement_AboveRightAnchor = 8,
    MenuPlacement_MenuLeft = 9,
    MenuPlacement_Center = 10,
    MenuPlacement_RightLeftCenter = 11,
    MenuPlacement_MatchBottomLeft = 12,
    MenuPlacement_MAX = 13
};

enum class ENavigationGenesis : uint8_t
{
    Keyboard = 0,
    Controller = 1,
    User = 2,
    ENavigationGenesis_MAX = 3
};

enum class ENavigationSource : uint8_t
{
    FocusedWidget = 0,
    WidgetUnderCursor = 1,
    ENavigationSource_MAX = 2
};

enum class EButtonPressMethod : uint8_t
{
    DownAndUp = 0,
    ButtonPress = 1,
    ButtonRelease = 2,
    EButtonPressMethod_MAX = 3
};

enum class EButtonTouchMethod : uint8_t
{
    DownAndUp = 0,
    PreciseTap = 1,
    EButtonTouchMethod_MAX = 2
};

enum class EButtonClickMethod : uint8_t
{
    DownAndUp = 0,
    MouseDown = 1,
    MouseUp = 2,
    PreciseClick = 3,
    EButtonClickMethod_MAX = 4
};

enum class EFontFallback : uint8_t
{
    FF_NoFallback = 0,
    FF_LocalizedFallback = 1,
    FF_LastResortFallback = 2,
    FF_Max = 3
};

enum class ESlateCheckBoxType : uint8_t
{
    CheckBox = 0,
    ToggleButton = 1,
    ESlateCheckBoxType_MAX = 2
};

enum class ESlateParentWindowSearchMethod : uint8_t
{
    ActiveWindow = 0,
    MainWindow = 1,
    ESlateParentWindowSearchMethod_MAX = 2
};

enum class EConsumeMouseWheel : uint8_t
{
    WhenScrollingPossible = 0,
    Always = 1,
    Never = 2,
    EConsumeMouseWheel_MAX = 3
};struct FScrollBoxStyle : public FSlateWidgetStyle
{
	public:
	    struct FSlateBrush TopShadowBrush; // 0x8 Size: 0x88
	    struct FSlateBrush BottomShadowBrush; // 0x90 Size: 0x88
	    struct FSlateBrush LeftShadowBrush; // 0x118 Size: 0x88
	    struct FSlateBrush RightShadowBrush; // 0x1a0 Size: 0x88

};

struct FCheckBoxStyle : public FSlateWidgetStyle
{
	public:
	    char CheckBoxType; // 0x8 Size: 0x1
	    char UnknownData0[0x7]; // 0x9
	    struct FSlateBrush UncheckedImage; // 0x10 Size: 0x88
	    struct FSlateBrush UncheckedHoveredImage; // 0x98 Size: 0x88
	    struct FSlateBrush UncheckedPressedImage; // 0x120 Size: 0x88
	    struct FSlateBrush CheckedImage; // 0x1a8 Size: 0x88
	    struct FSlateBrush CheckedHoveredImage; // 0x230 Size: 0x88
	    struct FSlateBrush CheckedPressedImage; // 0x2b8 Size: 0x88
	    struct FSlateBrush UndeterminedImage; // 0x340 Size: 0x88
	    struct FSlateBrush UndeterminedHoveredImage; // 0x3c8 Size: 0x88
	    struct FSlateBrush UndeterminedPressedImage; // 0x450 Size: 0x88
	    struct FMargin Padding; // 0x4d8 Size: 0x10
	    struct FSlateColor ForegroundColor; // 0x4e8 Size: 0x28
	    struct FSlateColor BorderBackgroundColor; // 0x510 Size: 0x28
	    struct FSlateSound CheckedSlateSound; // 0x538 Size: 0x18
	    struct FSlateSound UncheckedSlateSound; // 0x550 Size: 0x18
	    struct FSlateSound HoveredSlateSound; // 0x568 Size: 0x18

};

struct FFontData
{
	public:
	    struct FString FontFilename; // 0x0 Size: 0x10
	    EFontHinting Hinting; // 0x10 Size: 0x1
	    EFontLoadingPolicy LoadingPolicy; // 0x11 Size: 0x1
	    char UnknownData0[0x2]; // 0x12
	    int SubFaceIndex; // 0x14 Size: 0x4
	    class UObject* FontFaceAsset; // 0x18 Size: 0x8

};

struct FTypefaceEntry
{
	public:
	    FName Name; // 0x0 Size: 0x8
	    struct FFontData Font; // 0x8 Size: 0x20

};

struct FCaptureLostEvent
{
	public:
	    char UnknownData0[0x8];

};

struct FWindowStyle : public FSlateWidgetStyle
{
	public:
	    struct FButtonStyle MinimizeButtonStyle; // 0x8 Size: 0x278
	    struct FButtonStyle MaximizeButtonStyle; // 0x280 Size: 0x278
	    struct FButtonStyle RestoreButtonStyle; // 0x4f8 Size: 0x278
	    struct FButtonStyle CloseButtonStyle; // 0x770 Size: 0x278
	    struct FTextBlockStyle TitleTextStyle; // 0x9e8 Size: 0x1e0
	    struct FSlateBrush ActiveTitleBrush; // 0xbc8 Size: 0x88
	    struct FSlateBrush InactiveTitleBrush; // 0xc50 Size: 0x88
	    struct FSlateBrush FlashTitleBrush; // 0xcd8 Size: 0x88
	    struct FSlateColor BackgroundColor; // 0xd60 Size: 0x28
	    struct FSlateBrush OutlineBrush; // 0xd88 Size: 0x88
	    struct FSlateColor OutlineColor; // 0xe10 Size: 0x28
	    struct FSlateBrush BorderBrush; // 0xe38 Size: 0x88
	    struct FSlateBrush BackgroundBrush; // 0xec0 Size: 0x88
	    struct FSlateBrush ChildBackgroundBrush; // 0xf48 Size: 0x88

};

struct FScrollBorderStyle : public FSlateWidgetStyle
{
	public:
	    struct FSlateBrush TopShadowBrush; // 0x8 Size: 0x88
	    struct FSlateBrush BottomShadowBrush; // 0x90 Size: 0x88

};

struct FDockTabStyle : public FSlateWidgetStyle
{
	public:
	    struct FButtonStyle CloseButtonStyle; // 0x8 Size: 0x278
	    struct FSlateBrush NormalBrush; // 0x280 Size: 0x88
	    struct FSlateBrush ActiveBrush; // 0x308 Size: 0x88
	    struct FSlateBrush ColorOverlayTabBrush; // 0x390 Size: 0x88
	    struct FSlateBrush ColorOverlayIconBrush; // 0x418 Size: 0x88
	    struct FSlateBrush ForegroundBrush; // 0x4a0 Size: 0x88
	    struct FSlateBrush HoveredBrush; // 0x528 Size: 0x88
	    struct FSlateBrush ContentAreaBrush; // 0x5b0 Size: 0x88
	    struct FSlateBrush TabWellBrush; // 0x638 Size: 0x88
	    struct FMargin TabPadding; // 0x6c0 Size: 0x10
	    float OverlapWidth; // 0x6d0 Size: 0x4
	    char UnknownData0[0x4]; // 0x6d4
	    struct FSlateColor FlashColor; // 0x6d8 Size: 0x28

};

struct FSplitterStyle : public FSlateWidgetStyle
{
	public:
	    struct FSlateBrush HandleNormalBrush; // 0x8 Size: 0x88
	    struct FSlateBrush HandleHighlightBrush; // 0x90 Size: 0x88

};

struct FTableColumnHeaderStyle : public FSlateWidgetStyle
{
	public:
	    struct FSlateBrush SortPrimaryAscendingImage; // 0x8 Size: 0x88
	    struct FSlateBrush SortPrimaryDescendingImage; // 0x90 Size: 0x88
	    struct FSlateBrush SortSecondaryAscendingImage; // 0x118 Size: 0x88
	    struct FSlateBrush SortSecondaryDescendingImage; // 0x1a0 Size: 0x88
	    struct FSlateBrush NormalBrush; // 0x228 Size: 0x88
	    struct FSlateBrush HoveredBrush; // 0x2b0 Size: 0x88
	    struct FSlateBrush MenuDropdownImage; // 0x338 Size: 0x88
	    struct FSlateBrush MenuDropdownNormalBorderBrush; // 0x3c0 Size: 0x88
	    struct FSlateBrush MenuDropdownHoveredBorderBrush; // 0x448 Size: 0x88

};

struct FHeaderRowStyle : public FSlateWidgetStyle
{
	public:
	    struct FTableColumnHeaderStyle ColumnStyle; // 0x8 Size: 0x4d0
	    struct FTableColumnHeaderStyle LastColumnStyle; // 0x4d8 Size: 0x4d0
	    struct FSplitterStyle ColumnSplitterStyle; // 0x9a8 Size: 0x118
	    struct FSlateBrush BackgroundBrush; // 0xac0 Size: 0x88
	    struct FSlateColor ForegroundColor; // 0xb48 Size: 0x28

};

struct FInlineTextImageStyle : public FSlateWidgetStyle
{
	public:
	    struct FSlateBrush Image; // 0x8 Size: 0x88
	    int16_t Baseline; // 0x90 Size: 0x2
	    char UnknownData0[0x6];

};

struct FSliderStyle : public FSlateWidgetStyle
{
	public:
	    struct FSlateBrush NormalBarImage; // 0x8 Size: 0x88
	    struct FSlateBrush HoveredBarImage; // 0x90 Size: 0x88
	    struct FSlateBrush DisabledBarImage; // 0x118 Size: 0x88
	    struct FSlateBrush NormalThumbImage; // 0x1a0 Size: 0x88
	    struct FSlateBrush HoveredThumbImage; // 0x228 Size: 0x88
	    struct FSlateBrush DisabledThumbImage; // 0x2b0 Size: 0x88
	    float BarThickness; // 0x338 Size: 0x4
	    char UnknownData0[0x4];

};

struct FVolumeControlStyle : public FSlateWidgetStyle
{
	public:
	    struct FSliderStyle SliderStyle; // 0x8 Size: 0x340
	    struct FSlateBrush HighVolumeImage; // 0x348 Size: 0x88
	    struct FSlateBrush MidVolumeImage; // 0x3d0 Size: 0x88
	    struct FSlateBrush LowVolumeImage; // 0x458 Size: 0x88
	    struct FSlateBrush NoVolumeImage; // 0x4e0 Size: 0x88
	    struct FSlateBrush MutedImage; // 0x568 Size: 0x88

};

struct FSearchBoxStyle : public FSlateWidgetStyle
{
	public:
	    struct FEditableTextBoxStyle TextBoxStyle; // 0x8 Size: 0x7f0
	    struct FSlateFontInfo ActiveFontInfo; // 0x7f8 Size: 0x50
	    struct FSlateBrush UpArrowImage; // 0x848 Size: 0x88
	    struct FSlateBrush DownArrowImage; // 0x8d0 Size: 0x88
	    struct FSlateBrush GlassImage; // 0x958 Size: 0x88
	    struct FSlateBrush ClearImage; // 0x9e0 Size: 0x88
	    struct FMargin ImagePadding; // 0xa68 Size: 0x10
	    bool bLeftAlignButtons; // 0xa78 Size: 0x1
	    char UnknownData0[0x7];

};

struct FExpandableAreaStyle : public FSlateWidgetStyle
{
	public:
	    struct FSlateBrush CollapsedImage; // 0x8 Size: 0x88
	    struct FSlateBrush ExpandedImage; // 0x90 Size: 0x88
	    float RolloutAnimationSeconds; // 0x118 Size: 0x4
	    char UnknownData0[0x4];

};

struct FProgressBarStyle : public FSlateWidgetStyle
{
	public:
	    struct FSlateBrush BackgroundImage; // 0x8 Size: 0x88
	    struct FSlateBrush FillImage; // 0x90 Size: 0x88
	    struct FSlateBrush MarqueeImage; // 0x118 Size: 0x88

};

struct FInlineEditableTextBlockStyle : public FSlateWidgetStyle
{
	public:
	    struct FEditableTextBoxStyle EditableTextBoxStyle; // 0x8 Size: 0x7f0
	    struct FTextBlockStyle TextStyle; // 0x7f8 Size: 0x1e0

};

struct FHyperlinkStyle : public FSlateWidgetStyle
{
	public:
	    struct FButtonStyle UnderlineStyle; // 0x8 Size: 0x278
	    struct FTextBlockStyle TextStyle; // 0x280 Size: 0x1e0
	    struct FMargin Padding; // 0x460 Size: 0x10

};


}