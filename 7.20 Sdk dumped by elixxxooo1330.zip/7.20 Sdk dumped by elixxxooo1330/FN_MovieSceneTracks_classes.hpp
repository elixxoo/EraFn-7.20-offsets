#pragma once

#include "../SDK.hpp"

namespace SDK {


class UMovieSceneSpawnTrack : public UMovieSceneTrack
{
	public:
	    TArray<class UMovieSceneSection*> Sections; // 0x58 Size: 0x10
	    struct FGuid ObjectGuid; // 0x68 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneSpawnTrack");
			return (class UClass*)ptr;
		};

};

class UMovieScenePropertyTrack : public UMovieSceneNameableTrack
{
	public:
	    FName PropertyName; // 0x58 Size: 0x8
	    struct FString PropertyPath; // 0x60 Size: 0x10
	    TArray<class UMovieSceneSection*> Sections; // 0x70 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieScenePropertyTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneTransformOrigin : public UInterface
{
	public:
	    struct FTransform BP_GetTransformOrigin(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneTransformOrigin");
			return (class UClass*)ptr;
		};

};

class UMovieScene3DConstraintSection : public UMovieSceneSection
{
	public:
	    struct FGuid ConstraintId; // 0xe0 Size: 0x10
	    struct FMovieSceneObjectBindingID ConstraintBindingID; // 0xf0 Size: 0x18

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieScene3DConstraintSection");
			return (class UClass*)ptr;
		};

};

class UMovieScene3DAttachSection : public UMovieScene3DConstraintSection
{
	public:
	    FName AttachSocketName; // 0x108 Size: 0x8
	    FName AttachComponentName; // 0x110 Size: 0x8
	    EAttachmentRule AttachmentLocationRule; // 0x118 Size: 0x1
	    EAttachmentRule AttachmentRotationRule; // 0x119 Size: 0x1
	    EAttachmentRule AttachmentScaleRule; // 0x11a Size: 0x1
	    EDetachmentRule DetachmentLocationRule; // 0x11b Size: 0x1
	    EDetachmentRule DetachmentRotationRule; // 0x11c Size: 0x1
	    EDetachmentRule DetachmentScaleRule; // 0x11d Size: 0x1
	    char UnknownData0[0x2];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieScene3DAttachSection");
			return (class UClass*)ptr;
		};

};

class UMovieScene3DConstraintTrack : public UMovieSceneTrack
{
	public:
	    TArray<class UMovieSceneSection*> ConstraintSections; // 0x58 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieScene3DConstraintTrack");
			return (class UClass*)ptr;
		};

};

class UMovieScene3DAttachTrack : public UMovieScene3DConstraintTrack
{
	public:
	    char UnknownData0[0x68];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieScene3DAttachTrack");
			return (class UClass*)ptr;
		};

};

class UMovieScene3DPathSection : public UMovieScene3DConstraintSection
{
	public:
	    struct FMovieSceneFloatChannel TimingCurve; // 0x108 Size: 0xa0
	    MovieScene3DPathSection_Axis FrontAxisEnum; // 0x1a8 Size: 0x1
	    MovieScene3DPathSection_Axis UpAxisEnum; // 0x1a9 Size: 0x1
	    bool bFollow; // 0x1ac Size: 0x1
	    bool bReverse; // 0x1ac Size: 0x1
	    bool bForceUpright; // 0x1ac Size: 0x1
	    char UnknownData0[0x3];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieScene3DPathSection");
			return (class UClass*)ptr;
		};

};

class UMovieScene3DPathTrack : public UMovieScene3DConstraintTrack
{
	public:
	    char UnknownData0[0x68];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieScene3DPathTrack");
			return (class UClass*)ptr;
		};

};

class UMovieScene3DTransformSection : public UMovieSceneSection
{
	public:
	    struct FMovieSceneTransformMask TransformMask; // 0xe0 Size: 0x4
	    char UnknownData0[0x4]; // 0xe4
	    struct FMovieSceneFloatChannel* Translation; // 0xe8 Size: 0xa0
	    char UnknownData1[0x140]; // 0x188
	    struct FMovieSceneFloatChannel* Rotation; // 0x2c8 Size: 0xa0
	    char UnknownData2[0x140]; // 0x368
	    struct FMovieSceneFloatChannel* Scale; // 0x4a8 Size: 0xa0
	    char UnknownData3[0x140]; // 0x548
	    struct FMovieSceneFloatChannel ManualWeight; // 0x688 Size: 0xa0
	    bool bUseQuaternionInterpolation; // 0x72c Size: 0x1
	    char UnknownData4[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieScene3DTransformSection");
			return (class UClass*)ptr;
		};

};

class UMovieScene3DTransformTrack : public UMovieScenePropertyTrack
{
	public:
	    char UnknownData0[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieScene3DTransformTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneActorReferenceSection : public UMovieSceneSection
{
	public:
	    struct FMovieSceneActorReferenceData ActorReferenceData; // 0xe0 Size: 0xa0
	    struct FIntegralCurve ActorGuidIndexCurve; // 0x180 Size: 0x80
	    TArray<struct FString> ActorGuidStrings; // 0x200 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneActorReferenceSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneActorReferenceTrack : public UMovieScenePropertyTrack
{
	public:
	    char UnknownData0[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneActorReferenceTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneAudioSection : public UMovieSceneSection
{
	public:
	    class USoundBase* Sound; // 0xe0 Size: 0x8
	    float StartOffset; // 0xe8 Size: 0x4
	    float AudioStartTime; // 0xec Size: 0x4
	    float AudioDilationFactor; // 0xf0 Size: 0x4
	    float AudioVolume; // 0xf4 Size: 0x4
	    struct FMovieSceneFloatChannel SoundVolume; // 0xf8 Size: 0xa0
	    struct FMovieSceneFloatChannel PitchMultiplier; // 0x198 Size: 0xa0
	    bool bSuppressSubtitles; // 0x238 Size: 0x1
	    bool bOverrideAttenuation; // 0x239 Size: 0x1
	    char UnknownData0[0x6]; // 0x23a
	    class USoundAttenuation* AttenuationSettings; // 0x240 Size: 0x8
	    __int64/*DelegateProperty*/ OnQueueSubtitles; // 0x248 Size: 0x10
	    MulticastDelegateProperty OnAudioFinished; // 0x258 Size: 0x10
	    MulticastDelegateProperty OnAudioPlaybackPercent; // 0x268 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneAudioSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneAudioTrack : public UMovieSceneNameableTrack
{
	public:
	    TArray<class UMovieSceneSection*> AudioSections; // 0x58 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneAudioTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneBoolSection : public UMovieSceneSection
{
	public:
	    bool DefaultValue; // 0xe0 Size: 0x1
	    char UnknownData0[0x7]; // 0xe1
	    struct FMovieSceneBoolChannel BoolCurve; // 0xe8 Size: 0x90

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneBoolSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneBoolTrack : public UMovieScenePropertyTrack
{
	public:
	    char UnknownData0[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneBoolTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneByteSection : public UMovieSceneSection
{
	public:
	    struct FMovieSceneByteChannel ByteCurve; // 0xe0 Size: 0x98

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneByteSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneByteTrack : public UMovieScenePropertyTrack
{
	public:
	    class UEnum* Enum; // 0x80 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneByteTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneCameraAnimSection : public UMovieSceneSection
{
	public:
	    struct FMovieSceneCameraAnimSectionData AnimData; // 0xe0 Size: 0x20
	    class UCameraAnim* CameraAnim; // 0x100 Size: 0x8
	    float PlayRate; // 0x108 Size: 0x4
	    float PlayScale; // 0x10c Size: 0x4
	    float BlendInTime; // 0x110 Size: 0x4
	    float BlendOutTime; // 0x114 Size: 0x4
	    bool bLooping; // 0x118 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneCameraAnimSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneCameraAnimTrack : public UMovieSceneNameableTrack
{
	public:
	    TArray<class UMovieSceneSection*> CameraAnimSections; // 0x58 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneCameraAnimTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneCameraCutSection : public UMovieSceneSection
{
	public:
	    struct FGuid CameraGuid; // 0xe0 Size: 0x10
	    struct FMovieSceneObjectBindingID CameraBindingID; // 0xf0 Size: 0x18

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneCameraCutSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneCameraCutTrack : public UMovieSceneNameableTrack
{
	public:
	    TArray<class UMovieSceneSection*> Sections; // 0x58 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneCameraCutTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneCameraShakeSection : public UMovieSceneSection
{
	public:
	    struct FMovieSceneCameraShakeSectionData ShakeData; // 0xe0 Size: 0x20
	    class UCameraShake* ShakeClass; // 0x100 Size: 0x8
	    float PlayScale; // 0x108 Size: 0x4
	    char PlaySpace; // 0x10c Size: 0x1
	    char UnknownData0[0x3]; // 0x10d
	    struct FRotator UserDefinedPlaySpace; // 0x110 Size: 0xc
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneCameraShakeSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneCameraShakeTrack : public UMovieSceneNameableTrack
{
	public:
	    TArray<class UMovieSceneSection*> CameraShakeSections; // 0x58 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneCameraShakeTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneCinematicShotSection : public UMovieSceneSubSection
{
	public:
	    struct FString ShotDisplayName; // 0x150 Size: 0x10
	    struct FText DisplayName; // 0x160 Size: 0x18

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneCinematicShotSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneCinematicShotTrack : public UMovieSceneSubTrack
{
	public:
	    char UnknownData0[0x68];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneCinematicShotTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneColorSection : public UMovieSceneSection
{
	public:
	    struct FMovieSceneFloatChannel RedCurve; // 0xe0 Size: 0xa0
	    struct FMovieSceneFloatChannel GreenCurve; // 0x180 Size: 0xa0
	    struct FMovieSceneFloatChannel BlueCurve; // 0x220 Size: 0xa0
	    struct FMovieSceneFloatChannel AlphaCurve; // 0x2c0 Size: 0xa0

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneColorSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneColorTrack : public UMovieScenePropertyTrack
{
	public:
	    bool bIsSlateColor; // 0x80 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneColorTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneEnumSection : public UMovieSceneSection
{
	public:
	    struct FMovieSceneByteChannel EnumCurve; // 0xe0 Size: 0x98

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneEnumSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneEnumTrack : public UMovieScenePropertyTrack
{
	public:
	    class UEnum* Enum; // 0x80 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneEnumTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneEulerTransformTrack : public UMovieScenePropertyTrack
{
	public:
	    char UnknownData0[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneEulerTransformTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneEventSectionBase : public UMovieSceneSection
{
	public:
	    char UnknownData0[0xe0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneEventSectionBase");
			return (class UClass*)ptr;
		};

};

class UMovieSceneEventRepeaterSection : public UMovieSceneEventSectionBase
{
	public:
	    struct FMovieSceneEvent Event; // 0xe0 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneEventRepeaterSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneEventSection : public UMovieSceneSection
{
	public:
	    struct FNameCurve Events; // 0xe0 Size: 0x78
	    struct FMovieSceneEventSectionData EventData; // 0x158 Size: 0x88

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneEventSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneEventTrack : public UMovieSceneNameableTrack
{
	public:
	    bool bFireEventsWhenForwards; // 0x58 Size: 0x1
	    bool bFireEventsWhenBackwards; // 0x58 Size: 0x1
	    char UnknownData0[0x2]; // 0x5a
	    EFireEventsAtPosition EventPosition; // 0x5c Size: 0x1
	    char UnknownData1[0x3]; // 0x5d
	    TArray<struct FMovieSceneObjectBindingID> EventReceivers; // 0x60 Size: 0x10
	    TArray<class UMovieSceneSection*> Sections; // 0x70 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneEventTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneEventTriggerSection : public UMovieSceneEventSectionBase
{
	public:
	    struct FMovieSceneEventChannel EventChannel; // 0xe0 Size: 0x88

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneEventTriggerSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneFloatSection : public UMovieSceneSection
{
	public:
	    struct FMovieSceneFloatChannel FloatCurve; // 0xe0 Size: 0xa0

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneFloatSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneFadeSection : public UMovieSceneFloatSection
{
	public:
	    struct FLinearColor FadeColor; // 0x180 Size: 0x10
	    bool bFadeAudio; // 0x190 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneFadeSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneFloatTrack : public UMovieScenePropertyTrack
{
	public:
	    char UnknownData0[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneFloatTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneFadeTrack : public UMovieSceneFloatTrack
{
	public:
	    char UnknownData0[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneFadeTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneIntegerSection : public UMovieSceneSection
{
	public:
	    struct FMovieSceneIntegerChannel IntegerCurve; // 0xe0 Size: 0x90

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneIntegerSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneIntegerTrack : public UMovieScenePropertyTrack
{
	public:
	    char UnknownData0[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneIntegerTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneLevelVisibilitySection : public UMovieSceneSection
{
	public:
	    ELevelVisibility Visibility; // 0xe0 Size: 0x1
	    char UnknownData0[0x7]; // 0xe1
	    TArray<FName> LevelNames; // 0xe8 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneLevelVisibilitySection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneLevelVisibilityTrack : public UMovieSceneNameableTrack
{
	public:
	    TArray<class UMovieSceneSection*> Sections; // 0x58 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneLevelVisibilityTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneMaterialTrack : public UMovieSceneNameableTrack
{
	public:
	    TArray<class UMovieSceneSection*> Sections; // 0x58 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneMaterialTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneMaterialParameterCollectionTrack : public UMovieSceneMaterialTrack
{
	public:
	    class UMaterialParameterCollection* MPC; // 0x68 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneMaterialParameterCollectionTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneComponentMaterialTrack : public UMovieSceneMaterialTrack
{
	public:
	    int MaterialIndex; // 0x68 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneComponentMaterialTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneObjectPropertySection : public UMovieSceneSection
{
	public:
	    struct FMovieSceneObjectPathChannel ObjectChannel; // 0xe0 Size: 0xc0

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneObjectPropertySection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneObjectPropertyTrack : public UMovieScenePropertyTrack
{
	public:
	    class UObject* PropertyClass; // 0x80 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneObjectPropertyTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneParameterSection : public UMovieSceneSection
{
	public:
	    TArray<struct FScalarParameterNameAndCurve> ScalarParameterNamesAndCurves; // 0xe0 Size: 0x10
	    TArray<struct FVectorParameterNameAndCurves> VectorParameterNamesAndCurves; // 0xf0 Size: 0x10
	    TArray<struct FColorParameterNameAndCurves> ColorParameterNamesAndCurves; // 0x100 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneParameterSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneParticleParameterTrack : public UMovieSceneNameableTrack
{
	public:
	    TArray<class UMovieSceneSection*> Sections; // 0x58 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneParticleParameterTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneParticleSection : public UMovieSceneSection
{
	public:
	    struct FMovieSceneParticleChannel ParticleKeys; // 0xe0 Size: 0x98

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneParticleSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneParticleTrack : public UMovieSceneNameableTrack
{
	public:
	    TArray<class UMovieSceneSection*> ParticleSections; // 0x58 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneParticleTrack");
			return (class UClass*)ptr;
		};

};

class UMovieScenePrimitiveMaterialSection : public UMovieSceneSection
{
	public:
	    struct FMovieSceneObjectPathChannel MaterialChannel; // 0xe0 Size: 0xc0

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieScenePrimitiveMaterialSection");
			return (class UClass*)ptr;
		};

};

class UMovieScenePrimitiveMaterialTrack : public UMovieScenePropertyTrack
{
	public:
	    int MaterialIndex; // 0x80 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieScenePrimitiveMaterialTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneSkeletalAnimationSection : public UMovieSceneSection
{
	public:
	    struct FMovieSceneSkeletalAnimationParams Params; // 0xe0 Size: 0xc8
	    class UAnimSequence* AnimSequence; // 0x1a8 Size: 0x8
	    class UAnimSequenceBase* Animation; // 0x1b0 Size: 0x8
	    float StartOffset; // 0x1b8 Size: 0x4
	    float EndOffset; // 0x1bc Size: 0x4
	    float PlayRate; // 0x1c0 Size: 0x4
	    bool bReverse; // 0x1c4 Size: 0x1
	    char UnknownData0[0x3]; // 0x1c5
	    FName SlotName; // 0x1c8 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneSkeletalAnimationSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneSkeletalAnimationTrack : public UMovieSceneNameableTrack
{
	public:
	    TArray<class UMovieSceneSection*> AnimationSections; // 0x58 Size: 0x10
	    bool bUseLegacySectionIndexBlend; // 0x68 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneSkeletalAnimationTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneSlomoSection : public UMovieSceneFloatSection
{
	public:
	    char UnknownData0[0x180];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneSlomoSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneSlomoTrack : public UMovieSceneFloatTrack
{
	public:
	    char UnknownData0[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneSlomoTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneSpawnSection : public UMovieSceneBoolSection
{
	public:
	    char UnknownData0[0x178];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneSpawnSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneStringSection : public UMovieSceneSection
{
	public:
	    struct FMovieSceneStringChannel StringCurve; // 0xe0 Size: 0xa0

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneStringSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneStringTrack : public UMovieScenePropertyTrack
{
	public:
	    char UnknownData0[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneStringTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneTransformTrack : public UMovieScenePropertyTrack
{
	public:
	    char UnknownData0[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneTransformTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneVectorSection : public UMovieSceneSection
{
	public:
	    struct FMovieSceneFloatChannel* Curves; // 0xe0 Size: 0xa0
	    char UnknownData0[0x1e0]; // 0x180
	    int ChannelsUsed; // 0x360 Size: 0x4
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneVectorSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneVectorTrack : public UMovieScenePropertyTrack
{
	public:
	    int NumChannelsUsed; // 0x80 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneVectorTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneVisibilityTrack : public UMovieSceneBoolTrack
{
	public:
	    char UnknownData0[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneVisibilityTrack");
			return (class UClass*)ptr;
		};

};


}