#include "../SDK.hpp"

void UEpicCMSTileBase::Launch()
{
    static auto fn = UObject::FindObject("/Script/EpicCMSUIFramework.EpicCMSTileBase:Launch");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

void UEpicCMSTileCarousel::SetCurrentPageByIndex(int PageIndex)
{
	struct {
            int PageIndex;
	} params{ PageIndex };

    static auto fn = UObject::FindObject("/Script/EpicCMSUIFramework.EpicCMSTileCarousel:SetCurrentPageByIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UEpicCMSTileCarousel::PreviousPage()
{
    static auto fn = UObject::FindObject("/Script/EpicCMSUIFramework.EpicCMSTileCarousel:PreviousPage");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UEpicCMSTileCarousel::NextPage()
{
    static auto fn = UObject::FindObject("/Script/EpicCMSUIFramework.EpicCMSTileCarousel:NextPage");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UEpicCMSTileCarousel::NavigationVisibilityChanged(bool bShowNavigation)
{
	struct {
            bool bShowNavigation;
	} params{ bShowNavigation };

    static auto fn = UObject::FindObject("/Script/EpicCMSUIFramework.EpicCMSTileCarousel:NavigationVisibilityChanged");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UEpicCMSTileCarousel::HandleTilePageAdded(class UWidget* TileWidget)
{
	struct {
            class UWidget* TileWidget;
	} params{ TileWidget };

    static auto fn = UObject::FindObject("/Script/EpicCMSUIFramework.EpicCMSTileCarousel:HandleTilePageAdded");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


int UEpicCMSTileCarousel::GetCurrentPageIndex()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/EpicCMSUIFramework.EpicCMSTileCarousel:GetCurrentPageIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

