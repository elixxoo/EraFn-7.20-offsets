#include "../SDK.hpp"

void USynthComponent::Stop()
{
    static auto fn = UObject::FindObject("/Script/AudioMixer.SynthComponent:Stop");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void USynthComponent::Start()
{
    static auto fn = UObject::FindObject("/Script/AudioMixer.SynthComponent:Start");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void USynthComponent::SetVolumeMultiplier(float VolumeMultiplier)
{
	struct {
            float VolumeMultiplier;
	} params{ VolumeMultiplier };

    static auto fn = UObject::FindObject("/Script/AudioMixer.SynthComponent:SetVolumeMultiplier");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USynthComponent::SetSubmixSend(class USoundSubmix* Submix, float SendLevel)
{
	struct {
            class USoundSubmix* Submix;
            float SendLevel;
	} params{ Submix, SendLevel };

    static auto fn = UObject::FindObject("/Script/AudioMixer.SynthComponent:SetSubmixSend");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool USynthComponent::IsPlaying()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AudioMixer.SynthComponent:IsPlaying");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

static class USoundWave* UAudioMixerBlueprintLibrary::StopRecordingOutput(class UObject* WorldContextObject, EAudioRecordingExportType ExportType, struct FString Name, struct FString Path, class USoundSubmix* SubmixToRecord, class USoundWave* ExistingSoundWaveToOverwrite)
{
	struct {
            class UObject* WorldContextObject;
            EAudioRecordingExportType ExportType;
            struct FString Name;
            struct FString Path;
            class USoundSubmix* SubmixToRecord;
            class USoundWave* ExistingSoundWaveToOverwrite;
            class USoundWave* ReturnValue;
	} params{ WorldContextObject, ExportType, Name, Path, SubmixToRecord, ExistingSoundWaveToOverwrite };

    static auto fn = UObject::FindObject("/Script/AudioMixer.AudioMixerBlueprintLibrary:StopRecordingOutput");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAudioMixerBlueprintLibrary::StartRecordingOutput(class UObject* WorldContextObject, float ExpectedDuration, class USoundSubmix* SubmixToRecord)
{
	struct {
            class UObject* WorldContextObject;
            float ExpectedDuration;
            class USoundSubmix* SubmixToRecord;            void ReturnValue;
	} params{ WorldContextObject, ExpectedDuration, SubmixToRecord };

    static auto fn = UObject::FindObject("/Script/AudioMixer.AudioMixerBlueprintLibrary:StartRecordingOutput");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAudioMixerBlueprintLibrary::SetBypassSourceEffectChainEntry(class UObject* WorldContextObject, class USoundEffectSourcePresetChain* PresetChain, int EntryIndex, bool bBypassed)
{
	struct {
            class UObject* WorldContextObject;
            class USoundEffectSourcePresetChain* PresetChain;
            int EntryIndex;
            bool bBypassed;            void ReturnValue;
	} params{ WorldContextObject, PresetChain, EntryIndex, bBypassed };

    static auto fn = UObject::FindObject("/Script/AudioMixer.AudioMixerBlueprintLibrary:SetBypassSourceEffectChainEntry");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAudioMixerBlueprintLibrary::ResumeRecordingOutput(class UObject* WorldContextObject, class USoundSubmix* SubmixToPause)
{
	struct {
            class UObject* WorldContextObject;
            class USoundSubmix* SubmixToPause;            void ReturnValue;
	} params{ WorldContextObject, SubmixToPause };

    static auto fn = UObject::FindObject("/Script/AudioMixer.AudioMixerBlueprintLibrary:ResumeRecordingOutput");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAudioMixerBlueprintLibrary::RemoveSourceEffectFromPresetChain(class UObject* WorldContextObject, class USoundEffectSourcePresetChain* PresetChain, int EntryIndex)
{
	struct {
            class UObject* WorldContextObject;
            class USoundEffectSourcePresetChain* PresetChain;
            int EntryIndex;            void ReturnValue;
	} params{ WorldContextObject, PresetChain, EntryIndex };

    static auto fn = UObject::FindObject("/Script/AudioMixer.AudioMixerBlueprintLibrary:RemoveSourceEffectFromPresetChain");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAudioMixerBlueprintLibrary::RemoveMasterSubmixEffect(class UObject* WorldContextObject, class USoundEffectSubmixPreset* SubmixEffectPreset)
{
	struct {
            class UObject* WorldContextObject;
            class USoundEffectSubmixPreset* SubmixEffectPreset;            void ReturnValue;
	} params{ WorldContextObject, SubmixEffectPreset };

    static auto fn = UObject::FindObject("/Script/AudioMixer.AudioMixerBlueprintLibrary:RemoveMasterSubmixEffect");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAudioMixerBlueprintLibrary::PauseRecordingOutput(class UObject* WorldContextObject, class USoundSubmix* SubmixToPause)
{
	struct {
            class UObject* WorldContextObject;
            class USoundSubmix* SubmixToPause;            void ReturnValue;
	} params{ WorldContextObject, SubmixToPause };

    static auto fn = UObject::FindObject("/Script/AudioMixer.AudioMixerBlueprintLibrary:PauseRecordingOutput");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static int UAudioMixerBlueprintLibrary::GetNumberOfEntriesInSourceEffectChain(class UObject* WorldContextObject, class USoundEffectSourcePresetChain* PresetChain)
{
	struct {
            class UObject* WorldContextObject;
            class USoundEffectSourcePresetChain* PresetChain;
            int ReturnValue;
	} params{ WorldContextObject, PresetChain };

    static auto fn = UObject::FindObject("/Script/AudioMixer.AudioMixerBlueprintLibrary:GetNumberOfEntriesInSourceEffectChain");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAudioMixerBlueprintLibrary::ClearMasterSubmixEffects(class UObject* WorldContextObject)
{
	struct {
            class UObject* WorldContextObject;            void ReturnValue;
	} params{ WorldContextObject };

    static auto fn = UObject::FindObject("/Script/AudioMixer.AudioMixerBlueprintLibrary:ClearMasterSubmixEffects");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAudioMixerBlueprintLibrary::AddSourceEffectToPresetChain(class UObject* WorldContextObject, class USoundEffectSourcePresetChain* PresetChain, struct FSourceEffectChainEntry Entry)
{
	struct {
            class UObject* WorldContextObject;
            class USoundEffectSourcePresetChain* PresetChain;
            struct FSourceEffectChainEntry Entry;            void ReturnValue;
	} params{ WorldContextObject, PresetChain, Entry };

    static auto fn = UObject::FindObject("/Script/AudioMixer.AudioMixerBlueprintLibrary:AddSourceEffectToPresetChain");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAudioMixerBlueprintLibrary::AddMasterSubmixEffect(class UObject* WorldContextObject, class USoundEffectSubmixPreset* SubmixEffectPreset)
{
	struct {
            class UObject* WorldContextObject;
            class USoundEffectSubmixPreset* SubmixEffectPreset;            void ReturnValue;
	} params{ WorldContextObject, SubmixEffectPreset };

    static auto fn = UObject::FindObject("/Script/AudioMixer.AudioMixerBlueprintLibrary:AddMasterSubmixEffect");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void USubmixEffectDynamicsProcessorPreset::SetSettings(struct FSubmixEffectDynamicsProcessorSettings InSettings)
{
	struct {
            struct FSubmixEffectDynamicsProcessorSettings InSettings;
	} params{ InSettings };

    static auto fn = UObject::FindObject("/Script/AudioMixer.SubmixEffectDynamicsProcessorPreset:SetSettings");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void USubmixEffectSubmixEQPreset::SetSettings(struct FSubmixEffectSubmixEQSettings InSettings)
{
	struct {
            struct FSubmixEffectSubmixEQSettings InSettings;
	} params{ InSettings };

    static auto fn = UObject::FindObject("/Script/AudioMixer.SubmixEffectSubmixEQPreset:SetSettings");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void USubmixEffectReverbPreset::SetSettingsWithReverbEffect(class UReverbEffect* InReverbEffect, float WetLevel, float DryLevel)
{
	struct {
            class UReverbEffect* InReverbEffect;
            float WetLevel;
            float DryLevel;
	} params{ InReverbEffect, WetLevel, DryLevel };

    static auto fn = UObject::FindObject("/Script/AudioMixer.SubmixEffectReverbPreset:SetSettingsWithReverbEffect");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USubmixEffectReverbPreset::SetSettings(struct FSubmixEffectReverbSettings InSettings)
{
	struct {
            struct FSubmixEffectReverbSettings InSettings;
	} params{ InSettings };

    static auto fn = UObject::FindObject("/Script/AudioMixer.SubmixEffectReverbPreset:SetSettings");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

