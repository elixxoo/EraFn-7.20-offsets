#pragma once

#include "../SDK.hpp"

namespace SDK {


class USignificanceManager : public UObject
{
	public:
	    char UnknownData0[0xd8];
	    struct FSoftClassPath SignificanceManagerClassName; // 0x100 Size: 0x18
	    char UnknownData1[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SignificanceManager.SignificanceManager");
			return (class UClass*)ptr;
		};

};


}