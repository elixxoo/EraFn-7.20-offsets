#pragma once

#include "../SDK.hpp"

namespace SDK {


class UMediaSource : public UObject
{
	public:
	    bool Validate(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    struct FString GetUrl(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7fb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MediaAssets.MediaSource");
			return (class UClass*)ptr;
		};

};

class UBaseMediaSource : public UMediaSource
{
	public:
	    FName PlayerName; // 0x30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MediaAssets.BaseMediaSource");
			return (class UClass*)ptr;
		};

};

class UFileMediaSource : public UBaseMediaSource
{
	public:
	    struct FString FilePath; // 0x38 Size: 0x10
	    bool PrecacheFile; // 0x48 Size: 0x1
	    char UnknownData0[0x49]; // 0x49
	    void SetFilePath(struct FString Path); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MediaAssets.FileMediaSource");
			return (class UClass*)ptr;
		};

};

class UMediaBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void EnumerateWebcamCaptureDevices(TArray<struct FMediaCaptureDevice> OutDevices, int Filter); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void EnumerateVideoCaptureDevices(TArray<struct FMediaCaptureDevice> OutDevices, int Filter); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static void EnumerateAudioCaptureDevices(TArray<struct FMediaCaptureDevice> OutDevices, int Filter); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MediaAssets.MediaBlueprintFunctionLibrary");
			return (class UClass*)ptr;
		};

};

class UMediaPlayer : public UObject
{
	public:
	    MulticastDelegateProperty OnEndReached; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnMediaClosed; // 0x38 Size: 0x10
	    MulticastDelegateProperty OnMediaOpened; // 0x48 Size: 0x10
	    MulticastDelegateProperty OnMediaOpenFailed; // 0x58 Size: 0x10
	    MulticastDelegateProperty OnPlaybackResumed; // 0x68 Size: 0x10
	    MulticastDelegateProperty OnPlaybackSuspended; // 0x78 Size: 0x10
	    MulticastDelegateProperty OnSeekCompleted; // 0x88 Size: 0x10
	    MulticastDelegateProperty OnTracksChanged; // 0x98 Size: 0x10
	    struct FTimespan CacheAhead; // 0xa8 Size: 0x8
	    struct FTimespan CacheBehind; // 0xb0 Size: 0x8
	    struct FTimespan CacheBehindGame; // 0xb8 Size: 0x8
	    bool NativeAudioOut; // 0xc0 Size: 0x1
	    bool PlayOnOpen; // 0xc1 Size: 0x1
	    bool Shuffle; // 0xc4 Size: 0x1
	    bool Loop; // 0xc4 Size: 0x1
	    char UnknownData0[0x4]; // 0xc4
	    class UMediaPlaylist* Playlist; // 0xc8 Size: 0x8
	    int PlaylistIndex; // 0xd0 Size: 0x4
	    char UnknownData1[0x4]; // 0xd4
	    struct FTimespan TimeDelay; // 0xd8 Size: 0x8
	    float HorizontalFieldOfView; // 0xe0 Size: 0x4
	    float VerticalFieldOfView; // 0xe4 Size: 0x4
	    struct FRotator ViewRotation; // 0xe8 Size: 0xc
	    char UnknownData2[0x2c]; // 0xf4
	    struct FGuid PlayerGuid; // 0x120 Size: 0x10
	    char UnknownData3[0x130]; // 0x130
	    bool SupportsSeeking(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool SupportsScrubbing(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool SupportsRate(float Rate, bool Unthinned); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool SetViewRotation(struct FRotator Rotation, bool Absolute); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool SetViewField(float Horizontal, float Vertical, bool Absolute); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool SetVideoTrackFrameRate(int TrackIndex, int FormatIndex, float FrameRate); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool SetTrackFormat(EMediaPlayerTrack TrackType, int TrackIndex, int FormatIndex); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetTimeDelay(struct FTimespan TimeDelay); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    bool SetRate(float Rate); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    bool SetNativeVolume(float Volume); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    bool SetLooping(bool Looping); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void SetDesiredPlayerName(FName PlayerName); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void SetBlockOnTime(struct FTimespan Time); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    bool SelectTrack(EMediaPlayerTrack TrackType, int TrackIndex); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    bool Seek(struct FTimespan Time); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    bool Rewind(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    bool Reopen(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    bool Previous(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    bool Play(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    bool Pause(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    bool OpenUrl(struct FString URL); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    bool OpenSourceWithOptions(class UMediaSource* MediaSource, struct FMediaPlayerOptions Options); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    bool OpenSource(class UMediaSource* MediaSource); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    bool OpenPlaylistIndex(class UMediaPlaylist* InPlaylist, int Index); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    bool OpenPlaylist(class UMediaPlaylist* InPlaylist); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    bool OpenFile(struct FString FilePath); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    bool Next(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    bool IsReady(); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    bool IsPreparing(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    bool IsPlaying(); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    bool IsPaused(); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    bool IsLooping(); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    bool IsConnecting(); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    bool IsBuffering(); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    bool HasError(); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    struct FRotator GetViewRotation(); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    struct FString GetVideoTrackType(int TrackIndex, int FormatIndex); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    struct FFloatRange GetVideoTrackFrameRates(int TrackIndex, int FormatIndex); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    float GetVideoTrackFrameRate(int TrackIndex, int FormatIndex); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    struct FIntPoint GetVideoTrackDimensions(int TrackIndex, int FormatIndex); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    float GetVideoTrackAspectRatio(int TrackIndex, int FormatIndex); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    float GetVerticalFieldOfView(); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    struct FString GetUrl(); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    struct FString GetTrackLanguage(EMediaPlayerTrack TrackType, int TrackIndex); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    int GetTrackFormat(EMediaPlayerTrack TrackType, int TrackIndex); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    struct FText GetTrackDisplayName(EMediaPlayerTrack TrackType, int TrackIndex); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    struct FTimespan GetTimeDelay(); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    struct FTimespan GetTime(); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    void GetSupportedRates(TArray<struct FFloatRange> OutRates, bool Unthinned); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    int GetSelectedTrack(EMediaPlayerTrack TrackType); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    float GetRate(); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    int GetPlaylistIndex(); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    class UMediaPlaylist* GetPlaylist(); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    FName GetPlayerName(); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    int GetNumTracks(EMediaPlayerTrack TrackType); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    int GetNumTrackFormats(EMediaPlayerTrack TrackType, int TrackIndex); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    struct FText GetMediaName(); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    float GetHorizontalFieldOfView(); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    struct FTimespan GetDuration(); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x7fe1]; // 0x7fe1
	    FName GetDesiredPlayerName(); // 0x0 Size: 0x7fe1
	    char UnknownData63[0x7fe1]; // 0x7fe1
	    struct FString GetAudioTrackType(int TrackIndex, int FormatIndex); // 0x0 Size: 0x7fe1
	    char UnknownData64[0x7fe1]; // 0x7fe1
	    int GetAudioTrackSampleRate(int TrackIndex, int FormatIndex); // 0x0 Size: 0x7fe1
	    char UnknownData65[0x7fe1]; // 0x7fe1
	    int GetAudioTrackChannels(int TrackIndex, int FormatIndex); // 0x0 Size: 0x7fe1
	    char UnknownData66[0x7fe1]; // 0x7fe1
	    void Close(); // 0x0 Size: 0x7fe1
	    char UnknownData67[0x7fe1]; // 0x7fe1
	    bool CanPlayUrl(struct FString URL); // 0x0 Size: 0x7fe1
	    char UnknownData68[0x7fe1]; // 0x7fe1
	    bool CanPlaySource(class UMediaSource* MediaSource); // 0x0 Size: 0x7fe1
	    char UnknownData69[0x7fe1]; // 0x7fe1
	    bool CanPause(); // 0x0 Size: 0x7fe1
	    char UnknownData70[0x-7ea9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MediaAssets.MediaPlayer");
			return (class UClass*)ptr;
		};

};

class UMediaPlaylist : public UObject
{
	public:
	    TArray<class UMediaSource*> Items; // 0x28 Size: 0x10
	    char UnknownData0[0x38]; // 0x38
	    bool Replace(int Index, class UMediaSource* Replacement); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool RemoveAt(int Index); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool Remove(class UMediaSource* MediaSource); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    int Num(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void Insert(class UMediaSource* MediaSource, int Index); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    class UMediaSource* GetRandom(int OutIndex); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    class UMediaSource* GetPrevious(int InOutIndex); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    class UMediaSource* GetNext(int InOutIndex); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    class UMediaSource* Get(int Index); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool AddUrl(struct FString URL); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    bool AddFile(struct FString FilePath); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    bool Add(class UMediaSource* MediaSource); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7fa9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MediaAssets.MediaPlaylist");
			return (class UClass*)ptr;
		};

};

class UMediaSoundComponent : public USynthComponent
{
	public:
	    EMediaSoundChannels Channels; // 0x610 Size: 0x4
	    bool DynamicRateAdjustment; // 0x614 Size: 0x1
	    char UnknownData0[0x3]; // 0x615
	    float RateAdjustmentFactor; // 0x618 Size: 0x4
	    struct FFloatRange RateAdjustmentRange; // 0x61c Size: 0x10
	    char UnknownData1[0x4]; // 0x62c
	    class UMediaPlayer* MediaPlayer; // 0x630 Size: 0x8
	    char UnknownData2[0x638]; // 0x638
	    void SetSpectralAnalysisSettings(TArray<float> InFrequenciesToAnalyze, EMediaSoundComponentFFTSize InFFTSize); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetMediaPlayer(class UMediaPlayer* NewMediaPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetEnableSpectralAnalysis(bool bInSpectralAnalysisEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    TArray<struct FMediaSoundComponentSpectralData> GetSpectralData(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    class UMediaPlayer* GetMediaPlayer(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool BP_GetAttenuationSettingsToApply(struct FSoundAttenuationSettings OutAttenuationSettings); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7831];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MediaAssets.MediaSoundComponent");
			return (class UClass*)ptr;
		};

};

class UMediaTexture : public UTexture
{
	public:
	    char AddressX; // 0xb8 Size: 0x1
	    char AddressY; // 0xb9 Size: 0x1
	    bool AutoClear; // 0xba Size: 0x1
	    char UnknownData0[0x1]; // 0xbb
	    struct FLinearColor ClearColor; // 0xbc Size: 0x10
	    char UnknownData1[0x4]; // 0xcc
	    class UMediaPlayer* MediaPlayer; // 0xd0 Size: 0x8
	    char UnknownData2[0xd8]; // 0xd8
	    void SetMediaPlayer(class UMediaPlayer* NewMediaPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    int GetWidth(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    class UMediaPlayer* GetMediaPlayer(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    int GetHeight(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    float GetAspectRatio(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7e99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MediaAssets.MediaTexture");
			return (class UClass*)ptr;
		};

};

class UPlatformMediaSource : public UMediaSource
{
	public:
	    class UMediaSource* MediaSource; // 0x30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MediaAssets.PlatformMediaSource");
			return (class UClass*)ptr;
		};

};

class UStreamMediaSource : public UBaseMediaSource
{
	public:
	    struct FString StreamUrl; // 0x38 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MediaAssets.StreamMediaSource");
			return (class UClass*)ptr;
		};

};

class UTimeSynchronizableMediaSource : public UBaseMediaSource
{
	public:
	    bool bUseTimeSynchronization; // 0x38 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MediaAssets.TimeSynchronizableMediaSource");
			return (class UClass*)ptr;
		};

};


}