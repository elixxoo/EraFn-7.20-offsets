#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FLiveLinkTickSignature__DelegateSignature
{
	public:
	    float DeltaTime; // 0x0 Size: 0x4

};

struct FAnimNode_LiveLinkPose : public FAnimNode_Base
{
	public:
	    FName SubjectName; // 0x10 Size: 0x8
	    class ULiveLinkRetargetAsset* RetargetAsset; // 0x18 Size: 0x8
	    class ULiveLinkRetargetAsset* CurrentRetargetAsset; // 0x20 Size: 0x8
	    char UnknownData0[0x10];

};

struct FSubjectFrameHandle
{
	public:
	    char UnknownData0[0x18];

};

struct FLiveLinkTransform
{
	public:
	    char UnknownData0[0x20];

};

struct FCachedSubjectFrame
{
	public:
	    char UnknownData0[0x140];

};

struct FSubjectMetadata
{
	public:
	    __int64/*MapProperty*/ StringMetadata; // 0x0 Size: 0x50
	    struct FTimecode SceneTimecode; // 0x50 Size: 0x14
	    struct FFrameRate SceneFramerate; // 0x64 Size: 0x8
	    char UnknownData0[0x4];

};

struct FLiveLinkInstanceProxy : public FAnimInstanceProxy
{
	public:
	    char UnknownData0[0x740];

};

struct FProviderPollResult
{
	public:
	    struct FString Name; // 0x10 Size: 0x10
	    struct FString MachineName; // 0x20 Size: 0x10

};

struct FLiveLinkRetargetAssetReference
{
	public:
	    class ULiveLinkRetargetAsset* CurrentRetargetAsset; // 0x0 Size: 0x8

};


}