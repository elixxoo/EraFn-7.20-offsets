#pragma once

#include "../SDK.hpp"

namespace SDK {


class UWheeledVehicleMovementComponent : public UPawnMovementComponent
{
	public:
	    char UnknownData0[0x8];
	    bool bDeprecatedSpringOffsetMode; // 0x188 Size: 0x1
	    bool bReverseAsBrake; // 0x188 Size: 0x1
	    bool bUseRVOAvoidance; // 0x188 Size: 0x1
	    bool bRawHandbrakeInput; // 0x188 Size: 0x1
	    bool bRawGearUpInput; // 0x188 Size: 0x1
	    bool bRawGearDownInput; // 0x188 Size: 0x1
	    bool bWasAvoidanceUpdated; // 0x18c Size: 0x1
	    char UnknownData1[0x1]; // 0x18f
	    float Mass; // 0x190 Size: 0x4
	    char UnknownData2[0x4]; // 0x194
	    TArray<struct FWheelSetup> WheelSetups; // 0x198 Size: 0x10
	    float DragCoefficient; // 0x1a8 Size: 0x4
	    float ChassisWidth; // 0x1ac Size: 0x4
	    float ChassisHeight; // 0x1b0 Size: 0x4
	    float DragArea; // 0x1b4 Size: 0x4
	    float EstimatedMaxEngineSpeed; // 0x1b8 Size: 0x4
	    float MaxEngineRPM; // 0x1bc Size: 0x4
	    float DebugDragMagnitude; // 0x1c0 Size: 0x4
	    struct FVector InertiaTensorScale; // 0x1c4 Size: 0xc
	    float MinNormalizedTireLoad; // 0x1d0 Size: 0x4
	    float MinNormalizedTireLoadFiltered; // 0x1d4 Size: 0x4
	    float MaxNormalizedTireLoad; // 0x1d8 Size: 0x4
	    float MaxNormalizedTireLoadFiltered; // 0x1dc Size: 0x4
	    float ThresholdLongitudinalSpeed; // 0x1e0 Size: 0x4
	    int LowForwardSpeedSubStepCount; // 0x1e4 Size: 0x4
	    int HighForwardSpeedSubStepCount; // 0x1e8 Size: 0x4
	    char UnknownData3[0x4]; // 0x1ec
	    TArray<class UVehicleWheel*> Wheels; // 0x1f0 Size: 0x10
	    char UnknownData4[0x18]; // 0x200
	    float RVOAvoidanceRadius; // 0x218 Size: 0x4
	    float RVOAvoidanceHeight; // 0x21c Size: 0x4
	    float AvoidanceConsiderationRadius; // 0x220 Size: 0x4
	    float RVOSteeringStep; // 0x224 Size: 0x4
	    float RVOThrottleStep; // 0x228 Size: 0x4
	    int AvoidanceUID; // 0x22c Size: 0x4
	    struct FNavAvoidanceMask AvoidanceGroup; // 0x230 Size: 0x4
	    struct FNavAvoidanceMask GroupsToAvoid; // 0x234 Size: 0x4
	    struct FNavAvoidanceMask GroupsToIgnore; // 0x238 Size: 0x4
	    float AvoidanceWeight; // 0x23c Size: 0x4
	    struct FVector PendingLaunchVelocity; // 0x240 Size: 0xc
	    struct FReplicatedVehicleState ReplicatedState; // 0x24c Size: 0x14
	    char UnknownData5[0x4]; // 0x260
	    float RawSteeringInput; // 0x264 Size: 0x4
	    float RawThrottleInput; // 0x268 Size: 0x4
	    float RawBrakeInput; // 0x26c Size: 0x4
	    float SteeringInput; // 0x270 Size: 0x4
	    float ThrottleInput; // 0x274 Size: 0x4
	    float BrakeInput; // 0x278 Size: 0x4
	    float HandbrakeInput; // 0x27c Size: 0x4
	    float IdleBrakeInput; // 0x280 Size: 0x4
	    float StopThreshold; // 0x284 Size: 0x4
	    float WrongDirectionThreshold; // 0x288 Size: 0x4
	    struct FVehicleInputRate ThrottleInputRate; // 0x28c Size: 0x8
	    struct FVehicleInputRate BrakeInputRate; // 0x294 Size: 0x8
	    struct FVehicleInputRate HandbrakeInputRate; // 0x29c Size: 0x8
	    struct FVehicleInputRate SteeringInputRate; // 0x2a4 Size: 0x8
	    char UnknownData6[0x24]; // 0x2ac
	    class AController* OverrideController; // 0x2d0 Size: 0x8
	    char UnknownData7[0x2d8]; // 0x2d8
	    void SetUseAutoGears(bool bUseAuto); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetThrottleInput(float Throttle); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetTargetGear(int GearNum, bool bImmediate); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetSteeringInput(float Steering); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetHandbrakeInput(bool bNewHandbrake); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetGroupsToIgnoreMask(struct FNavAvoidanceMask GroupMask); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void SetGroupsToIgnore(int GroupFlags); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void SetGroupsToAvoidMask(struct FNavAvoidanceMask GroupMask); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void SetGroupsToAvoid(int GroupFlags); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void SetGearUp(bool bNewGearUp); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void SetGearDown(bool bNewGearDown); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void SetBrakeInput(float Brake); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void SetAvoidanceGroupMask(struct FNavAvoidanceMask GroupMask); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void SetAvoidanceGroup(int GroupFlags); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void SetAvoidanceEnabled(bool bEnable); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void ServerUpdateState(float InSteeringInput, float InThrottleInput, float InBrakeInput, float InHandbrakeInput, int CurrentGear); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    bool GetUseAutoGears(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    int GetTargetGear(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    float GetForwardSpeed(); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    float GetEngineRotationSpeed(); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    float GetEngineMaxRotationSpeed(); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    int GetCurrentGear(); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x-7d09];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent");
			return (class UClass*)ptr;
		};

};

class USimpleWheeledVehicleMovementComponent : public UWheeledVehicleMovementComponent
{
	public:
	    void SetSteerAngle(float SteerAngle, int WheelIndex); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void SetDriveTorque(float DriveTorque, int WheelIndex); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetBrakeTorque(float BrakeTorque, int WheelIndex); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d09];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/PhysXVehicles.SimpleWheeledVehicleMovementComponent");
			return (class UClass*)ptr;
		};

};

class UTireConfig : public UDataAsset
{
	public:
	    float FrictionScale; // 0x30 Size: 0x4
	    char UnknownData0[0x4]; // 0x34
	    TArray<struct FTireConfigMaterialFriction> TireFrictionScales; // 0x38 Size: 0x10
	    char UnknownData1[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/PhysXVehicles.TireConfig");
			return (class UClass*)ptr;
		};

};

class UVehicleAnimInstance : public UAnimInstance
{
	public:
	    char UnknownData0[0x720];
	    class UWheeledVehicleMovementComponent* WheeledVehicleMovementComponent; // 0x990 Size: 0x8
	    char UnknownData1[0x998]; // 0x998
	    class AWheeledVehicle* GetVehicle(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7641];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/PhysXVehicles.VehicleAnimInstance");
			return (class UClass*)ptr;
		};

};

class UVehicleWheel : public UObject
{
	public:
	    class UStaticMesh* CollisionMesh; // 0x28 Size: 0x8
	    bool bDontCreateShape; // 0x30 Size: 0x1
	    bool bAutoAdjustCollisionSize; // 0x31 Size: 0x1
	    char UnknownData0[0x2]; // 0x32
	    struct FVector Offset; // 0x34 Size: 0xc
	    float ShapeRadius; // 0x40 Size: 0x4
	    float ShapeWidth; // 0x44 Size: 0x4
	    float Mass; // 0x48 Size: 0x4
	    float DampingRate; // 0x4c Size: 0x4
	    float SteerAngle; // 0x50 Size: 0x4
	    bool bAffectedByHandbrake; // 0x54 Size: 0x1
	    char UnknownData1[0x3]; // 0x55
	    class UTireType* TireType; // 0x58 Size: 0x8
	    class UTireConfig* TireConfig; // 0x60 Size: 0x8
	    float LatStiffMaxLoad; // 0x68 Size: 0x4
	    float LatStiffValue; // 0x6c Size: 0x4
	    float LongStiffValue; // 0x70 Size: 0x4
	    float SuspensionForceOffset; // 0x74 Size: 0x4
	    float SuspensionMaxRaise; // 0x78 Size: 0x4
	    float SuspensionMaxDrop; // 0x7c Size: 0x4
	    float SuspensionNaturalFrequency; // 0x80 Size: 0x4
	    float SuspensionDampingRatio; // 0x84 Size: 0x4
	    char SweepType; // 0x88 Size: 0x1
	    char UnknownData2[0x3]; // 0x89
	    float MaxBrakeTorque; // 0x8c Size: 0x4
	    float MaxHandBrakeTorque; // 0x90 Size: 0x4
	    char UnknownData3[0x4]; // 0x94
	    class UWheeledVehicleMovementComponent* VehicleSim; // 0x98 Size: 0x8
	    int WheelIndex; // 0xa0 Size: 0x4
	    float DebugLongSlip; // 0xa4 Size: 0x4
	    float DebugLatSlip; // 0xa8 Size: 0x4
	    float DebugNormalizedTireLoad; // 0xac Size: 0x4
	    char UnknownData4[0x4]; // 0xb0
	    float DebugWheelTorque; // 0xb4 Size: 0x4
	    float DebugLongForce; // 0xb8 Size: 0x4
	    float DebugLatForce; // 0xbc Size: 0x4
	    struct FVector Location; // 0xc0 Size: 0xc
	    struct FVector OldLocation; // 0xcc Size: 0xc
	    struct FVector Velocity; // 0xd8 Size: 0xc
	    char UnknownData5[0xe4]; // 0xe4
	    bool IsInAir(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    float GetSuspensionOffset(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    float GetSteerAngle(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    float GetRotationAngle(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7ef1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/PhysXVehicles.VehicleWheel");
			return (class UClass*)ptr;
		};

};

class AWheeledVehicle : public APawn
{
	public:
	    class USkeletalMeshComponent* Mesh; // 0x390 Size: 0x8
	    class UWheeledVehicleMovementComponent* VehicleMovement; // 0x398 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicle");
			return (class UClass*)ptr;
		};

};

class UWheeledVehicleMovementComponent4W : public UWheeledVehicleMovementComponent
{
	public:
	    struct FVehicleEngineData EngineSetup; // 0x2d8 Size: 0xa0
	    struct FVehicleDifferential4WData DifferentialSetup; // 0x378 Size: 0x1c
	    float AckermannAccuracy; // 0x394 Size: 0x4
	    struct FVehicleTransmissionData TransmissionSetup; // 0x398 Size: 0x30
	    struct FRuntimeFloatCurve SteeringCurve; // 0x3c8 Size: 0x88

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent4W");
			return (class UClass*)ptr;
		};

};


}