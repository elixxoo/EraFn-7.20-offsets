#pragma once

#include "../SDK.hpp"

namespace SDK {


class UButtonWidgetStyle : public USlateWidgetStyleContainerBase
{
	public:
	    struct FButtonStyle ButtonStyle; // 0x30 Size: 0x278

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Slate.ButtonWidgetStyle");
			return (class UClass*)ptr;
		};

};

class UCheckBoxWidgetStyle : public USlateWidgetStyleContainerBase
{
	public:
	    struct FCheckBoxStyle CheckBoxStyle; // 0x30 Size: 0x580

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Slate.CheckBoxWidgetStyle");
			return (class UClass*)ptr;
		};

};

class UComboBoxWidgetStyle : public USlateWidgetStyleContainerBase
{
	public:
	    struct FComboBoxStyle ComboBoxStyle; // 0x30 Size: 0x3d8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Slate.ComboBoxWidgetStyle");
			return (class UClass*)ptr;
		};

};

class UComboButtonWidgetStyle : public USlateWidgetStyleContainerBase
{
	public:
	    struct FComboButtonStyle ComboButtonStyle; // 0x30 Size: 0x3a0

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Slate.ComboButtonWidgetStyle");
			return (class UClass*)ptr;
		};

};

class UEditableTextBoxWidgetStyle : public USlateWidgetStyleContainerBase
{
	public:
	    struct FEditableTextBoxStyle EditableTextBoxStyle; // 0x30 Size: 0x7f0

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Slate.EditableTextBoxWidgetStyle");
			return (class UClass*)ptr;
		};

};

class UEditableTextWidgetStyle : public USlateWidgetStyleContainerBase
{
	public:
	    struct FEditableTextStyle EditableTextStyle; // 0x30 Size: 0x218

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Slate.EditableTextWidgetStyle");
			return (class UClass*)ptr;
		};

};

class UProgressWidgetStyle : public USlateWidgetStyleContainerBase
{
	public:
	    struct FProgressBarStyle ProgressBarStyle; // 0x30 Size: 0x1a0

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Slate.ProgressWidgetStyle");
			return (class UClass*)ptr;
		};

};

class UScrollBarWidgetStyle : public USlateWidgetStyleContainerBase
{
	public:
	    struct FScrollBarStyle ScrollBarStyle; // 0x30 Size: 0x4d0

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Slate.ScrollBarWidgetStyle");
			return (class UClass*)ptr;
		};

};

class UScrollBoxWidgetStyle : public USlateWidgetStyleContainerBase
{
	public:
	    struct FScrollBoxStyle ScrollBoxStyle; // 0x30 Size: 0x228

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Slate.ScrollBoxWidgetStyle");
			return (class UClass*)ptr;
		};

};

class USlateSettings : public UObject
{
	public:
	    bool bExplicitCanvasChildZOrder; // 0x28 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Slate.SlateSettings");
			return (class UClass*)ptr;
		};

};

class USpinBoxWidgetStyle : public USlateWidgetStyleContainerBase
{
	public:
	    struct FSpinBoxStyle SpinBoxStyle; // 0x30 Size: 0x2e8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Slate.SpinBoxWidgetStyle");
			return (class UClass*)ptr;
		};

};

class UTextBlockWidgetStyle : public USlateWidgetStyleContainerBase
{
	public:
	    struct FTextBlockStyle TextBlockStyle; // 0x30 Size: 0x1e0

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Slate.TextBlockWidgetStyle");
			return (class UClass*)ptr;
		};

};


}