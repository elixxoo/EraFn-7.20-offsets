#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class ELobbyBeaconJoinState : uint8_t
{
    None = 0,
    SentJoinRequest = 1,
    JoinRequestAcknowledged = 2,
    ELobbyBeaconJoinState_MAX = 3
};struct FLobbyPlayerStateActorInfo : public FFastArraySerializerItem
{
	public:
	    char UnknownData0[0x4];
	    class ALobbyBeaconPlayerState* LobbyPlayerState; // 0x10 Size: 0x8

};


}