#pragma once

#include "../SDK.hpp"

namespace SDK {


class UMcpItemAware : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/McpProfileSys.McpItemAware");
			return (class UClass*)ptr;
		};

};

class UMcpItemDefinitionBase : public UPrimaryDataAsset
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/McpProfileSys.McpItemDefinitionBase");
			return (class UClass*)ptr;
		};

};

class UMcpProfile : public UObject
{
	public:
	    EServerClientFlag AllowSubscriptionToNotificationsService; // 0x28 Size: 0x1
	    char UnknownData0[0x57]; // 0x29
	    struct FString DebugName; // 0x80 Size: 0x10
	    bool bProfileLockOperationPending; // 0x90 Size: 0x1
	    bool bProfileUnlockOperationPending; // 0x91 Size: 0x1
	    bool bEnableMocks; // 0x92 Size: 0x1
	    char UnknownData1[0x1d]; // 0x93
	    class UMcpProfileGroup* ProfileGroup; // 0xb0 Size: 0x8
	    struct FString ProfileId; // 0xb8 Size: 0x10
	    int64_t ProfileRevision; // 0xc8 Size: 0x8
	    int FullProfileQueryQueued; // 0xd0 Size: 0x4
	    bool bProfileWriteLocked; // 0xd4 Size: 0x1
	    char UnknownData2[0x3]; // 0xd5
	    struct FDateTime ProfileWriteLockExpireTime; // 0xd8 Size: 0x8
	    int CommandRevision; // 0xe0 Size: 0x4
	    char UnknownData3[0xe4]; // 0xe4
	    void UnlockProfileForWrite(struct FString Code, struct FDedicatedServerUrlContext Context); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void QueryPublicProfile(struct FBaseUrlContext Context); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void QueryProfile(struct FBaseUrlContext Context); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void LockProfileForWrite(struct FString Code, int Timeout, struct FDedicatedServerUrlContext Context); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void DeleteProfile(struct FClientUrlContext Context); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void DeleteAllProfiles(struct FClientUrlContext Context); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7e59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/McpProfileSys.McpProfile");
			return (class UClass*)ptr;
		};

};

class UMcpProfileGroup : public UObject
{
	public:
	    char UnknownData0[0xa0];
	    int DelayMcpResults; // 0xc8 Size: 0x4
	    int WeeklyIntervalStartDay; // 0xcc Size: 0x4
	    TArray<struct FProfileEntry> ProfileList; // 0xd0 Size: 0x10
	    bool bIsInitialized; // 0xe0 Size: 0x1
	    char UnknownData1[0x7]; // 0xe1
	    struct FString PlayerName; // 0xe8 Size: 0x10
	    bool bIsServer; // 0xf8 Size: 0x1
	    char UnknownData2[0x7]; // 0xf9
	    struct FString ProfileNotificationsStompTopic; // 0x100 Size: 0x10
	    char UnknownData3[0x40]; // 0x110
	    struct FString LastMcpVersion; // 0x150 Size: 0x10
	    struct FString LastContentVersion; // 0x160 Size: 0x10
	    struct FTimespan LocalTimeOffset; // 0x170 Size: 0x8
	    TArray<struct FProfileHttpRequest> PendingRequests; // 0x178 Size: 0x10
	    bool bIsProcessingRequestGenerator; // 0x188 Size: 0x1
	    char UnknownData4[0x7]; // 0x189
	    struct FString LockCode; // 0x190 Size: 0x10
	    TArray<class UMcpProfile*> LockedProfiles; // 0x1a0 Size: 0x10
	    struct FString LockedProfilesString; // 0x1b0 Size: 0x10
	    int ProfileWriteLockTimeoutSecs; // 0x1c0 Size: 0x4
	    bool bSubscribedToNotifications; // 0x1c4 Size: 0x1
	    char UnknownData5[0x3]; // 0x1c5
	    struct FString ApplyStashEndPoint; // 0x1c8 Size: 0x10
	    bool bPendingInterceptedRequest; // 0x1d8 Size: 0x1
	    bool bSendProfileCommandRevisions; // 0x1e8 Size: 0x1
	    bool bAsyncParseProfileUpdates; // 0x1e9 Size: 0x1
	    char UnknownData6[0x35];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/McpProfileSys.McpProfileGroup");
			return (class UClass*)ptr;
		};

};

class UMcpProfileManager : public UObject
{
	public:
	    char UnknownData0[0x10];
	    TArray<struct FProfileGroupEntry> ServerProfileGroups; // 0x38 Size: 0x10
	    TArray<struct FProfileGroupEntry> ClientProfileGroups; // 0x48 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/McpProfileSys.McpProfileManager");
			return (class UClass*)ptr;
		};

};


}