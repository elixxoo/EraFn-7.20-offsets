#pragma once

#include "../SDK.hpp"

namespace SDK {


class UCommonInputSubsystem : public UGameInstanceSubsystem
{
	public:
	    MulticastDelegateProperty OnInputMethodChanged; // 0x28 Size: 0x10
	    char UnknownData0[0x18]; // 0x38
	    ECommonInputType CurrentInputType; // 0x50 Size: 0x1
	    ECommonGamepadType GamepadInputType; // 0x51 Size: 0x1
	    bool bIsGamepadSimulatedClick; // 0x69 Size: 0x1
	    char UnknownData1[0x53]; // 0x53
	    bool ShouldShowInputKeys(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetGamepadInputType(ECommonGamepadType InGamepadInputType); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetCurrentInputType(ECommonInputType NewInputType); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool IsUsingPointerInput(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ InputMethodChangedDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    ECommonInputType GetDefaultInputType(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    ECommonInputType GetCurrentInputType(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    ECommonGamepadType GetCurrentGamepadType(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7f71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonInput.CommonInputSubsystem");
			return (class UClass*)ptr;
		};

};


}