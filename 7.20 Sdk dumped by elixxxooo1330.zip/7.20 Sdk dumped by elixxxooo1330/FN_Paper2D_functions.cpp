#include "../SDK.hpp"

bool UPaperFlipbook::IsValidKeyFrameIndex(int Index)
{
	struct {
            int Index;
            bool ReturnValue;
	} params{ Index };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbook:IsValidKeyFrameIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


float UPaperFlipbook::GetTotalDuration()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbook:GetTotalDuration");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UPaperSprite* UPaperFlipbook::GetSpriteAtTime(float Time, bool bClampToEnds)
{
	struct {
            float Time;
            bool bClampToEnds;
            class UPaperSprite* ReturnValue;
	} params{ Time, bClampToEnds };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbook:GetSpriteAtTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


class UPaperSprite* UPaperFlipbook::GetSpriteAtFrame(int FrameIndex)
{
	struct {
            int FrameIndex;
            class UPaperSprite* ReturnValue;
	} params{ FrameIndex };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbook:GetSpriteAtFrame");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


int UPaperFlipbook::GetNumKeyFrames()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbook:GetNumKeyFrames");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


int UPaperFlipbook::GetNumFrames()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbook:GetNumFrames");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


int UPaperFlipbook::GetKeyFrameIndexAtTime(float Time, bool bClampToEnds)
{
	struct {
            float Time;
            bool bClampToEnds;
            int ReturnValue;
	} params{ Time, bClampToEnds };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbook:GetKeyFrameIndexAtTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UPaperFlipbookComponent::Stop()
{
    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent:Stop");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UPaperFlipbookComponent::SetSpriteColor(struct FLinearColor NewColor)
{
	struct {
            struct FLinearColor NewColor;
	} params{ NewColor };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent:SetSpriteColor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UPaperFlipbookComponent::SetPlayRate(float NewRate)
{
	struct {
            float NewRate;
	} params{ NewRate };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent:SetPlayRate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UPaperFlipbookComponent::SetPlaybackPositionInFrames(int NewFramePosition, bool bFireEvents)
{
	struct {
            int NewFramePosition;
            bool bFireEvents;
	} params{ NewFramePosition, bFireEvents };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent:SetPlaybackPositionInFrames");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UPaperFlipbookComponent::SetPlaybackPosition(float NewPosition, bool bFireEvents)
{
	struct {
            float NewPosition;
            bool bFireEvents;
	} params{ NewPosition, bFireEvents };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent:SetPlaybackPosition");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UPaperFlipbookComponent::SetNewTime(float NewTime)
{
	struct {
            float NewTime;
	} params{ NewTime };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent:SetNewTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UPaperFlipbookComponent::SetLooping(bool bNewLooping)
{
	struct {
            bool bNewLooping;
	} params{ bNewLooping };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent:SetLooping");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UPaperFlipbookComponent::SetFlipbook(class UPaperFlipbook* NewFlipbook)
{
	struct {
            class UPaperFlipbook* NewFlipbook;
            bool ReturnValue;
	} params{ NewFlipbook };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent:SetFlipbook");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UPaperFlipbookComponent::ReverseFromEnd()
{
    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent:ReverseFromEnd");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UPaperFlipbookComponent::Reverse()
{
    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent:Reverse");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UPaperFlipbookComponent::PlayFromStart()
{
    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent:PlayFromStart");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UPaperFlipbookComponent::Play()
{
    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent:Play");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UPaperFlipbookComponent::OnRep_SourceFlipbook(class UPaperFlipbook* OldFlipbook)
{
	struct {
            class UPaperFlipbook* OldFlipbook;
	} params{ OldFlipbook };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent:OnRep_SourceFlipbook");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UPaperFlipbookComponent::IsReversing()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent:IsReversing");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UPaperFlipbookComponent::IsPlaying()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent:IsPlaying");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UPaperFlipbookComponent::IsLooping()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent:IsLooping");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UPaperFlipbookComponent::GetPlayRate()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent:GetPlayRate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


int UPaperFlipbookComponent::GetPlaybackPositionInFrames()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent:GetPlaybackPositionInFrames");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UPaperFlipbookComponent::GetPlaybackPosition()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent:GetPlaybackPosition");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


int UPaperFlipbookComponent::GetFlipbookLengthInFrames()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent:GetFlipbookLengthInFrames");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UPaperFlipbookComponent::GetFlipbookLength()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent:GetFlipbookLength");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UPaperFlipbookComponent::GetFlipbookFramerate()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent:GetFlipbookFramerate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UPaperFlipbook* UPaperFlipbookComponent::GetFlipbook()
{
	struct {
            class UPaperFlipbook* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent:GetFlipbook");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

bool UPaperGroupedSpriteComponent::UpdateInstanceTransform(int InstanceIndex, struct FTransform NewInstanceTransform, bool bWorldSpace, bool bMarkRenderStateDirty, bool bTeleport)
{
	struct {
            int InstanceIndex;
            struct FTransform NewInstanceTransform;
            bool bWorldSpace;
            bool bMarkRenderStateDirty;
            bool bTeleport;
            bool ReturnValue;
	} params{ InstanceIndex, NewInstanceTransform, bWorldSpace, bMarkRenderStateDirty, bTeleport };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperGroupedSpriteComponent:UpdateInstanceTransform");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UPaperGroupedSpriteComponent::UpdateInstanceColor(int InstanceIndex, struct FLinearColor NewInstanceColor, bool bMarkRenderStateDirty)
{
	struct {
            int InstanceIndex;
            struct FLinearColor NewInstanceColor;
            bool bMarkRenderStateDirty;
            bool ReturnValue;
	} params{ InstanceIndex, NewInstanceColor, bMarkRenderStateDirty };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperGroupedSpriteComponent:UpdateInstanceColor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UPaperGroupedSpriteComponent::SortInstancesAlongAxis(struct FVector WorldSpaceSortAxis)
{
	struct {
            struct FVector WorldSpaceSortAxis;
	} params{ WorldSpaceSortAxis };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperGroupedSpriteComponent:SortInstancesAlongAxis");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UPaperGroupedSpriteComponent::RemoveInstance(int InstanceIndex)
{
	struct {
            int InstanceIndex;
            bool ReturnValue;
	} params{ InstanceIndex };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperGroupedSpriteComponent:RemoveInstance");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UPaperGroupedSpriteComponent::GetInstanceTransform(int InstanceIndex, struct FTransform OutInstanceTransform, bool bWorldSpace)
{
	struct {
            int InstanceIndex;
            struct FTransform OutInstanceTransform;
            bool bWorldSpace;
            bool ReturnValue;
	} params{ InstanceIndex, OutInstanceTransform, bWorldSpace };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperGroupedSpriteComponent:GetInstanceTransform");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


int UPaperGroupedSpriteComponent::GetInstanceCount()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperGroupedSpriteComponent:GetInstanceCount");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UPaperGroupedSpriteComponent::ClearInstances()
{
    static auto fn = UObject::FindObject("/Script/Paper2D.PaperGroupedSpriteComponent:ClearInstances");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


int UPaperGroupedSpriteComponent::AddInstance(struct FTransform Transform, class UPaperSprite* Sprite, bool bWorldSpace, struct FLinearColor Color)
{
	struct {
            struct FTransform Transform;
            class UPaperSprite* Sprite;
            bool bWorldSpace;
            struct FLinearColor Color;
            int ReturnValue;
	} params{ Transform, Sprite, bWorldSpace, Color };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperGroupedSpriteComponent:AddInstance");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static struct FSlateBrush UPaperSpriteBlueprintLibrary::MakeBrushFromSprite(class UPaperSprite* Sprite, int Width, int Height)
{
	struct {
            class UPaperSprite* Sprite;
            int Width;
            int Height;
            struct FSlateBrush ReturnValue;
	} params{ Sprite, Width, Height };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperSpriteBlueprintLibrary:MakeBrushFromSprite");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UPaperSpriteComponent::SetSpriteColor(struct FLinearColor NewColor)
{
	struct {
            struct FLinearColor NewColor;
	} params{ NewColor };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperSpriteComponent:SetSpriteColor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UPaperSpriteComponent::SetSprite(class UPaperSprite* NewSprite)
{
	struct {
            class UPaperSprite* NewSprite;
            bool ReturnValue;
	} params{ NewSprite };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperSpriteComponent:SetSprite");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


class UPaperSprite* UPaperSpriteComponent::GetSprite()
{
	struct {
            class UPaperSprite* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperSpriteComponent:GetSprite");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UPaperTerrainComponent::SetTerrainColor(struct FLinearColor NewColor)
{
	struct {
            struct FLinearColor NewColor;
	} params{ NewColor };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperTerrainComponent:SetTerrainColor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UPaperTileMapComponent::SetTileMapColor(struct FLinearColor NewColor)
{
	struct {
            struct FLinearColor NewColor;
	} params{ NewColor };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperTileMapComponent:SetTileMapColor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UPaperTileMapComponent::SetTileMap(class UPaperTileMap* NewTileMap)
{
	struct {
            class UPaperTileMap* NewTileMap;
            bool ReturnValue;
	} params{ NewTileMap };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperTileMapComponent:SetTileMap");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UPaperTileMapComponent::SetTile(int X, int Y, int Layer, struct FPaperTileInfo NewValue)
{
	struct {
            int X;
            int Y;
            int Layer;
            struct FPaperTileInfo NewValue;
	} params{ X, Y, Layer, NewValue };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperTileMapComponent:SetTile");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UPaperTileMapComponent::SetLayerColor(struct FLinearColor NewColor, int Layer)
{
	struct {
            struct FLinearColor NewColor;
            int Layer;
	} params{ NewColor, Layer };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperTileMapComponent:SetLayerColor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UPaperTileMapComponent::SetLayerCollision(int Layer, bool bHasCollision, bool bOverrideThickness, float CustomThickness, bool bOverrideOffset, float CustomOffset, bool bRebuildCollision)
{
	struct {
            int Layer;
            bool bHasCollision;
            bool bOverrideThickness;
            float CustomThickness;
            bool bOverrideOffset;
            float CustomOffset;
            bool bRebuildCollision;
	} params{ Layer, bHasCollision, bOverrideThickness, CustomThickness, bOverrideOffset, CustomOffset, bRebuildCollision };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperTileMapComponent:SetLayerCollision");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UPaperTileMapComponent::SetDefaultCollisionThickness(float Thickness, bool bRebuildCollision)
{
	struct {
            float Thickness;
            bool bRebuildCollision;
	} params{ Thickness, bRebuildCollision };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperTileMapComponent:SetDefaultCollisionThickness");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UPaperTileMapComponent::ResizeMap(int NewWidthInTiles, int NewHeightInTiles)
{
	struct {
            int NewWidthInTiles;
            int NewHeightInTiles;
	} params{ NewWidthInTiles, NewHeightInTiles };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperTileMapComponent:ResizeMap");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UPaperTileMapComponent::RebuildCollision()
{
    static auto fn = UObject::FindObject("/Script/Paper2D.PaperTileMapComponent:RebuildCollision");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


bool UPaperTileMapComponent::OwnsTileMap()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperTileMapComponent:OwnsTileMap");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UPaperTileMapComponent::MakeTileMapEditable()
{
    static auto fn = UObject::FindObject("/Script/Paper2D.PaperTileMapComponent:MakeTileMapEditable");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UPaperTileMapComponent::GetTilePolygon(int TileX, int TileY, TArray<struct FVector> Points, int LayerIndex, bool bWorldSpace)
{
	struct {
            int TileX;
            int TileY;
            TArray<struct FVector> Points;
            int LayerIndex;
            bool bWorldSpace;
	} params{ TileX, TileY, Points, LayerIndex, bWorldSpace };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperTileMapComponent:GetTilePolygon");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


struct FLinearColor UPaperTileMapComponent::GetTileMapColor()
{
	struct {
            struct FLinearColor ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperTileMapComponent:GetTileMapColor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FVector UPaperTileMapComponent::GetTileCornerPosition(int TileX, int TileY, int LayerIndex, bool bWorldSpace)
{
	struct {
            int TileX;
            int TileY;
            int LayerIndex;
            bool bWorldSpace;
            struct FVector ReturnValue;
	} params{ TileX, TileY, LayerIndex, bWorldSpace };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperTileMapComponent:GetTileCornerPosition");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FVector UPaperTileMapComponent::GetTileCenterPosition(int TileX, int TileY, int LayerIndex, bool bWorldSpace)
{
	struct {
            int TileX;
            int TileY;
            int LayerIndex;
            bool bWorldSpace;
            struct FVector ReturnValue;
	} params{ TileX, TileY, LayerIndex, bWorldSpace };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperTileMapComponent:GetTileCenterPosition");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FPaperTileInfo UPaperTileMapComponent::GetTile(int X, int Y, int Layer)
{
	struct {
            int X;
            int Y;
            int Layer;
            struct FPaperTileInfo ReturnValue;
	} params{ X, Y, Layer };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperTileMapComponent:GetTile");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UPaperTileMapComponent::GetMapSize(int MapWidth, int MapHeight, int NumLayers)
{
	struct {
            int MapWidth;
            int MapHeight;
            int NumLayers;
	} params{ MapWidth, MapHeight, NumLayers };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperTileMapComponent:GetMapSize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


struct FLinearColor UPaperTileMapComponent::GetLayerColor(int Layer)
{
	struct {
            int Layer;
            struct FLinearColor ReturnValue;
	} params{ Layer };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperTileMapComponent:GetLayerColor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UPaperTileMapComponent::CreateNewTileMap(int MapWidth, int MapHeight, int TileWidth, int TileHeight, float PixelsPerUnrealUnit, bool bCreateLayer)
{
	struct {
            int MapWidth;
            int MapHeight;
            int TileWidth;
            int TileHeight;
            float PixelsPerUnrealUnit;
            bool bCreateLayer;
	} params{ MapWidth, MapHeight, TileWidth, TileHeight, PixelsPerUnrealUnit, bCreateLayer };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperTileMapComponent:CreateNewTileMap");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


class UPaperTileLayer* UPaperTileMapComponent::AddNewLayer()
{
	struct {
            class UPaperTileLayer* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Paper2D.PaperTileMapComponent:AddNewLayer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

static struct FPaperTileInfo UTileMapBlueprintLibrary::MakeTile(int TileIndex, class UPaperTileSet* TileSet, bool bFlipH, bool bFlipV, bool bFlipD)
{
	struct {
            int TileIndex;
            class UPaperTileSet* TileSet;
            bool bFlipH;
            bool bFlipV;
            bool bFlipD;
            struct FPaperTileInfo ReturnValue;
	} params{ TileIndex, TileSet, bFlipH, bFlipV, bFlipD };

    static auto fn = UObject::FindObject("/Script/Paper2D.TileMapBlueprintLibrary:MakeTile");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static FName UTileMapBlueprintLibrary::GetTileUserData(struct FPaperTileInfo Tile)
{
	struct {
            struct FPaperTileInfo Tile;
            FName ReturnValue;
	} params{ Tile };

    static auto fn = UObject::FindObject("/Script/Paper2D.TileMapBlueprintLibrary:GetTileUserData");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FTransform UTileMapBlueprintLibrary::GetTileTransform(struct FPaperTileInfo Tile)
{
	struct {
            struct FPaperTileInfo Tile;
            struct FTransform ReturnValue;
	} params{ Tile };

    static auto fn = UObject::FindObject("/Script/Paper2D.TileMapBlueprintLibrary:GetTileTransform");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UTileMapBlueprintLibrary::BreakTile(struct FPaperTileInfo Tile, int TileIndex, class UPaperTileSet* TileSet, bool bFlipH, bool bFlipV, bool bFlipD)
{
	struct {
            struct FPaperTileInfo Tile;
            int TileIndex;
            class UPaperTileSet* TileSet;
            bool bFlipH;
            bool bFlipV;
            bool bFlipD;            void ReturnValue;
	} params{ Tile, TileIndex, TileSet, bFlipH, bFlipV, bFlipD };

    static auto fn = UObject::FindObject("/Script/Paper2D.TileMapBlueprintLibrary:BreakTile");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

