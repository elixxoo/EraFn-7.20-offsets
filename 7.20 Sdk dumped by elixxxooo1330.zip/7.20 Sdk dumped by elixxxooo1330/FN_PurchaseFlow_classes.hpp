#pragma once

#include "../SDK.hpp"

namespace SDK {


class UPurchaseFlowJSBridge : public UObject
{
	public:
	    void RequestClose(struct FString CloseInfo); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void RECEIPT(struct FPurchaseFlowReceiptParam RECEIPT); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool LaunchValidatedExternalBrowserUrl(struct FString AllowedBrowserID, struct FString URL); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool LaunchExternalBrowserUrl(struct FString URL); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    struct FString GetExternalBrowserPath(struct FString BrowserId); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    struct FString GetExternalBrowserName(struct FString BrowserId); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    struct FString GetDefaultExternalBrowserID(struct FString URL); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7fa9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/PurchaseFlow.PurchaseFlowJSBridge");
			return (class UClass*)ptr;
		};

};


}