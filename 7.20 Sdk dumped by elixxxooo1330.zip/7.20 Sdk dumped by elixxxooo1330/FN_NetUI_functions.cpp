#include "../SDK.hpp"

void UNetDebugWidget::StopTimer()
{
    static auto fn = UObject::FindObject("/Script/NetUI.NetDebugWidget:StopTimer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UNetDebugWidget::StartTimer()
{
    static auto fn = UObject::FindObject("/Script/NetUI.NetDebugWidget:StartTimer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

