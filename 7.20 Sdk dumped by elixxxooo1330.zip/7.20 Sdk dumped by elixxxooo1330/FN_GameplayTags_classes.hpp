#pragma once

#include "../SDK.hpp"

namespace SDK {


class UBlueprintGameplayTagLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static bool RemoveGameplayTag(struct FGameplayTagContainer TagContainer, struct FGameplayTag Tag); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static bool NotEqual_TagTag(struct FGameplayTag A, struct FString B); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static bool NotEqual_TagContainerTagContainer(struct FGameplayTagContainer A, struct FString B); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static bool NotEqual_GameplayTagContainer(struct FGameplayTagContainer A, struct FGameplayTagContainer B); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static bool NotEqual_GameplayTag(struct FGameplayTag A, struct FGameplayTag B); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static bool MatchesTag(struct FGameplayTag TagOne, struct FGameplayTag TagTwo, bool bExactMatch); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static bool MatchesAnyTags(struct FGameplayTag TagOne, struct FGameplayTagContainer OtherContainer, bool bExactMatch); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static struct FGameplayTagContainer MakeLiteralGameplayTagContainer(struct FGameplayTagContainer Value); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static struct FGameplayTag MakeLiteralGameplayTag(struct FGameplayTag Value); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static struct FGameplayTagQuery MakeGameplayTagQuery(struct FGameplayTagQuery TagQuery); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static struct FGameplayTagContainer MakeGameplayTagContainerFromTag(struct FGameplayTag SingleTag); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static struct FGameplayTagContainer MakeGameplayTagContainerFromArray(TArray<struct FGameplayTag> GameplayTags); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    static bool IsGameplayTagValid(struct FGameplayTag GameplayTag); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    static bool HasTag(struct FGameplayTagContainer TagContainer, struct FGameplayTag Tag, bool bExactMatch); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    static bool HasAnyTags(struct FGameplayTagContainer TagContainer, struct FGameplayTagContainer OtherContainer, bool bExactMatch); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    static bool HasAllTags(struct FGameplayTagContainer TagContainer, struct FGameplayTagContainer OtherContainer, bool bExactMatch); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    static bool HasAllMatchingGameplayTags(__int64/*InterfaceProperty*/ TagContainerInterface, struct FGameplayTagContainer OtherContainer); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    static FName GetTagName(struct FGameplayTag GameplayTag); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    static int GetNumGameplayTagsInContainer(struct FGameplayTagContainer TagContainer); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    static struct FString GetDebugStringFromGameplayTagContainer(struct FGameplayTagContainer TagContainer); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    static struct FString GetDebugStringFromGameplayTag(struct FGameplayTag GameplayTag); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    static void GetAllActorsOfClassMatchingTagQuery(class UObject* WorldContextObject, class AActor* ActorClass, struct FGameplayTagQuery GameplayTagQuery, TArray<class AActor*> OutActors); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_GameplayTagContainer(struct FGameplayTagContainer A, struct FGameplayTagContainer B); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_GameplayTag(struct FGameplayTag A, struct FGameplayTag B); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    static bool DoesTagAssetInterfaceHaveTag(__int64/*InterfaceProperty*/ TagContainerInterface, struct FGameplayTag Tag); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    static bool DoesContainerMatchTagQuery(struct FGameplayTagContainer TagContainer, struct FGameplayTagQuery TagQuery); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    static void BreakGameplayTagContainer(struct FGameplayTagContainer GameplayTagContainer, TArray<struct FGameplayTag> GameplayTags); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    static void AppendGameplayTagContainers(struct FGameplayTagContainer InOutTagContainer, struct FGameplayTagContainer InTagContainer); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    static void AddGameplayTag(struct FGameplayTagContainer TagContainer, struct FGameplayTag Tag); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary");
			return (class UClass*)ptr;
		};

};

class UGameplayTagAssetInterface : public UInterface
{
	public:
	    bool HasMatchingGameplayTag(struct FGameplayTag TagToCheck); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    bool HasAnyMatchingGameplayTags(struct FGameplayTagContainer TagContainer); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool HasAllMatchingGameplayTags(struct FGameplayTagContainer TagContainer); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void GetOwnedGameplayTags(struct FGameplayTagContainer TagContainer); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayTags.GameplayTagAssetInterface");
			return (class UClass*)ptr;
		};

};

class UEditableGameplayTagQuery : public UObject
{
	public:
	    struct FString UserDescription; // 0x28 Size: 0x10
	    char UnknownData0[0x10]; // 0x38
	    class UEditableGameplayTagQueryExpression* RootExpression; // 0x48 Size: 0x8
	    struct FGameplayTagQuery TagQueryExportText_Helper; // 0x50 Size: 0x48

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayTags.EditableGameplayTagQuery");
			return (class UClass*)ptr;
		};

};

class UEditableGameplayTagQueryExpression : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayTags.EditableGameplayTagQueryExpression");
			return (class UClass*)ptr;
		};

};

class UEditableGameplayTagQueryExpression_AnyTagsMatch : public UEditableGameplayTagQueryExpression
{
	public:
	    struct FGameplayTagContainer Tags; // 0x28 Size: 0x20

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayTags.EditableGameplayTagQueryExpression_AnyTagsMatch");
			return (class UClass*)ptr;
		};

};

class UEditableGameplayTagQueryExpression_AllTagsMatch : public UEditableGameplayTagQueryExpression
{
	public:
	    struct FGameplayTagContainer Tags; // 0x28 Size: 0x20

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayTags.EditableGameplayTagQueryExpression_AllTagsMatch");
			return (class UClass*)ptr;
		};

};

class UEditableGameplayTagQueryExpression_NoTagsMatch : public UEditableGameplayTagQueryExpression
{
	public:
	    struct FGameplayTagContainer Tags; // 0x28 Size: 0x20

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayTags.EditableGameplayTagQueryExpression_NoTagsMatch");
			return (class UClass*)ptr;
		};

};

class UEditableGameplayTagQueryExpression_AnyExprMatch : public UEditableGameplayTagQueryExpression
{
	public:
	    TArray<class UEditableGameplayTagQueryExpression*> Expressions; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayTags.EditableGameplayTagQueryExpression_AnyExprMatch");
			return (class UClass*)ptr;
		};

};

class UEditableGameplayTagQueryExpression_AllExprMatch : public UEditableGameplayTagQueryExpression
{
	public:
	    TArray<class UEditableGameplayTagQueryExpression*> Expressions; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayTags.EditableGameplayTagQueryExpression_AllExprMatch");
			return (class UClass*)ptr;
		};

};

class UEditableGameplayTagQueryExpression_NoExprMatch : public UEditableGameplayTagQueryExpression
{
	public:
	    TArray<class UEditableGameplayTagQueryExpression*> Expressions; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayTags.EditableGameplayTagQueryExpression_NoExprMatch");
			return (class UClass*)ptr;
		};

};

class UGameplayTagsManager : public UObject
{
	public:
	    char UnknownData0[0x80];
	    TArray<struct FGameplayTagSource> TagSources; // 0xa8 Size: 0x10
	    char UnknownData1[0x68]; // 0xb8
	    TArray<class UDataTable*> RestrictedGameplayTagTables; // 0x120 Size: 0x10
	    TArray<class UDataTable*> GameplayTagTables; // 0x130 Size: 0x10
	    char UnknownData2[0x50];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayTags.GameplayTagsManager");
			return (class UClass*)ptr;
		};

};

class UGameplayTagsList : public UObject
{
	public:
	    struct FString ConfigFileName; // 0x28 Size: 0x10
	    TArray<struct FGameplayTagTableRow> GameplayTagList; // 0x38 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayTags.GameplayTagsList");
			return (class UClass*)ptr;
		};

};

class URestrictedGameplayTagsList : public UObject
{
	public:
	    struct FString ConfigFileName; // 0x28 Size: 0x10
	    TArray<struct FRestrictedGameplayTagTableRow> RestrictedGameplayTagList; // 0x38 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayTags.RestrictedGameplayTagsList");
			return (class UClass*)ptr;
		};

};

class UGameplayTagsSettings : public UGameplayTagsList
{
	public:
	    bool ImportTagsFromConfig; // 0x48 Size: 0x1
	    bool WarnOnInvalidTags; // 0x49 Size: 0x1
	    char UnknownData0[0x6]; // 0x4a
	    TArray<struct FGameplayTagCategoryRemap> CategoryRemapping; // 0x50 Size: 0x10
	    bool FastReplication; // 0x60 Size: 0x1
	    char UnknownData1[0x7]; // 0x61
	    TArray<struct FSoftObjectPath> GameplayTagTableList; // 0x68 Size: 0x10
	    TArray<struct FGameplayTagRedirect> GameplayTagRedirects; // 0x78 Size: 0x10
	    TArray<FName> CommonlyReplicatedTags; // 0x88 Size: 0x10
	    int NumBitsForContainerSize; // 0x98 Size: 0x4
	    int NetIndexFirstBitSegment; // 0x9c Size: 0x4
	    TArray<struct FRestrictedConfigInfo> RestrictedConfigFiles; // 0xa0 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayTags.GameplayTagsSettings");
			return (class UClass*)ptr;
		};

};

class UGameplayTagsDeveloperSettings : public UObject
{
	public:
	    struct FString DeveloperConfigName; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayTags.GameplayTagsDeveloperSettings");
			return (class UClass*)ptr;
		};

};


}