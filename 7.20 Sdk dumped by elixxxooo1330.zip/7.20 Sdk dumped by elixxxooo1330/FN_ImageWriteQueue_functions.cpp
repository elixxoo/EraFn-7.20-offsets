#include "../SDK.hpp"

static void UImageWriteBlueprintLibrary::ExportToDisk(class UTexture* Texture, struct FString Filename, struct FImageWriteOptions Options)
{
	struct {
            class UTexture* Texture;
            struct FString Filename;
            struct FImageWriteOptions Options;            void ReturnValue;
	} params{ Texture, Filename, Options };

    static auto fn = UObject::FindObject("/Script/ImageWriteQueue.ImageWriteBlueprintLibrary:ExportToDisk");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

