#include "../SDK.hpp"

static bool UBlueprintGameplayTagLibrary::RemoveGameplayTag(struct FGameplayTagContainer TagContainer, struct FGameplayTag Tag)
{
	struct {
            struct FGameplayTagContainer TagContainer;
            struct FGameplayTag Tag;
            bool ReturnValue;
	} params{ TagContainer, Tag };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:RemoveGameplayTag");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UBlueprintGameplayTagLibrary::NotEqual_TagTag(struct FGameplayTag A, struct FString B)
{
	struct {
            struct FGameplayTag A;
            struct FString B;
            bool ReturnValue;
	} params{ A, B };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:NotEqual_TagTag");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UBlueprintGameplayTagLibrary::NotEqual_TagContainerTagContainer(struct FGameplayTagContainer A, struct FString B)
{
	struct {
            struct FGameplayTagContainer A;
            struct FString B;
            bool ReturnValue;
	} params{ A, B };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:NotEqual_TagContainerTagContainer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UBlueprintGameplayTagLibrary::NotEqual_GameplayTagContainer(struct FGameplayTagContainer A, struct FGameplayTagContainer B)
{
	struct {
            struct FGameplayTagContainer A;
            struct FGameplayTagContainer B;
            bool ReturnValue;
	} params{ A, B };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:NotEqual_GameplayTagContainer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UBlueprintGameplayTagLibrary::NotEqual_GameplayTag(struct FGameplayTag A, struct FGameplayTag B)
{
	struct {
            struct FGameplayTag A;
            struct FGameplayTag B;
            bool ReturnValue;
	} params{ A, B };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:NotEqual_GameplayTag");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UBlueprintGameplayTagLibrary::MatchesTag(struct FGameplayTag TagOne, struct FGameplayTag TagTwo, bool bExactMatch)
{
	struct {
            struct FGameplayTag TagOne;
            struct FGameplayTag TagTwo;
            bool bExactMatch;
            bool ReturnValue;
	} params{ TagOne, TagTwo, bExactMatch };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:MatchesTag");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UBlueprintGameplayTagLibrary::MatchesAnyTags(struct FGameplayTag TagOne, struct FGameplayTagContainer OtherContainer, bool bExactMatch)
{
	struct {
            struct FGameplayTag TagOne;
            struct FGameplayTagContainer OtherContainer;
            bool bExactMatch;
            bool ReturnValue;
	} params{ TagOne, OtherContainer, bExactMatch };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:MatchesAnyTags");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayTagContainer UBlueprintGameplayTagLibrary::MakeLiteralGameplayTagContainer(struct FGameplayTagContainer Value)
{
	struct {
            struct FGameplayTagContainer Value;
            struct FGameplayTagContainer ReturnValue;
	} params{ Value };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:MakeLiteralGameplayTagContainer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayTag UBlueprintGameplayTagLibrary::MakeLiteralGameplayTag(struct FGameplayTag Value)
{
	struct {
            struct FGameplayTag Value;
            struct FGameplayTag ReturnValue;
	} params{ Value };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:MakeLiteralGameplayTag");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayTagQuery UBlueprintGameplayTagLibrary::MakeGameplayTagQuery(struct FGameplayTagQuery TagQuery)
{
	struct {
            struct FGameplayTagQuery TagQuery;
            struct FGameplayTagQuery ReturnValue;
	} params{ TagQuery };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:MakeGameplayTagQuery");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayTagContainer UBlueprintGameplayTagLibrary::MakeGameplayTagContainerFromTag(struct FGameplayTag SingleTag)
{
	struct {
            struct FGameplayTag SingleTag;
            struct FGameplayTagContainer ReturnValue;
	} params{ SingleTag };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:MakeGameplayTagContainerFromTag");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayTagContainer UBlueprintGameplayTagLibrary::MakeGameplayTagContainerFromArray(TArray<struct FGameplayTag> GameplayTags)
{
	struct {
            TArray<struct FGameplayTag> GameplayTags;
            struct FGameplayTagContainer ReturnValue;
	} params{ GameplayTags };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:MakeGameplayTagContainerFromArray");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UBlueprintGameplayTagLibrary::IsGameplayTagValid(struct FGameplayTag GameplayTag)
{
	struct {
            struct FGameplayTag GameplayTag;
            bool ReturnValue;
	} params{ GameplayTag };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:IsGameplayTagValid");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UBlueprintGameplayTagLibrary::HasTag(struct FGameplayTagContainer TagContainer, struct FGameplayTag Tag, bool bExactMatch)
{
	struct {
            struct FGameplayTagContainer TagContainer;
            struct FGameplayTag Tag;
            bool bExactMatch;
            bool ReturnValue;
	} params{ TagContainer, Tag, bExactMatch };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:HasTag");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UBlueprintGameplayTagLibrary::HasAnyTags(struct FGameplayTagContainer TagContainer, struct FGameplayTagContainer OtherContainer, bool bExactMatch)
{
	struct {
            struct FGameplayTagContainer TagContainer;
            struct FGameplayTagContainer OtherContainer;
            bool bExactMatch;
            bool ReturnValue;
	} params{ TagContainer, OtherContainer, bExactMatch };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:HasAnyTags");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UBlueprintGameplayTagLibrary::HasAllTags(struct FGameplayTagContainer TagContainer, struct FGameplayTagContainer OtherContainer, bool bExactMatch)
{
	struct {
            struct FGameplayTagContainer TagContainer;
            struct FGameplayTagContainer OtherContainer;
            bool bExactMatch;
            bool ReturnValue;
	} params{ TagContainer, OtherContainer, bExactMatch };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:HasAllTags");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UBlueprintGameplayTagLibrary::HasAllMatchingGameplayTags(__int64/*InterfaceProperty*/ TagContainerInterface, struct FGameplayTagContainer OtherContainer)
{
	struct {
            __int64/*InterfaceProperty*/ TagContainerInterface;
            struct FGameplayTagContainer OtherContainer;
            bool ReturnValue;
	} params{ TagContainerInterface, OtherContainer };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:HasAllMatchingGameplayTags");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static FName UBlueprintGameplayTagLibrary::GetTagName(struct FGameplayTag GameplayTag)
{
	struct {
            struct FGameplayTag GameplayTag;
            FName ReturnValue;
	} params{ GameplayTag };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:GetTagName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static int UBlueprintGameplayTagLibrary::GetNumGameplayTagsInContainer(struct FGameplayTagContainer TagContainer)
{
	struct {
            struct FGameplayTagContainer TagContainer;
            int ReturnValue;
	} params{ TagContainer };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:GetNumGameplayTagsInContainer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FString UBlueprintGameplayTagLibrary::GetDebugStringFromGameplayTagContainer(struct FGameplayTagContainer TagContainer)
{
	struct {
            struct FGameplayTagContainer TagContainer;
            struct FString ReturnValue;
	} params{ TagContainer };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:GetDebugStringFromGameplayTagContainer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FString UBlueprintGameplayTagLibrary::GetDebugStringFromGameplayTag(struct FGameplayTag GameplayTag)
{
	struct {
            struct FGameplayTag GameplayTag;
            struct FString ReturnValue;
	} params{ GameplayTag };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:GetDebugStringFromGameplayTag");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UBlueprintGameplayTagLibrary::GetAllActorsOfClassMatchingTagQuery(class UObject* WorldContextObject, class AActor* ActorClass, struct FGameplayTagQuery GameplayTagQuery, TArray<class AActor*> OutActors)
{
	struct {
            class UObject* WorldContextObject;
            class AActor* ActorClass;
            struct FGameplayTagQuery GameplayTagQuery;
            TArray<class AActor*> OutActors;            void ReturnValue;
	} params{ WorldContextObject, ActorClass, GameplayTagQuery, OutActors };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:GetAllActorsOfClassMatchingTagQuery");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UBlueprintGameplayTagLibrary::EqualEqual_GameplayTagContainer(struct FGameplayTagContainer A, struct FGameplayTagContainer B)
{
	struct {
            struct FGameplayTagContainer A;
            struct FGameplayTagContainer B;
            bool ReturnValue;
	} params{ A, B };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:EqualEqual_GameplayTagContainer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UBlueprintGameplayTagLibrary::EqualEqual_GameplayTag(struct FGameplayTag A, struct FGameplayTag B)
{
	struct {
            struct FGameplayTag A;
            struct FGameplayTag B;
            bool ReturnValue;
	} params{ A, B };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:EqualEqual_GameplayTag");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UBlueprintGameplayTagLibrary::DoesTagAssetInterfaceHaveTag(__int64/*InterfaceProperty*/ TagContainerInterface, struct FGameplayTag Tag)
{
	struct {
            __int64/*InterfaceProperty*/ TagContainerInterface;
            struct FGameplayTag Tag;
            bool ReturnValue;
	} params{ TagContainerInterface, Tag };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:DoesTagAssetInterfaceHaveTag");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UBlueprintGameplayTagLibrary::DoesContainerMatchTagQuery(struct FGameplayTagContainer TagContainer, struct FGameplayTagQuery TagQuery)
{
	struct {
            struct FGameplayTagContainer TagContainer;
            struct FGameplayTagQuery TagQuery;
            bool ReturnValue;
	} params{ TagContainer, TagQuery };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:DoesContainerMatchTagQuery");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UBlueprintGameplayTagLibrary::BreakGameplayTagContainer(struct FGameplayTagContainer GameplayTagContainer, TArray<struct FGameplayTag> GameplayTags)
{
	struct {
            struct FGameplayTagContainer GameplayTagContainer;
            TArray<struct FGameplayTag> GameplayTags;            void ReturnValue;
	} params{ GameplayTagContainer, GameplayTags };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:BreakGameplayTagContainer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UBlueprintGameplayTagLibrary::AppendGameplayTagContainers(struct FGameplayTagContainer InOutTagContainer, struct FGameplayTagContainer InTagContainer)
{
	struct {
            struct FGameplayTagContainer InOutTagContainer;
            struct FGameplayTagContainer InTagContainer;            void ReturnValue;
	} params{ InOutTagContainer, InTagContainer };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:AppendGameplayTagContainers");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UBlueprintGameplayTagLibrary::AddGameplayTag(struct FGameplayTagContainer TagContainer, struct FGameplayTag Tag)
{
	struct {
            struct FGameplayTagContainer TagContainer;
            struct FGameplayTag Tag;            void ReturnValue;
	} params{ TagContainer, Tag };

    static auto fn = UObject::FindObject("/Script/GameplayTags.BlueprintGameplayTagLibrary:AddGameplayTag");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

bool UGameplayTagAssetInterface::HasMatchingGameplayTag(struct FGameplayTag TagToCheck)
{
	struct {
            struct FGameplayTag TagToCheck;
            bool ReturnValue;
	} params{ TagToCheck };

    static auto fn = UObject::FindObject("/Script/GameplayTags.GameplayTagAssetInterface:HasMatchingGameplayTag");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UGameplayTagAssetInterface::HasAnyMatchingGameplayTags(struct FGameplayTagContainer TagContainer)
{
	struct {
            struct FGameplayTagContainer TagContainer;
            bool ReturnValue;
	} params{ TagContainer };

    static auto fn = UObject::FindObject("/Script/GameplayTags.GameplayTagAssetInterface:HasAnyMatchingGameplayTags");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UGameplayTagAssetInterface::HasAllMatchingGameplayTags(struct FGameplayTagContainer TagContainer)
{
	struct {
            struct FGameplayTagContainer TagContainer;
            bool ReturnValue;
	} params{ TagContainer };

    static auto fn = UObject::FindObject("/Script/GameplayTags.GameplayTagAssetInterface:HasAllMatchingGameplayTags");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UGameplayTagAssetInterface::GetOwnedGameplayTags(struct FGameplayTagContainer TagContainer)
{
	struct {
            struct FGameplayTagContainer TagContainer;
	} params{ TagContainer };

    static auto fn = UObject::FindObject("/Script/GameplayTags.GameplayTagAssetInterface:GetOwnedGameplayTags");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

