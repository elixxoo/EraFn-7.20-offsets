#include "../SDK.hpp"

static void UMIDIDeviceManager::FindMIDIDevices(TArray<struct FFoundMIDIDevice> OutMIDIDevices)
{
	struct {
            TArray<struct FFoundMIDIDevice> OutMIDIDevices;            void ReturnValue;
	} params{ OutMIDIDevices };

    static auto fn = UObject::FindObject("/Script/MIDIDevice.MIDIDeviceManager:FindMIDIDevices");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UMIDIDeviceController* UMIDIDeviceManager::CreateMIDIDeviceController(int DeviceID, int MIDIBufferSize)
{
	struct {
            int DeviceID;
            int MIDIBufferSize;
            class UMIDIDeviceController* ReturnValue;
	} params{ DeviceID, MIDIBufferSize };

    static auto fn = UObject::FindObject("/Script/MIDIDevice.MIDIDeviceManager:CreateMIDIDeviceController");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

