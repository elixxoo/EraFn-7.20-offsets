#pragma once

#include "../SDK.hpp"

namespace SDK {


class UTimeSynchronizationSource : public UObject
{
	public:
	    bool bUseForSynchronization; // 0x28 Size: 0x1
	    char UnknownData0[0x3]; // 0x29
	    int FrameOffset; // 0x2c Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/TimeManagement.TimeSynchronizationSource");
			return (class UClass*)ptr;
		};

};

class UFixedFrameRateCustomTimeStep : public UEngineCustomTimeStep
{
	public:
	    struct FFrameRate FixedFrameRate; // 0x28 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/TimeManagement.FixedFrameRateCustomTimeStep");
			return (class UClass*)ptr;
		};

};

class UTimeManagementBlueprintLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static struct FFrameTime TransformTime(struct FFrameTime SourceTime, struct FFrameRate SourceRate, struct FFrameRate DestinationRate); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static struct FFrameNumber Subtract_FrameNumberInteger(struct FFrameNumber A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static struct FFrameNumber Subtract_FrameNumberFrameNumber(struct FFrameNumber A, struct FFrameNumber B); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static struct FFrameTime SnapFrameTimeToRate(struct FFrameTime SourceTime, struct FFrameRate SourceRate, struct FFrameRate SnapToRate); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static struct FFrameTime Multiply_SecondsFrameRate(float TimeInSeconds, struct FFrameRate FrameRate); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static struct FFrameNumber Multiply_FrameNumberInteger(struct FFrameNumber A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static bool IsValid_MultipleOf(struct FFrameRate InFrameRate, struct FFrameRate OtherFramerate); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static bool IsValid_Framerate(struct FFrameRate InFrameRate); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static struct FTimecode GetTimecode(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static struct FFrameNumber Divide_FrameNumberInteger(struct FFrameNumber A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static struct FString Conv_TimecodeToString(struct FTimecode InTimecode, bool bForceSignDisplay); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static float Conv_QualifiedFrameTimeToSeconds(struct FQualifiedFrameTime InFrameTime); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    static float Conv_FrameRateToSeconds(struct FFrameRate InFrameRate); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    static int Conv_FrameNumberToInteger(struct FFrameNumber InFrameNumber); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    static struct FFrameNumber Add_FrameNumberInteger(struct FFrameNumber A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    static struct FFrameNumber Add_FrameNumberFrameNumber(struct FFrameNumber A, struct FFrameNumber B); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/TimeManagement.TimeManagementBlueprintLibrary");
			return (class UClass*)ptr;
		};

};


}