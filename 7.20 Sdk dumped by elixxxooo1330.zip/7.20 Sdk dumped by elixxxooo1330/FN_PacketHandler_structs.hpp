#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FNetAnalyticsDataConfig
{
	public:
	    FName DataName; // 0x0 Size: 0x8
	    bool bEnabled; // 0x8 Size: 0x1
	    char UnknownData0[0x3];

};


}