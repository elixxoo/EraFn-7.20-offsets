#pragma once

#include "../SDK.hpp"

namespace SDK {


class UFortMediaSubtitlesPlayer : public UObject
{
	public:
	    char UnknownData0[0x18];
	    class UOverlays* SourceSubtitles; // 0x40 Size: 0x8
	    char UnknownData1[0x48]; // 0x48
	    void Stop(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetSubtitles(class UOverlays* Subtitles); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void Play(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void BindToMediaPlayer(class UMediaPlayer* InMediaPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7f89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SubtitlesWidgets.FortMediaSubtitlesPlayer");
			return (class UClass*)ptr;
		};

};

class USubtitleDisplay : public UWidget
{
	public:
	    struct FSlateFontInfo FontInfo; // 0x100 Size: 0x50
	    struct FLinearColor ColorAndOpacity; // 0x150 Size: 0x10
	    float WrapTextAt; // 0x160 Size: 0x4
	    char UnknownData0[0x164]; // 0x164
	    bool HasSubtitles(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7c71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SubtitlesWidgets.SubtitleDisplay");
			return (class UClass*)ptr;
		};

};


}