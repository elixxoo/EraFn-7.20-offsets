#pragma once

#include "../SDK.hpp"

namespace SDK {


class UAnalogSlider : public USlider
{
	public:
	    MulticastDelegateProperty OnAnalogCapture; // 0x4e8 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.AnalogSlider");
			return (class UClass*)ptr;
		};

};

class UCommonActionHandlerInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonActionHandlerInterface");
			return (class UClass*)ptr;
		};

};

class UCommonActionWidget : public UWidget
{
	public:
	    MulticastDelegateProperty OnInputMethodChanged; // 0x100 Size: 0x10
	    struct FDataTableRowHandle InputActionDataRow; // 0x110 Size: 0x10
	    struct FSlateBrush ProgressMaterialBrush; // 0x120 Size: 0x88
	    FName ProgressMaterialParam; // 0x1a8 Size: 0x8
	    struct FSlateBrush IconRimBrush; // 0x1b0 Size: 0x88
	    class UMaterialInstanceDynamic* ProgressDynamicMaterial; // 0x238 Size: 0x8
	    char UnknownData0[0x240]; // 0x240
	    void SetInputAction(struct FDataTableRowHandle InputActionRow); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetIconRimBrush(struct FSlateBrush InIconRimBrush); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnInputMethodChanged__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool IsHeldAction(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    struct FSlateBrush GetIcon(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    struct FText GetDisplayText(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7cd1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonActionWidget");
			return (class UClass*)ptr;
		};

};

class UCommonUserWidget : public UUserWidget
{
	public:
	    bool bConsumePointerInput; // 0x228 Size: 0x1
	    char UnknownData0[0x229]; // 0x229
	    void SetConsumePointerInput(bool bInConsumePointerInput); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnTouchLeave(struct FPointerEvent TouchEvent); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7db1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonUserWidget");
			return (class UClass*)ptr;
		};

};

class UCommonActivatablePanel : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x8];
	    MulticastDelegateProperty OnWidgetActivated; // 0x238 Size: 0x10
	    MulticastDelegateProperty OnWidgetDeactivated; // 0x248 Size: 0x10
	    bool bConsumeAllActions; // 0x298 Size: 0x1
	    bool bExposeActionsExternally; // 0x299 Size: 0x1
	    bool bShouldBypassStack; // 0x29a Size: 0x1
	    char UnknownData1[0x25b]; // 0x25b
	    void SetInputActionHandlerWithProgressPopupMenu(struct FDataTableRowHandle InputActionRow, __int64/*DelegateProperty*/ CommitedEvent, __int64/*DelegateProperty*/ ProgressEvent, class UCommonPopupMenu* PopupMenu); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetInputActionHandlerWithProgress(struct FDataTableRowHandle InputActionRow, __int64/*DelegateProperty*/ CommitedEvent, __int64/*DelegateProperty*/ ProgressEvent); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetInputActionHandlerWithPopupMenu(struct FDataTableRowHandle InputActionRow, __int64/*DelegateProperty*/ CommitedEvent, class UCommonPopupMenu* PopupMenu); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetInputActionHandler(struct FDataTableRowHandle InputActionRow, __int64/*DelegateProperty*/ CommitedEvent); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetActionHandlerStateWithDisabledCommitEvent(class UDataTable* DataTable, FName RowName, EInputActionState State, __int64/*DelegateProperty*/ DisabledCommitEvent); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetActionHandlerStateFromHandleWithDisabledCommitEvent(struct FDataTableRowHandle InputActionRow, EInputActionState State, __int64/*DelegateProperty*/ DisabledCommitEvent); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetActionHandlerStateFromHandle(struct FDataTableRowHandle InputActionRow, EInputActionState State); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetActionHandlerState(class UDataTable* DataTable, FName RowName, EInputActionState State); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void RemoveInputActionHandler(struct FDataTableRowHandle InputActionRow); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void RemoveAllInputActionHandlers(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void PopPanel(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void OnRemovedFromActivationStack(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void OnInputModeChanged(bool bUsingGamepad); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void OnDeactivated(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void OnBeginOutro(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void OnBeginIntro(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void OnAddedToActivationStack(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void OnActivated(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    bool IsIntroed(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    bool IsInActivationStack(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    bool IsActivated(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    bool HasInputActionHandler(struct FDataTableRowHandle InputActionRow); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    bool GetInputActions(TArray<struct FCommonInputActionHandlerData> InputActionDataRows); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void EndOutro(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void EndIntro(); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void BeginOutro(); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void BeginIntro(); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void AddInputActionNoHandler(class UDataTable* DataTable, FName RowName); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    void AddInputActionHandlerWithProgressPopup(class UDataTable* DataTable, FName RowName, __int64/*DelegateProperty*/ CommitedEvent, __int64/*DelegateProperty*/ ProgressEvent, class UCommonPopupMenu* PopupMenu); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    void AddInputActionHandlerWithProgress(class UDataTable* DataTable, FName RowName, __int64/*DelegateProperty*/ CommitedEvent, __int64/*DelegateProperty*/ ProgressEvent); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    void AddInputActionHandlerWithPopup(class UDataTable* DataTable, FName RowName, __int64/*DelegateProperty*/ CommitedEvent, class UCommonPopupMenu* PopupMenu); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    void AddInputActionHandler(class UDataTable* DataTable, FName RowName, __int64/*DelegateProperty*/ CommitedEvent); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x-7cc9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel");
			return (class UClass*)ptr;
		};

};

class UCommonBorderStyle : public UObject
{
	public:
	    struct FSlateBrush Background; // 0x28 Size: 0x88
	    char UnknownData0[0xb0]; // 0xb0
	    void GetBackgroundBrush(struct FSlateBrush Brush); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f31];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonBorderStyle");
			return (class UClass*)ptr;
		};

};

class UCommonBorder : public UBorder
{
	public:
	    class UCommonBorderStyle* Style; // 0x260 Size: 0x8
	    bool bReducePaddingBySafezone; // 0x268 Size: 0x1
	    char UnknownData0[0x3]; // 0x269
	    struct FMargin MinimumPadding; // 0x26c Size: 0x10
	    char UnknownData1[0x27c]; // 0x27c
	    void SetStyle(class UCommonBorderStyle* InStyle); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonBorder");
			return (class UClass*)ptr;
		};

};

class UCommonButtonStyle : public UObject
{
	public:
	    bool bSingleMaterial; // 0x28 Size: 0x1
	    char UnknownData0[0x7]; // 0x29
	    struct FSlateBrush SingleMaterialBrush; // 0x30 Size: 0x88
	    struct FSlateBrush NormalBase; // 0xb8 Size: 0x88
	    struct FSlateBrush NormalHovered; // 0x140 Size: 0x88
	    struct FSlateBrush NormalPressed; // 0x1c8 Size: 0x88
	    struct FSlateBrush SelectedBase; // 0x250 Size: 0x88
	    struct FSlateBrush SelectedHovered; // 0x2d8 Size: 0x88
	    struct FSlateBrush SelectedPressed; // 0x360 Size: 0x88
	    struct FSlateBrush Disabled; // 0x3e8 Size: 0x88
	    struct FMargin ButtonPadding; // 0x470 Size: 0x10
	    struct FMargin CustomPadding; // 0x480 Size: 0x10
	    int MinWidth; // 0x490 Size: 0x4
	    int MinHeight; // 0x494 Size: 0x4
	    class UCommonTextStyle* NormalTextStyle; // 0x498 Size: 0x8
	    class UCommonTextStyle* NormalHoveredTextStyle; // 0x4a0 Size: 0x8
	    class UCommonTextStyle* SelectedTextStyle; // 0x4a8 Size: 0x8
	    class UCommonTextStyle* SelectedHoveredTextStyle; // 0x4b0 Size: 0x8
	    class UCommonTextStyle* DisabledTextStyle; // 0x4b8 Size: 0x8
	    struct FSlateSound PressedSlateSound; // 0x4c0 Size: 0x18
	    struct FCommonButtonStyleOptionalSlateSound SelectedPressedSlateSound; // 0x4d8 Size: 0x20
	    struct FCommonButtonStyleOptionalSlateSound DisabledPressedSlateSound; // 0x4f8 Size: 0x20
	    struct FSlateSound HoveredSlateSound; // 0x518 Size: 0x18
	    struct FCommonButtonStyleOptionalSlateSound SelectedHoveredSlateSound; // 0x530 Size: 0x20
	    struct FCommonButtonStyleOptionalSlateSound DisabledHoveredSlateSound; // 0x550 Size: 0x20
	    char UnknownData1[0x570]; // 0x570
	    class UCommonTextStyle* GetSelectedTextStyle(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void GetSelectedPressedBrush(struct FSlateBrush Brush); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    class UCommonTextStyle* GetSelectedHoveredTextStyle(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void GetSelectedHoveredBrush(struct FSlateBrush Brush); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void GetSelectedBaseBrush(struct FSlateBrush Brush); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    class UCommonTextStyle* GetNormalTextStyle(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void GetNormalPressedBrush(struct FSlateBrush Brush); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    class UCommonTextStyle* GetNormalHoveredTextStyle(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void GetNormalHoveredBrush(struct FSlateBrush Brush); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void GetNormalBaseBrush(struct FSlateBrush Brush); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void GetMaterialBrush(struct FSlateBrush Brush); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    class UCommonTextStyle* GetDisabledTextStyle(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void GetDisabledBrush(struct FSlateBrush Brush); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void GetCustomPadding(struct FMargin OutCustomPadding); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void GetButtonPadding(struct FMargin OutButtonPadding); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x-7a71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonButtonStyle");
			return (class UClass*)ptr;
		};

};

class UCommonButtonInternal : public UButton
{
	public:
	    char UnknownData0[0x10];
	    MulticastDelegateProperty OnDoubleClicked; // 0x430 Size: 0x10
	    char UnknownData1[0x10]; // 0x440
	    int MinWidth; // 0x450 Size: 0x4
	    int MinHeight; // 0x454 Size: 0x4
	    bool bButtonEnabled; // 0x458 Size: 0x1
	    bool bInteractionEnabled; // 0x459 Size: 0x1
	    char UnknownData2[0x26];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonButtonInternal");
			return (class UClass*)ptr;
		};

};

class UCommonButton : public UCommonUserWidget
{
	public:
	    int MinWidth; // 0x230 Size: 0x4
	    int MinHeight; // 0x234 Size: 0x4
	    class UCommonButtonStyle* Style; // 0x238 Size: 0x8
	    bool bHideInputAction; // 0x240 Size: 0x1
	    char UnknownData0[0x7]; // 0x241
	    struct FSlateSound PressedSlateSoundOverride; // 0x248 Size: 0x18
	    struct FSlateSound HoveredSlateSoundOverride; // 0x260 Size: 0x18
	    bool bApplyAlphaOnDisable; // 0x278 Size: 0x1
	    bool bSelectable; // 0x278 Size: 0x1
	    bool bShouldSelectUponReceivingFocus; // 0x278 Size: 0x1
	    bool bInteractableWhenSelected; // 0x278 Size: 0x1
	    bool bToggleable; // 0x278 Size: 0x1
	    bool bDisplayInputActionWhenNotInteractable; // 0x278 Size: 0x1
	    bool bHideInputActionWithKeyboard; // 0x278 Size: 0x1
	    bool bShouldUseFallbackDefaultInputAction; // 0x278 Size: 0x1
	    char UnknownData1[0x6]; // 0x280
	    char ClickMethod; // 0x27a Size: 0x1
	    char TouchMethod; // 0x27b Size: 0x1
	    char PressMethod; // 0x27c Size: 0x1
	    char UnknownData2[0x3]; // 0x27d
	    int InputPriority; // 0x280 Size: 0x4
	    char UnknownData3[0x4]; // 0x284
	    struct FDataTableRowHandle TriggeringInputAction; // 0x288 Size: 0x10
	    char UnknownData4[0x10]; // 0x298
	    MulticastDelegateProperty OnSelectedChanged; // 0x2a8 Size: 0x10
	    MulticastDelegateProperty OnButtonClicked; // 0x2b8 Size: 0x10
	    MulticastDelegateProperty OnButtonDoubleClicked; // 0x2c8 Size: 0x10
	    MulticastDelegateProperty OnButtonHovered; // 0x2d8 Size: 0x10
	    MulticastDelegateProperty OnButtonUnhovered; // 0x2e8 Size: 0x10
	    char UnknownData5[0x30]; // 0x2f8
	    class UCommonActionWidget* InputActionWidget; // 0x328 Size: 0x8
	    class UMaterialInstanceDynamic* SingleMaterialStyleMID; // 0x330 Size: 0x8
	    struct FButtonStyle NormalStyle; // 0x338 Size: 0x278
	    struct FButtonStyle SelectedStyle; // 0x5b0 Size: 0x278
	    struct FButtonStyle DisabledStyle; // 0x828 Size: 0x278
	    bool bStopDoubleClickPropagation; // 0xaa0 Size: 0x1
	    char UnknownData6[0xaa1]; // 0xaa1
	    void StopDoubleClickPropagation(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetTriggeringInputAction(struct FDataTableRowHandle InputActionRow); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetTriggeredInputAction(struct FDataTableRowHandle InputActionRow, class UCommonActivatablePanel* OldPanel); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetTouchMethod(char InTouchMethod); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetStyle(class UCommonButtonStyle* InStyle); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetShouldSelectUponReceivingFocus(bool bInShouldSelectUponReceivingFocus); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetSelectedInternal(bool bInSelected, bool bAllowSound, bool bBroadcast); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void SetPressMethod(char InPressMethod); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void SetMinDimensions(int InMinWidth, int InMinHeight); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void SetIsToggleable(bool bInIsToggleable); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void SetIsSelected(bool InSelected, bool bGiveClickFeedback); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void SetIsSelectable(bool bInIsSelectable); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void SetIsInteractionEnabled(bool bInIsInteractionEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void SetIsInteractableWhenSelected(bool bInInteractableWhenSelected); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void SetInputActionProgressMaterial(struct FSlateBrush InProgressMaterialBrush, FName InProgressMaterialParam); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void SetClickMethod(char InClickMethod); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void OnTriggeredInputActionChanged(struct FDataTableRowHandle NewTriggeredAction); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void OnInputMethodChanged(ECommonInputType CurrentInputType); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void OnCurrentTextStyleChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void OnActionProgress(float HeldPercent); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void OnActionComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void NativeOnActionProgress(float HeldPercent); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void NativeOnActionComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    bool IsPressed(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    bool IsInteractionEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    void HandleTriggeringActionCommited(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    void HandleFocusReceived(); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    void HandleButtonReleased(); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    void HandleButtonPressed(); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    void HandleButtonClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    class UCommonButtonStyle* GetStyle(); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    class UMaterialInstanceDynamic* GetSingleMaterialStyleMID(); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    bool GetShouldSelectUponReceivingFocus(); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    bool GetSelected(); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    bool GetInputAction(struct FDataTableRowHandle InputActionRow); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    class UCommonTextStyle* GetCurrentTextStyleClass(); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    class UCommonTextStyle* GetCurrentTextStyle(); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    void GetCurrentCustomPadding(struct FMargin OutCustomPadding); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    void GetCurrentButtonPadding(struct FMargin OutButtonPadding); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    void DisableButtonWithReason(struct FText DisabledReason); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    void ClearSelection(); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    void BP_OnUnhovered(); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    void BP_OnSelected(); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    void BP_OnHovered(); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    void BP_OnEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    void BP_OnDoubleClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    void BP_OnDisabled(); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    void BP_OnDeselected(); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    void BP_OnClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x-74b9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonButton");
			return (class UClass*)ptr;
		};

};

class UCommonWidgetGroupBase : public UObject
{
	public:
	    void RemoveWidget(class UWidget* InWidget); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void RemoveAll(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void AddWidget(class UWidget* InWidget); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonWidgetGroupBase");
			return (class UClass*)ptr;
		};

};

class UCommonButtonGroup : public UCommonWidgetGroupBase
{
	public:
	    MulticastDelegateProperty OnSelectedButtonChanged; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnHoveredButtonChanged; // 0x38 Size: 0x10
	    MulticastDelegateProperty OnButtonClicked; // 0x48 Size: 0x10
	    MulticastDelegateProperty OnButtonDoubleClicked; // 0x58 Size: 0x10
	    MulticastDelegateProperty OnSelectionCleared; // 0x68 Size: 0x10
	    bool bSelectionRequired; // 0x78 Size: 0x1
	    char UnknownData0[0x79]; // 0x79
	    void SetSelectionRequired(bool bRequireSelection); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SelectPreviousButton(bool bAllowWrap); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SelectNextButton(bool bAllowWrap); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SelectButtonAtIndex(int ButtonIndex); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnSelectionStateChanged(class UCommonButton* BaseButton, bool bIsSelected); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnHandleButtonDoubleClicked(class UCommonButton* BaseButton); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnHandleButtonClicked(class UCommonButton* BaseButton); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnButtonUnhovered(class UCommonButton* BaseButton); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnButtonHovered(class UCommonButton* BaseButton); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool HasAnyButtons(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    int GetSelectedButtonIndex(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    int GetHoveredButtonIndex(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    int GetButtonCount(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    class UCommonButton* GetButtonAtIndex(int Index); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    int FindButtonIndex(class UCommonButton* ButtonToFind); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void DeselectAll(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x-7f49];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonButtonGroup");
			return (class UClass*)ptr;
		};

};

class UCommonCustomNavigation : public UBorder
{
	public:
	    __int64/*DelegateProperty*/ OnNavigationEvent; // 0x260 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonCustomNavigation");
			return (class UClass*)ptr;
		};

};

class UCommonTextBlock : public UTextBlock
{
	public:
	    class UCommonTextStyle* Style; // 0x210 Size: 0x8
	    class UCommonTextScrollStyle* ScrollStyle; // 0x218 Size: 0x8
	    char UnknownData0[0x220]; // 0x220
	    void SetWrapTextWidth(int InWrapTextAt); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetStyle(class UCommonTextStyle* InStyle); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetScrollStyle(class UCommonTextScrollStyle* InScrollStyle); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void ResetScrollState(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7d81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonTextBlock");
			return (class UClass*)ptr;
		};

};

class UCommonDateTimeTextBlock : public UCommonTextBlock
{
	public:
	    void SetTimespanValue(struct FTimespan InTimespan); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void SetDateTimeValue(struct FDateTime InDateTime, bool bShowAsCountdown); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetCountDownCompletionText(struct FText InCompletionText); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    struct FDateTime GetDateTime(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonDateTimeTextBlock");
			return (class UClass*)ptr;
		};

};

class UCommonGlobalInputHandler : public UObject
{
	public:
	    char UnknownData0[0x70];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonGlobalInputHandler");
			return (class UClass*)ptr;
		};

};

class UCommonHierarchicalScrollBox : public UScrollBox
{
	public:
	    char UnknownData0[0x860];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonHierarchicalScrollBox");
			return (class UClass*)ptr;
		};

};

class UCommonInputManager : public UObject
{
	public:
	    char UnknownData0[0x80];
	    __int64/*InterfaceProperty*/ CurrentlyHeldActionInputHandler; // 0xa8 Size: 0x10
	    TArray<class UCommonActivatablePanel*> ActivatablePanelStack; // 0xb8 Size: 0x10
	    class UCommonGlobalInputHandler* GlobalInputHandler; // 0xc8 Size: 0x8
	    char UnknownData1[0x18]; // 0xd0
	    TArray<struct FOperation> Operations; // 0xe8 Size: 0x10
	    char UnknownData2[0xf8]; // 0xf8
	    void SuspendStartingOperationProcessing(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool StopListeningForExistingHeldAction(struct FDataTableRowHandle InputActionDataRow, __int64/*DelegateProperty*/ CompleteEvent, __int64/*DelegateProperty*/ ProgressEvent); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool StartListeningForExistingHeldAction(struct FDataTableRowHandle InputActionDataRow, __int64/*DelegateProperty*/ CompleteEvent, __int64/*DelegateProperty*/ ProgressEvent); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetGlobalInputHandlerPriorityFilter(int InFilterPriority); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ResumeStartingOperationProcessing(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void PushActivatablePanel(class UCommonActivatablePanel* ActivatablePanel, bool bIntroPanel, bool bOutroPanelBelow); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void PopActivatablePanel(class UCommonActivatablePanel* ActivatablePanel); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool IsPanelOnStack(class UCommonActivatablePanel* InPanel); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    bool IsInputSuspended(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    class UCommonActivatablePanel* GetTopPanel(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    int GetGlobalInputHandlerPriorityFilter(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    bool GetAvailableInputActions(TArray<struct FCommonInputActionHandlerData> AvailableInputActions); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x-7ed9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonInputManager");
			return (class UClass*)ptr;
		};

};

class UCommonInputReflector : public UCommonUserWidget
{
	public:
	    class UCommonButton* ButtonType; // 0x230 Size: 0x8
	    TArray<class UCommonButton*> ActiveButtons; // 0x238 Size: 0x10
	    TArray<class UCommonButton*> InactiveButtons; // 0x248 Size: 0x10
	    char UnknownData0[0x258]; // 0x258
	    void OnButtonAdded(class UCommonButton* AddedButton, struct FCommonInputActionHandlerData Data); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7d81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonInputReflector");
			return (class UClass*)ptr;
		};

};

class UCommonLazyImage : public UImage
{
	public:
	    struct FSlateBrush LoadingBackgroundBrush; // 0x200 Size: 0x88
	    FName MaterialTextureParamName; // 0x288 Size: 0x8
	    MulticastDelegateProperty BP_OnLoadingStateChanged; // 0x290 Size: 0x10
	    char UnknownData0[0x2a0]; // 0x2a0
	    void SetMaterialTextureParamName(FName TextureParamName); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetBrushFromLazyTexture(struct TSoftObjectPtr<struct UTexture2D*> LazyTexture, bool bMatchSize); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetBrushFromLazyMaterial(struct TSoftObjectPtr<struct UMaterialInterface*> LazyMaterial); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetBrushFromLazyDisplayAsset(struct TSoftObjectPtr<struct UObject*> LazyObject, bool bMatchTextureSize); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool IsLoading(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7d19];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonLazyImage");
			return (class UClass*)ptr;
		};

};

class UCommonLazyWidget : public UWidget
{
	public:
	    struct FSlateBrush LoadingBackgroundBrush; // 0x100 Size: 0x88
	    class UUserWidget* Content; // 0x188 Size: 0x8
	    char UnknownData0[0x28]; // 0x190
	    MulticastDelegateProperty BP_OnLoadingStateChanged; // 0x1b8 Size: 0x10
	    char UnknownData1[0x1c8]; // 0x1c8
	    void SetLazyContent(__int64/*SoftClassProperty*/ SoftWidget); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool IsLoading(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7df1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonLazyWidget");
			return (class UClass*)ptr;
		};

};

class UCommonListView : public UListView
{
	public:
	    char UnknownData0[0x330];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonListView");
			return (class UClass*)ptr;
		};

};

class ULoadGuardSlot : public UPanelSlot
{
	public:
	    struct FMargin Padding; // 0x38 Size: 0x10
	    char HorizontalAlignment; // 0x48 Size: 0x1
	    char VerticalAlignment; // 0x49 Size: 0x1
	    char UnknownData0[0x4a]; // 0x4a
	    void SetVerticalAlignment(char InVerticalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetPadding(struct FMargin InPadding); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetHorizontalAlignment(char InHorizontalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.LoadGuardSlot");
			return (class UClass*)ptr;
		};

};

class UCommonLoadGuard : public UContentWidget
{
	public:
	    struct FSlateBrush LoadingBackgroundBrush; // 0x118 Size: 0x88
	    char ThrobberAlignment; // 0x1a0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1a1
	    struct FMargin ThrobberPadding; // 0x1a4 Size: 0x10
	    char UnknownData1[0x4]; // 0x1b4
	    struct FText LoadingText; // 0x1b8 Size: 0x18
	    class UCommonTextStyle* TextStyle; // 0x1d0 Size: 0x8
	    MulticastDelegateProperty BP_OnLoadingStateChanged; // 0x1d8 Size: 0x10
	    struct FSoftObjectPath SpinnerMaterialPath; // 0x1e8 Size: 0x18
	    char UnknownData2[0x200]; // 0x200
	    void SetLoadingText(struct FText InLoadingText); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetIsLoading(bool bInIsLoading); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnAssetLoaded__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool IsLoading(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void BP_GuardAndLoadAsset(struct TSoftObjectPtr<struct UObject*> InLazyAsset, __int64/*DelegateProperty*/ OnAssetLoaded); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7db9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonLoadGuard");
			return (class UClass*)ptr;
		};

};

class UCommonNumericTextBlock : public UCommonTextBlock
{
	public:
	    MulticastDelegateProperty OnOutroEvent; // 0x260 Size: 0x10
	    MulticastDelegateProperty OnInterpolationEndedEvent; // 0x270 Size: 0x10
	    float CurrentNumericValue; // 0x280 Size: 0x4
	    ECommonNumericType NumericType; // 0x284 Size: 0x1
	    char UnknownData0[0x3]; // 0x285
	    struct FCommonNumberFormattingOptions FormattingSpecification; // 0x288 Size: 0x14
	    float EaseOutInterpolationExponent; // 0x29c Size: 0x4
	    float InterpolationUpdateInterval; // 0x2a0 Size: 0x4
	    float PostInterpolationShrinkDuration; // 0x2a4 Size: 0x4
	    bool PerformSizeInterpolation; // 0x2a8 Size: 0x1
	    bool IsPercentage; // 0x2a9 Size: 0x1
	    char UnknownData1[0x2aa]; // 0x2aa
	    void SetNumericType(ECommonNumericType InNumericType); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetCurrentValue(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnOutro__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnInterpolationEnded__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool IsInterpolatingNumericValue(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void InterpolateToValue(float TargetValue, float MaximumInterpolationDuration, float MinimumChangeRate, float OutroOffset); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    float GetTargetValue(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7d01];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonNumericTextBlock");
			return (class UClass*)ptr;
		};

};

class UCommonPoolableWidgetInterface : public UInterface
{
	public:
	    void OnReleaseToPool(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void OnAcquireFromPool(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonPoolableWidgetInterface");
			return (class UClass*)ptr;
		};

};

class UCommonPopupButton : public UCommonButton
{
	public:
	    class UMenuAnchor* PopupMenuAnchor; // 0xb28 Size: 0x8
	    class UCommonPopupMenu* PopupMenu; // 0xb30 Size: 0x8
	    char UnknownData0[0xb38]; // 0xb38
	    class UWidget* GetMenuAnchorWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-74a9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonPopupButton");
			return (class UClass*)ptr;
		};

};

class UCommonPopupMenu : public UCommonActivatablePanel
{
	public:
	    bool bUseInputStack; // 0x318 Size: 0x1
	    char UnknownData0[0x3]; // 0x319
	    TWeakObjectPtr<UMenuAnchor*> OwningMenuAnchor; // 0x31c Size: 0x8
	    TWeakObjectPtr<UObject*> ContextProvidingObject; // 0x324 Size: 0x8
	    char UnknownData1[0x32c]; // 0x32c
	    void SetOwningMenuAnchor(class UMenuAnchor* MenuAnchor); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetContextProvider(class UObject* ContextProvidingObject); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void RequestClose(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnIsOpenChanged(bool IsOpen); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandlePreDifferentContextProviderSet(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void HandlePostDifferentContextProviderSet(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7cb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonPopupMenu");
			return (class UClass*)ptr;
		};

};

class UCommonRotator : public UCommonButton
{
	public:
	    char UnknownData0[0x10];
	    MulticastDelegateProperty OnRotated; // 0xb38 Size: 0x10
	    class UCommonTextBlock* MyText; // 0xb48 Size: 0x8
	    char UnknownData1[0xb50]; // 0xb50
	    void ShiftTextRight(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void ShiftTextLeft(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetSelectedItem(int InValue); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void PopulateTextLabels(TArray<struct FText> Labels); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    struct FText GetSelectedText(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    int GetSelectedIndex(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7479];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonRotator");
			return (class UClass*)ptr;
		};

};

class UCommonTabListWidget : public UCommonUserWidget
{
	public:
	    MulticastDelegateProperty OnTabSelected; // 0x230 Size: 0x10
	    MulticastDelegateProperty OnTabButtonCreated; // 0x240 Size: 0x10
	    MulticastDelegateProperty OnTabButtonRemoved; // 0x250 Size: 0x10
	    struct FDataTableRowHandle NextTabInputActionData; // 0x260 Size: 0x10
	    struct FDataTableRowHandle PreviousTabInputActionData; // 0x270 Size: 0x10
	    bool bAutoListenForInput; // 0x280 Size: 0x1
	    char UnknownData0[0x3]; // 0x281
	    TWeakObjectPtr<UCommonWidgetSwitcher*> LinkedSwitcher; // 0x284 Size: 0x8
	    char UnknownData1[0x4]; // 0x28c
	    __int64/*MapProperty*/ RegisteredTabsByID; // 0x290 Size: 0x50
	    class UCommonButtonGroup* TabButtonGroup; // 0x2e0 Size: 0x8
	    char UnknownData2[0x2e8]; // 0x2e8
	    void SetTabVisibility(FName TabNameID, ESlateVisibility NewVisibility); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetTabInteractionEnabled(FName TabNameID, bool bEnable); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetTabEnabled(FName TabNameID, bool bEnable); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetListeningForInput(bool bShouldListen); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetLinkedSwitcher(class UCommonWidgetSwitcher* CommonSwitcher); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool SelectTabByID(FName TabNameID, bool bSuppressClickFeedback); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool RemoveTab(FName TabNameID); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void RemoveAllTabs(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    bool RegisterTab(FName TabNameID, class UCommonButton* ButtonWidgetType, class UWidget* ContentWidget); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnTabSelected__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnTabButtonRemoved__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnTabButtonCreated__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void HandleTabRemoved(FName TabNameID, class UCommonButton* TabButton); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void HandleTabCreated(FName TabNameID, class UCommonButton* TabButton); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void HandleTabButtonSelected(class UCommonButton* SelectedTabButton, int ButtonIndex); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void HandlePreviousTabInputAction(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void HandlePreLinkedSwitcherChanged_BP(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void HandlePostLinkedSwitcherChanged_BP(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void HandleNextTabInputAction(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    FName GetTabIdAtIndex(int Index); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    int GetTabCount(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    class UCommonButton* GetTabButtonByID(FName TabNameID); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    FName GetSelectedTabId(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    class UCommonWidgetSwitcher* GetLinkedSwitcher(); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    FName GetActiveTab(); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void DisableTabWithReason(FName TabNameID, struct FText Reason); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x-7ce9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonTabListWidget");
			return (class UClass*)ptr;
		};

};

class UCommonTextStyle : public UObject
{
	public:
	    struct FSlateFontInfo Font; // 0x28 Size: 0x50
	    struct FLinearColor Color; // 0x78 Size: 0x10
	    bool bUsesDropShadow; // 0x88 Size: 0x1
	    char UnknownData0[0x3]; // 0x89
	    struct FVector2D ShadowOffset; // 0x8c Size: 0x8
	    struct FLinearColor ShadowColor; // 0x94 Size: 0x10
	    struct FMargin Margin; // 0xa4 Size: 0x10
	    float LineHeightPercentage; // 0xb4 Size: 0x4
	    char UnknownData1[0xb8]; // 0xb8
	    void GetShadowOffset(struct FVector2D OutShadowOffset); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void GetShadowColor(struct FLinearColor OutColor); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void GetMargin(struct FMargin OutMargin); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    float GetLineHeightPercentage(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void GetFont(struct FSlateFontInfo OutFont); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void GetColor(struct FLinearColor OutColor); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7f29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonTextStyle");
			return (class UClass*)ptr;
		};

};

class UCommonTextScrollStyle : public UObject
{
	public:
	    float Speed; // 0x28 Size: 0x4
	    float StartDelay; // 0x2c Size: 0x4
	    float EndDelay; // 0x30 Size: 0x4
	    float FadeInDelay; // 0x34 Size: 0x4
	    float FadeOutDelay; // 0x38 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonTextScrollStyle");
			return (class UClass*)ptr;
		};

};

class UCommonTileView : public UTileView
{
	public:
	    char UnknownData0[0x350];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonTileView");
			return (class UClass*)ptr;
		};

};

class UCommonTreeView : public UTreeView
{
	public:
	    char UnknownData0[0x388];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonTreeView");
			return (class UClass*)ptr;
		};

};

class UCommonUIEditorSettings : public UObject
{
	public:
	    __int64/*SoftClassProperty*/ TemplateTextStyle; // 0x28 Size: 0x28
	    __int64/*SoftClassProperty*/ TemplateButtonStyle; // 0x50 Size: 0x28
	    __int64/*SoftClassProperty*/ TemplateBorderStyle; // 0x78 Size: 0x28
	    char UnknownData0[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonUIEditorSettings");
			return (class UClass*)ptr;
		};

};

class UCommonUILibrary : public UBlueprintFunctionLibrary
{
	public:
	    static class UWidget* FindParentWidgetOfType(class UWidget* StartingWidget, class UWidget* Type); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonUILibrary");
			return (class UClass*)ptr;
		};

};

class UCommonUIInputData : public UObject
{
	public:
	    struct FDataTableRowHandle DefaultClickAction; // 0x28 Size: 0x10
	    TArray<struct FCommonInputKeyDisplayConfiguration> InputKeyDataMap; // 0x38 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonUIInputData");
			return (class UClass*)ptr;
		};

};

class UCommonUISettings : public UObject
{
	public:
	    bool bAutoLoadData; // 0x28 Size: 0x1
	    char UnknownData0[0x7]; // 0x29
	    struct TSoftObjectPtr<struct UObject*> DefaultImageResourceObject; // 0x30 Size: 0x28
	    struct TSoftObjectPtr<struct UMaterialInterface*> DefaultThrobberMaterial; // 0x58 Size: 0x28
	    __int64/*SoftClassProperty*/ InputData; // 0x80 Size: 0x28
	    char UnknownData1[0x8]; // 0xa8
	    class UObject* DefaultImageResourceObjectInstance; // 0xb0 Size: 0x8
	    class UMaterialInterface* DefaultThrobberMaterialInstance; // 0xb8 Size: 0x8
	    struct FSlateBrush DefaultThrobberBrush; // 0xc0 Size: 0x88
	    class UCommonUIInputData* InputDataClass; // 0x148 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonUISettings");
			return (class UClass*)ptr;
		};

};

class UCommonUISubsystem : public UGameInstanceSubsystem
{
	public:
	    MulticastDelegateProperty OnInputMethodChanged; // 0x28 Size: 0x10
	    char UnknownData0[0x18]; // 0x38
	    MulticastDelegateProperty OnInputSuspensionChanged; // 0x50 Size: 0x10
	    char UnknownData1[0x10]; // 0x60
	    class UCommonInputManager* CommonInputManager; // 0x70 Size: 0x8
	    char UnknownData2[0x78]; // 0x78
	    __int64/*DelegateFunction*/ InputSuspensionChanged__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ InputMethodChangedDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    class UCommonInputManager* GetInputManager(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    struct FSlateBrush GetInputActionButtonIcon(struct FDataTableRowHandle InputActionRowHandle, ECommonInputType InputType, ECommonGamepadType GamepadType); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7f69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonUISubsystem");
			return (class UClass*)ptr;
		};

};

class UCommonVisibilityWidget : public UCommonBorder
{
	public:
	    bool bShowForGamepad; // 0x280 Size: 0x1
	    bool bShowForMouseAndKeyboard; // 0x281 Size: 0x1
	    bool bShowForTouch; // 0x282 Size: 0x1
	    bool bShowForPC; // 0x283 Size: 0x1
	    bool bShowForMac; // 0x284 Size: 0x1
	    bool bShowForPS4; // 0x285 Size: 0x1
	    bool bShowForXBox; // 0x286 Size: 0x1
	    bool bShowForIOS; // 0x287 Size: 0x1
	    bool bShowForAndroid; // 0x288 Size: 0x1
	    bool bShowForErebus; // 0x289 Size: 0x1
	    ESlateVisibility VisibleType; // 0x28a Size: 0x1
	    ESlateVisibility HiddenType; // 0x28b Size: 0x1
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonVisibilityWidget");
			return (class UClass*)ptr;
		};

};

class UCommonWidgetCarousel : public UPanelWidget
{
	public:
	    int ActiveWidgetIndex; // 0x118 Size: 0x4
	    char UnknownData0[0x4]; // 0x11c
	    MulticastDelegateProperty OnCurrentPageIndexChanged; // 0x120 Size: 0x10
	    char UnknownData1[0x130]; // 0x130
	    void SetActiveWidgetIndex(int Index); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetActiveWidget(class UWidget* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void PreviousPage(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void NextPage(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    class UWidget* GetWidgetAtIndex(int Index); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    int GetActiveWidgetIndex(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void EndAutoScrolling(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void BeginAutoScrolling(float ScrollInterval); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7e89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonWidgetCarousel");
			return (class UClass*)ptr;
		};

};

class UCommonWidgetCarouselNavBar : public UWidget
{
	public:
	    class UCommonButton* ButtonWidgetType; // 0x100 Size: 0x8
	    struct FMargin ButtonPadding; // 0x108 Size: 0x10
	    char UnknownData0[0x10]; // 0x118
	    class UCommonWidgetCarousel* LinkedCarousel; // 0x128 Size: 0x8
	    class UCommonButtonGroup* ButtonGroup; // 0x130 Size: 0x8
	    TArray<class UCommonButton*> Buttons; // 0x138 Size: 0x10
	    char UnknownData1[0x148]; // 0x148
	    void SetLinkedCarousel(class UCommonWidgetCarousel* CommonCarousel); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HandlePageChanged(class UCommonWidgetCarousel* CommonCarousel, int PageIndex); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleButtonClicked(class UCommonButton* AssociatedButton, int ButtonIndex); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7e99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonWidgetCarouselNavBar");
			return (class UClass*)ptr;
		};

};

class UCommonWidgetSwitcher : public UWidgetSwitcher
{
	public:
	    MulticastDelegateProperty OnActiveWidgetDeactivated; // 0x130 Size: 0x10
	    MulticastDelegateProperty OnActiveWidgetChanged; // 0x140 Size: 0x10
	    ECommonSwitcherTransition TransitionType; // 0x150 Size: 0x1
	    ETransitionCurve TransitionCurveType; // 0x151 Size: 0x1
	    char UnknownData0[0x2]; // 0x152
	    float TransitionDuration; // 0x154 Size: 0x4
	    bool bWidgetActivationEnabled; // 0x17a Size: 0x1
	    bool bOutroPanelBelow; // 0x17b Size: 0x1
	    char UnknownData1[0x15a]; // 0x15a
	    void SetDisableTransitionAnimation(bool bDisableAnimation); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetActiveWidgetIndex_Advanced(int Index, bool AttemptActivationChange); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetActiveWidget_Advanced(class UWidget* Widget, bool AttemptActivationChange); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool HasWidgets(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleActiveWidgetDeactivated(class UCommonActivatablePanel* DeactivatedPanel); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void DeactivateWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void ActivateWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void ActivatePreviousWidget(bool bCanWrap); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void ActivateNextWidget(bool bCanWrap); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7e61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonWidgetSwitcher");
			return (class UClass*)ptr;
		};

};

class UCommonWidgetStack : public UCommonWidgetSwitcher
{
	public:
	    void PushWidget(class UWidget* InWidget); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    class UWidget* PopWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7e61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CommonUI.CommonWidgetStack");
			return (class UClass*)ptr;
		};

};


}