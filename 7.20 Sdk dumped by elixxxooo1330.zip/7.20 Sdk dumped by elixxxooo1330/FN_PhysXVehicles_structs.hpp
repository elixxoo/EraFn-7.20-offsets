#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class EWheelSweepType : uint8_t
{
    SimpleAndComplex = 0,
    Simple = 1,
    Complex = 2,
    EWheelSweepType_MAX = 3
};

enum class EVehicleDifferential4W : uint8_t
{
    LimitedSlip_4W = 0,
    LimitedSlip_FrontDrive = 1,
    LimitedSlip_RearDrive = 2,
    Open_4W = 3,
    Open_FrontDrive = 4,
    Open_RearDrive = 5,
    EVehicleDifferential4W_MAX = 6
};struct FAnimNode_WheelHandler : public FAnimNode_SkeletalControlBase
{
	public:
	    char UnknownData0[0xe0];

};

struct FTireConfigMaterialFriction
{
	public:
	    class UPhysicalMaterial* PhysicalMaterial; // 0x0 Size: 0x8
	    float FrictionScale; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FVehicleAnimInstanceProxy : public FAnimInstanceProxy
{
	public:
	    char UnknownData0[0x710];

};

struct FVehicleInputRate
{
	public:
	    float RiseRate; // 0x0 Size: 0x4
	    float FallRate; // 0x4 Size: 0x4

};

struct FReplicatedVehicleState
{
	public:
	    float SteeringInput; // 0x0 Size: 0x4
	    float ThrottleInput; // 0x4 Size: 0x4
	    float BrakeInput; // 0x8 Size: 0x4
	    float HandbrakeInput; // 0xc Size: 0x4
	    int CurrentGear; // 0x10 Size: 0x4

};

struct FWheelSetup
{
	public:
	    class UVehicleWheel* WheelClass; // 0x0 Size: 0x8
	    FName BoneName; // 0x8 Size: 0x8
	    struct FVector AdditionalOffset; // 0x10 Size: 0xc
	    bool bDisableSteering; // 0x1c Size: 0x1
	    char UnknownData0[0x3];

};

struct FVehicleGearData
{
	public:
	    float Ratio; // 0x0 Size: 0x4
	    float DownRatio; // 0x4 Size: 0x4
	    float UpRatio; // 0x8 Size: 0x4

};

struct FVehicleDifferential4WData
{
	public:
	    char DifferentialType; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float FrontRearSplit; // 0x4 Size: 0x4
	    float FrontLeftRightSplit; // 0x8 Size: 0x4
	    float RearLeftRightSplit; // 0xc Size: 0x4
	    float CentreBias; // 0x10 Size: 0x4
	    float FrontBias; // 0x14 Size: 0x4
	    float RearBias; // 0x18 Size: 0x4

};


}