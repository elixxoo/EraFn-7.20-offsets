#include "../SDK.hpp"

void UFortMediaSubtitlesPlayer::Stop()
{
    static auto fn = UObject::FindObject("/Script/SubtitlesWidgets.FortMediaSubtitlesPlayer:Stop");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UFortMediaSubtitlesPlayer::SetSubtitles(class UOverlays* Subtitles)
{
	struct {
            class UOverlays* Subtitles;
	} params{ Subtitles };

    static auto fn = UObject::FindObject("/Script/SubtitlesWidgets.FortMediaSubtitlesPlayer:SetSubtitles");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UFortMediaSubtitlesPlayer::Play()
{
    static auto fn = UObject::FindObject("/Script/SubtitlesWidgets.FortMediaSubtitlesPlayer:Play");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UFortMediaSubtitlesPlayer::BindToMediaPlayer(class UMediaPlayer* InMediaPlayer)
{
	struct {
            class UMediaPlayer* InMediaPlayer;
	} params{ InMediaPlayer };

    static auto fn = UObject::FindObject("/Script/SubtitlesWidgets.FortMediaSubtitlesPlayer:BindToMediaPlayer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

bool USubtitleDisplay::HasSubtitles()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/SubtitlesWidgets.SubtitleDisplay:HasSubtitles");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

