#pragma once

#include "../SDK.hpp"

namespace SDK {


class UControlRig : public UObject
{
	public:
	    char UnknownData0[0x14];
	    ERigExecutionType ExecutionType; // 0x3c Size: 0x1
	    char UnknownData1[0x3]; // 0x3d
	    struct FRigHierarchyContainer Hierarchy; // 0x40 Size: 0xc0
	    TArray<struct FControlRigOperator> Operators; // 0x100 Size: 0x10
	    char UnknownData2[0x110]; // 0x110
	    void SetGlobalTransform(FName JointName, struct FTransform InTransform); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    struct FTransform GetGlobalTransform(FName JointName); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    float GetDeltaTime(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7e91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ControlRig.ControlRig");
			return (class UClass*)ptr;
		};

};

class UControlRigBindingTrack : public UMovieSceneSpawnTrack
{
	public:
	    char UnknownData0[0x78];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ControlRig.ControlRigBindingTrack");
			return (class UClass*)ptr;
		};

};

class UControlRigBlueprintGeneratedClass : public UBlueprintGeneratedClass
{
	public:
	    char UnknownData0[0x2e0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ControlRig.ControlRigBlueprintGeneratedClass");
			return (class UClass*)ptr;
		};

};

class UControlRigComponent : public UActorComponent
{
	public:
	    MulticastDelegateProperty OnPreInitializeDelegate; // 0xf8 Size: 0x10
	    MulticastDelegateProperty OnPostInitializeDelegate; // 0x108 Size: 0x10
	    MulticastDelegateProperty OnPreEvaluateDelegate; // 0x118 Size: 0x10
	    MulticastDelegateProperty OnPostEvaluateDelegate; // 0x128 Size: 0x10
	    class UControlRig* ControlRig; // 0x138 Size: 0x8
	    char UnknownData0[0x140]; // 0x140
	    void OnPreInitialize(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnPreEvaluate(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnPostInitialize(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnPostEvaluate(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    class UControlRig* BP_GetControlRig(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7ea1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ControlRig.ControlRigComponent");
			return (class UClass*)ptr;
		};

};

class AControlRigControl : public AActor
{
	public:
	    struct FString PropertyPath; // 0x330 Size: 0x10
	    struct FTransform Transform; // 0x340 Size: 0x30
	    bool bEnabled; // 0x370 Size: 0x1
	    bool bSelected; // 0x370 Size: 0x1
	    bool bHovered; // 0x370 Size: 0x1
	    bool bManipulating; // 0x370 Size: 0x1
	    char UnknownData0[0x374]; // 0x374
	    void OnTransformChanged(struct FTransform NewTransform); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnSelectionChanged(bool bIsSelected); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnManipulatingChanged(bool bIsManipulating); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnHoveredChanged(bool bIsSelected); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnEnabledChanged(bool bIsEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7c61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ControlRig.ControlRigControl");
			return (class UClass*)ptr;
		};

};

class UControlRigLibrary : public UBlueprintFunctionLibrary
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ControlRig.ControlRigLibrary");
			return (class UClass*)ptr;
		};

};

class UControlRigObjectHolder : public UObject
{
	public:
	    TArray<class UObject*> Objects; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ControlRig.ControlRigObjectHolder");
			return (class UClass*)ptr;
		};

};

class UControlRigSequence : public ULevelSequence
{
	public:
	    struct TSoftObjectPtr<struct UAnimSequence*> LastExportedToAnimationSequence; // 0x498 Size: 0x28
	    struct TSoftObjectPtr<struct USkeletalMesh*> LastExportedUsingSkeletalMesh; // 0x4c0 Size: 0x28
	    float LastExportedFrameRate; // 0x4e8 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ControlRig.ControlRigSequence");
			return (class UClass*)ptr;
		};

};

class UControlRigSequencerAnimInstance : public UAnimSequencerInstance
{
	public:
	    char UnknownData0[0x270];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ControlRig.ControlRigSequencerAnimInstance");
			return (class UClass*)ptr;
		};

};

class AControlRigStaticMeshControl : public AControlRigControl
{
	public:
	    class USceneComponent* Scene; // 0x378 Size: 0x8
	    class UStaticMeshComponent* Mesh; // 0x380 Size: 0x8
	    char UnknownData0[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ControlRig.ControlRigStaticMeshControl");
			return (class UClass*)ptr;
		};

};

class UMovieSceneControlRigSection : public UMovieSceneSubSection
{
	public:
	    bool bAdditive; // 0x150 Size: 0x1
	    bool bApplyBoneFilter; // 0x151 Size: 0x1
	    char UnknownData0[0x6]; // 0x152
	    struct FInputBlendPose BoneFilter; // 0x158 Size: 0x10
	    struct FMovieSceneFloatChannel Weight; // 0x168 Size: 0xa0

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ControlRig.MovieSceneControlRigSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneControlRigTrack : public UMovieSceneSubTrack
{
	public:
	    char UnknownData0[0x68];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ControlRig.MovieSceneControlRigTrack");
			return (class UClass*)ptr;
		};

};

class UDefault__ControlRigBlueprintGeneratedClass
{
	public:

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ControlRig.Default__ControlRigBlueprintGeneratedClass");
			return (class UClass*)ptr;
		};

};


}