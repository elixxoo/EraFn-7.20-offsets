#pragma once

#include "../SDK.hpp"

namespace SDK {


class UMoviePlayerSettings : public UObject
{
	public:
	    bool bWaitForMoviesToComplete; // 0x28 Size: 0x1
	    bool bMoviesAreSkippable; // 0x29 Size: 0x1
	    char UnknownData0[0x6]; // 0x2a
	    TArray<struct FString> StartupMovies; // 0x30 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MoviePlayer.MoviePlayerSettings");
			return (class UClass*)ptr;
		};

};


}