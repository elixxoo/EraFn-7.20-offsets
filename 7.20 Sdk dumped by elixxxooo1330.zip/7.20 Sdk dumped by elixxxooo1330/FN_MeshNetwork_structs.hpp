#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FOnConnectedToRootChanged__DelegateSignature
{
	public:
	    bool bConnected; // 0x0 Size: 0x1

};

struct FOnMeshMetaDataUpdated__DelegateSignature
{
	public:

};



enum class EMeshNetworkNodeType : uint8_t
{
    Root = 0,
    Inner = 1,
    Edge = 2,
    Client = 3,
    EMeshNetworkNodeType_MAX = 4
};struct FOnMeshNodeTypeChanged__DelegateSignature
{
	public:
	    EMeshNetworkNodeType NodeType; // 0x0 Size: 0x1

};

struct FOnGameServerNodeTypeChanged__DelegateSignature
{
	public:
	    EMeshNetworkNodeType NodeType; // 0x0 Size: 0x1

};



enum class EMeshNetworkRelevancy : uint8_t
{
    NotRelevant = 0,
    RelevantToEdgeNodes = 1,
    RelevantToClients = 2,
    EMeshNetworkRelevancy_MAX = 3
};struct FAggregatedFunction
{
	public:
	    class UFunction* Function; // 0x0 Size: 0x8
	    char UnknownData0[0x20];

};

struct FMeshMetaDataStruct
{
	public:
	    char UnknownData0[0x1];

};


}