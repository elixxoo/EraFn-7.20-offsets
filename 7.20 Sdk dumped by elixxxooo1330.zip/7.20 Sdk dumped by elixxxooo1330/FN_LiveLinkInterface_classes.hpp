#pragma once

#include "../SDK.hpp"

namespace SDK {


class ULiveLinkSourceFactory : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/LiveLinkInterface.LiveLinkSourceFactory");
			return (class UClass*)ptr;
		};

};

class ULiveLinkSourceSettings : public UObject
{
	public:
	    ELiveLinkSourceMode Mode; // 0x28 Size: 0x1
	    char UnknownData0[0x3]; // 0x29
	    struct FLiveLinkInterpolationSettings InterpolationSettings; // 0x2c Size: 0x4
	    struct FLiveLinkTimeSynchronizationSettings TimeSynchronizationSettings; // 0x30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/LiveLinkInterface.LiveLinkSourceSettings");
			return (class UClass*)ptr;
		};

};


}