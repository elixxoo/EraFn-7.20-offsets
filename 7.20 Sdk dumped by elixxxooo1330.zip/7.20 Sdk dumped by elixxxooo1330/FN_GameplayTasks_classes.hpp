#pragma once

#include "../SDK.hpp"

namespace SDK {


class UGameplayTasksComponent : public UActorComponent
{
	public:
	    char UnknownData0[0xc];
	    bool bIsNetDirty; // 0x104 Size: 0x1
	    char UnknownData1[0x3]; // 0x105
	    TArray<class UGameplayTask*> SimulatedTasks; // 0x108 Size: 0x10
	    TArray<class UGameplayTask*> TaskPriorityQueue; // 0x118 Size: 0x10
	    char UnknownData2[0x10]; // 0x128
	    TArray<class UGameplayTask*> TickingTasks; // 0x138 Size: 0x10
	    TArray<class UGameplayTask*> KnownTasks; // 0x148 Size: 0x10
	    MulticastDelegateProperty OnClaimedResourcesChange; // 0x158 Size: 0x10
	    char UnknownData3[0x168]; // 0x168
	    void OnRep_SimulatedTasks(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static EGameplayTaskRunResult K2_RunGameplayTask(__int64/*InterfaceProperty*/ TaskOwner, class UGameplayTask* Task, char Priority, TArray<class UGameplayTaskResource*> AdditionalRequiredResources, TArray<class UGameplayTaskResource*> AdditionalClaimedResources); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7e79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayTasks.GameplayTasksComponent");
			return (class UClass*)ptr;
		};

};

class UGameplayTask : public UObject
{
	public:
	    char UnknownData0[0x8];
	    FName InstanceName; // 0x30 Size: 0x8
	    char UnknownData1[0x2]; // 0x38
	    ETaskResourceOverlapPolicy ResourceOverlapPolicy; // 0x3a Size: 0x1
	    char UnknownData2[0x25]; // 0x3b
	    class UGameplayTask* ChildTask; // 0x60 Size: 0x8
	    char UnknownData3[0x68]; // 0x68
	    void ReadyForActivation(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ GenericGameplayTaskDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void EndTask(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7f79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayTasks.GameplayTask");
			return (class UClass*)ptr;
		};

};

class UGameplayTask_ClaimResource : public UGameplayTask
{
	public:
	    static class UGameplayTask_ClaimResource* ClaimResources(__int64/*InterfaceProperty*/ InTaskOwner, TArray<class UGameplayTaskResource*> ResourceClasses, char Priority, FName TaskInstanceName); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static class UGameplayTask_ClaimResource* ClaimResource(__int64/*InterfaceProperty*/ InTaskOwner, class UGameplayTaskResource* ResourceClass, char Priority, FName TaskInstanceName); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayTasks.GameplayTask_ClaimResource");
			return (class UClass*)ptr;
		};

};

class UGameplayTask_SpawnActor : public UGameplayTask
{
	public:
	    MulticastDelegateProperty Success; // 0x68 Size: 0x10
	    MulticastDelegateProperty DidNotSpawn; // 0x78 Size: 0x10
	    char UnknownData0[0x18]; // 0x88
	    class AActor* ClassToSpawn; // 0xa0 Size: 0x8
	    char UnknownData1[0xa8]; // 0xa8
	    static class UGameplayTask_SpawnActor* SpawnActor(__int64/*InterfaceProperty*/ TaskOwner, struct FVector SpawnLocation, struct FRotator SpawnRotation, class AActor* Class, bool bSpawnOnlyOnAuthority); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void FinishSpawningActor(class UObject* WorldContextObject, class AActor* SpawnedActor); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool BeginSpawningActor(class UObject* WorldContextObject, class AActor* SpawnedActor); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7f39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayTasks.GameplayTask_SpawnActor");
			return (class UClass*)ptr;
		};

};

class UGameplayTask_TimeLimitedExecution : public UGameplayTask
{
	public:
	    MulticastDelegateProperty OnFinished; // 0x68 Size: 0x10
	    MulticastDelegateProperty OnTimeExpired; // 0x78 Size: 0x10
	    char UnknownData0[0x10];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayTasks.GameplayTask_TimeLimitedExecution");
			return (class UClass*)ptr;
		};

};

class UGameplayTask_WaitDelay : public UGameplayTask
{
	public:
	    MulticastDelegateProperty OnFinish; // 0x68 Size: 0x10
	    char UnknownData0[0x78]; // 0x78
	    static class UGameplayTask_WaitDelay* TaskWaitDelay(__int64/*InterfaceProperty*/ TaskOwner, float Time, char Priority); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ TaskDelayDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayTasks.GameplayTask_WaitDelay");
			return (class UClass*)ptr;
		};

};

class UGameplayTaskOwnerInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayTasks.GameplayTaskOwnerInterface");
			return (class UClass*)ptr;
		};

};

class UGameplayTaskResource : public UObject
{
	public:
	    int ManualResourceID; // 0x28 Size: 0x4
	    int8_t AutoResourceID; // 0x2c Size: 0x1
	    bool bManuallySetID; // 0x30 Size: 0x1
	    char UnknownData0[0xa];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayTasks.GameplayTaskResource");
			return (class UClass*)ptr;
		};

};


}