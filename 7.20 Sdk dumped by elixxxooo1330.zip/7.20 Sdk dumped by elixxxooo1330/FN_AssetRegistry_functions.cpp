#include "../SDK.hpp"

static struct FSoftObjectPath UAssetRegistryHelpers::ToSoftObjectPath(struct FAssetData InAssetData)
{
	struct {
            struct FAssetData InAssetData;
            struct FSoftObjectPath ReturnValue;
	} params{ InAssetData };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistryHelpers:ToSoftObjectPath");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FARFilter UAssetRegistryHelpers::SetFilterTagsAndValues(struct FARFilter InFilter, TArray<struct FTagAndValue> InTagsAndValues)
{
	struct {
            struct FARFilter InFilter;
            TArray<struct FTagAndValue> InTagsAndValues;
            struct FARFilter ReturnValue;
	} params{ InFilter, InTagsAndValues };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistryHelpers:SetFilterTagsAndValues");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAssetRegistryHelpers::IsValid(struct FAssetData InAssetData)
{
	struct {
            struct FAssetData InAssetData;
            bool ReturnValue;
	} params{ InAssetData };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistryHelpers:IsValid");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAssetRegistryHelpers::IsUAsset(struct FAssetData InAssetData)
{
	struct {
            struct FAssetData InAssetData;
            bool ReturnValue;
	} params{ InAssetData };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistryHelpers:IsUAsset");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAssetRegistryHelpers::IsRedirector(struct FAssetData InAssetData)
{
	struct {
            struct FAssetData InAssetData;
            bool ReturnValue;
	} params{ InAssetData };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistryHelpers:IsRedirector");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAssetRegistryHelpers::IsAssetLoaded(struct FAssetData InAssetData)
{
	struct {
            struct FAssetData InAssetData;
            bool ReturnValue;
	} params{ InAssetData };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistryHelpers:IsAssetLoaded");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAssetRegistryHelpers::GetTagValue(struct FAssetData InAssetData, FName InTagName, struct FString OutTagValue)
{
	struct {
            struct FAssetData InAssetData;
            FName InTagName;
            struct FString OutTagValue;
            bool ReturnValue;
	} params{ InAssetData, InTagName, OutTagValue };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistryHelpers:GetTagValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FString UAssetRegistryHelpers::GetFullName(struct FAssetData InAssetData)
{
	struct {
            struct FAssetData InAssetData;
            struct FString ReturnValue;
	} params{ InAssetData };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistryHelpers:GetFullName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FString UAssetRegistryHelpers::GetExportTextName(struct FAssetData InAssetData)
{
	struct {
            struct FAssetData InAssetData;
            struct FString ReturnValue;
	} params{ InAssetData };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistryHelpers:GetExportTextName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UObject* UAssetRegistryHelpers::GetClass(struct FAssetData InAssetData)
{
	struct {
            struct FAssetData InAssetData;
            class UObject* ReturnValue;
	} params{ InAssetData };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistryHelpers:GetClass");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static __int64/*InterfaceProperty*/ UAssetRegistryHelpers::GetAssetRegistry()
{
	struct {
            __int64/*InterfaceProperty*/ ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistryHelpers:GetAssetRegistry");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static class UObject* UAssetRegistryHelpers::GetAsset(struct FAssetData InAssetData)
{
	struct {
            struct FAssetData InAssetData;
            class UObject* ReturnValue;
	} params{ InAssetData };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistryHelpers:GetAsset");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FAssetData UAssetRegistryHelpers::CreateAssetData(class UObject* InAsset, bool bAllowBlueprintClass)
{
	struct {
            class UObject* InAsset;
            bool bAllowBlueprintClass;
            struct FAssetData ReturnValue;
	} params{ InAsset, bAllowBlueprintClass };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistryHelpers:CreateAssetData");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UAssetRegistry::UseFilterToExcludeAssets(TArray<struct FAssetData> AssetDataList, struct FARFilter Filter)
{
	struct {
            TArray<struct FAssetData> AssetDataList;
            struct FARFilter Filter;
	} params{ AssetDataList, Filter };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistry:UseFilterToExcludeAssets");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAssetRegistry::SearchAllAssets(bool bSynchronousSearch)
{
	struct {
            bool bSynchronousSearch;
	} params{ bSynchronousSearch };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistry:SearchAllAssets");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAssetRegistry::ScanPathsSynchronous(TArray<struct FString> InPaths, bool bForceRescan)
{
	struct {
            TArray<struct FString> InPaths;
            bool bForceRescan;
	} params{ InPaths, bForceRescan };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistry:ScanPathsSynchronous");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAssetRegistry::ScanModifiedAssetFiles(TArray<struct FString> InFilePaths)
{
	struct {
            TArray<struct FString> InFilePaths;
	} params{ InFilePaths };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistry:ScanModifiedAssetFiles");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAssetRegistry::ScanFilesSynchronous(TArray<struct FString> InFilePaths, bool bForceRescan)
{
	struct {
            TArray<struct FString> InFilePaths;
            bool bForceRescan;
	} params{ InFilePaths, bForceRescan };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistry:ScanFilesSynchronous");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAssetRegistry::RunAssetsThroughFilter(TArray<struct FAssetData> AssetDataList, struct FARFilter Filter)
{
	struct {
            TArray<struct FAssetData> AssetDataList;
            struct FARFilter Filter;
	} params{ AssetDataList, Filter };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistry:RunAssetsThroughFilter");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAssetRegistry::PrioritizeSearchPath(struct FString PathToPrioritize)
{
	struct {
            struct FString PathToPrioritize;
	} params{ PathToPrioritize };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistry:PrioritizeSearchPath");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UAssetRegistry::IsLoadingAssets()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistry:IsLoadingAssets");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UAssetRegistry::HasAssets(FName PackagePath, bool bRecursive)
{
	struct {
            FName PackagePath;
            bool bRecursive;
            bool ReturnValue;
	} params{ PackagePath, bRecursive };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistry:HasAssets");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UAssetRegistry::GetSubPaths(struct FString InBasePath, TArray<struct FString> OutPathList, bool bInRecurse)
{
	struct {
            struct FString InBasePath;
            TArray<struct FString> OutPathList;
            bool bInRecurse;
	} params{ InBasePath, OutPathList, bInRecurse };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistry:GetSubPaths");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UAssetRegistry::GetAssetsByPath(FName PackagePath, TArray<struct FAssetData> OutAssetData, bool bRecursive, bool bIncludeOnlyOnDiskAssets)
{
	struct {
            FName PackagePath;
            TArray<struct FAssetData> OutAssetData;
            bool bRecursive;
            bool bIncludeOnlyOnDiskAssets;
            bool ReturnValue;
	} params{ PackagePath, OutAssetData, bRecursive, bIncludeOnlyOnDiskAssets };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistry:GetAssetsByPath");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UAssetRegistry::GetAssetsByPackageName(FName PackageName, TArray<struct FAssetData> OutAssetData, bool bIncludeOnlyOnDiskAssets)
{
	struct {
            FName PackageName;
            TArray<struct FAssetData> OutAssetData;
            bool bIncludeOnlyOnDiskAssets;
            bool ReturnValue;
	} params{ PackageName, OutAssetData, bIncludeOnlyOnDiskAssets };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistry:GetAssetsByPackageName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UAssetRegistry::GetAssetsByClass(FName ClassName, TArray<struct FAssetData> OutAssetData, bool bSearchSubClasses)
{
	struct {
            FName ClassName;
            TArray<struct FAssetData> OutAssetData;
            bool bSearchSubClasses;
            bool ReturnValue;
	} params{ ClassName, OutAssetData, bSearchSubClasses };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistry:GetAssetsByClass");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UAssetRegistry::GetAssets(struct FARFilter Filter, TArray<struct FAssetData> OutAssetData)
{
	struct {
            struct FARFilter Filter;
            TArray<struct FAssetData> OutAssetData;
            bool ReturnValue;
	} params{ Filter, OutAssetData };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistry:GetAssets");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FAssetData UAssetRegistry::GetAssetByObjectPath(FName ObjectPath, bool bIncludeOnlyOnDiskAssets)
{
	struct {
            FName ObjectPath;
            bool bIncludeOnlyOnDiskAssets;
            struct FAssetData ReturnValue;
	} params{ ObjectPath, bIncludeOnlyOnDiskAssets };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistry:GetAssetByObjectPath");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UAssetRegistry::GetAllCachedPaths(TArray<struct FString> OutPathList)
{
	struct {
            TArray<struct FString> OutPathList;
	} params{ OutPathList };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistry:GetAllCachedPaths");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UAssetRegistry::GetAllAssets(TArray<struct FAssetData> OutAssetData, bool bIncludeOnlyOnDiskAssets)
{
	struct {
            TArray<struct FAssetData> OutAssetData;
            bool bIncludeOnlyOnDiskAssets;
            bool ReturnValue;
	} params{ OutAssetData, bIncludeOnlyOnDiskAssets };

    static auto fn = UObject::FindObject("/Script/AssetRegistry.AssetRegistry:GetAllAssets");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

