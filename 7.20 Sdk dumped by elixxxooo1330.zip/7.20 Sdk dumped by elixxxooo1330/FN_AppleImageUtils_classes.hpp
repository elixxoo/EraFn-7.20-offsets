#pragma once

#include "../SDK.hpp"

namespace SDK {


class UAppleImageUtilsBaseAsyncTaskBlueprintProxy : public UObject
{
	public:
	    char UnknownData0[0x8];
	    MulticastDelegateProperty OnSuccess; // 0x30 Size: 0x10
	    MulticastDelegateProperty OnFailure; // 0x40 Size: 0x10
	    char UnknownData1[0x10]; // 0x50
	    struct FAppleImageUtilsImageConversionResult ConversionResult; // 0x60 Size: 0x20
	    char UnknownData2[0x80]; // 0x80
	    static class UAppleImageUtilsBaseAsyncTaskBlueprintProxy* CreateProxyObjectForConvertToTIFF(class UTexture* SourceImage, bool bWantColor, bool bUseGpu, float Scale, ETextureRotationDirection Rotate); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static class UAppleImageUtilsBaseAsyncTaskBlueprintProxy* CreateProxyObjectForConvertToPNG(class UTexture* SourceImage, bool bWantColor, bool bUseGpu, float Scale, ETextureRotationDirection Rotate); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static class UAppleImageUtilsBaseAsyncTaskBlueprintProxy* CreateProxyObjectForConvertToJPEG(class UTexture* SourceImage, int Quality, bool bWantColor, bool bUseGpu, float Scale, ETextureRotationDirection Rotate); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static class UAppleImageUtilsBaseAsyncTaskBlueprintProxy* CreateProxyObjectForConvertToHEIF(class UTexture* SourceImage, int Quality, bool bWantColor, bool bUseGpu, float Scale, ETextureRotationDirection Rotate); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7f59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AppleImageUtils.AppleImageUtilsBaseAsyncTaskBlueprintProxy");
			return (class UClass*)ptr;
		};

};

class UAppleImageInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AppleImageUtils.AppleImageInterface");
			return (class UClass*)ptr;
		};

};


}