#pragma once

#include "../SDK.hpp"

namespace SDK {


class UProceduralFoliageComponent : public UActorComponent
{
	public:
	    class UProceduralFoliageSpawner* FoliageSpawner; // 0xf8 Size: 0x8
	    float TileOverlap; // 0x100 Size: 0x4
	    char UnknownData0[0x4]; // 0x104
	    class AVolume* SpawningVolume; // 0x108 Size: 0x8
	    struct FGuid ProceduralGuid; // 0x110 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Foliage.ProceduralFoliageComponent");
			return (class UClass*)ptr;
		};

};

class UFoliageInstancedStaticMeshComponent : public UHierarchicalInstancedStaticMeshComponent
{
	public:
	    MulticastDelegateProperty OnInstanceTakePointDamage; // 0x788 Size: 0x10
	    MulticastDelegateProperty OnInstanceTakeRadialDamage; // 0x798 Size: 0x10
	    char UnknownData0[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Foliage.FoliageInstancedStaticMeshComponent");
			return (class UClass*)ptr;
		};

};

class UFoliageStatistics : public UBlueprintFunctionLibrary
{
	public:
	    static int FoliageOverlappingSphereCount(class UObject* WorldContextObject, class UStaticMesh* StaticMesh, struct FVector CenterPosition, float Radius); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static int FoliageOverlappingBoxCount(class UObject* WorldContextObject, class UStaticMesh* StaticMesh, struct FBox Box); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Foliage.FoliageStatistics");
			return (class UClass*)ptr;
		};

};

class UFoliageType : public UObject
{
	public:
	    struct FGuid UpdateGuid; // 0x28 Size: 0x10
	    float Density; // 0x38 Size: 0x4
	    float DensityAdjustmentFactor; // 0x3c Size: 0x4
	    float Radius; // 0x40 Size: 0x4
	    EFoliageScaling Scaling; // 0x44 Size: 0x1
	    char UnknownData0[0x3]; // 0x45
	    struct FFloatInterval ScaleX; // 0x48 Size: 0x8
	    struct FFloatInterval ScaleY; // 0x50 Size: 0x8
	    struct FFloatInterval ScaleZ; // 0x58 Size: 0x8
	    struct FFoliageVertexColorChannelMask* VertexColorMaskByChannel; // 0x60 Size: 0xc
	    char UnknownData1[0x24]; // 0x6c
	    char VertexColorMask; // 0x90 Size: 0x1
	    char UnknownData2[0x3]; // 0x91
	    float VertexColorMaskThreshold; // 0x94 Size: 0x4
	    bool VertexColorMaskInvert; // 0x98 Size: 0x1
	    char UnknownData3[0x3]; // 0x99
	    struct FFloatInterval ZOffset; // 0x9c Size: 0x8
	    bool AlignToNormal; // 0xa4 Size: 0x1
	    char UnknownData4[0x3]; // 0xa5
	    float AlignMaxAngle; // 0xa8 Size: 0x4
	    bool RandomYaw; // 0xac Size: 0x1
	    char UnknownData5[0x3]; // 0xad
	    float RandomPitchAngle; // 0xb0 Size: 0x4
	    struct FFloatInterval GroundSlopeAngle; // 0xb4 Size: 0x8
	    struct FFloatInterval Height; // 0xbc Size: 0x8
	    char UnknownData6[0x4]; // 0xc4
	    TArray<FName> LandscapeLayers; // 0xc8 Size: 0x10
	    FName LandscapeLayer; // 0xd8 Size: 0x8
	    bool CollisionWithWorld; // 0xe0 Size: 0x1
	    char UnknownData7[0x3]; // 0xe1
	    struct FVector CollisionScale; // 0xe4 Size: 0xc
	    float MinimumLayerWeight; // 0xf0 Size: 0x4
	    struct FBoxSphereBounds MeshBounds; // 0xf4 Size: 0x1c
	    struct FVector LowBoundOriginRadius; // 0x110 Size: 0xc
	    char Mobility; // 0x11c Size: 0x1
	    char UnknownData8[0x3]; // 0x11d
	    struct FInt32Interval CullDistance; // 0x120 Size: 0x8
	    bool bEnableStaticLighting; // 0x128 Size: 0x1
	    bool CastShadow; // 0x128 Size: 0x1
	    bool bAffectDynamicIndirectLighting; // 0x128 Size: 0x1
	    bool bAffectDistanceFieldLighting; // 0x128 Size: 0x1
	    bool bCastDynamicShadow; // 0x128 Size: 0x1
	    bool bCastStaticShadow; // 0x128 Size: 0x1
	    bool bCastShadowAsTwoSided; // 0x128 Size: 0x1
	    bool bReceivesDecals; // 0x128 Size: 0x1
	    bool bOverrideLightMapRes; // 0x129 Size: 0x1
	    char UnknownData9[0x5]; // 0x131
	    int OverriddenLightMapRes; // 0x12c Size: 0x4
	    ELightmapType LightmapType; // 0x130 Size: 0x1
	    bool bUseAsOccluder; // 0x134 Size: 0x1
	    char UnknownData10[0x6]; // 0x132
	    struct FBodyInstance BodyInstance; // 0x138 Size: 0x150
	    char CustomNavigableGeometry; // 0x288 Size: 0x1
	    struct FLightingChannels LightingChannels; // 0x289 Size: 0x1
	    bool bRenderCustomDepth; // 0x28c Size: 0x1
	    char UnknownData11[0x5]; // 0x28b
	    int CustomDepthStencilValue; // 0x290 Size: 0x4
	    float CollisionRadius; // 0x294 Size: 0x4
	    float ShadeRadius; // 0x298 Size: 0x4
	    int NumSteps; // 0x29c Size: 0x4
	    float InitialSeedDensity; // 0x2a0 Size: 0x4
	    float AverageSpreadDistance; // 0x2a4 Size: 0x4
	    float SpreadVariance; // 0x2a8 Size: 0x4
	    int SeedsPerStep; // 0x2ac Size: 0x4
	    int DistributionSeed; // 0x2b0 Size: 0x4
	    float MaxInitialSeedOffset; // 0x2b4 Size: 0x4
	    bool bCanGrowInShade; // 0x2b8 Size: 0x1
	    bool bSpawnsInShade; // 0x2b9 Size: 0x1
	    char UnknownData12[0x2]; // 0x2ba
	    float MaxInitialAge; // 0x2bc Size: 0x4
	    float MaxAge; // 0x2c0 Size: 0x4
	    float OverlapPriority; // 0x2c4 Size: 0x4
	    struct FFloatInterval ProceduralScale; // 0x2c8 Size: 0x8
	    struct FRuntimeFloatCurve ScaleCurve; // 0x2d0 Size: 0x88
	    int ChangeCount; // 0x358 Size: 0x4
	    bool ReapplyDensity; // 0x35c Size: 0x1
	    bool ReapplyRadius; // 0x35c Size: 0x1
	    bool ReapplyAlignToNormal; // 0x35c Size: 0x1
	    bool ReapplyRandomYaw; // 0x35c Size: 0x1
	    bool ReapplyScaling; // 0x35c Size: 0x1
	    bool ReapplyScaleX; // 0x35c Size: 0x1
	    bool ReapplyScaleY; // 0x35c Size: 0x1
	    bool ReapplyScaleZ; // 0x35c Size: 0x1
	    bool ReapplyRandomPitchAngle; // 0x35d Size: 0x1
	    bool ReapplyGroundSlope; // 0x35d Size: 0x1
	    bool ReapplyHeight; // 0x35d Size: 0x1
	    bool ReapplyLandscapeLayers; // 0x35d Size: 0x1
	    bool ReapplyZOffset; // 0x35d Size: 0x1
	    bool ReapplyCollisionWithWorld; // 0x35d Size: 0x1
	    bool ReapplyVertexColorMask; // 0x35d Size: 0x1
	    bool bEnableDensityScaling; // 0x35d Size: 0x1
	    char UnknownData13[0x-c];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Foliage.FoliageType");
			return (class UClass*)ptr;
		};

};

class UFoliageType_InstancedStaticMesh : public UFoliageType
{
	public:
	    class UStaticMesh* Mesh; // 0x360 Size: 0x8
	    TArray<class UMaterialInterface*> OverrideMaterials; // 0x368 Size: 0x10
	    class UFoliageInstancedStaticMeshComponent* ComponentClass; // 0x378 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Foliage.FoliageType_InstancedStaticMesh");
			return (class UClass*)ptr;
		};

};

class AInstancedFoliageActor : public AActor
{
	public:
	    char UnknownData0[0x380];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Foliage.InstancedFoliageActor");
			return (class UClass*)ptr;
		};

};

class AInteractiveFoliageActor : public AStaticMeshActor
{
	public:
	    class UCapsuleComponent* CapsuleComponent; // 0x340 Size: 0x8
	    struct FVector TouchingActorEntryPosition; // 0x348 Size: 0xc
	    struct FVector FoliageVelocity; // 0x354 Size: 0xc
	    struct FVector FoliageForce; // 0x360 Size: 0xc
	    struct FVector FoliagePosition; // 0x36c Size: 0xc
	    float FoliageDamageImpulseScale; // 0x378 Size: 0x4
	    float FoliageTouchImpulseScale; // 0x37c Size: 0x4
	    float FoliageStiffness; // 0x380 Size: 0x4
	    float FoliageStiffnessQuadratic; // 0x384 Size: 0x4
	    float FoliageDamping; // 0x388 Size: 0x4
	    float MaxDamageImpulse; // 0x38c Size: 0x4
	    float MaxTouchImpulse; // 0x390 Size: 0x4
	    float MaxForce; // 0x394 Size: 0x4
	    float Mass; // 0x398 Size: 0x4
	    char UnknownData0[0x39c]; // 0x39c
	    void CapsuleTouched(class UPrimitiveComponent* OverlappedComp, class AActor* Other, class UPrimitiveComponent* OtherComp, int OtherBodyIndex, bool bFromSweep, struct FHitResult OverlapInfo); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7c41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Foliage.InteractiveFoliageActor");
			return (class UClass*)ptr;
		};

};

class UInteractiveFoliageComponent : public UStaticMeshComponent
{
	public:
	    char UnknownData0[0x610];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Foliage.InteractiveFoliageComponent");
			return (class UClass*)ptr;
		};

};

class AProceduralFoliageBlockingVolume : public AVolume
{
	public:
	    class AProceduralFoliageVolume* ProceduralFoliageVolume; // 0x368 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Foliage.ProceduralFoliageBlockingVolume");
			return (class UClass*)ptr;
		};

};

class UProceduralFoliageSpawner : public UObject
{
	public:
	    int RandomSeed; // 0x28 Size: 0x4
	    float TileSize; // 0x2c Size: 0x4
	    int NumUniqueTiles; // 0x30 Size: 0x4
	    float MinimumQuadTreeSize; // 0x34 Size: 0x4
	    char UnknownData0[0x8]; // 0x38
	    TArray<struct FFoliageTypeObject> FoliageTypes; // 0x40 Size: 0x10
	    bool bNeedsSimulation; // 0x50 Size: 0x1
	    char UnknownData1[0x51]; // 0x51
	    void Simulate(int NumSteps); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Foliage.ProceduralFoliageSpawner");
			return (class UClass*)ptr;
		};

};

class UProceduralFoliageTile : public UObject
{
	public:
	    class UProceduralFoliageSpawner* FoliageSpawner; // 0x28 Size: 0x8
	    char UnknownData0[0xa0]; // 0x30
	    TArray<struct FProceduralFoliageInstance> InstancesArray; // 0xd0 Size: 0x10
	    char UnknownData1[0x78];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Foliage.ProceduralFoliageTile");
			return (class UClass*)ptr;
		};

};

class AProceduralFoliageVolume : public AVolume
{
	public:
	    class UProceduralFoliageComponent* ProceduralComponent; // 0x368 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Foliage.ProceduralFoliageVolume");
			return (class UClass*)ptr;
		};

};


}