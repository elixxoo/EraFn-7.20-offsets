#pragma once

#include "../SDK.hpp"

namespace SDK {


class UMaterialShaderQualitySettings : public UObject
{
	public:
	    __int64/*MapProperty*/ ForwardSettingMap; // 0x28 Size: 0x50

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MaterialShaderQualitySettings.MaterialShaderQualitySettings");
			return (class UClass*)ptr;
		};

};

class UShaderPlatformQualitySettings : public UObject
{
	public:
	    struct FMaterialQualityOverrides* QualityOverrides; // 0x28 Size: 0x8
	    char UnknownData0[0x20];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MaterialShaderQualitySettings.ShaderPlatformQualitySettings");
			return (class UClass*)ptr;
		};

};


}