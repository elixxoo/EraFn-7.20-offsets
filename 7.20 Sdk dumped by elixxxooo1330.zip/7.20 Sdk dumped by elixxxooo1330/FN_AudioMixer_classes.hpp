#pragma once

#include "../SDK.hpp"

namespace SDK {


class USynthComponent : public USceneComponent
{
	public:
	    bool bAutoDestroy; // 0x248 Size: 0x1
	    bool bStopWhenOwnerDestroyed; // 0x248 Size: 0x1
	    bool bAllowSpatialization; // 0x248 Size: 0x1
	    bool bOverrideAttenuation; // 0x248 Size: 0x1
	    bool bOutputToBusOnly; // 0x24c Size: 0x1
	    char UnknownData0[0x3]; // 0x24d
	    class USoundAttenuation* AttenuationSettings; // 0x250 Size: 0x8
	    struct FSoundAttenuationSettings AttenuationOverrides; // 0x258 Size: 0x2e8
	    class USoundConcurrency* ConcurrencySettings; // 0x540 Size: 0x8
	    class USoundClass* SoundClass; // 0x548 Size: 0x8
	    class USoundEffectSourcePresetChain* SourceEffectChain; // 0x550 Size: 0x8
	    class USoundSubmix* SoundSubmix; // 0x558 Size: 0x8
	    TArray<struct FSoundSubmixSendInfo> SoundSubmixSends; // 0x560 Size: 0x10
	    TArray<struct FSoundSourceBusSendInfo> BusSends; // 0x570 Size: 0x10
	    TArray<struct FSoundSourceBusSendInfo> PreEffectBusSends; // 0x580 Size: 0x10
	    bool bIsUISound; // 0x590 Size: 0x1
	    bool bIsPreviewSound; // 0x590 Size: 0x1
	    char UnknownData1[0x2]; // 0x592
	    int EnvelopeFollowerAttackTime; // 0x594 Size: 0x4
	    int EnvelopeFollowerReleaseTime; // 0x598 Size: 0x4
	    char UnknownData2[0x4]; // 0x59c
	    MulticastDelegateProperty OnAudioEnvelopeValue; // 0x5a0 Size: 0x10
	    char UnknownData3[0x20]; // 0x5b0
	    class USynthSound* Synth; // 0x5d0 Size: 0x8
	    class UAudioComponent* AudioComponent; // 0x5d8 Size: 0x8
	    char UnknownData4[0x5e0]; // 0x5e0
	    void Stop(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void Start(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetVolumeMultiplier(float VolumeMultiplier); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetSubmixSend(class USoundSubmix* Submix, float SendLevel); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool IsPlaying(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-79d1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AudioMixer.SynthComponent");
			return (class UClass*)ptr;
		};

};

class UAudioMixerBlueprintLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static class USoundWave* StopRecordingOutput(class UObject* WorldContextObject, EAudioRecordingExportType ExportType, struct FString Name, struct FString Path, class USoundSubmix* SubmixToRecord, class USoundWave* ExistingSoundWaveToOverwrite); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void StartRecordingOutput(class UObject* WorldContextObject, float ExpectedDuration, class USoundSubmix* SubmixToRecord); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static void SetBypassSourceEffectChainEntry(class UObject* WorldContextObject, class USoundEffectSourcePresetChain* PresetChain, int EntryIndex, bool bBypassed); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static void ResumeRecordingOutput(class UObject* WorldContextObject, class USoundSubmix* SubmixToPause); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static void RemoveSourceEffectFromPresetChain(class UObject* WorldContextObject, class USoundEffectSourcePresetChain* PresetChain, int EntryIndex); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static void RemoveMasterSubmixEffect(class UObject* WorldContextObject, class USoundEffectSubmixPreset* SubmixEffectPreset); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static void PauseRecordingOutput(class UObject* WorldContextObject, class USoundSubmix* SubmixToPause); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static int GetNumberOfEntriesInSourceEffectChain(class UObject* WorldContextObject, class USoundEffectSourcePresetChain* PresetChain); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static void ClearMasterSubmixEffects(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static void AddSourceEffectToPresetChain(class UObject* WorldContextObject, class USoundEffectSourcePresetChain* PresetChain, struct FSourceEffectChainEntry Entry); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static void AddMasterSubmixEffect(class UObject* WorldContextObject, class USoundEffectSubmixPreset* SubmixEffectPreset); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AudioMixer.AudioMixerBlueprintLibrary");
			return (class UClass*)ptr;
		};

};

class USubmixEffectDynamicsProcessorPreset : public USoundEffectSubmixPreset
{
	public:
	    char UnknownData0[0x50];
	    struct FSubmixEffectDynamicsProcessorSettings Settings; // 0x90 Size: 0x28
	    char UnknownData1[0xb8]; // 0xb8
	    void SetSettings(struct FSubmixEffectDynamicsProcessorSettings InSettings); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AudioMixer.SubmixEffectDynamicsProcessorPreset");
			return (class UClass*)ptr;
		};

};

class USubmixEffectSubmixEQPreset : public USoundEffectSubmixPreset
{
	public:
	    char UnknownData0[0x38];
	    struct FSubmixEffectSubmixEQSettings Settings; // 0x78 Size: 0x10
	    char UnknownData1[0x88]; // 0x88
	    void SetSettings(struct FSubmixEffectSubmixEQSettings InSettings); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AudioMixer.SubmixEffectSubmixEQPreset");
			return (class UClass*)ptr;
		};

};

class USubmixEffectReverbPreset : public USoundEffectSubmixPreset
{
	public:
	    char UnknownData0[0x5c];
	    struct FSubmixEffectReverbSettings Settings; // 0x9c Size: 0x34
	    char UnknownData1[0xd0]; // 0xd0
	    void SetSettingsWithReverbEffect(class UReverbEffect* InReverbEffect, float WetLevel, float DryLevel); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetSettings(struct FSubmixEffectReverbSettings InSettings); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7f11];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AudioMixer.SubmixEffectReverbPreset");
			return (class UClass*)ptr;
		};

};

class USynthSound : public USoundWaveProcedural
{
	public:
	    char UnknownData0[0x280];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AudioMixer.SynthSound");
			return (class UClass*)ptr;
		};

};


}