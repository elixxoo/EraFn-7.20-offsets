#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FSessionServiceLogUnsubscribe
{
	public:
	    char UnknownData0[0x1];

};

struct FSessionServiceLogSubscribe
{
	public:
	    char UnknownData0[0x1];

};

struct FSessionServiceLog
{
	public:
	    FName Category; // 0x0 Size: 0x8
	    struct FString Data; // 0x8 Size: 0x10
	    struct FGuid InstanceId; // 0x18 Size: 0x10
	    double TimeSeconds; // 0x28 Size: 0x8
	    char Verbosity; // 0x30 Size: 0x1
	    char UnknownData0[0x7];

};

struct FSessionServicePong
{
	public:
	    bool Authorized; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FString BuildDate; // 0x8 Size: 0x10
	    struct FString DeviceName; // 0x18 Size: 0x10
	    struct FGuid InstanceId; // 0x28 Size: 0x10
	    struct FString InstanceName; // 0x38 Size: 0x10
	    bool IsConsoleBuild; // 0x48 Size: 0x1
	    char UnknownData1[0x7]; // 0x49
	    struct FString PlatformName; // 0x50 Size: 0x10
	    struct FGuid SessionId; // 0x60 Size: 0x10
	    struct FString SessionName; // 0x70 Size: 0x10
	    struct FString SessionOwner; // 0x80 Size: 0x10
	    bool Standalone; // 0x90 Size: 0x1
	    char UnknownData2[0x7];

};

struct FSessionServicePing
{
	public:
	    struct FString UserName; // 0x0 Size: 0x10

};


}