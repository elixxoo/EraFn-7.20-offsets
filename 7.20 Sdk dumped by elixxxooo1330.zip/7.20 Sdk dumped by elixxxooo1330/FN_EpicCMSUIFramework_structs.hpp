#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FonLoadingCompleted__DelegateSignature
{
	public:

};

struct FOnCMSTileConfirmed__DelegateSignature
{
	public:
	    bool bSuccess; // 0x0 Size: 0x1

};



enum class EDateType : uint8_t
{
    None = 0,
    Coming = 1,
    Ending = 2,
    EDateType_MAX = 3
};struct FSlotDescription
{
	public:
	    FName SlotName; // 0x0 Size: 0x8
	    int ColumnCount; // 0x8 Size: 0x4
	    int RowCount; // 0xc Size: 0x4
	    bool bUseFeaturedTextStyle; // 0x10 Size: 0x1
	    bool bEnableAutoScroll; // 0x11 Size: 0x1
	    char UnknownData0[0x2];

};

struct FEpicCMSTileTypeMapping : public FTableRowBase
{
	public:
	    __int64/*SoftClassProperty*/ TileClass; // 0x8 Size: 0x28

};

struct FEpicCMSLayoutTypeMapping : public FTableRowBase
{
	public:
	    __int64/*SoftClassProperty*/ LayoutType; // 0x8 Size: 0x28

};

struct FTileDefinition
{
	public:
	    struct FString TypeString; // 0x0 Size: 0x10
	    struct FString Title; // 0x10 Size: 0x10
	    struct FString Subtitle; // 0x20 Size: 0x10
	    struct FString Eyebrow; // 0x30 Size: 0x10
	    struct FString Link; // 0x40 Size: 0x10
	    struct FString GroupID; // 0x50 Size: 0x10
	    struct FDateTime Countdown; // 0x60 Size: 0x8
	    EDateType CountdownType; // 0x68 Size: 0x1
	    char UnknownData0[0x7]; // 0x69
	    struct FString MediaUrl; // 0x70 Size: 0x10
	    bool IsVisible; // 0x80 Size: 0x1
	    char UnknownData1[0x7];

};


}