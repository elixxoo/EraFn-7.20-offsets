#include "../SDK.hpp"

float UMovieSceneEasingFunction::OnEvaluate(float Interp)
{
	struct {
            float Interp;
            float ReturnValue;
	} params{ Interp };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneEasingFunction:OnEvaluate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UMovieSceneSequencePlayer::StopAtCurrentTime()
{
    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:StopAtCurrentTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UMovieSceneSequencePlayer::Stop()
{
    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:Stop");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UMovieSceneSequencePlayer::SetTimeRange(float StartTime, float Duration)
{
	struct {
            float StartTime;
            float Duration;
	} params{ StartTime, Duration };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:SetTimeRange");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMovieSceneSequencePlayer::SetPlayRate(float PlayRate)
{
	struct {
            float PlayRate;
	} params{ PlayRate };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:SetPlayRate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMovieSceneSequencePlayer::SetPlaybackRange(float NewStartTime, float NewEndTime)
{
	struct {
            float NewStartTime;
            float NewEndTime;
	} params{ NewStartTime, NewEndTime };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:SetPlaybackRange");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMovieSceneSequencePlayer::SetPlaybackPosition(float NewPlaybackPosition)
{
	struct {
            float NewPlaybackPosition;
	} params{ NewPlaybackPosition };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:SetPlaybackPosition");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMovieSceneSequencePlayer::SetFrameRate(struct FFrameRate FrameRate)
{
	struct {
            struct FFrameRate FrameRate;
	} params{ FrameRate };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:SetFrameRate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMovieSceneSequencePlayer::SetFrameRange(int StartFrame, int Duration)
{
	struct {
            int StartFrame;
            int Duration;
	} params{ StartFrame, Duration };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:SetFrameRange");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMovieSceneSequencePlayer::SetDisableCameraCuts(bool bInDisableCameraCuts)
{
	struct {
            bool bInDisableCameraCuts;
	} params{ bInDisableCameraCuts };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:SetDisableCameraCuts");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMovieSceneSequencePlayer::ScrubToSeconds(float TimeInSeconds)
{
	struct {
            float TimeInSeconds;
	} params{ TimeInSeconds };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:ScrubToSeconds");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMovieSceneSequencePlayer::ScrubToFrame(struct FFrameTime NewPosition)
{
	struct {
            struct FFrameTime NewPosition;
	} params{ NewPosition };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:ScrubToFrame");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMovieSceneSequencePlayer::Scrub()
{
    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:Scrub");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UMovieSceneSequencePlayer::RPC_OnStopEvent(struct FFrameTime StoppedTime)
{
	struct {
            struct FFrameTime StoppedTime;
	} params{ StoppedTime };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:RPC_OnStopEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMovieSceneSequencePlayer::RPC_ExplicitServerUpdateEvent(EUpdatePositionMethod Method, struct FFrameTime RelevantTime)
{
	struct {
            EUpdatePositionMethod Method;
            struct FFrameTime RelevantTime;
	} params{ Method, RelevantTime };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:RPC_ExplicitServerUpdateEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMovieSceneSequencePlayer::PlayToSeconds(float TimeInSeconds)
{
	struct {
            float TimeInSeconds;
	} params{ TimeInSeconds };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:PlayToSeconds");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMovieSceneSequencePlayer::PlayToFrame(struct FFrameTime NewPosition)
{
	struct {
            struct FFrameTime NewPosition;
	} params{ NewPosition };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:PlayToFrame");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMovieSceneSequencePlayer::PlayReverse()
{
    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:PlayReverse");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UMovieSceneSequencePlayer::PlayLooping(int NumLoops)
{
	struct {
            int NumLoops;
	} params{ NumLoops };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:PlayLooping");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMovieSceneSequencePlayer::Play()
{
    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:Play");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UMovieSceneSequencePlayer::Pause()
{
    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:Pause");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UMovieSceneSequencePlayer::JumpToSeconds(float TimeInSeconds)
{
	struct {
            float TimeInSeconds;
	} params{ TimeInSeconds };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:JumpToSeconds");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMovieSceneSequencePlayer::JumpToPosition(float NewPlaybackPosition)
{
	struct {
            float NewPlaybackPosition;
	} params{ NewPlaybackPosition };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:JumpToPosition");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMovieSceneSequencePlayer::JumpToFrame(struct FFrameTime NewPosition)
{
	struct {
            struct FFrameTime NewPosition;
	} params{ NewPosition };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:JumpToFrame");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UMovieSceneSequencePlayer::IsReversed()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:IsReversed");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UMovieSceneSequencePlayer::IsPlaying()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:IsPlaying");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UMovieSceneSequencePlayer::IsPaused()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:IsPaused");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UMovieSceneSequencePlayer::GoToEndAndStop()
{
    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:GoToEndAndStop");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


struct FQualifiedFrameTime UMovieSceneSequencePlayer::GetStartTime()
{
	struct {
            struct FQualifiedFrameTime ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:GetStartTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UMovieSceneSequencePlayer::GetPlayRate()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:GetPlayRate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UMovieSceneSequencePlayer::GetPlaybackStart()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:GetPlaybackStart");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UMovieSceneSequencePlayer::GetPlaybackPosition()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:GetPlaybackPosition");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UMovieSceneSequencePlayer::GetPlaybackEnd()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:GetPlaybackEnd");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


TArray<struct FMovieSceneObjectBindingID> UMovieSceneSequencePlayer::GetObjectBindings(class UObject* InObject)
{
	struct {
            class UObject* InObject;
            TArray<struct FMovieSceneObjectBindingID> ReturnValue;
	} params{ InObject };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:GetObjectBindings");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


float UMovieSceneSequencePlayer::GetLength()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:GetLength");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FFrameRate UMovieSceneSequencePlayer::GetFrameRate()
{
	struct {
            struct FFrameRate ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:GetFrameRate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


int UMovieSceneSequencePlayer::GetFrameDuration()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:GetFrameDuration");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FQualifiedFrameTime UMovieSceneSequencePlayer::GetEndTime()
{
	struct {
            struct FQualifiedFrameTime ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:GetEndTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FQualifiedFrameTime UMovieSceneSequencePlayer::GetDuration()
{
	struct {
            struct FQualifiedFrameTime ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:GetDuration");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UMovieSceneSequencePlayer::GetDisableCameraCuts()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:GetDisableCameraCuts");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FQualifiedFrameTime UMovieSceneSequencePlayer::GetCurrentTime()
{
	struct {
            struct FQualifiedFrameTime ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:GetCurrentTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


TArray<class UObject*> UMovieSceneSequencePlayer::GetBoundObjects(struct FMovieSceneObjectBindingID ObjectBinding)
{
	struct {
            struct FMovieSceneObjectBindingID ObjectBinding;
            TArray<class UObject*> ReturnValue;
	} params{ ObjectBinding };

    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:GetBoundObjects");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UMovieSceneSequencePlayer::ChangePlaybackDirection()
{
    static auto fn = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer:ChangePlaybackDirection");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

