#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FControlRigSignature__DelegateSignature
{
	public:
	    class UControlRigComponent* Component; // 0x0 Size: 0x8

};



enum class ERigExecutionType : uint8_t
{
    Runtime = 0,
    Editing = 1,
    Max = 2
};

enum class EControlRigOpCode : uint8_t
{
    Done = 0,
    Copy = 1,
    Exec = 2,
    Invalid = 3,
    EControlRigOpCode_MAX = 4
};

enum class ETransformGetterType : uint8_t
{
    Initial = 0,
    Current = 1,
    Max = 2
};

enum class ETransformSpaceMode : uint8_t
{
    LocalSpace = 0,
    GlobalSpace = 1,
    BaseSpace = 2,
    BaseJoint = 3,
    Max = 4
};

enum class EUnitExecutionType : uint8_t
{
    Always = 0,
    InEditingTime = 1,
    Disable = 2,
    Max = 3
};

enum class EAimMode : uint8_t
{
    AimAtTarget = 0,
    OrientToTarget = 1,
    MAX = 2
};

enum class EApplyTransformMode : uint8_t
{
    Override = 0,
    Additive = 1,
    Max = 2
};

enum class EControlRigState : uint8_t
{
    Init = 0,
    Update = 1,
    Invalid = 2,
    EControlRigState_MAX = 3
};struct FAnimNode_ControlRig : public FAnimNode_ControlRigBase
{
	public:
	    struct FPoseLink Source; // 0x28 Size: 0x10
	    class UControlRig* ControlRigClass; // 0x38 Size: 0x8
	    class UControlRig* ControlRig; // 0x40 Size: 0x8

};

struct FAnimNode_ControlRig_ExternalSource : public FAnimNode_ControlRigBase
{
	public:
	    TWeakObjectPtr<UControlRig*> ControlRig; // 0x28 Size: 0x8

};

struct FControlRigBindingTemplate : public FMovieSceneSpawnSectionTemplate
{
	public:
	    char UnknownData0[0xb0];

};

struct FControlRigOperator
{
	public:
	    EControlRigOpCode OpCode; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FString PropertyPath1; // 0x8 Size: 0x10
	    struct FString PropertyPath2; // 0x18 Size: 0x10

};

struct FControlRigSequenceObjectReference
{
	public:
	    class UControlRig* ControlRigClass; // 0x0 Size: 0x8

};

struct FControlRigSequencerAnimInstanceProxy : public FAnimSequencerInstanceProxy
{
	public:
	    char UnknownData0[0xa30];

};

struct FRigHierarchyRef
{
	public:
	    bool bUseBaseHierarchy; // 0x8 Size: 0x1
	    char UnknownData0[0x3]; // 0x9
	    FName Name; // 0xc Size: 0x8
	    char UnknownData1[0x4];

};

struct FRigUnit
{
	public:
	    FName RigUnitName; // 0x8 Size: 0x8
	    FName RigUnitStructName; // 0x10 Size: 0x8
	    EUnitExecutionType ExecutionType; // 0x18 Size: 0x1
	    char UnknownData0[0x7];

};

struct FAimTarget
{
	public:
	    float Weight; // 0x0 Size: 0x4
	    char UnknownData0[0xc]; // 0x4
	    struct FTransform Transform; // 0x10 Size: 0x30
	    struct FVector AlignVector; // 0x40 Size: 0xc
	    char UnknownData1[0x4];

};

struct FRigUnit_ApplyFK : public FRigUnit
{
	public:
	    struct FRigHierarchyRef HierarchyRef; // 0x20 Size: 0x18
	    FName Joint; // 0x38 Size: 0x8
	    struct FTransform Transform; // 0x40 Size: 0x30
	    struct FTransformFilter Filter; // 0x70 Size: 0x9
	    EApplyTransformMode ApplyTransformMode; // 0x79 Size: 0x1
	    ETransformSpaceMode ApplyTransformSpace; // 0x7a Size: 0x1
	    char UnknownData0[0x5]; // 0x7b
	    struct FTransform BaseTransform; // 0x80 Size: 0x30
	    FName BaseJoint; // 0xb0 Size: 0x8
	    char UnknownData1[0x8];

};

struct FBlendTarget
{
	public:
	    struct FTransform Transform; // 0x0 Size: 0x30
	    float Weight; // 0x30 Size: 0x4
	    char UnknownData0[0xc];

};

struct FRigUnit_Control : public FRigUnit
{
	public:
	    struct FEulerTransform Transform; // 0x20 Size: 0x24
	    char UnknownData0[0xc]; // 0x44
	    struct FTransform Base; // 0x50 Size: 0x30
	    struct FTransform InitTransform; // 0x80 Size: 0x30
	    struct FTransform Result; // 0xb0 Size: 0x30
	    struct FTransformFilter Filter; // 0xe0 Size: 0x9
	    char UnknownData1[0x7];

};

struct FRigUnit_Control_StaticMesh : public FRigUnit_Control
{
	public:
	    char UnknownData0[0xf0];

};

struct FRigUnit_ToSwingAndTwist : public FRigUnit
{
	public:
	    struct FQuat Input; // 0x20 Size: 0x10
	    struct FVector TwistAxis; // 0x30 Size: 0xc
	    char UnknownData0[0x4]; // 0x3c
	    struct FQuat Swing; // 0x40 Size: 0x10
	    struct FQuat Twist; // 0x50 Size: 0x10

};

struct FRigUnit_ConvertQuaternionToVector : public FRigUnit
{
	public:
	    struct FQuat Input; // 0x20 Size: 0x10
	    struct FVector Result; // 0x30 Size: 0xc
	    char UnknownData0[0x4];

};

struct FRigUnit_ConvertRotationToVector : public FRigUnit
{
	public:
	    struct FRotator Input; // 0x20 Size: 0xc
	    struct FVector Result; // 0x2c Size: 0xc

};

struct FRigUnit_ConvertVectorToQuaternion : public FRigUnit
{
	public:
	    struct FVector Input; // 0x20 Size: 0xc
	    char UnknownData0[0x4]; // 0x2c
	    struct FQuat Result; // 0x30 Size: 0x10

};

struct FRigUnit_ConvertVectorToRotation : public FRigUnit
{
	public:
	    struct FVector Input; // 0x20 Size: 0xc
	    struct FRotator Result; // 0x2c Size: 0xc

};

struct FRigUnit_ConvertQuaternion : public FRigUnit
{
	public:
	    struct FQuat Input; // 0x20 Size: 0x10
	    struct FRotator Result; // 0x30 Size: 0xc
	    char UnknownData0[0x4];

};

struct FRigUnit_ConvertRotation : public FRigUnit
{
	public:
	    struct FRotator Input; // 0x20 Size: 0xc
	    char UnknownData0[0x4]; // 0x2c
	    struct FQuat Result; // 0x30 Size: 0x10

};

struct FRigUnit_ConvertEulerTransform : public FRigUnit
{
	public:
	    struct FEulerTransform Input; // 0x20 Size: 0x24
	    char UnknownData0[0xc]; // 0x44
	    struct FTransform Result; // 0x50 Size: 0x30

};

struct FRigUnit_ConvertTransform : public FRigUnit
{
	public:
	    struct FTransform Input; // 0x20 Size: 0x30
	    struct FEulerTransform Result; // 0x50 Size: 0x24
	    char UnknownData0[0xc];

};

struct FRigUnit_CreateHierarchy : public FRigUnit
{
	public:
	    struct FRigHierarchyRef NewHierarchy; // 0x20 Size: 0x18
	    struct FRigHierarchyRef SourceHierarchy; // 0x38 Size: 0x18
	    FName Root; // 0x50 Size: 0x8

};

struct FStructReference
{
	public:
	    char UnknownData0[0x8];

};

struct FRigUnitReference_Example : public FStructReference
{
	public:
	    char UnknownData0[0x8];

};

struct FRigUnit_FABRIK : public FRigUnit
{
	public:
	    struct FRigHierarchyRef HierarchyRef; // 0x20 Size: 0x18
	    FName StartJoint; // 0x38 Size: 0x8
	    FName EndJoint; // 0x40 Size: 0x8
	    float Precision; // 0x48 Size: 0x4
	    int MaxIterations; // 0x4c Size: 0x4
	    char UnknownData0[0x18];

};

struct FRigUnit_Clamp_Float : public FRigUnit
{
	public:
	    float Value; // 0x20 Size: 0x4
	    float Min; // 0x24 Size: 0x4
	    float Max; // 0x28 Size: 0x4
	    float Result; // 0x2c Size: 0x4

};

struct FRigUnit_BinaryFloatOp : public FRigUnit
{
	public:
	    float Argument0; // 0x20 Size: 0x4
	    float Argument1; // 0x24 Size: 0x4
	    float Result; // 0x28 Size: 0x4
	    char UnknownData0[0x4];

};

struct FRigUnit_Divide_FloatFloat : public FRigUnit_BinaryFloatOp
{
	public:
	    char UnknownData0[0x30];

};

struct FRigUnit_Subtract_FloatFloat : public FRigUnit_BinaryFloatOp
{
	public:
	    char UnknownData0[0x30];

};

struct FRigUnit_Add_FloatFloat : public FRigUnit_BinaryFloatOp
{
	public:
	    char UnknownData0[0x30];

};

struct FRigUnit_Multiply_FloatFloat : public FRigUnit_BinaryFloatOp
{
	public:
	    char UnknownData0[0x30];

};

struct FRigUnit_GetJointTransform : public FRigUnit
{
	public:
	    struct FRigHierarchyRef HierarchyRef; // 0x20 Size: 0x18
	    FName Joint; // 0x38 Size: 0x8
	    ETransformGetterType Type; // 0x40 Size: 0x1
	    ETransformSpaceMode TransformSpace; // 0x41 Size: 0x1
	    char UnknownData0[0xe]; // 0x42
	    struct FTransform BaseTransform; // 0x50 Size: 0x30
	    FName BaseJoint; // 0x80 Size: 0x8
	    char UnknownData1[0x8]; // 0x88
	    struct FTransform Output; // 0x90 Size: 0x30

};

struct FRigUnit_MergeHierarchy : public FRigUnit
{
	public:
	    struct FRigHierarchyRef TargetHierarchy; // 0x20 Size: 0x18
	    struct FRigHierarchyRef SourceHierarchy; // 0x38 Size: 0x18

};

struct FRigUnit_QuaternionToAngle : public FRigUnit
{
	public:
	    struct FVector Axis; // 0x20 Size: 0xc
	    char UnknownData0[0x4]; // 0x2c
	    struct FQuat Argument; // 0x30 Size: 0x10
	    float Angle; // 0x40 Size: 0x4
	    char UnknownData1[0xc];

};

struct FRigUnit_QuaternionFromAxisAndAngle : public FRigUnit
{
	public:
	    struct FVector Axis; // 0x20 Size: 0xc
	    float Angle; // 0x2c Size: 0x4
	    struct FQuat Result; // 0x30 Size: 0x10

};

struct FRigUnit_QuaternionToAxisAndAngle : public FRigUnit
{
	public:
	    struct FQuat Argument; // 0x20 Size: 0x10
	    struct FVector Axis; // 0x30 Size: 0xc
	    float Angle; // 0x3c Size: 0x4

};

struct FRigUnit_UnaryQuaternionOp : public FRigUnit
{
	public:
	    struct FQuat Argument; // 0x20 Size: 0x10
	    struct FQuat Result; // 0x30 Size: 0x10

};

struct FRigUnit_InverseQuaterion : public FRigUnit_UnaryQuaternionOp
{
	public:
	    char UnknownData0[0x40];

};

struct FRigUnit_BinaryQuaternionOp : public FRigUnit
{
	public:
	    struct FQuat Argument0; // 0x20 Size: 0x10
	    struct FQuat Argument1; // 0x30 Size: 0x10
	    struct FQuat Result; // 0x40 Size: 0x10

};

struct FRigUnit_MultiplyQuaternion : public FRigUnit_BinaryQuaternionOp
{
	public:
	    char UnknownData0[0x50];

};

struct FRigUnit_BinaryTransformOp : public FRigUnit
{
	public:
	    struct FTransform Argument0; // 0x20 Size: 0x30
	    struct FTransform Argument1; // 0x50 Size: 0x30
	    struct FTransform Result; // 0x80 Size: 0x30

};

struct FRigUnit_GetRelativeTransform : public FRigUnit_BinaryTransformOp
{
	public:
	    char UnknownData0[0xb0];

};

struct FRigUnit_MultiplyTransform : public FRigUnit_BinaryTransformOp
{
	public:
	    char UnknownData0[0xb0];

};

struct FConstraintTarget
{
	public:
	    struct FTransform Transform; // 0x0 Size: 0x30
	    float Weight; // 0x30 Size: 0x4
	    bool bMaintainOffset; // 0x34 Size: 0x1
	    struct FTransformFilter Filter; // 0x35 Size: 0x9
	    char UnknownData0[0x2];

};

struct FRigUnit_TwoBoneIKFK : public FRigUnit
{
	public:
	    struct FRigHierarchyRef HierarchyRef; // 0x20 Size: 0x18
	    FName StartJoint; // 0x38 Size: 0x8
	    FName EndJoint; // 0x40 Size: 0x8
	    bool bUsePoleTarget; // 0x48 Size: 0x1
	    char UnknownData0[0x3]; // 0x49
	    struct FVector PoleTarget; // 0x4c Size: 0xc
	    float Spin; // 0x58 Size: 0x4
	    char UnknownData1[0x4]; // 0x5c
	    struct FTransform EndEffector; // 0x60 Size: 0x30
	    float IKBlend; // 0x90 Size: 0x4
	    char UnknownData2[0xc]; // 0x94
	    struct FTransform StartJointFKTransform; // 0xa0 Size: 0x30
	    struct FTransform MidJointFKTransform; // 0xd0 Size: 0x30
	    struct FTransform EndJointFKTransform; // 0x100 Size: 0x30
	    char UnknownData3[0xc0];

};

struct FRigUnit_Distance_VectorVector : public FRigUnit
{
	public:
	    struct FVector Argument0; // 0x20 Size: 0xc
	    struct FVector Argument1; // 0x2c Size: 0xc
	    float Result; // 0x38 Size: 0x4
	    char UnknownData0[0x4];

};

struct FRigUnit_BinaryVectorOp : public FRigUnit
{
	public:
	    struct FVector Argument0; // 0x20 Size: 0xc
	    struct FVector Argument1; // 0x2c Size: 0xc
	    struct FVector Result; // 0x38 Size: 0xc
	    char UnknownData0[0x4];

};

struct FRigUnit_Divide_VectorVector : public FRigUnit_BinaryVectorOp
{
	public:
	    char UnknownData0[0x48];

};

struct FRigUnit_Subtract_VectorVector : public FRigUnit_BinaryVectorOp
{
	public:
	    char UnknownData0[0x48];

};

struct FRigUnit_Add_VectorVector : public FRigUnit_BinaryVectorOp
{
	public:
	    char UnknownData0[0x48];

};

struct FRigUnit_Multiply_VectorVector : public FRigUnit_BinaryVectorOp
{
	public:
	    char UnknownData0[0x48];

};


}