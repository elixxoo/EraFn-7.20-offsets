#pragma once

#include "../SDK.hpp"

namespace SDK {


class UTimeSynthVolumeGroup : public UObject
{
	public:
	    float DefaultVolume; // 0x28 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/TimeSynth.TimeSynthVolumeGroup");
			return (class UClass*)ptr;
		};

};

class UTimeSynthClip : public UObject
{
	public:
	    TArray<struct FTimeSynthClipSound> Sounds; // 0x28 Size: 0x10
	    struct FVector2D VolumeScaleDb; // 0x38 Size: 0x8
	    struct FVector2D PitchScaleSemitones; // 0x40 Size: 0x8
	    struct FTimeSynthTimeDef FadeInTime; // 0x48 Size: 0x8
	    bool bApplyFadeOut; // 0x50 Size: 0x1
	    char UnknownData0[0x3]; // 0x51
	    struct FTimeSynthTimeDef FadeOutTime; // 0x54 Size: 0x8
	    struct FTimeSynthTimeDef ClipDuration; // 0x5c Size: 0x8
	    ETimeSynthEventClipQuantization ClipQuantization; // 0x64 Size: 0x1
	    char UnknownData1[0x3];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/TimeSynth.TimeSynthClip");
			return (class UClass*)ptr;
		};

};

class UTimeSynthComponent : public USynthComponent
{
	public:
	    struct FTimeSynthQuantizationSettings QuantizationSettings; // 0x610 Size: 0x14
	    bool bEnableSpectralAnalysis; // 0x624 Size: 0x1
	    char UnknownData0[0x3]; // 0x625
	    TArray<float> FrequenciesToAnalyze; // 0x628 Size: 0x10
	    ETimeSynthFFTSize FFTSize; // 0x638 Size: 0x1
	    char UnknownData1[0x7]; // 0x639
	    MulticastDelegateProperty OnPlaybackTime; // 0x640 Size: 0x10
	    bool bIsFilterAEnabled; // 0x650 Size: 0x1
	    bool bIsFilterBEnabled; // 0x650 Size: 0x1
	    char UnknownData2[0x2]; // 0x652
	    struct FTimeSynthFilterSettings FilterASettings; // 0x654 Size: 0xc
	    struct FTimeSynthFilterSettings FilterBSettings; // 0x660 Size: 0xc
	    bool bIsEnvelopeFollowerEnabled; // 0x66c Size: 0x1
	    char UnknownData3[0x3]; // 0x66d
	    struct FTimeSynthEnvelopeFollowerSettings EnvelopeFollowerSettings; // 0x670 Size: 0xc
	    char UnknownData4[0x67c]; // 0x67c
	    void StopSoundsOnVolumeGroupWithFadeOverride(class UTimeSynthVolumeGroup* InVolumeGroup, ETimeSynthEventClipQuantization EventQuantization, struct FTimeSynthTimeDef FadeTime); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void StopSoundsOnVolumeGroup(class UTimeSynthVolumeGroup* InVolumeGroup, ETimeSynthEventClipQuantization EventQuantization); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void StopClipWithFadeOverride(struct FTimeSynthClipHandle InClipHandle, ETimeSynthEventClipQuantization EventQuantization, struct FTimeSynthTimeDef FadeTime); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void StopClip(struct FTimeSynthClipHandle InClipHandle, ETimeSynthEventClipQuantization EventQuantization); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetVolumeGroup(class UTimeSynthVolumeGroup* InVolumeGroup, float VolumeDb, float FadeTimeSec); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetSeed(int InSeed); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetQuantizationSettings(struct FTimeSynthQuantizationSettings InQuantizationSettings); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetFilterSettings(ETimeSynthFilter Filter, struct FTimeSynthFilterSettings InSettings); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetFilterEnabled(ETimeSynthFilter Filter, bool bIsEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void SetFFTSize(ETimeSynthFFTSize InFFTSize); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void SetEnvelopeFollowerSettings(struct FTimeSynthEnvelopeFollowerSettings InSettings); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void SetEnvelopeFollowerEnabled(bool bInIsEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void SetBPM(float BeatsPerMinute); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void ResetSeed(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    struct FTimeSynthClipHandle PlayClip(class UTimeSynthClip* InClip, class UTimeSynthVolumeGroup* InVolumeGroup); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    TArray<struct FTimeSynthSpectralData> GetSpectralData(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    float GetEnvelopeFollowerValue(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    int GetBPM(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void AddQuantizationEventDelegate(ETimeSynthEventQuantization QuantizationType, __int64/*DelegateProperty*/ OnQuantizationEvent); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x-7041];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/TimeSynth.TimeSynthComponent");
			return (class UClass*)ptr;
		};

};


}