#include "../SDK.hpp"

static int UFoliageStatistics::FoliageOverlappingSphereCount(class UObject* WorldContextObject, class UStaticMesh* StaticMesh, struct FVector CenterPosition, float Radius)
{
	struct {
            class UObject* WorldContextObject;
            class UStaticMesh* StaticMesh;
            struct FVector CenterPosition;
            float Radius;
            int ReturnValue;
	} params{ WorldContextObject, StaticMesh, CenterPosition, Radius };

    static auto fn = UObject::FindObject("/Script/Foliage.FoliageStatistics:FoliageOverlappingSphereCount");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static int UFoliageStatistics::FoliageOverlappingBoxCount(class UObject* WorldContextObject, class UStaticMesh* StaticMesh, struct FBox Box)
{
	struct {
            class UObject* WorldContextObject;
            class UStaticMesh* StaticMesh;
            struct FBox Box;
            int ReturnValue;
	} params{ WorldContextObject, StaticMesh, Box };

    static auto fn = UObject::FindObject("/Script/Foliage.FoliageStatistics:FoliageOverlappingBoxCount");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void AInteractiveFoliageActor::CapsuleTouched(class UPrimitiveComponent* OverlappedComp, class AActor* Other, class UPrimitiveComponent* OtherComp, int OtherBodyIndex, bool bFromSweep, struct FHitResult OverlapInfo)
{
	struct {
            class UPrimitiveComponent* OverlappedComp;
            class AActor* Other;
            class UPrimitiveComponent* OtherComp;
            int OtherBodyIndex;
            bool bFromSweep;
            struct FHitResult OverlapInfo;
	} params{ OverlappedComp, Other, OtherComp, OtherBodyIndex, bFromSweep, OverlapInfo };

    static auto fn = UObject::FindObject("/Script/Foliage.InteractiveFoliageActor:CapsuleTouched");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UProceduralFoliageSpawner::Simulate(int NumSteps)
{
	struct {
            int NumSteps;
	} params{ NumSteps };

    static auto fn = UObject::FindObject("/Script/Foliage.ProceduralFoliageSpawner:Simulate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

