#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FVivoxMuteList
{
	public:
	    char UnknownData0[0x50];

};


}