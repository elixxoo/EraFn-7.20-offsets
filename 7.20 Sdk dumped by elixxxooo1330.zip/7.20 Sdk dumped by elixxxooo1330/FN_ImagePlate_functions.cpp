#include "../SDK.hpp"

void UImagePlateComponent::SetImagePlate(struct FImagePlateParameters Plate)
{
	struct {
            struct FImagePlateParameters Plate;
	} params{ Plate };

    static auto fn = UObject::FindObject("/Script/ImagePlate.ImagePlateComponent:SetImagePlate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UImagePlateComponent::OnRenderTextureChanged()
{
    static auto fn = UObject::FindObject("/Script/ImagePlate.ImagePlateComponent:OnRenderTextureChanged");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


struct FImagePlateParameters UImagePlateComponent::GetPlate()
{
	struct {
            struct FImagePlateParameters ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/ImagePlate.ImagePlateComponent:GetPlate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

