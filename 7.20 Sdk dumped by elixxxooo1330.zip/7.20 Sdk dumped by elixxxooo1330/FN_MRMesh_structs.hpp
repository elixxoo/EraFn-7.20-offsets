#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FMRMeshConfiguration
{
	public:
	    char UnknownData0[0x1];

};


}