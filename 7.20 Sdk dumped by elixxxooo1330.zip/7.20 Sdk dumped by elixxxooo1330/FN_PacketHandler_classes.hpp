#pragma once

#include "../SDK.hpp"

namespace SDK {


class UHandlerComponentFactory : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/PacketHandler.HandlerComponentFactory");
			return (class UClass*)ptr;
		};

};

class UNetAnalyticsAggregatorConfig : public UObject
{
	public:
	    TArray<struct FNetAnalyticsDataConfig> NetAnalyticsData; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/PacketHandler.NetAnalyticsAggregatorConfig");
			return (class UClass*)ptr;
		};

};


}