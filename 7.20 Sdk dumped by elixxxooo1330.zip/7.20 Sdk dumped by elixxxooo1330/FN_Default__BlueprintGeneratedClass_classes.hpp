#pragma once

#include "../SDK.hpp"

namespace SDK {


class UDefault__BlueprintGeneratedClass
{
	public:

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Default__BlueprintGeneratedClass");
			return (class UClass*)ptr;
		};

};

