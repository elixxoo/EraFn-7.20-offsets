#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FOnItemClicked__DelegateSignature
{
	public:
	    class UUserWidget* Widget; // 0x0 Size: 0x8

};

struct FOnItemSelected__DelegateSignature
{
	public:
	    class UUserWidget* Widget; // 0x0 Size: 0x8
	    bool Selected; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FCommonActionCommited__DelegateSignature
{
	public:
	    bool bPassThrough; // 0x0 Size: 0x1

};

struct FCommonActionCompleteSingle__DelegateSignature
{
	public:

};

struct FCommonActionComplete__DelegateSignature
{
	public:

};

struct FCommonActionProgressSingle__DelegateSignature
{
	public:
	    float HeldPercent; // 0x0 Size: 0x4

};

struct FCommonActionProgress__DelegateSignature
{
	public:
	    float HeldPercent; // 0x0 Size: 0x4

};

struct FOnWidgetActivationChangedDynamic__DelegateSignature
{
	public:
	    class UCommonActivatablePanel* Panel; // 0x0 Size: 0x8

};

struct FCommonSelectedStateChanged__DelegateSignature
{
	public:
	    class UCommonButton* Button; // 0x0 Size: 0x8
	    bool Selected; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FCommonButtonClicked__DelegateSignature
{
	public:
	    class UCommonButton* Button; // 0x0 Size: 0x8

};

struct FOnLoadGuardStateChangedDynamic__DelegateSignature
{
	public:
	    bool bIsLoading; // 0x0 Size: 0x1

};



enum class ECommonNumericType : uint8_t
{
    Number = 0,
    Percentage = 1,
    Seconds = 2,
    Distance = 3,
    ECommonNumericType_MAX = 4
};struct FCommonNumberFormattingOptions
{
	public:
	    char RoundingMode; // 0x0 Size: 0x1
	    bool UseGrouping; // 0x1 Size: 0x1
	    char UnknownData0[0x2]; // 0x2
	    int MinimumIntegralDigits; // 0x4 Size: 0x4
	    int MaximumIntegralDigits; // 0x8 Size: 0x4
	    int MinimumFractionalDigits; // 0xc Size: 0x4
	    int MaximumFractionalDigits; // 0x10 Size: 0x4

};

struct FOnRotated__DelegateSignature
{
	public:
	    int Value; // 0x0 Size: 0x4

};

struct FOnActiveWidgetDeactivated__DelegateSignature
{
	public:
	    class UCommonActivatablePanel* DeactivatedWidget; // 0x0 Size: 0x8

};

struct FOnActiveWidgetChanged__DelegateSignature
{
	public:
	    class UWidget* ActiveWidget; // 0x0 Size: 0x8
	    int ActiveWidgetIndex; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FCommonRegisteredTabInfo
{
	public:
	    int TabIndex; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    class UCommonButton* TabButton; // 0x8 Size: 0x8
	    class UWidget* ContentInstance; // 0x10 Size: 0x8

};

struct FOnCurrentPageIndexChanged__DelegateSignature
{
	public:
	    class UCommonWidgetCarousel* CarouselWidget; // 0x0 Size: 0x8
	    int CurrentPageIndex; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FSimpleButtonGroupDelegate__DelegateSignature
{
	public:
	    class UCommonButton* AssociatedButton; // 0x0 Size: 0x8
	    int ButtonIndex; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FOnSelectionCleared__DelegateSignature
{
	public:

};



enum class EOperation : uint8_t
{
    Intro = 0,
    Outro = 1,
    Push = 2,
    Pop = 3,
    Invalid = 4,
    EOperation_MAX = 5
};

enum class ECommonPlatformType : uint8_t
{
    PC = 0,
    Mac = 1,
    PS4 = 2,
    XBox = 3,
    IOS = 4,
    Android = 5,
    Erebus = 6,
    Count = 7,
    ECommonPlatformType_MAX = 8
};

enum class EInputActionState : uint8_t
{
    Enabled = 0,
    Disabled = 1,
    Hidden = 2,
    HiddenAndDisabled = 3,
    EInputActionState_MAX = 4
};

enum class ETransitionCurve : uint8_t
{
    Linear = 0,
    QuadIn = 1,
    QuadOut = 2,
    QuadInOut = 3,
    CubicIn = 4,
    CubicOut = 5,
    CubicInOut = 6,
    ETransitionCurve_MAX = 7
};

enum class ECommonSwitcherTransition : uint8_t
{
    FadeOnly = 0,
    Horizontal = 1,
    Vertical = 2,
    Zoom = 3,
    ECommonSwitcherTransition_MAX = 4
};struct FCommonInputActionHandlerData
{
	public:
	    struct FDataTableRowHandle InputActionRow; // 0x0 Size: 0x10
	    EInputActionState State; // 0x10 Size: 0x1
	    char UnknownData0[0xf];

};

struct FCommonButtonStyleOptionalSlateSound
{
	public:
	    bool bHasSound; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FSlateSound Sound; // 0x8 Size: 0x18

};

struct FOperation
{
	public:
	    EOperation Operation; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class UCommonActivatablePanel* Panel; // 0x8 Size: 0x8
	    bool bIntroPanel; // 0x10 Size: 0x1
	    bool bActivatePanel; // 0x11 Size: 0x1
	    bool bOutroPanelBelow; // 0x12 Size: 0x1
	    char UnknownData1[0x5];

};

struct FSoftSlateBrush
{
	public:
	    struct FVector2D ImageSize; // 0x0 Size: 0x8
	    struct FMargin Margin; // 0x8 Size: 0x10
	    struct FSlateColor TintColor; // 0x18 Size: 0x28
	    struct TSoftObjectPtr<struct UObject*> ResourceObject; // 0x40 Size: 0x28
	    char DrawAs; // 0x68 Size: 0x1
	    char Tiling; // 0x69 Size: 0x1
	    char Mirroring; // 0x6a Size: 0x1
	    char ImageType; // 0x6b Size: 0x1
	    char UnknownData0[0x4];

};

struct FCommonInputKeyDisplayData
{
	public:
	    struct FSoftSlateBrush KeyboardBrush; // 0x0 Size: 0x70
	    struct FSoftSlateBrush* GamepadBrushes; // 0x70 Size: 0x70
	    char UnknownData0[0x150]; // 0xe0
	    struct FSoftSlateBrush TouchBrush; // 0x230 Size: 0x70

};

struct FCommonInputKeyDisplayConfiguration
{
	public:
	    struct FKey Key; // 0x0 Size: 0x18
	    struct FCommonInputKeyDisplayData Value; // 0x18 Size: 0x2a0

};

struct FCommonInputTypeInfo
{
	public:
	    struct FKey Key; // 0x0 Size: 0x18
	    EInputActionState OverrrideState; // 0x18 Size: 0x1
	    bool bActionRequiresHold; // 0x19 Size: 0x1
	    char UnknownData0[0x2]; // 0x1a
	    float HoldTime; // 0x1c Size: 0x4
	    struct FSlateBrush OverrideBrush; // 0x20 Size: 0x88

};

struct FCommonInputActionData : public FTableRowBase
{
	public:
	    struct FText DisplayName; // 0x8 Size: 0x18
	    struct FText HoldDisplayName; // 0x20 Size: 0x18
	    struct FCommonInputTypeInfo KeyboardInputTypeInfo; // 0x38 Size: 0xa8
	    struct FCommonInputTypeInfo* GamepadInputTypeInfos; // 0xe0 Size: 0xa8
	    char UnknownData0[0x1f8]; // 0x188
	    struct FCommonInputTypeInfo TouchInputTypeInfo; // 0x380 Size: 0xa8

};


}