#pragma once

#include "../SDK.hpp"

namespace SDK {


class UNamedInterfaces : public UObject
{
	public:
	    TArray<struct FNamedInterface> NamedInterfaces; // 0x28 Size: 0x10
	    TArray<struct FNamedInterfaceDef> NamedInterfaceDefs; // 0x38 Size: 0x10
	    char UnknownData0[0x18];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystem.NamedInterfaces");
			return (class UClass*)ptr;
		};

};

class UTurnBasedMatchInterface : public UInterface
{
	public:
	    void OnMatchReceivedTurn(struct FString Match, bool bDidBecomeActive); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void OnMatchEnded(struct FString Match); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystem.TurnBasedMatchInterface");
			return (class UClass*)ptr;
		};

};


}