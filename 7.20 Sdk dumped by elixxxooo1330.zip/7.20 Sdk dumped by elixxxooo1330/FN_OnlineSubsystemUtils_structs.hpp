#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FAchievementWriteDelegate__DelegateSignature
{
	public:
	    FName WrittenAchievementName; // 0x0 Size: 0x8
	    float WrittenProgress; // 0x8 Size: 0x4
	    int WrittenUserTag; // 0xc Size: 0x4

};

struct FOnlineConnectionResult__DelegateSignature
{
	public:
	    int ErrorCode; // 0x0 Size: 0x4

};

struct FBlueprintSessionResult
{
	public:
	    char UnknownData0[0xb8];

};

struct FOnlineTurnBasedMatchResult__DelegateSignature
{
	public:
	    struct FString MatchID; // 0x0 Size: 0x10

};

struct FInAppPurchaseResult__DelegateSignature
{
	public:
	    char CompletionStatus; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FInAppPurchaseProductInfo InAppPurchaseInformation; // 0x8 Size: 0xa8

};

struct FOnLeaderboardFlushed__DelegateSignature
{
	public:
	    FName SessionName; // 0x0 Size: 0x8

};

struct FLeaderboardQueryResult__DelegateSignature
{
	public:
	    int LeaderboardValue; // 0x0 Size: 0x4

};

struct FOnlineLogoutResult__DelegateSignature
{
	public:
	    class APlayerController* PlayerController; // 0x0 Size: 0x8

};

struct FOnlineShowLoginUIResult__DelegateSignature
{
	public:
	    class APlayerController* PlayerController; // 0x0 Size: 0x8

};



enum class EBeaconConnectionState : uint8_t
{
    Invalid = 0,
    Closed = 1,
    Pending = 2,
    Open = 3,
    EBeaconConnectionState_MAX = 4
};

enum class EClientRequestType : uint8_t
{
    NonePending = 0,
    ExistingSessionReservation = 1,
    ReservationUpdate = 2,
    EmptyServerReservation = 3,
    Reconnect = 4,
    Abandon = 5,
    EClientRequestType_MAX = 6
};

enum class EPartyReservationResult : uint8_t
{
    NoResult = 0,
    RequestPending = 1,
    GeneralError = 2,
    PartyLimitReached = 3,
    IncorrectPlayerCount = 4,
    RequestTimedOut = 5,
    ReservationDuplicate = 6,
    ReservationNotFound = 7,
    ReservationAccepted = 8,
    ReservationDenied = 9,
    ReservationDenied_CrossPlayRestriction = 10,
    ReservationDenied_Banned = 11,
    ReservationRequestCanceled = 12,
    ReservationInvalid = 13,
    BadSessionId = 14,
    ReservationDenied_ContainsExistingPlayers = 15,
    EPartyReservationResult_MAX = 16
};
}