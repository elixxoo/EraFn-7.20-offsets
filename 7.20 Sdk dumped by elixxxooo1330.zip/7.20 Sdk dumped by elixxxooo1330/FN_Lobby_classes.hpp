#pragma once

#include "../SDK.hpp"

namespace SDK {


class ALobbyBeaconClient : public AOnlineBeaconClient
{
	public:
	    class ALobbyBeaconState* LobbyState; // 0x3b0 Size: 0x8
	    class ALobbyBeaconPlayerState* PlayerState; // 0x3b8 Size: 0x8
	    char UnknownData0[0x1]; // 0x3c0
	    ELobbyBeaconJoinState LobbyJoinServerState; // 0x3c1 Size: 0x1
	    char UnknownData1[0x3c2]; // 0x3c2
	    void ServerSetPartyOwner(struct FUniqueNetIdRepl InUniqueId, struct FUniqueNetIdRepl InPartyOwnerId); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void ServerNotifyJoiningServer(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void ServerLoginPlayer(struct FString InSessionId, struct FUniqueNetIdRepl InUniqueId, struct FString UrlString); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void ServerKickPlayer(struct FUniqueNetIdRepl PlayerToKick, struct FText Reason); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ServerDisconnectFromLobby(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ServerCheat(struct FString Msg); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void ClientWasKicked(struct FText KickReason); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void ClientSetInviteFlags(struct FJoinabilitySettings Settings); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void ClientPlayerLeft(struct FUniqueNetIdRepl InUniqueId); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void ClientPlayerJoined(struct FText NewPlayerName, struct FUniqueNetIdRepl InUniqueId); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void ClientLoginComplete(struct FUniqueNetIdRepl InUniqueId, bool bWasSuccessful); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void ClientJoinGame(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void ClientAckJoiningServer(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x-7ba9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Lobby.LobbyBeaconClient");
			return (class UClass*)ptr;
		};

};

class ALobbyBeaconHost : public AOnlineBeaconHostObject
{
	public:
	    char UnknownData0[0x8];
	    __int64/*SoftClassProperty*/ LobbyStateClass; // 0x360 Size: 0x28
	    class ALobbyBeaconState* LobbyState; // 0x388 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Lobby.LobbyBeaconHost");
			return (class UClass*)ptr;
		};

};

class ALobbyBeaconPlayerState : public AInfo
{
	public:
	    struct FText DisplayName; // 0x330 Size: 0x18
	    struct FUniqueNetIdRepl UniqueId; // 0x348 Size: 0x28
	    struct FUniqueNetIdRepl PartyOwnerUniqueId; // 0x370 Size: 0x28
	    bool bInLobby; // 0x398 Size: 0x1
	    char UnknownData0[0x7]; // 0x399
	    class AOnlineBeaconClient* ClientActor; // 0x3a0 Size: 0x8
	    char UnknownData1[0x3a8]; // 0x3a8
	    void OnRep_PartyOwner(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnRep_InLobby(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7c09];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Lobby.LobbyBeaconPlayerState");
			return (class UClass*)ptr;
		};

};

class ALobbyBeaconState : public AInfo
{
	public:
	    int MaxPlayers; // 0x330 Size: 0x4
	    char UnknownData0[0x4]; // 0x334
	    class ALobbyBeaconPlayerState* LobbyBeaconPlayerStateClass; // 0x338 Size: 0x8
	    bool bLobbyStarted; // 0x348 Size: 0x1
	    char UnknownData1[0xb]; // 0x341
	    float WaitForPlayersTimeRemaining; // 0x34c Size: 0x4
	    struct FLobbyPlayerStateInfoArray Players; // 0x350 Size: 0xc8
	    char UnknownData2[0x418]; // 0x418
	    void OnRep_WaitForPlayersTimeRemaining(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnRep_LobbyStarted(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7b61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Lobby.LobbyBeaconState");
			return (class UClass*)ptr;
		};

};


}