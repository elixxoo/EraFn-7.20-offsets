#pragma once

#include "../SDK.hpp"

namespace SDK {


class UClothingAssetBase : public UObject
{
	public:
	    struct FString ImportedFilePath; // 0x28 Size: 0x10
	    struct FGuid AssetGuid; // 0x38 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ClothingSystemRuntimeInterface.ClothingAssetBase");
			return (class UClass*)ptr;
		};

};

class UClothingSimulationFactory : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ClothingSystemRuntimeInterface.ClothingSimulationFactory");
			return (class UClass*)ptr;
		};

};

class UClothingSimulationInteractor : public UObject
{
	public:
	    void PhysicsAssetUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void ClothConfigUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7fb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ClothingSystemRuntimeInterface.ClothingSimulationInteractor");
			return (class UClass*)ptr;
		};

};


}