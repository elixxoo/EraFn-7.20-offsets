#pragma once

#include "../SDK.hpp"

namespace SDK {


class UButtonStyle-Outline-Red_C : public UCommonButtonStyle
{
	public:
	    char UnknownData0[0x570];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Game/UI/Foundation/Buttons/ButtonStyles/TopBar/ButtonStyle-Outline-Red.ButtonStyle-Outline-Red_C");
			return (class UClass*)ptr;
		};

};

