#pragma once

#include "../SDK.hpp"

namespace SDK {


class UFontBulkData : public UObject
{
	public:
	    char UnknownData0[0xc0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SlateCore.FontBulkData");
			return (class UClass*)ptr;
		};

};

class UFontFaceInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SlateCore.FontFaceInterface");
			return (class UClass*)ptr;
		};

};

class UFontProviderInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SlateCore.FontProviderInterface");
			return (class UClass*)ptr;
		};

};

class USlateTypes : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SlateCore.SlateTypes");
			return (class UClass*)ptr;
		};

};

class USlateWidgetStyleAsset : public UObject
{
	public:
	    class USlateWidgetStyleContainerBase* CustomStyle; // 0x28 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SlateCore.SlateWidgetStyleAsset");
			return (class UClass*)ptr;
		};

};

class USlateWidgetStyleContainerBase : public UObject
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SlateCore.SlateWidgetStyleContainerBase");
			return (class UClass*)ptr;
		};

};

class USlateWidgetStyleContainerInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SlateCore.SlateWidgetStyleContainerInterface");
			return (class UClass*)ptr;
		};

};


}