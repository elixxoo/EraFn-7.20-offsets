#pragma once

#include "../SDK.hpp"

namespace SDK {


class ACineCameraActor : public ACameraActor
{
	public:
	    struct FCameraLookatTrackingSettings LookatTrackingSettings; // 0x840 Size: 0x50
	    char UnknownData0[0x890]; // 0x890
	    class UCineCameraComponent* GetCineCameraComponent(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7741];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CinematicCamera.CineCameraActor");
			return (class UClass*)ptr;
		};

};

class UCineCameraComponent : public UCameraComponent
{
	public:
	    struct FCameraFilmbackSettings FilmbackSettings; // 0x7a0 Size: 0xc
	    struct FCameraLensSettings LensSettings; // 0x7ac Size: 0x18
	    char UnknownData0[0x4]; // 0x7c4
	    struct FCameraFocusSettings FocusSettings; // 0x7c8 Size: 0x58
	    float CurrentFocalLength; // 0x820 Size: 0x4
	    float CurrentAperture; // 0x824 Size: 0x4
	    float CurrentFocusDistance; // 0x828 Size: 0x4
	    char UnknownData1[0xc]; // 0x82c
	    TArray<struct FNamedFilmbackPreset> FilmbackPresets; // 0x838 Size: 0x10
	    TArray<struct FNamedLensPreset> LensPresets; // 0x848 Size: 0x10
	    struct FString DefaultFilmbackPresetName; // 0x858 Size: 0x10
	    struct FString DefaultLensPresetName; // 0x868 Size: 0x10
	    float DefaultLensFocalLength; // 0x878 Size: 0x4
	    float DefaultLensFStop; // 0x87c Size: 0x4
	    char UnknownData2[0x880]; // 0x880
	    void SetLensPresetByName(struct FString InPresetName); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetFilmbackPresetByName(struct FString InPresetName); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    float GetVerticalFieldOfView(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    struct FString GetLensPresetName(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    float GetHorizontalFieldOfView(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    struct FString GetFilmbackPresetName(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7761];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CinematicCamera.CineCameraComponent");
			return (class UClass*)ptr;
		};

};

class ACameraRig_Crane : public AActor
{
	public:
	    float CranePitch; // 0x330 Size: 0x4
	    float CraneYaw; // 0x334 Size: 0x4
	    float CraneArmLength; // 0x338 Size: 0x4
	    bool bLockMountPitch; // 0x33c Size: 0x1
	    bool bLockMountYaw; // 0x33d Size: 0x1
	    char UnknownData0[0x2]; // 0x33e
	    class USceneComponent* TransformComponent; // 0x340 Size: 0x8
	    class USceneComponent* CraneYawControl; // 0x348 Size: 0x8
	    class USceneComponent* CranePitchControl; // 0x350 Size: 0x8
	    class USceneComponent* CraneCameraMount; // 0x358 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CinematicCamera.CameraRig_Crane");
			return (class UClass*)ptr;
		};

};

class ACameraRig_Rail : public AActor
{
	public:
	    float CurrentPositionOnRail; // 0x330 Size: 0x4
	    bool bLockOrientationToRail; // 0x334 Size: 0x1
	    char UnknownData0[0x3]; // 0x335
	    class USceneComponent* TransformComponent; // 0x338 Size: 0x8
	    class USplineComponent* RailSplineComponent; // 0x340 Size: 0x8
	    class USceneComponent* RailCameraMount; // 0x348 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CinematicCamera.CameraRig_Rail");
			return (class UClass*)ptr;
		};

};


}