#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FChatChromeColorScheme
{
	public:
	    struct FLinearColor ChatEntryBackgroundColor; // 0x0 Size: 0x10
	    struct FLinearColor NoneActiveTabColor; // 0x10 Size: 0x10
	    struct FLinearColor TabFontColor; // 0x20 Size: 0x10
	    struct FLinearColor TabFontColorInverted; // 0x30 Size: 0x10
	    struct FLinearColor ChatBackgroundColor; // 0x40 Size: 0x10

};

struct FChatChromeMargins
{
	public:
	    float TabWidth; // 0x0 Size: 0x4
	    struct FMargin TabPadding; // 0x4 Size: 0x10
	    struct FMargin ChatWindowPadding; // 0x14 Size: 0x10
	    struct FMargin ChatWindowToEntryMargin; // 0x24 Size: 0x10
	    struct FMargin ChatChannelPadding; // 0x34 Size: 0x10
	    struct FMargin UserListButtonPadding; // 0x44 Size: 0x10
	    struct FMargin UserListIconPadding; // 0x54 Size: 0x10

};

struct FChatChromeStyle
{
	public:
	    struct FSlateBrush UserListBrush; // 0x0 Size: 0x88
	    struct FSlateBrush ChatBackgroundBrush; // 0x88 Size: 0x88
	    struct FSlateBrush ChatEntryBackgroundBrush; // 0x110 Size: 0x88
	    struct FSlateBrush ChannelBackgroundBrush; // 0x198 Size: 0x88
	    struct FSlateBrush TabBackgroundBrush; // 0x220 Size: 0x88
	    struct FButtonStyle TabSelectorButtonStyle; // 0x2a8 Size: 0x278
	    struct FMargin TabOptionPadding; // 0x520 Size: 0x10
	    struct FMargin TabContentPadding; // 0x530 Size: 0x10
	    struct FMargin TabClosePadding; // 0x540 Size: 0x10
	    struct FButtonStyle UserListButtonStyle; // 0x550 Size: 0x278

};

struct FChatColorScheme
{
	public:
	    struct FLinearColor TimeStampColor; // 0x0 Size: 0x10
	    struct FLinearColor DefaultChatColor; // 0x10 Size: 0x10
	    struct FLinearColor WhisperChatColor; // 0x20 Size: 0x10
	    struct FLinearColor GlobalChatColor; // 0x30 Size: 0x10
	    struct FLinearColor FounderChatColor; // 0x40 Size: 0x10
	    struct FLinearColor GameChatColor; // 0x50 Size: 0x10
	    struct FLinearColor TeamChatColor; // 0x60 Size: 0x10
	    struct FLinearColor PartyChatColor; // 0x70 Size: 0x10
	    struct FLinearColor AdminChatColor; // 0x80 Size: 0x10
	    struct FLinearColor GameAdminChatColor; // 0x90 Size: 0x10
	    struct FLinearColor WhisperHyperlinkChatColor; // 0xa0 Size: 0x10
	    struct FLinearColor GlobalHyperlinkChatColor; // 0xb0 Size: 0x10
	    struct FLinearColor FounderHyperlinkChatColor; // 0xc0 Size: 0x10
	    struct FLinearColor GameHyperlinkChatColor; // 0xd0 Size: 0x10
	    struct FLinearColor TeamHyperlinkChatColor; // 0xe0 Size: 0x10
	    struct FLinearColor PartyHyperlinkChatColor; // 0xf0 Size: 0x10
	    struct FLinearColor EnemyColor; // 0x100 Size: 0x10
	    struct FLinearColor FriendlyColor; // 0x110 Size: 0x10

};

struct FChatMarkupStyle
{
	public:
	    struct FButtonStyle MarkupButtonStyle; // 0x0 Size: 0x278
	    struct FTextBlockStyle MarkupTextStyle; // 0x278 Size: 0x1e0
	    struct FSlateBrush MarkupBackground; // 0x458 Size: 0x88
	    struct FSlateColor ButtonColor; // 0x4e0 Size: 0x28
	    struct FSlateColor ButtonHoverColor; // 0x508 Size: 0x28
	    struct FSlateColor TipColor; // 0x530 Size: 0x28
	    struct FSlateBrush SeperatorBrush; // 0x558 Size: 0x88
	    float SeperatorThickness; // 0x5e0 Size: 0x4
	    struct FMargin MarkupPadding; // 0x5e4 Size: 0x10
	    struct FMargin ButtonPadding; // 0x5f4 Size: 0x10
	    char UnknownData0[0x4];

};

struct FChatStyle
{
	public:
	    struct FEditableTextBoxStyle ChatEntryTextStyle; // 0x0 Size: 0x7f0
	    struct FEditableTextBoxStyle ChatDisplayTextStyle; // 0x7f0 Size: 0x7f0
	    struct FScrollBoxStyle ScrollBorderStyle; // 0xfe0 Size: 0x228
	    struct FSlateBrush MessageNotificationBrush; // 0x1208 Size: 0x88
	    struct FMargin ChatEntryPadding; // 0x1290 Size: 0x10
	    float ChatEntryHeight; // 0x12a0 Size: 0x4
	    char UnknownData0[0x4]; // 0x12a4
	    struct FSlateBrush ChatMenuBackgroundBrush; // 0x12a8 Size: 0x88
	    struct FMargin FriendActionPadding; // 0x1330 Size: 0x10
	    struct FMargin FriendActionHeaderPadding; // 0x1340 Size: 0x10
	    struct FMargin FriendActionStatusMargin; // 0x1350 Size: 0x10

};

struct FSocialFontStyle
{
	public:
	    struct FSlateFontInfo FontSmall; // 0x0 Size: 0x50
	    struct FSlateFontInfo FontSmallBold; // 0x50 Size: 0x50
	    struct FSlateFontInfo FontNormal; // 0xa0 Size: 0x50
	    struct FSlateFontInfo FontNormalBold; // 0xf0 Size: 0x50
	    struct FSlateFontInfo FontLarge; // 0x140 Size: 0x50
	    struct FSlateFontInfo FontLargeBold; // 0x190 Size: 0x50
	    struct FLinearColor DefaultFontColor; // 0x1e0 Size: 0x10
	    struct FLinearColor InvertedFontColor; // 0x1f0 Size: 0x10
	    struct FLinearColor DefaultDullFontColor; // 0x200 Size: 0x10

};

struct FSocialListMargins
{
	public:
	    struct FVector2D UserPresenceImageSize; // 0x0 Size: 0x8
	    struct FMargin HeaderButtonMargin; // 0x8 Size: 0x10
	    struct FMargin FriendsListMargin; // 0x18 Size: 0x10
	    struct FMargin FriendsListNoFriendsMargin; // 0x28 Size: 0x10
	    struct FMargin FriendsListHeaderMargin; // 0x38 Size: 0x10
	    struct FMargin FriendsListHeaderCountMargin; // 0x48 Size: 0x10
	    struct FMargin HeaderButtonContentMargin; // 0x58 Size: 0x10
	    struct FMargin FriendItemMargin; // 0x68 Size: 0x10
	    struct FMargin FriendItemStatusMargin; // 0x78 Size: 0x10
	    struct FMargin FriendTipStatusMargin; // 0x88 Size: 0x10
	    struct FMargin FriendItemPresenceMargin; // 0x98 Size: 0x10
	    struct FMargin FriendItemPlatformMargin; // 0xa8 Size: 0x10
	    struct FMargin FriendItemTextScrollerMargin; // 0xb8 Size: 0x10
	    struct FMargin ConfirmationBorderMargin; // 0xc8 Size: 0x10
	    struct FMargin ConfirmationButtonMargin; // 0xd8 Size: 0x10
	    struct FMargin ConfirmationButtonContentMargin; // 0xe8 Size: 0x10
	    struct FMargin NoneFriendContentMargin; // 0xf8 Size: 0x10
	    float NoneFriendContentHeight; // 0x108 Size: 0x4
	    float NoneFriendIconWidth; // 0x10c Size: 0x4
	    struct FMargin SubMenuBackIconMargin; // 0x110 Size: 0x10
	    struct FMargin SubMenuPageIconMargin; // 0x120 Size: 0x10
	    struct FMargin RadioSettingTitleMargin; // 0x130 Size: 0x10
	    struct FMargin SubMenuSearchIconMargin; // 0x140 Size: 0x10
	    struct FMargin SubMenuSearchTextMargin; // 0x150 Size: 0x10
	    struct FMargin SubMenuBackButtonMargin; // 0x160 Size: 0x10
	    struct FMargin SubMenuSettingButtonMargin; // 0x170 Size: 0x10
	    struct FMargin SubMenuListMargin; // 0x180 Size: 0x10
	    float SubMenuSeperatorThickness; // 0x190 Size: 0x4
	    float PresenceSeperatorThickness; // 0x194 Size: 0x4
	    struct FMargin FriendTipMargin; // 0x198 Size: 0x10
	    struct FMargin FriendTipPresenceMargin; // 0x1a8 Size: 0x10
	    struct FMargin FriendTipSeperatorMargin; // 0x1b8 Size: 0x10
	    struct FMargin ToolTipMargin; // 0x1c8 Size: 0x10
	    struct FMargin TipStatusMargin; // 0x1d8 Size: 0x10
	    struct FMargin AddButtonMargin; // 0x1e8 Size: 0x10
	    struct FVector2D AddButtonSpacing; // 0x1f8 Size: 0x8

};

struct FSocialListStyle
{
	public:
	    struct FButtonStyle GlobalChatButtonStyle; // 0x0 Size: 0x278
	    struct FSlateBrush GlobalChatIcon; // 0x278 Size: 0x88
	    struct FButtonStyle FriendItemButtonStyle; // 0x300 Size: 0x278
	    struct FButtonStyle ConfirmButtonStyle; // 0x578 Size: 0x278
	    struct FButtonStyle CancelButtonStyle; // 0x7f0 Size: 0x278
	    struct FSlateColor ButtonContentColor; // 0xa68 Size: 0x28
	    struct FSlateColor ButtonHoverContentColor; // 0xa90 Size: 0x28
	    struct FSlateBrush ActionMenuArrowBrush; // 0xab8 Size: 0x88
	    struct FSlateBrush ActionMenuArrowRightBrush; // 0xb40 Size: 0x88
	    struct FSlateColor ActionMenuBackgroundColor; // 0xbc8 Size: 0x28
	    struct FSlateBrush ToolTipArrowBrush; // 0xbf0 Size: 0x88
	    struct FButtonStyle BackButtonStyle; // 0xc78 Size: 0x278
	    struct FButtonStyle HeaderButtonStyle; // 0xef0 Size: 0x278
	    struct FButtonStyle FriendListActionButtonStyle; // 0x1168 Size: 0x278
	    struct FSlateBrush AddFriendButtonContentBrush; // 0x13e0 Size: 0x88
	    struct FSlateBrush StatusIconBrush; // 0x1468 Size: 0x88
	    struct FSlateBrush PCIconBrush; // 0x14f0 Size: 0x88
	    struct FSlateBrush ConsoleIconBrush; // 0x1578 Size: 0x88
	    struct FSlateBrush MobileIconBrush; // 0x1600 Size: 0x88
	    struct FSlateBrush FacebookIconBrush; // 0x1688 Size: 0x88
	    struct FSlateBrush EpicIconBrush; // 0x1710 Size: 0x88
	    struct FSlateBrush FriendImageBrush; // 0x1798 Size: 0x88
	    struct FSlateBrush OfflineBrush; // 0x1820 Size: 0x88
	    struct FSlateBrush OnlineBrush; // 0x18a8 Size: 0x88
	    struct FSlateBrush AwayBrush; // 0x1930 Size: 0x88
	    struct FSlateBrush SpectateBrush; // 0x19b8 Size: 0x88
	    struct FSlateBrush FriendsContainerBackground; // 0x1a40 Size: 0x88
	    struct FSlateBrush FriendsListBackground; // 0x1ac8 Size: 0x88
	    struct FEditableTextBoxStyle AddFriendEditableTextStyle; // 0x1b50 Size: 0x7f0
	    struct FSlateBrush BackBrush; // 0x2340 Size: 0x88
	    struct FSlateBrush SelectedOptionBrush; // 0x23c8 Size: 0x88
	    struct FSlateBrush SettingsBrush; // 0x2450 Size: 0x88
	    struct FSlateBrush SeperatorBrush; // 0x24d8 Size: 0x88
	    struct FSlateBrush PresenceSeperatorBrush; // 0x2560 Size: 0x88
	    struct FSlateBrush FontSizeBrush; // 0x25e8 Size: 0x88
	    struct FSlateBrush SearchBrush; // 0x2670 Size: 0x88

};

struct FProfanityData
{
	public:
	    struct FString CountryCode; // 0x0 Size: 0x10
	    struct FString ProfanityList; // 0x10 Size: 0x10
	    struct FString WhiteList; // 0x20 Size: 0x10
	    bool bAutoAdd; // 0x30 Size: 0x1
	    char UnknownData0[0x7];

};

struct FSocialSoundSchema
{
	public:
	    struct FSlateSound MessageReceivedSound; // 0x0 Size: 0x18
	    struct FSlateSound PartyInviteReceivedSound; // 0x18 Size: 0x18
	    struct FSlateSound FriendInviteReceivedSound; // 0x30 Size: 0x18

};

struct FSocialStyle
{
	public:
	    struct FScrollBarStyle ScrollBarStyle; // 0x0 Size: 0x4d0
	    struct FButtonStyle ActionButtonStyle; // 0x4d0 Size: 0x278
	    struct FSocialFontStyle SmallFontStyle; // 0x748 Size: 0x210
	    struct FSocialFontStyle NormalFontStyle; // 0x958 Size: 0x210
	    struct FSocialFontStyle LargeFontStyle; // 0xb68 Size: 0x210
	    struct FSocialFontStyle ChatFontStyle; // 0xd78 Size: 0x210
	    struct FCheckBoxStyle CheckBoxStyle; // 0xf88 Size: 0x580
	    struct FCheckBoxStyle RadioBoxStyle; // 0x1508 Size: 0x580
	    struct FSocialListStyle SocialListStyle; // 0x1a88 Size: 0x26f8
	    struct FSocialListMargins SocialListMargins; // 0x4180 Size: 0x200
	    struct FChatStyle ChatStyle; // 0x4380 Size: 0x1360
	    struct FChatColorScheme ChatColorScheme; // 0x56e0 Size: 0x120
	    struct FChatChromeStyle ChatChromeStyle; // 0x5800 Size: 0x7c8
	    struct FChatChromeMargins ChatChromeMargins; // 0x5fc8 Size: 0x64
	    struct FChatChromeColorScheme ChatChromeColorScheme; // 0x602c Size: 0x50
	    char UnknownData0[0x4]; // 0x607c
	    struct FChatMarkupStyle ChatMarkupStyle; // 0x6080 Size: 0x608
	    struct FSocialSoundSchema SoundSchema; // 0x6688 Size: 0x48

};


}