#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FCalendarDownload
{
	public:
	    struct FDateTime CurrentTime; // 0x0 Size: 0x8
	    double EventsTimeOffsetHrs; // 0x8 Size: 0x8
	    __int64/*MapProperty*/ Channels; // 0x10 Size: 0x50

};

struct FEventRecord
{
	public:
	    struct FString EventType; // 0x0 Size: 0x10
	    struct FDateTime ActiveUntil; // 0x10 Size: 0x8
	    struct FDateTime ActiveSince; // 0x18 Size: 0x8

};


}