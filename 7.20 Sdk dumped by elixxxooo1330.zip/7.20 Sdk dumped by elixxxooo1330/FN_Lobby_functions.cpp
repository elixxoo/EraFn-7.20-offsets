#include "../SDK.hpp"

void ALobbyBeaconClient::ServerSetPartyOwner(struct FUniqueNetIdRepl InUniqueId, struct FUniqueNetIdRepl InPartyOwnerId)
{
	struct {
            struct FUniqueNetIdRepl InUniqueId;
            struct FUniqueNetIdRepl InPartyOwnerId;
	} params{ InUniqueId, InPartyOwnerId };

    static auto fn = UObject::FindObject("/Script/Lobby.LobbyBeaconClient:ServerSetPartyOwner");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ALobbyBeaconClient::ServerNotifyJoiningServer()
{
    static auto fn = UObject::FindObject("/Script/Lobby.LobbyBeaconClient:ServerNotifyJoiningServer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void ALobbyBeaconClient::ServerLoginPlayer(struct FString InSessionId, struct FUniqueNetIdRepl InUniqueId, struct FString UrlString)
{
	struct {
            struct FString InSessionId;
            struct FUniqueNetIdRepl InUniqueId;
            struct FString UrlString;
	} params{ InSessionId, InUniqueId, UrlString };

    static auto fn = UObject::FindObject("/Script/Lobby.LobbyBeaconClient:ServerLoginPlayer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ALobbyBeaconClient::ServerKickPlayer(struct FUniqueNetIdRepl PlayerToKick, struct FText Reason)
{
	struct {
            struct FUniqueNetIdRepl PlayerToKick;
            struct FText Reason;
	} params{ PlayerToKick, Reason };

    static auto fn = UObject::FindObject("/Script/Lobby.LobbyBeaconClient:ServerKickPlayer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ALobbyBeaconClient::ServerDisconnectFromLobby()
{
    static auto fn = UObject::FindObject("/Script/Lobby.LobbyBeaconClient:ServerDisconnectFromLobby");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void ALobbyBeaconClient::ServerCheat(struct FString Msg)
{
	struct {
            struct FString Msg;
	} params{ Msg };

    static auto fn = UObject::FindObject("/Script/Lobby.LobbyBeaconClient:ServerCheat");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ALobbyBeaconClient::ClientWasKicked(struct FText KickReason)
{
	struct {
            struct FText KickReason;
	} params{ KickReason };

    static auto fn = UObject::FindObject("/Script/Lobby.LobbyBeaconClient:ClientWasKicked");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ALobbyBeaconClient::ClientSetInviteFlags(struct FJoinabilitySettings Settings)
{
	struct {
            struct FJoinabilitySettings Settings;
	} params{ Settings };

    static auto fn = UObject::FindObject("/Script/Lobby.LobbyBeaconClient:ClientSetInviteFlags");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ALobbyBeaconClient::ClientPlayerLeft(struct FUniqueNetIdRepl InUniqueId)
{
	struct {
            struct FUniqueNetIdRepl InUniqueId;
	} params{ InUniqueId };

    static auto fn = UObject::FindObject("/Script/Lobby.LobbyBeaconClient:ClientPlayerLeft");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ALobbyBeaconClient::ClientPlayerJoined(struct FText NewPlayerName, struct FUniqueNetIdRepl InUniqueId)
{
	struct {
            struct FText NewPlayerName;
            struct FUniqueNetIdRepl InUniqueId;
	} params{ NewPlayerName, InUniqueId };

    static auto fn = UObject::FindObject("/Script/Lobby.LobbyBeaconClient:ClientPlayerJoined");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ALobbyBeaconClient::ClientLoginComplete(struct FUniqueNetIdRepl InUniqueId, bool bWasSuccessful)
{
	struct {
            struct FUniqueNetIdRepl InUniqueId;
            bool bWasSuccessful;
	} params{ InUniqueId, bWasSuccessful };

    static auto fn = UObject::FindObject("/Script/Lobby.LobbyBeaconClient:ClientLoginComplete");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ALobbyBeaconClient::ClientJoinGame()
{
    static auto fn = UObject::FindObject("/Script/Lobby.LobbyBeaconClient:ClientJoinGame");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void ALobbyBeaconClient::ClientAckJoiningServer()
{
    static auto fn = UObject::FindObject("/Script/Lobby.LobbyBeaconClient:ClientAckJoiningServer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

void ALobbyBeaconPlayerState::OnRep_PartyOwner()
{
    static auto fn = UObject::FindObject("/Script/Lobby.LobbyBeaconPlayerState:OnRep_PartyOwner");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void ALobbyBeaconPlayerState::OnRep_InLobby()
{
    static auto fn = UObject::FindObject("/Script/Lobby.LobbyBeaconPlayerState:OnRep_InLobby");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

void ALobbyBeaconState::OnRep_WaitForPlayersTimeRemaining()
{
    static auto fn = UObject::FindObject("/Script/Lobby.LobbyBeaconState:OnRep_WaitForPlayersTimeRemaining");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void ALobbyBeaconState::OnRep_LobbyStarted()
{
    static auto fn = UObject::FindObject("/Script/Lobby.LobbyBeaconState:OnRep_LobbyStarted");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

