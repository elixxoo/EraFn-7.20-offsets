#include "../SDK.hpp"

static bool UAbilitySystemBlueprintLibrary::TargetDataHasOrigin(struct FGameplayAbilityTargetDataHandle TargetData, int Index)
{
	struct {
            struct FGameplayAbilityTargetDataHandle TargetData;
            int Index;
            bool ReturnValue;
	} params{ TargetData, Index };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:TargetDataHasOrigin");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAbilitySystemBlueprintLibrary::TargetDataHasHitResult(struct FGameplayAbilityTargetDataHandle HitResult, int Index)
{
	struct {
            struct FGameplayAbilityTargetDataHandle HitResult;
            int Index;
            bool ReturnValue;
	} params{ HitResult, Index };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:TargetDataHasHitResult");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAbilitySystemBlueprintLibrary::TargetDataHasEndPoint(struct FGameplayAbilityTargetDataHandle TargetData, int Index)
{
	struct {
            struct FGameplayAbilityTargetDataHandle TargetData;
            int Index;
            bool ReturnValue;
	} params{ TargetData, Index };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:TargetDataHasEndPoint");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAbilitySystemBlueprintLibrary::TargetDataHasActor(struct FGameplayAbilityTargetDataHandle TargetData, int Index)
{
	struct {
            struct FGameplayAbilityTargetDataHandle TargetData;
            int Index;
            bool ReturnValue;
	} params{ TargetData, Index };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:TargetDataHasActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayEffectSpecHandle UAbilitySystemBlueprintLibrary::SetStackCountToMax(struct FGameplayEffectSpecHandle SpecHandle)
{
	struct {
            struct FGameplayEffectSpecHandle SpecHandle;
            struct FGameplayEffectSpecHandle ReturnValue;
	} params{ SpecHandle };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:SetStackCountToMax");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayEffectSpecHandle UAbilitySystemBlueprintLibrary::SetStackCount(struct FGameplayEffectSpecHandle SpecHandle, int StackCount)
{
	struct {
            struct FGameplayEffectSpecHandle SpecHandle;
            int StackCount;
            struct FGameplayEffectSpecHandle ReturnValue;
	} params{ SpecHandle, StackCount };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:SetStackCount");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayEffectSpecHandle UAbilitySystemBlueprintLibrary::SetDuration(struct FGameplayEffectSpecHandle SpecHandle, float Duration)
{
	struct {
            struct FGameplayEffectSpecHandle SpecHandle;
            float Duration;
            struct FGameplayEffectSpecHandle ReturnValue;
	} params{ SpecHandle, Duration };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:SetDuration");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAbilitySystemBlueprintLibrary::SendGameplayEventToActor(class AActor* Actor, struct FGameplayTag EventTag, struct FGameplayEventData Payload)
{
	struct {
            class AActor* Actor;
            struct FGameplayTag EventTag;
            struct FGameplayEventData Payload;            void ReturnValue;
	} params{ Actor, EventTag, Payload };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:SendGameplayEventToActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAbilitySystemBlueprintLibrary::NotEqual_GameplayAttributeGameplayAttribute(struct FGameplayAttribute AttributeA, struct FGameplayAttribute AttributeB)
{
	struct {
            struct FGameplayAttribute AttributeA;
            struct FGameplayAttribute AttributeB;
            bool ReturnValue;
	} params{ AttributeA, AttributeB };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:NotEqual_GameplayAttributeGameplayAttribute");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayEffectSpecHandle UAbilitySystemBlueprintLibrary::MakeSpecHandle(class UGameplayEffect* InGameplayEffect, class AActor* InInstigator, class AActor* InEffectCauser, float InLevel)
{
	struct {
            class UGameplayEffect* InGameplayEffect;
            class AActor* InInstigator;
            class AActor* InEffectCauser;
            float InLevel;
            struct FGameplayEffectSpecHandle ReturnValue;
	} params{ InGameplayEffect, InInstigator, InEffectCauser, InLevel };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:MakeSpecHandle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayTargetDataFilterHandle UAbilitySystemBlueprintLibrary::MakeFilterHandle(struct FGameplayTargetDataFilter Filter, class AActor* FilterActor)
{
	struct {
            struct FGameplayTargetDataFilter Filter;
            class AActor* FilterActor;
            struct FGameplayTargetDataFilterHandle ReturnValue;
	} params{ Filter, FilterActor };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:MakeFilterHandle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAbilitySystemBlueprintLibrary::IsValid(struct FGameplayAttribute Attribute)
{
	struct {
            struct FGameplayAttribute Attribute;
            bool ReturnValue;
	} params{ Attribute };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:IsValid");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAbilitySystemBlueprintLibrary::IsInstigatorLocallyControlledPlayer(struct FGameplayCueParameters Parameters)
{
	struct {
            struct FGameplayCueParameters Parameters;
            bool ReturnValue;
	} params{ Parameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:IsInstigatorLocallyControlledPlayer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAbilitySystemBlueprintLibrary::IsInstigatorLocallyControlled(struct FGameplayCueParameters Parameters)
{
	struct {
            struct FGameplayCueParameters Parameters;
            bool ReturnValue;
	} params{ Parameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:IsInstigatorLocallyControlled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAbilitySystemBlueprintLibrary::HasHitResult(struct FGameplayCueParameters Parameters)
{
	struct {
            struct FGameplayCueParameters Parameters;
            bool ReturnValue;
	} params{ Parameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:HasHitResult");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FTransform UAbilitySystemBlueprintLibrary::GetTargetDataOrigin(struct FGameplayAbilityTargetDataHandle TargetData, int Index)
{
	struct {
            struct FGameplayAbilityTargetDataHandle TargetData;
            int Index;
            struct FTransform ReturnValue;
	} params{ TargetData, Index };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetTargetDataOrigin");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FTransform UAbilitySystemBlueprintLibrary::GetTargetDataEndPointTransform(struct FGameplayAbilityTargetDataHandle TargetData, int Index)
{
	struct {
            struct FGameplayAbilityTargetDataHandle TargetData;
            int Index;
            struct FTransform ReturnValue;
	} params{ TargetData, Index };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetTargetDataEndPointTransform");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FVector UAbilitySystemBlueprintLibrary::GetTargetDataEndPoint(struct FGameplayAbilityTargetDataHandle TargetData, int Index)
{
	struct {
            struct FGameplayAbilityTargetDataHandle TargetData;
            int Index;
            struct FVector ReturnValue;
	} params{ TargetData, Index };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetTargetDataEndPoint");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FVector UAbilitySystemBlueprintLibrary::GetOrigin(struct FGameplayCueParameters Parameters)
{
	struct {
            struct FGameplayCueParameters Parameters;
            struct FVector ReturnValue;
	} params{ Parameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetOrigin");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static float UAbilitySystemBlueprintLibrary::GetModifiedAttributeMagnitude(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayAttribute Attribute)
{
	struct {
            struct FGameplayEffectSpecHandle SpecHandle;
            struct FGameplayAttribute Attribute;
            float ReturnValue;
	} params{ SpecHandle, Attribute };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetModifiedAttributeMagnitude");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FTransform UAbilitySystemBlueprintLibrary::GetInstigatorTransform(struct FGameplayCueParameters Parameters)
{
	struct {
            struct FGameplayCueParameters Parameters;
            struct FTransform ReturnValue;
	} params{ Parameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetInstigatorTransform");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class AActor* UAbilitySystemBlueprintLibrary::GetInstigatorActor(struct FGameplayCueParameters Parameters)
{
	struct {
            struct FGameplayCueParameters Parameters;
            class AActor* ReturnValue;
	} params{ Parameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetInstigatorActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FHitResult UAbilitySystemBlueprintLibrary::GetHitResultFromTargetData(struct FGameplayAbilityTargetDataHandle HitResult, int Index)
{
	struct {
            struct FGameplayAbilityTargetDataHandle HitResult;
            int Index;
            struct FHitResult ReturnValue;
	} params{ HitResult, Index };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetHitResultFromTargetData");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FHitResult UAbilitySystemBlueprintLibrary::GetHitResult(struct FGameplayCueParameters Parameters)
{
	struct {
            struct FGameplayCueParameters Parameters;
            struct FHitResult ReturnValue;
	} params{ Parameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetHitResult");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAbilitySystemBlueprintLibrary::GetGameplayCueEndLocationAndNormal(class AActor* TargetActor, struct FGameplayCueParameters Parameters, struct FVector Location, struct FVector Normal)
{
	struct {
            class AActor* TargetActor;
            struct FGameplayCueParameters Parameters;
            struct FVector Location;
            struct FVector Normal;
            bool ReturnValue;
	} params{ TargetActor, Parameters, Location, Normal };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetGameplayCueEndLocationAndNormal");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAbilitySystemBlueprintLibrary::GetGameplayCueDirection(class AActor* TargetActor, struct FGameplayCueParameters Parameters, struct FVector Direction)
{
	struct {
            class AActor* TargetActor;
            struct FGameplayCueParameters Parameters;
            struct FVector Direction;
            bool ReturnValue;
	} params{ TargetActor, Parameters, Direction };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetGameplayCueDirection");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static float UAbilitySystemBlueprintLibrary::GetFloatAttributeFromAbilitySystemComponent(class UAbilitySystemComponent* AbilitySystem, struct FGameplayAttribute Attribute, bool bSuccessfullyFoundAttribute)
{
	struct {
            class UAbilitySystemComponent* AbilitySystem;
            struct FGameplayAttribute Attribute;
            bool bSuccessfullyFoundAttribute;
            float ReturnValue;
	} params{ AbilitySystem, Attribute, bSuccessfullyFoundAttribute };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetFloatAttributeFromAbilitySystemComponent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static float UAbilitySystemBlueprintLibrary::GetFloatAttributeBaseFromAbilitySystemComponent(class UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayAttribute Attribute, bool bSuccessfullyFoundAttribute)
{
	struct {
            class UAbilitySystemComponent* AbilitySystemComponent;
            struct FGameplayAttribute Attribute;
            bool bSuccessfullyFoundAttribute;
            float ReturnValue;
	} params{ AbilitySystemComponent, Attribute, bSuccessfullyFoundAttribute };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetFloatAttributeBaseFromAbilitySystemComponent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static float UAbilitySystemBlueprintLibrary::GetFloatAttributeBase(class AActor* Actor, struct FGameplayAttribute Attribute, bool bSuccessfullyFoundAttribute)
{
	struct {
            class AActor* Actor;
            struct FGameplayAttribute Attribute;
            bool bSuccessfullyFoundAttribute;
            float ReturnValue;
	} params{ Actor, Attribute, bSuccessfullyFoundAttribute };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetFloatAttributeBase");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static float UAbilitySystemBlueprintLibrary::GetFloatAttribute(class AActor* Actor, struct FGameplayAttribute Attribute, bool bSuccessfullyFoundAttribute)
{
	struct {
            class AActor* Actor;
            struct FGameplayAttribute Attribute;
            bool bSuccessfullyFoundAttribute;
            float ReturnValue;
	} params{ Actor, Attribute, bSuccessfullyFoundAttribute };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetFloatAttribute");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayEffectContextHandle UAbilitySystemBlueprintLibrary::GetEffectContext(struct FGameplayEffectSpecHandle SpecHandle)
{
	struct {
            struct FGameplayEffectSpecHandle SpecHandle;
            struct FGameplayEffectContextHandle ReturnValue;
	} params{ SpecHandle };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetEffectContext");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static int UAbilitySystemBlueprintLibrary::GetDataCountFromTargetData(struct FGameplayAbilityTargetDataHandle TargetData)
{
	struct {
            struct FGameplayAbilityTargetDataHandle TargetData;
            int ReturnValue;
	} params{ TargetData };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetDataCountFromTargetData");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static TArray<struct FGameplayEffectSpecHandle> UAbilitySystemBlueprintLibrary::GetAllLinkedGameplayEffectSpecHandles(struct FGameplayEffectSpecHandle SpecHandle)
{
	struct {
            struct FGameplayEffectSpecHandle SpecHandle;
            TArray<struct FGameplayEffectSpecHandle> ReturnValue;
	} params{ SpecHandle };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetAllLinkedGameplayEffectSpecHandles");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static TArray<class AActor*> UAbilitySystemBlueprintLibrary::GetAllActorsFromTargetData(struct FGameplayAbilityTargetDataHandle TargetData)
{
	struct {
            struct FGameplayAbilityTargetDataHandle TargetData;
            TArray<class AActor*> ReturnValue;
	} params{ TargetData };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetAllActorsFromTargetData");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static TArray<class AActor*> UAbilitySystemBlueprintLibrary::GetActorsFromTargetData(struct FGameplayAbilityTargetDataHandle TargetData, int Index)
{
	struct {
            struct FGameplayAbilityTargetDataHandle TargetData;
            int Index;
            TArray<class AActor*> ReturnValue;
	} params{ TargetData, Index };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetActorsFromTargetData");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static int UAbilitySystemBlueprintLibrary::GetActorCount(struct FGameplayCueParameters Parameters)
{
	struct {
            struct FGameplayCueParameters Parameters;
            int ReturnValue;
	} params{ Parameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetActorCount");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class AActor* UAbilitySystemBlueprintLibrary::GetActorByIndex(struct FGameplayCueParameters Parameters, int Index)
{
	struct {
            struct FGameplayCueParameters Parameters;
            int Index;
            class AActor* ReturnValue;
	} params{ Parameters, Index };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetActorByIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static float UAbilitySystemBlueprintLibrary::GetActiveGameplayEffectTotalDuration(struct FActiveGameplayEffectHandle ActiveHandle)
{
	struct {
            struct FActiveGameplayEffectHandle ActiveHandle;
            float ReturnValue;
	} params{ ActiveHandle };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetActiveGameplayEffectTotalDuration");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static float UAbilitySystemBlueprintLibrary::GetActiveGameplayEffectStartTime(struct FActiveGameplayEffectHandle ActiveHandle)
{
	struct {
            struct FActiveGameplayEffectHandle ActiveHandle;
            float ReturnValue;
	} params{ ActiveHandle };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetActiveGameplayEffectStartTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static int UAbilitySystemBlueprintLibrary::GetActiveGameplayEffectStackLimitCount(struct FActiveGameplayEffectHandle ActiveHandle)
{
	struct {
            struct FActiveGameplayEffectHandle ActiveHandle;
            int ReturnValue;
	} params{ ActiveHandle };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetActiveGameplayEffectStackLimitCount");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static int UAbilitySystemBlueprintLibrary::GetActiveGameplayEffectStackCount(struct FActiveGameplayEffectHandle ActiveHandle)
{
	struct {
            struct FActiveGameplayEffectHandle ActiveHandle;
            int ReturnValue;
	} params{ ActiveHandle };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetActiveGameplayEffectStackCount");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static float UAbilitySystemBlueprintLibrary::GetActiveGameplayEffectRemainingDuration(class UObject* WorldContextObject, struct FActiveGameplayEffectHandle ActiveHandle)
{
	struct {
            class UObject* WorldContextObject;
            struct FActiveGameplayEffectHandle ActiveHandle;
            float ReturnValue;
	} params{ WorldContextObject, ActiveHandle };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetActiveGameplayEffectRemainingDuration");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static float UAbilitySystemBlueprintLibrary::GetActiveGameplayEffectExpectedEndTime(struct FActiveGameplayEffectHandle ActiveHandle)
{
	struct {
            struct FActiveGameplayEffectHandle ActiveHandle;
            float ReturnValue;
	} params{ ActiveHandle };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetActiveGameplayEffectExpectedEndTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FString UAbilitySystemBlueprintLibrary::GetActiveGameplayEffectDebugString(struct FActiveGameplayEffectHandle ActiveHandle)
{
	struct {
            struct FActiveGameplayEffectHandle ActiveHandle;
            struct FString ReturnValue;
	} params{ ActiveHandle };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetActiveGameplayEffectDebugString");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UAbilitySystemComponent* UAbilitySystemBlueprintLibrary::GetAbilitySystemComponent(class AActor* Actor)
{
	struct {
            class AActor* Actor;
            class UAbilitySystemComponent* ReturnValue;
	} params{ Actor };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetAbilitySystemComponent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAbilitySystemBlueprintLibrary::ForwardGameplayCueToTarget(__int64/*InterfaceProperty*/ TargetCueInterface, char EventType, struct FGameplayCueParameters Parameters)
{
	struct {
            __int64/*InterfaceProperty*/ TargetCueInterface;
            char EventType;
            struct FGameplayCueParameters Parameters;            void ReturnValue;
	} params{ TargetCueInterface, EventType, Parameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:ForwardGameplayCueToTarget");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayAbilityTargetDataHandle UAbilitySystemBlueprintLibrary::FilterTargetData(struct FGameplayAbilityTargetDataHandle TargetDataHandle, struct FGameplayTargetDataFilterHandle ActorFilterClass)
{
	struct {
            struct FGameplayAbilityTargetDataHandle TargetDataHandle;
            struct FGameplayTargetDataFilterHandle ActorFilterClass;
            struct FGameplayAbilityTargetDataHandle ReturnValue;
	} params{ TargetDataHandle, ActorFilterClass };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:FilterTargetData");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static float UAbilitySystemBlueprintLibrary::EvaluateAttributeValueWithTagsAndBase(class UAbilitySystemComponent* AbilitySystem, struct FGameplayAttribute Attribute, struct FGameplayTagContainer SourceTags, struct FGameplayTagContainer TargetTags, float BaseValue, bool bSuccess)
{
	struct {
            class UAbilitySystemComponent* AbilitySystem;
            struct FGameplayAttribute Attribute;
            struct FGameplayTagContainer SourceTags;
            struct FGameplayTagContainer TargetTags;
            float BaseValue;
            bool bSuccess;
            float ReturnValue;
	} params{ AbilitySystem, Attribute, SourceTags, TargetTags, BaseValue, bSuccess };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:EvaluateAttributeValueWithTagsAndBase");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static float UAbilitySystemBlueprintLibrary::EvaluateAttributeValueWithTags(class UAbilitySystemComponent* AbilitySystem, struct FGameplayAttribute Attribute, struct FGameplayTagContainer SourceTags, struct FGameplayTagContainer TargetTags, bool bSuccess)
{
	struct {
            class UAbilitySystemComponent* AbilitySystem;
            struct FGameplayAttribute Attribute;
            struct FGameplayTagContainer SourceTags;
            struct FGameplayTagContainer TargetTags;
            bool bSuccess;
            float ReturnValue;
	} params{ AbilitySystem, Attribute, SourceTags, TargetTags, bSuccess };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:EvaluateAttributeValueWithTags");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAbilitySystemBlueprintLibrary::EqualEqual_GameplayAttributeGameplayAttribute(struct FGameplayAttribute AttributeA, struct FGameplayAttribute AttributeB)
{
	struct {
            struct FGameplayAttribute AttributeA;
            struct FGameplayAttribute AttributeB;
            bool ReturnValue;
	} params{ AttributeA, AttributeB };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:EqualEqual_GameplayAttributeGameplayAttribute");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAbilitySystemBlueprintLibrary::EffectContextSetOrigin(struct FGameplayEffectContextHandle EffectContext, struct FVector Origin)
{
	struct {
            struct FGameplayEffectContextHandle EffectContext;
            struct FVector Origin;            void ReturnValue;
	} params{ EffectContext, Origin };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:EffectContextSetOrigin");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAbilitySystemBlueprintLibrary::EffectContextIsValid(struct FGameplayEffectContextHandle EffectContext)
{
	struct {
            struct FGameplayEffectContextHandle EffectContext;
            bool ReturnValue;
	} params{ EffectContext };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:EffectContextIsValid");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAbilitySystemBlueprintLibrary::EffectContextIsInstigatorLocallyControlled(struct FGameplayEffectContextHandle EffectContext)
{
	struct {
            struct FGameplayEffectContextHandle EffectContext;
            bool ReturnValue;
	} params{ EffectContext };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:EffectContextIsInstigatorLocallyControlled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAbilitySystemBlueprintLibrary::EffectContextHasHitResult(struct FGameplayEffectContextHandle EffectContext)
{
	struct {
            struct FGameplayEffectContextHandle EffectContext;
            bool ReturnValue;
	} params{ EffectContext };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:EffectContextHasHitResult");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UObject* UAbilitySystemBlueprintLibrary::EffectContextGetSourceObject(struct FGameplayEffectContextHandle EffectContext)
{
	struct {
            struct FGameplayEffectContextHandle EffectContext;
            class UObject* ReturnValue;
	} params{ EffectContext };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:EffectContextGetSourceObject");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class AActor* UAbilitySystemBlueprintLibrary::EffectContextGetOriginalInstigatorActor(struct FGameplayEffectContextHandle EffectContext)
{
	struct {
            struct FGameplayEffectContextHandle EffectContext;
            class AActor* ReturnValue;
	} params{ EffectContext };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:EffectContextGetOriginalInstigatorActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FVector UAbilitySystemBlueprintLibrary::EffectContextGetOrigin(struct FGameplayEffectContextHandle EffectContext)
{
	struct {
            struct FGameplayEffectContextHandle EffectContext;
            struct FVector ReturnValue;
	} params{ EffectContext };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:EffectContextGetOrigin");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class AActor* UAbilitySystemBlueprintLibrary::EffectContextGetInstigatorActor(struct FGameplayEffectContextHandle EffectContext)
{
	struct {
            struct FGameplayEffectContextHandle EffectContext;
            class AActor* ReturnValue;
	} params{ EffectContext };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:EffectContextGetInstigatorActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FHitResult UAbilitySystemBlueprintLibrary::EffectContextGetHitResult(struct FGameplayEffectContextHandle EffectContext)
{
	struct {
            struct FGameplayEffectContextHandle EffectContext;
            struct FHitResult ReturnValue;
	} params{ EffectContext };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:EffectContextGetHitResult");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class AActor* UAbilitySystemBlueprintLibrary::EffectContextGetEffectCauser(struct FGameplayEffectContextHandle EffectContext)
{
	struct {
            struct FGameplayEffectContextHandle EffectContext;
            class AActor* ReturnValue;
	} params{ EffectContext };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:EffectContextGetEffectCauser");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAbilitySystemBlueprintLibrary::EffectContextAddHitResult(struct FGameplayEffectContextHandle EffectContext, struct FHitResult HitResult, bool bReset)
{
	struct {
            struct FGameplayEffectContextHandle EffectContext;
            struct FHitResult HitResult;
            bool bReset;            void ReturnValue;
	} params{ EffectContext, HitResult, bReset };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:EffectContextAddHitResult");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAbilitySystemBlueprintLibrary::DoesTargetDataContainActor(struct FGameplayAbilityTargetDataHandle TargetData, int Index, class AActor* Actor)
{
	struct {
            struct FGameplayAbilityTargetDataHandle TargetData;
            int Index;
            class AActor* Actor;
            bool ReturnValue;
	} params{ TargetData, Index, Actor };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:DoesTargetDataContainActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAbilitySystemBlueprintLibrary::DoesGameplayCueMeetTagRequirements(struct FGameplayCueParameters Parameters, struct FGameplayTagRequirements SourceTagReqs, struct FGameplayTagRequirements TargetTagReqs)
{
	struct {
            struct FGameplayCueParameters Parameters;
            struct FGameplayTagRequirements SourceTagReqs;
            struct FGameplayTagRequirements TargetTagReqs;
            bool ReturnValue;
	} params{ Parameters, SourceTagReqs, TargetTagReqs };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:DoesGameplayCueMeetTagRequirements");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayEffectSpecHandle UAbilitySystemBlueprintLibrary::CloneSpecHandle(class AActor* InNewInstigator, class AActor* InEffectCauser, struct FGameplayEffectSpecHandle GameplayEffectSpecHandle_Clone)
{
	struct {
            class AActor* InNewInstigator;
            class AActor* InEffectCauser;
            struct FGameplayEffectSpecHandle GameplayEffectSpecHandle_Clone;
            struct FGameplayEffectSpecHandle ReturnValue;
	} params{ InNewInstigator, InEffectCauser, GameplayEffectSpecHandle_Clone };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:CloneSpecHandle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayEffectSpecHandle UAbilitySystemBlueprintLibrary::AssignTagSetByCallerMagnitude(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTag DataTag, float Magnitude)
{
	struct {
            struct FGameplayEffectSpecHandle SpecHandle;
            struct FGameplayTag DataTag;
            float Magnitude;
            struct FGameplayEffectSpecHandle ReturnValue;
	} params{ SpecHandle, DataTag, Magnitude };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:AssignTagSetByCallerMagnitude");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayEffectSpecHandle UAbilitySystemBlueprintLibrary::AssignSetByCallerMagnitude(struct FGameplayEffectSpecHandle SpecHandle, FName DataName, float Magnitude)
{
	struct {
            struct FGameplayEffectSpecHandle SpecHandle;
            FName DataName;
            float Magnitude;
            struct FGameplayEffectSpecHandle ReturnValue;
	} params{ SpecHandle, DataName, Magnitude };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:AssignSetByCallerMagnitude");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayAbilityTargetDataHandle UAbilitySystemBlueprintLibrary::AppendTargetDataHandle(struct FGameplayAbilityTargetDataHandle TargetHandle, struct FGameplayAbilityTargetDataHandle HandleToAdd)
{
	struct {
            struct FGameplayAbilityTargetDataHandle TargetHandle;
            struct FGameplayAbilityTargetDataHandle HandleToAdd;
            struct FGameplayAbilityTargetDataHandle ReturnValue;
	} params{ TargetHandle, HandleToAdd };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:AppendTargetDataHandle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayEffectSpecHandle UAbilitySystemBlueprintLibrary::AddLinkedGameplayEffectSpec(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayEffectSpecHandle LinkedGameplayEffectSpec)
{
	struct {
            struct FGameplayEffectSpecHandle SpecHandle;
            struct FGameplayEffectSpecHandle LinkedGameplayEffectSpec;
            struct FGameplayEffectSpecHandle ReturnValue;
	} params{ SpecHandle, LinkedGameplayEffectSpec };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:AddLinkedGameplayEffectSpec");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayEffectSpecHandle UAbilitySystemBlueprintLibrary::AddLinkedGameplayEffect(struct FGameplayEffectSpecHandle SpecHandle, class UGameplayEffect* LinkedGameplayEffect)
{
	struct {
            struct FGameplayEffectSpecHandle SpecHandle;
            class UGameplayEffect* LinkedGameplayEffect;
            struct FGameplayEffectSpecHandle ReturnValue;
	} params{ SpecHandle, LinkedGameplayEffect };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:AddLinkedGameplayEffect");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayEffectSpecHandle UAbilitySystemBlueprintLibrary::AddGrantedTags(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTagContainer NewGameplayTags)
{
	struct {
            struct FGameplayEffectSpecHandle SpecHandle;
            struct FGameplayTagContainer NewGameplayTags;
            struct FGameplayEffectSpecHandle ReturnValue;
	} params{ SpecHandle, NewGameplayTags };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:AddGrantedTags");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayEffectSpecHandle UAbilitySystemBlueprintLibrary::AddGrantedTag(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTag NewGameplayTag)
{
	struct {
            struct FGameplayEffectSpecHandle SpecHandle;
            struct FGameplayTag NewGameplayTag;
            struct FGameplayEffectSpecHandle ReturnValue;
	} params{ SpecHandle, NewGameplayTag };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:AddGrantedTag");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayEffectSpecHandle UAbilitySystemBlueprintLibrary::AddAssetTags(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTagContainer NewGameplayTags)
{
	struct {
            struct FGameplayEffectSpecHandle SpecHandle;
            struct FGameplayTagContainer NewGameplayTags;
            struct FGameplayEffectSpecHandle ReturnValue;
	} params{ SpecHandle, NewGameplayTags };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:AddAssetTags");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayEffectSpecHandle UAbilitySystemBlueprintLibrary::AddAssetTag(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTag NewGameplayTag)
{
	struct {
            struct FGameplayEffectSpecHandle SpecHandle;
            struct FGameplayTag NewGameplayTag;
            struct FGameplayEffectSpecHandle ReturnValue;
	} params{ SpecHandle, NewGameplayTag };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:AddAssetTag");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayAbilityTargetDataHandle UAbilitySystemBlueprintLibrary::AbilityTargetDataFromLocations(struct FGameplayAbilityTargetingLocationInfo SourceLocation, struct FGameplayAbilityTargetingLocationInfo TargetLocation)
{
	struct {
            struct FGameplayAbilityTargetingLocationInfo SourceLocation;
            struct FGameplayAbilityTargetingLocationInfo TargetLocation;
            struct FGameplayAbilityTargetDataHandle ReturnValue;
	} params{ SourceLocation, TargetLocation };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:AbilityTargetDataFromLocations");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayAbilityTargetDataHandle UAbilitySystemBlueprintLibrary::AbilityTargetDataFromHitResult(struct FHitResult HitResult)
{
	struct {
            struct FHitResult HitResult;
            struct FGameplayAbilityTargetDataHandle ReturnValue;
	} params{ HitResult };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:AbilityTargetDataFromHitResult");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayAbilityTargetDataHandle UAbilitySystemBlueprintLibrary::AbilityTargetDataFromActorArray(TArray<class AActor*> ActorArray, bool OneTargetPerHandle)
{
	struct {
            TArray<class AActor*> ActorArray;
            bool OneTargetPerHandle;
            struct FGameplayAbilityTargetDataHandle ReturnValue;
	} params{ ActorArray, OneTargetPerHandle };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:AbilityTargetDataFromActorArray");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGameplayAbilityTargetDataHandle UAbilitySystemBlueprintLibrary::AbilityTargetDataFromActor(class AActor* Actor)
{
	struct {
            class AActor* Actor;
            struct FGameplayAbilityTargetDataHandle ReturnValue;
	} params{ Actor };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:AbilityTargetDataFromActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

bool UAbilitySystemComponent::TryActivateAbilityByClass(class UGameplayAbility* InAbilityToActivate, bool bAllowRemoteActivation)
{
	struct {
            class UGameplayAbility* InAbilityToActivate;
            bool bAllowRemoteActivation;
            bool ReturnValue;
	} params{ InAbilityToActivate, bAllowRemoteActivation };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:TryActivateAbilityByClass");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UAbilitySystemComponent::TryActivateAbilitiesByTag(struct FGameplayTagContainer GameplayTagContainer, bool bAllowRemoteActivation)
{
	struct {
            struct FGameplayTagContainer GameplayTagContainer;
            bool bAllowRemoteActivation;
            bool ReturnValue;
	} params{ GameplayTagContainer, bAllowRemoteActivation };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:TryActivateAbilitiesByTag");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UAbilitySystemComponent::TargetConfirm()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:TargetConfirm");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UAbilitySystemComponent::TargetCancel()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:TargetCancel");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UAbilitySystemComponent::SetUserAbilityActivationInhibited(bool NewInhibit)
{
	struct {
            bool NewInhibit;
	} params{ NewInhibit };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:SetUserAbilityActivationInhibited");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::SetActiveGameplayEffectLevelUsingQuery(struct FGameplayEffectQuery Query, int NewLevel)
{
	struct {
            struct FGameplayEffectQuery Query;
            int NewLevel;
	} params{ Query, NewLevel };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:SetActiveGameplayEffectLevelUsingQuery");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::SetActiveGameplayEffectLevel(struct FActiveGameplayEffectHandle ActiveHandle, int NewLevel)
{
	struct {
            struct FActiveGameplayEffectHandle ActiveHandle;
            int NewLevel;
	} params{ ActiveHandle, NewLevel };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:SetActiveGameplayEffectLevel");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::ServerTryActivateAbilityWithEventData(struct FGameplayAbilitySpecHandle AbilityToActivate, bool InputPressed, struct FPredictionKey PredictionKey, struct FGameplayEventData TriggerEventData)
{
	struct {
            struct FGameplayAbilitySpecHandle AbilityToActivate;
            bool InputPressed;
            struct FPredictionKey PredictionKey;
            struct FGameplayEventData TriggerEventData;
	} params{ AbilityToActivate, InputPressed, PredictionKey, TriggerEventData };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ServerTryActivateAbilityWithEventData");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::ServerTryActivateAbility(struct FGameplayAbilitySpecHandle AbilityToActivate, bool InputPressed, struct FPredictionKey PredictionKey)
{
	struct {
            struct FGameplayAbilitySpecHandle AbilityToActivate;
            bool InputPressed;
            struct FPredictionKey PredictionKey;
	} params{ AbilityToActivate, InputPressed, PredictionKey };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ServerTryActivateAbility");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::ServerSetReplicatedTargetDataCancelled(struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FPredictionKey CurrentPredictionKey)
{
	struct {
            struct FGameplayAbilitySpecHandle AbilityHandle;
            struct FPredictionKey AbilityOriginalPredictionKey;
            struct FPredictionKey CurrentPredictionKey;
	} params{ AbilityHandle, AbilityOriginalPredictionKey, CurrentPredictionKey };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ServerSetReplicatedTargetDataCancelled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::ServerSetReplicatedTargetData(struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FGameplayAbilityTargetDataHandle ReplicatedTargetDataHandle, struct FGameplayTag ApplicationTag, struct FPredictionKey CurrentPredictionKey)
{
	struct {
            struct FGameplayAbilitySpecHandle AbilityHandle;
            struct FPredictionKey AbilityOriginalPredictionKey;
            struct FGameplayAbilityTargetDataHandle ReplicatedTargetDataHandle;
            struct FGameplayTag ApplicationTag;
            struct FPredictionKey CurrentPredictionKey;
	} params{ AbilityHandle, AbilityOriginalPredictionKey, ReplicatedTargetDataHandle, ApplicationTag, CurrentPredictionKey };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ServerSetReplicatedTargetData");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::ServerSetReplicatedEventWithPayload(char EventType, struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FPredictionKey CurrentPredictionKey, struct FVector_NetQuantize100 VectorPayload)
{
	struct {
            char EventType;
            struct FGameplayAbilitySpecHandle AbilityHandle;
            struct FPredictionKey AbilityOriginalPredictionKey;
            struct FPredictionKey CurrentPredictionKey;
            struct FVector_NetQuantize100 VectorPayload;
	} params{ EventType, AbilityHandle, AbilityOriginalPredictionKey, CurrentPredictionKey, VectorPayload };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ServerSetReplicatedEventWithPayload");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::ServerSetReplicatedEvent(char EventType, struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FPredictionKey CurrentPredictionKey)
{
	struct {
            char EventType;
            struct FGameplayAbilitySpecHandle AbilityHandle;
            struct FPredictionKey AbilityOriginalPredictionKey;
            struct FPredictionKey CurrentPredictionKey;
	} params{ EventType, AbilityHandle, AbilityOriginalPredictionKey, CurrentPredictionKey };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ServerSetReplicatedEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::ServerSetInputReleased(struct FGameplayAbilitySpecHandle AbilityHandle)
{
	struct {
            struct FGameplayAbilitySpecHandle AbilityHandle;
	} params{ AbilityHandle };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ServerSetInputReleased");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::ServerSetInputPressed(struct FGameplayAbilitySpecHandle AbilityHandle)
{
	struct {
            struct FGameplayAbilitySpecHandle AbilityHandle;
	} params{ AbilityHandle };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ServerSetInputPressed");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::ServerPrintDebug_RequestWithStrings(TArray<struct FString> Strings)
{
	struct {
            TArray<struct FString> Strings;
	} params{ Strings };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ServerPrintDebug_RequestWithStrings");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::ServerPrintDebug_Request()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ServerPrintDebug_Request");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UAbilitySystemComponent::ServerEndAbility(struct FGameplayAbilitySpecHandle AbilityToEnd, struct FGameplayAbilityActivationInfo ActivationInfo, struct FPredictionKey PredictionKey)
{
	struct {
            struct FGameplayAbilitySpecHandle AbilityToEnd;
            struct FGameplayAbilityActivationInfo ActivationInfo;
            struct FPredictionKey PredictionKey;
	} params{ AbilityToEnd, ActivationInfo, PredictionKey };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ServerEndAbility");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::ServerCurrentMontageSetPlayRate(class UAnimMontage* ClientAnimMontage, float InPlayRate)
{
	struct {
            class UAnimMontage* ClientAnimMontage;
            float InPlayRate;
	} params{ ClientAnimMontage, InPlayRate };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ServerCurrentMontageSetPlayRate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::ServerCurrentMontageSetNextSectionName(class UAnimMontage* ClientAnimMontage, float ClientPosition, FName SectionName, FName NextSectionName)
{
	struct {
            class UAnimMontage* ClientAnimMontage;
            float ClientPosition;
            FName SectionName;
            FName NextSectionName;
	} params{ ClientAnimMontage, ClientPosition, SectionName, NextSectionName };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ServerCurrentMontageSetNextSectionName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::ServerCurrentMontageJumpToSectionName(class UAnimMontage* ClientAnimMontage, FName SectionName)
{
	struct {
            class UAnimMontage* ClientAnimMontage;
            FName SectionName;
	} params{ ClientAnimMontage, SectionName };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ServerCurrentMontageJumpToSectionName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::ServerCancelAbility(struct FGameplayAbilitySpecHandle AbilityToCancel, struct FGameplayAbilityActivationInfo ActivationInfo)
{
	struct {
            struct FGameplayAbilitySpecHandle AbilityToCancel;
            struct FGameplayAbilityActivationInfo ActivationInfo;
	} params{ AbilityToCancel, ActivationInfo };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ServerCancelAbility");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::ServerAbilityRPCBatch(struct FServerAbilityRPCBatch BatchInfo)
{
	struct {
            struct FServerAbilityRPCBatch BatchInfo;
	} params{ BatchInfo };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ServerAbilityRPCBatch");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::RemoveActiveGameplayEffectBySourceEffect(class UGameplayEffect* GameplayEffect, class UAbilitySystemComponent* InstigatorAbilitySystemComponent, int StacksToRemove)
{
	struct {
            class UGameplayEffect* GameplayEffect;
            class UAbilitySystemComponent* InstigatorAbilitySystemComponent;
            int StacksToRemove;
	} params{ GameplayEffect, InstigatorAbilitySystemComponent, StacksToRemove };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:RemoveActiveGameplayEffectBySourceEffect");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UAbilitySystemComponent::RemoveActiveGameplayEffect(struct FActiveGameplayEffectHandle Handle, int StacksToRemove)
{
	struct {
            struct FActiveGameplayEffectHandle Handle;
            int StacksToRemove;
            bool ReturnValue;
	} params{ Handle, StacksToRemove };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:RemoveActiveGameplayEffect");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


int UAbilitySystemComponent::RemoveActiveEffectsWithTags(struct FGameplayTagContainer Tags)
{
	struct {
            struct FGameplayTagContainer Tags;
            int ReturnValue;
	} params{ Tags };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:RemoveActiveEffectsWithTags");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


int UAbilitySystemComponent::RemoveActiveEffectsWithSourceTags(struct FGameplayTagContainer Tags)
{
	struct {
            struct FGameplayTagContainer Tags;
            int ReturnValue;
	} params{ Tags };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:RemoveActiveEffectsWithSourceTags");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


int UAbilitySystemComponent::RemoveActiveEffectsWithGrantedTags(struct FGameplayTagContainer Tags)
{
	struct {
            struct FGameplayTagContainer Tags;
            int ReturnValue;
	} params{ Tags };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:RemoveActiveEffectsWithGrantedTags");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


int UAbilitySystemComponent::RemoveActiveEffectsWithAppliedTags(struct FGameplayTagContainer Tags)
{
	struct {
            struct FGameplayTagContainer Tags;
            int ReturnValue;
	} params{ Tags };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:RemoveActiveEffectsWithAppliedTags");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UAbilitySystemComponent::OnRep_ServerDebugString()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:OnRep_ServerDebugString");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UAbilitySystemComponent::OnRep_ReplicatedAnimMontage()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:OnRep_ReplicatedAnimMontage");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UAbilitySystemComponent::OnRep_OwningActor()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:OnRep_OwningActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UAbilitySystemComponent::OnRep_ClientDebugString()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:OnRep_ClientDebugString");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UAbilitySystemComponent::OnRep_ActivateAbilities()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:OnRep_ActivateAbilities");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UAbilitySystemComponent::NetMulticast_InvokeGameplayCuesExecuted_WithParams(struct FGameplayTagContainer GameplayCueTags, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters)
{
	struct {
            struct FGameplayTagContainer GameplayCueTags;
            struct FPredictionKey PredictionKey;
            struct FGameplayCueParameters GameplayCueParameters;
	} params{ GameplayCueTags, PredictionKey, GameplayCueParameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:NetMulticast_InvokeGameplayCuesExecuted_WithParams");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::NetMulticast_InvokeGameplayCuesExecuted(struct FGameplayTagContainer GameplayCueTags, struct FPredictionKey PredictionKey, struct FGameplayEffectContextHandle EffectContext)
{
	struct {
            struct FGameplayTagContainer GameplayCueTags;
            struct FPredictionKey PredictionKey;
            struct FGameplayEffectContextHandle EffectContext;
	} params{ GameplayCueTags, PredictionKey, EffectContext };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:NetMulticast_InvokeGameplayCuesExecuted");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::NetMulticast_InvokeGameplayCuesAddedAndWhileActive_WithParams(struct FGameplayTagContainer GameplayCueTags, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters)
{
	struct {
            struct FGameplayTagContainer GameplayCueTags;
            struct FPredictionKey PredictionKey;
            struct FGameplayCueParameters GameplayCueParameters;
	} params{ GameplayCueTags, PredictionKey, GameplayCueParameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:NetMulticast_InvokeGameplayCuesAddedAndWhileActive_WithParams");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::NetMulticast_InvokeGameplayCueExecuted_WithParams(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters)
{
	struct {
            struct FGameplayTag GameplayCueTag;
            struct FPredictionKey PredictionKey;
            struct FGameplayCueParameters GameplayCueParameters;
	} params{ GameplayCueTag, PredictionKey, GameplayCueParameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:NetMulticast_InvokeGameplayCueExecuted_WithParams");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::NetMulticast_InvokeGameplayCueExecuted_FromSpec(struct FGameplayEffectSpecForRPC Spec, struct FPredictionKey PredictionKey)
{
	struct {
            struct FGameplayEffectSpecForRPC Spec;
            struct FPredictionKey PredictionKey;
	} params{ Spec, PredictionKey };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:NetMulticast_InvokeGameplayCueExecuted_FromSpec");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::NetMulticast_InvokeGameplayCueExecuted(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayEffectContextHandle EffectContext)
{
	struct {
            struct FGameplayTag GameplayCueTag;
            struct FPredictionKey PredictionKey;
            struct FGameplayEffectContextHandle EffectContext;
	} params{ GameplayCueTag, PredictionKey, EffectContext };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:NetMulticast_InvokeGameplayCueExecuted");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::NetMulticast_InvokeGameplayCueAddedAndWhileActive_WithParams(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters)
{
	struct {
            struct FGameplayTag GameplayCueTag;
            struct FPredictionKey PredictionKey;
            struct FGameplayCueParameters GameplayCueParameters;
	} params{ GameplayCueTag, PredictionKey, GameplayCueParameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:NetMulticast_InvokeGameplayCueAddedAndWhileActive_WithParams");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::NetMulticast_InvokeGameplayCueAddedAndWhileActive_FromSpec(struct FGameplayEffectSpecForRPC Spec, struct FPredictionKey PredictionKey)
{
	struct {
            struct FGameplayEffectSpecForRPC Spec;
            struct FPredictionKey PredictionKey;
	} params{ Spec, PredictionKey };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:NetMulticast_InvokeGameplayCueAddedAndWhileActive_FromSpec");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::NetMulticast_InvokeGameplayCueAdded_WithParams(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayCueParameters Parameters)
{
	struct {
            struct FGameplayTag GameplayCueTag;
            struct FPredictionKey PredictionKey;
            struct FGameplayCueParameters Parameters;
	} params{ GameplayCueTag, PredictionKey, Parameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:NetMulticast_InvokeGameplayCueAdded_WithParams");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::NetMulticast_InvokeGameplayCueAdded(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayEffectContextHandle EffectContext)
{
	struct {
            struct FGameplayTag GameplayCueTag;
            struct FPredictionKey PredictionKey;
            struct FGameplayEffectContextHandle EffectContext;
	} params{ GameplayCueTag, PredictionKey, EffectContext };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:NetMulticast_InvokeGameplayCueAdded");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


struct FGameplayEffectSpecHandle UAbilitySystemComponent::MakeOutgoingSpec(class UGameplayEffect* GameplayEffectClass, float Level, struct FGameplayEffectContextHandle Context)
{
	struct {
            class UGameplayEffect* GameplayEffectClass;
            float Level;
            struct FGameplayEffectContextHandle Context;
            struct FGameplayEffectSpecHandle ReturnValue;
	} params{ GameplayEffectClass, Level, Context };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:MakeOutgoingSpec");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FGameplayEffectContextHandle UAbilitySystemComponent::MakeEffectContext()
{
	struct {
            struct FGameplayEffectContextHandle ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:MakeEffectContext");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UAbilitySystemComponent::K2_InitStats(class UAttributeSet* Attributes, class UDataTable* DataTable)
{
	struct {
            class UAttributeSet* Attributes;
            class UDataTable* DataTable;
	} params{ Attributes, DataTable };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:K2_InitStats");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UAbilitySystemComponent::IsGameplayCueActive(struct FGameplayTag GameplayCueTag)
{
	struct {
            struct FGameplayTag GameplayCueTag;
            bool ReturnValue;
	} params{ GameplayCueTag };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:IsGameplayCueActive");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UAbilitySystemComponent::GetUserAbilityActivationInhibited()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:GetUserAbilityActivationInhibited");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UAbilitySystemComponent::GetGameplayEffectMagnitude(struct FActiveGameplayEffectHandle Handle, struct FGameplayAttribute Attribute)
{
	struct {
            struct FActiveGameplayEffectHandle Handle;
            struct FGameplayAttribute Attribute;
            float ReturnValue;
	} params{ Handle, Attribute };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:GetGameplayEffectMagnitude");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


int UAbilitySystemComponent::GetGameplayEffectCount(class UGameplayEffect* SourceGameplayEffect, class UAbilitySystemComponent* OptionalInstigatorFilterComponent, bool bEnforceOnGoingCheck)
{
	struct {
            class UGameplayEffect* SourceGameplayEffect;
            class UAbilitySystemComponent* OptionalInstigatorFilterComponent;
            bool bEnforceOnGoingCheck;
            int ReturnValue;
	} params{ SourceGameplayEffect, OptionalInstigatorFilterComponent, bEnforceOnGoingCheck };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:GetGameplayEffectCount");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


TArray<struct FActiveGameplayEffectHandle> UAbilitySystemComponent::GetActiveEffects(struct FGameplayEffectQuery Query)
{
	struct {
            struct FGameplayEffectQuery Query;
            TArray<struct FActiveGameplayEffectHandle> ReturnValue;
	} params{ Query };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:GetActiveEffects");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UAbilitySystemComponent::ClientTryActivateAbility(struct FGameplayAbilitySpecHandle AbilityToActivate)
{
	struct {
            struct FGameplayAbilitySpecHandle AbilityToActivate;
	} params{ AbilityToActivate };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ClientTryActivateAbility");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::ClientSetReplicatedEvent(char EventType, struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey)
{
	struct {
            char EventType;
            struct FGameplayAbilitySpecHandle AbilityHandle;
            struct FPredictionKey AbilityOriginalPredictionKey;
	} params{ EventType, AbilityHandle, AbilityOriginalPredictionKey };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ClientSetReplicatedEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::ClientPrintDebug_Response(TArray<struct FString> Strings, int GameFlags)
{
	struct {
            TArray<struct FString> Strings;
            int GameFlags;
	} params{ Strings, GameFlags };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ClientPrintDebug_Response");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::ClientEndAbility(struct FGameplayAbilitySpecHandle AbilityToEnd, struct FGameplayAbilityActivationInfo ActivationInfo)
{
	struct {
            struct FGameplayAbilitySpecHandle AbilityToEnd;
            struct FGameplayAbilityActivationInfo ActivationInfo;
	} params{ AbilityToEnd, ActivationInfo };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ClientEndAbility");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::ClientCancelAbility(struct FGameplayAbilitySpecHandle AbilityToCancel, struct FGameplayAbilityActivationInfo ActivationInfo)
{
	struct {
            struct FGameplayAbilitySpecHandle AbilityToCancel;
            struct FGameplayAbilityActivationInfo ActivationInfo;
	} params{ AbilityToCancel, ActivationInfo };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ClientCancelAbility");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::ClientActivateAbilitySucceedWithEventData(struct FGameplayAbilitySpecHandle AbilityToActivate, struct FPredictionKey PredictionKey, struct FGameplayEventData TriggerEventData)
{
	struct {
            struct FGameplayAbilitySpecHandle AbilityToActivate;
            struct FPredictionKey PredictionKey;
            struct FGameplayEventData TriggerEventData;
	} params{ AbilityToActivate, PredictionKey, TriggerEventData };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ClientActivateAbilitySucceedWithEventData");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::ClientActivateAbilitySucceed(struct FGameplayAbilitySpecHandle AbilityToActivate, struct FPredictionKey PredictionKey)
{
	struct {
            struct FGameplayAbilitySpecHandle AbilityToActivate;
            struct FPredictionKey PredictionKey;
	} params{ AbilityToActivate, PredictionKey };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ClientActivateAbilitySucceed");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilitySystemComponent::ClientActivateAbilityFailed(struct FGameplayAbilitySpecHandle AbilityToActivate, int16_t PredictionKey)
{
	struct {
            struct FGameplayAbilitySpecHandle AbilityToActivate;
            int16_t PredictionKey;
	} params{ AbilityToActivate, PredictionKey };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:ClientActivateAbilityFailed");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


struct FActiveGameplayEffectHandle UAbilitySystemComponent::BP_ApplyGameplayEffectToTarget(class UGameplayEffect* GameplayEffectClass, class UAbilitySystemComponent* Target, float Level, struct FGameplayEffectContextHandle Context)
{
	struct {
            class UGameplayEffect* GameplayEffectClass;
            class UAbilitySystemComponent* Target;
            float Level;
            struct FGameplayEffectContextHandle Context;
            struct FActiveGameplayEffectHandle ReturnValue;
	} params{ GameplayEffectClass, Target, Level, Context };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:BP_ApplyGameplayEffectToTarget");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FActiveGameplayEffectHandle UAbilitySystemComponent::BP_ApplyGameplayEffectToSelf(class UGameplayEffect* GameplayEffectClass, float Level, struct FGameplayEffectContextHandle EffectContext)
{
	struct {
            class UGameplayEffect* GameplayEffectClass;
            float Level;
            struct FGameplayEffectContextHandle EffectContext;
            struct FActiveGameplayEffectHandle ReturnValue;
	} params{ GameplayEffectClass, Level, EffectContext };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:BP_ApplyGameplayEffectToSelf");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FActiveGameplayEffectHandle UAbilitySystemComponent::BP_ApplyGameplayEffectSpecToTarget(struct FGameplayEffectSpecHandle SpecHandle, class UAbilitySystemComponent* Target)
{
	struct {
            struct FGameplayEffectSpecHandle SpecHandle;
            class UAbilitySystemComponent* Target;
            struct FActiveGameplayEffectHandle ReturnValue;
	} params{ SpecHandle, Target };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:BP_ApplyGameplayEffectSpecToTarget");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FActiveGameplayEffectHandle UAbilitySystemComponent::BP_ApplyGameplayEffectSpecToSelf(struct FGameplayEffectSpecHandle SpecHandle)
{
	struct {
            struct FGameplayEffectSpecHandle SpecHandle;
            struct FActiveGameplayEffectHandle ReturnValue;
	} params{ SpecHandle };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent:BP_ApplyGameplayEffectSpecToSelf");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UAbilitySystemGlobals::ToggleIgnoreAbilitySystemCosts()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemGlobals:ToggleIgnoreAbilitySystemCosts");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UAbilitySystemGlobals::ToggleIgnoreAbilitySystemCooldowns()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemGlobals:ToggleIgnoreAbilitySystemCooldowns");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

static class UAbilityTask_ApplyRootMotionConstantForce* UAbilityTask_ApplyRootMotionConstantForce::ApplyRootMotionConstantForce(class UGameplayAbility* OwningAbility, FName TaskInstanceName, struct FVector WorldDirection, float Strength, float Duration, bool bIsAdditive, class UCurveFloat* StrengthOverTime, ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish)
{
	struct {
            class UGameplayAbility* OwningAbility;
            FName TaskInstanceName;
            struct FVector WorldDirection;
            float Strength;
            float Duration;
            bool bIsAdditive;
            class UCurveFloat* StrengthOverTime;
            ERootMotionFinishVelocityMode VelocityOnFinishMode;
            struct FVector SetVelocityOnFinish;
            float ClampVelocityOnFinish;
            class UAbilityTask_ApplyRootMotionConstantForce* ReturnValue;
	} params{ OwningAbility, TaskInstanceName, WorldDirection, Strength, Duration, bIsAdditive, StrengthOverTime, VelocityOnFinishMode, SetVelocityOnFinish, ClampVelocityOnFinish };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_ApplyRootMotionConstantForce:ApplyRootMotionConstantForce");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UAbilityTask_ApplyRootMotionJumpForce::OnLandedCallback(struct FHitResult Hit)
{
	struct {
            struct FHitResult Hit;
	} params{ Hit };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_ApplyRootMotionJumpForce:OnLandedCallback");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilityTask_ApplyRootMotionJumpForce::Finish()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_ApplyRootMotionJumpForce:Finish");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


static class UAbilityTask_ApplyRootMotionJumpForce* UAbilityTask_ApplyRootMotionJumpForce::ApplyRootMotionJumpForce(class UGameplayAbility* OwningAbility, FName TaskInstanceName, struct FRotator Rotation, float Distance, float Height, float Duration, float MinimumLandedTriggerTime, bool bFinishOnLanded, ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish, class UCurveVector* PathOffsetCurve, class UCurveFloat* TimeMappingCurve)
{
	struct {
            class UGameplayAbility* OwningAbility;
            FName TaskInstanceName;
            struct FRotator Rotation;
            float Distance;
            float Height;
            float Duration;
            float MinimumLandedTriggerTime;
            bool bFinishOnLanded;
            ERootMotionFinishVelocityMode VelocityOnFinishMode;
            struct FVector SetVelocityOnFinish;
            float ClampVelocityOnFinish;
            class UCurveVector* PathOffsetCurve;
            class UCurveFloat* TimeMappingCurve;
            class UAbilityTask_ApplyRootMotionJumpForce* ReturnValue;
	} params{ OwningAbility, TaskInstanceName, Rotation, Distance, Height, Duration, MinimumLandedTriggerTime, bFinishOnLanded, VelocityOnFinishMode, SetVelocityOnFinish, ClampVelocityOnFinish, PathOffsetCurve, TimeMappingCurve };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_ApplyRootMotionJumpForce:ApplyRootMotionJumpForce");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UAbilityTask_ApplyRootMotionMoveToActorForce::OnTargetActorSwapped(class AActor* OriginalTarget, class AActor* NewTarget)
{
	struct {
            class AActor* OriginalTarget;
            class AActor* NewTarget;
	} params{ OriginalTarget, NewTarget };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce:OnTargetActorSwapped");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilityTask_ApplyRootMotionMoveToActorForce::OnRep_TargetLocation()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce:OnRep_TargetLocation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


static class UAbilityTask_ApplyRootMotionMoveToActorForce* UAbilityTask_ApplyRootMotionMoveToActorForce::ApplyRootMotionMoveToTargetDataActorForce(class UGameplayAbility* OwningAbility, FName TaskInstanceName, struct FGameplayAbilityTargetDataHandle TargetDataHandle, int TargetDataIndex, int TargetActorIndex, struct FVector TargetLocationOffset, ERootMotionMoveToActorTargetOffsetType OffsetAlignment, float Duration, class UCurveFloat* TargetLerpSpeedHorizontal, class UCurveFloat* TargetLerpSpeedVertical, bool bSetNewMovementMode, char MovementMode, bool bRestrictSpeedToExpected, class UCurveVector* PathOffsetCurve, class UCurveFloat* TimeMappingCurve, ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish, bool bDisableDestinationReachedInterrupt)
{
	struct {
            class UGameplayAbility* OwningAbility;
            FName TaskInstanceName;
            struct FGameplayAbilityTargetDataHandle TargetDataHandle;
            int TargetDataIndex;
            int TargetActorIndex;
            struct FVector TargetLocationOffset;
            ERootMotionMoveToActorTargetOffsetType OffsetAlignment;
            float Duration;
            class UCurveFloat* TargetLerpSpeedHorizontal;
            class UCurveFloat* TargetLerpSpeedVertical;
            bool bSetNewMovementMode;
            char MovementMode;
            bool bRestrictSpeedToExpected;
            class UCurveVector* PathOffsetCurve;
            class UCurveFloat* TimeMappingCurve;
            ERootMotionFinishVelocityMode VelocityOnFinishMode;
            struct FVector SetVelocityOnFinish;
            float ClampVelocityOnFinish;
            bool bDisableDestinationReachedInterrupt;
            class UAbilityTask_ApplyRootMotionMoveToActorForce* ReturnValue;
	} params{ OwningAbility, TaskInstanceName, TargetDataHandle, TargetDataIndex, TargetActorIndex, TargetLocationOffset, OffsetAlignment, Duration, TargetLerpSpeedHorizontal, TargetLerpSpeedVertical, bSetNewMovementMode, MovementMode, bRestrictSpeedToExpected, PathOffsetCurve, TimeMappingCurve, VelocityOnFinishMode, SetVelocityOnFinish, ClampVelocityOnFinish, bDisableDestinationReachedInterrupt };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce:ApplyRootMotionMoveToTargetDataActorForce");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UAbilityTask_ApplyRootMotionMoveToActorForce* UAbilityTask_ApplyRootMotionMoveToActorForce::ApplyRootMotionMoveToActorForce(class UGameplayAbility* OwningAbility, FName TaskInstanceName, class AActor* TargetActor, struct FVector TargetLocationOffset, ERootMotionMoveToActorTargetOffsetType OffsetAlignment, float Duration, class UCurveFloat* TargetLerpSpeedHorizontal, class UCurveFloat* TargetLerpSpeedVertical, bool bSetNewMovementMode, char MovementMode, bool bRestrictSpeedToExpected, class UCurveVector* PathOffsetCurve, class UCurveFloat* TimeMappingCurve, ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish, bool bDisableDestinationReachedInterrupt)
{
	struct {
            class UGameplayAbility* OwningAbility;
            FName TaskInstanceName;
            class AActor* TargetActor;
            struct FVector TargetLocationOffset;
            ERootMotionMoveToActorTargetOffsetType OffsetAlignment;
            float Duration;
            class UCurveFloat* TargetLerpSpeedHorizontal;
            class UCurveFloat* TargetLerpSpeedVertical;
            bool bSetNewMovementMode;
            char MovementMode;
            bool bRestrictSpeedToExpected;
            class UCurveVector* PathOffsetCurve;
            class UCurveFloat* TimeMappingCurve;
            ERootMotionFinishVelocityMode VelocityOnFinishMode;
            struct FVector SetVelocityOnFinish;
            float ClampVelocityOnFinish;
            bool bDisableDestinationReachedInterrupt;
            class UAbilityTask_ApplyRootMotionMoveToActorForce* ReturnValue;
	} params{ OwningAbility, TaskInstanceName, TargetActor, TargetLocationOffset, OffsetAlignment, Duration, TargetLerpSpeedHorizontal, TargetLerpSpeedVertical, bSetNewMovementMode, MovementMode, bRestrictSpeedToExpected, PathOffsetCurve, TimeMappingCurve, VelocityOnFinishMode, SetVelocityOnFinish, ClampVelocityOnFinish, bDisableDestinationReachedInterrupt };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce:ApplyRootMotionMoveToActorForce");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UAbilityTask_ApplyRootMotionMoveToForce* UAbilityTask_ApplyRootMotionMoveToForce::ApplyRootMotionMoveToForce(class UGameplayAbility* OwningAbility, FName TaskInstanceName, struct FVector TargetLocation, float Duration, bool bSetNewMovementMode, char MovementMode, bool bRestrictSpeedToExpected, class UCurveVector* PathOffsetCurve, ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish)
{
	struct {
            class UGameplayAbility* OwningAbility;
            FName TaskInstanceName;
            struct FVector TargetLocation;
            float Duration;
            bool bSetNewMovementMode;
            char MovementMode;
            bool bRestrictSpeedToExpected;
            class UCurveVector* PathOffsetCurve;
            ERootMotionFinishVelocityMode VelocityOnFinishMode;
            struct FVector SetVelocityOnFinish;
            float ClampVelocityOnFinish;
            class UAbilityTask_ApplyRootMotionMoveToForce* ReturnValue;
	} params{ OwningAbility, TaskInstanceName, TargetLocation, Duration, bSetNewMovementMode, MovementMode, bRestrictSpeedToExpected, PathOffsetCurve, VelocityOnFinishMode, SetVelocityOnFinish, ClampVelocityOnFinish };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_ApplyRootMotionMoveToForce:ApplyRootMotionMoveToForce");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UAbilityTask_ApplyRootMotionRadialForce* UAbilityTask_ApplyRootMotionRadialForce::ApplyRootMotionRadialForce(class UGameplayAbility* OwningAbility, FName TaskInstanceName, struct FVector Location, class AActor* LocationActor, float Strength, float Duration, float Radius, bool bIsPush, bool bIsAdditive, bool bNoZForce, class UCurveFloat* StrengthDistanceFalloff, class UCurveFloat* StrengthOverTime, bool bUseFixedWorldDirection, struct FRotator FixedWorldDirection, ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish)
{
	struct {
            class UGameplayAbility* OwningAbility;
            FName TaskInstanceName;
            struct FVector Location;
            class AActor* LocationActor;
            float Strength;
            float Duration;
            float Radius;
            bool bIsPush;
            bool bIsAdditive;
            bool bNoZForce;
            class UCurveFloat* StrengthDistanceFalloff;
            class UCurveFloat* StrengthOverTime;
            bool bUseFixedWorldDirection;
            struct FRotator FixedWorldDirection;
            ERootMotionFinishVelocityMode VelocityOnFinishMode;
            struct FVector SetVelocityOnFinish;
            float ClampVelocityOnFinish;
            class UAbilityTask_ApplyRootMotionRadialForce* ReturnValue;
	} params{ OwningAbility, TaskInstanceName, Location, LocationActor, Strength, Duration, Radius, bIsPush, bIsAdditive, bNoZForce, StrengthDistanceFalloff, StrengthOverTime, bUseFixedWorldDirection, FixedWorldDirection, VelocityOnFinishMode, SetVelocityOnFinish, ClampVelocityOnFinish };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_ApplyRootMotionRadialForce:ApplyRootMotionRadialForce");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UAbilityTask_MoveToLocation* UAbilityTask_MoveToLocation::MoveToLocation(class UGameplayAbility* OwningAbility, FName TaskInstanceName, struct FVector Location, float Duration, class UCurveFloat* OptionalInterpolationCurve, class UCurveVector* OptionalVectorInterpolationCurve)
{
	struct {
            class UGameplayAbility* OwningAbility;
            FName TaskInstanceName;
            struct FVector Location;
            float Duration;
            class UCurveFloat* OptionalInterpolationCurve;
            class UCurveVector* OptionalVectorInterpolationCurve;
            class UAbilityTask_MoveToLocation* ReturnValue;
	} params{ OwningAbility, TaskInstanceName, Location, Duration, OptionalInterpolationCurve, OptionalVectorInterpolationCurve };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_MoveToLocation:MoveToLocation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UAbilityTask_NetworkSyncPoint* UAbilityTask_NetworkSyncPoint::WaitNetSync(class UGameplayAbility* OwningAbility, EAbilityTaskNetSyncType SyncType)
{
	struct {
            class UGameplayAbility* OwningAbility;
            EAbilityTaskNetSyncType SyncType;
            class UAbilityTask_NetworkSyncPoint* ReturnValue;
	} params{ OwningAbility, SyncType };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_NetworkSyncPoint:WaitNetSync");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UAbilityTask_NetworkSyncPoint::OnSignalCallback()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_NetworkSyncPoint:OnSignalCallback");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

void UAbilityTask_PlayMontageAndWait::OnMontageInterrupted()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_PlayMontageAndWait:OnMontageInterrupted");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UAbilityTask_PlayMontageAndWait::OnMontageEnded(class UAnimMontage* Montage, bool bInterrupted)
{
	struct {
            class UAnimMontage* Montage;
            bool bInterrupted;
	} params{ Montage, bInterrupted };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_PlayMontageAndWait:OnMontageEnded");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilityTask_PlayMontageAndWait::OnMontageBlendingOut(class UAnimMontage* Montage, bool bInterrupted)
{
	struct {
            class UAnimMontage* Montage;
            bool bInterrupted;
	} params{ Montage, bInterrupted };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_PlayMontageAndWait:OnMontageBlendingOut");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


static class UAbilityTask_PlayMontageAndWait* UAbilityTask_PlayMontageAndWait::CreatePlayMontageAndWaitProxy(class UGameplayAbility* OwningAbility, FName TaskInstanceName, class UAnimMontage* MontageToPlay, float Rate, FName StartSection, bool bStopWhenAbilityEnds, float AnimRootMotionTranslationScale)
{
	struct {
            class UGameplayAbility* OwningAbility;
            FName TaskInstanceName;
            class UAnimMontage* MontageToPlay;
            float Rate;
            FName StartSection;
            bool bStopWhenAbilityEnds;
            float AnimRootMotionTranslationScale;
            class UAbilityTask_PlayMontageAndWait* ReturnValue;
	} params{ OwningAbility, TaskInstanceName, MontageToPlay, Rate, StartSection, bStopWhenAbilityEnds, AnimRootMotionTranslationScale };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_PlayMontageAndWait:CreatePlayMontageAndWaitProxy");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UAbilityTask_Repeat* UAbilityTask_Repeat::RepeatAction(class UGameplayAbility* OwningAbility, float TimeBetweenActions, int TotalActionCount)
{
	struct {
            class UGameplayAbility* OwningAbility;
            float TimeBetweenActions;
            int TotalActionCount;
            class UAbilityTask_Repeat* ReturnValue;
	} params{ OwningAbility, TimeBetweenActions, TotalActionCount };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_Repeat:RepeatAction");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UAbilityTask_SpawnActor* UAbilityTask_SpawnActor::SpawnActor(class UGameplayAbility* OwningAbility, struct FGameplayAbilityTargetDataHandle TargetData, class AActor* Class)
{
	struct {
            class UGameplayAbility* OwningAbility;
            struct FGameplayAbilityTargetDataHandle TargetData;
            class AActor* Class;
            class UAbilityTask_SpawnActor* ReturnValue;
	} params{ OwningAbility, TargetData, Class };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_SpawnActor:SpawnActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UAbilityTask_SpawnActor::FinishSpawningActor(class UGameplayAbility* OwningAbility, struct FGameplayAbilityTargetDataHandle TargetData, class AActor* SpawnedActor)
{
	struct {
            class UGameplayAbility* OwningAbility;
            struct FGameplayAbilityTargetDataHandle TargetData;
            class AActor* SpawnedActor;
	} params{ OwningAbility, TargetData, SpawnedActor };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_SpawnActor:FinishSpawningActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UAbilityTask_SpawnActor::BeginSpawningActor(class UGameplayAbility* OwningAbility, struct FGameplayAbilityTargetDataHandle TargetData, class AActor* Class, class AActor* SpawnedActor)
{
	struct {
            class UGameplayAbility* OwningAbility;
            struct FGameplayAbilityTargetDataHandle TargetData;
            class AActor* Class;
            class AActor* SpawnedActor;
            bool ReturnValue;
	} params{ OwningAbility, TargetData, Class, SpawnedActor };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_SpawnActor:BeginSpawningActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UAbilityTask_StartAbilityState* UAbilityTask_StartAbilityState::StartAbilityState(class UGameplayAbility* OwningAbility, FName StateName, bool bEndCurrentState)
{
	struct {
            class UGameplayAbility* OwningAbility;
            FName StateName;
            bool bEndCurrentState;
            class UAbilityTask_StartAbilityState* ReturnValue;
	} params{ OwningAbility, StateName, bEndCurrentState };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_StartAbilityState:StartAbilityState");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UAbilityTask_VisualizeTargeting* UAbilityTask_VisualizeTargeting::VisualizeTargetingUsingActor(class UGameplayAbility* OwningAbility, class AGameplayAbilityTargetActor* TargetActor, FName TaskInstanceName, float Duration)
{
	struct {
            class UGameplayAbility* OwningAbility;
            class AGameplayAbilityTargetActor* TargetActor;
            FName TaskInstanceName;
            float Duration;
            class UAbilityTask_VisualizeTargeting* ReturnValue;
	} params{ OwningAbility, TargetActor, TaskInstanceName, Duration };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_VisualizeTargeting:VisualizeTargetingUsingActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UAbilityTask_VisualizeTargeting* UAbilityTask_VisualizeTargeting::VisualizeTargeting(class UGameplayAbility* OwningAbility, class AGameplayAbilityTargetActor* Class, FName TaskInstanceName, float Duration)
{
	struct {
            class UGameplayAbility* OwningAbility;
            class AGameplayAbilityTargetActor* Class;
            FName TaskInstanceName;
            float Duration;
            class UAbilityTask_VisualizeTargeting* ReturnValue;
	} params{ OwningAbility, Class, TaskInstanceName, Duration };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_VisualizeTargeting:VisualizeTargeting");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UAbilityTask_VisualizeTargeting::FinishSpawningActor(class UGameplayAbility* OwningAbility, class AGameplayAbilityTargetActor* SpawnedActor)
{
	struct {
            class UGameplayAbility* OwningAbility;
            class AGameplayAbilityTargetActor* SpawnedActor;
	} params{ OwningAbility, SpawnedActor };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_VisualizeTargeting:FinishSpawningActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UAbilityTask_VisualizeTargeting::BeginSpawningActor(class UGameplayAbility* OwningAbility, class AGameplayAbilityTargetActor* Class, class AGameplayAbilityTargetActor* SpawnedActor)
{
	struct {
            class UGameplayAbility* OwningAbility;
            class AGameplayAbilityTargetActor* Class;
            class AGameplayAbilityTargetActor* SpawnedActor;
            bool ReturnValue;
	} params{ OwningAbility, Class, SpawnedActor };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_VisualizeTargeting:BeginSpawningActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UAbilityTask_WaitAbilityActivate* UAbilityTask_WaitAbilityActivate::WaitForAbilityActivateWithTagRequirements(class UGameplayAbility* OwningAbility, struct FGameplayTagRequirements TagRequirements, bool IncludeTriggeredAbilities, bool TriggerOnce)
{
	struct {
            class UGameplayAbility* OwningAbility;
            struct FGameplayTagRequirements TagRequirements;
            bool IncludeTriggeredAbilities;
            bool TriggerOnce;
            class UAbilityTask_WaitAbilityActivate* ReturnValue;
	} params{ OwningAbility, TagRequirements, IncludeTriggeredAbilities, TriggerOnce };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitAbilityActivate:WaitForAbilityActivateWithTagRequirements");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UAbilityTask_WaitAbilityActivate* UAbilityTask_WaitAbilityActivate::WaitForAbilityActivate_Query(class UGameplayAbility* OwningAbility, struct FGameplayTagQuery Query, bool IncludeTriggeredAbilities, bool TriggerOnce)
{
	struct {
            class UGameplayAbility* OwningAbility;
            struct FGameplayTagQuery Query;
            bool IncludeTriggeredAbilities;
            bool TriggerOnce;
            class UAbilityTask_WaitAbilityActivate* ReturnValue;
	} params{ OwningAbility, Query, IncludeTriggeredAbilities, TriggerOnce };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitAbilityActivate:WaitForAbilityActivate_Query");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UAbilityTask_WaitAbilityActivate* UAbilityTask_WaitAbilityActivate::WaitForAbilityActivate(class UGameplayAbility* OwningAbility, struct FGameplayTag WithTag, struct FGameplayTag WithoutTag, bool IncludeTriggeredAbilities, bool TriggerOnce)
{
	struct {
            class UGameplayAbility* OwningAbility;
            struct FGameplayTag WithTag;
            struct FGameplayTag WithoutTag;
            bool IncludeTriggeredAbilities;
            bool TriggerOnce;
            class UAbilityTask_WaitAbilityActivate* ReturnValue;
	} params{ OwningAbility, WithTag, WithoutTag, IncludeTriggeredAbilities, TriggerOnce };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitAbilityActivate:WaitForAbilityActivate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UAbilityTask_WaitAbilityActivate::OnAbilityActivate(class UGameplayAbility* ActivatedAbility)
{
	struct {
            class UGameplayAbility* ActivatedAbility;
	} params{ ActivatedAbility };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitAbilityActivate:OnAbilityActivate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

static class UAbilityTask_WaitAbilityCommit* UAbilityTask_WaitAbilityCommit::WaitForAbilityCommit_Query(class UGameplayAbility* OwningAbility, struct FGameplayTagQuery Query, bool TriggerOnce)
{
	struct {
            class UGameplayAbility* OwningAbility;
            struct FGameplayTagQuery Query;
            bool TriggerOnce;
            class UAbilityTask_WaitAbilityCommit* ReturnValue;
	} params{ OwningAbility, Query, TriggerOnce };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitAbilityCommit:WaitForAbilityCommit_Query");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UAbilityTask_WaitAbilityCommit* UAbilityTask_WaitAbilityCommit::WaitForAbilityCommit(class UGameplayAbility* OwningAbility, struct FGameplayTag WithTag, struct FGameplayTag WithoutTage, bool TriggerOnce)
{
	struct {
            class UGameplayAbility* OwningAbility;
            struct FGameplayTag WithTag;
            struct FGameplayTag WithoutTage;
            bool TriggerOnce;
            class UAbilityTask_WaitAbilityCommit* ReturnValue;
	} params{ OwningAbility, WithTag, WithoutTage, TriggerOnce };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitAbilityCommit:WaitForAbilityCommit");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UAbilityTask_WaitAbilityCommit::OnAbilityCommit(class UGameplayAbility* ActivatedAbility)
{
	struct {
            class UGameplayAbility* ActivatedAbility;
	} params{ ActivatedAbility };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitAbilityCommit:OnAbilityCommit");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

static class UAbilityTask_WaitAttributeChange* UAbilityTask_WaitAttributeChange::WaitForAttributeChangeWithComparison(class UGameplayAbility* OwningAbility, struct FGameplayAttribute InAttribute, struct FGameplayTag InWithTag, struct FGameplayTag InWithoutTag, char InComparisonType, float InComparisonValue, bool TriggerOnce, class AActor* OptionalExternalOwner)
{
	struct {
            class UGameplayAbility* OwningAbility;
            struct FGameplayAttribute InAttribute;
            struct FGameplayTag InWithTag;
            struct FGameplayTag InWithoutTag;
            char InComparisonType;
            float InComparisonValue;
            bool TriggerOnce;
            class AActor* OptionalExternalOwner;
            class UAbilityTask_WaitAttributeChange* ReturnValue;
	} params{ OwningAbility, InAttribute, InWithTag, InWithoutTag, InComparisonType, InComparisonValue, TriggerOnce, OptionalExternalOwner };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitAttributeChange:WaitForAttributeChangeWithComparison");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UAbilityTask_WaitAttributeChange* UAbilityTask_WaitAttributeChange::WaitForAttributeChange(class UGameplayAbility* OwningAbility, struct FGameplayAttribute Attribute, struct FGameplayTag WithSrcTag, struct FGameplayTag WithoutSrcTag, bool TriggerOnce, class AActor* OptionalExternalOwner)
{
	struct {
            class UGameplayAbility* OwningAbility;
            struct FGameplayAttribute Attribute;
            struct FGameplayTag WithSrcTag;
            struct FGameplayTag WithoutSrcTag;
            bool TriggerOnce;
            class AActor* OptionalExternalOwner;
            class UAbilityTask_WaitAttributeChange* ReturnValue;
	} params{ OwningAbility, Attribute, WithSrcTag, WithoutSrcTag, TriggerOnce, OptionalExternalOwner };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitAttributeChange:WaitForAttributeChange");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UAbilityTask_WaitAttributeChangeRatioThreshold* UAbilityTask_WaitAttributeChangeRatioThreshold::WaitForAttributeChangeRatioThreshold(class UGameplayAbility* OwningAbility, struct FGameplayAttribute AttributeNumerator, struct FGameplayAttribute AttributeDenominator, char ComparisonType, float ComparisonValue, bool bTriggerOnce, class AActor* OptionalExternalOwner)
{
	struct {
            class UGameplayAbility* OwningAbility;
            struct FGameplayAttribute AttributeNumerator;
            struct FGameplayAttribute AttributeDenominator;
            char ComparisonType;
            float ComparisonValue;
            bool bTriggerOnce;
            class AActor* OptionalExternalOwner;
            class UAbilityTask_WaitAttributeChangeRatioThreshold* ReturnValue;
	} params{ OwningAbility, AttributeNumerator, AttributeDenominator, ComparisonType, ComparisonValue, bTriggerOnce, OptionalExternalOwner };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitAttributeChangeRatioThreshold:WaitForAttributeChangeRatioThreshold");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UAbilityTask_WaitAttributeChangeThreshold* UAbilityTask_WaitAttributeChangeThreshold::WaitForAttributeChangeThreshold(class UGameplayAbility* OwningAbility, struct FGameplayAttribute Attribute, char ComparisonType, float ComparisonValue, bool bTriggerOnce, class AActor* OptionalExternalOwner)
{
	struct {
            class UGameplayAbility* OwningAbility;
            struct FGameplayAttribute Attribute;
            char ComparisonType;
            float ComparisonValue;
            bool bTriggerOnce;
            class AActor* OptionalExternalOwner;
            class UAbilityTask_WaitAttributeChangeThreshold* ReturnValue;
	} params{ OwningAbility, Attribute, ComparisonType, ComparisonValue, bTriggerOnce, OptionalExternalOwner };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitAttributeChangeThreshold:WaitForAttributeChangeThreshold");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UAbilityTask_WaitCancel* UAbilityTask_WaitCancel::WaitCancel(class UGameplayAbility* OwningAbility)
{
	struct {
            class UGameplayAbility* OwningAbility;
            class UAbilityTask_WaitCancel* ReturnValue;
	} params{ OwningAbility };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitCancel:WaitCancel");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UAbilityTask_WaitCancel::OnLocalCancelCallback()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitCancel:OnLocalCancelCallback");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UAbilityTask_WaitCancel::OnCancelCallback()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitCancel:OnCancelCallback");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

static class UAbilityTask_WaitConfirm* UAbilityTask_WaitConfirm::WaitConfirm(class UGameplayAbility* OwningAbility)
{
	struct {
            class UGameplayAbility* OwningAbility;
            class UAbilityTask_WaitConfirm* ReturnValue;
	} params{ OwningAbility };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitConfirm:WaitConfirm");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UAbilityTask_WaitConfirm::OnConfirmCallback(class UGameplayAbility* InAbility)
{
	struct {
            class UGameplayAbility* InAbility;
	} params{ InAbility };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitConfirm:OnConfirmCallback");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

static class UAbilityTask_WaitConfirmCancel* UAbilityTask_WaitConfirmCancel::WaitConfirmCancel(class UGameplayAbility* OwningAbility)
{
	struct {
            class UGameplayAbility* OwningAbility;
            class UAbilityTask_WaitConfirmCancel* ReturnValue;
	} params{ OwningAbility };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitConfirmCancel:WaitConfirmCancel");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UAbilityTask_WaitConfirmCancel::OnLocalConfirmCallback()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitConfirmCancel:OnLocalConfirmCallback");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UAbilityTask_WaitConfirmCancel::OnLocalCancelCallback()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitConfirmCancel:OnLocalCancelCallback");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UAbilityTask_WaitConfirmCancel::OnConfirmCallback()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitConfirmCancel:OnConfirmCallback");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UAbilityTask_WaitConfirmCancel::OnCancelCallback()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitConfirmCancel:OnCancelCallback");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

static class UAbilityTask_WaitDelay* UAbilityTask_WaitDelay::WaitDelay(class UGameplayAbility* OwningAbility, float Time)
{
	struct {
            class UGameplayAbility* OwningAbility;
            float Time;
            class UAbilityTask_WaitDelay* ReturnValue;
	} params{ OwningAbility, Time };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitDelay:WaitDelay");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UAbilityTask_WaitGameplayEffectApplied::OnApplyGameplayEffectCallback(class UAbilitySystemComponent* Target, struct FGameplayEffectSpec SpecApplied, struct FActiveGameplayEffectHandle ActiveHandle)
{
	struct {
            class UAbilitySystemComponent* Target;
            struct FGameplayEffectSpec SpecApplied;
            struct FActiveGameplayEffectHandle ActiveHandle;
	} params{ Target, SpecApplied, ActiveHandle };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayEffectApplied:OnApplyGameplayEffectCallback");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

static class UAbilityTask_WaitGameplayEffectApplied_Self* UAbilityTask_WaitGameplayEffectApplied_Self::WaitGameplayEffectAppliedToSelf_Query(class UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle SourceFilter, struct FGameplayTagQuery SourceTagQuery, struct FGameplayTagQuery TargetTagQuery, bool TriggerOnce, class AActor* OptionalExternalOwner, bool ListenForPeriodicEffect)
{
	struct {
            class UGameplayAbility* OwningAbility;
            struct FGameplayTargetDataFilterHandle SourceFilter;
            struct FGameplayTagQuery SourceTagQuery;
            struct FGameplayTagQuery TargetTagQuery;
            bool TriggerOnce;
            class AActor* OptionalExternalOwner;
            bool ListenForPeriodicEffect;
            class UAbilityTask_WaitGameplayEffectApplied_Self* ReturnValue;
	} params{ OwningAbility, SourceFilter, SourceTagQuery, TargetTagQuery, TriggerOnce, OptionalExternalOwner, ListenForPeriodicEffect };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Self:WaitGameplayEffectAppliedToSelf_Query");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UAbilityTask_WaitGameplayEffectApplied_Self* UAbilityTask_WaitGameplayEffectApplied_Self::WaitGameplayEffectAppliedToSelf(class UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle SourceFilter, struct FGameplayTagRequirements SourceTagRequirements, struct FGameplayTagRequirements TargetTagRequirements, bool TriggerOnce, class AActor* OptionalExternalOwner, bool ListenForPeriodicEffect)
{
	struct {
            class UGameplayAbility* OwningAbility;
            struct FGameplayTargetDataFilterHandle SourceFilter;
            struct FGameplayTagRequirements SourceTagRequirements;
            struct FGameplayTagRequirements TargetTagRequirements;
            bool TriggerOnce;
            class AActor* OptionalExternalOwner;
            bool ListenForPeriodicEffect;
            class UAbilityTask_WaitGameplayEffectApplied_Self* ReturnValue;
	} params{ OwningAbility, SourceFilter, SourceTagRequirements, TargetTagRequirements, TriggerOnce, OptionalExternalOwner, ListenForPeriodicEffect };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Self:WaitGameplayEffectAppliedToSelf");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UAbilityTask_WaitGameplayEffectApplied_Target* UAbilityTask_WaitGameplayEffectApplied_Target::WaitGameplayEffectAppliedToTarget_Query(class UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle SourceFilter, struct FGameplayTagQuery SourceTagQuery, struct FGameplayTagQuery TargetTagQuery, bool TriggerOnce, class AActor* OptionalExternalOwner, bool ListenForPeriodicEffect)
{
	struct {
            class UGameplayAbility* OwningAbility;
            struct FGameplayTargetDataFilterHandle SourceFilter;
            struct FGameplayTagQuery SourceTagQuery;
            struct FGameplayTagQuery TargetTagQuery;
            bool TriggerOnce;
            class AActor* OptionalExternalOwner;
            bool ListenForPeriodicEffect;
            class UAbilityTask_WaitGameplayEffectApplied_Target* ReturnValue;
	} params{ OwningAbility, SourceFilter, SourceTagQuery, TargetTagQuery, TriggerOnce, OptionalExternalOwner, ListenForPeriodicEffect };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Target:WaitGameplayEffectAppliedToTarget_Query");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UAbilityTask_WaitGameplayEffectApplied_Target* UAbilityTask_WaitGameplayEffectApplied_Target::WaitGameplayEffectAppliedToTarget(class UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle TargetFilter, struct FGameplayTagRequirements SourceTagRequirements, struct FGameplayTagRequirements TargetTagRequirements, bool TriggerOnce, class AActor* OptionalExternalOwner, bool ListenForPeriodicEffects)
{
	struct {
            class UGameplayAbility* OwningAbility;
            struct FGameplayTargetDataFilterHandle TargetFilter;
            struct FGameplayTagRequirements SourceTagRequirements;
            struct FGameplayTagRequirements TargetTagRequirements;
            bool TriggerOnce;
            class AActor* OptionalExternalOwner;
            bool ListenForPeriodicEffects;
            class UAbilityTask_WaitGameplayEffectApplied_Target* ReturnValue;
	} params{ OwningAbility, TargetFilter, SourceTagRequirements, TargetTagRequirements, TriggerOnce, OptionalExternalOwner, ListenForPeriodicEffects };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Target:WaitGameplayEffectAppliedToTarget");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UAbilityTask_WaitGameplayEffectBlockedImmunity* UAbilityTask_WaitGameplayEffectBlockedImmunity::WaitGameplayEffectBlockedByImmunity(class UGameplayAbility* OwningAbility, struct FGameplayTagRequirements SourceTagRequirements, struct FGameplayTagRequirements TargetTagRequirements, class AActor* OptionalExternalTarget, bool OnlyTriggerOnce)
{
	struct {
            class UGameplayAbility* OwningAbility;
            struct FGameplayTagRequirements SourceTagRequirements;
            struct FGameplayTagRequirements TargetTagRequirements;
            class AActor* OptionalExternalTarget;
            bool OnlyTriggerOnce;
            class UAbilityTask_WaitGameplayEffectBlockedImmunity* ReturnValue;
	} params{ OwningAbility, SourceTagRequirements, TargetTagRequirements, OptionalExternalTarget, OnlyTriggerOnce };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayEffectBlockedImmunity:WaitGameplayEffectBlockedByImmunity");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UAbilityTask_WaitGameplayEffectRemoved* UAbilityTask_WaitGameplayEffectRemoved::WaitForGameplayEffectRemoved(class UGameplayAbility* OwningAbility, struct FActiveGameplayEffectHandle Handle)
{
	struct {
            class UGameplayAbility* OwningAbility;
            struct FActiveGameplayEffectHandle Handle;
            class UAbilityTask_WaitGameplayEffectRemoved* ReturnValue;
	} params{ OwningAbility, Handle };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayEffectRemoved:WaitForGameplayEffectRemoved");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UAbilityTask_WaitGameplayEffectRemoved::OnGameplayEffectRemoved(struct FGameplayEffectRemovalInfo InGameplayEffectRemovalInfo)
{
	struct {
            struct FGameplayEffectRemovalInfo InGameplayEffectRemovalInfo;
	} params{ InGameplayEffectRemovalInfo };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayEffectRemoved:OnGameplayEffectRemoved");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

static class UAbilityTask_WaitGameplayEffectStackChange* UAbilityTask_WaitGameplayEffectStackChange::WaitForGameplayEffectStackChange(class UGameplayAbility* OwningAbility, struct FActiveGameplayEffectHandle Handle)
{
	struct {
            class UGameplayAbility* OwningAbility;
            struct FActiveGameplayEffectHandle Handle;
            class UAbilityTask_WaitGameplayEffectStackChange* ReturnValue;
	} params{ OwningAbility, Handle };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayEffectStackChange:WaitForGameplayEffectStackChange");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UAbilityTask_WaitGameplayEffectStackChange::OnGameplayEffectStackChange(struct FActiveGameplayEffectHandle Handle, int NewCount, int OldCount)
{
	struct {
            struct FActiveGameplayEffectHandle Handle;
            int NewCount;
            int OldCount;
	} params{ Handle, NewCount, OldCount };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayEffectStackChange:OnGameplayEffectStackChange");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

static class UAbilityTask_WaitGameplayEvent* UAbilityTask_WaitGameplayEvent::WaitGameplayEvent(class UGameplayAbility* OwningAbility, struct FGameplayTag EventTag, class AActor* OptionalExternalTarget, bool OnlyTriggerOnce, bool OnlyMatchExact)
{
	struct {
            class UGameplayAbility* OwningAbility;
            struct FGameplayTag EventTag;
            class AActor* OptionalExternalTarget;
            bool OnlyTriggerOnce;
            bool OnlyMatchExact;
            class UAbilityTask_WaitGameplayEvent* ReturnValue;
	} params{ OwningAbility, EventTag, OptionalExternalTarget, OnlyTriggerOnce, OnlyMatchExact };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayEvent:WaitGameplayEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UAbilityTask_WaitGameplayTag::GameplayTagCallback(struct FGameplayTag Tag, int NewCount)
{
	struct {
            struct FGameplayTag Tag;
            int NewCount;
	} params{ Tag, NewCount };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayTag:GameplayTagCallback");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

static class UAbilityTask_WaitGameplayTagAdded* UAbilityTask_WaitGameplayTagAdded::WaitGameplayTagAdd(class UGameplayAbility* OwningAbility, struct FGameplayTag Tag, class AActor* InOptionalExternalTarget, bool OnlyTriggerOnce)
{
	struct {
            class UGameplayAbility* OwningAbility;
            struct FGameplayTag Tag;
            class AActor* InOptionalExternalTarget;
            bool OnlyTriggerOnce;
            class UAbilityTask_WaitGameplayTagAdded* ReturnValue;
	} params{ OwningAbility, Tag, InOptionalExternalTarget, OnlyTriggerOnce };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayTagAdded:WaitGameplayTagAdd");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UAbilityTask_WaitGameplayTagRemoved* UAbilityTask_WaitGameplayTagRemoved::WaitGameplayTagRemove(class UGameplayAbility* OwningAbility, struct FGameplayTag Tag, class AActor* InOptionalExternalTarget, bool OnlyTriggerOnce)
{
	struct {
            class UGameplayAbility* OwningAbility;
            struct FGameplayTag Tag;
            class AActor* InOptionalExternalTarget;
            bool OnlyTriggerOnce;
            class UAbilityTask_WaitGameplayTagRemoved* ReturnValue;
	} params{ OwningAbility, Tag, InOptionalExternalTarget, OnlyTriggerOnce };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayTagRemoved:WaitGameplayTagRemove");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UAbilityTask_WaitInputPress* UAbilityTask_WaitInputPress::WaitInputPress(class UGameplayAbility* OwningAbility, bool bTestAlreadyPressed)
{
	struct {
            class UGameplayAbility* OwningAbility;
            bool bTestAlreadyPressed;
            class UAbilityTask_WaitInputPress* ReturnValue;
	} params{ OwningAbility, bTestAlreadyPressed };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitInputPress:WaitInputPress");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UAbilityTask_WaitInputPress::OnPressCallback()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitInputPress:OnPressCallback");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

static class UAbilityTask_WaitInputRelease* UAbilityTask_WaitInputRelease::WaitInputRelease(class UGameplayAbility* OwningAbility, bool bTestAlreadyReleased)
{
	struct {
            class UGameplayAbility* OwningAbility;
            bool bTestAlreadyReleased;
            class UAbilityTask_WaitInputRelease* ReturnValue;
	} params{ OwningAbility, bTestAlreadyReleased };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitInputRelease:WaitInputRelease");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UAbilityTask_WaitInputRelease::OnReleaseCallback()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitInputRelease:OnReleaseCallback");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

void UAbilityTask_WaitMovementModeChange::OnMovementModeChange(class ACharacter* Character, char PrevMovementMode, char PreviousCustomMode)
{
	struct {
            class ACharacter* Character;
            char PrevMovementMode;
            char PreviousCustomMode;
	} params{ Character, PrevMovementMode, PreviousCustomMode };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitMovementModeChange:OnMovementModeChange");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


static class UAbilityTask_WaitMovementModeChange* UAbilityTask_WaitMovementModeChange::CreateWaitMovementModeChange(class UGameplayAbility* OwningAbility, char NewMode)
{
	struct {
            class UGameplayAbility* OwningAbility;
            char NewMode;
            class UAbilityTask_WaitMovementModeChange* ReturnValue;
	} params{ OwningAbility, NewMode };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitMovementModeChange:CreateWaitMovementModeChange");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UAbilityTask_WaitOverlap* UAbilityTask_WaitOverlap::WaitForOverlap(class UGameplayAbility* OwningAbility)
{
	struct {
            class UGameplayAbility* OwningAbility;
            class UAbilityTask_WaitOverlap* ReturnValue;
	} params{ OwningAbility };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitOverlap:WaitForOverlap");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UAbilityTask_WaitOverlap::OnHitCallback(class UPrimitiveComponent* HitComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult Hit)
{
	struct {
            class UPrimitiveComponent* HitComp;
            class AActor* OtherActor;
            class UPrimitiveComponent* OtherComp;
            struct FVector NormalImpulse;
            struct FHitResult Hit;
	} params{ HitComp, OtherActor, OtherComp, NormalImpulse, Hit };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitOverlap:OnHitCallback");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

static class UAbilityTask_WaitTargetData* UAbilityTask_WaitTargetData::WaitTargetDataUsingActor(class UGameplayAbility* OwningAbility, FName TaskInstanceName, char ConfirmationType, class AGameplayAbilityTargetActor* TargetActor)
{
	struct {
            class UGameplayAbility* OwningAbility;
            FName TaskInstanceName;
            char ConfirmationType;
            class AGameplayAbilityTargetActor* TargetActor;
            class UAbilityTask_WaitTargetData* ReturnValue;
	} params{ OwningAbility, TaskInstanceName, ConfirmationType, TargetActor };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitTargetData:WaitTargetDataUsingActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UAbilityTask_WaitTargetData* UAbilityTask_WaitTargetData::WaitTargetData(class UGameplayAbility* OwningAbility, FName TaskInstanceName, char ConfirmationType, class AGameplayAbilityTargetActor* Class)
{
	struct {
            class UGameplayAbility* OwningAbility;
            FName TaskInstanceName;
            char ConfirmationType;
            class AGameplayAbilityTargetActor* Class;
            class UAbilityTask_WaitTargetData* ReturnValue;
	} params{ OwningAbility, TaskInstanceName, ConfirmationType, Class };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitTargetData:WaitTargetData");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UAbilityTask_WaitTargetData::OnTargetDataReplicatedCancelledCallback()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitTargetData:OnTargetDataReplicatedCancelledCallback");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UAbilityTask_WaitTargetData::OnTargetDataReplicatedCallback(struct FGameplayAbilityTargetDataHandle Data, struct FGameplayTag ActivationTag)
{
	struct {
            struct FGameplayAbilityTargetDataHandle Data;
            struct FGameplayTag ActivationTag;
	} params{ Data, ActivationTag };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitTargetData:OnTargetDataReplicatedCallback");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilityTask_WaitTargetData::OnTargetDataReadyCallback(struct FGameplayAbilityTargetDataHandle Data)
{
	struct {
            struct FGameplayAbilityTargetDataHandle Data;
	} params{ Data };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitTargetData:OnTargetDataReadyCallback");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilityTask_WaitTargetData::OnTargetDataCancelledCallback(struct FGameplayAbilityTargetDataHandle Data)
{
	struct {
            struct FGameplayAbilityTargetDataHandle Data;
	} params{ Data };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitTargetData:OnTargetDataCancelledCallback");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAbilityTask_WaitTargetData::FinishSpawningActor(class UGameplayAbility* OwningAbility, class AGameplayAbilityTargetActor* SpawnedActor)
{
	struct {
            class UGameplayAbility* OwningAbility;
            class AGameplayAbilityTargetActor* SpawnedActor;
	} params{ OwningAbility, SpawnedActor };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitTargetData:FinishSpawningActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UAbilityTask_WaitTargetData::BeginSpawningActor(class UGameplayAbility* OwningAbility, class AGameplayAbilityTargetActor* Class, class AGameplayAbilityTargetActor* SpawnedActor)
{
	struct {
            class UGameplayAbility* OwningAbility;
            class AGameplayAbilityTargetActor* Class;
            class AGameplayAbilityTargetActor* SpawnedActor;
            bool ReturnValue;
	} params{ OwningAbility, Class, SpawnedActor };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitTargetData:BeginSpawningActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UAbilityTask_WaitVelocityChange* UAbilityTask_WaitVelocityChange::CreateWaitVelocityChange(class UGameplayAbility* OwningAbility, struct FVector Direction, float MinimumMagnitude)
{
	struct {
            class UGameplayAbility* OwningAbility;
            struct FVector Direction;
            float MinimumMagnitude;
            class UAbilityTask_WaitVelocityChange* ReturnValue;
	} params{ OwningAbility, Direction, MinimumMagnitude };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitVelocityChange:CreateWaitVelocityChange");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UGameplayAbility::SetShouldBlockOtherAbilities(bool bShouldBlockAbilities)
{
	struct {
            bool bShouldBlockAbilities;
	} params{ bShouldBlockAbilities };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:SetShouldBlockOtherAbilities");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGameplayAbility::SetCanBeCanceled(bool bCanBeCanceled)
{
	struct {
            bool bCanBeCanceled;
	} params{ bCanBeCanceled };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:SetCanBeCanceled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGameplayAbility::SendGameplayEvent(struct FGameplayTag EventTag, struct FGameplayEventData Payload)
{
	struct {
            struct FGameplayTag EventTag;
            struct FGameplayEventData Payload;
	} params{ EventTag, Payload };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:SendGameplayEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGameplayAbility::RemoveGrantedByEffect()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:RemoveGrantedByEffect");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UGameplayAbility::MontageStop(float OverrideBlendOutTime)
{
	struct {
            float OverrideBlendOutTime;
	} params{ OverrideBlendOutTime };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:MontageStop");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGameplayAbility::MontageSetNextSectionName(FName FromSectionName, FName ToSectionName)
{
	struct {
            FName FromSectionName;
            FName ToSectionName;
	} params{ FromSectionName, ToSectionName };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:MontageSetNextSectionName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGameplayAbility::MontageJumpToSection(FName SectionName)
{
	struct {
            FName SectionName;
	} params{ SectionName };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:MontageJumpToSection");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


struct FGameplayAbilityTargetingLocationInfo UGameplayAbility::MakeTargetLocationInfoFromOwnerSkeletalMeshComponent(FName SocketName)
{
	struct {
            FName SocketName;
            struct FGameplayAbilityTargetingLocationInfo ReturnValue;
	} params{ SocketName };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:MakeTargetLocationInfoFromOwnerSkeletalMeshComponent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FGameplayAbilityTargetingLocationInfo UGameplayAbility::MakeTargetLocationInfoFromOwnerActor()
{
	struct {
            struct FGameplayAbilityTargetingLocationInfo ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:MakeTargetLocationInfoFromOwnerActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FGameplayEffectSpecHandle UGameplayAbility::MakeOutgoingGameplayEffectSpec(class UGameplayEffect* GameplayEffectClass, float Level)
{
	struct {
            class UGameplayEffect* GameplayEffectClass;
            float Level;
            struct FGameplayEffectSpecHandle ReturnValue;
	} params{ GameplayEffectClass, Level };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:MakeOutgoingGameplayEffectSpec");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UGameplayAbility::K2_ShouldAbilityRespondToEvent(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayEventData Payload)
{
	struct {
            struct FGameplayAbilityActorInfo ActorInfo;
            struct FGameplayEventData Payload;
            bool ReturnValue;
	} params{ ActorInfo, Payload };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:K2_ShouldAbilityRespondToEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UGameplayAbility::K2_RemoveGameplayCue(struct FGameplayTag GameplayCueTag)
{
	struct {
            struct FGameplayTag GameplayCueTag;
	} params{ GameplayCueTag };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:K2_RemoveGameplayCue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGameplayAbility::K2_OnEndAbility(bool bWasCancelled)
{
	struct {
            bool bWasCancelled;
	} params{ bWasCancelled };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:K2_OnEndAbility");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGameplayAbility::K2_ExecuteGameplayCueWithParams(struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters GameplayCueParameters)
{
	struct {
            struct FGameplayTag GameplayCueTag;
            struct FGameplayCueParameters GameplayCueParameters;
	} params{ GameplayCueTag, GameplayCueParameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:K2_ExecuteGameplayCueWithParams");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGameplayAbility::K2_ExecuteGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayEffectContextHandle Context)
{
	struct {
            struct FGameplayTag GameplayCueTag;
            struct FGameplayEffectContextHandle Context;
	} params{ GameplayCueTag, Context };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:K2_ExecuteGameplayCue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGameplayAbility::K2_EndAbility()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:K2_EndAbility");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UGameplayAbility::K2_CommitExecute()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:K2_CommitExecute");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


bool UGameplayAbility::K2_CommitAbilityCost(bool BroadcastCommitEvent)
{
	struct {
            bool BroadcastCommitEvent;
            bool ReturnValue;
	} params{ BroadcastCommitEvent };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:K2_CommitAbilityCost");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UGameplayAbility::K2_CommitAbilityCooldown(bool BroadcastCommitEvent, bool ForceCooldown)
{
	struct {
            bool BroadcastCommitEvent;
            bool ForceCooldown;
            bool ReturnValue;
	} params{ BroadcastCommitEvent, ForceCooldown };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:K2_CommitAbilityCooldown");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UGameplayAbility::K2_CommitAbility()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:K2_CommitAbility");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UGameplayAbility::K2_CheckAbilityCost()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:K2_CheckAbilityCost");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UGameplayAbility::K2_CheckAbilityCooldown()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:K2_CheckAbilityCooldown");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UGameplayAbility::K2_CancelAbility()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:K2_CancelAbility");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


bool UGameplayAbility::K2_CanActivateAbility(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayTagContainer RelevantTags)
{
	struct {
            struct FGameplayAbilityActorInfo ActorInfo;
            struct FGameplayTagContainer RelevantTags;
            bool ReturnValue;
	} params{ ActorInfo, RelevantTags };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:K2_CanActivateAbility");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


TArray<struct FActiveGameplayEffectHandle> UGameplayAbility::K2_ApplyGameplayEffectSpecToTarget(struct FGameplayEffectSpecHandle EffectSpecHandle, struct FGameplayAbilityTargetDataHandle TargetData)
{
	struct {
            struct FGameplayEffectSpecHandle EffectSpecHandle;
            struct FGameplayAbilityTargetDataHandle TargetData;
            TArray<struct FActiveGameplayEffectHandle> ReturnValue;
	} params{ EffectSpecHandle, TargetData };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:K2_ApplyGameplayEffectSpecToTarget");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FActiveGameplayEffectHandle UGameplayAbility::K2_ApplyGameplayEffectSpecToOwner(struct FGameplayEffectSpecHandle EffectSpecHandle)
{
	struct {
            struct FGameplayEffectSpecHandle EffectSpecHandle;
            struct FActiveGameplayEffectHandle ReturnValue;
	} params{ EffectSpecHandle };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:K2_ApplyGameplayEffectSpecToOwner");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UGameplayAbility::K2_AddGameplayCueWithParams(struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters GameplayCueParameter, bool bRemoveOnAbilityEnd)
{
	struct {
            struct FGameplayTag GameplayCueTag;
            struct FGameplayCueParameters GameplayCueParameter;
            bool bRemoveOnAbilityEnd;
	} params{ GameplayCueTag, GameplayCueParameter, bRemoveOnAbilityEnd };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:K2_AddGameplayCueWithParams");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGameplayAbility::K2_AddGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayEffectContextHandle Context, bool bRemoveOnAbilityEnd)
{
	struct {
            struct FGameplayTag GameplayCueTag;
            struct FGameplayEffectContextHandle Context;
            bool bRemoveOnAbilityEnd;
	} params{ GameplayCueTag, Context, bRemoveOnAbilityEnd };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:K2_AddGameplayCue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGameplayAbility::K2_ActivateAbilityFromEvent(struct FGameplayEventData EventData)
{
	struct {
            struct FGameplayEventData EventData;
	} params{ EventData };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:K2_ActivateAbilityFromEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGameplayAbility::K2_ActivateAbility()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:K2_ActivateAbility");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UGameplayAbility::InvalidateClientPredictionKey()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:InvalidateClientPredictionKey");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


class USkeletalMeshComponent* UGameplayAbility::GetOwningComponentFromActorInfo()
{
	struct {
            class USkeletalMeshComponent* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:GetOwningComponentFromActorInfo");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class AActor* UGameplayAbility::GetOwningActorFromActorInfo()
{
	struct {
            class AActor* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:GetOwningActorFromActorInfo");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FGameplayEffectContextHandle UGameplayAbility::GetGrantedByEffectContext()
{
	struct {
            struct FGameplayEffectContextHandle ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:GetGrantedByEffectContext");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UObject* UGameplayAbility::GetCurrentSourceObject()
{
	struct {
            class UObject* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:GetCurrentSourceObject");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UAnimMontage* UGameplayAbility::GetCurrentMontage()
{
	struct {
            class UAnimMontage* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:GetCurrentMontage");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UGameplayAbility::GetCooldownTimeRemaining()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:GetCooldownTimeRemaining");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FGameplayEffectContextHandle UGameplayAbility::GetContextFromOwner(struct FGameplayAbilityTargetDataHandle OptionalTargetData)
{
	struct {
            struct FGameplayAbilityTargetDataHandle OptionalTargetData;
            struct FGameplayEffectContextHandle ReturnValue;
	} params{ OptionalTargetData };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:GetContextFromOwner");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


class AActor* UGameplayAbility::GetAvatarActorFromActorInfo()
{
	struct {
            class AActor* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:GetAvatarActorFromActorInfo");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FGameplayAbilityActorInfo UGameplayAbility::GetActorInfo()
{
	struct {
            struct FGameplayAbilityActorInfo ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:GetActorInfo");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UAbilitySystemComponent* UGameplayAbility::GetAbilitySystemComponentFromActorInfo()
{
	struct {
            class UAbilitySystemComponent* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:GetAbilitySystemComponentFromActorInfo");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


int UGameplayAbility::GetAbilityLevel()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:GetAbilityLevel");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UGameplayAbility::EndTaskByInstanceName(FName InstanceName)
{
	struct {
            FName InstanceName;
	} params{ InstanceName };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:EndTaskByInstanceName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGameplayAbility::EndAbilityState(FName OptionalStateNameToEnd)
{
	struct {
            FName OptionalStateNameToEnd;
	} params{ OptionalStateNameToEnd };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:EndAbilityState");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGameplayAbility::ConfirmTaskByInstanceName(FName InstanceName, bool bEndTask)
{
	struct {
            FName InstanceName;
            bool bEndTask;
	} params{ InstanceName, bEndTask };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:ConfirmTaskByInstanceName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGameplayAbility::CancelTaskByInstanceName(FName InstanceName)
{
	struct {
            FName InstanceName;
	} params{ InstanceName };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:CancelTaskByInstanceName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGameplayAbility::BP_RemoveGameplayEffectFromOwnerWithHandle(struct FActiveGameplayEffectHandle Handle, int StacksToRemove)
{
	struct {
            struct FActiveGameplayEffectHandle Handle;
            int StacksToRemove;
	} params{ Handle, StacksToRemove };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:BP_RemoveGameplayEffectFromOwnerWithHandle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGameplayAbility::BP_RemoveGameplayEffectFromOwnerWithGrantedTags(struct FGameplayTagContainer WithGrantedTags, int StacksToRemove)
{
	struct {
            struct FGameplayTagContainer WithGrantedTags;
            int StacksToRemove;
	} params{ WithGrantedTags, StacksToRemove };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:BP_RemoveGameplayEffectFromOwnerWithGrantedTags");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGameplayAbility::BP_RemoveGameplayEffectFromOwnerWithAssetTags(struct FGameplayTagContainer WithAssetTags, int StacksToRemove)
{
	struct {
            struct FGameplayTagContainer WithAssetTags;
            int StacksToRemove;
	} params{ WithAssetTags, StacksToRemove };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:BP_RemoveGameplayEffectFromOwnerWithAssetTags");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


TArray<struct FActiveGameplayEffectHandle> UGameplayAbility::BP_ApplyGameplayEffectToTarget(struct FGameplayAbilityTargetDataHandle TargetData, class UGameplayEffect* GameplayEffectClass, int GameplayEffectLevel, int Stacks)
{
	struct {
            struct FGameplayAbilityTargetDataHandle TargetData;
            class UGameplayEffect* GameplayEffectClass;
            int GameplayEffectLevel;
            int Stacks;
            TArray<struct FActiveGameplayEffectHandle> ReturnValue;
	} params{ TargetData, GameplayEffectClass, GameplayEffectLevel, Stacks };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:BP_ApplyGameplayEffectToTarget");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FActiveGameplayEffectHandle UGameplayAbility::BP_ApplyGameplayEffectToOwner(class UGameplayEffect* GameplayEffectClass, int GameplayEffectLevel, int Stacks)
{
	struct {
            class UGameplayEffect* GameplayEffectClass;
            int GameplayEffectLevel;
            int Stacks;
            struct FActiveGameplayEffectHandle ReturnValue;
	} params{ GameplayEffectClass, GameplayEffectLevel, Stacks };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility:BP_ApplyGameplayEffectToOwner");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void AGameplayAbilityTargetActor::ConfirmTargeting()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbilityTargetActor:ConfirmTargeting");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void AGameplayAbilityTargetActor::CancelTargeting()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbilityTargetActor:CancelTargeting");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

void AGameplayAbilityWorldReticle::SetReticleMaterialParamVector(FName ParamName, struct FVector Value)
{
	struct {
            FName ParamName;
            struct FVector Value;
	} params{ ParamName, Value };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbilityWorldReticle:SetReticleMaterialParamVector");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void AGameplayAbilityWorldReticle::SetReticleMaterialParamFloat(FName ParamName, float Value)
{
	struct {
            FName ParamName;
            float Value;
	} params{ ParamName, Value };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbilityWorldReticle:SetReticleMaterialParamFloat");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void AGameplayAbilityWorldReticle::OnValidTargetChanged(bool bNewValue)
{
	struct {
            bool bNewValue;
	} params{ bNewValue };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbilityWorldReticle:OnValidTargetChanged");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void AGameplayAbilityWorldReticle::OnTargetingAnActor(bool bNewValue)
{
	struct {
            bool bNewValue;
	} params{ bNewValue };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbilityWorldReticle:OnTargetingAnActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void AGameplayAbilityWorldReticle::OnParametersInitialized()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbilityWorldReticle:OnParametersInitialized");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void AGameplayAbilityWorldReticle::FaceTowardSource(bool bFaceIn2D)
{
	struct {
            bool bFaceIn2D;
	} params{ bFaceIn2D };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayAbilityWorldReticle:FaceTowardSource");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UGameplayCueInterface::ForwardGameplayCueToParent()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayCueInterface:ForwardGameplayCueToParent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UGameplayCueInterface::BlueprintCustomHandler(char EventType, struct FGameplayCueParameters Parameters)
{
	struct {
            char EventType;
            struct FGameplayCueParameters Parameters;
	} params{ EventType, Parameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayCueInterface:BlueprintCustomHandler");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

bool AGameplayCueNotify_Actor::WhileActive(class AActor* MyTarget, struct FGameplayCueParameters Parameters)
{
	struct {
            class AActor* MyTarget;
            struct FGameplayCueParameters Parameters;
            bool ReturnValue;
	} params{ MyTarget, Parameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayCueNotify_Actor:WhileActive");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool AGameplayCueNotify_Actor::OnRemove(class AActor* MyTarget, struct FGameplayCueParameters Parameters)
{
	struct {
            class AActor* MyTarget;
            struct FGameplayCueParameters Parameters;
            bool ReturnValue;
	} params{ MyTarget, Parameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayCueNotify_Actor:OnRemove");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void AGameplayCueNotify_Actor::OnOwnerDestroyed(class AActor* DestroyedActor)
{
	struct {
            class AActor* DestroyedActor;
	} params{ DestroyedActor };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayCueNotify_Actor:OnOwnerDestroyed");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool AGameplayCueNotify_Actor::OnExecute(class AActor* MyTarget, struct FGameplayCueParameters Parameters)
{
	struct {
            class AActor* MyTarget;
            struct FGameplayCueParameters Parameters;
            bool ReturnValue;
	} params{ MyTarget, Parameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayCueNotify_Actor:OnExecute");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool AGameplayCueNotify_Actor::OnActive(class AActor* MyTarget, struct FGameplayCueParameters Parameters)
{
	struct {
            class AActor* MyTarget;
            struct FGameplayCueParameters Parameters;
            bool ReturnValue;
	} params{ MyTarget, Parameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayCueNotify_Actor:OnActive");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void AGameplayCueNotify_Actor::K2_HandleGameplayCue(class AActor* MyTarget, char EventType, struct FGameplayCueParameters Parameters)
{
	struct {
            class AActor* MyTarget;
            char EventType;
            struct FGameplayCueParameters Parameters;
	} params{ MyTarget, EventType, Parameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayCueNotify_Actor:K2_HandleGameplayCue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void AGameplayCueNotify_Actor::K2_EndGameplayCue()
{
    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayCueNotify_Actor:K2_EndGameplayCue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

bool UGameplayCueNotify_Static::WhileActive(class AActor* MyTarget, struct FGameplayCueParameters Parameters)
{
	struct {
            class AActor* MyTarget;
            struct FGameplayCueParameters Parameters;
            bool ReturnValue;
	} params{ MyTarget, Parameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayCueNotify_Static:WhileActive");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UGameplayCueNotify_Static::OnRemove(class AActor* MyTarget, struct FGameplayCueParameters Parameters)
{
	struct {
            class AActor* MyTarget;
            struct FGameplayCueParameters Parameters;
            bool ReturnValue;
	} params{ MyTarget, Parameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayCueNotify_Static:OnRemove");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UGameplayCueNotify_Static::OnExecute(class AActor* MyTarget, struct FGameplayCueParameters Parameters)
{
	struct {
            class AActor* MyTarget;
            struct FGameplayCueParameters Parameters;
            bool ReturnValue;
	} params{ MyTarget, Parameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayCueNotify_Static:OnExecute");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UGameplayCueNotify_Static::OnActive(class AActor* MyTarget, struct FGameplayCueParameters Parameters)
{
	struct {
            class AActor* MyTarget;
            struct FGameplayCueParameters Parameters;
            bool ReturnValue;
	} params{ MyTarget, Parameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayCueNotify_Static:OnActive");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UGameplayCueNotify_Static::K2_HandleGameplayCue(class AActor* MyTarget, char EventType, struct FGameplayCueParameters Parameters)
{
	struct {
            class AActor* MyTarget;
            char EventType;
            struct FGameplayCueParameters Parameters;
	} params{ MyTarget, EventType, Parameters };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayCueNotify_Static:K2_HandleGameplayCue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

bool UGameplayEffectCustomApplicationRequirement::CanApplyGameplayEffect(class UGameplayEffect* GameplayEffect, struct FGameplayEffectSpec Spec, class UAbilitySystemComponent* ASC)
{
	struct {
            class UGameplayEffect* GameplayEffect;
            struct FGameplayEffectSpec Spec;
            class UAbilitySystemComponent* ASC;
            bool ReturnValue;
	} params{ GameplayEffect, Spec, ASC };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayEffectCustomApplicationRequirement:CanApplyGameplayEffect");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UGameplayEffectExecutionCalculation::Execute(struct FGameplayEffectCustomExecutionParameters ExecutionParams, struct FGameplayEffectCustomExecutionOutput OutExecutionOutput)
{
	struct {
            struct FGameplayEffectCustomExecutionParameters ExecutionParams;
            struct FGameplayEffectCustomExecutionOutput OutExecutionOutput;
	} params{ ExecutionParams, OutExecutionOutput };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayEffectExecutionCalculation:Execute");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

float UGameplayModMagnitudeCalculation::CalculateBaseMagnitude(struct FGameplayEffectSpec Spec)
{
	struct {
            struct FGameplayEffectSpec Spec;
            float ReturnValue;
	} params{ Spec };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayModMagnitudeCalculation:CalculateBaseMagnitude");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UGameplayTagReponseTable::TagResponseEvent(struct FGameplayTag Tag, int NewCount, class UAbilitySystemComponent* ASC, int idx)
{
	struct {
            struct FGameplayTag Tag;
            int NewCount;
            class UAbilitySystemComponent* ASC;
            int idx;
	} params{ Tag, NewCount, ASC, idx };

    static auto fn = UObject::FindObject("/Script/GameplayAbilities.GameplayTagReponseTable:TagResponseEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

