#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FOnMovieSceneSequencePlayerEvent__DelegateSignature
{
	public:

};



enum class EMovieSceneKeyInterpolation : uint8_t
{
    Auto = 0,
    User = 1,
    Break = 2,
    Linear = 3,
    Constant = 4,
    EMovieSceneKeyInterpolation_MAX = 5
};

enum class EMovieSceneBlendType : uint8_t
{
    Absolute = 1,
    Additive = 2,
    Relative = 4,
    EMovieSceneBlendType_MAX = 5
};

enum class EMovieSceneBuiltInEasing : uint8_t
{
    Linear = 0,
    SinIn = 1,
    SinOut = 2,
    SinInOut = 3,
    QuadIn = 4,
    QuadOut = 5,
    QuadInOut = 6,
    CubicIn = 7,
    CubicOut = 8,
    CubicInOut = 9,
    QuartIn = 10,
    QuartOut = 11,
    QuartInOut = 12,
    QuintIn = 13,
    QuintOut = 14,
    QuintInOut = 15,
    ExpoIn = 16,
    ExpoOut = 17,
    ExpoInOut = 18,
    CircIn = 19,
    CircOut = 20,
    CircInOut = 21,
    EMovieSceneBuiltInEasing_MAX = 22
};

enum class EEvaluationMethod : uint8_t
{
    Static = 0,
    Swept = 1,
    EEvaluationMethod_MAX = 2
};

enum class EUpdateClockSource : uint8_t
{
    Tick = 0,
    Platform = 1,
    Audio = 2,
    EUpdateClockSource_MAX = 3
};

enum class EMovieSceneEvaluationType : uint8_t
{
    FrameLocked = 0,
    WithSubFrames = 1,
    EMovieSceneEvaluationType_MAX = 2
};

enum class EMovieScenePlayerStatus : uint8_t
{
    Stopped = 0,
    Playing = 1,
    Recording = 2,
    Scrubbing = 3,
    Jumping = 4,
    Stepping = 5,
    Paused = 6,
    MAX = 7
};

enum class EMovieSceneObjectBindingSpace : uint8_t
{
    Local = 0,
    Root = 1,
    EMovieSceneObjectBindingSpace_MAX = 2
};

enum class EMovieSceneCompletionMode : uint8_t
{
    KeepState = 0,
    RestoreState = 1,
    ProjectDefault = 2,
    EMovieSceneCompletionMode_MAX = 3
};

enum class ESectionEvaluationFlags : uint8_t
{
    None = 0,
    PreRoll = 1,
    PostRoll = 2,
    ESectionEvaluationFlags_MAX = 3
};

enum class EUpdatePositionMethod : uint8_t
{
    Play = 0,
    Jump = 1,
    Scrub = 2,
    EUpdatePositionMethod_MAX = 3
};

enum class ESpawnOwnership : uint8_t
{
    InnerSequence = 0,
    MasterSequence = 1,
    External = 2,
    ESpawnOwnership_MAX = 3
};struct FMovieSceneEvalTemplateBase
{
	public:
	    char UnknownData0[0x10];

};

struct FMovieSceneEvalTemplate : public FMovieSceneEvalTemplateBase
{
	public:
	    EMovieSceneCompletionMode CompletionMode; // 0x10 Size: 0x1
	    char UnknownData0[0x7]; // 0x11
	    class UMovieSceneSection* SourceSection; // 0x18 Size: 0x8

};

struct FMovieSceneChannel
{
	public:
	    char UnknownData0[0x8];

};

struct FMovieSceneSequenceInstanceData
{
	public:
	    char UnknownData0[0x8];

};

struct FMovieSceneSequenceID
{
	public:
	    uint32_t Value; // 0x0 Size: 0x4

};

struct FMovieSceneEvaluationOperand
{
	public:
	    struct FGuid ObjectBindingID; // 0x0 Size: 0x10
	    struct FMovieSceneSequenceID SequenceID; // 0x10 Size: 0x4

};

struct FMovieSceneKeyHandleMap : public FKeyHandleLookupTable
{
	public:
	    char UnknownData0[0x60];

};

struct FMovieSceneTangentData
{
	public:
	    float ArriveTangent; // 0x0 Size: 0x4
	    float LeaveTangent; // 0x4 Size: 0x4
	    char TangentWeightMode; // 0x8 Size: 0x1
	    char UnknownData0[0x3]; // 0x9
	    float ArriveTangentWeight; // 0xc Size: 0x4
	    float LeaveTangentWeight; // 0x10 Size: 0x4

};

struct FMovieSceneFloatValue
{
	public:
	    float Value; // 0x0 Size: 0x4
	    char InterpMode; // 0x4 Size: 0x1
	    char TangentMode; // 0x5 Size: 0x1
	    char UnknownData0[0x2]; // 0x6
	    struct FMovieSceneTangentData Tangent; // 0x8 Size: 0x14

};

struct FMovieScenePropertySectionData
{
	public:
	    FName PropertyName; // 0x0 Size: 0x8
	    struct FString PropertyPath; // 0x8 Size: 0x10
	    FName FunctionName; // 0x18 Size: 0x8
	    FName NotifyFunctionName; // 0x20 Size: 0x8

};

struct FMovieScenePropertySectionTemplate : public FMovieSceneEvalTemplate
{
	public:
	    struct FMovieScenePropertySectionData PropertyData; // 0x20 Size: 0x28

};

struct FMovieSceneTrackImplementation : public FMovieSceneEvalTemplateBase
{
	public:
	    char UnknownData0[0x10];

};

struct FMovieSceneEditorData
{
	public:
	    __int64/*MapProperty*/ ExpansionStates; // 0x0 Size: 0x50
	    double ViewStart; // 0x50 Size: 0x8
	    double ViewEnd; // 0x58 Size: 0x8
	    double WorkStart; // 0x60 Size: 0x8
	    double WorkEnd; // 0x68 Size: 0x8
	    __int64/*SetProperty*/ MarkedFrames; // 0x70 Size: 0x50
	    struct FFloatRange WorkingRange; // 0xc0 Size: 0x10
	    struct FFloatRange ViewRange; // 0xd0 Size: 0x10

};

struct FMovieSceneExpansionState
{
	public:
	    bool bExpanded; // 0x0 Size: 0x1

};

struct FMovieSceneTimecodeSource
{
	public:
	    struct FTimecode Timecode; // 0x0 Size: 0x14
	    struct FFrameNumber DeltaFrame; // 0x14 Size: 0x4

};

struct FMovieSceneObjectBindingID
{
	public:
	    int SequenceID; // 0x0 Size: 0x4
	    EMovieSceneObjectBindingSpace Space; // 0x4 Size: 0x1
	    char UnknownData0[0x3]; // 0x5
	    struct FGuid Guid; // 0x8 Size: 0x10

};

struct FMovieSceneBindingOverrideData
{
	public:
	    struct FMovieSceneObjectBindingID ObjectBindingID; // 0x0 Size: 0x18
	    TWeakObjectPtr<UObject*> Object; // 0x18 Size: 0x8
	    bool bOverridesDefault; // 0x20 Size: 0x1
	    char UnknownData0[0x3];

};

struct FOptionalMovieSceneBlendType
{
	public:
	    EMovieSceneBlendType BlendType; // 0x0 Size: 0x1
	    bool bIsValid; // 0x1 Size: 0x1

};

struct FMovieSceneEvalTemplatePtr
{
	public:
	    char UnknownData0[0x38];

};

struct FMovieSceneEmptyStruct
{
	public:
	    char UnknownData0[0x1];

};

struct FMovieSceneTrackIdentifier
{
	public:
	    uint32_t Value; // 0x0 Size: 0x4

};

struct FMovieSceneEvaluationKey
{
	public:
	    struct FMovieSceneSequenceID SequenceID; // 0x0 Size: 0x4
	    struct FMovieSceneTrackIdentifier TrackIdentifier; // 0x4 Size: 0x4
	    uint32_t SectionIndex; // 0x8 Size: 0x4

};

struct FMovieSceneOrderedEvaluationKey
{
	public:
	    struct FMovieSceneEvaluationKey Key; // 0x0 Size: 0xc
	    uint32_t EvaluationIndex; // 0xc Size: 0x4

};

struct FMovieSceneEvaluationFieldTrackPtr
{
	public:
	    struct FMovieSceneSequenceID SequenceID; // 0x0 Size: 0x4
	    struct FMovieSceneTrackIdentifier TrackIdentifier; // 0x4 Size: 0x4

};

struct FMovieSceneSegmentIdentifier
{
	public:
	    int IdentifierIndex; // 0x0 Size: 0x4

};

struct FMovieSceneEvaluationFieldSegmentPtr : public FMovieSceneEvaluationFieldTrackPtr
{
	public:
	    struct FMovieSceneSegmentIdentifier SegmentID; // 0x8 Size: 0x4

};

struct FMovieSceneEvaluationGroupLUTIndex
{
	public:
	    int LUTOffset; // 0x0 Size: 0x4
	    int NumInitPtrs; // 0x4 Size: 0x4
	    int NumEvalPtrs; // 0x8 Size: 0x4

};

struct FMovieSceneFrameRange
{
	public:
	    char UnknownData0[0x10];

};

struct FMovieSceneSubSectionFieldData
{
	public:
	    char UnknownData0[0x60];

};

struct FMovieSceneTrackFieldData
{
	public:
	    char UnknownData0[0x60];

};

struct FMovieSceneTemplateGenerationLedger
{
	public:
	    struct FMovieSceneTrackIdentifier LastTrackIdentifier; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    __int64/*MapProperty*/ TrackSignatureToTrackIdentifier; // 0x8 Size: 0x50
	    __int64/*MapProperty*/ SubSectionRanges; // 0x58 Size: 0x50

};

struct FMovieSceneEvaluationTemplateSerialNumber
{
	public:
	    uint32_t Value; // 0x0 Size: 0x4

};

struct FMovieSceneSequenceHierarchy
{
	public:
	    __int64/*MapProperty*/ SubSequences; // 0x0 Size: 0x50
	    __int64/*MapProperty*/ Hierarchy; // 0x50 Size: 0x50

};

struct FMovieSceneSequenceTransform
{
	public:
	    float TimeScale; // 0x0 Size: 0x4
	    struct FFrameTime Offset; // 0x4 Size: 0x8

};

struct FMovieSceneSequenceInstanceDataPtr
{
	public:
	    char UnknownData0[0x18];

};

struct FMovieSceneSubSequenceData
{
	public:
	    struct FSoftObjectPath Sequence; // 0x0 Size: 0x18
	    struct FMovieSceneSequenceTransform RootToSequenceTransform; // 0x18 Size: 0xc
	    struct FFrameRate TickResolution; // 0x24 Size: 0x8
	    struct FMovieSceneSequenceID DeterministicSequenceID; // 0x2c Size: 0x4
	    struct FMovieSceneFrameRange PlayRange; // 0x30 Size: 0x10
	    struct FMovieSceneFrameRange PreRollRange; // 0x40 Size: 0x10
	    struct FMovieSceneFrameRange PostRollRange; // 0x50 Size: 0x10
	    int HierarchicalBias; // 0x60 Size: 0x4
	    char UnknownData0[0x4]; // 0x64
	    struct FMovieSceneSequenceInstanceDataPtr InstanceData; // 0x68 Size: 0x18
	    char UnknownData1[0x8]; // 0x80
	    struct FGuid SubSectionSignature; // 0x88 Size: 0x10
	    struct FMovieSceneSequenceTransform OuterToInnerTransform; // 0x98 Size: 0xc
	    char UnknownData2[0x4];

};

struct FMovieSceneTrackImplementationPtr
{
	public:
	    char UnknownData0[0x38];

};

struct FSectionEvaluationDataTree
{
	public:
	    char UnknownData0[0x60];

};

struct FMovieSceneSegment
{
	public:
	    char UnknownData0[0x58];

};

struct FMovieSceneSubSectionData
{
	public:
	    TWeakObjectPtr<UMovieSceneSubSection*> Section; // 0x0 Size: 0x8
	    struct FGuid ObjectBindingID; // 0x8 Size: 0x10
	    ESectionEvaluationFlags Flags; // 0x18 Size: 0x1
	    char UnknownData0[0x3];

};

struct FMovieSceneRootEvaluationTemplateInstance
{
	public:
	    __int64/*MapProperty*/ DirectorInstances; // 0x18 Size: 0x50
	    char UnknownData0[0x298];

};

struct FMovieSceneKeyStruct
{
	public:
	    char UnknownData0[0x8];

};

struct FMovieSceneKeyTimeStruct : public FMovieSceneKeyStruct
{
	public:
	    struct FFrameNumber Time; // 0x8 Size: 0x4
	    char UnknownData0[0x1c];

};

struct FGeneratedMovieSceneKeyStruct
{
	public:
	    char UnknownData0[0x50];

};

struct FMovieSceneObjectPathChannelKeyValue
{
	public:
	    struct TSoftObjectPtr<struct UObject*> SoftPtr; // 0x0 Size: 0x28
	    class UObject* HardPtr; // 0x28 Size: 0x8

};

struct FMovieSceneEasingSettings
{
	public:
	    int AutoEaseInDuration; // 0x0 Size: 0x4
	    int AutoEaseOutDuration; // 0x4 Size: 0x4
	    __int64/*InterfaceProperty*/ EaseIn; // 0x8 Size: 0x10
	    bool bManualEaseIn; // 0x18 Size: 0x1
	    char UnknownData0[0x3]; // 0x19
	    int ManualEaseInDuration; // 0x1c Size: 0x4
	    __int64/*InterfaceProperty*/ EaseOut; // 0x20 Size: 0x10
	    bool bManualEaseOut; // 0x30 Size: 0x1
	    char UnknownData1[0x3]; // 0x31
	    int ManualEaseOutDuration; // 0x34 Size: 0x4

};

struct FMovieSceneSectionEvalOptions
{
	public:
	    bool bCanEditCompletionMode; // 0x0 Size: 0x1
	    EMovieSceneCompletionMode CompletionMode; // 0x1 Size: 0x1

};

struct FMovieSceneSectionParameters
{
	public:
	    struct FFrameNumber StartFrameOffset; // 0x0 Size: 0x4
	    float TimeScale; // 0x4 Size: 0x4
	    int HierarchicalBias; // 0x8 Size: 0x4
	    float StartOffset; // 0xc Size: 0x4
	    float PrerollTime; // 0x10 Size: 0x4
	    float PostrollTime; // 0x14 Size: 0x4

};

struct FSectionEvaluationData
{
	public:
	    int ImplIndex; // 0x0 Size: 0x4
	    struct FFrameNumber ForcedTime; // 0x4 Size: 0x4
	    ESectionEvaluationFlags Flags; // 0x8 Size: 0x1
	    char UnknownData0[0x3];

};

struct FMovieSceneSequenceLoopCount
{
	public:
	    int Value; // 0x0 Size: 0x4

};

struct FMovieSceneSequencePlaybackSettings
{
	public:
	    struct FMovieSceneSequenceLoopCount LoopCount; // 0x0 Size: 0x4
	    float PlayRate; // 0x4 Size: 0x4
	    float StartTime; // 0x8 Size: 0x4
	    bool bRandomStartTime; // 0xc Size: 0x1
	    bool bRestoreState; // 0xc Size: 0x1
	    bool bDisableMovementInput; // 0xc Size: 0x1
	    bool bDisableLookAtInput; // 0xc Size: 0x1
	    bool bHidePlayer; // 0xc Size: 0x1
	    bool bHideHud; // 0xc Size: 0x1
	    bool bDisableCameraCuts; // 0xc Size: 0x1
	    bool bPauseAtEnd; // 0xc Size: 0x1
	    char UnknownData0[0x-4];

};

struct FMovieSceneSequenceReplProperties
{
	public:
	    struct FFrameTime LastKnownPosition; // 0x0 Size: 0x8
	    char LastKnownStatus; // 0x8 Size: 0x1
	    char UnknownData0[0x3]; // 0x9
	    int LastKnownNumLoops; // 0xc Size: 0x4

};

struct FTestMovieSceneEvalTemplate : public FMovieSceneEvalTemplate
{
	public:
	    char UnknownData0[0x20];

};

struct FMovieSceneTrackEvalOptions
{
	public:
	    bool bCanEvaluateNearestSection; // 0x0 Size: 0x1
	    bool bEvalNearestSection; // 0x0 Size: 0x1
	    bool bEvaluateInPreroll; // 0x0 Size: 0x1
	    bool bEvaluateInPostroll; // 0x0 Size: 0x1
	    bool bEvaluateNearestSection; // 0x0 Size: 0x1
	    char UnknownData0[0x-1];

};


}