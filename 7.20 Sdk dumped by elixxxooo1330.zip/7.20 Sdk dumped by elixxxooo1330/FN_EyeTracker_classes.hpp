#pragma once

#include "../SDK.hpp"

namespace SDK {


class UEyeTrackerFunctionLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void SetEyeTrackedPlayer(class APlayerController* PlayerController); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static bool IsStereoGazeDataAvailable(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static bool IsEyeTrackerConnected(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static bool GetStereoGazeData(struct FEyeTrackerStereoGazeData OutGazeData); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static bool GetGazeData(struct FEyeTrackerGazeData OutGazeData); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EyeTracker.EyeTrackerFunctionLibrary");
			return (class UClass*)ptr;
		};

};


}