#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FOnTimeSynthPlaybackTime__DelegateSignature
{
	public:
	    float SynthPlaybackTimeSeconds; // 0x0 Size: 0x4

};



enum class ETimeSynthEventQuantization : uint8_t
{
    None = 0,
    Bars8 = 1,
    Bars4 = 2,
    Bars2 = 3,
    Bar = 4,
    HalfNote = 5,
    HalfNoteTriplet = 6,
    QuarterNote = 7,
    QuarterNoteTriplet = 8,
    EighthNote = 9,
    EighthNoteTriplet = 10,
    SixteenthNote = 11,
    SixteenthNoteTriplet = 12,
    ThirtySecondNote = 13,
    Count = 14,
    ETimeSynthEventQuantization_MAX = 15
};struct FOnQuantizationEvent__DelegateSignature
{
	public:
	    ETimeSynthEventQuantization QuantizationType; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    int NumBars; // 0x4 Size: 0x4
	    float Beat; // 0x8 Size: 0x4

};

struct FOnQuantizationEventBP__DelegateSignature
{
	public:
	    ETimeSynthEventQuantization QuantizationType; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    int NumBars; // 0x4 Size: 0x4
	    float Beat; // 0x8 Size: 0x4

};



enum class ETimeSynthEnvelopeFollowerPeakMode : uint8_t
{
    MeanSquared = 0,
    RootMeanSquared = 1,
    Peak = 2,
    Count = 3,
    ETimeSynthEnvelopeFollowerPeakMode_MAX = 4
};

enum class ETimeSynthFilterType : uint8_t
{
    LowPass = 0,
    HighPass = 1,
    BandPass = 2,
    BandStop = 3,
    Count = 4,
    ETimeSynthFilterType_MAX = 5
};

enum class ETimeSynthFilter : uint8_t
{
    FilterA = 0,
    FilterB = 1,
    Count = 2,
    ETimeSynthFilter_MAX = 3
};

enum class ETimeSynthEventClipQuantization : uint8_t
{
    Global = 0,
    None = 1,
    Bars8 = 2,
    Bars4 = 3,
    Bars2 = 4,
    Bar = 5,
    HalfNote = 6,
    HalfNoteTriplet = 7,
    QuarterNote = 8,
    QuarterNoteTriplet = 9,
    EighthNote = 10,
    EighthNoteTriplet = 11,
    SixteenthNote = 12,
    SixteenthNoteTriplet = 13,
    ThirtySecondNote = 14,
    Count = 15,
    ETimeSynthEventClipQuantization_MAX = 16
};

enum class ETimeSynthFFTSize : uint8_t
{
    Min_64 = 0,
    Small_256 = 1,
    Medium_512 = 2,
    Large_1024 = 3,
    ETimeSynthFFTSize_MAX = 4
};

enum class ETimeSynthBeatDivision : uint8_t
{
    One = 0,
    Two = 1,
    Four = 2,
    Eight = 3,
    Sixteen = 4,
    Count = 5,
    ETimeSynthBeatDivision_MAX = 6
};struct FTimeSynthEnvelopeFollowerSettings
{
	public:
	    float AttackTime; // 0x0 Size: 0x4
	    float ReleaseTime; // 0x4 Size: 0x4
	    ETimeSynthEnvelopeFollowerPeakMode PeakMode; // 0x8 Size: 0x1
	    bool bIsAnalogMode; // 0x9 Size: 0x1
	    char UnknownData0[0x2];

};

struct FTimeSynthFilterSettings
{
	public:
	    ETimeSynthFilterType FilterType; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float CutoffFrequency; // 0x4 Size: 0x4
	    float FilterQ; // 0x8 Size: 0x4

};

struct FTimeSynthClipSound
{
	public:
	    class USoundWave* SoundWave; // 0x0 Size: 0x8
	    float RandomWeight; // 0x8 Size: 0x4
	    struct FVector2D DistanceRange; // 0xc Size: 0x8
	    char UnknownData0[0x4];

};

struct FTimeSynthClipHandle
{
	public:
	    FName ClipName; // 0x0 Size: 0x8
	    int ClipId; // 0x8 Size: 0x4

};

struct FTimeSynthTimeDef
{
	public:
	    int NumBars; // 0x0 Size: 0x4
	    int NumBeats; // 0x4 Size: 0x4

};

struct FTimeSynthQuantizationSettings
{
	public:
	    float BeatsPerMinute; // 0x0 Size: 0x4
	    int BeatsPerBar; // 0x4 Size: 0x4
	    ETimeSynthBeatDivision BeatDivision; // 0x8 Size: 0x1
	    char UnknownData0[0x3]; // 0x9
	    float EventDelaySeconds; // 0xc Size: 0x4
	    ETimeSynthEventQuantization GlobalQuantization; // 0x10 Size: 0x1
	    char UnknownData1[0x3];

};

struct FTimeSynthSpectralData
{
	public:
	    float FrequencyHz; // 0x0 Size: 0x4
	    float Magnitude; // 0x4 Size: 0x4

};


}