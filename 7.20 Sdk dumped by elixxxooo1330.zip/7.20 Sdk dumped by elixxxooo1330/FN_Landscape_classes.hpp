#pragma once

#include "../SDK.hpp"

namespace SDK {


class UControlPointMeshComponent : public UStaticMeshComponent
{
	public:
	    char UnknownData0[0x610];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.ControlPointMeshComponent");
			return (class UClass*)ptr;
		};

};

class ALandscapeProxy : public AActor
{
	public:
	    class ULandscapeSplinesComponent* SplineComponent; // 0x330 Size: 0x8
	    struct FGuid LandscapeGuid; // 0x338 Size: 0x10
	    struct FIntPoint LandscapeSectionOffset; // 0x348 Size: 0x8
	    int MaxLODLevel; // 0x350 Size: 0x4
	    float LODDistanceFactor; // 0x354 Size: 0x4
	    char LODFalloff; // 0x358 Size: 0x1
	    char UnknownData0[0x3]; // 0x359
	    float ComponentScreenSizeToUseSubSections; // 0x35c Size: 0x4
	    float LOD0DistributionSetting; // 0x360 Size: 0x4
	    float LODDistributionSetting; // 0x364 Size: 0x4
	    float TessellationComponentScreenSize; // 0x368 Size: 0x4
	    bool UseTessellationComponentScreenSizeFalloff; // 0x36c Size: 0x1
	    char UnknownData1[0x3]; // 0x36d
	    float TessellationComponentScreenSizeFalloff; // 0x370 Size: 0x4
	    int OccluderGeometryLOD; // 0x374 Size: 0x4
	    int StaticLightingLOD; // 0x378 Size: 0x4
	    char UnknownData2[0x4]; // 0x37c
	    class UPhysicalMaterial* DefaultPhysMaterial; // 0x380 Size: 0x8
	    float StreamingDistanceMultiplier; // 0x388 Size: 0x4
	    char UnknownData3[0x4]; // 0x38c
	    class UMaterialInterface* LandscapeMaterial; // 0x390 Size: 0x8
	    class UMaterialInterface* LandscapeHoleMaterial; // 0x398 Size: 0x8
	    TArray<struct FLandscapeProxyMaterialOverride> LandscapeMaterialsOverride; // 0x3a0 Size: 0x10
	    float NegativeZBoundsExtension; // 0x3b0 Size: 0x4
	    float PositiveZBoundsExtension; // 0x3b4 Size: 0x4
	    TArray<class ULandscapeComponent*> LandscapeComponents; // 0x3b8 Size: 0x10
	    TArray<class ULandscapeHeightfieldCollisionComponent*> CollisionComponents; // 0x3c8 Size: 0x10
	    TArray<class UHierarchicalInstancedStaticMeshComponent*> FoliageComponents; // 0x3d8 Size: 0x10
	    bool bHasLandscapeGrass; // 0x44c Size: 0x1
	    char UnknownData4[0x67]; // 0x3e9
	    float StaticLightingResolution; // 0x450 Size: 0x4
	    bool bCastStaticShadow; // 0x454 Size: 0x1
	    bool bCastShadowAsTwoSided; // 0x454 Size: 0x1
	    bool bCastFarShadow; // 0x454 Size: 0x1
	    bool bAffectDistanceFieldLighting; // 0x458 Size: 0x1
	    char UnknownData5[0x1]; // 0x458
	    struct FLightingChannels LightingChannels; // 0x459 Size: 0x1
	    bool bUseMaterialPositionOffsetInStaticLighting; // 0x45c Size: 0x1
	    bool bRenderCustomDepth; // 0x45c Size: 0x1
	    char UnknownData6[0x4]; // 0x45c
	    int CustomDepthStencilValue; // 0x460 Size: 0x4
	    float LDMaxDrawDistance; // 0x464 Size: 0x4
	    struct FLightmassPrimitiveSettings LightmassSettings; // 0x468 Size: 0x18
	    int CollisionMipLevel; // 0x480 Size: 0x4
	    int SimpleCollisionMipLevel; // 0x484 Size: 0x4
	    float CollisionThickness; // 0x488 Size: 0x4
	    char UnknownData7[0x4]; // 0x48c
	    struct FBodyInstance BodyInstance; // 0x490 Size: 0x150
	    bool bGenerateOverlapEvents; // 0x5e0 Size: 0x1
	    bool bBakeMaterialPositionOffsetIntoCollision; // 0x5e0 Size: 0x1
	    char UnknownData8[0x2]; // 0x5e2
	    int ComponentSizeQuads; // 0x5e4 Size: 0x4
	    int SubsectionSizeQuads; // 0x5e8 Size: 0x4
	    int NumSubsections; // 0x5ec Size: 0x4
	    bool bUsedForNavigation; // 0x5f0 Size: 0x1
	    bool bUseDynamicMaterialInstance; // 0x5f4 Size: 0x1
	    char UnknownData9[0x3]; // 0x5f2
	    ENavDataGatheringMode NavigationGeometryGatheringMode; // 0x5f5 Size: 0x1
	    bool bUseLandscapeForCullingInvisibleHLODVertices; // 0x5f6 Size: 0x1
	    char UnknownData10[0x5f7]; // 0x5f7
	    void SetLandscapeMaterialVectorParameterValue(FName ParameterName, struct FLinearColor Value); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetLandscapeMaterialTextureParameterValue(FName ParameterName, class UTexture* Value); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetLandscapeMaterialScalarParameterValue(FName ParameterName, float Value); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void EditorSetLandscapeMaterial(class UMaterialInterface* NewLandscapeMaterial); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void EditorApplySpline(class USplineComponent* InSplineComponent, float StartWidth, float EndWidth, float StartSideFalloff, float EndSideFalloff, float StartRoll, float EndRoll, int NumSubdivisions, bool bRaiseHeights, bool bLowerHeights, class ULandscapeLayerInfoObject* PaintLayer); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void ChangeUseTessellationComponentScreenSizeFalloff(bool InComponentScreenSizeToUseSubSections); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void ChangeTessellationComponentScreenSizeFalloff(float InUseTessellationComponentScreenSizeFalloff); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void ChangeTessellationComponentScreenSize(float InTessellationComponentScreenSize); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void ChangeLODDistanceFactor(float InLODDistanceFactor); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void ChangeComponentScreenSizeToUseSubSections(float InComponentScreenSizeToUseSubSections); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x-7999];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.LandscapeProxy");
			return (class UClass*)ptr;
		};

};

class ALandscape : public ALandscapeProxy
{
	public:
	    char UnknownData0[0x648];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.Landscape");
			return (class UClass*)ptr;
		};

};

class ALandscapeBlueprintCustomBrush : public AActor
{
	public:
	    bool AffectHeightmap; // 0x330 Size: 0x1
	    bool AffectWeightmap; // 0x331 Size: 0x1
	    char UnknownData0[0x332]; // 0x332
	    class UTextureRenderTarget2D* Render(bool InIsHeightmap, class UTextureRenderTarget2D* InCombinedResult); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void Initialize(struct FIntPoint InLandscapeSize, struct FIntPoint InLandscapeRenderTargetSize); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7ca9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.LandscapeBlueprintCustomBrush");
			return (class UClass*)ptr;
		};

};

class ALandscapeBlueprintCustomSimulationBrush : public ALandscapeBlueprintCustomBrush
{
	public:
	    char UnknownData0[0x338];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.LandscapeBlueprintCustomSimulationBrush");
			return (class UClass*)ptr;
		};

};

class ULandscapeComponent : public UPrimitiveComponent
{
	public:
	    int SectionBaseX; // 0x570 Size: 0x4
	    int SectionBaseY; // 0x574 Size: 0x4
	    int ComponentSizeQuads; // 0x578 Size: 0x4
	    int SubsectionSizeQuads; // 0x57c Size: 0x4
	    int NumSubsections; // 0x580 Size: 0x4
	    char UnknownData0[0x4]; // 0x584
	    class UMaterialInterface* OverrideMaterial; // 0x588 Size: 0x8
	    class UMaterialInterface* OverrideHoleMaterial; // 0x590 Size: 0x8
	    TArray<struct FLandscapeComponentMaterialOverride> OverrideMaterials; // 0x598 Size: 0x10
	    TArray<class UMaterialInstanceConstant*> MaterialInstances; // 0x5a8 Size: 0x10
	    TArray<class UMaterialInstanceDynamic*> MaterialInstancesDynamic; // 0x5b8 Size: 0x10
	    TArray<int8_t> LODIndexToMaterialIndex; // 0x5c8 Size: 0x10
	    TArray<int8_t> MaterialIndexToDisabledTessellationMaterial; // 0x5d8 Size: 0x10
	    TArray<struct FWeightmapLayerAllocationInfo> WeightmapLayerAllocations; // 0x5e8 Size: 0x10
	    TArray<class UTexture2D*> WeightmapTextures; // 0x5f8 Size: 0x10
	    class UTexture2D* XYOffsetmapTexture; // 0x608 Size: 0x8
	    struct FVector4 WeightmapScaleBias; // 0x610 Size: 0x10
	    float WeightmapSubsectionOffset; // 0x620 Size: 0x4
	    char UnknownData1[0xc]; // 0x624
	    struct FVector4 HeightmapScaleBias; // 0x630 Size: 0x10
	    struct FBox CachedLocalBox; // 0x640 Size: 0x1c
	    TLazyObjectPtr<ULandscapeHeightfieldCollisionComponent*> CollisionComponent; // 0x65c Size: 0x1c
	    class UTexture2D* HeightmapTexture; // 0x678 Size: 0x8
	    struct FGuid MapBuildDataId; // 0x680 Size: 0x10
	    TArray<struct FGuid> IrrelevantLights; // 0x690 Size: 0x10
	    int CollisionMipLevel; // 0x6a0 Size: 0x4
	    int SimpleCollisionMipLevel; // 0x6a4 Size: 0x4
	    float NegativeZBoundsExtension; // 0x6a8 Size: 0x4
	    float PositiveZBoundsExtension; // 0x6ac Size: 0x4
	    float StaticLightingResolution; // 0x6b0 Size: 0x4
	    int ForcedLOD; // 0x6b4 Size: 0x4
	    int LODBias; // 0x6b8 Size: 0x4
	    struct FGuid StateId; // 0x6bc Size: 0x10
	    struct FGuid BakedTextureMaterialGuid; // 0x6cc Size: 0x10
	    char UnknownData2[0x4]; // 0x6dc
	    class UTexture2D* GIBakedBaseColorTexture; // 0x6e0 Size: 0x8
	    char MobileBlendableLayerMask; // 0x6e8 Size: 0x1
	    char UnknownData3[0x7]; // 0x6e9
	    class UMaterialInterface* MobileMaterialInterface; // 0x6f0 Size: 0x8
	    TArray<class UMaterialInterface*> MobileMaterialInterfaces; // 0x6f8 Size: 0x10
	    TArray<class UTexture2D*> MobileWeightmapTextures; // 0x708 Size: 0x10
	    char UnknownData4[0x718]; // 0x718
	    class UMaterialInstanceDynamic* GetMaterialInstanceDynamic(int InIndex); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7881];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.LandscapeComponent");
			return (class UClass*)ptr;
		};

};

class ALandscapeGizmoActor : public AActor
{
	public:
	    char UnknownData0[0x330];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.LandscapeGizmoActor");
			return (class UClass*)ptr;
		};

};

class ALandscapeGizmoActiveActor : public ALandscapeGizmoActor
{
	public:
	    char UnknownData0[0x380];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.LandscapeGizmoActiveActor");
			return (class UClass*)ptr;
		};

};

class ULandscapeGizmoRenderComponent : public UPrimitiveComponent
{
	public:
	    char UnknownData0[0x570];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.LandscapeGizmoRenderComponent");
			return (class UClass*)ptr;
		};

};

class ULandscapeGrassType : public UObject
{
	public:
	    TArray<struct FGrassVariety> GrassVarieties; // 0x28 Size: 0x10
	    bool bEnableDensityScaling; // 0x38 Size: 0x1
	    char UnknownData0[0x7]; // 0x39
	    class UStaticMesh* GrassMesh; // 0x40 Size: 0x8
	    float GrassDensity; // 0x48 Size: 0x4
	    float PlacementJitter; // 0x4c Size: 0x4
	    int StartCullDistance; // 0x50 Size: 0x4
	    int EndCullDistance; // 0x54 Size: 0x4
	    bool RandomRotation; // 0x58 Size: 0x1
	    bool AlignToSurface; // 0x59 Size: 0x1
	    char UnknownData1[0x6];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.LandscapeGrassType");
			return (class UClass*)ptr;
		};

};

class ULandscapeHeightfieldCollisionComponent : public UPrimitiveComponent
{
	public:
	    TArray<class ULandscapeLayerInfoObject*> ComponentLayerInfos; // 0x570 Size: 0x10
	    int SectionBaseX; // 0x580 Size: 0x4
	    int SectionBaseY; // 0x584 Size: 0x4
	    int CollisionSizeQuads; // 0x588 Size: 0x4
	    float CollisionScale; // 0x58c Size: 0x4
	    int SimpleCollisionSizeQuads; // 0x590 Size: 0x4
	    char UnknownData0[0x4]; // 0x594
	    TArray<char> CollisionQuadFlags; // 0x598 Size: 0x10
	    struct FGuid HeightfieldGuid; // 0x5a8 Size: 0x10
	    struct FBox CachedLocalBox; // 0x5b8 Size: 0x1c
	    TLazyObjectPtr<ULandscapeComponent*> RenderComponent; // 0x5d4 Size: 0x1c
	    char UnknownData1[0x10]; // 0x5f0
	    TArray<class UPhysicalMaterial*> CookedPhysicalMaterials; // 0x600 Size: 0x10
	    char UnknownData2[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.LandscapeHeightfieldCollisionComponent");
			return (class UClass*)ptr;
		};

};

class ULandscapeInfo : public UObject
{
	public:
	    TLazyObjectPtr<ALandscape*> LandscapeActor; // 0x28 Size: 0x1c
	    struct FGuid LandscapeGuid; // 0x44 Size: 0x10
	    int ComponentSizeQuads; // 0x54 Size: 0x4
	    int SubsectionSizeQuads; // 0x58 Size: 0x4
	    int ComponentNumSubsections; // 0x5c Size: 0x4
	    struct FVector DrawScale; // 0x60 Size: 0xc
	    char UnknownData0[0x54]; // 0x6c
	    __int64/*SetProperty*/ Proxies; // 0xc0 Size: 0x50
	    char UnknownData1[0xf0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.LandscapeInfo");
			return (class UClass*)ptr;
		};

};

class ULandscapeInfoMap : public UObject
{
	public:
	    char UnknownData0[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.LandscapeInfoMap");
			return (class UClass*)ptr;
		};

};

class ULandscapeLayerInfoObject : public UObject
{
	public:
	    FName LayerName; // 0x28 Size: 0x8
	    class UPhysicalMaterial* PhysMaterial; // 0x30 Size: 0x8
	    float Hardness; // 0x38 Size: 0x4
	    struct FLinearColor LayerUsageDebugColor; // 0x3c Size: 0x10
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.LandscapeLayerInfoObject");
			return (class UClass*)ptr;
		};

};

class ULandscapeMaterialInstanceConstant : public UMaterialInstanceConstant
{
	public:
	    bool bIsLayerThumbnail; // 0x1d8 Size: 0x1
	    bool bDisableTessellation; // 0x1d8 Size: 0x1
	    bool bMobile; // 0x1d8 Size: 0x1
	    bool bEditorToolUsage; // 0x1d8 Size: 0x1
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.LandscapeMaterialInstanceConstant");
			return (class UClass*)ptr;
		};

};

class ULandscapeMeshCollisionComponent : public ULandscapeHeightfieldCollisionComponent
{
	public:
	    struct FGuid MeshGuid; // 0x650 Size: 0x10
	    char UnknownData0[0x10];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.LandscapeMeshCollisionComponent");
			return (class UClass*)ptr;
		};

};

class ALandscapeMeshProxyActor : public AActor
{
	public:
	    class ULandscapeMeshProxyComponent* LandscapeMeshProxyComponent; // 0x330 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.LandscapeMeshProxyActor");
			return (class UClass*)ptr;
		};

};

class ULandscapeMeshProxyComponent : public UStaticMeshComponent
{
	public:
	    struct FGuid LandscapeGuid; // 0x608 Size: 0x10
	    TArray<struct FIntPoint> ProxyComponentBases; // 0x618 Size: 0x10
	    int8_t ProxyLOD; // 0x628 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.LandscapeMeshProxyComponent");
			return (class UClass*)ptr;
		};

};

class ULandscapeSplinesComponent : public UPrimitiveComponent
{
	public:
	    TArray<class ULandscapeSplineControlPoint*> ControlPoints; // 0x570 Size: 0x10
	    TArray<class ULandscapeSplineSegment*> Segments; // 0x580 Size: 0x10
	    TArray<class UMeshComponent*> CookedForeignMeshComponents; // 0x590 Size: 0x10
	    char UnknownData0[0x5a0]; // 0x5a0
	    TArray<class USplineMeshComponent*> GetSplineMeshComponents(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7a41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.LandscapeSplinesComponent");
			return (class UClass*)ptr;
		};

};

class ULandscapeSplineControlPoint : public UObject
{
	public:
	    struct FVector Location; // 0x28 Size: 0xc
	    struct FRotator Rotation; // 0x34 Size: 0xc
	    float Width; // 0x40 Size: 0x4
	    float SideFalloff; // 0x44 Size: 0x4
	    float EndFalloff; // 0x48 Size: 0x4
	    char UnknownData0[0x4]; // 0x4c
	    TArray<struct FLandscapeSplineConnection> ConnectedSegments; // 0x50 Size: 0x10
	    TArray<struct FLandscapeSplineInterpPoint> Points; // 0x60 Size: 0x10
	    struct FBox Bounds; // 0x70 Size: 0x1c
	    char UnknownData1[0x4]; // 0x8c
	    class UControlPointMeshComponent* LocalMeshComponent; // 0x90 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.LandscapeSplineControlPoint");
			return (class UClass*)ptr;
		};

};

class ULandscapeSplineSegment : public UObject
{
	public:
	    struct FLandscapeSplineSegmentConnection* Connections; // 0x28 Size: 0x18
	    char UnknownData0[0x18]; // 0x40
	    struct FInterpCurveVector SplineInfo; // 0x58 Size: 0x18
	    TArray<struct FLandscapeSplineInterpPoint> Points; // 0x70 Size: 0x10
	    struct FBox Bounds; // 0x80 Size: 0x1c
	    char UnknownData1[0x4]; // 0x9c
	    TArray<class USplineMeshComponent*> LocalMeshComponents; // 0xa0 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.LandscapeSplineSegment");
			return (class UClass*)ptr;
		};

};

class ALandscapeStreamingProxy : public ALandscapeProxy
{
	public:
	    TLazyObjectPtr<ALandscape*> LandscapeActor; // 0x648 Size: 0x1c
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.LandscapeStreamingProxy");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionLandscapeGrassOutput : public UMaterialExpressionCustomOutput
{
	public:
	    TArray<struct FGrassInput> GrassTypes; // 0x40 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.MaterialExpressionLandscapeGrassOutput");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionLandscapeLayerBlend : public UMaterialExpression
{
	public:
	    TArray<struct FLayerBlendInput> Layers; // 0x40 Size: 0x10
	    struct FGuid ExpressionGUID; // 0x50 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.MaterialExpressionLandscapeLayerBlend");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionLandscapeLayerCoords : public UMaterialExpression
{
	public:
	    char MappingType; // 0x40 Size: 0x1
	    char CustomUVType; // 0x41 Size: 0x1
	    char UnknownData0[0x2]; // 0x42
	    float MappingScale; // 0x44 Size: 0x4
	    float MappingRotation; // 0x48 Size: 0x4
	    float MappingPanU; // 0x4c Size: 0x4
	    float MappingPanV; // 0x50 Size: 0x4
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.MaterialExpressionLandscapeLayerCoords");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionLandscapeLayerSample : public UMaterialExpression
{
	public:
	    FName ParameterName; // 0x40 Size: 0x8
	    float PreviewWeight; // 0x48 Size: 0x4
	    struct FGuid ExpressionGUID; // 0x4c Size: 0x10
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.MaterialExpressionLandscapeLayerSample");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionLandscapeLayerSwitch : public UMaterialExpression
{
	public:
	    struct FExpressionInput LayerUsed; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput LayerNotUsed; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    FName ParameterName; // 0x68 Size: 0x8
	    bool PreviewUsed; // 0x70 Size: 0x1
	    char UnknownData2[0x3]; // 0x71
	    struct FGuid ExpressionGUID; // 0x74 Size: 0x10
	    char UnknownData3[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.MaterialExpressionLandscapeLayerSwitch");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionLandscapeLayerWeight : public UMaterialExpression
{
	public:
	    struct FExpressionInput Base; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput Layer; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    FName ParameterName; // 0x68 Size: 0x8
	    float PreviewWeight; // 0x70 Size: 0x4
	    struct FVector ConstBase; // 0x74 Size: 0xc
	    struct FGuid ExpressionGUID; // 0x80 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.MaterialExpressionLandscapeLayerWeight");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionLandscapeVisibilityMask : public UMaterialExpression
{
	public:
	    struct FGuid ExpressionGUID; // 0x40 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Landscape.MaterialExpressionLandscapeVisibilityMask");
			return (class UClass*)ptr;
		};

};


}