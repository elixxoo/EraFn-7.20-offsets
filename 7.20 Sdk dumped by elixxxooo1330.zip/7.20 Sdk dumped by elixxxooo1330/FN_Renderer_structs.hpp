#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FLightPropagationVolumeSettings
{
	public:
	    bool bOverride_LPVIntensity; // 0x0 Size: 0x1
	    bool bOverride_LPVDirectionalOcclusionIntensity; // 0x0 Size: 0x1
	    bool bOverride_LPVDirectionalOcclusionRadius; // 0x0 Size: 0x1
	    bool bOverride_LPVDiffuseOcclusionExponent; // 0x0 Size: 0x1
	    bool bOverride_LPVSpecularOcclusionExponent; // 0x0 Size: 0x1
	    bool bOverride_LPVDiffuseOcclusionIntensity; // 0x0 Size: 0x1
	    bool bOverride_LPVSpecularOcclusionIntensity; // 0x0 Size: 0x1
	    bool bOverride_LPVSize; // 0x0 Size: 0x1
	    bool bOverride_LPVSecondaryOcclusionIntensity; // 0x1 Size: 0x1
	    bool bOverride_LPVSecondaryBounceIntensity; // 0x1 Size: 0x1
	    bool bOverride_LPVGeometryVolumeBias; // 0x1 Size: 0x1
	    bool bOverride_LPVVplInjectionBias; // 0x1 Size: 0x1
	    bool bOverride_LPVEmissiveInjectionIntensity; // 0x1 Size: 0x1
	    Yea, we fucked up; // 0x0
	    float LPVIntensity; // 0x4 Size: 0x4
	    float LPVVplInjectionBias; // 0x8 Size: 0x4
	    float LPVSize; // 0xc Size: 0x4
	    float LPVSecondaryOcclusionIntensity; // 0x10 Size: 0x4
	    float LPVSecondaryBounceIntensity; // 0x14 Size: 0x4
	    float LPVGeometryVolumeBias; // 0x18 Size: 0x4
	    float LPVEmissiveInjectionIntensity; // 0x1c Size: 0x4
	    float LPVDirectionalOcclusionIntensity; // 0x20 Size: 0x4
	    float LPVDirectionalOcclusionRadius; // 0x24 Size: 0x4
	    float LPVDiffuseOcclusionExponent; // 0x28 Size: 0x4
	    float LPVSpecularOcclusionExponent; // 0x2c Size: 0x4
	    float LPVDiffuseOcclusionIntensity; // 0x30 Size: 0x4
	    float LPVSpecularOcclusionIntensity; // 0x34 Size: 0x4
	    float LPVFadeRange; // 0x38 Size: 0x4
	    float LPVDirectionalOcclusionFadeRange; // 0x3c Size: 0x4

};


}