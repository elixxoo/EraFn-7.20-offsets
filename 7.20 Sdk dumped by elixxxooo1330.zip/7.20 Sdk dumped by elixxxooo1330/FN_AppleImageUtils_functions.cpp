#include "../SDK.hpp"

static class UAppleImageUtilsBaseAsyncTaskBlueprintProxy* UAppleImageUtilsBaseAsyncTaskBlueprintProxy::CreateProxyObjectForConvertToTIFF(class UTexture* SourceImage, bool bWantColor, bool bUseGpu, float Scale, ETextureRotationDirection Rotate)
{
	struct {
            class UTexture* SourceImage;
            bool bWantColor;
            bool bUseGpu;
            float Scale;
            ETextureRotationDirection Rotate;
            class UAppleImageUtilsBaseAsyncTaskBlueprintProxy* ReturnValue;
	} params{ SourceImage, bWantColor, bUseGpu, Scale, Rotate };

    static auto fn = UObject::FindObject("/Script/AppleImageUtils.AppleImageUtilsBaseAsyncTaskBlueprintProxy:CreateProxyObjectForConvertToTIFF");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UAppleImageUtilsBaseAsyncTaskBlueprintProxy* UAppleImageUtilsBaseAsyncTaskBlueprintProxy::CreateProxyObjectForConvertToPNG(class UTexture* SourceImage, bool bWantColor, bool bUseGpu, float Scale, ETextureRotationDirection Rotate)
{
	struct {
            class UTexture* SourceImage;
            bool bWantColor;
            bool bUseGpu;
            float Scale;
            ETextureRotationDirection Rotate;
            class UAppleImageUtilsBaseAsyncTaskBlueprintProxy* ReturnValue;
	} params{ SourceImage, bWantColor, bUseGpu, Scale, Rotate };

    static auto fn = UObject::FindObject("/Script/AppleImageUtils.AppleImageUtilsBaseAsyncTaskBlueprintProxy:CreateProxyObjectForConvertToPNG");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UAppleImageUtilsBaseAsyncTaskBlueprintProxy* UAppleImageUtilsBaseAsyncTaskBlueprintProxy::CreateProxyObjectForConvertToJPEG(class UTexture* SourceImage, int Quality, bool bWantColor, bool bUseGpu, float Scale, ETextureRotationDirection Rotate)
{
	struct {
            class UTexture* SourceImage;
            int Quality;
            bool bWantColor;
            bool bUseGpu;
            float Scale;
            ETextureRotationDirection Rotate;
            class UAppleImageUtilsBaseAsyncTaskBlueprintProxy* ReturnValue;
	} params{ SourceImage, Quality, bWantColor, bUseGpu, Scale, Rotate };

    static auto fn = UObject::FindObject("/Script/AppleImageUtils.AppleImageUtilsBaseAsyncTaskBlueprintProxy:CreateProxyObjectForConvertToJPEG");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UAppleImageUtilsBaseAsyncTaskBlueprintProxy* UAppleImageUtilsBaseAsyncTaskBlueprintProxy::CreateProxyObjectForConvertToHEIF(class UTexture* SourceImage, int Quality, bool bWantColor, bool bUseGpu, float Scale, ETextureRotationDirection Rotate)
{
	struct {
            class UTexture* SourceImage;
            int Quality;
            bool bWantColor;
            bool bUseGpu;
            float Scale;
            ETextureRotationDirection Rotate;
            class UAppleImageUtilsBaseAsyncTaskBlueprintProxy* ReturnValue;
	} params{ SourceImage, Quality, bWantColor, bUseGpu, Scale, Rotate };

    static auto fn = UObject::FindObject("/Script/AppleImageUtils.AppleImageUtilsBaseAsyncTaskBlueprintProxy:CreateProxyObjectForConvertToHEIF");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

