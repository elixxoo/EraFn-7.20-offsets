#pragma once

#include "../SDK.hpp"

namespace SDK {


class ULevelSequence : public UMovieSceneSequence
{
	public:
	    class UMovieScene* MovieScene; // 0x348 Size: 0x8
	    class UObject* DirectorClass; // 0x350 Size: 0x8
	    struct FLevelSequenceObjectReferenceMap ObjectReferences; // 0x358 Size: 0x50
	    struct FLevelSequenceBindingReferences BindingReferences; // 0x3a8 Size: 0xa0
	    __int64/*MapProperty*/ PossessedObjects; // 0x448 Size: 0x50

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/LevelSequence.LevelSequence");
			return (class UClass*)ptr;
		};

};

class UDefaultLevelSequenceInstanceData : public UObject
{
	public:
	    char UnknownData0[0x8];
	    class AActor* TransformOriginActor; // 0x30 Size: 0x8
	    char UnknownData1[0x8]; // 0x38
	    struct FTransform TransformOrigin; // 0x40 Size: 0x30

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/LevelSequence.DefaultLevelSequenceInstanceData");
			return (class UClass*)ptr;
		};

};

class ULevelSequenceBurnInInitSettings : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/LevelSequence.LevelSequenceBurnInInitSettings");
			return (class UClass*)ptr;
		};

};

class ULevelSequenceBurnInOptions : public UObject
{
	public:
	    bool bUseBurnIn; // 0x28 Size: 0x1
	    char UnknownData0[0x7]; // 0x29
	    struct FSoftClassPath BurnInClass; // 0x30 Size: 0x18
	    class ULevelSequenceBurnInInitSettings* Settings; // 0x48 Size: 0x8
	    char UnknownData1[0x50]; // 0x50
	    void SetBurnIn(struct FSoftClassPath InBurnInClass); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/LevelSequence.LevelSequenceBurnInOptions");
			return (class UClass*)ptr;
		};

};

class ALevelSequenceActor : public AActor
{
	public:
	    char UnknownData0[0x10];
	    struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // 0x340 Size: 0x10
	    class ULevelSequencePlayer* SequencePlayer; // 0x350 Size: 0x8
	    struct FSoftObjectPath LevelSequence; // 0x358 Size: 0x18
	    TArray<class AActor*> AdditionalEventReceivers; // 0x370 Size: 0x10
	    class ULevelSequenceBurnInOptions* BurnInOptions; // 0x380 Size: 0x8
	    class UMovieSceneBindingOverrides* BindingOverrides; // 0x388 Size: 0x8
	    bool bAutoPlay; // 0x390 Size: 0x1
	    bool bOverrideInstanceData; // 0x390 Size: 0x1
	    bool bReplicatePlayback; // 0x390 Size: 0x1
	    char UnknownData1[0x5]; // 0x393
	    class UObject* DefaultInstanceData; // 0x398 Size: 0x8
	    class ULevelSequenceBurnIn* BurnInInstance; // 0x3a0 Size: 0x8
	    char UnknownData2[0x3a8]; // 0x3a8
	    void SetSequence(class ULevelSequence* InSequence); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetReplicatePlayback(bool ReplicatePlayback); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetEventReceivers(TArray<class AActor*> AdditionalReceivers); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetBinding(struct FMovieSceneObjectBindingID Binding, TArray<class AActor*> Actors, bool bAllowBindingsFromAsset); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ResetBindings(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void ResetBinding(struct FMovieSceneObjectBindingID Binding); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void RemoveBinding(struct FMovieSceneObjectBindingID Binding, class AActor* Actor); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnLevelSequenceLoaded__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    class ULevelSequence* LoadSequence(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    class ULevelSequence* GetSequence(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void AddBinding(struct FMovieSceneObjectBindingID Binding, class AActor* Actor, bool bAllowBindingsFromAsset); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x-7c39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/LevelSequence.LevelSequenceActor");
			return (class UClass*)ptr;
		};

};

class ULevelSequenceBurnIn : public UUserWidget
{
	public:
	    struct FLevelSequencePlayerSnapshot FrameInformation; // 0x228 Size: 0x88
	    class ALevelSequenceActor* LevelSequenceActor; // 0x2b0 Size: 0x8
	    char UnknownData0[0x2b8]; // 0x2b8
	    void SetSettings(class UObject* InSettings); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    class ULevelSequenceBurnInInitSettings* GetSettingsClass(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/LevelSequence.LevelSequenceBurnIn");
			return (class UClass*)ptr;
		};

};

class ULevelSequenceDirector : public UObject
{
	public:
	    class ULevelSequencePlayer* Player; // 0x28 Size: 0x8
	    char UnknownData0[0x30]; // 0x30
	    void OnCreated(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7fb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/LevelSequence.LevelSequenceDirector");
			return (class UClass*)ptr;
		};

};

class ULegacyLevelSequenceDirectorBlueprint : public UBlueprint
{
	public:
	    char UnknownData0[0xe0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/LevelSequence.LegacyLevelSequenceDirectorBlueprint");
			return (class UClass*)ptr;
		};

};

class ULevelSequencePlayer : public UMovieSceneSequencePlayer
{
	public:
	    MulticastDelegateProperty OnCameraCut; // 0x7c0 Size: 0x10
	    char UnknownData0[0x7d0]; // 0x7d0
	    static class ULevelSequencePlayer* CreateLevelSequencePlayer(class UObject* WorldContextObject, class ULevelSequence* LevelSequence, struct FMovieSceneSequencePlaybackSettings Settings, class ALevelSequenceActor* OutActor); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7791];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/LevelSequence.LevelSequencePlayer");
			return (class UClass*)ptr;
		};

};


}