#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FClothCollisionPrim_SphereConnection
{
	public:
	    int SphereIndices; // 0x0 Size: 0x4
	    char UnknownData0[0x4];

};

struct FClothCollisionPrim_Sphere
{
	public:
	    int BoneIndex; // 0x0 Size: 0x4
	    float Radius; // 0x4 Size: 0x4
	    struct FVector LocalPosition; // 0x8 Size: 0xc

};


}