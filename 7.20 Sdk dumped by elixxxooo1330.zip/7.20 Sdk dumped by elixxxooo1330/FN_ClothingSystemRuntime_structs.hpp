#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class EClothingWindMethod : uint8_t
{
    Legacy = 0,
    Accurate = 1,
    EClothingWindMethod_MAX = 2
};

enum class MaskTarget_PhysMesh : uint8_t
{
    None = 0,
    MaxDistance = 1,
    BackstopDistance = 2,
    BackstopRadius = 3,
    AnimDriveMultiplier = 4,
    MaskTarget_MAX = 5
};struct FClothConstraintSetup
{
	public:
	    float Stiffness; // 0x0 Size: 0x4
	    float StiffnessMultiplier; // 0x4 Size: 0x4
	    float StretchLimit; // 0x8 Size: 0x4
	    float CompressionLimit; // 0xc Size: 0x4

};

struct FClothConfig
{
	public:
	    EClothingWindMethod WindMethod; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    struct FClothConstraintSetup VerticalConstraintConfig; // 0x4 Size: 0x10
	    struct FClothConstraintSetup HorizontalConstraintConfig; // 0x14 Size: 0x10
	    struct FClothConstraintSetup BendConstraintConfig; // 0x24 Size: 0x10
	    struct FClothConstraintSetup ShearConstraintConfig; // 0x34 Size: 0x10
	    float SelfCollisionRadius; // 0x44 Size: 0x4
	    float SelfCollisionStiffness; // 0x48 Size: 0x4
	    float SelfCollisionCullScale; // 0x4c Size: 0x4
	    struct FVector Damping; // 0x50 Size: 0xc
	    float Friction; // 0x5c Size: 0x4
	    float WindDragCoefficient; // 0x60 Size: 0x4
	    float WindLiftCoefficient; // 0x64 Size: 0x4
	    struct FVector LinearDrag; // 0x68 Size: 0xc
	    struct FVector AngularDrag; // 0x74 Size: 0xc
	    struct FVector LinearInertiaScale; // 0x80 Size: 0xc
	    struct FVector AngularInertiaScale; // 0x8c Size: 0xc
	    struct FVector CentrifugalInertiaScale; // 0x98 Size: 0xc
	    float SolverFrequency; // 0xa4 Size: 0x4
	    float StiffnessFrequency; // 0xa8 Size: 0x4
	    float GravityScale; // 0xac Size: 0x4
	    struct FVector GravityOverride; // 0xb0 Size: 0xc
	    bool bUseGravityOverride; // 0xbc Size: 0x1
	    char UnknownData1[0x3]; // 0xbd
	    float TetherStiffness; // 0xc0 Size: 0x4
	    float TetherLimit; // 0xc4 Size: 0x4
	    float CollisionThickness; // 0xc8 Size: 0x4
	    float AnimDriveSpringStiffness; // 0xcc Size: 0x4
	    float AnimDriveDamperStiffness; // 0xd0 Size: 0x4

};

struct FClothVertBoneData
{
	public:
	    int NumInfluences; // 0x0 Size: 0x4
	    __int64/*UInt16Property*/ BoneIndices; // 0x4 Size: 0x2
	    char UnknownData0[0xe]; // 0x6
	    float BoneWeights; // 0x14 Size: 0x4
	    char UnknownData1[0x1c];

};


}