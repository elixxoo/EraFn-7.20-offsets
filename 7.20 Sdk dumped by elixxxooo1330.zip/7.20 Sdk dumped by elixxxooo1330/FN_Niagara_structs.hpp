#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class ENiagaraCollisionMode : uint8_t
{
    None = 0,
    SceneGeometry = 1,
    DepthBuffer = 2,
    DistanceField = 3,
    ENiagaraCollisionMode_MAX = 4
};

enum class ENiagaraScriptGroup : uint8_t
{
    Particle = 0,
    Emitter = 1,
    System = 2,
    Max = 3
};

enum class ENiagaraScriptUsage : uint8_t
{
    Function = 0,
    Module = 1,
    DynamicInput = 2,
    ParticleSpawnScript = 3,
    ParticleSpawnScriptInterpolated = 4,
    ParticleUpdateScript = 5,
    ParticleEventScript = 6,
    ParticleGPUComputeScript = 7,
    EmitterSpawnScript = 8,
    EmitterUpdateScript = 9,
    SystemSpawnScript = 10,
    SystemUpdateScript = 11,
    ENiagaraScriptUsage_MAX = 12
};

enum class ENiagaraScriptCompileStatus : uint8_t
{
    NCS_Unknown = 0,
    NCS_Dirty = 1,
    NCS_Error = 2,
    NCS_UpToDate = 3,
    NCS_BeingCreated = 4,
    NCS_UpToDateWithWarnings = 5,
    NCS_ComputeUpToDateWithWarnings = 6,
    NCS_MAX = 7
};

enum class ENiagaraInputNodeUsage : uint8_t
{
    Undefined = 0,
    Parameter = 1,
    Attribute = 2,
    SystemConstant = 3,
    TranslatorConstant = 4,
    RapidIterationParameter = 5,
    ENiagaraInputNodeUsage_MAX = 6
};

enum class ENiagaraDataSetType : uint8_t
{
    ParticleData = 0,
    Shared = 1,
    Event = 2,
    ENiagaraDataSetType_MAX = 3
};

enum class ENiagaraAgeUpdateMode : uint8_t
{
    TickDeltaTime = 0,
    DesiredAge = 1,
    ENiagaraAgeUpdateMode_MAX = 2
};

enum class ENiagaraSimTarget : uint8_t
{
    CPUSim = 0,
    GPUComputeSim = 1,
    DynamicLoadBalancedSim = 2,
    ENiagaraSimTarget_MAX = 3
};

enum class ENDISkeletalMesh_SkinningMode : uint8_t
{
    None = 0,
    SkinOnTheFly = 1,
    PreSkin = 2,
    ENDISkeletalMesh_MAX = 3
};

enum class EScriptExecutionMode : uint8_t
{
    EveryParticle = 0,
    SpawnedParticles = 1,
    SingleParticle = 2,
    EScriptExecutionMode_MAX = 3
};

enum class ENiagaraMeshFacingMode : uint8_t
{
    Default = 0,
    Velocity = 1,
    CameraPosition = 2,
    CameraPlane = 3,
    ENiagaraMeshFacingMode_MAX = 4
};

enum class ENiagaraSortMode : uint8_t
{
    None = 0,
    ViewDepth = 1,
    ViewDistance = 2,
    CustomAscending = 3,
    CustomDecending = 4,
    ENiagaraSortMode_MAX = 5
};

enum class ENiagaraRibbonDrawDirection : uint8_t
{
    FrontToBack = 0,
    BackToFront = 1,
    ENiagaraRibbonDrawDirection_MAX = 2
};

enum class ENiagaraRibbonAgeOffsetMode : uint8_t
{
    Scale = 0,
    Clip = 1,
    ENiagaraRibbonAgeOffsetMode_MAX = 2
};

enum class ENiagaraRibbonFacingMode : uint8_t
{
    Screen = 0,
    Custom = 1,
    ENiagaraRibbonFacingMode_MAX = 2
};

enum class ENiagaraModuleDependencyType : uint8_t
{
    PreDependency = 0,
    PostDependency = 1,
    ENiagaraModuleDependencyType_MAX = 2
};

enum class EUnusedAttributeBehaviour : uint8_t
{
    Copy = 0,
    Zero = 1,
    None = 2,
    MarkInvalid = 3,
    PassThrough = 4,
    EUnusedAttributeBehaviour_MAX = 5
};

enum class ENiagaraSpriteFacingMode : uint8_t
{
    FaceCamera = 0,
    FaceCameraPlane = 1,
    CustomFacingVector = 2,
    FaceCameraPosition = 3,
    FaceCameraDistanceBlend = 4,
    ENiagaraSpriteFacingMode_MAX = 5
};

enum class ENiagaraSpriteAlignment : uint8_t
{
    Unaligned = 0,
    VelocityAligned = 1,
    CustomAlignment = 2,
    ENiagaraSpriteAlignment_MAX = 3
};

enum class ENiagaraExecutionState : uint8_t
{
    Active = 0,
    Inactive = 1,
    InactiveClear = 2,
    Complete = 3,
    Disabled = 4,
    Num = 5,
    ENiagaraExecutionState_MAX = 6
};

enum class ENiagaraExecutionStateSource : uint8_t
{
    Scalability = 0,
    Internal = 1,
    Owner = 2,
    InternalCompletion = 3,
    ENiagaraExecutionStateSource_MAX = 4
};

enum class ENiagaraNumericOutputTypeSelectionMode : uint8_t
{
    None = 0,
    Largest = 1,
    Smallest = 2,
    Scalar = 3,
    ENiagaraNumericOutputTypeSelectionMode_MAX = 4
};struct FNiagaraTypeDefinition
{
	public:
	    class UStruct* Struct; // 0x0 Size: 0x8
	    class UEnum* Enum; // 0x8 Size: 0x8
	    char UnknownData0[0x8];

};

struct FMovieSceneNiagaraSystemTrackImplementation : public FMovieSceneTrackImplementation
{
	public:
	    char UnknownData0[0x18];

};

struct FMovieSceneNiagaraSystemTrackTemplate : public FMovieSceneEvalTemplate
{
	public:
	    char UnknownData0[0x20];

};

struct FNiagaraStatScope
{
	public:
	    FName FullName; // 0x0 Size: 0x8
	    FName FriendlyName; // 0x8 Size: 0x8

};

struct FNiagaraScriptDataInterfaceInfo
{
	public:
	    class UNiagaraDataInterface* DataInterface; // 0x0 Size: 0x8
	    FName Name; // 0x8 Size: 0x8
	    int UserPtrIdx; // 0x10 Size: 0x4
	    char UnknownData0[0x4]; // 0x14
	    struct FNiagaraTypeDefinition Type; // 0x18 Size: 0x18
	    FName RegisteredParameterMapRead; // 0x30 Size: 0x8
	    FName RegisteredParameterMapWrite; // 0x38 Size: 0x8

};

struct FNiagaraScriptDataUsageInfo
{
	public:
	    bool bReadsAttributeData; // 0x0 Size: 0x1

};

struct FNiagaraDataSetID
{
	public:
	    FName Name; // 0x0 Size: 0x8
	    ENiagaraDataSetType Type; // 0x8 Size: 0x1
	    char UnknownData0[0x3];

};

struct FMeshTriCoordinate
{
	public:
	    int Tri; // 0x0 Size: 0x4
	    struct FVector BaryCoord; // 0x4 Size: 0xc

};

struct FNiagaraEventReceiverProperties
{
	public:
	    FName Name; // 0x0 Size: 0x8
	    FName SourceEventGenerator; // 0x8 Size: 0x8
	    FName SourceEmitter; // 0x10 Size: 0x8

};

struct FNiagaraEventScriptProperties : public FNiagaraEmitterScriptProperties
{
	public:
	    EScriptExecutionMode ExecutionMode; // 0x28 Size: 0x1
	    char UnknownData0[0x3]; // 0x29
	    uint32_t SpawnNumber; // 0x2c Size: 0x4
	    uint32_t MaxEventsPerFrame; // 0x30 Size: 0x4
	    struct FGuid SourceEmitterID; // 0x34 Size: 0x10
	    FName SourceEventName; // 0x44 Size: 0x8
	    bool bRandomSpawnNumber; // 0x4c Size: 0x1
	    char UnknownData1[0x3]; // 0x4d
	    uint32_t MinSpawnNumber; // 0x50 Size: 0x4
	    char UnknownData2[0x4];

};

struct FNiagaraEmitterHandle
{
	public:
	    struct FGuid ID; // 0x0 Size: 0x10
	    FName IdName; // 0x10 Size: 0x8
	    bool bIsEnabled; // 0x18 Size: 0x1
	    char UnknownData0[0x3]; // 0x19
	    FName Name; // 0x1c Size: 0x8
	    char UnknownData1[0x4]; // 0x24
	    class UNiagaraEmitter* Instance; // 0x28 Size: 0x8

};

struct FNiagaraCollisionEventPayload
{
	public:
	    struct FVector CollisionPos; // 0x0 Size: 0xc
	    struct FVector CollisionNormal; // 0xc Size: 0xc
	    struct FVector CollisionVelocity; // 0x18 Size: 0xc
	    int ParticleIndex; // 0x24 Size: 0x4
	    int PhysicalMaterialIndex; // 0x28 Size: 0x4

};

struct FNiagaraModuleDependency
{
	public:
	    FName ID; // 0x0 Size: 0x8
	    ENiagaraModuleDependencyType Type; // 0x8 Size: 0x1
	    char UnknownData0[0x7]; // 0x9
	    struct FText Description; // 0x10 Size: 0x18

};

struct FNiagaraScriptExecutionPaddingInfo
{
	public:
	    char UnknownData0[0x10];

};

struct FEmitterCompiledScriptPair
{
	public:
	    char UnknownData0[0x98];

};

struct FNiagaraID
{
	public:
	    int Index; // 0x0 Size: 0x4
	    int AcquireTag; // 0x4 Size: 0x4

};

struct FNiagaraSpawnInfo
{
	public:
	    int Count; // 0x0 Size: 0x4
	    float InterpStartDt; // 0x4 Size: 0x4
	    float IntervalDt; // 0x8 Size: 0x4
	    int SpawnGroup; // 0xc Size: 0x4

};

struct FNiagaraMatrix
{
	public:
	    struct FVector4 Row0; // 0x0 Size: 0x10
	    struct FVector4 Row1; // 0x10 Size: 0x10
	    struct FVector4 Row2; // 0x20 Size: 0x10
	    struct FVector4 Row3; // 0x30 Size: 0x10

};

struct FNiagaraTestStructInner
{
	public:
	    struct FVector InnerVector1; // 0x0 Size: 0xc
	    struct FVector InnerVector2; // 0xc Size: 0xc

};

struct FNiagaraTestStruct
{
	public:
	    struct FVector Vector1; // 0x0 Size: 0xc
	    struct FVector Vector2; // 0xc Size: 0xc
	    struct FNiagaraTestStructInner InnerStruct1; // 0x18 Size: 0x18
	    struct FNiagaraTestStructInner InnerStruct2; // 0x30 Size: 0x18

};

struct FNiagaraParameterMap
{
	public:
	    char UnknownData0[0x1];

};

struct FNiagaraNumeric
{
	public:
	    char UnknownData0[0x1];

};

struct FNiagaraBool
{
	public:
	    int Value; // 0x0 Size: 0x4

};

struct FNiagaraInt32
{
	public:
	    int Value; // 0x0 Size: 0x4

};

struct FNiagaraFloat
{
	public:
	    float Value; // 0x0 Size: 0x4

};


}