#pragma once

#include "../SDK.hpp"

namespace SDK {


class UImageWriteBlueprintLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void ExportToDisk(class UTexture* Texture, struct FString Filename, struct FImageWriteOptions Options); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ImageWriteQueue.ImageWriteBlueprintLibrary");
			return (class UClass*)ptr;
		};

};


}