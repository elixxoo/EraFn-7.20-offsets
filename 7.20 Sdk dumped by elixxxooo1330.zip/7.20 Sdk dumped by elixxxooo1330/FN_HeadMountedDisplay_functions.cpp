#include "../SDK.hpp"

static void UHeadMountedDisplayFunctionLibrary::UpdateExternalTrackingHMDPosition(struct FTransform ExternalTrackingTransform)
{
	struct {
            struct FTransform ExternalTrackingTransform;            void ReturnValue;
	} params{ ExternalTrackingTransform };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:UpdateExternalTrackingHMDPosition");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UHeadMountedDisplayFunctionLibrary::SetWorldToMetersScale(class UObject* WorldContext, float NewScale)
{
	struct {
            class UObject* WorldContext;
            float NewScale;            void ReturnValue;
	} params{ WorldContext, NewScale };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:SetWorldToMetersScale");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UHeadMountedDisplayFunctionLibrary::SetTrackingOrigin(char Origin)
{
	struct {
            char Origin;            void ReturnValue;
	} params{ Origin };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:SetTrackingOrigin");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UHeadMountedDisplayFunctionLibrary::SetSpectatorScreenTexture(class UTexture* InTexture)
{
	struct {
            class UTexture* InTexture;            void ReturnValue;
	} params{ InTexture };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:SetSpectatorScreenTexture");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UHeadMountedDisplayFunctionLibrary::SetSpectatorScreenModeTexturePlusEyeLayout(struct FVector2D EyeRectMin, struct FVector2D EyeRectMax, struct FVector2D TextureRectMin, struct FVector2D TextureRectMax, bool bDrawEyeFirst, bool bClearBlack, bool bUseAlpha)
{
	struct {
            struct FVector2D EyeRectMin;
            struct FVector2D EyeRectMax;
            struct FVector2D TextureRectMin;
            struct FVector2D TextureRectMax;
            bool bDrawEyeFirst;
            bool bClearBlack;
            bool bUseAlpha;            void ReturnValue;
	} params{ EyeRectMin, EyeRectMax, TextureRectMin, TextureRectMax, bDrawEyeFirst, bClearBlack, bUseAlpha };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:SetSpectatorScreenModeTexturePlusEyeLayout");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UHeadMountedDisplayFunctionLibrary::SetSpectatorScreenMode(ESpectatorScreenMode Mode)
{
	struct {
            ESpectatorScreenMode Mode;            void ReturnValue;
	} params{ Mode };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:SetSpectatorScreenMode");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UHeadMountedDisplayFunctionLibrary::SetClippingPlanes(float Near, float Far)
{
	struct {
            float Near;
            float Far;            void ReturnValue;
	} params{ Near, Far };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:SetClippingPlanes");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UHeadMountedDisplayFunctionLibrary::ResetOrientationAndPosition(float Yaw, char Options)
{
	struct {
            float Yaw;
            char Options;            void ReturnValue;
	} params{ Yaw, Options };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:ResetOrientationAndPosition");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UHeadMountedDisplayFunctionLibrary::IsSpectatorScreenModeControllable()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:IsSpectatorScreenModeControllable");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static bool UHeadMountedDisplayFunctionLibrary::IsInLowPersistenceMode()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:IsInLowPersistenceMode");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static bool UHeadMountedDisplayFunctionLibrary::IsHeadMountedDisplayEnabled()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:IsHeadMountedDisplayEnabled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static bool UHeadMountedDisplayFunctionLibrary::IsHeadMountedDisplayConnected()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:IsHeadMountedDisplayConnected");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static bool UHeadMountedDisplayFunctionLibrary::IsDeviceTracking(struct FXRDeviceId XRDeviceId)
{
	struct {
            struct FXRDeviceId XRDeviceId;
            bool ReturnValue;
	} params{ XRDeviceId };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:IsDeviceTracking");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UHeadMountedDisplayFunctionLibrary::HasValidTrackingPosition()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:HasValidTrackingPosition");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static float UHeadMountedDisplayFunctionLibrary::GetWorldToMetersScale(class UObject* WorldContext)
{
	struct {
            class UObject* WorldContext;
            float ReturnValue;
	} params{ WorldContext };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:GetWorldToMetersScale");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UHeadMountedDisplayFunctionLibrary::GetVRFocusState(bool bUseFocus, bool bHasFocus)
{
	struct {
            bool bUseFocus;
            bool bHasFocus;            void ReturnValue;
	} params{ bUseFocus, bHasFocus };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:GetVRFocusState");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FTransform UHeadMountedDisplayFunctionLibrary::GetTrackingToWorldTransform(class UObject* WorldContext)
{
	struct {
            class UObject* WorldContext;
            struct FTransform ReturnValue;
	} params{ WorldContext };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:GetTrackingToWorldTransform");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UHeadMountedDisplayFunctionLibrary::GetTrackingSensorParameters(struct FVector Origin, struct FRotator Rotation, float LeftFOV, float RightFOV, float TopFOV, float BottomFOV, float Distance, float NearPlane, float FarPlane, bool IsActive, int Index)
{
	struct {
            struct FVector Origin;
            struct FRotator Rotation;
            float LeftFOV;
            float RightFOV;
            float TopFOV;
            float BottomFOV;
            float Distance;
            float NearPlane;
            float FarPlane;
            bool IsActive;
            int Index;            void ReturnValue;
	} params{ Origin, Rotation, LeftFOV, RightFOV, TopFOV, BottomFOV, Distance, NearPlane, FarPlane, IsActive, Index };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:GetTrackingSensorParameters");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static char UHeadMountedDisplayFunctionLibrary::GetTrackingOrigin()
{
	struct {
            char ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:GetTrackingOrigin");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static float UHeadMountedDisplayFunctionLibrary::GetScreenPercentage()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:GetScreenPercentage");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static void UHeadMountedDisplayFunctionLibrary::GetPositionalTrackingCameraParameters(struct FVector CameraOrigin, struct FRotator CameraRotation, float HFOV, float VFOV, float CameraDistance, float NearPlane, float FarPlane)
{
	struct {
            struct FVector CameraOrigin;
            struct FRotator CameraRotation;
            float HFOV;
            float VFOV;
            float CameraDistance;
            float NearPlane;
            float FarPlane;            void ReturnValue;
	} params{ CameraOrigin, CameraRotation, HFOV, VFOV, CameraDistance, NearPlane, FarPlane };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:GetPositionalTrackingCameraParameters");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static float UHeadMountedDisplayFunctionLibrary::GetPixelDensity()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:GetPixelDensity");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static void UHeadMountedDisplayFunctionLibrary::GetOrientationAndPosition(struct FRotator DeviceRotation, struct FVector DevicePosition)
{
	struct {
            struct FRotator DeviceRotation;
            struct FVector DevicePosition;            void ReturnValue;
	} params{ DeviceRotation, DevicePosition };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:GetOrientationAndPosition");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static int UHeadMountedDisplayFunctionLibrary::GetNumOfTrackingSensors()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:GetNumOfTrackingSensors");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static char UHeadMountedDisplayFunctionLibrary::GetHMDWornState()
{
	struct {
            char ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:GetHMDWornState");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static FName UHeadMountedDisplayFunctionLibrary::GetHMDDeviceName()
{
	struct {
            FName ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:GetHMDDeviceName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static void UHeadMountedDisplayFunctionLibrary::GetDeviceWorldPose(class UObject* WorldContext, struct FXRDeviceId XRDeviceId, bool bIsTracked, struct FRotator Orientation, bool bHasPositionalTracking, struct FVector Position)
{
	struct {
            class UObject* WorldContext;
            struct FXRDeviceId XRDeviceId;
            bool bIsTracked;
            struct FRotator Orientation;
            bool bHasPositionalTracking;
            struct FVector Position;            void ReturnValue;
	} params{ WorldContext, XRDeviceId, bIsTracked, Orientation, bHasPositionalTracking, Position };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:GetDeviceWorldPose");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UHeadMountedDisplayFunctionLibrary::GetDevicePose(struct FXRDeviceId XRDeviceId, bool bIsTracked, struct FRotator Orientation, bool bHasPositionalTracking, struct FVector Position)
{
	struct {
            struct FXRDeviceId XRDeviceId;
            bool bIsTracked;
            struct FRotator Orientation;
            bool bHasPositionalTracking;
            struct FVector Position;            void ReturnValue;
	} params{ XRDeviceId, bIsTracked, Orientation, bHasPositionalTracking, Position };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:GetDevicePose");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static TArray<struct FXRDeviceId> UHeadMountedDisplayFunctionLibrary::EnumerateTrackedDevices(FName SystemId, EXRTrackedDeviceType DeviceType)
{
	struct {
            FName SystemId;
            EXRTrackedDeviceType DeviceType;
            TArray<struct FXRDeviceId> ReturnValue;
	} params{ SystemId, DeviceType };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:EnumerateTrackedDevices");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UHeadMountedDisplayFunctionLibrary::EnableLowPersistenceMode(bool bEnable)
{
	struct {
            bool bEnable;            void ReturnValue;
	} params{ bEnable };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:EnableLowPersistenceMode");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UHeadMountedDisplayFunctionLibrary::EnableHMD(bool bEnable)
{
	struct {
            bool bEnable;
            bool ReturnValue;
	} params{ bEnable };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:EnableHMD");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UHeadMountedDisplayFunctionLibrary::CalibrateExternalTrackingToHMD(struct FTransform ExternalTrackingTransform)
{
	struct {
            struct FTransform ExternalTrackingTransform;            void ReturnValue;
	} params{ ExternalTrackingTransform };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary:CalibrateExternalTrackingToHMD");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UMotionControllerComponent::SetTrackingSource(EControllerHand NewSource)
{
	struct {
            EControllerHand NewSource;
	} params{ NewSource };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionControllerComponent:SetTrackingSource");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMotionControllerComponent::SetTrackingMotionSource(FName NewSource)
{
	struct {
            FName NewSource;
	} params{ NewSource };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionControllerComponent:SetTrackingMotionSource");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMotionControllerComponent::SetShowDeviceModel(bool bShowControllerModel)
{
	struct {
            bool bShowControllerModel;
	} params{ bShowControllerModel };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionControllerComponent:SetShowDeviceModel");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMotionControllerComponent::SetDisplayModelSource(FName NewDisplayModelSource)
{
	struct {
            FName NewDisplayModelSource;
	} params{ NewDisplayModelSource };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionControllerComponent:SetDisplayModelSource");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMotionControllerComponent::SetCustomDisplayMesh(class UStaticMesh* NewDisplayMesh)
{
	struct {
            class UStaticMesh* NewDisplayMesh;
	} params{ NewDisplayMesh };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionControllerComponent:SetCustomDisplayMesh");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMotionControllerComponent::SetAssociatedPlayerIndex(int NewPlayer)
{
	struct {
            int NewPlayer;
	} params{ NewPlayer };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionControllerComponent:SetAssociatedPlayerIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMotionControllerComponent::OnMotionControllerUpdated()
{
    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionControllerComponent:OnMotionControllerUpdated");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


bool UMotionControllerComponent::IsTracked()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionControllerComponent:IsTracked");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


EControllerHand UMotionControllerComponent::GetTrackingSource()
{
	struct {
            EControllerHand ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionControllerComponent:GetTrackingSource");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UMotionControllerComponent::GetParameterValue(FName InName, bool bValueFound)
{
	struct {
            FName InName;
            bool bValueFound;
            float ReturnValue;
	} params{ InName, bValueFound };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionControllerComponent:GetParameterValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static void UMotionTrackedDeviceFunctionLibrary::SetIsControllerMotionTrackingEnabledByDefault(bool Enable)
{
	struct {
            bool Enable;            void ReturnValue;
	} params{ Enable };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary:SetIsControllerMotionTrackingEnabledByDefault");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UMotionTrackedDeviceFunctionLibrary::IsMotionTrackingEnabledForSource(int PlayerIndex, FName SourceName)
{
	struct {
            int PlayerIndex;
            FName SourceName;
            bool ReturnValue;
	} params{ PlayerIndex, SourceName };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary:IsMotionTrackingEnabledForSource");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UMotionTrackedDeviceFunctionLibrary::IsMotionTrackingEnabledForDevice(int PlayerIndex, EControllerHand Hand)
{
	struct {
            int PlayerIndex;
            EControllerHand Hand;
            bool ReturnValue;
	} params{ PlayerIndex, Hand };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary:IsMotionTrackingEnabledForDevice");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UMotionTrackedDeviceFunctionLibrary::IsMotionTrackingEnabledForComponent(class UMotionControllerComponent* MotionControllerComponent)
{
	struct {
            class UMotionControllerComponent* MotionControllerComponent;
            bool ReturnValue;
	} params{ MotionControllerComponent };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary:IsMotionTrackingEnabledForComponent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UMotionTrackedDeviceFunctionLibrary::IsMotionTrackedDeviceCountManagementNecessary()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary:IsMotionTrackedDeviceCountManagementNecessary");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static bool UMotionTrackedDeviceFunctionLibrary::IsMotionSourceTracking(int PlayerIndex, FName SourceName)
{
	struct {
            int PlayerIndex;
            FName SourceName;
            bool ReturnValue;
	} params{ PlayerIndex, SourceName };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary:IsMotionSourceTracking");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static int UMotionTrackedDeviceFunctionLibrary::GetMotionTrackingEnabledControllerCount()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary:GetMotionTrackingEnabledControllerCount");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static int UMotionTrackedDeviceFunctionLibrary::GetMaximumMotionTrackedControllerCount()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary:GetMaximumMotionTrackedControllerCount");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static FName UMotionTrackedDeviceFunctionLibrary::GetActiveTrackingSystemName()
{
	struct {
            FName ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary:GetActiveTrackingSystemName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static TArray<FName> UMotionTrackedDeviceFunctionLibrary::EnumerateMotionSources()
{
	struct {
            TArray<FName> ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary:EnumerateMotionSources");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static bool UMotionTrackedDeviceFunctionLibrary::EnableMotionTrackingOfSource(int PlayerIndex, FName SourceName)
{
	struct {
            int PlayerIndex;
            FName SourceName;
            bool ReturnValue;
	} params{ PlayerIndex, SourceName };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary:EnableMotionTrackingOfSource");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UMotionTrackedDeviceFunctionLibrary::EnableMotionTrackingOfDevice(int PlayerIndex, EControllerHand Hand)
{
	struct {
            int PlayerIndex;
            EControllerHand Hand;
            bool ReturnValue;
	} params{ PlayerIndex, Hand };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary:EnableMotionTrackingOfDevice");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UMotionTrackedDeviceFunctionLibrary::EnableMotionTrackingForComponent(class UMotionControllerComponent* MotionControllerComponent)
{
	struct {
            class UMotionControllerComponent* MotionControllerComponent;
            bool ReturnValue;
	} params{ MotionControllerComponent };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary:EnableMotionTrackingForComponent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UMotionTrackedDeviceFunctionLibrary::DisableMotionTrackingOfSource(int PlayerIndex, FName SourceName)
{
	struct {
            int PlayerIndex;
            FName SourceName;            void ReturnValue;
	} params{ PlayerIndex, SourceName };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary:DisableMotionTrackingOfSource");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UMotionTrackedDeviceFunctionLibrary::DisableMotionTrackingOfDevice(int PlayerIndex, EControllerHand Hand)
{
	struct {
            int PlayerIndex;
            EControllerHand Hand;            void ReturnValue;
	} params{ PlayerIndex, Hand };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary:DisableMotionTrackingOfDevice");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UMotionTrackedDeviceFunctionLibrary::DisableMotionTrackingOfControllersForPlayer(int PlayerIndex)
{
	struct {
            int PlayerIndex;            void ReturnValue;
	} params{ PlayerIndex };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary:DisableMotionTrackingOfControllersForPlayer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UMotionTrackedDeviceFunctionLibrary::DisableMotionTrackingOfAllControllers()
{
    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary:DisableMotionTrackingOfAllControllers");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static void UMotionTrackedDeviceFunctionLibrary::DisableMotionTrackingForComponent(class UMotionControllerComponent* MotionControllerComponent)
{
	struct {
            class UMotionControllerComponent* MotionControllerComponent;            void ReturnValue;
	} params{ MotionControllerComponent };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary:DisableMotionTrackingForComponent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UPrimitiveComponent* UXRAssetFunctionLibrary::AddNamedDeviceVisualizationComponentBlocking(class AActor* Target, FName SystemName, FName DeviceName, bool bManualAttachment, struct FTransform RelativeTransform, struct FXRDeviceId XRDeviceId)
{
	struct {
            class AActor* Target;
            FName SystemName;
            FName DeviceName;
            bool bManualAttachment;
            struct FTransform RelativeTransform;
            struct FXRDeviceId XRDeviceId;
            class UPrimitiveComponent* ReturnValue;
	} params{ Target, SystemName, DeviceName, bManualAttachment, RelativeTransform, XRDeviceId };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.XRAssetFunctionLibrary:AddNamedDeviceVisualizationComponentBlocking");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UPrimitiveComponent* UXRAssetFunctionLibrary::AddDeviceVisualizationComponentBlocking(class AActor* Target, struct FXRDeviceId XRDeviceId, bool bManualAttachment, struct FTransform RelativeTransform)
{
	struct {
            class AActor* Target;
            struct FXRDeviceId XRDeviceId;
            bool bManualAttachment;
            struct FTransform RelativeTransform;
            class UPrimitiveComponent* ReturnValue;
	} params{ Target, XRDeviceId, bManualAttachment, RelativeTransform };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.XRAssetFunctionLibrary:AddDeviceVisualizationComponentBlocking");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UAsyncTask_LoadXRDeviceVisComponent* UAsyncTask_LoadXRDeviceVisComponent::AddNamedDeviceVisualizationComponentAsync(class AActor* Target, FName SystemName, FName DeviceName, bool bManualAttachment, struct FTransform RelativeTransform, struct FXRDeviceId XRDeviceId, class UPrimitiveComponent* NewComponent)
{
	struct {
            class AActor* Target;
            FName SystemName;
            FName DeviceName;
            bool bManualAttachment;
            struct FTransform RelativeTransform;
            struct FXRDeviceId XRDeviceId;
            class UPrimitiveComponent* NewComponent;
            class UAsyncTask_LoadXRDeviceVisComponent* ReturnValue;
	} params{ Target, SystemName, DeviceName, bManualAttachment, RelativeTransform, XRDeviceId, NewComponent };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.AsyncTask_LoadXRDeviceVisComponent:AddNamedDeviceVisualizationComponentAsync");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UAsyncTask_LoadXRDeviceVisComponent* UAsyncTask_LoadXRDeviceVisComponent::AddDeviceVisualizationComponentAsync(class AActor* Target, struct FXRDeviceId XRDeviceId, bool bManualAttachment, struct FTransform RelativeTransform, class UPrimitiveComponent* NewComponent)
{
	struct {
            class AActor* Target;
            struct FXRDeviceId XRDeviceId;
            bool bManualAttachment;
            struct FTransform RelativeTransform;
            class UPrimitiveComponent* NewComponent;
            class UAsyncTask_LoadXRDeviceVisComponent* ReturnValue;
	} params{ Target, XRDeviceId, bManualAttachment, RelativeTransform, NewComponent };

    static auto fn = UObject::FindObject("/Script/HeadMountedDisplay.AsyncTask_LoadXRDeviceVisComponent:AddDeviceVisualizationComponentAsync");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

