#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class ELandscapeSetupErrors : uint8_t
{
    LSE_None = 0,
    LSE_NoLandscapeInfo = 1,
    LSE_CollsionXY = 2,
    LSE_NoLayerInfo = 3,
    LSE_MAX = 4
};

enum class ELandscapeGizmoType : uint8_t
{
    LGT_None = 0,
    LGT_Height = 1,
    LGT_Weight = 2,
    LGT_MAX = 3
};

enum class EGrassScaling : uint8_t
{
    Uniform = 0,
    Free = 1,
    LockXY = 2,
    EGrassScaling_MAX = 3
};

enum class ELandscapeLODFalloff : uint8_t
{
    Linear = 0,
    SquareRoot = 1,
    ELandscapeLODFalloff_MAX = 2
};

enum class ELandscapeLayerDisplayMode : uint8_t
{
    Default = 0,
    Alphabetical = 1,
    UserSpecific = 2,
    ELandscapeLayerDisplayMode_MAX = 3
};

enum class ELandscapeLayerPaintingRestriction : uint8_t
{
    None = 0,
    UseMaxLayers = 1,
    ExistingOnly = 2,
    UseComponentWhitelist = 3,
    ELandscapeLayerPaintingRestriction_MAX = 4
};

enum class ELandscapeImportAlphamapType : uint8_t
{
    Additive = 0,
    Layered = 1,
    ELandscapeImportAlphamapType_MAX = 2
};

enum class LandscapeSplineMeshOrientation : uint8_t
{
    LSMO_XUp = 0,
    LSMO_YUp = 1,
    LSMO_MAX = 2
};

enum class ELandscapeLayerBlendType : uint8_t
{
    LB_WeightBlend = 0,
    LB_AlphaBlend = 1,
    LB_HeightBlend = 2,
    LB_MAX = 3
};

enum class ELandscapeCustomizedCoordType : uint8_t
{
    LCCT_None = 0,
    LCCT_CustomUV0 = 1,
    LCCT_CustomUV1 = 2,
    LCCT_CustomUV2 = 3,
    LCCT_WeightMapUV = 4,
    LCCT_MAX = 5
};

enum class ETerrainCoordMappingType : uint8_t
{
    TCMT_Auto = 0,
    TCMT_XY = 1,
    TCMT_XZ = 2,
    TCMT_YZ = 3,
    TCMT_MAX = 4
};struct FLandscapeProceduralLayerBrush
{
	public:
	    class ALandscapeBlueprintCustomBrush* BPCustomBrush; // 0x0 Size: 0x8

};

struct FLandscapeComponentMaterialOverride
{
	public:
	    struct FPerPlatformInt LODIndex; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    class UMaterialInterface* Material; // 0x8 Size: 0x8

};

struct FWeightmapLayerAllocationInfo
{
	public:
	    class ULandscapeLayerInfoObject* LayerInfo; // 0x0 Size: 0x8
	    char WeightmapTextureIndex; // 0x8 Size: 0x1
	    char WeightmapTextureChannel; // 0x9 Size: 0x1
	    char UnknownData0[0x6];

};

struct FLandscapeEditToolRenderData
{
	public:
	    class UMaterialInterface* ToolMaterial; // 0x0 Size: 0x8
	    class UMaterialInterface* GizmoMaterial; // 0x8 Size: 0x8
	    int SelectedType; // 0x10 Size: 0x4
	    int DebugChannelR; // 0x14 Size: 0x4
	    int DebugChannelG; // 0x18 Size: 0x4
	    int DebugChannelB; // 0x1c Size: 0x4
	    class UTexture2D* DataTexture; // 0x20 Size: 0x8

};

struct FGizmoSelectData
{
	public:
	    char UnknownData0[0x50];

};

struct FGrassVariety
{
	public:
	    class UStaticMesh* GrassMesh; // 0x0 Size: 0x8
	    struct FPerPlatformFloat GrassDensity; // 0x8 Size: 0x4
	    bool bUseGrid; // 0xc Size: 0x1
	    char UnknownData0[0x3]; // 0xd
	    float PlacementJitter; // 0x10 Size: 0x4
	    struct FPerPlatformInt StartCullDistance; // 0x14 Size: 0x4
	    struct FPerPlatformInt EndCullDistance; // 0x18 Size: 0x4
	    int MinLOD; // 0x1c Size: 0x4
	    EGrassScaling Scaling; // 0x20 Size: 0x1
	    char UnknownData1[0x3]; // 0x21
	    struct FFloatInterval ScaleX; // 0x24 Size: 0x8
	    struct FFloatInterval ScaleY; // 0x2c Size: 0x8
	    struct FFloatInterval ScaleZ; // 0x34 Size: 0x8
	    bool RandomRotation; // 0x3c Size: 0x1
	    bool AlignToSurface; // 0x3d Size: 0x1
	    bool bUseLandscapeLightmap; // 0x3e Size: 0x1
	    struct FLightingChannels LightingChannels; // 0x3f Size: 0x1
	    bool bReceivesDecals; // 0x40 Size: 0x1
	    bool bCastDynamicShadow; // 0x41 Size: 0x1
	    bool bKeepInstanceBufferCPUCopy; // 0x42 Size: 0x1
	    char UnknownData2[0x5];

};

struct FLandscapeInfoLayerSettings
{
	public:
	    class ULandscapeLayerInfoObject* LayerInfoObj; // 0x0 Size: 0x8
	    FName LayerName; // 0x8 Size: 0x8

};

struct FProceduralLayerData
{
	public:
	    __int64/*MapProperty*/ Heightmaps; // 0x0 Size: 0x50

};

struct FLandscapeProxyMaterialOverride
{
	public:
	    struct FPerPlatformInt LODIndex; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    class UMaterialInterface* Material; // 0x8 Size: 0x8

};

struct FLandscapeImportLayerInfo
{
	public:
	    char UnknownData0[0x1];

};

struct FLandscapeLayerStruct
{
	public:
	    class ULandscapeLayerInfoObject* LayerInfoObj; // 0x0 Size: 0x8

};

struct FLandscapeEditorLayerSettings
{
	public:
	    char UnknownData0[0x1];

};

struct FLandscapeWeightmapUsage
{
	public:
	    class ULandscapeComponent* ChannelUsage; // 0x0 Size: 0x8
	    char UnknownData0[0x18];

};

struct FLandscapeSplineConnection
{
	public:
	    class ULandscapeSplineSegment* Segment; // 0x0 Size: 0x8
	    bool End; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FForeignWorldSplineData
{
	public:
	    char UnknownData0[0x1];

};

struct FForeignSplineSegmentData
{
	public:
	    char UnknownData0[0x1];

};

struct FForeignControlPointData
{
	public:
	    char UnknownData0[0x1];

};

struct FLandscapeSplineSegmentConnection
{
	public:
	    class ULandscapeSplineControlPoint* ControlPoint; // 0x0 Size: 0x8
	    float TangentLen; // 0x8 Size: 0x4
	    FName SocketName; // 0xc Size: 0x8
	    char UnknownData0[0x4];

};

struct FLandscapeSplineInterpPoint
{
	public:
	    struct FVector Center; // 0x0 Size: 0xc
	    struct FVector Left; // 0xc Size: 0xc
	    struct FVector Right; // 0x18 Size: 0xc
	    struct FVector FalloffLeft; // 0x24 Size: 0xc
	    struct FVector FalloffRight; // 0x30 Size: 0xc
	    float StartEndFalloff; // 0x3c Size: 0x4

};

struct FGrassInput
{
	public:
	    FName Name; // 0x0 Size: 0x8
	    class ULandscapeGrassType* GrassType; // 0x8 Size: 0x8
	    struct FExpressionInput Input; // 0x10 Size: 0xc
	    char UnknownData0[0xc];

};

struct FLayerBlendInput
{
	public:
	    FName LayerName; // 0x0 Size: 0x8
	    char BlendType; // 0x8 Size: 0x1
	    char UnknownData0[0x3]; // 0x9
	    struct FExpressionInput LayerInput; // 0xc Size: 0xc
	    char UnknownData1[0x8]; // 0x18
	    struct FExpressionInput HeightInput; // 0x20 Size: 0xc
	    char UnknownData2[0x8]; // 0x2c
	    float PreviewWeight; // 0x34 Size: 0x4
	    struct FVector ConstLayerInput; // 0x38 Size: 0xc
	    float ConstHeightInput; // 0x44 Size: 0x4

};


}