#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class EOnlineStatus : uint8_t
{
    Online = 0,
    Away = 1,
    Offline = 2,
    Blocked = 3,
    EOnlineStatus_MAX = 4
};struct FSocialChatMessageEntryTextStyle
{
	public:
	    struct FSlateFontInfo FontInfo; // 0x0 Size: 0x50
	    struct FLinearColor ColorAndOpacity; // 0x50 Size: 0x10

};

struct FSocialChatMessageEntryStyle
{
	public:
	    struct FSocialChatMessageEntryTextStyle SenderNameStyle; // 0x0 Size: 0x60
	    struct FSocialChatMessageEntryTextStyle ChannelNameStyle; // 0x60 Size: 0x60
	    struct FSocialChatMessageEntryTextStyle MessageTextStyle; // 0xc0 Size: 0x60

};


}