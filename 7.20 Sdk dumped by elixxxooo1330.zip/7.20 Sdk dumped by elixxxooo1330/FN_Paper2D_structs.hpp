#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FFlipbookFinishedPlaySignature__DelegateSignature
{
	public:

};



enum class EFlipbookCollisionMode : uint8_t
{
    NoCollision = 0,
    FirstFrameCollision = 1,
    EachFrameCollision = 2,
    EFlipbookCollisionMode_MAX = 3
};

enum class EPaperSpriteAtlasPadding : uint8_t
{
    DilateBorder = 0,
    PadWithZero = 1,
    EPaperSpriteAtlasPadding_MAX = 2
};

enum class ETileMapProjectionMode : uint8_t
{
    Orthogonal = 0,
    IsometricDiamond = 1,
    IsometricStaggered = 2,
    HexagonalStaggered = 3,
    ETileMapProjectionMode_MAX = 4
};

enum class ESpritePivotMode : uint8_t
{
    Top_Left = 0,
    Top_Center = 1,
    Top_Right = 2,
    Center_Left = 3,
    Center_Center = 4,
    Center_Right = 5,
    Bottom_Left = 6,
    Bottom_Center = 7,
    Bottom_Right = 8,
    Custom = 9,
    ESpritePivotMode_MAX = 10
};

enum class ESpritePolygonMode : uint8_t
{
    SourceBoundingBox = 0,
    TightBoundingBox = 1,
    ShrinkWrapped = 2,
    FullyCustom = 3,
    Diced = 4,
    ESpritePolygonMode_MAX = 5
};

enum class ESpriteShapeType : uint8_t
{
    Box = 0,
    Circle = 1,
    Polygon = 2,
    ESpriteShapeType_MAX = 3
};

enum class ESpriteCollisionMode : uint8_t
{
    None = 0,
    Use2DPhysics = 1,
    Use3DPhysics = 2,
    ESpriteCollisionMode_MAX = 3
};struct FIntMargin
{
	public:
	    int Left; // 0x0 Size: 0x4
	    int Top; // 0x4 Size: 0x4
	    int Right; // 0x8 Size: 0x4
	    int Bottom; // 0xc Size: 0x4

};

struct FPaperFlipbookKeyFrame
{
	public:
	    class UPaperSprite* Sprite; // 0x0 Size: 0x8
	    int FrameRun; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FSpriteInstanceData
{
	public:
	    struct FMatrix Transform; // 0x0 Size: 0x40
	    class UPaperSprite* SourceSprite; // 0x40 Size: 0x8
	    struct FColor VertexColor; // 0x48 Size: 0x4
	    int MaterialIndex; // 0x4c Size: 0x4

};

struct FPaperSpriteSocket
{
	public:
	    struct FTransform LocalTransform; // 0x0 Size: 0x30
	    FName SocketName; // 0x30 Size: 0x8
	    char UnknownData0[0x8];

};

struct FPaperSpriteAtlasSlot
{
	public:
	    struct TSoftObjectPtr<struct UPaperSprite*> SpriteRef; // 0x0 Size: 0x28
	    int AtlasIndex; // 0x28 Size: 0x4
	    int X; // 0x2c Size: 0x4
	    int Y; // 0x30 Size: 0x4
	    int Width; // 0x34 Size: 0x4
	    int Height; // 0x38 Size: 0x4
	    char UnknownData0[0x4];

};

struct FPaperTileInfo
{
	public:
	    class UPaperTileSet* TileSet; // 0x0 Size: 0x8
	    int PackedTileIndex; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FPaperTileSetTerrain
{
	public:
	    struct FString TerrainName; // 0x0 Size: 0x10
	    int CenterTileIndex; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FSpriteDrawCallRecord
{
	public:
	    struct FVector Destination; // 0x0 Size: 0xc
	    char UnknownData0[0x4]; // 0xc
	    class UTexture* BaseTexture; // 0x10 Size: 0x8
	    char UnknownData1[0x30]; // 0x18
	    struct FColor Color; // 0x48 Size: 0x4
	    char UnknownData2[0x84];

};

struct FSpriteAssetInitParameters
{
	public:
	    char UnknownData0[0x40];

};


}