#pragma once

#include "../SDK.hpp"

namespace SDK {


class UFacialLiveLinkRemapAsset : public ULiveLinkRetargetAsset
{
	public:
	    bool bExtractBoneTransform; // 0x28 Size: 0x1
	    bool bExtractCurve; // 0x29 Size: 0x1
	    char UnknownData0[0x6];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FacialAnimSystem.FacialLiveLinkRemapAsset");
			return (class UClass*)ptr;
		};

};


}