#include "../SDK.hpp"

void AMeshBeaconClient::ServerUpdateMultipleLevelsVisibility(TArray<struct FUpdateLevelVisibilityLevelInfo> LevelVisibilities)
{
	struct {
            TArray<struct FUpdateLevelVisibilityLevelInfo> LevelVisibilities;
	} params{ LevelVisibilities };

    static auto fn = UObject::FindObject("/Script/MeshNetwork.MeshBeaconClient:ServerUpdateMultipleLevelsVisibility");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void AMeshBeaconClient::ServerUpdateLevelVisibility(FName PackageName, bool bIsVisible)
{
	struct {
            FName PackageName;
            bool bIsVisible;
	} params{ PackageName, bIsVisible };

    static auto fn = UObject::FindObject("/Script/MeshNetwork.MeshBeaconClient:ServerUpdateLevelVisibility");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void AMeshBeaconClient::OnRep_ConnectedToRoot()
{
    static auto fn = UObject::FindObject("/Script/MeshNetwork.MeshBeaconClient:OnRep_ConnectedToRoot");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

EMeshNetworkNodeType UMeshNetworkComponent::GetMeshNetworkNodeType()
{
	struct {
            EMeshNetworkNodeType ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MeshNetwork.MeshNetworkComponent:GetMeshNetworkNodeType");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UMeshNetworkSubsystem::SetMetaData(struct FMeshMetaDataStruct MetaData)
{
	struct {
            struct FMeshMetaDataStruct MetaData;
	} params{ MetaData };

    static auto fn = UObject::FindObject("/Script/MeshNetwork.MeshNetworkSubsystem:SetMetaData");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMeshNetworkSubsystem::GetMetadata(struct FMeshMetaDataStruct MetaData)
{
	struct {
            struct FMeshMetaDataStruct MetaData;
	} params{ MetaData };

    static auto fn = UObject::FindObject("/Script/MeshNetwork.MeshNetworkSubsystem:GetMetadata");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


EMeshNetworkNodeType UMeshNetworkSubsystem::GetMeshNetworkNodeType()
{
	struct {
            EMeshNetworkNodeType ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MeshNetwork.MeshNetworkSubsystem:GetMeshNetworkNodeType");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


EMeshNetworkNodeType UMeshNetworkSubsystem::GetGameServerNodeType()
{
	struct {
            EMeshNetworkNodeType ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MeshNetwork.MeshNetworkSubsystem:GetGameServerNodeType");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UMeshNetworkSubsystem::GetConnectedToRoot()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MeshNetwork.MeshNetworkSubsystem:GetConnectedToRoot");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

