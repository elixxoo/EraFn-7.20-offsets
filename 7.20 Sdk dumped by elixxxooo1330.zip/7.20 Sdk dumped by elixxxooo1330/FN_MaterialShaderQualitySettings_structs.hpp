#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class EMobileCSMQuality : uint8_t
{
    NoFiltering = 0,
    PCF_1x1 = 1,
    PCF_2x2 = 2,
    EMobileCSMQuality_MAX = 3
};struct FMaterialQualityOverrides
{
	public:
	    bool bDiscardQualityDuringCook; // 0x0 Size: 0x1
	    bool bEnableOverride; // 0x1 Size: 0x1
	    bool bForceFullyRough; // 0x2 Size: 0x1
	    bool bForceNonMetal; // 0x3 Size: 0x1
	    bool bForceDisableLMDirectionality; // 0x4 Size: 0x1
	    bool bForceLQReflections; // 0x5 Size: 0x1
	    bool bDisableMaterialNormalCalculation; // 0x6 Size: 0x1
	    EMobileCSMQuality MobileCSMQuality; // 0x7 Size: 0x1

};


}