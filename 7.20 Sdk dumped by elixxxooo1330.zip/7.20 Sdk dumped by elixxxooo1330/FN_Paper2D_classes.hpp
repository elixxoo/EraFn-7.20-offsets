#pragma once

#include "../SDK.hpp"

namespace SDK {


class UMaterialExpressionSpriteTextureSampler : public UMaterialExpressionTextureSampleParameter2D
{
	public:
	    bool bSampleAdditionalTextures; // 0x100 Size: 0x1
	    char UnknownData0[0x3]; // 0x101
	    int AdditionalSlotIndex; // 0x104 Size: 0x4
	    struct FText SlotDisplayName; // 0x108 Size: 0x18

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Paper2D.MaterialExpressionSpriteTextureSampler");
			return (class UClass*)ptr;
		};

};

class APaperCharacter : public ACharacter
{
	public:
	    class UPaperFlipbookComponent* Sprite; // 0x748 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Paper2D.PaperCharacter");
			return (class UClass*)ptr;
		};

};

class UPaperFlipbook : public UObject
{
	public:
	    float FramesPerSecond; // 0x28 Size: 0x4
	    char UnknownData0[0x4]; // 0x2c
	    TArray<struct FPaperFlipbookKeyFrame> KeyFrames; // 0x30 Size: 0x10
	    class UMaterialInterface* DefaultMaterial; // 0x40 Size: 0x8
	    char CollisionSource; // 0x48 Size: 0x1
	    char UnknownData1[0x49]; // 0x49
	    bool IsValidKeyFrameIndex(int Index); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    float GetTotalDuration(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    class UPaperSprite* GetSpriteAtTime(float Time, bool bClampToEnds); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    class UPaperSprite* GetSpriteAtFrame(int FrameIndex); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    int GetNumKeyFrames(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    int GetNumFrames(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    int GetKeyFrameIndexAtTime(float Time, bool bClampToEnds); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7f91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Paper2D.PaperFlipbook");
			return (class UClass*)ptr;
		};

};

class APaperFlipbookActor : public AActor
{
	public:
	    class UPaperFlipbookComponent* RenderComponent; // 0x330 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Paper2D.PaperFlipbookActor");
			return (class UClass*)ptr;
		};

};

class UPaperFlipbookComponent : public UMeshComponent
{
	public:
	    class UPaperFlipbook* SourceFlipbook; // 0x5a0 Size: 0x8
	    class UMaterialInterface* Material; // 0x5a8 Size: 0x8
	    float PlayRate; // 0x5b0 Size: 0x4
	    bool bLooping; // 0x5b4 Size: 0x1
	    bool bReversePlayback; // 0x5b4 Size: 0x1
	    bool bPlaying; // 0x5b4 Size: 0x1
	    char UnknownData0[0x1]; // 0x5b7
	    float AccumulatedTime; // 0x5b8 Size: 0x4
	    int CachedFrameIndex; // 0x5bc Size: 0x4
	    struct FLinearColor SpriteColor; // 0x5c0 Size: 0x10
	    class UBodySetup* CachedBodySetup; // 0x5d0 Size: 0x8
	    MulticastDelegateProperty OnFinishedPlaying; // 0x5d8 Size: 0x10
	    char UnknownData1[0x5e8]; // 0x5e8
	    void Stop(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetSpriteColor(struct FLinearColor NewColor); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetPlayRate(float NewRate); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetPlaybackPositionInFrames(int NewFramePosition, bool bFireEvents); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetPlaybackPosition(float NewPosition, bool bFireEvents); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetNewTime(float NewTime); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetLooping(bool bNewLooping); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool SetFlipbook(class UPaperFlipbook* NewFlipbook); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void ReverseFromEnd(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void Reverse(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void PlayFromStart(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void Play(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void OnRep_SourceFlipbook(class UPaperFlipbook* OldFlipbook); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    bool IsReversing(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    bool IsPlaying(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    bool IsLooping(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    float GetPlayRate(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    int GetPlaybackPositionInFrames(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    float GetPlaybackPosition(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    int GetFlipbookLengthInFrames(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    float GetFlipbookLength(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    float GetFlipbookFramerate(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    class UPaperFlipbook* GetFlipbook(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x-79f1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Paper2D.PaperFlipbookComponent");
			return (class UClass*)ptr;
		};

};

class APaperGroupedSpriteActor : public AActor
{
	public:
	    class UPaperGroupedSpriteComponent* RenderComponent; // 0x330 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Paper2D.PaperGroupedSpriteActor");
			return (class UClass*)ptr;
		};

};

class UPaperGroupedSpriteComponent : public UMeshComponent
{
	public:
	    TArray<class UMaterialInterface*> InstanceMaterials; // 0x5a0 Size: 0x10
	    TArray<struct FSpriteInstanceData> PerInstanceSpriteData; // 0x5b0 Size: 0x10
	    char UnknownData0[0x5c0]; // 0x5c0
	    bool UpdateInstanceTransform(int InstanceIndex, struct FTransform NewInstanceTransform, bool bWorldSpace, bool bMarkRenderStateDirty, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool UpdateInstanceColor(int InstanceIndex, struct FLinearColor NewInstanceColor, bool bMarkRenderStateDirty); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SortInstancesAlongAxis(struct FVector WorldSpaceSortAxis); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool RemoveInstance(int InstanceIndex); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool GetInstanceTransform(int InstanceIndex, struct FTransform OutInstanceTransform, bool bWorldSpace); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    int GetInstanceCount(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ClearInstances(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    int AddInstance(struct FTransform Transform, class UPaperSprite* Sprite, bool bWorldSpace, struct FLinearColor Color); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7a11];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Paper2D.PaperGroupedSpriteComponent");
			return (class UClass*)ptr;
		};

};

class UPaperRuntimeSettings : public UObject
{
	public:
	    bool bEnableSpriteAtlasGroups; // 0x28 Size: 0x1
	    bool bEnableTerrainSplineEditing; // 0x29 Size: 0x1
	    bool bResizeSpriteDataToMatchTextures; // 0x2a Size: 0x1
	    char UnknownData0[0x5];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Paper2D.PaperRuntimeSettings");
			return (class UClass*)ptr;
		};

};

class UPaperSprite : public UObject
{
	public:
	    char UnknownData0[0x10];
	    struct FVector2D SourceUV; // 0x38 Size: 0x8
	    struct FVector2D SourceDimension; // 0x40 Size: 0x8
	    class UTexture2D* SourceTexture; // 0x48 Size: 0x8
	    TArray<class UTexture*> AdditionalSourceTextures; // 0x50 Size: 0x10
	    struct FVector2D BakedSourceUV; // 0x60 Size: 0x8
	    struct FVector2D BakedSourceDimension; // 0x68 Size: 0x8
	    class UTexture2D* BakedSourceTexture; // 0x70 Size: 0x8
	    class UMaterialInterface* DefaultMaterial; // 0x78 Size: 0x8
	    class UMaterialInterface* AlternateMaterial; // 0x80 Size: 0x8
	    TArray<struct FPaperSpriteSocket> Sockets; // 0x88 Size: 0x10
	    char SpriteCollisionDomain; // 0x98 Size: 0x1
	    char UnknownData1[0x3]; // 0x99
	    float PixelsPerUnrealUnit; // 0x9c Size: 0x4
	    class UBodySetup* BodySetup; // 0xa0 Size: 0x8
	    int AlternateMaterialSplitIndex; // 0xa8 Size: 0x4
	    char UnknownData2[0x4]; // 0xac
	    TArray<struct FVector4> BakedRenderData; // 0xb0 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Paper2D.PaperSprite");
			return (class UClass*)ptr;
		};

};

class APaperSpriteActor : public AActor
{
	public:
	    class UPaperSpriteComponent* RenderComponent; // 0x330 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Paper2D.PaperSpriteActor");
			return (class UClass*)ptr;
		};

};

class UPaperSpriteAtlas : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Paper2D.PaperSpriteAtlas");
			return (class UClass*)ptr;
		};

};

class UPaperSpriteBlueprintLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static struct FSlateBrush MakeBrushFromSprite(class UPaperSprite* Sprite, int Width, int Height); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Paper2D.PaperSpriteBlueprintLibrary");
			return (class UClass*)ptr;
		};

};

class UPaperSpriteComponent : public UMeshComponent
{
	public:
	    class UPaperSprite* SourceSprite; // 0x5a0 Size: 0x8
	    class UMaterialInterface* MaterialOverride; // 0x5a8 Size: 0x8
	    struct FLinearColor SpriteColor; // 0x5b0 Size: 0x10
	    char UnknownData0[0x5c0]; // 0x5c0
	    void SetSpriteColor(struct FLinearColor NewColor); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool SetSprite(class UPaperSprite* NewSprite); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    class UPaperSprite* GetSprite(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7a21];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Paper2D.PaperSpriteComponent");
			return (class UClass*)ptr;
		};

};

class APaperTerrainActor : public AActor
{
	public:
	    class USceneComponent* DummyRoot; // 0x330 Size: 0x8
	    class UPaperTerrainSplineComponent* SplineComponent; // 0x338 Size: 0x8
	    class UPaperTerrainComponent* RenderComponent; // 0x340 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Paper2D.PaperTerrainActor");
			return (class UClass*)ptr;
		};

};

class UPaperTerrainComponent : public UPrimitiveComponent
{
	public:
	    class UPaperTerrainMaterial* TerrainMaterial; // 0x570 Size: 0x8
	    bool bClosedSpline; // 0x578 Size: 0x1
	    bool bFilledSpline; // 0x579 Size: 0x1
	    char UnknownData0[0x6]; // 0x57a
	    class UPaperTerrainSplineComponent* AssociatedSpline; // 0x580 Size: 0x8
	    int RandomSeed; // 0x588 Size: 0x4
	    float SegmentOverlapAmount; // 0x58c Size: 0x4
	    struct FLinearColor TerrainColor; // 0x590 Size: 0x10
	    int ReparamStepsPerSegment; // 0x5a0 Size: 0x4
	    char SpriteCollisionDomain; // 0x5a4 Size: 0x1
	    char UnknownData1[0x3]; // 0x5a5
	    float CollisionThickness; // 0x5a8 Size: 0x4
	    char UnknownData2[0x4]; // 0x5ac
	    class UBodySetup* CachedBodySetup; // 0x5b0 Size: 0x8
	    char UnknownData3[0x5b8]; // 0x5b8
	    void SetTerrainColor(struct FLinearColor NewColor); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7a11];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Paper2D.PaperTerrainComponent");
			return (class UClass*)ptr;
		};

};

class UPaperTerrainMaterial : public UDataAsset
{
	public:
	    TArray<struct FPaperTerrainMaterialRule> Rules; // 0x30 Size: 0x10
	    class UPaperSprite* InteriorFill; // 0x40 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Paper2D.PaperTerrainMaterial");
			return (class UClass*)ptr;
		};

};

class UPaperTerrainSplineComponent : public USplineComponent
{
	public:
	    char UnknownData0[0x670];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Paper2D.PaperTerrainSplineComponent");
			return (class UClass*)ptr;
		};

};

class UPaperTileLayer : public UObject
{
	public:
	    struct FText LayerName; // 0x28 Size: 0x18
	    int LayerWidth; // 0x40 Size: 0x4
	    int LayerHeight; // 0x44 Size: 0x4
	    bool bHiddenInGame; // 0x48 Size: 0x1
	    bool bLayerCollides; // 0x48 Size: 0x1
	    bool bOverrideCollisionThickness; // 0x48 Size: 0x1
	    bool bOverrideCollisionOffset; // 0x48 Size: 0x1
	    float CollisionThicknessOverride; // 0x4c Size: 0x4
	    float CollisionOffsetOverride; // 0x50 Size: 0x4
	    struct FLinearColor LayerColor; // 0x54 Size: 0x10
	    int AllocatedWidth; // 0x64 Size: 0x4
	    int AllocatedHeight; // 0x68 Size: 0x4
	    char UnknownData0[0x4]; // 0x6c
	    TArray<struct FPaperTileInfo> AllocatedCells; // 0x70 Size: 0x10
	    class UPaperTileSet* TileSet; // 0x80 Size: 0x8
	    TArray<int> AllocatedGrid; // 0x88 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Paper2D.PaperTileLayer");
			return (class UClass*)ptr;
		};

};

class UPaperTileMap : public UObject
{
	public:
	    int MapWidth; // 0x28 Size: 0x4
	    int MapHeight; // 0x2c Size: 0x4
	    int TileWidth; // 0x30 Size: 0x4
	    int TileHeight; // 0x34 Size: 0x4
	    float PixelsPerUnrealUnit; // 0x38 Size: 0x4
	    float SeparationPerTileX; // 0x3c Size: 0x4
	    float SeparationPerTileY; // 0x40 Size: 0x4
	    float SeparationPerLayer; // 0x44 Size: 0x4
	    struct TSoftObjectPtr<struct UPaperTileSet*> SelectedTileSet; // 0x48 Size: 0x28
	    class UMaterialInterface* Material; // 0x70 Size: 0x8
	    TArray<class UPaperTileLayer*> TileLayers; // 0x78 Size: 0x10
	    float CollisionThickness; // 0x88 Size: 0x4
	    char SpriteCollisionDomain; // 0x8c Size: 0x1
	    char ProjectionMode; // 0x8d Size: 0x1
	    char UnknownData0[0x2]; // 0x8e
	    int HexSideLength; // 0x90 Size: 0x4
	    char UnknownData1[0x4]; // 0x94
	    class UBodySetup* BodySetup; // 0x98 Size: 0x8
	    int LayerNameIndex; // 0xa0 Size: 0x4
	    char UnknownData2[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Paper2D.PaperTileMap");
			return (class UClass*)ptr;
		};

};

class APaperTileMapActor : public AActor
{
	public:
	    class UPaperTileMapComponent* RenderComponent; // 0x330 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Paper2D.PaperTileMapActor");
			return (class UClass*)ptr;
		};

};

class UPaperTileMapComponent : public UMeshComponent
{
	public:
	    int MapWidth; // 0x5a0 Size: 0x4
	    int MapHeight; // 0x5a4 Size: 0x4
	    int TileWidth; // 0x5a8 Size: 0x4
	    int TileHeight; // 0x5ac Size: 0x4
	    class UPaperTileSet* DefaultLayerTileSet; // 0x5b0 Size: 0x8
	    class UMaterialInterface* Material; // 0x5b8 Size: 0x8
	    TArray<class UPaperTileLayer*> TileLayers; // 0x5c0 Size: 0x10
	    struct FLinearColor TileMapColor; // 0x5d0 Size: 0x10
	    int UseSingleLayerIndex; // 0x5e0 Size: 0x4
	    bool bUseSingleLayer; // 0x5e4 Size: 0x1
	    char UnknownData0[0x3]; // 0x5e5
	    class UPaperTileMap* TileMap; // 0x5e8 Size: 0x8
	    char UnknownData1[0x5f0]; // 0x5f0
	    void SetTileMapColor(struct FLinearColor NewColor); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool SetTileMap(class UPaperTileMap* NewTileMap); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetTile(int X, int Y, int Layer, struct FPaperTileInfo NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetLayerColor(struct FLinearColor NewColor, int Layer); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetLayerCollision(int Layer, bool bHasCollision, bool bOverrideThickness, float CustomThickness, bool bOverrideOffset, float CustomOffset, bool bRebuildCollision); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetDefaultCollisionThickness(float Thickness, bool bRebuildCollision); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void ResizeMap(int NewWidthInTiles, int NewHeightInTiles); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void RebuildCollision(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool OwnsTileMap(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void MakeTileMapEditable(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void GetTilePolygon(int TileX, int TileY, TArray<struct FVector> Points, int LayerIndex, bool bWorldSpace); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    struct FLinearColor GetTileMapColor(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    struct FVector GetTileCornerPosition(int TileX, int TileY, int LayerIndex, bool bWorldSpace); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    struct FVector GetTileCenterPosition(int TileX, int TileY, int LayerIndex, bool bWorldSpace); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    struct FPaperTileInfo GetTile(int X, int Y, int Layer); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void GetMapSize(int MapWidth, int MapHeight, int NumLayers); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    struct FLinearColor GetLayerColor(int Layer); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void CreateNewTileMap(int MapWidth, int MapHeight, int TileWidth, int TileHeight, float PixelsPerUnrealUnit, bool bCreateLayer); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    class UPaperTileLayer* AddNewLayer(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x-79f1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Paper2D.PaperTileMapComponent");
			return (class UClass*)ptr;
		};

};

class UPaperTileSet : public UObject
{
	public:
	    struct FIntPoint TileSize; // 0x28 Size: 0x8
	    class UTexture2D* TileSheet; // 0x30 Size: 0x8
	    TArray<class UTexture*> AdditionalSourceTextures; // 0x38 Size: 0x10
	    struct FIntMargin BorderMargin; // 0x48 Size: 0x10
	    struct FIntPoint PerTileSpacing; // 0x58 Size: 0x8
	    struct FIntPoint DrawingOffset; // 0x60 Size: 0x8
	    int WidthInTiles; // 0x68 Size: 0x4
	    int HeightInTiles; // 0x6c Size: 0x4
	    int AllocatedWidth; // 0x70 Size: 0x4
	    int AllocatedHeight; // 0x74 Size: 0x4
	    TArray<struct FPaperTileMetadata> PerTileData; // 0x78 Size: 0x10
	    TArray<struct FPaperTileSetTerrain> Terrains; // 0x88 Size: 0x10
	    int TileWidth; // 0x98 Size: 0x4
	    int TileHeight; // 0x9c Size: 0x4
	    int Margin; // 0xa0 Size: 0x4
	    int Spacing; // 0xa4 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Paper2D.PaperTileSet");
			return (class UClass*)ptr;
		};

};

class UTileMapBlueprintLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static struct FPaperTileInfo MakeTile(int TileIndex, class UPaperTileSet* TileSet, bool bFlipH, bool bFlipV, bool bFlipD); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static FName GetTileUserData(struct FPaperTileInfo Tile); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static struct FTransform GetTileTransform(struct FPaperTileInfo Tile); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static void BreakTile(struct FPaperTileInfo Tile, int TileIndex, class UPaperTileSet* TileSet, bool bFlipH, bool bFlipV, bool bFlipD); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Paper2D.TileMapBlueprintLibrary");
			return (class UClass*)ptr;
		};

};


}