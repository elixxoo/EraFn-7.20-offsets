#include "../SDK.hpp"

void UEasyAntiCheatNetComponent::ServerMessage(TArray<char> MESSAGE)
{
	struct {
            TArray<char> MESSAGE;
	} params{ MESSAGE };

    static auto fn = UObject::FindObject("/Script/EasyAntiCheatCommon.EasyAntiCheatNetComponent:ServerMessage");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UEasyAntiCheatNetComponent::ClientMessage(TArray<char> MESSAGE)
{
	struct {
            TArray<char> MESSAGE;
	} params{ MESSAGE };

    static auto fn = UObject::FindObject("/Script/EasyAntiCheatCommon.EasyAntiCheatNetComponent:ClientMessage");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

