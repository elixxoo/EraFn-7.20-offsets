#pragma once

#include "../SDK.hpp"

namespace SDK {


class UOodleTrainerCommandlet : public UCommandlet
{
	public:
	    char UnknownData0[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OodleHandlerComponent.OodleTrainerCommandlet");
			return (class UClass*)ptr;
		};

};


}