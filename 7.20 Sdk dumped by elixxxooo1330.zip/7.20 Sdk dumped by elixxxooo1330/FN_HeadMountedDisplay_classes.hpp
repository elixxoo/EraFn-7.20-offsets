#pragma once

#include "../SDK.hpp"

namespace SDK {


class UHeadMountedDisplayFunctionLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void UpdateExternalTrackingHMDPosition(struct FTransform ExternalTrackingTransform); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void SetWorldToMetersScale(class UObject* WorldContext, float NewScale); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static void SetTrackingOrigin(char Origin); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static void SetSpectatorScreenTexture(class UTexture* InTexture); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static void SetSpectatorScreenModeTexturePlusEyeLayout(struct FVector2D EyeRectMin, struct FVector2D EyeRectMax, struct FVector2D TextureRectMin, struct FVector2D TextureRectMax, bool bDrawEyeFirst, bool bClearBlack, bool bUseAlpha); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static void SetSpectatorScreenMode(ESpectatorScreenMode Mode); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static void SetClippingPlanes(float Near, float Far); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static void ResetOrientationAndPosition(float Yaw, char Options); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static bool IsSpectatorScreenModeControllable(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static bool IsInLowPersistenceMode(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static bool IsHeadMountedDisplayEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static bool IsHeadMountedDisplayConnected(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    static bool IsDeviceTracking(struct FXRDeviceId XRDeviceId); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    static bool HasValidTrackingPosition(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    static float GetWorldToMetersScale(class UObject* WorldContext); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    static void GetVRFocusState(bool bUseFocus, bool bHasFocus); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    static struct FTransform GetTrackingToWorldTransform(class UObject* WorldContext); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    static void GetTrackingSensorParameters(struct FVector Origin, struct FRotator Rotation, float LeftFOV, float RightFOV, float TopFOV, float BottomFOV, float Distance, float NearPlane, float FarPlane, bool IsActive, int Index); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    static char GetTrackingOrigin(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    static float GetScreenPercentage(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    static void GetPositionalTrackingCameraParameters(struct FVector CameraOrigin, struct FRotator CameraRotation, float HFOV, float VFOV, float CameraDistance, float NearPlane, float FarPlane); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    static float GetPixelDensity(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    static void GetOrientationAndPosition(struct FRotator DeviceRotation, struct FVector DevicePosition); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    static int GetNumOfTrackingSensors(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    static char GetHMDWornState(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    static FName GetHMDDeviceName(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    static void GetDeviceWorldPose(class UObject* WorldContext, struct FXRDeviceId XRDeviceId, bool bIsTracked, struct FRotator Orientation, bool bHasPositionalTracking, struct FVector Position); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    static void GetDevicePose(struct FXRDeviceId XRDeviceId, bool bIsTracked, struct FRotator Orientation, bool bHasPositionalTracking, struct FVector Position); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    static TArray<struct FXRDeviceId> EnumerateTrackedDevices(FName SystemId, EXRTrackedDeviceType DeviceType); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    static void EnableLowPersistenceMode(bool bEnable); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    static bool EnableHMD(bool bEnable); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    static void CalibrateExternalTrackingToHMD(struct FTransform ExternalTrackingTransform); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/HeadMountedDisplay.HeadMountedDisplayFunctionLibrary");
			return (class UClass*)ptr;
		};

};

class UMotionControllerComponent : public UPrimitiveComponent
{
	public:
	    int PlayerIndex; // 0x570 Size: 0x4
	    EControllerHand Hand; // 0x574 Size: 0x1
	    char UnknownData0[0x3]; // 0x575
	    FName MotionSource; // 0x578 Size: 0x8
	    bool bDisableLowLatencyUpdate; // 0x580 Size: 0x1
	    char UnknownData1[0x3]; // 0x581
	    ETrackingStatus CurrentTrackingStatus; // 0x584 Size: 0x1
	    bool bDisplayDeviceModel; // 0x585 Size: 0x1
	    char UnknownData2[0x2]; // 0x586
	    FName DisplayModelSource; // 0x588 Size: 0x8
	    class UStaticMesh* CustomDisplayMesh; // 0x590 Size: 0x8
	    TArray<class UMaterialInterface*> DisplayMeshMaterialOverrides; // 0x598 Size: 0x10
	    char UnknownData3[0x68]; // 0x5a8
	    class UPrimitiveComponent* DisplayComponent; // 0x610 Size: 0x8
	    char UnknownData4[0x618]; // 0x618
	    void SetTrackingSource(EControllerHand NewSource); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetTrackingMotionSource(FName NewSource); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetShowDeviceModel(bool bShowControllerModel); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetDisplayModelSource(FName NewDisplayModelSource); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetCustomDisplayMesh(class UStaticMesh* NewDisplayMesh); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetAssociatedPlayerIndex(int NewPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnMotionControllerUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    bool IsTracked(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    EControllerHand GetTrackingSource(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    float GetParameterValue(FName InName, bool bValueFound); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x-79b1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/HeadMountedDisplay.MotionControllerComponent");
			return (class UClass*)ptr;
		};

};

class UMotionTrackedDeviceFunctionLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void SetIsControllerMotionTrackingEnabledByDefault(bool Enable); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static bool IsMotionTrackingEnabledForSource(int PlayerIndex, FName SourceName); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static bool IsMotionTrackingEnabledForDevice(int PlayerIndex, EControllerHand Hand); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static bool IsMotionTrackingEnabledForComponent(class UMotionControllerComponent* MotionControllerComponent); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static bool IsMotionTrackedDeviceCountManagementNecessary(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static bool IsMotionSourceTracking(int PlayerIndex, FName SourceName); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static int GetMotionTrackingEnabledControllerCount(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static int GetMaximumMotionTrackedControllerCount(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static FName GetActiveTrackingSystemName(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static TArray<FName> EnumerateMotionSources(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static bool EnableMotionTrackingOfSource(int PlayerIndex, FName SourceName); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static bool EnableMotionTrackingOfDevice(int PlayerIndex, EControllerHand Hand); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    static bool EnableMotionTrackingForComponent(class UMotionControllerComponent* MotionControllerComponent); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    static void DisableMotionTrackingOfSource(int PlayerIndex, FName SourceName); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    static void DisableMotionTrackingOfDevice(int PlayerIndex, EControllerHand Hand); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    static void DisableMotionTrackingOfControllersForPlayer(int PlayerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    static void DisableMotionTrackingOfAllControllers(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    static void DisableMotionTrackingForComponent(class UMotionControllerComponent* MotionControllerComponent); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary");
			return (class UClass*)ptr;
		};

};

class UVRNotificationsComponent : public UActorComponent
{
	public:
	    MulticastDelegateProperty HMDTrackingInitializingAndNeedsHMDToBeTrackedDelegate; // 0xf8 Size: 0x10
	    MulticastDelegateProperty HMDTrackingInitializedDelegate; // 0x108 Size: 0x10
	    MulticastDelegateProperty HMDRecenteredDelegate; // 0x118 Size: 0x10
	    MulticastDelegateProperty HMDLostDelegate; // 0x128 Size: 0x10
	    MulticastDelegateProperty HMDReconnectedDelegate; // 0x138 Size: 0x10
	    MulticastDelegateProperty HMDConnectCanceledDelegate; // 0x148 Size: 0x10
	    MulticastDelegateProperty HMDPutOnHeadDelegate; // 0x158 Size: 0x10
	    MulticastDelegateProperty HMDRemovedFromHeadDelegate; // 0x168 Size: 0x10
	    MulticastDelegateProperty VRControllerRecenteredDelegate; // 0x178 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/HeadMountedDisplay.VRNotificationsComponent");
			return (class UClass*)ptr;
		};

};

class UXRAssetFunctionLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static class UPrimitiveComponent* AddNamedDeviceVisualizationComponentBlocking(class AActor* Target, FName SystemName, FName DeviceName, bool bManualAttachment, struct FTransform RelativeTransform, struct FXRDeviceId XRDeviceId); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static class UPrimitiveComponent* AddDeviceVisualizationComponentBlocking(class AActor* Target, struct FXRDeviceId XRDeviceId, bool bManualAttachment, struct FTransform RelativeTransform); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/HeadMountedDisplay.XRAssetFunctionLibrary");
			return (class UClass*)ptr;
		};

};

class UAsyncTask_LoadXRDeviceVisComponent : public UBlueprintAsyncActionBase
{
	public:
	    MulticastDelegateProperty OnModelLoaded; // 0x30 Size: 0x10
	    MulticastDelegateProperty OnLoadFailure; // 0x40 Size: 0x10
	    char UnknownData0[0x8]; // 0x50
	    class UPrimitiveComponent* SpawnedComponent; // 0x58 Size: 0x8
	    char UnknownData1[0x60]; // 0x60
	    static class UAsyncTask_LoadXRDeviceVisComponent* AddNamedDeviceVisualizationComponentAsync(class AActor* Target, FName SystemName, FName DeviceName, bool bManualAttachment, struct FTransform RelativeTransform, struct FXRDeviceId XRDeviceId, class UPrimitiveComponent* NewComponent); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static class UAsyncTask_LoadXRDeviceVisComponent* AddDeviceVisualizationComponentAsync(class AActor* Target, struct FXRDeviceId XRDeviceId, bool bManualAttachment, struct FTransform RelativeTransform, class UPrimitiveComponent* NewComponent); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/HeadMountedDisplay.AsyncTask_LoadXRDeviceVisComponent");
			return (class UClass*)ptr;
		};

};


}