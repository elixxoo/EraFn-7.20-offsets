#pragma once

#include "../SDK.hpp"

namespace SDK {


class UGauntletTestController : public UObject
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Gauntlet.GauntletTestController");
			return (class UClass*)ptr;
		};

};

class UGauntletTestControllerBootTest : public UGauntletTestController
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Gauntlet.GauntletTestControllerBootTest");
			return (class UClass*)ptr;
		};

};

class UGauntletTestControllerErrorTest : public UGauntletTestController
{
	public:
	    char UnknownData0[0x50];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Gauntlet.GauntletTestControllerErrorTest");
			return (class UClass*)ptr;
		};

};


}