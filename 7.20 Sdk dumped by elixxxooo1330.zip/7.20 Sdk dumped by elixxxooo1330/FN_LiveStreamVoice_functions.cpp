#include "../SDK.hpp"

void ULiveStreamVoiceSubsystem::SetVoiceSettings(struct FVoiceSettings InSettings)
{
	struct {
            struct FVoiceSettings InSettings;
	} params{ InSettings };

    static auto fn = UObject::FindObject("/Script/LiveStreamVoice.LiveStreamVoiceSubsystem:SetVoiceSettings");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ULiveStreamVoiceSubsystem::ClearVoiceSettings()
{
    static auto fn = UObject::FindObject("/Script/LiveStreamVoice.LiveStreamVoiceSubsystem:ClearVoiceSettings");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

