#pragma once

#include "../SDK.hpp"

namespace SDK {


class UCrashlyticsBlueprintLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void SetUserName(struct FString Name); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void SetUserIdentifier(struct FString ID); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static void SetUserEmail(struct FString Email); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static void SetStringKey(struct FString Key, struct FString Value); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static void SetIntegerKey(struct FString Key, int Value); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static void SetFloatKey(struct FString Key, float Value); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static void SetBooleanKey(struct FString Key, bool Value); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static void LogMessage(struct FString MESSAGE); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static void LogException(struct FString MESSAGE); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Crashlytics.CrashlyticsBlueprintLibrary");
			return (class UClass*)ptr;
		};

};


}