#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class EInAppPurchaseState : uint8_t
{
    Unknown = 0,
    Success = 1,
    Failed = 2,
    Cancelled = 3,
    Invalid = 4,
    NotAllowed = 5,
    Restored = 6,
    AlreadyOwned = 7,
    EInAppPurchaseState_MAX = 8
};

enum class EMPMatchOutcome : uint8_t
{
    None = 0,
    Quit = 1,
    Won = 2,
    Lost = 3,
    Tied = 4,
    TimeExpired = 5,
    First = 6,
    Second = 7,
    Third = 8,
    Fourth = 9,
    EMPMatchOutcome_MAX = 10
};struct FInAppPurchaseProductInfo
{
	public:
	    struct FString Identifier; // 0x0 Size: 0x10
	    struct FString TransactionIdentifier; // 0x10 Size: 0x10
	    struct FString DisplayName; // 0x20 Size: 0x10
	    struct FString DisplayDescription; // 0x30 Size: 0x10
	    struct FString DisplayPrice; // 0x40 Size: 0x10
	    float RawPrice; // 0x50 Size: 0x4
	    char UnknownData0[0x4]; // 0x54
	    struct FString CurrencyCode; // 0x58 Size: 0x10
	    struct FString CurrencySymbol; // 0x68 Size: 0x10
	    struct FString DecimalSeparator; // 0x78 Size: 0x10
	    struct FString GroupingSeparator; // 0x88 Size: 0x10
	    struct FString ReceiptData; // 0x98 Size: 0x10

};

struct FInAppPurchaseRestoreInfo
{
	public:
	    struct FString Identifier; // 0x0 Size: 0x10
	    struct FString ReceiptData; // 0x10 Size: 0x10
	    struct FString TransactionIdentifier; // 0x20 Size: 0x10

};

struct FNamedInterfaceDef
{
	public:
	    FName InterfaceName; // 0x0 Size: 0x8
	    struct FString InterfaceClassName; // 0x8 Size: 0x10

};

struct FNamedInterface
{
	public:
	    FName InterfaceName; // 0x0 Size: 0x8
	    class UObject* InterfaceObject; // 0x8 Size: 0x8

};

struct FInAppPurchaseProductRequest
{
	public:
	    struct FString ProductIdentifier; // 0x0 Size: 0x10
	    bool bIsConsumable; // 0x10 Size: 0x1
	    char UnknownData0[0x7];

};


}