#include "../SDK.hpp"

void AReplicationGraphDebugActor::ServerStopDebugging()
{
    static auto fn = UObject::FindObject("/Script/ReplicationGraph.ReplicationGraphDebugActor:ServerStopDebugging");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void AReplicationGraphDebugActor::ServerStartDebugging()
{
    static auto fn = UObject::FindObject("/Script/ReplicationGraph.ReplicationGraphDebugActor:ServerStartDebugging");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void AReplicationGraphDebugActor::ServerSetPeriodFrameForClass(class UObject* Class, int PeriodFrame)
{
	struct {
            class UObject* Class;
            int PeriodFrame;
	} params{ Class, PeriodFrame };

    static auto fn = UObject::FindObject("/Script/ReplicationGraph.ReplicationGraphDebugActor:ServerSetPeriodFrameForClass");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void AReplicationGraphDebugActor::ServerSetCullDistanceForClass(class UObject* Class, float CullDistance)
{
	struct {
            class UObject* Class;
            float CullDistance;
	} params{ Class, CullDistance };

    static auto fn = UObject::FindObject("/Script/ReplicationGraph.ReplicationGraphDebugActor:ServerSetCullDistanceForClass");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void AReplicationGraphDebugActor::ServerSetConditionalActorBreakpoint(class AActor* Actor)
{
	struct {
            class AActor* Actor;
	} params{ Actor };

    static auto fn = UObject::FindObject("/Script/ReplicationGraph.ReplicationGraphDebugActor:ServerSetConditionalActorBreakpoint");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void AReplicationGraphDebugActor::ServerPrintAllActorInfo(struct FString Str)
{
	struct {
            struct FString Str;
	} params{ Str };

    static auto fn = UObject::FindObject("/Script/ReplicationGraph.ReplicationGraphDebugActor:ServerPrintAllActorInfo");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void AReplicationGraphDebugActor::ServerCellInfo()
{
    static auto fn = UObject::FindObject("/Script/ReplicationGraph.ReplicationGraphDebugActor:ServerCellInfo");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void AReplicationGraphDebugActor::ClientCellInfo(struct FVector CellLocation, struct FVector CellExtent, TArray<class AActor*> Actors)
{
	struct {
            struct FVector CellLocation;
            struct FVector CellExtent;
            TArray<class AActor*> Actors;
	} params{ CellLocation, CellExtent, Actors };

    static auto fn = UObject::FindObject("/Script/ReplicationGraph.ReplicationGraphDebugActor:ClientCellInfo");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

