#include "../SDK.hpp"

static struct FFrameTime UTimeManagementBlueprintLibrary::TransformTime(struct FFrameTime SourceTime, struct FFrameRate SourceRate, struct FFrameRate DestinationRate)
{
	struct {
            struct FFrameTime SourceTime;
            struct FFrameRate SourceRate;
            struct FFrameRate DestinationRate;
            struct FFrameTime ReturnValue;
	} params{ SourceTime, SourceRate, DestinationRate };

    static auto fn = UObject::FindObject("/Script/TimeManagement.TimeManagementBlueprintLibrary:TransformTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FFrameNumber UTimeManagementBlueprintLibrary::Subtract_FrameNumberInteger(struct FFrameNumber A, int B)
{
	struct {
            struct FFrameNumber A;
            int B;
            struct FFrameNumber ReturnValue;
	} params{ A, B };

    static auto fn = UObject::FindObject("/Script/TimeManagement.TimeManagementBlueprintLibrary:Subtract_FrameNumberInteger");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FFrameNumber UTimeManagementBlueprintLibrary::Subtract_FrameNumberFrameNumber(struct FFrameNumber A, struct FFrameNumber B)
{
	struct {
            struct FFrameNumber A;
            struct FFrameNumber B;
            struct FFrameNumber ReturnValue;
	} params{ A, B };

    static auto fn = UObject::FindObject("/Script/TimeManagement.TimeManagementBlueprintLibrary:Subtract_FrameNumberFrameNumber");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FFrameTime UTimeManagementBlueprintLibrary::SnapFrameTimeToRate(struct FFrameTime SourceTime, struct FFrameRate SourceRate, struct FFrameRate SnapToRate)
{
	struct {
            struct FFrameTime SourceTime;
            struct FFrameRate SourceRate;
            struct FFrameRate SnapToRate;
            struct FFrameTime ReturnValue;
	} params{ SourceTime, SourceRate, SnapToRate };

    static auto fn = UObject::FindObject("/Script/TimeManagement.TimeManagementBlueprintLibrary:SnapFrameTimeToRate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FFrameTime UTimeManagementBlueprintLibrary::Multiply_SecondsFrameRate(float TimeInSeconds, struct FFrameRate FrameRate)
{
	struct {
            float TimeInSeconds;
            struct FFrameRate FrameRate;
            struct FFrameTime ReturnValue;
	} params{ TimeInSeconds, FrameRate };

    static auto fn = UObject::FindObject("/Script/TimeManagement.TimeManagementBlueprintLibrary:Multiply_SecondsFrameRate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FFrameNumber UTimeManagementBlueprintLibrary::Multiply_FrameNumberInteger(struct FFrameNumber A, int B)
{
	struct {
            struct FFrameNumber A;
            int B;
            struct FFrameNumber ReturnValue;
	} params{ A, B };

    static auto fn = UObject::FindObject("/Script/TimeManagement.TimeManagementBlueprintLibrary:Multiply_FrameNumberInteger");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UTimeManagementBlueprintLibrary::IsValid_MultipleOf(struct FFrameRate InFrameRate, struct FFrameRate OtherFramerate)
{
	struct {
            struct FFrameRate InFrameRate;
            struct FFrameRate OtherFramerate;
            bool ReturnValue;
	} params{ InFrameRate, OtherFramerate };

    static auto fn = UObject::FindObject("/Script/TimeManagement.TimeManagementBlueprintLibrary:IsValid_MultipleOf");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UTimeManagementBlueprintLibrary::IsValid_Framerate(struct FFrameRate InFrameRate)
{
	struct {
            struct FFrameRate InFrameRate;
            bool ReturnValue;
	} params{ InFrameRate };

    static auto fn = UObject::FindObject("/Script/TimeManagement.TimeManagementBlueprintLibrary:IsValid_Framerate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FTimecode UTimeManagementBlueprintLibrary::GetTimecode()
{
	struct {
            struct FTimecode ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/TimeManagement.TimeManagementBlueprintLibrary:GetTimecode");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static struct FFrameNumber UTimeManagementBlueprintLibrary::Divide_FrameNumberInteger(struct FFrameNumber A, int B)
{
	struct {
            struct FFrameNumber A;
            int B;
            struct FFrameNumber ReturnValue;
	} params{ A, B };

    static auto fn = UObject::FindObject("/Script/TimeManagement.TimeManagementBlueprintLibrary:Divide_FrameNumberInteger");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FString UTimeManagementBlueprintLibrary::Conv_TimecodeToString(struct FTimecode InTimecode, bool bForceSignDisplay)
{
	struct {
            struct FTimecode InTimecode;
            bool bForceSignDisplay;
            struct FString ReturnValue;
	} params{ InTimecode, bForceSignDisplay };

    static auto fn = UObject::FindObject("/Script/TimeManagement.TimeManagementBlueprintLibrary:Conv_TimecodeToString");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static float UTimeManagementBlueprintLibrary::Conv_QualifiedFrameTimeToSeconds(struct FQualifiedFrameTime InFrameTime)
{
	struct {
            struct FQualifiedFrameTime InFrameTime;
            float ReturnValue;
	} params{ InFrameTime };

    static auto fn = UObject::FindObject("/Script/TimeManagement.TimeManagementBlueprintLibrary:Conv_QualifiedFrameTimeToSeconds");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static float UTimeManagementBlueprintLibrary::Conv_FrameRateToSeconds(struct FFrameRate InFrameRate)
{
	struct {
            struct FFrameRate InFrameRate;
            float ReturnValue;
	} params{ InFrameRate };

    static auto fn = UObject::FindObject("/Script/TimeManagement.TimeManagementBlueprintLibrary:Conv_FrameRateToSeconds");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static int UTimeManagementBlueprintLibrary::Conv_FrameNumberToInteger(struct FFrameNumber InFrameNumber)
{
	struct {
            struct FFrameNumber InFrameNumber;
            int ReturnValue;
	} params{ InFrameNumber };

    static auto fn = UObject::FindObject("/Script/TimeManagement.TimeManagementBlueprintLibrary:Conv_FrameNumberToInteger");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FFrameNumber UTimeManagementBlueprintLibrary::Add_FrameNumberInteger(struct FFrameNumber A, int B)
{
	struct {
            struct FFrameNumber A;
            int B;
            struct FFrameNumber ReturnValue;
	} params{ A, B };

    static auto fn = UObject::FindObject("/Script/TimeManagement.TimeManagementBlueprintLibrary:Add_FrameNumberInteger");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FFrameNumber UTimeManagementBlueprintLibrary::Add_FrameNumberFrameNumber(struct FFrameNumber A, struct FFrameNumber B)
{
	struct {
            struct FFrameNumber A;
            struct FFrameNumber B;
            struct FFrameNumber ReturnValue;
	} params{ A, B };

    static auto fn = UObject::FindObject("/Script/TimeManagement.TimeManagementBlueprintLibrary:Add_FrameNumberFrameNumber");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

