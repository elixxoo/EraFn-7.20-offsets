#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FOnSynthEnvelopeValue__DelegateSignature
{
	public:
	    float EnvelopeValue; // 0x0 Size: 0x4

};



enum class ESubmixEffectDynamicsPeakMode : uint8_t
{
    MeanSquared = 0,
    RootMeanSquared = 1,
    Peak = 2,
    Count = 3,
    ESubmixEffectDynamicsPeakMode_MAX = 4
};

enum class ESubmixEffectDynamicsProcessorType : uint8_t
{
    Compressor = 0,
    Limiter = 1,
    Expander = 2,
    Gate = 3,
    Count = 4,
    ESubmixEffectDynamicsProcessorType_MAX = 5
};struct FSubmixEffectDynamicsProcessorSettings
{
	public:
	    ESubmixEffectDynamicsProcessorType DynamicsProcessorType; // 0x0 Size: 0x1
	    ESubmixEffectDynamicsPeakMode PeakMode; // 0x1 Size: 0x1
	    char UnknownData0[0x2]; // 0x2
	    float LookAheadMsec; // 0x4 Size: 0x4
	    float AttackTimeMsec; // 0x8 Size: 0x4
	    float ReleaseTimeMsec; // 0xc Size: 0x4
	    float ThresholdDb; // 0x10 Size: 0x4
	    float Ratio; // 0x14 Size: 0x4
	    float KneeBandwidthDb; // 0x18 Size: 0x4
	    float InputGainDb; // 0x1c Size: 0x4
	    float OutputGainDb; // 0x20 Size: 0x4
	    bool bChannelLinked; // 0x24 Size: 0x1
	    bool bAnalogMode; // 0x24 Size: 0x1
	    char UnknownData1[0x2];

};

struct FSubmixEffectEQBand
{
	public:
	    float Frequency; // 0x0 Size: 0x4
	    float Bandwidth; // 0x4 Size: 0x4
	    float GainDb; // 0x8 Size: 0x4
	    bool bEnabled; // 0xc Size: 0x1
	    char UnknownData0[0x3];

};

struct FSubmixEffectReverbSettings
{
	public:
	    float Density; // 0x0 Size: 0x4
	    float Diffusion; // 0x4 Size: 0x4
	    float Gain; // 0x8 Size: 0x4
	    float GainHF; // 0xc Size: 0x4
	    float DecayTime; // 0x10 Size: 0x4
	    float DecayHFRatio; // 0x14 Size: 0x4
	    float ReflectionsGain; // 0x18 Size: 0x4
	    float ReflectionsDelay; // 0x1c Size: 0x4
	    float LateGain; // 0x20 Size: 0x4
	    float LateDelay; // 0x24 Size: 0x4
	    float AirAbsorptionGainHF; // 0x28 Size: 0x4
	    float WetLevel; // 0x2c Size: 0x4
	    float DryLevel; // 0x30 Size: 0x4

};


}