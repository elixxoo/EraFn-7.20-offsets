#pragma once

#include "../SDK.hpp"

namespace SDK {


class ULiveLinkBlueprintLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void TransformNames(struct FSubjectFrameHandle SubjectFrameHandle, TArray<FName> TransformNames); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void TransformName(struct FLiveLinkTransform LiveLinkTransform, FName Name); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static bool RequestShutdown(struct FLiveLinkSourceHandle SourceHandle); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static void ParentBoneSpaceTransform(struct FLiveLinkTransform LiveLinkTransform, struct FTransform Transform); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static int NumberOfTransforms(struct FSubjectFrameHandle SubjectFrameHandle); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static bool IsSourceStillValid(struct FLiveLinkSourceHandle SourceHandle); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static bool HasParent(struct FLiveLinkTransform LiveLinkTransform); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static void GetTransformByName(struct FSubjectFrameHandle SubjectFrameHandle, FName TransformName, struct FLiveLinkTransform LiveLinkTransform); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static void GetTransformByIndex(struct FSubjectFrameHandle SubjectFrameHandle, int TransformIndex, struct FLiveLinkTransform LiveLinkTransform); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static struct FText GetSourceType(struct FLiveLinkSourceHandle SourceHandle); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static struct FText GetSourceStatus(struct FLiveLinkSourceHandle SourceHandle); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static struct FText GetSourceMachineName(struct FLiveLinkSourceHandle SourceHandle); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    static void GetRootTransform(struct FSubjectFrameHandle SubjectFrameHandle, struct FLiveLinkTransform LiveLinkTransform); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    static void GetParent(struct FLiveLinkTransform LiveLinkTransform, struct FLiveLinkTransform Parent); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    static void GetMetadata(struct FSubjectFrameHandle SubjectFrameHandle, struct FSubjectMetadata MetaData); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    static void GetCurves(struct FSubjectFrameHandle SubjectFrameHandle, __int64/*MapProperty*/ Curves); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    static void GetChildren(struct FLiveLinkTransform LiveLinkTransform, TArray<struct FLiveLinkTransform> Children); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    static void ComponentSpaceTransform(struct FLiveLinkTransform LiveLinkTransform, struct FTransform Transform); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    static int ChildCount(struct FLiveLinkTransform LiveLinkTransform); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/LiveLink.LiveLinkBlueprintLibrary");
			return (class UClass*)ptr;
		};

};

class ULiveLinkComponent : public UActorComponent
{
	public:
	    MulticastDelegateProperty OnLiveLinkUpdated; // 0xf8 Size: 0x10
	    char UnknownData0[0x108]; // 0x108
	    void GetSubjectDataAtWorldTime(FName SubjectName, float WorldTime, bool bSuccess, struct FSubjectFrameHandle SubjectFrameHandle); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void GetSubjectDataAtSceneTime(FName SubjectName, struct FTimecode SceneTime, bool bSuccess, struct FSubjectFrameHandle SubjectFrameHandle); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void GetSubjectData(FName SubjectName, bool bSuccess, struct FSubjectFrameHandle SubjectFrameHandle); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void GetAvailableSubjectNames(TArray<FName> SubjectNames); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7ec9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/LiveLink.LiveLinkComponent");
			return (class UClass*)ptr;
		};

};

class ULiveLinkDrivenComponent : public UActorComponent
{
	public:
	    struct FLiveLinkSubjectName SubjectName; // 0xf8 Size: 0x8
	    FName ActorTransformBone; // 0x100 Size: 0x8
	    bool bModifyActorTransform; // 0x108 Size: 0x1
	    bool bSetRelativeLocation; // 0x109 Size: 0x1
	    char UnknownData0[0xe];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/LiveLink.LiveLinkDrivenComponent");
			return (class UClass*)ptr;
		};

};

class ULiveLinkInstance : public UAnimInstance
{
	public:
	    class ULiveLinkRetargetAsset* CurrentRetargetAsset; // 0x268 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/LiveLink.LiveLinkInstance");
			return (class UClass*)ptr;
		};

};

class ULiveLinkMessageBusFinder : public UObject
{
	public:
	    void GetAvailableProviders(class UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, float Duration, TArray<struct FProviderPollResult> AvailableProviders); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static class ULiveLinkMessageBusFinder* ConstructMessageBusFinder(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static void ConnectToProvider(struct FProviderPollResult Provider, struct FLiveLinkSourceHandle SourceHandle); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/LiveLink.LiveLinkMessageBusFinder");
			return (class UClass*)ptr;
		};

};

class ULiveLinkRetargetAsset : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/LiveLink.LiveLinkRetargetAsset");
			return (class UClass*)ptr;
		};

};

class ULiveLinkRemapAsset : public ULiveLinkRetargetAsset
{
	public:
	    void RemapCurveElements(__int64/*MapProperty*/ CurveItems); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    FName GetRemappedCurveName(FName CurveName); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    FName GetRemappedBoneName(FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f11];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/LiveLink.LiveLinkRemapAsset");
			return (class UClass*)ptr;
		};

};

class ULiveLinkTimeSynchronizationSource : public UTimeSynchronizationSource
{
	public:
	    FName SubjectName; // 0x30 Size: 0x8
	    char UnknownData0[0x58];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/LiveLink.LiveLinkTimeSynchronizationSource");
			return (class UClass*)ptr;
		};

};

class UMovieSceneLiveLinkSection : public UMovieSceneSection
{
	public:
	    FName SubjectName; // 0xe0 Size: 0x8
	    struct FLiveLinkFrameData TemplateToPush; // 0xe8 Size: 0x90
	    struct FLiveLinkRefSkeleton RefSkeleton; // 0x178 Size: 0x20
	    TArray<struct FMovieSceneFloatChannel> PropertyFloatChannels; // 0x198 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/LiveLink.MovieSceneLiveLinkSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneLiveLinkTrack : public UMovieScenePropertyTrack
{
	public:
	    char UnknownData0[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/LiveLink.MovieSceneLiveLinkTrack");
			return (class UClass*)ptr;
		};

};


}