#include "../SDK.hpp"

void UPurchaseFlowJSBridge::RequestClose(struct FString CloseInfo)
{
	struct {
            struct FString CloseInfo;
	} params{ CloseInfo };

    static auto fn = UObject::FindObject("/Script/PurchaseFlow.PurchaseFlowJSBridge:RequestClose");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UPurchaseFlowJSBridge::RECEIPT(struct FPurchaseFlowReceiptParam RECEIPT)
{
	struct {
            struct FPurchaseFlowReceiptParam RECEIPT;
	} params{ RECEIPT };

    static auto fn = UObject::FindObject("/Script/PurchaseFlow.PurchaseFlowJSBridge:RECEIPT");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UPurchaseFlowJSBridge::LaunchValidatedExternalBrowserUrl(struct FString AllowedBrowserID, struct FString URL)
{
	struct {
            struct FString AllowedBrowserID;
            struct FString URL;
            bool ReturnValue;
	} params{ AllowedBrowserID, URL };

    static auto fn = UObject::FindObject("/Script/PurchaseFlow.PurchaseFlowJSBridge:LaunchValidatedExternalBrowserUrl");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UPurchaseFlowJSBridge::LaunchExternalBrowserUrl(struct FString URL)
{
	struct {
            struct FString URL;
            bool ReturnValue;
	} params{ URL };

    static auto fn = UObject::FindObject("/Script/PurchaseFlow.PurchaseFlowJSBridge:LaunchExternalBrowserUrl");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FString UPurchaseFlowJSBridge::GetExternalBrowserPath(struct FString BrowserId)
{
	struct {
            struct FString BrowserId;
            struct FString ReturnValue;
	} params{ BrowserId };

    static auto fn = UObject::FindObject("/Script/PurchaseFlow.PurchaseFlowJSBridge:GetExternalBrowserPath");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FString UPurchaseFlowJSBridge::GetExternalBrowserName(struct FString BrowserId)
{
	struct {
            struct FString BrowserId;
            struct FString ReturnValue;
	} params{ BrowserId };

    static auto fn = UObject::FindObject("/Script/PurchaseFlow.PurchaseFlowJSBridge:GetExternalBrowserName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FString UPurchaseFlowJSBridge::GetDefaultExternalBrowserID(struct FString URL)
{
	struct {
            struct FString URL;
            struct FString ReturnValue;
	} params{ URL };

    static auto fn = UObject::FindObject("/Script/PurchaseFlow.PurchaseFlowJSBridge:GetDefaultExternalBrowserID");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

