#include "../SDK.hpp"

static void UCrashlyticsBlueprintLibrary::SetUserName(struct FString Name)
{
	struct {
            struct FString Name;            void ReturnValue;
	} params{ Name };

    static auto fn = UObject::FindObject("/Script/Crashlytics.CrashlyticsBlueprintLibrary:SetUserName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UCrashlyticsBlueprintLibrary::SetUserIdentifier(struct FString ID)
{
	struct {
            struct FString ID;            void ReturnValue;
	} params{ ID };

    static auto fn = UObject::FindObject("/Script/Crashlytics.CrashlyticsBlueprintLibrary:SetUserIdentifier");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UCrashlyticsBlueprintLibrary::SetUserEmail(struct FString Email)
{
	struct {
            struct FString Email;            void ReturnValue;
	} params{ Email };

    static auto fn = UObject::FindObject("/Script/Crashlytics.CrashlyticsBlueprintLibrary:SetUserEmail");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UCrashlyticsBlueprintLibrary::SetStringKey(struct FString Key, struct FString Value)
{
	struct {
            struct FString Key;
            struct FString Value;            void ReturnValue;
	} params{ Key, Value };

    static auto fn = UObject::FindObject("/Script/Crashlytics.CrashlyticsBlueprintLibrary:SetStringKey");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UCrashlyticsBlueprintLibrary::SetIntegerKey(struct FString Key, int Value)
{
	struct {
            struct FString Key;
            int Value;            void ReturnValue;
	} params{ Key, Value };

    static auto fn = UObject::FindObject("/Script/Crashlytics.CrashlyticsBlueprintLibrary:SetIntegerKey");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UCrashlyticsBlueprintLibrary::SetFloatKey(struct FString Key, float Value)
{
	struct {
            struct FString Key;
            float Value;            void ReturnValue;
	} params{ Key, Value };

    static auto fn = UObject::FindObject("/Script/Crashlytics.CrashlyticsBlueprintLibrary:SetFloatKey");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UCrashlyticsBlueprintLibrary::SetBooleanKey(struct FString Key, bool Value)
{
	struct {
            struct FString Key;
            bool Value;            void ReturnValue;
	} params{ Key, Value };

    static auto fn = UObject::FindObject("/Script/Crashlytics.CrashlyticsBlueprintLibrary:SetBooleanKey");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UCrashlyticsBlueprintLibrary::LogMessage(struct FString MESSAGE)
{
	struct {
            struct FString MESSAGE;            void ReturnValue;
	} params{ MESSAGE };

    static auto fn = UObject::FindObject("/Script/Crashlytics.CrashlyticsBlueprintLibrary:LogMessage");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UCrashlyticsBlueprintLibrary::LogException(struct FString MESSAGE)
{
	struct {
            struct FString MESSAGE;            void ReturnValue;
	} params{ MESSAGE };

    static auto fn = UObject::FindObject("/Script/Crashlytics.CrashlyticsBlueprintLibrary:LogException");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

