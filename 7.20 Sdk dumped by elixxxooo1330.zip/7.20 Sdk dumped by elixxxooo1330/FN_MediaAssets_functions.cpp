#include "../SDK.hpp"

bool UMediaSource::Validate()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaSource:Validate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FString UMediaSource::GetUrl()
{
	struct {
            struct FString ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaSource:GetUrl");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UFileMediaSource::SetFilePath(struct FString Path)
{
	struct {
            struct FString Path;
	} params{ Path };

    static auto fn = UObject::FindObject("/Script/MediaAssets.FileMediaSource:SetFilePath");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

static void UMediaBlueprintFunctionLibrary::EnumerateWebcamCaptureDevices(TArray<struct FMediaCaptureDevice> OutDevices, int Filter)
{
	struct {
            TArray<struct FMediaCaptureDevice> OutDevices;
            int Filter;            void ReturnValue;
	} params{ OutDevices, Filter };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaBlueprintFunctionLibrary:EnumerateWebcamCaptureDevices");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UMediaBlueprintFunctionLibrary::EnumerateVideoCaptureDevices(TArray<struct FMediaCaptureDevice> OutDevices, int Filter)
{
	struct {
            TArray<struct FMediaCaptureDevice> OutDevices;
            int Filter;            void ReturnValue;
	} params{ OutDevices, Filter };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaBlueprintFunctionLibrary:EnumerateVideoCaptureDevices");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UMediaBlueprintFunctionLibrary::EnumerateAudioCaptureDevices(TArray<struct FMediaCaptureDevice> OutDevices, int Filter)
{
	struct {
            TArray<struct FMediaCaptureDevice> OutDevices;
            int Filter;            void ReturnValue;
	} params{ OutDevices, Filter };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaBlueprintFunctionLibrary:EnumerateAudioCaptureDevices");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

bool UMediaPlayer::SupportsSeeking()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:SupportsSeeking");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UMediaPlayer::SupportsScrubbing()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:SupportsScrubbing");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UMediaPlayer::SupportsRate(float Rate, bool Unthinned)
{
	struct {
            float Rate;
            bool Unthinned;
            bool ReturnValue;
	} params{ Rate, Unthinned };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:SupportsRate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UMediaPlayer::SetViewRotation(struct FRotator Rotation, bool Absolute)
{
	struct {
            struct FRotator Rotation;
            bool Absolute;
            bool ReturnValue;
	} params{ Rotation, Absolute };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:SetViewRotation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UMediaPlayer::SetViewField(float Horizontal, float Vertical, bool Absolute)
{
	struct {
            float Horizontal;
            float Vertical;
            bool Absolute;
            bool ReturnValue;
	} params{ Horizontal, Vertical, Absolute };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:SetViewField");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UMediaPlayer::SetVideoTrackFrameRate(int TrackIndex, int FormatIndex, float FrameRate)
{
	struct {
            int TrackIndex;
            int FormatIndex;
            float FrameRate;
            bool ReturnValue;
	} params{ TrackIndex, FormatIndex, FrameRate };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:SetVideoTrackFrameRate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UMediaPlayer::SetTrackFormat(EMediaPlayerTrack TrackType, int TrackIndex, int FormatIndex)
{
	struct {
            EMediaPlayerTrack TrackType;
            int TrackIndex;
            int FormatIndex;
            bool ReturnValue;
	} params{ TrackType, TrackIndex, FormatIndex };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:SetTrackFormat");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UMediaPlayer::SetTimeDelay(struct FTimespan TimeDelay)
{
	struct {
            struct FTimespan TimeDelay;
	} params{ TimeDelay };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:SetTimeDelay");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UMediaPlayer::SetRate(float Rate)
{
	struct {
            float Rate;
            bool ReturnValue;
	} params{ Rate };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:SetRate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UMediaPlayer::SetNativeVolume(float Volume)
{
	struct {
            float Volume;
            bool ReturnValue;
	} params{ Volume };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:SetNativeVolume");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UMediaPlayer::SetLooping(bool Looping)
{
	struct {
            bool Looping;
            bool ReturnValue;
	} params{ Looping };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:SetLooping");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UMediaPlayer::SetDesiredPlayerName(FName PlayerName)
{
	struct {
            FName PlayerName;
	} params{ PlayerName };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:SetDesiredPlayerName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMediaPlayer::SetBlockOnTime(struct FTimespan Time)
{
	struct {
            struct FTimespan Time;
	} params{ Time };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:SetBlockOnTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UMediaPlayer::SelectTrack(EMediaPlayerTrack TrackType, int TrackIndex)
{
	struct {
            EMediaPlayerTrack TrackType;
            int TrackIndex;
            bool ReturnValue;
	} params{ TrackType, TrackIndex };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:SelectTrack");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UMediaPlayer::Seek(struct FTimespan Time)
{
	struct {
            struct FTimespan Time;
            bool ReturnValue;
	} params{ Time };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:Seek");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UMediaPlayer::Rewind()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:Rewind");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UMediaPlayer::Reopen()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:Reopen");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UMediaPlayer::Previous()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:Previous");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UMediaPlayer::Play()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:Play");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UMediaPlayer::Pause()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:Pause");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UMediaPlayer::OpenUrl(struct FString URL)
{
	struct {
            struct FString URL;
            bool ReturnValue;
	} params{ URL };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:OpenUrl");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UMediaPlayer::OpenSourceWithOptions(class UMediaSource* MediaSource, struct FMediaPlayerOptions Options)
{
	struct {
            class UMediaSource* MediaSource;
            struct FMediaPlayerOptions Options;
            bool ReturnValue;
	} params{ MediaSource, Options };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:OpenSourceWithOptions");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UMediaPlayer::OpenSource(class UMediaSource* MediaSource)
{
	struct {
            class UMediaSource* MediaSource;
            bool ReturnValue;
	} params{ MediaSource };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:OpenSource");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UMediaPlayer::OpenPlaylistIndex(class UMediaPlaylist* InPlaylist, int Index)
{
	struct {
            class UMediaPlaylist* InPlaylist;
            int Index;
            bool ReturnValue;
	} params{ InPlaylist, Index };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:OpenPlaylistIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UMediaPlayer::OpenPlaylist(class UMediaPlaylist* InPlaylist)
{
	struct {
            class UMediaPlaylist* InPlaylist;
            bool ReturnValue;
	} params{ InPlaylist };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:OpenPlaylist");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UMediaPlayer::OpenFile(struct FString FilePath)
{
	struct {
            struct FString FilePath;
            bool ReturnValue;
	} params{ FilePath };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:OpenFile");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UMediaPlayer::Next()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:Next");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UMediaPlayer::IsReady()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:IsReady");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UMediaPlayer::IsPreparing()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:IsPreparing");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UMediaPlayer::IsPlaying()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:IsPlaying");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UMediaPlayer::IsPaused()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:IsPaused");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UMediaPlayer::IsLooping()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:IsLooping");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UMediaPlayer::IsConnecting()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:IsConnecting");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UMediaPlayer::IsBuffering()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:IsBuffering");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UMediaPlayer::HasError()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:HasError");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FRotator UMediaPlayer::GetViewRotation()
{
	struct {
            struct FRotator ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetViewRotation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FString UMediaPlayer::GetVideoTrackType(int TrackIndex, int FormatIndex)
{
	struct {
            int TrackIndex;
            int FormatIndex;
            struct FString ReturnValue;
	} params{ TrackIndex, FormatIndex };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetVideoTrackType");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FFloatRange UMediaPlayer::GetVideoTrackFrameRates(int TrackIndex, int FormatIndex)
{
	struct {
            int TrackIndex;
            int FormatIndex;
            struct FFloatRange ReturnValue;
	} params{ TrackIndex, FormatIndex };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetVideoTrackFrameRates");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


float UMediaPlayer::GetVideoTrackFrameRate(int TrackIndex, int FormatIndex)
{
	struct {
            int TrackIndex;
            int FormatIndex;
            float ReturnValue;
	} params{ TrackIndex, FormatIndex };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetVideoTrackFrameRate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FIntPoint UMediaPlayer::GetVideoTrackDimensions(int TrackIndex, int FormatIndex)
{
	struct {
            int TrackIndex;
            int FormatIndex;
            struct FIntPoint ReturnValue;
	} params{ TrackIndex, FormatIndex };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetVideoTrackDimensions");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


float UMediaPlayer::GetVideoTrackAspectRatio(int TrackIndex, int FormatIndex)
{
	struct {
            int TrackIndex;
            int FormatIndex;
            float ReturnValue;
	} params{ TrackIndex, FormatIndex };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetVideoTrackAspectRatio");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


float UMediaPlayer::GetVerticalFieldOfView()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetVerticalFieldOfView");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FString UMediaPlayer::GetUrl()
{
	struct {
            struct FString ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetUrl");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FString UMediaPlayer::GetTrackLanguage(EMediaPlayerTrack TrackType, int TrackIndex)
{
	struct {
            EMediaPlayerTrack TrackType;
            int TrackIndex;
            struct FString ReturnValue;
	} params{ TrackType, TrackIndex };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetTrackLanguage");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


int UMediaPlayer::GetTrackFormat(EMediaPlayerTrack TrackType, int TrackIndex)
{
	struct {
            EMediaPlayerTrack TrackType;
            int TrackIndex;
            int ReturnValue;
	} params{ TrackType, TrackIndex };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetTrackFormat");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FText UMediaPlayer::GetTrackDisplayName(EMediaPlayerTrack TrackType, int TrackIndex)
{
	struct {
            EMediaPlayerTrack TrackType;
            int TrackIndex;
            struct FText ReturnValue;
	} params{ TrackType, TrackIndex };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetTrackDisplayName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FTimespan UMediaPlayer::GetTimeDelay()
{
	struct {
            struct FTimespan ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetTimeDelay");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FTimespan UMediaPlayer::GetTime()
{
	struct {
            struct FTimespan ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UMediaPlayer::GetSupportedRates(TArray<struct FFloatRange> OutRates, bool Unthinned)
{
	struct {
            TArray<struct FFloatRange> OutRates;
            bool Unthinned;
	} params{ OutRates, Unthinned };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetSupportedRates");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


int UMediaPlayer::GetSelectedTrack(EMediaPlayerTrack TrackType)
{
	struct {
            EMediaPlayerTrack TrackType;
            int ReturnValue;
	} params{ TrackType };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetSelectedTrack");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


float UMediaPlayer::GetRate()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetRate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


int UMediaPlayer::GetPlaylistIndex()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetPlaylistIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UMediaPlaylist* UMediaPlayer::GetPlaylist()
{
	struct {
            class UMediaPlaylist* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetPlaylist");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


FName UMediaPlayer::GetPlayerName()
{
	struct {
            FName ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetPlayerName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


int UMediaPlayer::GetNumTracks(EMediaPlayerTrack TrackType)
{
	struct {
            EMediaPlayerTrack TrackType;
            int ReturnValue;
	} params{ TrackType };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetNumTracks");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


int UMediaPlayer::GetNumTrackFormats(EMediaPlayerTrack TrackType, int TrackIndex)
{
	struct {
            EMediaPlayerTrack TrackType;
            int TrackIndex;
            int ReturnValue;
	} params{ TrackType, TrackIndex };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetNumTrackFormats");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FText UMediaPlayer::GetMediaName()
{
	struct {
            struct FText ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetMediaName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UMediaPlayer::GetHorizontalFieldOfView()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetHorizontalFieldOfView");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FTimespan UMediaPlayer::GetDuration()
{
	struct {
            struct FTimespan ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetDuration");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


FName UMediaPlayer::GetDesiredPlayerName()
{
	struct {
            FName ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetDesiredPlayerName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FString UMediaPlayer::GetAudioTrackType(int TrackIndex, int FormatIndex)
{
	struct {
            int TrackIndex;
            int FormatIndex;
            struct FString ReturnValue;
	} params{ TrackIndex, FormatIndex };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetAudioTrackType");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


int UMediaPlayer::GetAudioTrackSampleRate(int TrackIndex, int FormatIndex)
{
	struct {
            int TrackIndex;
            int FormatIndex;
            int ReturnValue;
	} params{ TrackIndex, FormatIndex };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetAudioTrackSampleRate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


int UMediaPlayer::GetAudioTrackChannels(int TrackIndex, int FormatIndex)
{
	struct {
            int TrackIndex;
            int FormatIndex;
            int ReturnValue;
	} params{ TrackIndex, FormatIndex };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:GetAudioTrackChannels");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UMediaPlayer::Close()
{
    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:Close");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


bool UMediaPlayer::CanPlayUrl(struct FString URL)
{
	struct {
            struct FString URL;
            bool ReturnValue;
	} params{ URL };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:CanPlayUrl");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UMediaPlayer::CanPlaySource(class UMediaSource* MediaSource)
{
	struct {
            class UMediaSource* MediaSource;
            bool ReturnValue;
	} params{ MediaSource };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:CanPlaySource");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UMediaPlayer::CanPause()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlayer:CanPause");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

bool UMediaPlaylist::Replace(int Index, class UMediaSource* Replacement)
{
	struct {
            int Index;
            class UMediaSource* Replacement;
            bool ReturnValue;
	} params{ Index, Replacement };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlaylist:Replace");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UMediaPlaylist::RemoveAt(int Index)
{
	struct {
            int Index;
            bool ReturnValue;
	} params{ Index };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlaylist:RemoveAt");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UMediaPlaylist::Remove(class UMediaSource* MediaSource)
{
	struct {
            class UMediaSource* MediaSource;
            bool ReturnValue;
	} params{ MediaSource };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlaylist:Remove");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


int UMediaPlaylist::Num()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlaylist:Num");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UMediaPlaylist::Insert(class UMediaSource* MediaSource, int Index)
{
	struct {
            class UMediaSource* MediaSource;
            int Index;
	} params{ MediaSource, Index };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlaylist:Insert");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


class UMediaSource* UMediaPlaylist::GetRandom(int OutIndex)
{
	struct {
            int OutIndex;
            class UMediaSource* ReturnValue;
	} params{ OutIndex };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlaylist:GetRandom");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


class UMediaSource* UMediaPlaylist::GetPrevious(int InOutIndex)
{
	struct {
            int InOutIndex;
            class UMediaSource* ReturnValue;
	} params{ InOutIndex };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlaylist:GetPrevious");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


class UMediaSource* UMediaPlaylist::GetNext(int InOutIndex)
{
	struct {
            int InOutIndex;
            class UMediaSource* ReturnValue;
	} params{ InOutIndex };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlaylist:GetNext");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


class UMediaSource* UMediaPlaylist::Get(int Index)
{
	struct {
            int Index;
            class UMediaSource* ReturnValue;
	} params{ Index };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlaylist:Get");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UMediaPlaylist::AddUrl(struct FString URL)
{
	struct {
            struct FString URL;
            bool ReturnValue;
	} params{ URL };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlaylist:AddUrl");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UMediaPlaylist::AddFile(struct FString FilePath)
{
	struct {
            struct FString FilePath;
            bool ReturnValue;
	} params{ FilePath };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlaylist:AddFile");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UMediaPlaylist::Add(class UMediaSource* MediaSource)
{
	struct {
            class UMediaSource* MediaSource;
            bool ReturnValue;
	} params{ MediaSource };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaPlaylist:Add");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UMediaSoundComponent::SetSpectralAnalysisSettings(TArray<float> InFrequenciesToAnalyze, EMediaSoundComponentFFTSize InFFTSize)
{
	struct {
            TArray<float> InFrequenciesToAnalyze;
            EMediaSoundComponentFFTSize InFFTSize;
	} params{ InFrequenciesToAnalyze, InFFTSize };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaSoundComponent:SetSpectralAnalysisSettings");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMediaSoundComponent::SetMediaPlayer(class UMediaPlayer* NewMediaPlayer)
{
	struct {
            class UMediaPlayer* NewMediaPlayer;
	} params{ NewMediaPlayer };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaSoundComponent:SetMediaPlayer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMediaSoundComponent::SetEnableSpectralAnalysis(bool bInSpectralAnalysisEnabled)
{
	struct {
            bool bInSpectralAnalysisEnabled;
	} params{ bInSpectralAnalysisEnabled };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaSoundComponent:SetEnableSpectralAnalysis");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


TArray<struct FMediaSoundComponentSpectralData> UMediaSoundComponent::GetSpectralData()
{
	struct {
            TArray<struct FMediaSoundComponentSpectralData> ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaSoundComponent:GetSpectralData");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UMediaPlayer* UMediaSoundComponent::GetMediaPlayer()
{
	struct {
            class UMediaPlayer* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaSoundComponent:GetMediaPlayer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UMediaSoundComponent::BP_GetAttenuationSettingsToApply(struct FSoundAttenuationSettings OutAttenuationSettings)
{
	struct {
            struct FSoundAttenuationSettings OutAttenuationSettings;
            bool ReturnValue;
	} params{ OutAttenuationSettings };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaSoundComponent:BP_GetAttenuationSettingsToApply");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UMediaTexture::SetMediaPlayer(class UMediaPlayer* NewMediaPlayer)
{
	struct {
            class UMediaPlayer* NewMediaPlayer;
	} params{ NewMediaPlayer };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaTexture:SetMediaPlayer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


int UMediaTexture::GetWidth()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaTexture:GetWidth");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UMediaPlayer* UMediaTexture::GetMediaPlayer()
{
	struct {
            class UMediaPlayer* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaTexture:GetMediaPlayer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


int UMediaTexture::GetHeight()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaTexture:GetHeight");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UMediaTexture::GetAspectRatio()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MediaAssets.MediaTexture:GetAspectRatio");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

