#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class EProcMeshSliceCapOption : uint8_t
{
    NoCap = 0,
    CreateNewSectionForCap = 1,
    UseLastSectionForCap = 2,
    EProcMeshSliceCapOption_MAX = 3
};struct FProcMeshTangent
{
	public:
	    struct FVector TangentX; // 0x0 Size: 0xc
	    bool bFlipTangentY; // 0xc Size: 0x1
	    char UnknownData0[0x3];

};

struct FProcMeshVertex
{
	public:
	    struct FVector Position; // 0x0 Size: 0xc
	    struct FVector Normal; // 0xc Size: 0xc
	    struct FProcMeshTangent Tangent; // 0x18 Size: 0x10
	    struct FColor Color; // 0x28 Size: 0x4
	    struct FVector2D UV0; // 0x2c Size: 0x8
	    struct FVector2D UV1; // 0x34 Size: 0x8
	    struct FVector2D UV2; // 0x3c Size: 0x8
	    struct FVector2D UV3; // 0x44 Size: 0x8

};


}