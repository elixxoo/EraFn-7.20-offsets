#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class EEyeTrackerStatus : uint8_t
{
    NotConnected = 0,
    NotTracking = 1,
    Tracking = 2,
    EEyeTrackerStatus_MAX = 3
};struct FEyeTrackerStereoGazeData
{
	public:
	    struct FVector LeftEyeOrigin; // 0x0 Size: 0xc
	    struct FVector LeftEyeDirection; // 0xc Size: 0xc
	    struct FVector RightEyeOrigin; // 0x18 Size: 0xc
	    struct FVector RightEyeDirection; // 0x24 Size: 0xc
	    struct FVector FixationPoint; // 0x30 Size: 0xc
	    float ConfidenceValue; // 0x3c Size: 0x4

};

struct FEyeTrackerGazeData
{
	public:
	    struct FVector GazeOrigin; // 0x0 Size: 0xc
	    struct FVector GazeDirection; // 0xc Size: 0xc
	    struct FVector FixationPoint; // 0x18 Size: 0xc
	    float ConfidenceValue; // 0x24 Size: 0x4

};


}