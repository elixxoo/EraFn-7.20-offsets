#include "../SDK.hpp"

void UNiagaraComponent::SetSeekDelta(float InSeekDelta)
{
	struct {
            float InSeekDelta;
	} params{ InSeekDelta };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:SetSeekDelta");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraComponent::SetRenderingEnabled(bool bInRenderingEnabled)
{
	struct {
            bool bInRenderingEnabled;
	} params{ bInRenderingEnabled };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:SetRenderingEnabled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraComponent::SetPaused(bool bInPaused)
{
	struct {
            bool bInPaused;
	} params{ bInPaused };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:SetPaused");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraComponent::SetNiagaraVariableVec4(struct FString InVariableName, struct FVector4 InValue)
{
	struct {
            struct FString InVariableName;
            struct FVector4 InValue;
	} params{ InVariableName, InValue };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:SetNiagaraVariableVec4");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraComponent::SetNiagaraVariableVec3(struct FString InVariableName, struct FVector InValue)
{
	struct {
            struct FString InVariableName;
            struct FVector InValue;
	} params{ InVariableName, InValue };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:SetNiagaraVariableVec3");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraComponent::SetNiagaraVariableVec2(struct FString InVariableName, struct FVector2D InValue)
{
	struct {
            struct FString InVariableName;
            struct FVector2D InValue;
	} params{ InVariableName, InValue };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:SetNiagaraVariableVec2");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraComponent::SetNiagaraVariableQuat(struct FString InVariableName, struct FQuat InValue)
{
	struct {
            struct FString InVariableName;
            struct FQuat InValue;
	} params{ InVariableName, InValue };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:SetNiagaraVariableQuat");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraComponent::SetNiagaraVariableLinearColor(struct FString InVariableName, struct FLinearColor InValue)
{
	struct {
            struct FString InVariableName;
            struct FLinearColor InValue;
	} params{ InVariableName, InValue };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:SetNiagaraVariableLinearColor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraComponent::SetNiagaraVariableInt(struct FString InVariableName, int InValue)
{
	struct {
            struct FString InVariableName;
            int InValue;
	} params{ InVariableName, InValue };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:SetNiagaraVariableInt");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraComponent::SetNiagaraVariableFloat(struct FString InVariableName, float InValue)
{
	struct {
            struct FString InVariableName;
            float InValue;
	} params{ InVariableName, InValue };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:SetNiagaraVariableFloat");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraComponent::SetNiagaraVariableBool(struct FString InVariableName, bool InValue)
{
	struct {
            struct FString InVariableName;
            bool InValue;
	} params{ InVariableName, InValue };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:SetNiagaraVariableBool");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraComponent::SetNiagaraVariableActor(struct FString InVariableName, class AActor* Actor)
{
	struct {
            struct FString InVariableName;
            class AActor* Actor;
	} params{ InVariableName, Actor };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:SetNiagaraVariableActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraComponent::SetMaxSimTime(float InMaxTime)
{
	struct {
            float InMaxTime;
	} params{ InMaxTime };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:SetMaxSimTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraComponent::SetForceSolo(bool bInForceSolo)
{
	struct {
            bool bInForceSolo;
	} params{ bInForceSolo };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:SetForceSolo");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraComponent::SetDesiredAge(float InDesiredAge)
{
	struct {
            float InDesiredAge;
	} params{ InDesiredAge };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:SetDesiredAge");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraComponent::SetCanRenderWhileSeeking(bool bInCanRenderWhileSeeking)
{
	struct {
            bool bInCanRenderWhileSeeking;
	} params{ bInCanRenderWhileSeeking };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:SetCanRenderWhileSeeking");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraComponent::SetAutoDestroy(bool bInAutoDestroy)
{
	struct {
            bool bInAutoDestroy;
	} params{ bInAutoDestroy };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:SetAutoDestroy");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraComponent::SetAutoAttachmentParameters(class USceneComponent* Parent, FName SocketName, EAttachmentRule LocationRule, EAttachmentRule RotationRule, EAttachmentRule ScaleRule)
{
	struct {
            class USceneComponent* Parent;
            FName SocketName;
            EAttachmentRule LocationRule;
            EAttachmentRule RotationRule;
            EAttachmentRule ScaleRule;
	} params{ Parent, SocketName, LocationRule, RotationRule, ScaleRule };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:SetAutoAttachmentParameters");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraComponent::SetAsset(class UNiagaraSystem* InAsset)
{
	struct {
            class UNiagaraSystem* InAsset;
	} params{ InAsset };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:SetAsset");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraComponent::SetAgeUpdateMode(ENiagaraAgeUpdateMode InAgeUpdateMode)
{
	struct {
            ENiagaraAgeUpdateMode InAgeUpdateMode;
	} params{ InAgeUpdateMode };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:SetAgeUpdateMode");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraComponent::SeekToDesiredAge(float InDesiredAge)
{
	struct {
            float InDesiredAge;
	} params{ InDesiredAge };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:SeekToDesiredAge");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraComponent::ResetSystem()
{
    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:ResetSystem");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UNiagaraComponent::ReinitializeSystem()
{
    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:ReinitializeSystem");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


bool UNiagaraComponent::IsPaused()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:IsPaused");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UNiagaraComponent::GetSeekDelta()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:GetSeekDelta");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


TArray<struct FVector> UNiagaraComponent::GetNiagaraParticleValueVec3_DebugOnly(struct FString InEmitterName, struct FString InValueName)
{
	struct {
            struct FString InEmitterName;
            struct FString InValueName;
            TArray<struct FVector> ReturnValue;
	} params{ InEmitterName, InValueName };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:GetNiagaraParticleValueVec3_DebugOnly");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


TArray<float> UNiagaraComponent::GetNiagaraParticleValues_DebugOnly(struct FString InEmitterName, struct FString InValueName)
{
	struct {
            struct FString InEmitterName;
            struct FString InValueName;
            TArray<float> ReturnValue;
	} params{ InEmitterName, InValueName };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:GetNiagaraParticleValues_DebugOnly");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


TArray<struct FVector> UNiagaraComponent::GetNiagaraParticlePositions_DebugOnly(struct FString InEmitterName)
{
	struct {
            struct FString InEmitterName;
            TArray<struct FVector> ReturnValue;
	} params{ InEmitterName };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:GetNiagaraParticlePositions_DebugOnly");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


float UNiagaraComponent::GetMaxSimTime()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:GetMaxSimTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UNiagaraComponent::GetForceSolo()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:GetForceSolo");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UNiagaraComponent::GetDesiredAge()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:GetDesiredAge");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UNiagaraSystem* UNiagaraComponent::GetAsset()
{
	struct {
            class UNiagaraSystem* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:GetAsset");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


ENiagaraAgeUpdateMode UNiagaraComponent::GetAgeUpdateMode()
{
	struct {
            ENiagaraAgeUpdateMode ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:GetAgeUpdateMode");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UNiagaraComponent::AdvanceSimulationByTime(float SimulateTime, float TickDeltaSeconds)
{
	struct {
            float SimulateTime;
            float TickDeltaSeconds;
	} params{ SimulateTime, TickDeltaSeconds };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:AdvanceSimulationByTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraComponent::AdvanceSimulation(int TickCount, float TickDeltaSeconds)
{
	struct {
            int TickCount;
            float TickDeltaSeconds;
	} params{ TickCount, TickDeltaSeconds };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraComponent:AdvanceSimulation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

static class UNiagaraComponent* UNiagaraFunctionLibrary::SpawnSystemAttached(class UNiagaraSystem* SystemTemplate, class USceneComponent* AttachToComponent, FName AttachPointName, struct FVector Location, struct FRotator Rotation, char LocationType, bool bAutoDestroy)
{
	struct {
            class UNiagaraSystem* SystemTemplate;
            class USceneComponent* AttachToComponent;
            FName AttachPointName;
            struct FVector Location;
            struct FRotator Rotation;
            char LocationType;
            bool bAutoDestroy;
            class UNiagaraComponent* ReturnValue;
	} params{ SystemTemplate, AttachToComponent, AttachPointName, Location, Rotation, LocationType, bAutoDestroy };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraFunctionLibrary:SpawnSystemAttached");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UNiagaraComponent* UNiagaraFunctionLibrary::SpawnSystemAtLocation(class UObject* WorldContextObject, class UNiagaraSystem* SystemTemplate, struct FVector Location, struct FRotator Rotation, bool bAutoDestroy)
{
	struct {
            class UObject* WorldContextObject;
            class UNiagaraSystem* SystemTemplate;
            struct FVector Location;
            struct FRotator Rotation;
            bool bAutoDestroy;
            class UNiagaraComponent* ReturnValue;
	} params{ WorldContextObject, SystemTemplate, Location, Rotation, bAutoDestroy };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraFunctionLibrary:SpawnSystemAtLocation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UNiagaraParameterCollectionInstance* UNiagaraFunctionLibrary::GetNiagaraParameterCollection(class UObject* WorldContextObject, class UNiagaraParameterCollection* Collection)
{
	struct {
            class UObject* WorldContextObject;
            class UNiagaraParameterCollection* Collection;
            class UNiagaraParameterCollectionInstance* ReturnValue;
	} params{ WorldContextObject, Collection };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraFunctionLibrary:GetNiagaraParameterCollection");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UNiagaraParameterCollectionInstance::SetVectorParameter(struct FString InVariableName, struct FVector InValue)
{
	struct {
            struct FString InVariableName;
            struct FVector InValue;
	} params{ InVariableName, InValue };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraParameterCollectionInstance:SetVectorParameter");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraParameterCollectionInstance::SetVector4Parameter(struct FString InVariableName, struct FVector4 InValue)
{
	struct {
            struct FString InVariableName;
            struct FVector4 InValue;
	} params{ InVariableName, InValue };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraParameterCollectionInstance:SetVector4Parameter");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraParameterCollectionInstance::SetVector2DParameter(struct FString InVariableName, struct FVector2D InValue)
{
	struct {
            struct FString InVariableName;
            struct FVector2D InValue;
	} params{ InVariableName, InValue };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraParameterCollectionInstance:SetVector2DParameter");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraParameterCollectionInstance::SetQuatParameter(struct FString InVariableName, struct FQuat InValue)
{
	struct {
            struct FString InVariableName;
            struct FQuat InValue;
	} params{ InVariableName, InValue };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraParameterCollectionInstance:SetQuatParameter");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraParameterCollectionInstance::SetIntParameter(struct FString InVariableName, int InValue)
{
	struct {
            struct FString InVariableName;
            int InValue;
	} params{ InVariableName, InValue };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraParameterCollectionInstance:SetIntParameter");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraParameterCollectionInstance::SetFloatParameter(struct FString InVariableName, float InValue)
{
	struct {
            struct FString InVariableName;
            float InValue;
	} params{ InVariableName, InValue };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraParameterCollectionInstance:SetFloatParameter");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraParameterCollectionInstance::SetColorParameter(struct FString InVariableName, struct FLinearColor InValue)
{
	struct {
            struct FString InVariableName;
            struct FLinearColor InValue;
	} params{ InVariableName, InValue };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraParameterCollectionInstance:SetColorParameter");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNiagaraParameterCollectionInstance::SetBoolParameter(struct FString InVariableName, bool InValue)
{
	struct {
            struct FString InVariableName;
            bool InValue;
	} params{ InVariableName, InValue };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraParameterCollectionInstance:SetBoolParameter");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


struct FVector UNiagaraParameterCollectionInstance::GetVectorParameter(struct FString InVariableName)
{
	struct {
            struct FString InVariableName;
            struct FVector ReturnValue;
	} params{ InVariableName };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraParameterCollectionInstance:GetVectorParameter");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FVector4 UNiagaraParameterCollectionInstance::GetVector4Parameter(struct FString InVariableName)
{
	struct {
            struct FString InVariableName;
            struct FVector4 ReturnValue;
	} params{ InVariableName };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraParameterCollectionInstance:GetVector4Parameter");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FVector2D UNiagaraParameterCollectionInstance::GetVector2DParameter(struct FString InVariableName)
{
	struct {
            struct FString InVariableName;
            struct FVector2D ReturnValue;
	} params{ InVariableName };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraParameterCollectionInstance:GetVector2DParameter");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FQuat UNiagaraParameterCollectionInstance::GetQuatParameter(struct FString InVariableName)
{
	struct {
            struct FString InVariableName;
            struct FQuat ReturnValue;
	} params{ InVariableName };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraParameterCollectionInstance:GetQuatParameter");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


int UNiagaraParameterCollectionInstance::GetIntParameter(struct FString InVariableName)
{
	struct {
            struct FString InVariableName;
            int ReturnValue;
	} params{ InVariableName };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraParameterCollectionInstance:GetIntParameter");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


float UNiagaraParameterCollectionInstance::GetFloatParameter(struct FString InVariableName)
{
	struct {
            struct FString InVariableName;
            float ReturnValue;
	} params{ InVariableName };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraParameterCollectionInstance:GetFloatParameter");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FLinearColor UNiagaraParameterCollectionInstance::GetColorParameter(struct FString InVariableName)
{
	struct {
            struct FString InVariableName;
            struct FLinearColor ReturnValue;
	} params{ InVariableName };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraParameterCollectionInstance:GetColorParameter");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UNiagaraParameterCollectionInstance::GetBoolParameter(struct FString InVariableName)
{
	struct {
            struct FString InVariableName;
            bool ReturnValue;
	} params{ InVariableName };

    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraParameterCollectionInstance:GetBoolParameter");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UNiagaraScript::OnCompilationComplete()
{
    static auto fn = UObject::FindObject("/Script/Niagara.NiagaraScript:OnCompilationComplete");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

