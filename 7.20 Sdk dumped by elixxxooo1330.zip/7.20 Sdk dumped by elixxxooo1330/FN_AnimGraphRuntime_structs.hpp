#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FOnMontagePlayDelegate__DelegateSignature
{
	public:
	    FName NotifyName; // 0x0 Size: 0x8

};



enum class ESphericalLimitType : uint8_t
{
    Inner = 0,
    Outer = 1,
    ESphericalLimitType_MAX = 2
};

enum class AnimPhysSimSpaceType : uint8_t
{
    Component = 0,
    Actor = 1,
    World = 2,
    RootRelative = 3,
    BoneRelative = 4,
    AnimPhysSimSpaceType_MAX = 5
};

enum class AnimPhysLinearConstraintType : uint8_t
{
    Free = 0,
    Limited = 1,
    AnimPhysLinearConstraintType_MAX = 2
};

enum class AnimPhysAngularConstraintType : uint8_t
{
    Angular = 0,
    Cone = 1,
    AnimPhysAngularConstraintType_MAX = 2
};

enum class EDrivenDestinationMode : uint8_t
{
    Bone = 0,
    MorphTarget = 1,
    MaterialParameter = 2,
    EDrivenDestinationMode_MAX = 3
};

enum class EDrivenBoneModificationMode : uint8_t
{
    AddToInput = 0,
    ReplaceComponent = 1,
    AddToRefPose = 2,
    EDrivenBoneModificationMode_MAX = 3
};

enum class EConstraintOffsetOption : uint8_t
{
    None = 0,
    Offset_RefPose = 1,
    EConstraintOffsetOption_MAX = 2
};

enum class CopyBoneDeltaMode : uint8_t
{
    Accumulate = 0,
    Copy = 1,
    CopyBoneDeltaMode_MAX = 2
};

enum class EInterpolationBlend : uint8_t
{
    Linear = 0,
    Cubic = 1,
    Sinusoidal = 2,
    EaseInOutExponent2 = 3,
    EaseInOutExponent3 = 4,
    EaseInOutExponent4 = 5,
    EaseInOutExponent5 = 6,
    MAX = 7
};

enum class EBoneModificationMode : uint8_t
{
    BMM_Ignore = 0,
    BMM_Replace = 1,
    BMM_Additive = 2,
    BMM_MAX = 3
};

enum class EModifyCurveApplyMode : uint8_t
{
    Add = 0,
    Scale = 1,
    Blend = 2,
    WeightedMovingAverage = 3,
    RemapCurve = 4,
    EModifyCurveApplyMode_MAX = 5
};

enum class EPoseDriverOutput : uint8_t
{
    DrivePoses = 0,
    DriveCurves = 1,
    EPoseDriverOutput_MAX = 2
};

enum class EPoseDriverSource : uint8_t
{
    Rotation = 0,
    Translation = 1,
    EPoseDriverSource_MAX = 2
};

enum class EPoseDriverType : uint8_t
{
    SwingAndTwist = 0,
    SwingOnly = 1,
    Translation = 2,
    EPoseDriverType_MAX = 3
};

enum class ESnapshotSourceMode : uint8_t
{
    NamedSnapshot = 0,
    SnapshotPin = 1,
    ESnapshotSourceMode_MAX = 2
};

enum class ERefPoseType : uint8_t
{
    EIT_LocalSpace = 0,
    EIT_Additive = 1,
    EIT_MAX = 2
};

enum class ESimulationSpace : uint8_t
{
    ComponentSpace = 0,
    WorldSpace = 1,
    BaseBoneSpace = 2,
    ESimulationSpace_MAX = 3
};

enum class EScaleChainInitialLength : uint8_t
{
    FixedDefaultLengthValue = 0,
    Distance = 1,
    ChainLength = 2,
    EScaleChainInitialLength_MAX = 3
};

enum class ESequenceEvalReinit : uint8_t
{
    NoReset = 0,
    StartPosition = 1,
    ExplicitTime = 2,
    ESequenceEvalReinit_MAX = 3
};

enum class ESplineBoneAxis : uint8_t
{
    X = 1,
    Y = 2,
    Z = 3,
    ESplineBoneAxis_MAX = 4
};

enum class ERBFDistanceMethod : uint8_t
{
    Euclidean = 0,
    Quaternion = 1,
    SwingAngle = 2,
    ERBFDistanceMethod_MAX = 3
};

enum class ERBFFunctionType : uint8_t
{
    Gaussian = 0,
    Exponential = 1,
    Linear = 2,
    Cubic = 3,
    Quintic = 4,
    ERBFFunctionType_MAX = 5
};struct FAnimSequencerInstanceProxy : public FAnimInstanceProxy
{
	public:
	    char UnknownData0[0x8c0];

};

struct FAnimNode_SkeletalControlBase : public FAnimNode_Base
{
	public:
	    struct FComponentSpacePoseLink ComponentPose; // 0x10 Size: 0x10
	    int LODThreshold; // 0x20 Size: 0x4
	    float ActualAlpha; // 0x24 Size: 0x4
	    EAnimAlphaInputType AlphaInputType; // 0x28 Size: 0x1
	    bool bAlphaBoolEnabled; // 0x29 Size: 0x1
	    char UnknownData0[0x2]; // 0x2a
	    float Alpha; // 0x2c Size: 0x4
	    struct FInputScaleBias AlphaScaleBias; // 0x30 Size: 0x8
	    struct FInputAlphaBoolBlend AlphaBoolBlend; // 0x38 Size: 0x48
	    FName AlphaCurveName; // 0x80 Size: 0x8
	    struct FInputScaleBiasClamp AlphaScaleBiasClamp; // 0x88 Size: 0x30
	    char UnknownData1[0x10];

};

struct FRandomPlayerSequenceEntry
{
	public:
	    class UAnimSequence* Sequence; // 0x0 Size: 0x8
	    float ChanceToPlay; // 0x8 Size: 0x4
	    int MinLoopCount; // 0xc Size: 0x4
	    int MaxLoopCount; // 0x10 Size: 0x4
	    float MinPlayRate; // 0x14 Size: 0x4
	    float MaxPlayRate; // 0x18 Size: 0x4
	    char UnknownData0[0x4]; // 0x1c
	    struct FAlphaBlend BlendIn; // 0x20 Size: 0x30

};

struct FAnimNode_BlendSpacePlayer : public FAnimNode_AssetPlayerBase
{
	public:
	    float X; // 0x30 Size: 0x4
	    float Y; // 0x34 Size: 0x4
	    float Z; // 0x38 Size: 0x4
	    float PlayRate; // 0x3c Size: 0x4
	    bool bLoop; // 0x40 Size: 0x1
	    bool bResetPlayTimeWhenBlendSpaceChanges; // 0x41 Size: 0x1
	    char UnknownData0[0x2]; // 0x42
	    float StartPosition; // 0x44 Size: 0x4
	    class UBlendSpaceBase* BlendSpace; // 0x48 Size: 0x8
	    char UnknownData1[0x88]; // 0x50
	    class UBlendSpaceBase* PreviousBlendSpace; // 0xd8 Size: 0x8

};

struct FAnimNode_AimOffsetLookAt : public FAnimNode_BlendSpacePlayer
{
	public:
	    char UnknownData0[0x60];
	    struct FPoseLink BasePose; // 0x140 Size: 0x10
	    int LODThreshold; // 0x150 Size: 0x4
	    FName SourceSocketName; // 0x154 Size: 0x8
	    FName PivotSocketName; // 0x15c Size: 0x8
	    struct FVector LookAtLocation; // 0x164 Size: 0xc
	    struct FVector SocketAxis; // 0x170 Size: 0xc
	    float Alpha; // 0x17c Size: 0x4
	    char UnknownData1[0x30];

};

struct FAnimPhysPlanarLimit
{
	public:
	    struct FBoneReference DrivingBone; // 0x0 Size: 0x10
	    struct FTransform PlaneTransform; // 0x10 Size: 0x30

};

struct FAnimPhysSphericalLimit
{
	public:
	    struct FBoneReference DrivingBone; // 0x0 Size: 0x10
	    struct FVector SphereLocalOffset; // 0x10 Size: 0xc
	    float LimitRadius; // 0x1c Size: 0x4
	    ESphericalLimitType LimitType; // 0x20 Size: 0x1
	    char UnknownData0[0x3];

};

struct FAnimPhysConstraintSetup
{
	public:
	    AnimPhysLinearConstraintType LinearXLimitType; // 0x0 Size: 0x1
	    AnimPhysLinearConstraintType LinearYLimitType; // 0x1 Size: 0x1
	    AnimPhysLinearConstraintType LinearZLimitType; // 0x2 Size: 0x1
	    char UnknownData0[0x1]; // 0x3
	    struct FVector LinearAxesMin; // 0x4 Size: 0xc
	    struct FVector LinearAxesMax; // 0x10 Size: 0xc
	    AnimPhysAngularConstraintType AngularConstraintType; // 0x1c Size: 0x1
	    AnimPhysTwistAxis TwistAxis; // 0x1d Size: 0x1
	    AnimPhysTwistAxis AngularTargetAxis; // 0x1e Size: 0x1
	    char UnknownData1[0x1]; // 0x1f
	    float ConeAngle; // 0x20 Size: 0x4
	    struct FVector AngularLimitsMin; // 0x24 Size: 0xc
	    struct FVector AngularLimitsMax; // 0x30 Size: 0xc
	    struct FVector AngularTarget; // 0x3c Size: 0xc

};

struct FAnimNode_ApplyAdditive : public FAnimNode_Base
{
	public:
	    struct FPoseLink Base; // 0x10 Size: 0x10
	    struct FPoseLink Additive; // 0x20 Size: 0x10
	    float Alpha; // 0x30 Size: 0x4
	    struct FInputScaleBias AlphaScaleBias; // 0x34 Size: 0x8
	    int LODThreshold; // 0x3c Size: 0x4
	    struct FInputAlphaBoolBlend AlphaBoolBlend; // 0x40 Size: 0x48
	    FName AlphaCurveName; // 0x88 Size: 0x8
	    struct FInputScaleBiasClamp AlphaScaleBiasClamp; // 0x90 Size: 0x30
	    char UnknownData0[0x4]; // 0xc0
	    EAnimAlphaInputType AlphaInputType; // 0xc4 Size: 0x1
	    bool bAlphaBoolEnabled; // 0xc5 Size: 0x1
	    char UnknownData1[0x2];

};

struct FAngularRangeLimit
{
	public:
	    struct FVector LimitMin; // 0x0 Size: 0xc
	    struct FVector LimitMax; // 0xc Size: 0xc
	    struct FBoneReference Bone; // 0x18 Size: 0x10

};

struct FBlendBoneByChannelEntry
{
	public:
	    struct FBoneReference SourceBone; // 0x0 Size: 0x10
	    struct FBoneReference TargetBone; // 0x10 Size: 0x10
	    bool bBlendTranslation; // 0x20 Size: 0x1
	    bool bBlendRotation; // 0x21 Size: 0x1
	    bool bBlendScale; // 0x22 Size: 0x1
	    char UnknownData0[0x1];

};

struct FAnimNode_BlendListByBool : public FAnimNode_BlendListBase
{
	public:
	    bool bActiveValue; // 0x98 Size: 0x1
	    char UnknownData0[0x7];

};

struct FAnimNode_BlendListByInt : public FAnimNode_BlendListBase
{
	public:
	    int ActiveChildIndex; // 0x98 Size: 0x4
	    char UnknownData0[0x4];

};

struct FAnimNode_BlendSpaceEvaluator : public FAnimNode_BlendSpacePlayer
{
	public:
	    float NormalizedTime; // 0xe0 Size: 0x4
	    char UnknownData0[0x4];

};

struct FAnimNode_BoneDrivenController : public FAnimNode_SkeletalControlBase
{
	public:
	    struct FBoneReference SourceBone; // 0xc8 Size: 0x10
	    class UCurveFloat* DrivingCurve; // 0xd8 Size: 0x8
	    float Multiplier; // 0xe0 Size: 0x4
	    float RangeMin; // 0xe4 Size: 0x4
	    float RangeMax; // 0xe8 Size: 0x4
	    float RemappedMin; // 0xec Size: 0x4
	    float RemappedMax; // 0xf0 Size: 0x4
	    FName ParameterName; // 0xf4 Size: 0x8
	    struct FBoneReference TargetBone; // 0xfc Size: 0x10
	    EDrivenDestinationMode DestinationMode; // 0x10c Size: 0x1
	    EDrivenBoneModificationMode ModificationMode; // 0x10d Size: 0x1
	    char SourceComponent; // 0x10e Size: 0x1
	    bool bUseRange; // 0x10f Size: 0x1
	    bool bAffectTargetTranslationX; // 0x10f Size: 0x1
	    bool bAffectTargetTranslationY; // 0x10f Size: 0x1
	    bool bAffectTargetTranslationZ; // 0x10f Size: 0x1
	    bool bAffectTargetRotationX; // 0x10f Size: 0x1
	    bool bAffectTargetRotationY; // 0x10f Size: 0x1
	    bool bAffectTargetRotationZ; // 0x10f Size: 0x1
	    bool bAffectTargetScaleX; // 0x10f Size: 0x1
	    bool bAffectTargetScaleY; // 0x110 Size: 0x1
	    bool bAffectTargetScaleZ; // 0x110 Size: 0x1
	    char UnknownData0[0x-1];

};

struct FSocketReference
{
	public:
	    FName SocketName; // 0x30 Size: 0x8
	    char UnknownData0[0x8];

};

struct FBoneSocketTarget
{
	public:
	    bool bUseSocket; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    struct FBoneReference BoneReference; // 0x4 Size: 0x10
	    char UnknownData1[0xc]; // 0x14
	    struct FSocketReference SocketReference; // 0x20 Size: 0x40

};

struct FConstraint
{
	public:
	    struct FBoneReference TargetBone; // 0x0 Size: 0x10
	    EConstraintOffsetOption OffsetOption; // 0x10 Size: 0x1
	    ETransformConstraintType TransformType; // 0x11 Size: 0x1
	    struct FFilterOptionPerAxis PerAxis; // 0x12 Size: 0x3
	    char UnknownData0[0x7];

};

struct FAnimNode_CopyBone : public FAnimNode_SkeletalControlBase
{
	public:
	    struct FBoneReference SourceBone; // 0xc8 Size: 0x10
	    struct FBoneReference TargetBone; // 0xd8 Size: 0x10
	    bool bCopyTranslation; // 0xe8 Size: 0x1
	    bool bCopyRotation; // 0xe9 Size: 0x1
	    bool bCopyScale; // 0xea Size: 0x1
	    char ControlSpace; // 0xeb Size: 0x1
	    char UnknownData0[0x4];

};

struct FAnimNode_CopyBoneDelta : public FAnimNode_SkeletalControlBase
{
	public:
	    struct FBoneReference SourceBone; // 0xc8 Size: 0x10
	    struct FBoneReference TargetBone; // 0xd8 Size: 0x10
	    bool bCopyTranslation; // 0xe8 Size: 0x1
	    bool bCopyRotation; // 0xe9 Size: 0x1
	    bool bCopyScale; // 0xea Size: 0x1
	    CopyBoneDeltaMode CopyMode; // 0xeb Size: 0x1
	    float TranslationMultiplier; // 0xec Size: 0x4
	    float RotationMultiplier; // 0xf0 Size: 0x4
	    float ScaleMultiplier; // 0xf4 Size: 0x4

};

struct FAnimNode_CopyPoseFromMesh : public FAnimNode_Base
{
	public:
	    TWeakObjectPtr<USkeletalMeshComponent*> SourceMeshComponent; // 0x10 Size: 0x8
	    bool bUseAttachedParent; // 0x18 Size: 0x1
	    bool bCopyCurves; // 0x19 Size: 0x1
	    char UnknownData0[0x11e];

};

struct FAnimNode_CurveSource : public FAnimNode_Base
{
	public:
	    struct FPoseLink SourcePose; // 0x10 Size: 0x10
	    FName SourceBinding; // 0x20 Size: 0x8
	    float Alpha; // 0x28 Size: 0x4
	    char UnknownData0[0x4]; // 0x2c
	    __int64/*InterfaceProperty*/ CurveSource; // 0x30 Size: 0x10

};

struct FAnimNode_Fabrik : public FAnimNode_SkeletalControlBase
{
	public:
	    char UnknownData0[0x8];
	    struct FTransform EffectorTransform; // 0xd0 Size: 0x30
	    struct FBoneSocketTarget EffectorTarget; // 0x100 Size: 0x60
	    struct FBoneReference TipBone; // 0x160 Size: 0x10
	    struct FBoneReference RootBone; // 0x170 Size: 0x10
	    float Precision; // 0x180 Size: 0x4
	    int MaxIterations; // 0x184 Size: 0x4
	    char EffectorTransformSpace; // 0x188 Size: 0x1
	    char EffectorRotationSource; // 0x189 Size: 0x1
	    char UnknownData1[0x6];

};

struct FAnimLegIKDefinition
{
	public:
	    struct FBoneReference IKFootBone; // 0x0 Size: 0x10
	    struct FBoneReference FKFootBone; // 0x10 Size: 0x10
	    int NumBonesInLimb; // 0x20 Size: 0x4
	    float MinRotationAngle; // 0x24 Size: 0x4
	    char FootBoneForwardAxis; // 0x28 Size: 0x1
	    char HingeRotationAxis; // 0x29 Size: 0x1
	    bool bEnableRotationLimit; // 0x2a Size: 0x1
	    bool bEnableKneeTwistCorrection; // 0x2b Size: 0x1

};

struct FAnimLegIKData
{
	public:
	    char UnknownData0[0xa0];

};

struct FIKChain
{
	public:
	    char UnknownData0[0x38];

};

struct FIKChainLink
{
	public:
	    char UnknownData0[0x3c];

};

struct FAnimNode_LookAt : public FAnimNode_SkeletalControlBase
{
	public:
	    struct FBoneReference BoneToModify; // 0xc8 Size: 0x10
	    char UnknownData0[0x8]; // 0xd8
	    struct FBoneSocketTarget LookAtTarget; // 0xe0 Size: 0x60
	    struct FVector LookAtLocation; // 0x140 Size: 0xc
	    struct FAxis LookAt_Axis; // 0x14c Size: 0x10
	    bool bUseLookUpAxis; // 0x15c Size: 0x1
	    char InterpolationType; // 0x15d Size: 0x1
	    char UnknownData1[0x2]; // 0x15e
	    struct FAxis LookUp_Axis; // 0x160 Size: 0x10
	    float LookAtClamp; // 0x170 Size: 0x4
	    float InterpolationTime; // 0x174 Size: 0x4
	    float InterpolationTriggerThreashold; // 0x178 Size: 0x4
	    char UnknownData2[0x34];

};

struct FAnimNode_MakeDynamicAdditive : public FAnimNode_Base
{
	public:
	    struct FPoseLink Base; // 0x10 Size: 0x10
	    struct FPoseLink Additive; // 0x20 Size: 0x10
	    bool bMeshSpaceAdditive; // 0x30 Size: 0x1
	    char UnknownData0[0x7];

};

struct FAnimNode_ModifyBone : public FAnimNode_SkeletalControlBase
{
	public:
	    struct FBoneReference BoneToModify; // 0xc8 Size: 0x10
	    struct FVector Translation; // 0xd8 Size: 0xc
	    struct FRotator Rotation; // 0xe4 Size: 0xc
	    struct FVector Scale; // 0xf0 Size: 0xc
	    char TranslationMode; // 0xfc Size: 0x1
	    char RotationMode; // 0xfd Size: 0x1
	    char ScaleMode; // 0xfe Size: 0x1
	    char TranslationSpace; // 0xff Size: 0x1
	    char RotationSpace; // 0x100 Size: 0x1
	    char ScaleSpace; // 0x101 Size: 0x1
	    char UnknownData0[0x6];

};

struct FAnimNode_ObserveBone : public FAnimNode_SkeletalControlBase
{
	public:
	    struct FBoneReference BoneToObserve; // 0xc8 Size: 0x10
	    char DisplaySpace; // 0xd8 Size: 0x1
	    bool bRelativeToRefPose; // 0xd9 Size: 0x1
	    char UnknownData0[0x2]; // 0xda
	    struct FVector Translation; // 0xdc Size: 0xc
	    struct FRotator Rotation; // 0xe8 Size: 0xc
	    struct FVector Scale; // 0xf4 Size: 0xc

};

struct FAnimNode_PoseHandler : public FAnimNode_AssetPlayerBase
{
	public:
	    class UPoseAsset* PoseAsset; // 0x30 Size: 0x8
	    char UnknownData0[0x30];

};

struct FAnimNode_PoseBlendNode : public FAnimNode_PoseHandler
{
	public:
	    struct FPoseLink SourcePose; // 0x68 Size: 0x10
	    EAlphaBlendOption BlendOption; // 0x78 Size: 0x1
	    char UnknownData0[0x7]; // 0x79
	    class UCurveFloat* CustomCurve; // 0x80 Size: 0x8

};

struct FAnimNode_PoseByName : public FAnimNode_PoseHandler
{
	public:
	    FName PoseName; // 0x68 Size: 0x8
	    float PoseWeight; // 0x70 Size: 0x4
	    char UnknownData0[0x4];

};

struct FRBFParams
{
	public:
	    int TargetDimensions; // 0x0 Size: 0x4
	    float Radius; // 0x4 Size: 0x4
	    ERBFFunctionType Function; // 0x8 Size: 0x1
	    ERBFDistanceMethod DistanceMethod; // 0x9 Size: 0x1
	    char TwistAxis; // 0xa Size: 0x1
	    char UnknownData0[0x1]; // 0xb
	    float WeightThreshold; // 0xc Size: 0x4

};

struct FPoseDriverTransform
{
	public:
	    struct FVector TargetTranslation; // 0x0 Size: 0xc
	    struct FRotator TargetRotation; // 0xc Size: 0xc

};

struct FAnimNode_MeshSpaceRefPose : public FAnimNode_Base
{
	public:
	    char UnknownData0[0x10];

};

struct FAnimNode_RefPose : public FAnimNode_Base
{
	public:
	    char RefPoseType; // 0x10 Size: 0x1
	    char UnknownData0[0x7];

};

struct FAnimNode_ResetRoot : public FAnimNode_SkeletalControlBase
{
	public:
	    char UnknownData0[0xd8];

};

struct FAnimNode_RigidBody : public FAnimNode_SkeletalControlBase
{
	public:
	    class UPhysicsAsset* OverridePhysicsAsset; // 0xc8 Size: 0x8
	    char UnknownData0[0x90]; // 0xd0
	    struct FVector OverrideWorldGravity; // 0x160 Size: 0xc
	    struct FVector ExternalForce; // 0x16c Size: 0xc
	    struct FVector ComponentLinearAccScale; // 0x178 Size: 0xc
	    struct FVector ComponentLinearVelScale; // 0x184 Size: 0xc
	    struct FVector ComponentAppliedLinearAccClamp; // 0x190 Size: 0xc
	    float CachedBoundsScale; // 0x19c Size: 0x4
	    struct FBoneReference BaseBoneRef; // 0x1a0 Size: 0x10
	    char OverlapChannel; // 0x1b0 Size: 0x1
	    ESimulationSpace SimulationSpace; // 0x1b1 Size: 0x1
	    bool bForceDisableCollisionBetweenConstraintBodies; // 0x1b2 Size: 0x1
	    bool bEnableWorldGeometry; // 0x1b4 Size: 0x1
	    bool bOverrideWorldGravity; // 0x1b4 Size: 0x1
	    bool bTransferBoneVelocities; // 0x1b4 Size: 0x1
	    bool bFreezeIncomingPoseOnStart; // 0x1b4 Size: 0x1
	    bool bClampLinearTranslationLimitToRefPose; // 0x1b4 Size: 0x1
	    char UnknownData1[0x398];

};

struct FAnimNode_Root : public FAnimNode_Base
{
	public:
	    struct FPoseLink Result; // 0x10 Size: 0x10

};

struct FAnimNode_RotateRootBone : public FAnimNode_Base
{
	public:
	    struct FPoseLink BasePose; // 0x10 Size: 0x10
	    float Pitch; // 0x20 Size: 0x4
	    float Yaw; // 0x24 Size: 0x4
	    struct FInputScaleBiasClamp PitchScaleBiasClamp; // 0x28 Size: 0x30
	    struct FInputScaleBiasClamp YawScaleBiasClamp; // 0x58 Size: 0x30
	    struct FRotator MeshToComponent; // 0x88 Size: 0xc
	    char UnknownData0[0xc];

};

struct FAnimNode_RotationMultiplier : public FAnimNode_SkeletalControlBase
{
	public:
	    struct FBoneReference TargetBone; // 0xc8 Size: 0x10
	    struct FBoneReference SourceBone; // 0xd8 Size: 0x10
	    float Multiplier; // 0xe8 Size: 0x4
	    char RotationAxisToRefer; // 0xec Size: 0x1
	    bool bIsAdditive; // 0xed Size: 0x1
	    char UnknownData0[0x2];

};

struct FAnimNode_RotationOffsetBlendSpace : public FAnimNode_BlendSpacePlayer
{
	public:
	    struct FPoseLink BasePose; // 0xe0 Size: 0x10
	    int LODThreshold; // 0xf0 Size: 0x4
	    float Alpha; // 0xf4 Size: 0x4
	    struct FInputScaleBias AlphaScaleBias; // 0xf8 Size: 0x8
	    struct FInputAlphaBoolBlend AlphaBoolBlend; // 0x100 Size: 0x48
	    FName AlphaCurveName; // 0x148 Size: 0x8
	    struct FInputScaleBiasClamp AlphaScaleBiasClamp; // 0x150 Size: 0x30
	    char UnknownData0[0x4]; // 0x180
	    EAnimAlphaInputType AlphaInputType; // 0x184 Size: 0x1
	    bool bAlphaBoolEnabled; // 0x185 Size: 0x1
	    char UnknownData1[0x2];

};

struct FAnimNode_ScaleChainLength : public FAnimNode_Base
{
	public:
	    struct FPoseLink InputPose; // 0x10 Size: 0x10
	    float DefaultChainLength; // 0x20 Size: 0x4
	    struct FBoneReference ChainStartBone; // 0x24 Size: 0x10
	    struct FBoneReference ChainEndBone; // 0x34 Size: 0x10
	    struct FVector TargetLocation; // 0x44 Size: 0xc
	    float Alpha; // 0x50 Size: 0x4
	    char UnknownData0[0x4]; // 0x54
	    struct FInputScaleBias AlphaScaleBias; // 0x58 Size: 0x8
	    EScaleChainInitialLength ChainInitialLength; // 0x60 Size: 0x1
	    char UnknownData1[0x17];

};

struct FAnimNode_SequenceEvaluator : public FAnimNode_AssetPlayerBase
{
	public:
	    class UAnimSequenceBase* Sequence; // 0x30 Size: 0x8
	    float ExplicitTime; // 0x38 Size: 0x4
	    bool bShouldLoop; // 0x3c Size: 0x1
	    bool bTeleportToExplicitTime; // 0x3d Size: 0x1
	    char ReinitializationBehavior; // 0x3e Size: 0x1
	    char UnknownData0[0x1]; // 0x3f
	    float StartPosition; // 0x40 Size: 0x4
	    char UnknownData1[0x4];

};

struct FAnimNode_Slot : public FAnimNode_Base
{
	public:
	    struct FPoseLink Source; // 0x10 Size: 0x10
	    FName SlotName; // 0x20 Size: 0x8
	    bool bAlwaysUpdateSourcePose; // 0x28 Size: 0x1
	    char UnknownData0[0x1f];

};

struct FSplineIKCachedBoneData
{
	public:
	    struct FBoneReference Bone; // 0x0 Size: 0x10
	    int RefSkeletonIndex; // 0x10 Size: 0x4

};

struct FAnimNode_SpringBone : public FAnimNode_SkeletalControlBase
{
	public:
	    struct FBoneReference SpringBone; // 0xc8 Size: 0x10
	    float MaxDisplacement; // 0xd8 Size: 0x4
	    float SpringStiffness; // 0xdc Size: 0x4
	    float SpringDamping; // 0xe0 Size: 0x4
	    float ErrorResetThresh; // 0xe4 Size: 0x4
	    bool bLimitDisplacement; // 0x124 Size: 0x1
	    bool bTranslateX; // 0x124 Size: 0x1
	    bool bTranslateY; // 0x124 Size: 0x1
	    bool bTranslateZ; // 0x124 Size: 0x1
	    bool bRotateX; // 0x124 Size: 0x1
	    bool bRotateY; // 0x124 Size: 0x1
	    bool bRotateZ; // 0x124 Size: 0x1
	    char UnknownData0[0x39];

};

struct FAnimNode_StateResult : public FAnimNode_Root
{
	public:
	    char UnknownData0[0x20];

};

struct FRotationLimit
{
	public:
	    struct FVector LimitMin; // 0x0 Size: 0xc
	    struct FVector LimitMax; // 0xc Size: 0xc

};

struct FReferenceBoneFrame
{
	public:
	    struct FBoneReference Bone; // 0x0 Size: 0x10
	    struct FAxis Axis; // 0x10 Size: 0x10

};

struct FAnimNode_TwistCorrectiveNode : public FAnimNode_SkeletalControlBase
{
	public:
	    struct FReferenceBoneFrame BaseFrame; // 0xc8 Size: 0x20
	    struct FReferenceBoneFrame TwistFrame; // 0xe8 Size: 0x20
	    struct FAxis TwistPlaneNormalAxis; // 0x108 Size: 0x10
	    float RangeMax; // 0x118 Size: 0x4
	    float RemappedMin; // 0x11c Size: 0x4
	    float RemappedMax; // 0x120 Size: 0x4
	    struct FAnimCurveParam Curve; // 0x124 Size: 0xc
	    char UnknownData0[0x8];

};

struct FAnimNode_TwoBoneIK : public FAnimNode_SkeletalControlBase
{
	public:
	    struct FBoneReference IKBone; // 0xc8 Size: 0x10
	    float StartStretchRatio; // 0xd8 Size: 0x4
	    float MaxStretchScale; // 0xdc Size: 0x4
	    struct FVector EffectorLocation; // 0xe0 Size: 0xc
	    char UnknownData0[0x4]; // 0xec
	    struct FBoneSocketTarget EffectorTarget; // 0xf0 Size: 0x60
	    struct FVector JointTargetLocation; // 0x150 Size: 0xc
	    char UnknownData1[0x4]; // 0x15c
	    struct FBoneSocketTarget JointTarget; // 0x160 Size: 0x60
	    struct FAxis TwistAxis; // 0x1c0 Size: 0x10
	    char EffectorLocationSpace; // 0x1d0 Size: 0x1
	    char JointTargetLocationSpace; // 0x1d1 Size: 0x1
	    bool bAllowStretching; // 0x1d2 Size: 0x1
	    bool bTakeRotationFromEffectorSpace; // 0x1d2 Size: 0x1
	    bool bMaintainEffectorRelRot; // 0x1d2 Size: 0x1
	    bool bAllowTwist; // 0x1d2 Size: 0x1
	    char UnknownData2[0xa];

};

struct FAnimNode_TwoWayBlend : public FAnimNode_Base
{
	public:
	    struct FPoseLink A; // 0x10 Size: 0x10
	    struct FPoseLink B; // 0x20 Size: 0x10
	    EAnimAlphaInputType AlphaInputType; // 0x30 Size: 0x1
	    bool bAlphaBoolEnabled; // 0x31 Size: 0x1
	    bool bResetChildOnActivation; // 0x31 Size: 0x1
	    char UnknownData0[0x1]; // 0x33
	    float Alpha; // 0x34 Size: 0x4
	    struct FInputScaleBias AlphaScaleBias; // 0x38 Size: 0x8
	    struct FInputAlphaBoolBlend AlphaBoolBlend; // 0x40 Size: 0x48
	    FName AlphaCurveName; // 0x88 Size: 0x8
	    struct FInputScaleBiasClamp AlphaScaleBiasClamp; // 0x90 Size: 0x30
	    char UnknownData1[0x8];

};


}