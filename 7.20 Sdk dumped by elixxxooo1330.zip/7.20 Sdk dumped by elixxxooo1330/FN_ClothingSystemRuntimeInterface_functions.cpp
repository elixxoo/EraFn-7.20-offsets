#include "../SDK.hpp"

void UClothingSimulationInteractor::PhysicsAssetUpdated()
{
    static auto fn = UObject::FindObject("/Script/ClothingSystemRuntimeInterface.ClothingSimulationInteractor:PhysicsAssetUpdated");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UClothingSimulationInteractor::ClothConfigUpdated()
{
    static auto fn = UObject::FindObject("/Script/ClothingSystemRuntimeInterface.ClothingSimulationInteractor:ClothConfigUpdated");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

