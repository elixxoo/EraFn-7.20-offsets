#include "../SDK.hpp"

void USkeletalMeshComponentBudgeted::SetAutoRegisterWithBudgetAllocator(bool bInAutoRegisterWithBudgetAllocator)
{
	struct {
            bool bInAutoRegisterWithBudgetAllocator;
	} params{ bInAutoRegisterWithBudgetAllocator };

    static auto fn = UObject::FindObject("/Script/AnimationBudgetAllocator.SkeletalMeshComponentBudgeted:SetAutoRegisterWithBudgetAllocator");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

