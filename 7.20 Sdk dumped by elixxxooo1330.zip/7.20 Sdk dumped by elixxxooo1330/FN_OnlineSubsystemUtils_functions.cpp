#include "../SDK.hpp"

void AOnlineBeaconClient::ClientOnConnected()
{
    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.OnlineBeaconClient:ClientOnConnected");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

static void UAchievementBlueprintLibrary::GetCachedAchievementProgress(class UObject* WorldContextObject, class APlayerController* PlayerController, FName AchievementID, bool bFoundID, float Progress)
{
	struct {
            class UObject* WorldContextObject;
            class APlayerController* PlayerController;
            FName AchievementID;
            bool bFoundID;
            float Progress;            void ReturnValue;
	} params{ WorldContextObject, PlayerController, AchievementID, bFoundID, Progress };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.AchievementBlueprintLibrary:GetCachedAchievementProgress");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAchievementBlueprintLibrary::GetCachedAchievementDescription(class UObject* WorldContextObject, class APlayerController* PlayerController, FName AchievementID, bool bFoundID, struct FText Title, struct FText LockedDescription, struct FText UnlockedDescription, bool bHidden)
{
	struct {
            class UObject* WorldContextObject;
            class APlayerController* PlayerController;
            FName AchievementID;
            bool bFoundID;
            struct FText Title;
            struct FText LockedDescription;
            struct FText UnlockedDescription;
            bool bHidden;            void ReturnValue;
	} params{ WorldContextObject, PlayerController, AchievementID, bFoundID, Title, LockedDescription, UnlockedDescription, bHidden };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.AchievementBlueprintLibrary:GetCachedAchievementDescription");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UAchievementQueryCallbackProxy* UAchievementQueryCallbackProxy::CacheAchievements(class UObject* WorldContextObject, class APlayerController* PlayerController)
{
	struct {
            class UObject* WorldContextObject;
            class APlayerController* PlayerController;
            class UAchievementQueryCallbackProxy* ReturnValue;
	} params{ WorldContextObject, PlayerController };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.AchievementQueryCallbackProxy:CacheAchievements");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UAchievementQueryCallbackProxy* UAchievementQueryCallbackProxy::CacheAchievementDescriptions(class UObject* WorldContextObject, class APlayerController* PlayerController)
{
	struct {
            class UObject* WorldContextObject;
            class APlayerController* PlayerController;
            class UAchievementQueryCallbackProxy* ReturnValue;
	} params{ WorldContextObject, PlayerController };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.AchievementQueryCallbackProxy:CacheAchievementDescriptions");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UAchievementWriteCallbackProxy* UAchievementWriteCallbackProxy::WriteAchievementProgress(class UObject* WorldContextObject, class APlayerController* PlayerController, FName AchievementName, float Progress, int UserTag)
{
	struct {
            class UObject* WorldContextObject;
            class APlayerController* PlayerController;
            FName AchievementName;
            float Progress;
            int UserTag;
            class UAchievementWriteCallbackProxy* ReturnValue;
	} params{ WorldContextObject, PlayerController, AchievementName, Progress, UserTag };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.AchievementWriteCallbackProxy:WriteAchievementProgress");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UConnectionCallbackProxy* UConnectionCallbackProxy::ConnectToService(class UObject* WorldContextObject, class APlayerController* PlayerController)
{
	struct {
            class UObject* WorldContextObject;
            class APlayerController* PlayerController;
            class UConnectionCallbackProxy* ReturnValue;
	} params{ WorldContextObject, PlayerController };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.ConnectionCallbackProxy:ConnectToService");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UCreateSessionCallbackProxy* UCreateSessionCallbackProxy::CreateSession(class UObject* WorldContextObject, class APlayerController* PlayerController, int PublicConnections, bool bUseLAN)
{
	struct {
            class UObject* WorldContextObject;
            class APlayerController* PlayerController;
            int PublicConnections;
            bool bUseLAN;
            class UCreateSessionCallbackProxy* ReturnValue;
	} params{ WorldContextObject, PlayerController, PublicConnections, bUseLAN };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.CreateSessionCallbackProxy:CreateSession");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UDestroySessionCallbackProxy* UDestroySessionCallbackProxy::DestroySession(class UObject* WorldContextObject, class APlayerController* PlayerController)
{
	struct {
            class UObject* WorldContextObject;
            class APlayerController* PlayerController;
            class UDestroySessionCallbackProxy* ReturnValue;
	} params{ WorldContextObject, PlayerController };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.DestroySessionCallbackProxy:DestroySession");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UEndMatchCallbackProxy* UEndMatchCallbackProxy::EndMatch(class UObject* WorldContextObject, class APlayerController* PlayerController, __int64/*InterfaceProperty*/ MatchActor, struct FString MatchID, char LocalPlayerOutcome, char OtherPlayersOutcome)
{
	struct {
            class UObject* WorldContextObject;
            class APlayerController* PlayerController;
            __int64/*InterfaceProperty*/ MatchActor;
            struct FString MatchID;
            char LocalPlayerOutcome;
            char OtherPlayersOutcome;
            class UEndMatchCallbackProxy* ReturnValue;
	} params{ WorldContextObject, PlayerController, MatchActor, MatchID, LocalPlayerOutcome, OtherPlayersOutcome };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.EndMatchCallbackProxy:EndMatch");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UEndTurnCallbackProxy* UEndTurnCallbackProxy::EndTurn(class UObject* WorldContextObject, class APlayerController* PlayerController, struct FString MatchID, __int64/*InterfaceProperty*/ TurnBasedMatchInterface)
{
	struct {
            class UObject* WorldContextObject;
            class APlayerController* PlayerController;
            struct FString MatchID;
            __int64/*InterfaceProperty*/ TurnBasedMatchInterface;
            class UEndTurnCallbackProxy* ReturnValue;
	} params{ WorldContextObject, PlayerController, MatchID, TurnBasedMatchInterface };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.EndTurnCallbackProxy:EndTurn");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static struct FString UFindSessionsCallbackProxy::GetServerName(struct FBlueprintSessionResult Result)
{
	struct {
            struct FBlueprintSessionResult Result;
            struct FString ReturnValue;
	} params{ Result };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.FindSessionsCallbackProxy:GetServerName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static int UFindSessionsCallbackProxy::GetPingInMs(struct FBlueprintSessionResult Result)
{
	struct {
            struct FBlueprintSessionResult Result;
            int ReturnValue;
	} params{ Result };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.FindSessionsCallbackProxy:GetPingInMs");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static int UFindSessionsCallbackProxy::GetMaxPlayers(struct FBlueprintSessionResult Result)
{
	struct {
            struct FBlueprintSessionResult Result;
            int ReturnValue;
	} params{ Result };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.FindSessionsCallbackProxy:GetMaxPlayers");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static int UFindSessionsCallbackProxy::GetCurrentPlayers(struct FBlueprintSessionResult Result)
{
	struct {
            struct FBlueprintSessionResult Result;
            int ReturnValue;
	} params{ Result };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.FindSessionsCallbackProxy:GetCurrentPlayers");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UFindSessionsCallbackProxy* UFindSessionsCallbackProxy::FindSessions(class UObject* WorldContextObject, class APlayerController* PlayerController, int MaxResults, bool bUseLAN)
{
	struct {
            class UObject* WorldContextObject;
            class APlayerController* PlayerController;
            int MaxResults;
            bool bUseLAN;
            class UFindSessionsCallbackProxy* ReturnValue;
	} params{ WorldContextObject, PlayerController, MaxResults, bUseLAN };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.FindSessionsCallbackProxy:FindSessions");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UFindTurnBasedMatchCallbackProxy* UFindTurnBasedMatchCallbackProxy::FindTurnBasedMatch(class UObject* WorldContextObject, class APlayerController* PlayerController, __int64/*InterfaceProperty*/ MatchActor, int MinPlayers, int MaxPlayers, int PlayerGroup, bool ShowExistingMatches)
{
	struct {
            class UObject* WorldContextObject;
            class APlayerController* PlayerController;
            __int64/*InterfaceProperty*/ MatchActor;
            int MinPlayers;
            int MaxPlayers;
            int PlayerGroup;
            bool ShowExistingMatches;
            class UFindTurnBasedMatchCallbackProxy* ReturnValue;
	} params{ WorldContextObject, PlayerController, MatchActor, MinPlayers, MaxPlayers, PlayerGroup, ShowExistingMatches };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.FindTurnBasedMatchCallbackProxy:FindTurnBasedMatch");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UInAppPurchaseCallbackProxy* UInAppPurchaseCallbackProxy::CreateProxyObjectForInAppPurchase(class APlayerController* PlayerController, struct FInAppPurchaseProductRequest ProductRequest)
{
	struct {
            class APlayerController* PlayerController;
            struct FInAppPurchaseProductRequest ProductRequest;
            class UInAppPurchaseCallbackProxy* ReturnValue;
	} params{ PlayerController, ProductRequest };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.InAppPurchaseCallbackProxy:CreateProxyObjectForInAppPurchase");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UInAppPurchaseQueryCallbackProxy* UInAppPurchaseQueryCallbackProxy::CreateProxyObjectForInAppPurchaseQuery(class APlayerController* PlayerController, TArray<struct FString> ProductIdentifiers)
{
	struct {
            class APlayerController* PlayerController;
            TArray<struct FString> ProductIdentifiers;
            class UInAppPurchaseQueryCallbackProxy* ReturnValue;
	} params{ PlayerController, ProductIdentifiers };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.InAppPurchaseQueryCallbackProxy:CreateProxyObjectForInAppPurchaseQuery");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UInAppPurchaseRestoreCallbackProxy* UInAppPurchaseRestoreCallbackProxy::CreateProxyObjectForInAppPurchaseRestore(TArray<struct FInAppPurchaseProductRequest> ConsumableProductFlags, class APlayerController* PlayerController)
{
	struct {
            TArray<struct FInAppPurchaseProductRequest> ConsumableProductFlags;
            class APlayerController* PlayerController;
            class UInAppPurchaseRestoreCallbackProxy* ReturnValue;
	} params{ ConsumableProductFlags, PlayerController };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.InAppPurchaseRestoreCallbackProxy:CreateProxyObjectForInAppPurchaseRestore");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UJoinSessionCallbackProxy* UJoinSessionCallbackProxy::JoinSession(class UObject* WorldContextObject, class APlayerController* PlayerController, struct FBlueprintSessionResult SearchResult)
{
	struct {
            class UObject* WorldContextObject;
            class APlayerController* PlayerController;
            struct FBlueprintSessionResult SearchResult;
            class UJoinSessionCallbackProxy* ReturnValue;
	} params{ WorldContextObject, PlayerController, SearchResult };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.JoinSessionCallbackProxy:JoinSession");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static bool ULeaderboardBlueprintLibrary::WriteLeaderboardInteger(class APlayerController* PlayerController, FName StatName, int StatValue)
{
	struct {
            class APlayerController* PlayerController;
            FName StatName;
            int StatValue;
            bool ReturnValue;
	} params{ PlayerController, StatName, StatValue };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.LeaderboardBlueprintLibrary:WriteLeaderboardInteger");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class ULeaderboardFlushCallbackProxy* ULeaderboardFlushCallbackProxy::CreateProxyObjectForFlush(class APlayerController* PlayerController, FName SessionName)
{
	struct {
            class APlayerController* PlayerController;
            FName SessionName;
            class ULeaderboardFlushCallbackProxy* ReturnValue;
	} params{ PlayerController, SessionName };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.LeaderboardFlushCallbackProxy:CreateProxyObjectForFlush");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class ULeaderboardQueryCallbackProxy* ULeaderboardQueryCallbackProxy::CreateProxyObjectForIntQuery(class APlayerController* PlayerController, FName StatName)
{
	struct {
            class APlayerController* PlayerController;
            FName StatName;
            class ULeaderboardQueryCallbackProxy* ReturnValue;
	} params{ PlayerController, StatName };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.LeaderboardQueryCallbackProxy:CreateProxyObjectForIntQuery");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class ULogoutCallbackProxy* ULogoutCallbackProxy::Logout(class UObject* WorldContextObject, class APlayerController* PlayerController)
{
	struct {
            class UObject* WorldContextObject;
            class APlayerController* PlayerController;
            class ULogoutCallbackProxy* ReturnValue;
	} params{ WorldContextObject, PlayerController };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.LogoutCallbackProxy:Logout");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void APartyBeaconClient::ServerUpdateReservationRequest(struct FString SessionId, struct FPartyReservation ReservationUpdate)
{
	struct {
            struct FString SessionId;
            struct FPartyReservation ReservationUpdate;
	} params{ SessionId, ReservationUpdate };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.PartyBeaconClient:ServerUpdateReservationRequest");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void APartyBeaconClient::ServerReservationRequest(struct FString SessionId, struct FPartyReservation Reservation)
{
	struct {
            struct FString SessionId;
            struct FPartyReservation Reservation;
	} params{ SessionId, Reservation };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.PartyBeaconClient:ServerReservationRequest");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void APartyBeaconClient::ServerCancelReservationRequest(struct FUniqueNetIdRepl PartyLeader)
{
	struct {
            struct FUniqueNetIdRepl PartyLeader;
	} params{ PartyLeader };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.PartyBeaconClient:ServerCancelReservationRequest");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void APartyBeaconClient::ClientSendReservationUpdates(int NumRemainingReservations)
{
	struct {
            int NumRemainingReservations;
	} params{ NumRemainingReservations };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.PartyBeaconClient:ClientSendReservationUpdates");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void APartyBeaconClient::ClientSendReservationFull()
{
    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.PartyBeaconClient:ClientSendReservationFull");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void APartyBeaconClient::ClientReservationResponse(char ReservationResponse)
{
	struct {
            char ReservationResponse;
	} params{ ReservationResponse };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.PartyBeaconClient:ClientReservationResponse");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void APartyBeaconClient::ClientCancelReservationResponse(char ReservationResponse)
{
	struct {
            char ReservationResponse;
	} params{ ReservationResponse };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.PartyBeaconClient:ClientCancelReservationResponse");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

static class UQuitMatchCallbackProxy* UQuitMatchCallbackProxy::QuitMatch(class UObject* WorldContextObject, class APlayerController* PlayerController, struct FString MatchID, char Outcome, int TurnTimeoutInSeconds)
{
	struct {
            class UObject* WorldContextObject;
            class APlayerController* PlayerController;
            struct FString MatchID;
            char Outcome;
            int TurnTimeoutInSeconds;
            class UQuitMatchCallbackProxy* ReturnValue;
	} params{ WorldContextObject, PlayerController, MatchID, Outcome, TurnTimeoutInSeconds };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.QuitMatchCallbackProxy:QuitMatch");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UShowLoginUICallbackProxy* UShowLoginUICallbackProxy::ShowExternalLoginUI(class UObject* WorldContextObject, class APlayerController* InPlayerController)
{
	struct {
            class UObject* WorldContextObject;
            class APlayerController* InPlayerController;
            class UShowLoginUICallbackProxy* ReturnValue;
	} params{ WorldContextObject, InPlayerController };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.ShowLoginUICallbackProxy:ShowExternalLoginUI");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void ATestBeaconClient::ServerPong()
{
    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.TestBeaconClient:ServerPong");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void ATestBeaconClient::ClientPing()
{
    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.TestBeaconClient:ClientPing");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

static void UTurnBasedBlueprintLibrary::RegisterTurnBasedMatchInterfaceObject(class UObject* WorldContextObject, class APlayerController* PlayerController, class UObject* Object)
{
	struct {
            class UObject* WorldContextObject;
            class APlayerController* PlayerController;
            class UObject* Object;            void ReturnValue;
	} params{ WorldContextObject, PlayerController, Object };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.TurnBasedBlueprintLibrary:RegisterTurnBasedMatchInterfaceObject");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UTurnBasedBlueprintLibrary::GetPlayerDisplayName(class UObject* WorldContextObject, class APlayerController* PlayerController, struct FString MatchID, int PlayerIndex, struct FString PlayerDisplayName)
{
	struct {
            class UObject* WorldContextObject;
            class APlayerController* PlayerController;
            struct FString MatchID;
            int PlayerIndex;
            struct FString PlayerDisplayName;            void ReturnValue;
	} params{ WorldContextObject, PlayerController, MatchID, PlayerIndex, PlayerDisplayName };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.TurnBasedBlueprintLibrary:GetPlayerDisplayName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UTurnBasedBlueprintLibrary::GetMyPlayerIndex(class UObject* WorldContextObject, class APlayerController* PlayerController, struct FString MatchID, int PlayerIndex)
{
	struct {
            class UObject* WorldContextObject;
            class APlayerController* PlayerController;
            struct FString MatchID;
            int PlayerIndex;            void ReturnValue;
	} params{ WorldContextObject, PlayerController, MatchID, PlayerIndex };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.TurnBasedBlueprintLibrary:GetMyPlayerIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UTurnBasedBlueprintLibrary::GetIsMyTurn(class UObject* WorldContextObject, class APlayerController* PlayerController, struct FString MatchID, bool bIsMyTurn)
{
	struct {
            class UObject* WorldContextObject;
            class APlayerController* PlayerController;
            struct FString MatchID;
            bool bIsMyTurn;            void ReturnValue;
	} params{ WorldContextObject, PlayerController, MatchID, bIsMyTurn };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.TurnBasedBlueprintLibrary:GetIsMyTurn");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

bool UVoipListenerSynthComponent::IsIdling()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystemUtils.VoipListenerSynthComponent:IsIdling");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

