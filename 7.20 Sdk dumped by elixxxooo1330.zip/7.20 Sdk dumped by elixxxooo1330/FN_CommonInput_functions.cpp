#include "../SDK.hpp"

bool UCommonInputSubsystem::ShouldShowInputKeys()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonInput.CommonInputSubsystem:ShouldShowInputKeys");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UCommonInputSubsystem::SetGamepadInputType(ECommonGamepadType InGamepadInputType)
{
	struct {
            ECommonGamepadType InGamepadInputType;
	} params{ InGamepadInputType };

    static auto fn = UObject::FindObject("/Script/CommonInput.CommonInputSubsystem:SetGamepadInputType");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonInputSubsystem::SetCurrentInputType(ECommonInputType NewInputType)
{
	struct {
            ECommonInputType NewInputType;
	} params{ NewInputType };

    static auto fn = UObject::FindObject("/Script/CommonInput.CommonInputSubsystem:SetCurrentInputType");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UCommonInputSubsystem::IsUsingPointerInput()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonInput.CommonInputSubsystem:IsUsingPointerInput");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


ECommonInputType UCommonInputSubsystem::GetDefaultInputType()
{
	struct {
            ECommonInputType ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonInput.CommonInputSubsystem:GetDefaultInputType");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


ECommonInputType UCommonInputSubsystem::GetCurrentInputType()
{
	struct {
            ECommonInputType ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonInput.CommonInputSubsystem:GetCurrentInputType");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


ECommonGamepadType UCommonInputSubsystem::GetCurrentGamepadType()
{
	struct {
            ECommonGamepadType ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonInput.CommonInputSubsystem:GetCurrentGamepadType");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

