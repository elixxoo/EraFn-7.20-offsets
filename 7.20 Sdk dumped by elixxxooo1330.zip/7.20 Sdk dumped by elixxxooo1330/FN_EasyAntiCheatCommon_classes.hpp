#pragma once

#include "../SDK.hpp"

namespace SDK {


class UEasyAntiCheatNetComponent : public UActorComponent
{
	public:
	    void ServerMessage(TArray<char> MESSAGE); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void ClientMessage(TArray<char> MESSAGE); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7ee1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EasyAntiCheatCommon.EasyAntiCheatNetComponent");
			return (class UClass*)ptr;
		};

};


}