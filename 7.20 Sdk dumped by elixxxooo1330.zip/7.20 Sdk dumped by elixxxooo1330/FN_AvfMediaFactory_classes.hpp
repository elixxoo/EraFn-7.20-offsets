#pragma once

#include "../SDK.hpp"

namespace SDK {


class UAvfMediaSettings : public UObject
{
	public:
	    bool NativeAudioOut; // 0x28 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AvfMediaFactory.AvfMediaSettings");
			return (class UClass*)ptr;
		};

};


}