#pragma once

#include "../SDK.hpp"

namespace SDK {


class ULiveStreamVoiceChannel : public UVoiceChannel
{
	public:
	    char UnknownData0[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/LiveStreamVoice.LiveStreamVoiceChannel");
			return (class UClass*)ptr;
		};

};

class ULiveStreamVoiceSubsystem : public UGameInstanceSubsystem
{
	public:
	    struct FVoiceSettings PlaybackSettings; // 0x28 Size: 0x18
	    char UnknownData0[0x40]; // 0x40
	    void SetVoiceSettings(struct FVoiceSettings InSettings); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void ClearVoiceSettings(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7fa1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/LiveStreamVoice.LiveStreamVoiceSubsystem");
			return (class UClass*)ptr;
		};

};


}