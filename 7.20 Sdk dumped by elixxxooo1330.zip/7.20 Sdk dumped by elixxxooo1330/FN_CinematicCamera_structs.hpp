#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FCameraTrackingFocusSettings
{
	public:
	    struct TSoftObjectPtr<struct AActor*> ActorToTrack; // 0x0 Size: 0x28
	    struct FVector RelativeOffset; // 0x28 Size: 0xc
	    bool bDrawDebugTrackingFocusPoint; // 0x34 Size: 0x1
	    char UnknownData0[0x3];

};



enum class ECameraFocusMethod : uint8_t
{
    None = 0,
    Manual = 1,
    Tracking = 2,
    ECameraFocusMethod_MAX = 3
};struct FCameraFocusSettings
{
	public:
	    ECameraFocusMethod FocusMethod; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float ManualFocusDistance; // 0x4 Size: 0x4
	    struct FCameraTrackingFocusSettings TrackingFocusSettings; // 0x8 Size: 0x38
	    bool bDrawDebugFocusPlane; // 0x40 Size: 0x1
	    char UnknownData1[0x3]; // 0x41
	    struct FColor DebugFocusPlaneColor; // 0x44 Size: 0x4
	    bool bSmoothFocusChanges; // 0x48 Size: 0x1
	    char UnknownData2[0x3]; // 0x49
	    float FocusSmoothingInterpSpeed; // 0x4c Size: 0x4
	    float FocusOffset; // 0x50 Size: 0x4
	    char UnknownData3[0x4];

};

struct FCameraLensSettings
{
	public:
	    float MinFocalLength; // 0x0 Size: 0x4
	    float MaxFocalLength; // 0x4 Size: 0x4
	    float MinFStop; // 0x8 Size: 0x4
	    float MaxFStop; // 0xc Size: 0x4
	    float MinimumFocusDistance; // 0x10 Size: 0x4
	    int DiaphragmBladeCount; // 0x14 Size: 0x4

};

struct FCameraFilmbackSettings
{
	public:
	    float SensorWidth; // 0x0 Size: 0x4
	    float SensorHeight; // 0x4 Size: 0x4
	    float SensorAspectRatio; // 0x8 Size: 0x4

};

struct FCameraLookatTrackingSettings
{
	public:
	    bool bEnableLookAtTracking; // 0x0 Size: 0x1
	    bool bDrawDebugLookAtTrackingPosition; // 0x0 Size: 0x1
	    char UnknownData0[0x2]; // 0x2
	    float LookAtTrackingInterpSpeed; // 0x4 Size: 0x4
	    char UnknownData1[0x10]; // 0x8
	    struct TSoftObjectPtr<struct AActor*> ActorToTrack; // 0x18 Size: 0x28
	    struct FVector RelativeOffset; // 0x40 Size: 0xc
	    bool bAllowRoll; // 0x4c Size: 0x1
	    char UnknownData2[0x3];

};

struct FNamedLensPreset
{
	public:
	    struct FString Name; // 0x0 Size: 0x10
	    struct FCameraLensSettings LensSettings; // 0x10 Size: 0x18

};

struct FNamedFilmbackPreset
{
	public:
	    struct FString Name; // 0x0 Size: 0x10
	    struct FCameraFilmbackSettings FilmbackSettings; // 0x10 Size: 0xc
	    char UnknownData0[0x4];

};


}