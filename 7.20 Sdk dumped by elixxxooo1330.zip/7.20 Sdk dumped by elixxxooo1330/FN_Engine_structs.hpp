#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FFloatRK4SpringInterpolator
{
	public:
	    float StiffnessConstant; // 0x0 Size: 0x4
	    float DampeningRatio; // 0x4 Size: 0x4

};

struct FVectorRK4SpringInterpolator
{
	public:
	    float StiffnessConstant; // 0x0 Size: 0x4
	    float DampeningRatio; // 0x4 Size: 0x4

};



enum class ETextGender : uint8_t
{
    Masculine = 0,
    Feminine = 1,
    Neuter = 2,
    ETextGender_MAX = 3
};struct FFormatArgumentData
{
	public:
	    struct FString ArgumentName; // 0x0 Size: 0x10
	    char ArgumentValueType; // 0x10 Size: 0x1
	    char UnknownData0[0x7]; // 0x11
	    struct FText ArgumentValue; // 0x18 Size: 0x18
	    int ArgumentValueInt; // 0x30 Size: 0x4
	    float ArgumentValueFloat; // 0x34 Size: 0x4
	    ETextGender ArgumentValueGender; // 0x38 Size: 0x1
	    char UnknownData1[0x7];

};



enum class EFormatArgumentType : uint8_t
{
    Int = 0,
    UInt = 1,
    Float = 2,
    Double = 3,
    Text = 4,
    Gender = 5,
    EFormatArgumentType_MAX = 6
};struct FExpressionInput
{
	public:
	    int OutputIndex; // 0x0 Size: 0x4
	    FName ExpressionName; // 0x4 Size: 0x8

};

struct FMaterialAttributesInput : public FExpressionInput
{
	public:
	    int PropertyConnectedBitmask; // 0xc Size: 0x4

};

struct FExpressionOutput
{
	public:
	    FName OutputName; // 0x0 Size: 0x8

};

struct FMaterialInput
{
	public:
	    int OutputIndex; // 0x0 Size: 0x4
	    FName ExpressionName; // 0x4 Size: 0x8

};

struct FColorMaterialInput : public FMaterialInput
{
	public:
	    char UnknownData0[0xc];

};

struct FScalarMaterialInput : public FMaterialInput
{
	public:
	    char UnknownData0[0xc];

};

struct FVectorMaterialInput : public FMaterialInput
{
	public:
	    char UnknownData0[0xc];

};

struct FVector2MaterialInput : public FMaterialInput
{
	public:
	    char UnknownData0[0xc];

};

struct FTimerDynamicDelegate__DelegateSignature
{
	public:

};

struct FConstraintBrokenSignature__DelegateSignature
{
	public:
	    int ConstraintIndex; // 0x0 Size: 0x4

};

struct FActorComponentActivatedSignature__DelegateSignature
{
	public:
	    class UActorComponent* Component; // 0x0 Size: 0x8
	    bool bReset; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FActorComponentDeactivateSignature__DelegateSignature
{
	public:
	    class UActorComponent* Component; // 0x0 Size: 0x8

};

struct FPhysicsVolumeChanged__DelegateSignature
{
	public:
	    class APhysicsVolume* NewVolume; // 0x0 Size: 0x8

};

struct FTakeAnyDamageSignature__DelegateSignature
{
	public:
	    class AActor* DamagedActor; // 0x0 Size: 0x8
	    float Damage; // 0x8 Size: 0x4
	    char UnknownData0[0x4]; // 0xc
	    class UDamageType* DamageType; // 0x10 Size: 0x8
	    class AController* InstigatedBy; // 0x18 Size: 0x8
	    class AActor* DamageCauser; // 0x20 Size: 0x8

};

struct FTakePointDamageSignature__DelegateSignature
{
	public:
	    class AActor* DamagedActor; // 0x0 Size: 0x8
	    float Damage; // 0x8 Size: 0x4
	    char UnknownData0[0x4]; // 0xc
	    class AController* InstigatedBy; // 0x10 Size: 0x8
	    struct FVector HitLocation; // 0x18 Size: 0xc
	    char UnknownData1[0x4]; // 0x24
	    class UPrimitiveComponent* FHitComponent; // 0x28 Size: 0x8
	    FName BoneName; // 0x30 Size: 0x8
	    struct FVector ShotFromDirection; // 0x38 Size: 0xc
	    char UnknownData2[0x4]; // 0x44
	    class UDamageType* DamageType; // 0x48 Size: 0x8
	    class AActor* DamageCauser; // 0x50 Size: 0x8

};

struct FVector_NetQuantize : public FVector
{
	public:
	    char UnknownData0[0xc];

};

struct FVector_NetQuantizeNormal : public FVector
{
	public:
	    char UnknownData0[0xc];

};

struct FHitResult
{
	public:
	    bool bBlockingHit; // 0x0 Size: 0x1
	    bool bStartPenetrating; // 0x0 Size: 0x1
	    char UnknownData0[0x2]; // 0x2
	    int FaceIndex; // 0x4 Size: 0x4
	    float Time; // 0x8 Size: 0x4
	    float Distance; // 0xc Size: 0x4
	    struct FVector_NetQuantize Location; // 0x10 Size: 0xc
	    struct FVector_NetQuantize ImpactPoint; // 0x1c Size: 0xc
	    struct FVector_NetQuantizeNormal Normal; // 0x28 Size: 0xc
	    struct FVector_NetQuantizeNormal ImpactNormal; // 0x34 Size: 0xc
	    struct FVector_NetQuantize TraceStart; // 0x40 Size: 0xc
	    struct FVector_NetQuantize TraceEnd; // 0x4c Size: 0xc
	    float PenetrationDepth; // 0x58 Size: 0x4
	    int Item; // 0x5c Size: 0x4
	    TWeakObjectPtr<UPhysicalMaterial*> PhysMaterial; // 0x60 Size: 0x8
	    TWeakObjectPtr<AActor*> Actor; // 0x68 Size: 0x8
	    TWeakObjectPtr<UPrimitiveComponent*> Component; // 0x70 Size: 0x8
	    FName BoneName; // 0x78 Size: 0x8
	    FName MyBoneName; // 0x80 Size: 0x8

};

struct FTakeRadialDamageSignature__DelegateSignature
{
	public:
	    class AActor* DamagedActor; // 0x0 Size: 0x8
	    float Damage; // 0x8 Size: 0x4
	    char UnknownData0[0x4]; // 0xc
	    class UDamageType* DamageType; // 0x10 Size: 0x8
	    struct FVector Origin; // 0x18 Size: 0xc
	    struct FHitResult HitInfo; // 0x24 Size: 0x88
	    char UnknownData1[0x4]; // 0xac
	    class AController* InstigatedBy; // 0xb0 Size: 0x8
	    class AActor* DamageCauser; // 0xb8 Size: 0x8

};

struct FActorBeginOverlapSignature__DelegateSignature
{
	public:
	    class AActor* OverlappedActor; // 0x0 Size: 0x8
	    class AActor* OtherActor; // 0x8 Size: 0x8

};

struct FActorEndOverlapSignature__DelegateSignature
{
	public:
	    class AActor* OverlappedActor; // 0x0 Size: 0x8
	    class AActor* OtherActor; // 0x8 Size: 0x8

};

struct FActorHitSignature__DelegateSignature
{
	public:
	    class AActor* SelfActor; // 0x0 Size: 0x8
	    class AActor* OtherActor; // 0x8 Size: 0x8
	    struct FVector NormalImpulse; // 0x10 Size: 0xc
	    struct FHitResult Hit; // 0x1c Size: 0x88
	    char UnknownData0[0x4];

};

struct FActorBeginCursorOverSignature__DelegateSignature
{
	public:
	    class AActor* TouchedActor; // 0x0 Size: 0x8

};

struct FActorEndCursorOverSignature__DelegateSignature
{
	public:
	    class AActor* TouchedActor; // 0x0 Size: 0x8

};

struct FActorOnClickedSignature__DelegateSignature
{
	public:
	    class AActor* TouchedActor; // 0x0 Size: 0x8
	    struct FKey ButtonPressed; // 0x8 Size: 0x18

};

struct FActorOnReleasedSignature__DelegateSignature
{
	public:
	    class AActor* TouchedActor; // 0x0 Size: 0x8
	    struct FKey ButtonReleased; // 0x8 Size: 0x18

};

struct FActorOnInputTouchBeginSignature__DelegateSignature
{
	public:
	    char FingerIndex; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class AActor* TouchedActor; // 0x8 Size: 0x8

};

struct FActorOnInputTouchEndSignature__DelegateSignature
{
	public:
	    char FingerIndex; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class AActor* TouchedActor; // 0x8 Size: 0x8

};

struct FActorBeginTouchOverSignature__DelegateSignature
{
	public:
	    char FingerIndex; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class AActor* TouchedActor; // 0x8 Size: 0x8

};

struct FActorEndTouchOverSignature__DelegateSignature
{
	public:
	    char FingerIndex; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class AActor* TouchedActor; // 0x8 Size: 0x8

};

struct FActorDestroyedSignature__DelegateSignature
{
	public:
	    class AActor* DestroyedActor; // 0x0 Size: 0x8

};

struct FActorEndPlaySignature__DelegateSignature
{
	public:
	    class AActor* Actor; // 0x0 Size: 0x8
	    char EndPlayReason; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};



enum class EEndPlayReason : uint8_t
{
    Destroyed = 0,
    LevelTransition = 1,
    EndPlayInEditor = 2,
    RemovedFromWorld = 3,
    Quit = 4,
    EEndPlayReason_MAX = 5
};struct FComponentHitSignature__DelegateSignature
{
	public:
	    class UPrimitiveComponent* HitComponent; // 0x0 Size: 0x8
	    class AActor* OtherActor; // 0x8 Size: 0x8
	    class UPrimitiveComponent* OtherComp; // 0x10 Size: 0x8
	    struct FVector NormalImpulse; // 0x18 Size: 0xc
	    struct FHitResult Hit; // 0x24 Size: 0x88
	    char UnknownData0[0x4];

};

struct FComponentBeginOverlapSignature__DelegateSignature
{
	public:
	    class UPrimitiveComponent* OverlappedComponent; // 0x0 Size: 0x8
	    class AActor* OtherActor; // 0x8 Size: 0x8
	    class UPrimitiveComponent* OtherComp; // 0x10 Size: 0x8
	    int OtherBodyIndex; // 0x18 Size: 0x4
	    bool bFromSweep; // 0x1c Size: 0x1
	    char UnknownData0[0x3]; // 0x1d
	    struct FHitResult SweepResult; // 0x20 Size: 0x88

};

struct FComponentEndOverlapSignature__DelegateSignature
{
	public:
	    class UPrimitiveComponent* OverlappedComponent; // 0x0 Size: 0x8
	    class AActor* OtherActor; // 0x8 Size: 0x8
	    class UPrimitiveComponent* OtherComp; // 0x10 Size: 0x8
	    int OtherBodyIndex; // 0x18 Size: 0x4
	    char UnknownData0[0x4];

};

struct FComponentWakeSignature__DelegateSignature
{
	public:
	    class UPrimitiveComponent* WakingComponent; // 0x0 Size: 0x8
	    FName BoneName; // 0x8 Size: 0x8

};

struct FComponentSleepSignature__DelegateSignature
{
	public:
	    class UPrimitiveComponent* SleepingComponent; // 0x0 Size: 0x8
	    FName BoneName; // 0x8 Size: 0x8

};

struct FComponentCollisionSettingsChangedSignature__DelegateSignature
{
	public:
	    class UPrimitiveComponent* ChangedComponent; // 0x0 Size: 0x8

};

struct FComponentBeginCursorOverSignature__DelegateSignature
{
	public:
	    class UPrimitiveComponent* TouchedComponent; // 0x0 Size: 0x8

};

struct FComponentEndCursorOverSignature__DelegateSignature
{
	public:
	    class UPrimitiveComponent* TouchedComponent; // 0x0 Size: 0x8

};

struct FComponentOnClickedSignature__DelegateSignature
{
	public:
	    class UPrimitiveComponent* TouchedComponent; // 0x0 Size: 0x8
	    struct FKey ButtonPressed; // 0x8 Size: 0x18

};

struct FComponentOnReleasedSignature__DelegateSignature
{
	public:
	    class UPrimitiveComponent* TouchedComponent; // 0x0 Size: 0x8
	    struct FKey ButtonReleased; // 0x8 Size: 0x18

};

struct FComponentOnInputTouchBeginSignature__DelegateSignature
{
	public:
	    char FingerIndex; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class UPrimitiveComponent* TouchedComponent; // 0x8 Size: 0x8

};

struct FComponentOnInputTouchEndSignature__DelegateSignature
{
	public:
	    char FingerIndex; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class UPrimitiveComponent* TouchedComponent; // 0x8 Size: 0x8

};

struct FComponentBeginTouchOverSignature__DelegateSignature
{
	public:
	    char FingerIndex; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class UPrimitiveComponent* TouchedComponent; // 0x8 Size: 0x8

};

struct FComponentEndTouchOverSignature__DelegateSignature
{
	public:
	    char FingerIndex; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class UPrimitiveComponent* TouchedComponent; // 0x8 Size: 0x8

};

struct FOnAnimInitialized__DelegateSignature
{
	public:

};

struct FOnBoneTransformsFinalized__DelegateSignature
{
	public:

};

struct FOnMontageStartedMCDelegate__DelegateSignature
{
	public:
	    class UAnimMontage* Montage; // 0x0 Size: 0x8

};

struct FOnMontageEndedMCDelegate__DelegateSignature
{
	public:
	    class UAnimMontage* Montage; // 0x0 Size: 0x8
	    bool bInterrupted; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FOnAllMontageInstancesEndedMCDelegate__DelegateSignature
{
	public:

};

struct FOnMontageBlendingOutStartedMCDelegate__DelegateSignature
{
	public:
	    class UAnimMontage* Montage; // 0x0 Size: 0x8
	    bool bInterrupted; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FBranchingPointNotifyPayload
{
	public:
	    char UnknownData0[0x20];

};

struct FPlayMontageAnimNotifyDelegate__DelegateSignature
{
	public:
	    FName NotifyName; // 0x0 Size: 0x8
	    struct FBranchingPointNotifyPayload BranchingPointPayload; // 0x8 Size: 0x20

};

struct FPostEvaluateAnimEvent__DelegateSignature
{
	public:

};



enum class ETickingGroup : uint8_t
{
    TG_PrePhysics = 0,
    TG_StartPhysics = 1,
    TG_DuringPhysics = 2,
    TG_EndPhysics = 3,
    TG_PostPhysics = 4,
    TG_PostUpdateWork = 5,
    TG_LastDemotable = 6,
    TG_NewlySpawned = 7,
    TG_MAX = 8
};struct FSimpleMemberReference
{
	public:
	    class UObject* MemberParent; // 0x0 Size: 0x8
	    FName MemberName; // 0x8 Size: 0x8
	    struct FGuid MemberGuid; // 0x10 Size: 0x10

};



enum class EComponentCreationMethod : uint8_t
{
    Native = 0,
    SimpleConstructionScript = 1,
    UserConstructionScript = 2,
    Instance = 3,
    EComponentCreationMethod_MAX = 4
};struct FTickFunction
{
	public:
	    char TickGroup; // 0x8 Size: 0x1
	    char EndTickGroup; // 0x9 Size: 0x1
	    bool bTickEvenWhenPaused; // 0xc Size: 0x1
	    bool bCanEverTick; // 0xc Size: 0x1
	    bool bStartWithTickEnabled; // 0xc Size: 0x1
	    bool bAllowTickOnDedicatedServer; // 0xc Size: 0x1
	    char UnknownData0[0x32]; // 0xe
	    float TickInterval; // 0x40 Size: 0x4
	    char UnknownData1[0xc];

};

struct FActorComponentTickFunction : public FTickFunction
{
	public:
	    char UnknownData0[0x58];

};



enum class ETemperatureSeverityType : uint8_t
{
    Unknown = 0,
    Good = 1,
    Bad = 2,
    Serious = 3,
    Critical = 4,
    NumSeverities = 5,
    ETemperatureSeverityType_MAX = 6
};struct FOnSubmixRecordedFileDone__DelegateSignature
{
	public:
	    class USoundWave* ResultingSoundWave; // 0x0 Size: 0x8

};

struct FOnAudioFinished__DelegateSignature
{
	public:

};

struct FSubtitleCue
{
	public:
	    struct FText Text; // 0x0 Size: 0x18
	    float Time; // 0x18 Size: 0x4
	    char UnknownData0[0x4];

};

struct FOnAudioPlaybackPercent__DelegateSignature
{
	public:
	    class USoundWave* PlayingSoundWave; // 0x0 Size: 0x8
	    float PlaybackPercent; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FOnAudioSingleEnvelopeValue__DelegateSignature
{
	public:
	    class USoundWave* PlayingSoundWave; // 0x0 Size: 0x8
	    float EnvelopeValue; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FOnAudioMultiEnvelopeValue__DelegateSignature
{
	public:
	    float AverageEnvelopeValue; // 0x0 Size: 0x4
	    float MaxEnvelope; // 0x4 Size: 0x4
	    int NumWaveInstances; // 0x8 Size: 0x4

};

struct FOnForceFeedbackFinished__DelegateSignature
{
	public:
	    class UForceFeedbackComponent* ForceFeedbackComponent; // 0x0 Size: 0x8

};

struct FInputActionHandlerDynamicSignature__DelegateSignature
{
	public:
	    struct FKey Key; // 0x0 Size: 0x18

};

struct FInputTouchHandlerDynamicSignature__DelegateSignature
{
	public:
	    char FingerIndex; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    struct FVector Location; // 0x4 Size: 0xc

};

struct FInputAxisHandlerDynamicSignature__DelegateSignature
{
	public:
	    float AxisValue; // 0x0 Size: 0x4

};

struct FInputVectorAxisHandlerDynamicSignature__DelegateSignature
{
	public:
	    struct FVector AxisValue; // 0x0 Size: 0xc

};

struct FInputGestureHandlerDynamicSignature__DelegateSignature
{
	public:
	    float Value; // 0x0 Size: 0x4

};



enum class EPlaneConstraintAxisSetting : uint8_t
{
    Custom = 0,
    X = 1,
    Y = 2,
    Z = 3,
    UseGlobalPhysicsSetting = 4,
    EPlaneConstraintAxisSetting_MAX = 5
};struct FInterpControlPoint
{
	public:
	    struct FVector PositionControlPoint; // 0x0 Size: 0xc
	    bool bPositionIsRelative; // 0xc Size: 0x1
	    char UnknownData0[0xf];

};



enum class EInterpToBehaviourType : uint8_t
{
    OneShot = 0,
    OneShot_Reverse = 1,
    Loop_Reset = 2,
    PingPong = 3,
    EInterpToBehaviourType_MAX = 4
};struct FOnTimelineEvent__DelegateSignature
{
	public:

};

struct FOnTimelineFloat__DelegateSignature
{
	public:
	    float Output; // 0x0 Size: 0x4

};

struct FOnTimelineVector__DelegateSignature
{
	public:
	    struct FVector Output; // 0x0 Size: 0xc

};

struct FOnTimelineLinearColor__DelegateSignature
{
	public:
	    struct FLinearColor Output; // 0x0 Size: 0x10

};

struct FOnCanvasRenderTargetUpdate__DelegateSignature
{
	public:
	    class UCanvas* Canvas; // 0x0 Size: 0x8
	    int Width; // 0x8 Size: 0x4
	    int Height; // 0xc Size: 0x4

};

struct FPlatformInterfaceData
{
	public:
	    FName DataName; // 0x0 Size: 0x8
	    char Type; // 0x8 Size: 0x1
	    char UnknownData0[0x3]; // 0x9
	    int IntValue; // 0xc Size: 0x4
	    float FloatValue; // 0x10 Size: 0x4
	    char UnknownData1[0x4]; // 0x14
	    struct FString StringValue; // 0x18 Size: 0x10
	    class UObject* ObjectValue; // 0x28 Size: 0x8

};

struct FPlatformInterfaceDelegateResult
{
	public:
	    bool bSuccessful; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FPlatformInterfaceData Data; // 0x8 Size: 0x30

};

struct FPlatformInterfaceDelegate__DelegateSignature
{
	public:
	    struct FPlatformInterfaceDelegateResult Result; // 0x0 Size: 0x38

};



enum class EPlatformInterfaceDataType : uint8_t
{
    PIDT_None = 0,
    PIDT_Int = 1,
    PIDT_Float = 2,
    PIDT_String = 3,
    PIDT_Object = 4,
    PIDT_Custom = 5,
    PIDT_MAX = 6
};struct FInstigatedAnyDamageSignature__DelegateSignature
{
	public:
	    float Damage; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    class UDamageType* DamageType; // 0x8 Size: 0x8
	    class AActor* DamagedActor; // 0x10 Size: 0x8
	    class AActor* DamageCauser; // 0x18 Size: 0x8

};

struct FOnUserClickedBanner__DelegateSignature
{
	public:

};

struct FOnUserClosedAdvertisement__DelegateSignature
{
	public:

};

struct FLevelStreamingLoadedStatus__DelegateSignature
{
	public:

};

struct FLevelStreamingVisibilityStatus__DelegateSignature
{
	public:

};

struct FMovementModeChangedSignature__DelegateSignature
{
	public:
	    class ACharacter* Character; // 0x0 Size: 0x8
	    char PrevMovementMode; // 0x8 Size: 0x1
	    char PreviousCustomMode; // 0x9 Size: 0x1
	    char UnknownData0[0x6];

};



enum class EMovementMode : uint8_t
{
    MOVE_None = 0,
    MOVE_Walking = 1,
    MOVE_NavWalking = 2,
    MOVE_Falling = 3,
    MOVE_Swimming = 4,
    MOVE_Flying = 5,
    MOVE_Custom = 6,
    MOVE_MAX = 7
};struct FCharacterMovementUpdatedSignature__DelegateSignature
{
	public:
	    float DeltaSeconds; // 0x0 Size: 0x4
	    struct FVector OldLocation; // 0x4 Size: 0xc
	    struct FVector OldVelocity; // 0x10 Size: 0xc

};

struct FCharacterReachedApexSignature__DelegateSignature
{
	public:

};

struct FLandedSignature__DelegateSignature
{
	public:
	    struct FHitResult Hit; // 0x0 Size: 0x88

};

struct FOnGameUserSettingsUINeedsUpdate__DelegateSignature
{
	public:

};



enum class ENetworkFailure : uint8_t
{
    NetDriverAlreadyExists = 0,
    NetDriverCreateFailure = 1,
    NetDriverListenFailure = 2,
    ConnectionLost = 3,
    ConnectionTimeout = 4,
    FailureReceived = 5,
    OutdatedClient = 6,
    OutdatedServer = 7,
    PendingConnectionFailure = 8,
    NetGuidMismatch = 9,
    NetChecksumMismatch = 10,
    ENetworkFailure_MAX = 11
};

enum class ETravelFailure : uint8_t
{
    NoLevel = 0,
    LoadMapFailure = 1,
    InvalidURL = 2,
    PackageMissing = 3,
    PackageVersion = 4,
    NoDownload = 5,
    TravelFailure = 6,
    CheatCommands = 7,
    PendingNetGameCreateFailure = 8,
    CloudSaveFailure = 9,
    ServerTravelFailure = 10,
    ClientTravelFailure = 11,
    ETravelFailure_MAX = 12
};

enum class EScreenOrientation : uint8_t
{
    Unknown = 0,
    Portrait = 1,
    PortraitUpsideDown = 2,
    LandscapeLeft = 3,
    LandscapeRight = 4,
    FaceUp = 5,
    FaceDown = 6,
    EScreenOrientation_MAX = 7
};

enum class EApplicationState : uint8_t
{
    Unknown = 0,
    Inactive = 1,
    Background = 2,
    Active = 3,
    EApplicationState_MAX = 4
};

enum class EObjectTypeQuery : uint8_t
{
    ObjectTypeQuery1 = 0,
    ObjectTypeQuery2 = 1,
    ObjectTypeQuery3 = 2,
    ObjectTypeQuery4 = 3,
    ObjectTypeQuery5 = 4,
    ObjectTypeQuery6 = 5,
    ObjectTypeQuery7 = 6,
    ObjectTypeQuery8 = 7,
    ObjectTypeQuery9 = 8,
    ObjectTypeQuery10 = 9,
    ObjectTypeQuery11 = 10,
    ObjectTypeQuery12 = 11,
    ObjectTypeQuery13 = 12,
    ObjectTypeQuery14 = 13,
    ObjectTypeQuery15 = 14,
    ObjectTypeQuery16 = 15,
    ObjectTypeQuery17 = 16,
    ObjectTypeQuery18 = 17,
    ObjectTypeQuery19 = 18,
    ObjectTypeQuery20 = 19,
    ObjectTypeQuery21 = 20,
    ObjectTypeQuery22 = 21,
    ObjectTypeQuery23 = 22,
    ObjectTypeQuery24 = 23,
    ObjectTypeQuery25 = 24,
    ObjectTypeQuery26 = 25,
    ObjectTypeQuery27 = 26,
    ObjectTypeQuery28 = 27,
    ObjectTypeQuery29 = 28,
    ObjectTypeQuery30 = 29,
    ObjectTypeQuery31 = 30,
    ObjectTypeQuery32 = 31,
    ObjectTypeQuery_MAX = 32,
    EObjectTypeQuery_MAX = 33
};

enum class EDrawDebugTrace : uint8_t
{
    None = 0,
    ForOneFrame = 1,
    ForDuration = 2,
    Persistent = 3,
    EDrawDebugTrace_MAX = 4
};

enum class ETraceTypeQuery : uint8_t
{
    TraceTypeQuery1 = 0,
    TraceTypeQuery2 = 1,
    TraceTypeQuery3 = 2,
    TraceTypeQuery4 = 3,
    TraceTypeQuery5 = 4,
    TraceTypeQuery6 = 5,
    TraceTypeQuery7 = 6,
    TraceTypeQuery8 = 7,
    TraceTypeQuery9 = 8,
    TraceTypeQuery10 = 9,
    TraceTypeQuery11 = 10,
    TraceTypeQuery12 = 11,
    TraceTypeQuery13 = 12,
    TraceTypeQuery14 = 13,
    TraceTypeQuery15 = 14,
    TraceTypeQuery16 = 15,
    TraceTypeQuery17 = 16,
    TraceTypeQuery18 = 17,
    TraceTypeQuery19 = 18,
    TraceTypeQuery20 = 19,
    TraceTypeQuery21 = 20,
    TraceTypeQuery22 = 21,
    TraceTypeQuery23 = 22,
    TraceTypeQuery24 = 23,
    TraceTypeQuery25 = 24,
    TraceTypeQuery26 = 25,
    TraceTypeQuery27 = 26,
    TraceTypeQuery28 = 27,
    TraceTypeQuery29 = 28,
    TraceTypeQuery30 = 29,
    TraceTypeQuery31 = 30,
    TraceTypeQuery32 = 31,
    TraceTypeQuery_MAX = 32,
    ETraceTypeQuery_MAX = 33
};struct FLatentActionInfo
{
	public:
	    int Linkage; // 0x0 Size: 0x4
	    int UUID; // 0x4 Size: 0x4
	    FName ExecutionFunction; // 0x8 Size: 0x8
	    class UObject* CallbackTarget; // 0x10 Size: 0x8

};

struct FTimerHandle
{
	public:
	    uint64_t Handle; // 0x0 Size: 0x8

};



enum class EMoveComponentAction : uint8_t
{
    Move = 0,
    Stop = 1,
    Return = 2,
    EMoveComponentAction_MAX = 3
};

enum class EQuitPreference : uint8_t
{
    Quit = 0,
    Background = 1,
    EQuitPreference_MAX = 2
};struct FCollisionProfileName
{
	public:
	    FName Name; // 0x0 Size: 0x8

};

struct FGenericStruct
{
	public:
	    int Data; // 0x0 Size: 0x4

};

struct FUserActivity
{
	public:
	    struct FString ActionName; // 0x0 Size: 0x10
	    char UnknownData0[0x8];

};

struct FOnMatineeEvent__DelegateSignature
{
	public:

};

struct FParticleSpawnSignature__DelegateSignature
{
	public:
	    FName EventName; // 0x0 Size: 0x8
	    float EmitterTime; // 0x8 Size: 0x4
	    struct FVector Location; // 0xc Size: 0xc
	    struct FVector Velocity; // 0x18 Size: 0xc

};

struct FParticleBurstSignature__DelegateSignature
{
	public:
	    FName EventName; // 0x0 Size: 0x8
	    float EmitterTime; // 0x8 Size: 0x4
	    int ParticleCount; // 0xc Size: 0x4

};

struct FParticleDeathSignature__DelegateSignature
{
	public:
	    FName EventName; // 0x0 Size: 0x8
	    float EmitterTime; // 0x8 Size: 0x4
	    int ParticleTime; // 0xc Size: 0x4
	    struct FVector Location; // 0x10 Size: 0xc
	    struct FVector Velocity; // 0x1c Size: 0xc
	    struct FVector Direction; // 0x28 Size: 0xc

};

struct FParticleCollisionSignature__DelegateSignature
{
	public:
	    FName EventName; // 0x0 Size: 0x8
	    float EmitterTime; // 0x8 Size: 0x4
	    int ParticleTime; // 0xc Size: 0x4
	    struct FVector Location; // 0x10 Size: 0xc
	    struct FVector Velocity; // 0x1c Size: 0xc
	    struct FVector Direction; // 0x28 Size: 0xc
	    struct FVector Normal; // 0x34 Size: 0xc
	    FName BoneName; // 0x40 Size: 0x8
	    class UPhysicalMaterial* PhysMat; // 0x48 Size: 0x8

};

struct FOnSystemFinished__DelegateSignature
{
	public:
	    class UParticleSystemComponent* PSystem; // 0x0 Size: 0x8

};

struct FEmptyOnlineDelegate__DelegateSignature
{
	public:

};

struct FOnPrimaryAssetLoaded__DelegateSignature
{
	public:
	    class UObject* Loaded; // 0x0 Size: 0x8

};

struct FOnPrimaryAssetClassLoaded__DelegateSignature
{
	public:
	    class UObject* Loaded; // 0x0 Size: 0x8

};

struct FOnPrimaryAssetBundlesChanged__DelegateSignature
{
	public:

};



enum class EMouseLockMode : uint8_t
{
    DoNotLock = 0,
    LockOnCapture = 1,
    LockAlways = 2,
    LockInFullscreen = 3,
    EMouseLockMode_MAX = 4
};

enum class EWindowTitleBarMode : uint8_t
{
    Overlay = 0,
    VerticalBox = 1,
    EWindowTitleBarMode_MAX = 2
};struct FDataTableRowHandle
{
	public:
	    class UDataTable* DataTable; // 0x0 Size: 0x8
	    FName RowName; // 0x8 Size: 0x8

};



enum class ERoundingMode : uint8_t
{
    HalfToEven = 0,
    HalfFromZero = 1,
    HalfToZero = 2,
    FromZero = 3,
    ToZero = 4,
    ToNegativeInfinity = 5,
    ToPositiveInfinity = 6,
    ERoundingMode_MAX = 7
};

enum class EInputEvent : uint8_t
{
    IE_Pressed = 0,
    IE_Released = 1,
    IE_Repeat = 2,
    IE_DoubleClick = 3,
    IE_Axis = 4,
    IE_MAX = 5
};struct FFastArraySerializerItem
{
	public:
	    int ReplicationID; // 0x0 Size: 0x4
	    int ReplicationKey; // 0x4 Size: 0x4
	    int MostRecentArrayReplicationKey; // 0x8 Size: 0x4

};

struct FCurveTableRowHandle
{
	public:
	    class UCurveTable* CurveTable; // 0x0 Size: 0x8
	    FName RowName; // 0x8 Size: 0x8

};

struct FVector_NetQuantize10 : public FVector
{
	public:
	    char UnknownData0[0xc];

};

struct FVector_NetQuantize100 : public FVector
{
	public:
	    char UnknownData0[0xc];

};

struct FFastArraySerializer
{
	public:
	    char UnknownData0[0xb0];

};



enum class EPhysicalSurface : uint8_t
{
    SurfaceType_Default = 0,
    SurfaceType1 = 1,
    SurfaceType2 = 2,
    SurfaceType3 = 3,
    SurfaceType4 = 4,
    SurfaceType5 = 5,
    SurfaceType6 = 6,
    SurfaceType7 = 7,
    SurfaceType8 = 8,
    SurfaceType9 = 9,
    SurfaceType10 = 10,
    SurfaceType11 = 11,
    SurfaceType12 = 12,
    SurfaceType13 = 13,
    SurfaceType14 = 14,
    SurfaceType15 = 15,
    SurfaceType16 = 16,
    SurfaceType17 = 17,
    SurfaceType18 = 18,
    SurfaceType19 = 19,
    SurfaceType20 = 20,
    SurfaceType21 = 21,
    SurfaceType22 = 22,
    SurfaceType23 = 23,
    SurfaceType24 = 24,
    SurfaceType25 = 25,
    SurfaceType26 = 26,
    SurfaceType27 = 27,
    SurfaceType28 = 28,
    SurfaceType29 = 29,
    SurfaceType30 = 30,
    SurfaceType31 = 31,
    SurfaceType32 = 32,
    SurfaceType33 = 33,
    SurfaceType34 = 34,
    SurfaceType35 = 35,
    SurfaceType36 = 36,
    SurfaceType37 = 37,
    SurfaceType38 = 38,
    SurfaceType39 = 39,
    SurfaceType40 = 40,
    SurfaceType41 = 41,
    SurfaceType42 = 42,
    SurfaceType43 = 43,
    SurfaceType44 = 44,
    SurfaceType45 = 45,
    SurfaceType46 = 46,
    SurfaceType47 = 47,
    SurfaceType48 = 48,
    SurfaceType49 = 49,
    SurfaceType50 = 50,
    SurfaceType51 = 51,
    SurfaceType52 = 52,
    SurfaceType53 = 53,
    SurfaceType54 = 54,
    SurfaceType55 = 55,
    SurfaceType56 = 56,
    SurfaceType57 = 57,
    SurfaceType58 = 58,
    SurfaceType59 = 59,
    SurfaceType60 = 60,
    SurfaceType61 = 61,
    SurfaceType62 = 62,
    SurfaceType_Max = 63,
    EPhysicalSurface_MAX = 64
};

enum class ENetRole : uint8_t
{
    ROLE_None = 0,
    ROLE_SimulatedProxy = 1,
    ROLE_AutonomousProxy = 2,
    ROLE_Authority = 3,
    ROLE_MAX = 4
};

enum class EAttachLocation : uint8_t
{
    KeepRelativeOffset = 0,
    KeepWorldPosition = 1,
    SnapToTarget = 2,
    SnapToTargetIncludingScale = 3,
    EAttachLocation_MAX = 4
};

enum class EAttachmentRule : uint8_t
{
    KeepRelative = 0,
    KeepWorld = 1,
    SnapToTarget = 2,
    EAttachmentRule_MAX = 3
};

enum class EDetachmentRule : uint8_t
{
    KeepRelative = 0,
    KeepWorld = 1,
    EDetachmentRule_MAX = 2
};

enum class ENetDormancy : uint8_t
{
    DORM_Never = 0,
    DORM_Awake = 1,
    DORM_DormantAll = 2,
    DORM_DormantPartial = 3,
    DORM_Initial = 4,
    DORM_MAX = 5
};

enum class EAutoReceiveInput : uint8_t
{
    Disabled = 0,
    Player0 = 1,
    Player1 = 2,
    Player2 = 3,
    Player3 = 4,
    Player4 = 5,
    Player5 = 6,
    Player6 = 7,
    Player7 = 8,
    EAutoReceiveInput_MAX = 9
};

enum class ESpawnActorCollisionHandlingMethod : uint8_t
{
    Undefined = 0,
    AlwaysSpawn = 1,
    AdjustIfPossibleButAlwaysSpawn = 2,
    AdjustIfPossibleButDontSpawnIfColliding = 3,
    DontSpawnIfColliding = 4,
    ESpawnActorCollisionHandlingMethod_MAX = 5
};struct FRepAttachment
{
	public:
	    class AActor* AttachParent; // 0x0 Size: 0x8
	    struct FVector_NetQuantize100 LocationOffset; // 0x8 Size: 0xc
	    struct FVector_NetQuantize100 RelativeScale3D; // 0x14 Size: 0xc
	    struct FRotator RotationOffset; // 0x20 Size: 0xc
	    FName AttachSocket; // 0x2c Size: 0x8
	    char UnknownData0[0x4]; // 0x34
	    class USceneComponent* AttachComponent; // 0x38 Size: 0x8

};



enum class ERotatorQuantization : uint8_t
{
    ByteComponents = 0,
    ShortComponents = 1,
    ERotatorQuantization_MAX = 2
};

enum class EVectorQuantization : uint8_t
{
    RoundWholeNumber = 0,
    RoundOneDecimal = 1,
    RoundTwoDecimals = 2,
    EVectorQuantization_MAX = 3
};struct FRepMovement
{
	public:
	    struct FVector LinearVelocity; // 0x0 Size: 0xc
	    struct FVector AngularVelocity; // 0xc Size: 0xc
	    struct FVector Location; // 0x18 Size: 0xc
	    struct FRotator Rotation; // 0x24 Size: 0xc
	    bool bSimulatedPhysicSleep; // 0x30 Size: 0x1
	    bool bRepPhysics; // 0x30 Size: 0x1
	    Yea, we fucked up; // 0x0
	    EVectorQuantization LocationQuantizationLevel; // 0x31 Size: 0x1
	    EVectorQuantization VelocityQuantizationLevel; // 0x32 Size: 0x1
	    ERotatorQuantization RotationQuantizationLevel; // 0x33 Size: 0x1

};

struct FActorTickFunction : public FTickFunction
{
	public:
	    char UnknownData0[0x58];

};



enum class ECameraAnimPlaySpace : uint8_t
{
    CameraLocal = 0,
    World = 1,
    UserDefined = 2,
    ECameraAnimPlaySpace_MAX = 3
};struct FViewTargetTransitionParams
{
	public:
	    float BlendTime; // 0x0 Size: 0x4
	    char BlendFunction; // 0x4 Size: 0x1
	    char UnknownData0[0x3]; // 0x5
	    float BlendExp; // 0x8 Size: 0x4
	    bool bLockOutgoing; // 0xc Size: 0x1
	    char UnknownData1[0x3];

};



enum class EViewTargetBlendFunction : uint8_t
{
    VTBlend_Linear = 0,
    VTBlend_Cubic = 1,
    VTBlend_EaseIn = 2,
    VTBlend_EaseOut = 3,
    VTBlend_EaseInOut = 4,
    VTBlend_MAX = 5
};

enum class ETravelType : uint8_t
{
    TRAVEL_Absolute = 0,
    TRAVEL_Partial = 1,
    TRAVEL_Relative = 2,
    TRAVEL_MAX = 3
};struct FUpdateLevelStreamingLevelStatus
{
	public:
	    FName PackageName; // 0x0 Size: 0x8
	    int LODIndex; // 0x8 Size: 0x4
	    bool bNewShouldBeLoaded; // 0xc Size: 0x1
	    bool bNewShouldBeVisible; // 0xc Size: 0x1
	    bool bNewShouldBlockOnLoad; // 0xc Size: 0x1
	    char UnknownData0[0x1];

};



enum class ECollisionChannel : uint8_t
{
    ECC_WorldStatic = 0,
    ECC_WorldDynamic = 1,
    ECC_Pawn = 2,
    ECC_Visibility = 3,
    ECC_Camera = 4,
    ECC_PhysicsBody = 5,
    ECC_Vehicle = 6,
    ECC_Destructible = 7,
    ECC_EngineTraceChannel1 = 8,
    ECC_EngineTraceChannel2 = 9,
    ECC_EngineTraceChannel3 = 10,
    ECC_EngineTraceChannel4 = 11,
    ECC_EngineTraceChannel5 = 12,
    ECC_EngineTraceChannel6 = 13,
    ECC_GameTraceChannel1 = 14,
    ECC_GameTraceChannel2 = 15,
    ECC_GameTraceChannel3 = 16,
    ECC_GameTraceChannel4 = 17,
    ECC_GameTraceChannel5 = 18,
    ECC_GameTraceChannel6 = 19,
    ECC_GameTraceChannel7 = 20,
    ECC_GameTraceChannel8 = 21,
    ECC_GameTraceChannel9 = 22,
    ECC_GameTraceChannel10 = 23,
    ECC_GameTraceChannel11 = 24,
    ECC_GameTraceChannel12 = 25,
    ECC_GameTraceChannel13 = 26,
    ECC_GameTraceChannel14 = 27,
    ECC_GameTraceChannel15 = 28,
    ECC_GameTraceChannel16 = 29,
    ECC_GameTraceChannel17 = 30,
    ECC_GameTraceChannel18 = 31,
    ECC_OverlapAll_Deprecated = 32,
    ECC_MAX = 33
};

enum class EControllerAnalogStick : uint8_t
{
    CAS_LeftStick = 0,
    CAS_RightStick = 1,
    CAS_MAX = 2
};

enum class EDynamicForceFeedbackAction : uint8_t
{
    Start = 0,
    Update = 1,
    Stop = 2,
    EDynamicForceFeedbackAction_MAX = 3
};struct FUpdateLevelVisibilityLevelInfo
{
	public:
	    FName PackageName; // 0x0 Size: 0x8
	    bool bIsVisible; // 0x8 Size: 0x1
	    char UnknownData0[0x3];

};

struct FActiveForceFeedbackEffect
{
	public:
	    class UForceFeedbackEffect* ForceFeedbackEffect; // 0x0 Size: 0x8
	    char UnknownData0[0x10];

};



enum class EAlphaBlendOption : uint8_t
{
    Linear = 0,
    Cubic = 1,
    HermiteCubic = 2,
    Sinusoidal = 3,
    QuadraticInOut = 4,
    CubicInOut = 5,
    QuarticInOut = 6,
    QuinticInOut = 7,
    CircularIn = 8,
    CircularOut = 9,
    CircularInOut = 10,
    ExpIn = 11,
    ExpOut = 12,
    ExpInOut = 13,
    Custom = 14,
    EAlphaBlendOption_MAX = 15
};

enum class EAnimGroupRole : uint8_t
{
    CanBeLeader = 0,
    AlwaysFollower = 1,
    AlwaysLeader = 2,
    TransitionLeader = 3,
    TransitionFollower = 4,
    EAnimGroupRole_MAX = 5
};

enum class ERawCurveTrackTypes : uint8_t
{
    RCT_Float = 0,
    RCT_Vector = 1,
    RCT_Transform = 2,
    RCT_MAX = 3
};

enum class EAnimAssetCurveFlags : uint8_t
{
    AACF_DriveMorphTarget_DEPRECATED = 1,
    AACF_DriveAttribute_DEPRECATED = 2,
    AACF_Editable = 4,
    AACF_DriveMaterial_DEPRECATED = 8,
    AACF_Metadata = 16,
    AACF_DriveTrack = 32,
    AACF_Disabled = 64,
    AACF_MAX = 65
};

enum class AnimationCompressionFormat : uint8_t
{
    ACF_None = 0,
    ACF_Float96NoW = 1,
    ACF_Fixed48NoW = 2,
    ACF_IntervalFixed32NoW = 3,
    ACF_Fixed32NoW = 4,
    ACF_Float32NoW = 5,
    ACF_Identity = 6,
    ACF_MAX = 7
};

enum class EAdditiveBasePoseType : uint8_t
{
    ABPT_None = 0,
    ABPT_RefPose = 1,
    ABPT_AnimScaled = 2,
    ABPT_AnimFrame = 3,
    ABPT_MAX = 4
};

enum class ERootMotionMode : uint8_t
{
    NoRootMotionExtraction = 0,
    IgnoreRootMotion = 1,
    RootMotionFromEverything = 2,
    RootMotionFromMontagesOnly = 3,
    ERootMotionMode_MAX = 4
};

enum class ERootMotionRootLock : uint8_t
{
    RefPose = 0,
    AnimFirstFrame = 1,
    Zero = 2,
    ERootMotionRootLock_MAX = 3
};

enum class EMontagePlayReturnType : uint8_t
{
    MontageLength = 0,
    Duration = 1,
    EMontagePlayReturnType_MAX = 2
};

enum class EDrawDebugItemType : uint8_t
{
    DirectionalArrow = 0,
    Sphere = 1,
    Line = 2,
    OnScreenMessage = 3,
    CoordinateSystem = 4,
    EDrawDebugItemType_MAX = 5
};

enum class EAnimLinkMethod : uint8_t
{
    Absolute = 0,
    Relative = 1,
    Proportional = 2,
    EAnimLinkMethod_MAX = 3
};

enum class EMontageSubStepResult : uint8_t
{
    Moved = 0,
    NotMoved = 1,
    InvalidSection = 2,
    InvalidMontage = 3,
    EMontageSubStepResult_MAX = 4
};

enum class EAnimNotifyEventType : uint8_t
{
    Begin = 0,
    End = 1,
    EAnimNotifyEventType_MAX = 2
};

enum class EEvaluatorMode : uint8_t
{
    EM_Standard = 0,
    EM_Freeze = 1,
    EM_DelayedFreeze = 2,
    EM_MAX = 3
};

enum class EEvaluatorDataSource : uint8_t
{
    EDS_SourcePose = 0,
    EDS_DestinationPose = 1,
    EDS_MAX = 2
};

enum class ECopyType : uint8_t
{
    MemCopy = 0,
    BoolProperty = 1,
    StructProperty = 2,
    ObjectProperty = 3,
    ECopyType_MAX = 4
};

enum class EPostCopyOperation : uint8_t
{
    None = 0,
    LogicalNegateBool = 1,
    EPostCopyOperation_MAX = 2
};

enum class EPinHidingMode : uint8_t
{
    NeverAsPin = 0,
    PinHiddenByDefault = 1,
    PinShownByDefault = 2,
    AlwaysAsPin = 3,
    EPinHidingMode_MAX = 4
};

enum class AnimPhysCollisionType : uint8_t
{
    CoM = 0,
    CustomSphere = 1,
    InnerSphere = 2,
    OuterSphere = 3,
    AnimPhysCollisionType_MAX = 4
};

enum class AnimPhysTwistAxis : uint8_t
{
    AxisX = 0,
    AxisY = 1,
    AxisZ = 2,
    AnimPhysTwistAxis_MAX = 3
};

enum class AnimationKeyFormat : uint8_t
{
    AKF_ConstantKeyLerp = 0,
    AKF_VariableKeyLerp = 1,
    AKF_PerTrackCompression = 2,
    AKF_MAX = 3
};

enum class ETypeAdvanceAnim : uint8_t
{
    ETAA_Default = 0,
    ETAA_Finished = 1,
    ETAA_Looped = 2,
    ETAA_MAX = 3
};

enum class ETransitionLogicType : uint8_t
{
    TLT_StandardBlend = 0,
    TLT_Custom = 1,
    TLT_MAX = 2
};

enum class ETransitionBlendMode : uint8_t
{
    TBM_Linear = 0,
    TBM_Cubic = 1,
    TBM_MAX = 2
};

enum class EComponentType : uint8_t
{
    None = 0,
    TranslationX = 1,
    TranslationY = 2,
    TranslationZ = 3,
    RotationX = 4,
    RotationY = 5,
    RotationZ = 6,
    Scale = 7,
    ScaleX = 8,
    ScaleY = 9,
    ScaleZ = 10,
    EComponentType_MAX = 11
};

enum class EAxisOption : uint8_t
{
    X = 0,
    Y = 1,
    Z = 2,
    X_Neg = 3,
    Y_Neg = 4,
    Z_Neg = 5,
    Custom = 6,
    EAxisOption_MAX = 7
};

enum class EAnimInterpolationType : uint8_t
{
    Linear = 0,
    Step = 1,
    EAnimInterpolationType_MAX = 2
};

enum class ECurveBlendOption : uint8_t
{
    MaxWeight = 0,
    NormalizeByWeight = 1,
    BlendByWeight = 2,
    ECurveBlendOption_MAX = 3
};

enum class EAdditiveAnimationType : uint8_t
{
    AAT_None = 0,
    AAT_LocalSpaceBase = 1,
    AAT_RotationOffsetMeshSpace = 2,
    AAT_MAX = 3
};

enum class ENotifyFilterType : uint8_t
{
    NoFiltering = 0,
    LOD = 1,
    ENotifyFilterType_MAX = 2
};

enum class EMontageNotifyTickType : uint8_t
{
    Queued = 0,
    BranchingPoint = 1,
    EMontageNotifyTickType_MAX = 2
};

enum class EBoneRotationSource : uint8_t
{
    BRS_KeepComponentSpaceRotation = 0,
    BRS_KeepLocalSpaceRotation = 1,
    BRS_CopyFromTarget = 2,
    BRS_MAX = 3
};

enum class EBoneControlSpace : uint8_t
{
    BCS_WorldSpace = 0,
    BCS_ComponentSpace = 1,
    BCS_ParentBoneSpace = 2,
    BCS_BoneSpace = 3,
    BCS_MAX = 4
};

enum class EBoneAxis : uint8_t
{
    BA_X = 0,
    BA_Y = 1,
    BA_Z = 2,
    BA_MAX = 3
};

enum class EPrimaryAssetCookRule : uint8_t
{
    Unknown = 0,
    NeverCook = 1,
    DevelopmentCook = 2,
    DevelopmentAlwaysCook = 3,
    AlwaysCook = 4,
    EPrimaryAssetCookRule_MAX = 5
};

enum class EAttenuationShape : uint8_t
{
    Sphere = 0,
    Capsule = 1,
    Box = 2,
    Cone = 3,
    EAttenuationShape_MAX = 4
};

enum class EAttenuationDistanceModel : uint8_t
{
    Linear = 0,
    Logarithmic = 1,
    Inverse = 2,
    LogReverse = 3,
    NaturalSound = 4,
    Custom = 5,
    EAttenuationDistanceModel_MAX = 6
};

enum class EMonoChannelUpmixMethod : uint8_t
{
    Linear = 0,
    EqualPower = 1,
    FullVolume = 2,
    EMonoChannelUpmixMethod_MAX = 3
};

enum class EPanningMethod : uint8_t
{
    Linear = 0,
    EqualPower = 1,
    EPanningMethod_MAX = 2
};

enum class EVoiceSampleRate : uint8_t
{
    Low16000Hz = 16000,
    Normal24000Hz = 24000,
    EVoiceSampleRate_MAX = 24001
};

enum class ReverbPreset : uint8_t
{
    REVERB_Default = 0,
    REVERB_Bathroom = 1,
    REVERB_StoneRoom = 2,
    REVERB_Auditorium = 3,
    REVERB_ConcertHall = 4,
    REVERB_Cave = 5,
    REVERB_Hallway = 6,
    REVERB_StoneCorridor = 7,
    REVERB_Alley = 8,
    REVERB_Forest = 9,
    REVERB_City = 10,
    REVERB_Mountains = 11,
    REVERB_Quarry = 12,
    REVERB_Plain = 13,
    REVERB_ParkingLot = 14,
    REVERB_SewerPipe = 15,
    REVERB_Underwater = 16,
    REVERB_SmallRoom = 17,
    REVERB_MediumRoom = 18,
    REVERB_LargeRoom = 19,
    REVERB_MediumHall = 20,
    REVERB_LargeHall = 21,
    REVERB_Plate = 22,
    REVERB_MAX = 23
};

enum class EBlendableLocation : uint8_t
{
    BL_AfterTonemapping = 0,
    BL_BeforeTonemapping = 1,
    BL_BeforeTranslucency = 2,
    BL_ReplacingTonemapper = 3,
    BL_SSRInput = 4,
    BL_MAX = 5
};

enum class ENotifyTriggerMode : uint8_t
{
    AllAnimations = 0,
    HighestWeightedAnimation = 1,
    None = 2,
    ENotifyTriggerMode_MAX = 3
};

enum class EBlendSpaceAxis : uint8_t
{
    BSA_None = 0,
    BSA_X = 1,
    BSA_Y = 2,
    BSA_Max = 3
};

enum class EBlueprintNativizationFlag : uint8_t
{
    Disabled = 0,
    Dependency = 1,
    ExplicitlyEnabled = 2,
    EBlueprintNativizationFlag_MAX = 3
};

enum class EBlueprintCompileMode : uint8_t
{
    Default = 0,
    Development = 1,
    FinalRelease = 2,
    EBlueprintCompileMode_MAX = 3
};

enum class EBlueprintType : uint8_t
{
    BPTYPE_Normal = 0,
    BPTYPE_Const = 1,
    BPTYPE_MacroLibrary = 2,
    BPTYPE_Interface = 3,
    BPTYPE_LevelScript = 4,
    BPTYPE_FunctionLibrary = 5,
    BPTYPE_MAX = 6
};

enum class EBlueprintStatus : uint8_t
{
    BS_Unknown = 0,
    BS_Dirty = 1,
    BS_Error = 2,
    BS_UpToDate = 3,
    BS_BeingCreated = 4,
    BS_UpToDateWithWarnings = 5,
    BS_MAX = 6
};

enum class EDynamicActorScene : uint8_t
{
    Default = 0,
    UseSyncScene = 1,
    UseAsyncScene = 2,
    EDynamicActorScene_MAX = 3
};

enum class EDOFMode : uint8_t
{
    Default = 0,
    SixDOF = 1,
    YZPlane = 2,
    XZPlane = 3,
    XYPlane = 4,
    CustomPlane = 5,
    None = 6,
    EDOFMode_MAX = 7
};

enum class EBodyCollisionResponse : uint8_t
{
    BodyCollision_Enabled = 0,
    BodyCollision_Disabled = 1,
    BodyCollision_MAX = 2
};

enum class EPhysicsType : uint8_t
{
    PhysType_Default = 0,
    PhysType_Kinematic = 1,
    PhysType_Simulated = 2,
    PhysType_MAX = 3
};

enum class ECollisionTraceFlag : uint8_t
{
    CTF_UseDefault = 0,
    CTF_UseSimpleAndComplex = 1,
    CTF_UseSimpleAsComplex = 2,
    CTF_UseComplexAsSimple = 3,
    CTF_MAX = 4
};

enum class EBrushType : uint8_t
{
    Brush_Default = 0,
    Brush_Add = 1,
    Brush_Subtract = 2,
    Brush_MAX = 3
};

enum class ECsgOper : uint8_t
{
    CSG_Active = 0,
    CSG_Add = 1,
    CSG_Subtract = 2,
    CSG_Intersect = 3,
    CSG_Deintersect = 4,
    CSG_None = 5,
    CSG_MAX = 6
};

enum class EInitialOscillatorOffset : uint8_t
{
    EOO_OffsetRandom = 0,
    EOO_OffsetZero = 1,
    EOO_MAX = 2
};

enum class EOscillatorWaveform : uint8_t
{
    SineWave = 0,
    PerlinNoise = 1,
    EOscillatorWaveform_MAX = 2
};

enum class ECameraAlphaBlendMode : uint8_t
{
    CABM_Linear = 0,
    CABM_Cubic = 1,
    CABM_MAX = 2
};

enum class ECameraProjectionMode : uint8_t
{
    Perspective = 0,
    Orthographic = 1,
    ECameraProjectionMode_MAX = 2
};

enum class ECloudStorageDelegate : uint8_t
{
    CSD_KeyValueReadComplete = 0,
    CSD_KeyValueWriteComplete = 1,
    CSD_ValueChanged = 2,
    CSD_DocumentQueryComplete = 3,
    CSD_DocumentReadComplete = 4,
    CSD_DocumentWriteComplete = 5,
    CSD_DocumentConflictDetected = 6,
    CSD_MAX = 7
};

enum class EAngularDriveMode : uint8_t
{
    SLERP = 0,
    TwistAndSwing = 1,
    EAngularDriveMode_MAX = 2
};

enum class ELinearConstraintMotion : uint8_t
{
    LCM_Free = 0,
    LCM_Limited = 1,
    LCM_Locked = 2,
    LCM_MAX = 3
};

enum class ECurveTableMode : uint8_t
{
    Empty = 0,
    SimpleCurves = 1,
    RichCurves = 2,
    ECurveTableMode_MAX = 3
};

enum class EEvaluateCurveTableResult : uint8_t
{
    RowFound = 0,
    RowNotFound = 1,
    EEvaluateCurveTableResult_MAX = 2
};

enum class EGrammaticalNumber : uint8_t
{
    Singular = 0,
    Plural = 1,
    EGrammaticalNumber_MAX = 2
};

enum class EGrammaticalGender : uint8_t
{
    Neuter = 0,
    Masculine = 1,
    Feminine = 2,
    Mixed = 3,
    EGrammaticalGender_MAX = 4
};

enum class DistributionParamMode : uint8_t
{
    DPM_Normal = 0,
    DPM_Abs = 1,
    DPM_Direct = 2,
    DPM_MAX = 3
};

enum class EDistributionVectorMirrorFlags : uint8_t
{
    EDVMF_Same = 0,
    EDVMF_Different = 1,
    EDVMF_Mirror = 2,
    EDVMF_MAX = 3
};

enum class EDistributionVectorLockFlags : uint8_t
{
    EDVLF_None = 0,
    EDVLF_XY = 1,
    EDVLF_XZ = 2,
    EDVLF_YZ = 3,
    EDVLF_XYZ = 4,
    EDVLF_MAX = 5
};

enum class ENodeEnabledState : uint8_t
{
    Enabled = 0,
    Disabled = 1,
    DevelopmentOnly = 2,
    ENodeEnabledState_MAX = 3
};

enum class ENodeAdvancedPins : uint8_t
{
    NoPins = 0,
    Shown = 1,
    Hidden = 2,
    ENodeAdvancedPins_MAX = 3
};

enum class ENodeTitleType : uint8_t
{
    FullTitle = 0,
    ListView = 1,
    EditableTitle = 2,
    MenuTitle = 3,
    MAX_TitleTypes = 4,
    ENodeTitleType_MAX = 5
};

enum class EPinContainerType : uint8_t
{
    None = 0,
    Array = 1,
    Set = 2,
    Map = 3,
    EPinContainerType_MAX = 4
};

enum class EEdGraphPinDirection : uint8_t
{
    EGPD_Input = 0,
    EGPD_Output = 1,
    EGPD_MAX = 2
};

enum class EBlueprintPinStyleType : uint8_t
{
    BPST_Original = 0,
    BPST_VariantA = 1,
    BPST_MAX = 2
};

enum class ECanCreateConnectionResponse : uint8_t
{
    CONNECT_RESPONSE_MAKE = 0,
    CONNECT_RESPONSE_DISALLOW = 1,
    CONNECT_RESPONSE_BREAK_OTHERS_A = 2,
    CONNECT_RESPONSE_BREAK_OTHERS_B = 3,
    CONNECT_RESPONSE_BREAK_OTHERS_AB = 4,
    CONNECT_RESPONSE_MAKE_WITH_CONVERSION_NODE = 5,
    CONNECT_RESPONSE_MAX = 6
};

enum class EGraphType : uint8_t
{
    GT_Function = 0,
    GT_Ubergraph = 1,
    GT_Macro = 2,
    GT_Animation = 3,
    GT_StateMachine = 4,
    GT_MAX = 5
};

enum class EConsoleType : uint8_t
{
    CONSOLE_Any = 0,
    CONSOLE_Mobile = 1,
    CONSOLE_MAX = 2
};

enum class ETransitionType : uint8_t
{
    TT_None = 0,
    TT_Paused = 1,
    TT_Loading = 2,
    TT_Saving = 3,
    TT_Connecting = 4,
    TT_Precaching = 5,
    TT_WaitingToConnect = 6,
    TT_MAX = 7
};

enum class EFullyLoadPackageType : uint8_t
{
    FULLYLOAD_Map = 0,
    FULLYLOAD_Game_PreLoadClass = 1,
    FULLYLOAD_Game_PostLoadClass = 2,
    FULLYLOAD_Always = 3,
    FULLYLOAD_Mutator = 4,
    FULLYLOAD_MAX = 5
};

enum class EViewModeIndex : uint8_t
{
    VMI_BrushWireframe = 0,
    VMI_Wireframe = 1,
    VMI_Unlit = 2,
    VMI_Lit = 3,
    VMI_Lit_DetailLighting = 4,
    VMI_LightingOnly = 5,
    VMI_LightComplexity = 6,
    VMI_ShaderComplexity = 8,
    VMI_LightmapDensity = 9,
    VMI_LitLightmapDensity = 10,
    VMI_ReflectionOverride = 11,
    VMI_VisualizeBuffer = 12,
    VMI_StationaryLightOverlap = 14,
    VMI_CollisionPawn = 15,
    VMI_CollisionVisibility = 16,
    VMI_LODColoration = 18,
    VMI_QuadOverdraw = 19,
    VMI_PrimitiveDistanceAccuracy = 20,
    VMI_MeshUVDensityAccuracy = 21,
    VMI_ShaderComplexityWithQuadOverdraw = 22,
    VMI_HLODColoration = 23,
    VMI_GroupLODColoration = 24,
    VMI_MaterialTextureScaleAccuracy = 25,
    VMI_RequiredTextureResolution = 26,
    VMI_Max = 27,
    VMI_Unknown = 255
};

enum class EDemoPlayFailure : uint8_t
{
    Generic = 0,
    DemoNotFound = 1,
    Corrupt = 2,
    InvalidVersion = 3,
    InitBase = 4,
    GameSpecificHeader = 5,
    ReplayStreamerInternal = 6,
    LoadMap = 7,
    Serialization = 8,
    EDemoPlayFailure_MAX = 9
};

enum class ENetworkLagState : uint8_t
{
    NotLagging = 0,
    Lagging = 1,
    ENetworkLagState_MAX = 2
};

enum class EMouseCaptureMode : uint8_t
{
    NoCapture = 0,
    CapturePermanently = 1,
    CapturePermanently_IncludingInitialMouseDown = 2,
    CaptureDuringMouseDown = 3,
    CaptureDuringRightMouseDown = 4,
    EMouseCaptureMode_MAX = 5
};

enum class ECustomTimeStepSynchronizationState : uint8_t
{
    Closed = 0,
    Error = 1,
    Synchronized = 2,
    Synchronizing = 3,
    ECustomTimeStepSynchronizationState_MAX = 4
};

enum class EMeshBufferAccess : uint8_t
{
    Default = 0,
    ForceCPUAndGPU = 1,
    EMeshBufferAccess_MAX = 2
};

enum class EConstraintFrame : uint8_t
{
    Frame1 = 0,
    Frame2 = 1,
    EConstraintFrame_MAX = 2
};

enum class EAngularConstraintMotion : uint8_t
{
    ACM_Free = 0,
    ACM_Limited = 1,
    ACM_Locked = 2,
    ACM_MAX = 3
};

enum class EComponentSocketType : uint8_t
{
    Invalid = 0,
    Bone = 1,
    Socket = 2,
    EComponentSocketType_MAX = 3
};

enum class EComponentMobility : uint8_t
{
    Static = 0,
    Stationary = 1,
    Movable = 2,
    EComponentMobility_MAX = 3
};

enum class EWalkableSlopeBehavior : uint8_t
{
    WalkableSlope_Default = 0,
    WalkableSlope_Increase = 1,
    WalkableSlope_Decrease = 2,
    WalkableSlope_Unwalkable = 3,
    WalkableSlope_Max = 4
};

enum class EAutoPossessAI : uint8_t
{
    Disabled = 0,
    PlacedInWorld = 1,
    Spawned = 2,
    PlacedInWorldOrSpawned = 3,
    EAutoPossessAI_MAX = 4
};

enum class EUpdateRateShiftBucket : uint8_t
{
    ShiftBucket0 = 0,
    ShiftBucket1 = 1,
    ShiftBucket2 = 2,
    ShiftBucket3 = 3,
    ShiftBucket4 = 4,
    ShiftBucket5 = 5,
    ShiftBucketMax = 6,
    EUpdateRateShiftBucket_MAX = 7
};

enum class ETeleportType : uint8_t
{
    None = 0,
    TeleportPhysics = 1,
    ResetPhysics = 2,
    ETeleportType_MAX = 3
};

enum class EShadowMapFlags : uint8_t
{
    SMF_None = 0,
    SMF_Streamed = 1,
    SMF_MAX = 2
};

enum class ELightMapPaddingType : uint8_t
{
    LMPT_NormalPadding = 0,
    LMPT_PrePadding = 1,
    LMPT_NoPadding = 2,
    LMPT_MAX = 3
};

enum class ECollisionEnabled : uint8_t
{
    NoCollision = 0,
    QueryOnly = 1,
    PhysicsOnly = 2,
    QueryAndPhysics = 3,
    ECollisionEnabled_MAX = 4
};

enum class ETimelineSigType : uint8_t
{
    ETS_EventSignature = 0,
    ETS_FloatSignature = 1,
    ETS_VectorSignature = 2,
    ETS_LinearColorSignature = 3,
    ETS_InvalidSignature = 4,
    ETS_MAX = 5
};

enum class ESleepFamily : uint8_t
{
    Normal = 0,
    Sensitive = 1,
    Custom = 2,
    ESleepFamily_MAX = 3
};

enum class ERadialImpulseFalloff : uint8_t
{
    RIF_Constant = 0,
    RIF_Linear = 1,
    RIF_MAX = 2
};

enum class EInputConsumeOptions : uint8_t
{
    ICO_ConsumeAll = 0,
    ICO_ConsumeBoundKeys = 1,
    ICO_ConsumeNone = 2,
    ICO_MAX = 3
};

enum class EFilterInterpolationType : uint8_t
{
    BSIT_Average = 0,
    BSIT_Linear = 1,
    BSIT_Cubic = 2,
    BSIT_MAX = 3
};

enum class ECollisionResponse : uint8_t
{
    ECR_Ignore = 0,
    ECR_Overlap = 1,
    ECR_Block = 2,
    ECR_MAX = 3
};

enum class EPhysicsSceneType : uint8_t
{
    PST_Sync = 0,
    PST_Async = 1,
    PST_MAX = 2
};

enum class EOverlapFilterOption : uint8_t
{
    OverlapFilter_All = 0,
    OverlapFilter_DynamicOnly = 1,
    OverlapFilter_StaticOnly = 2,
    OverlapFilter_MAX = 3
};

enum class ENetworkSmoothingMode : uint8_t
{
    Disabled = 0,
    Linear = 1,
    Exponential = 2,
    Replay = 3,
    ENetworkSmoothingMode_MAX = 4
};

enum class ELightingBuildQuality : uint8_t
{
    Quality_Preview = 0,
    Quality_Medium = 1,
    Quality_High = 2,
    Quality_Production = 3,
    Quality_MAX = 4
};

enum class EMaterialSamplerType : uint8_t
{
    SAMPLERTYPE_Color = 0,
    SAMPLERTYPE_Grayscale = 1,
    SAMPLERTYPE_Alpha = 2,
    SAMPLERTYPE_Normal = 3,
    SAMPLERTYPE_Masks = 4,
    SAMPLERTYPE_DistanceFieldFont = 5,
    SAMPLERTYPE_LinearColor = 6,
    SAMPLERTYPE_LinearGrayscale = 7,
    SAMPLERTYPE_External = 8,
    SAMPLERTYPE_MAX = 9
};

enum class EMaterialTessellationMode : uint8_t
{
    MTM_NoTessellation = 0,
    MTM_FlatTessellation = 1,
    MTM_PNTriangles = 2,
    MTM_MAX = 3
};

enum class EMaterialShadingModel : uint8_t
{
    MSM_Unlit = 0,
    MSM_DefaultLit = 1,
    MSM_Subsurface = 2,
    MSM_PreintegratedSkin = 3,
    MSM_ClearCoat = 4,
    MSM_SubsurfaceProfile = 5,
    MSM_TwoSidedFoliage = 6,
    MSM_Hair = 7,
    MSM_Cloth = 8,
    MSM_Eye = 9,
    MSM_MAX = 10
};

enum class EParticleCollisionMode : uint8_t
{
    SceneDepth = 0,
    DistanceField = 1,
    EParticleCollisionMode_MAX = 2
};

enum class ETrailWidthMode : uint8_t
{
    ETrailWidthMode_FromCentre = 0,
    ETrailWidthMode_FromFirst = 1,
    ETrailWidthMode_FromSecond = 2,
    ETrailWidthMode_MAX = 3
};

enum class EGBufferFormat : uint8_t
{
    Force8BitsPerChannel = 0,
    Default = 1,
    HighPrecisionNormals = 3,
    Force16BitsPerChannel = 5,
    EGBufferFormat_MAX = 6
};

enum class ESceneCaptureCompositeMode : uint8_t
{
    SCCM_Overwrite = 0,
    SCCM_Additive = 1,
    SCCM_Composite = 2,
    SCCM_MAX = 3
};

enum class ESceneCaptureSource : uint8_t
{
    SCS_SceneColorHDR = 0,
    SCS_SceneColorHDRNoAlpha = 1,
    SCS_FinalColorLDR = 2,
    SCS_SceneColorSceneDepth = 3,
    SCS_SceneDepth = 4,
    SCS_DeviceDepth = 5,
    SCS_Normal = 6,
    SCS_BaseColor = 7,
    SCS_MAX = 8
};

enum class ETranslucentSortPolicy : uint8_t
{
    SortByDistance = 0,
    SortByProjectedZ = 1,
    SortAlongAxis = 2,
    ETranslucentSortPolicy_MAX = 3
};

enum class ERefractionMode : uint8_t
{
    RM_IndexOfRefraction = 0,
    RM_PixelNormalOffset = 1,
    RM_MAX = 2
};

enum class ETranslucencyLightingMode : uint8_t
{
    TLM_VolumetricNonDirectional = 0,
    TLM_VolumetricDirectional = 1,
    TLM_VolumetricPerVertexNonDirectional = 2,
    TLM_VolumetricPerVertexDirectional = 3,
    TLM_Surface = 4,
    TLM_SurfacePerPixelLighting = 5,
    TLM_MAX = 6
};

enum class ESamplerSourceMode : uint8_t
{
    SSM_FromTextureAsset = 0,
    SSM_Wrap_WorldGroupSettings = 1,
    SSM_Clamp_WorldGroupSettings = 2,
    SSM_MAX = 3
};

enum class EBlendMode : uint8_t
{
    BLEND_Opaque = 0,
    BLEND_Masked = 1,
    BLEND_Translucent = 2,
    BLEND_Additive = 3,
    BLEND_Modulate = 4,
    BLEND_AlphaComposite = 5,
    BLEND_MAX = 6
};

enum class EOcclusionCombineMode : uint8_t
{
    OCM_Minimum = 0,
    OCM_Multiply = 1,
    OCM_MAX = 2
};

enum class ELightmapType : uint8_t
{
    Default = 0,
    ForceSurface = 1,
    ForceVolumetric = 2,
    ELightmapType_MAX = 3
};

enum class EIndirectLightingCacheQuality : uint8_t
{
    ILCQ_Off = 0,
    ILCQ_Point = 1,
    ILCQ_Volume = 2,
    ILCQ_MAX = 3
};

enum class ESceneDepthPriorityGroup : uint8_t
{
    SDPG_World = 0,
    SDPG_Foreground = 1,
    SDPG_MAX = 2
};

enum class EActorMetricsType : uint8_t
{
    METRICS_VERTS = 0,
    METRICS_TRIS = 1,
    METRICS_SECTIONS = 2,
    METRICS_MAX = 3
};

enum class EAspectRatioAxisConstraint : uint8_t
{
    AspectRatio_MaintainYFOV = 0,
    AspectRatio_MaintainXFOV = 1,
    AspectRatio_MajorAxisFOV = 2,
    AspectRatio_MAX = 3
};

enum class EFontCacheType : uint8_t
{
    Offline = 0,
    Runtime = 1,
    EFontCacheType_MAX = 2
};

enum class EFontImportCharacterSet : uint8_t
{
    FontICS_Default = 0,
    FontICS_Ansi = 1,
    FontICS_Symbol = 2,
    FontICS_MAX = 3
};

enum class EStandbyType : uint8_t
{
    STDBY_Rx = 0,
    STDBY_Tx = 1,
    STDBY_BadPing = 2,
    STDBY_MAX = 3
};

enum class ESuggestProjVelocityTraceOption : uint8_t
{
    DoNotTrace = 0,
    TraceFullPath = 1,
    OnlyTraceWhileAscending = 2,
    ESuggestProjVelocityTraceOption_MAX = 3
};

enum class EWindowMode : uint8_t
{
    Fullscreen = 0,
    WindowedFullscreen = 1,
    Windowed = 2,
    EWindowMode_MAX = 3
};

enum class EImportanceWeight : uint8_t
{
    Luminance = 0,
    Red = 1,
    Green = 2,
    Blue = 3,
    Alpha = 4,
    EImportanceWeight_MAX = 5
};

enum class EAdManagerDelegate : uint8_t
{
    AMD_ClickedBanner = 0,
    AMD_UserClosedAd = 1,
    AMD_MAX = 2
};

enum class EAnimAlphaInputType : uint8_t
{
    Float = 0,
    Bool = 1,
    Curve = 2,
    EAnimAlphaInputType_MAX = 3
};

enum class ETrackActiveCondition : uint8_t
{
    ETAC_Always = 0,
    ETAC_GoreEnabled = 1,
    ETAC_GoreDisabled = 2,
    ETAC_MAX = 3
};

enum class EInterpTrackMoveRotMode : uint8_t
{
    IMR_Keyframed = 0,
    IMR_LookAtGroup = 1,
    IMR_Ignore = 2,
    IMR_MAX = 3
};

enum class EInterpMoveAxis : uint8_t
{
    AXIS_TranslationX = 0,
    AXIS_TranslationY = 1,
    AXIS_TranslationZ = 2,
    AXIS_RotationX = 3,
    AXIS_RotationY = 4,
    AXIS_RotationZ = 5,
    AXIS_MAX = 6
};

enum class ETrackToggleAction : uint8_t
{
    ETTA_Off = 0,
    ETTA_On = 1,
    ETTA_Toggle = 2,
    ETTA_Trigger = 3,
    ETTA_MAX = 4
};

enum class EVisibilityTrackCondition : uint8_t
{
    EVTC_Always = 0,
    EVTC_GoreEnabled = 1,
    EVTC_GoreDisabled = 2,
    EVTC_MAX = 3
};

enum class EVisibilityTrackAction : uint8_t
{
    EVTA_Hide = 0,
    EVTA_Show = 1,
    EVTA_Toggle = 2,
    EVTA_MAX = 3
};

enum class ESlateGesture : uint8_t
{
    None = 0,
    Scroll = 1,
    Magnify = 2,
    Swipe = 3,
    Rotate = 4,
    LongPress = 5,
    ESlateGesture_MAX = 6
};

enum class ELerpInterpolationMode : uint8_t
{
    QuatInterp = 0,
    EulerInterp = 1,
    DualQuatInterp = 2,
    ELerpInterpolationMode_MAX = 3
};

enum class EEasingFunc : uint8_t
{
    Linear = 0,
    Step = 1,
    SinusoidalIn = 2,
    SinusoidalOut = 3,
    SinusoidalInOut = 4,
    EaseIn = 5,
    EaseOut = 6,
    EaseInOut = 7,
    ExpoIn = 8,
    ExpoOut = 9,
    ExpoInOut = 10,
    CircularIn = 11,
    CircularOut = 12,
    CircularInOut = 13,
    EEasingFunc_MAX = 14
};

enum class EStreamingVolumeUsage : uint8_t
{
    SVB_Loading = 0,
    SVB_LoadingAndVisibility = 1,
    SVB_VisibilityBlockingOnLoad = 2,
    SVB_BlockingOnLoad = 3,
    SVB_LoadingNotVisible = 4,
    SVB_MAX = 5
};

enum class EMaterialDecalResponse : uint8_t
{
    MDR_None = 0,
    MDR_ColorNormalRoughness = 1,
    MDR_Color = 2,
    MDR_ColorNormal = 3,
    MDR_ColorRoughness = 4,
    MDR_Normal = 5,
    MDR_NormalRoughness = 6,
    MDR_Roughness = 7,
    MDR_MAX = 8
};

enum class EDecalBlendMode : uint8_t
{
    DBM_Translucent = 0,
    DBM_Stain = 1,
    DBM_Normal = 2,
    DBM_Emissive = 3,
    DBM_DBuffer_ColorNormalRoughness = 4,
    DBM_DBuffer_Color = 5,
    DBM_DBuffer_ColorNormal = 6,
    DBM_DBuffer_ColorRoughness = 7,
    DBM_DBuffer_Normal = 8,
    DBM_DBuffer_NormalRoughness = 9,
    DBM_DBuffer_Roughness = 10,
    DBM_DBuffer_Emissive = 11,
    DBM_DBuffer_AlphaComposite = 12,
    DBM_DBuffer_EmissiveAlphaComposite = 13,
    DBM_Volumetric_DistanceFunction = 14,
    DBM_AlphaComposite = 15,
    DBM_AmbientOcclusion = 16,
    DBM_MAX = 17
};

enum class ETextureColorChannel : uint8_t
{
    TCC_Red = 0,
    TCC_Green = 1,
    TCC_Blue = 2,
    TCC_Alpha = 3,
    TCC_MAX = 4
};

enum class EMaterialAttributeBlend : uint8_t
{
    Blend = 0,
    UseA = 1,
    UseB = 2,
    EMaterialAttributeBlend_MAX = 3
};

enum class EChannelMaskParameterColor : uint8_t
{
    Red = 0,
    Green = 1,
    Blue = 2,
    Alpha = 3,
    EChannelMaskParameterColor_MAX = 4
};

enum class EClampMode : uint8_t
{
    CMODE_Clamp = 0,
    CMODE_ClampMin = 1,
    CMODE_ClampMax = 2,
    CMODE_MAX = 3
};

enum class ECustomMaterialOutputType : uint8_t
{
    CMOT_Float1 = 0,
    CMOT_Float2 = 1,
    CMOT_Float3 = 2,
    CMOT_Float4 = 3,
    CMOT_MAX = 4
};

enum class EDepthOfFieldFunctionValue : uint8_t
{
    TDOF_NearAndFarMask = 0,
    TDOF_NearMask = 1,
    TDOF_FarMask = 2,
    TDOF_CircleOfConfusionRadius = 3,
    TDOF_MAX = 4
};

enum class EFunctionInputType : uint8_t
{
    FunctionInput_Scalar = 0,
    FunctionInput_Vector2 = 1,
    FunctionInput_Vector3 = 2,
    FunctionInput_Vector4 = 3,
    FunctionInput_Texture2D = 4,
    FunctionInput_TextureCube = 5,
    FunctionInput_VolumeTexture = 6,
    FunctionInput_StaticBool = 7,
    FunctionInput_MaterialAttributes = 8,
    FunctionInput_TextureExternal = 9,
    FunctionInput_MAX = 10
};

enum class ENoiseFunction : uint8_t
{
    NOISEFUNCTION_SimplexTex = 0,
    NOISEFUNCTION_GradientTex = 1,
    NOISEFUNCTION_GradientTex3D = 2,
    NOISEFUNCTION_GradientALU = 3,
    NOISEFUNCTION_ValueALU = 4,
    NOISEFUNCTION_VoronoiALU = 5,
    NOISEFUNCTION_MAX = 6
};

enum class EMaterialSceneAttributeInputMode : uint8_t
{
    Coordinates = 0,
    OffsetFraction = 1,
    EMaterialSceneAttributeInputMode_MAX = 2
};

enum class ESceneTextureId : uint8_t
{
    PPI_SceneColor = 0,
    PPI_SceneDepth = 1,
    PPI_DiffuseColor = 2,
    PPI_SpecularColor = 3,
    PPI_SubsurfaceColor = 4,
    PPI_BaseColor = 5,
    PPI_Specular = 6,
    PPI_Metallic = 7,
    PPI_WorldNormal = 8,
    PPI_SeparateTranslucency = 9,
    PPI_Opacity = 10,
    PPI_Roughness = 11,
    PPI_MaterialAO = 12,
    PPI_CustomDepth = 13,
    PPI_PostProcessInput0 = 14,
    PPI_PostProcessInput1 = 15,
    PPI_PostProcessInput2 = 16,
    PPI_PostProcessInput3 = 17,
    PPI_PostProcessInput4 = 18,
    PPI_PostProcessInput5 = 19,
    PPI_PostProcessInput6 = 20,
    PPI_DecalMask = 21,
    PPI_ShadingModelColor = 22,
    PPI_ShadingModelID = 23,
    PPI_AmbientOcclusion = 24,
    PPI_CustomStencil = 25,
    PPI_StoredBaseColor = 26,
    PPI_StoredSpecular = 27,
    PPI_MAX = 28
};

enum class ESpeedTreeLODType : uint8_t
{
    STLOD_Pop = 0,
    STLOD_Smooth = 1,
    STLOD_MAX = 2
};

enum class ESpeedTreeWindType : uint8_t
{
    STW_None = 0,
    STW_Fastest = 1,
    STW_Fast = 2,
    STW_Better = 3,
    STW_Best = 4,
    STW_Palm = 5,
    STW_BestPlus = 6,
    STW_MAX = 7
};

enum class ESpeedTreeGeometryType : uint8_t
{
    STG_Branch = 0,
    STG_Frond = 1,
    STG_Leaf = 2,
    STG_FacingLeaf = 3,
    STG_Billboard = 4,
    STG_MAX = 5
};

enum class EMaterialExposedTextureProperty : uint8_t
{
    TMTM_TextureSize = 0,
    TMTM_TexelSize = 1,
    TMTM_MAX = 2
};

enum class ETextureMipValueMode : uint8_t
{
    TMVM_None = 0,
    TMVM_MipLevel = 1,
    TMVM_MipBias = 2,
    TMVM_Derivative = 3,
    TMVM_MAX = 4
};

enum class EMaterialVectorCoordTransform : uint8_t
{
    TRANSFORM_Tangent = 0,
    TRANSFORM_Local = 1,
    TRANSFORM_World = 2,
    TRANSFORM_View = 3,
    TRANSFORM_Camera = 4,
    TRANSFORM_ParticleWorld = 5,
    TRANSFORM_MAX = 6
};

enum class EMaterialVectorCoordTransformSource : uint8_t
{
    TRANSFORMSOURCE_Tangent = 0,
    TRANSFORMSOURCE_Local = 1,
    TRANSFORMSOURCE_World = 2,
    TRANSFORMSOURCE_View = 3,
    TRANSFORMSOURCE_Camera = 4,
    TRANSFORMSOURCE_ParticleWorld = 5,
    TRANSFORMSOURCE_MAX = 6
};

enum class EMaterialPositionTransformSource : uint8_t
{
    TRANSFORMPOSSOURCE_Local = 0,
    TRANSFORMPOSSOURCE_World = 1,
    TRANSFORMPOSSOURCE_TranslatedWorld = 2,
    TRANSFORMPOSSOURCE_View = 3,
    TRANSFORMPOSSOURCE_Camera = 4,
    TRANSFORMPOSSOURCE_Particle = 5,
    TRANSFORMPOSSOURCE_MAX = 6
};

enum class EVectorNoiseFunction : uint8_t
{
    VNF_CellnoiseALU = 0,
    VNF_VectorALU = 1,
    VNF_GradientALU = 2,
    VNF_CurlALU = 3,
    VNF_VoronoiALU = 4,
    VNF_MAX = 5
};

enum class EMaterialExposedViewProperty : uint8_t
{
    MEVP_BufferSize = 0,
    MEVP_FieldOfView = 1,
    MEVP_TanHalfFieldOfView = 2,
    MEVP_ViewSize = 3,
    MEVP_WorldSpaceViewPosition = 4,
    MEVP_WorldSpaceCameraPosition = 5,
    MEVP_ViewportOffset = 6,
    MEVP_MAX = 7
};

enum class EWorldPositionIncludedOffsets : uint8_t
{
    WPT_Default = 0,
    WPT_ExcludeAllShaderOffsets = 1,
    WPT_CameraRelative = 2,
    WPT_CameraRelativeNoOffsets = 3,
    WPT_MAX = 4
};

enum class EMaterialFunctionUsage : uint8_t
{
    Default = 0,
    MaterialLayer = 1,
    MaterialLayerBlend = 2,
    EMaterialFunctionUsage_MAX = 3
};

enum class EMaterialUsage : uint8_t
{
    MATUSAGE_SkeletalMesh = 0,
    MATUSAGE_ParticleSprites = 1,
    MATUSAGE_BeamTrails = 2,
    MATUSAGE_MeshParticles = 3,
    MATUSAGE_StaticLighting = 4,
    MATUSAGE_MorphTargets = 5,
    MATUSAGE_SplineMesh = 6,
    MATUSAGE_InstancedStaticMeshes = 7,
    MATUSAGE_Clothing = 8,
    MATUSAGE_NiagaraSprites = 9,
    MATUSAGE_NiagaraRibbons = 10,
    MATUSAGE_NiagaraMeshParticles = 11,
    MATUSAGE_GeometryCache = 12,
    MATUSAGE_MAX = 13
};

enum class EMaterialParameterAssociation : uint8_t
{
    LayerParameter = 0,
    BlendParameter = 1,
    GlobalParameter = 2,
    EMaterialParameterAssociation_MAX = 3
};

enum class EMaterialMergeType : uint8_t
{
    MaterialMergeType_Default = 0,
    MaterialMergeType_Simplygon = 1,
    MaterialMergeType_MAX = 2
};

enum class ETextureSizingType : uint8_t
{
    TextureSizingType_UseSingleTextureSize = 0,
    TextureSizingType_UseAutomaticBiasedSizes = 1,
    TextureSizingType_UseManualOverrideTextureSize = 2,
    TextureSizingType_UseSimplygonAutomaticSizing = 3,
    TextureSizingType_MAX = 4
};

enum class EMaterialDomain : uint8_t
{
    MD_Surface = 0,
    MD_DeferredDecal = 1,
    MD_LightFunction = 2,
    MD_Volume = 3,
    MD_PostProcess = 4,
    MD_UI = 5,
    MD_MAX = 6
};

enum class EMeshInstancingReplacementMethod : uint8_t
{
    RemoveOriginalActors = 0,
    KeepOriginalActorsAsEditorOnly = 1,
    EMeshInstancingReplacementMethod_MAX = 2
};

enum class EUVOutput : uint8_t
{
    DoNotOutputChannel = 0,
    OutputChannel = 1,
    EUVOutput_MAX = 2
};

enum class EMeshMergeType : uint8_t
{
    MeshMergeType_Default = 0,
    MeshMergeType_MergeActor = 1,
    MeshMergeType_MAX = 2
};

enum class EMeshLODSelectionType : uint8_t
{
    AllLODs = 0,
    SpecificLOD = 1,
    CalculateLOD = 2,
    LowestDetailLOD = 3,
    EMeshLODSelectionType_MAX = 4
};

enum class EProxyNormalComputationMethod : uint8_t
{
    AngleWeighted = 0,
    AreaWeighted = 1,
    EqualWeighted = 2,
    EProxyNormalComputationMethod_MAX = 3
};

enum class ELandscapeCullingPrecision : uint8_t
{
    High = 0,
    Medium = 1,
    Low = 2,
    ELandscapeCullingPrecision_MAX = 3
};

enum class EStaticMeshReductionTerimationCriterion : uint8_t
{
    Triangles = 0,
    Vertices = 1,
    Any = 2,
    EStaticMeshReductionTerimationCriterion_MAX = 3
};

enum class EMeshFeatureImportance : uint8_t
{
    Off = 0,
    Lowest = 1,
    Low = 2,
    Normal = 3,
    High = 4,
    Highest = 5,
    EMeshFeatureImportance_MAX = 6
};

enum class EVertexPaintAxis : uint8_t
{
    X = 0,
    Y = 1,
    Z = 2,
    EVertexPaintAxis_MAX = 3
};

enum class EMicroTransactionResult : uint8_t
{
    MTR_Succeeded = 0,
    MTR_Failed = 1,
    MTR_Canceled = 2,
    MTR_RestoredFromServer = 3,
    MTR_MAX = 4
};

enum class EMicroTransactionDelegate : uint8_t
{
    MTD_PurchaseQueryComplete = 0,
    MTD_PurchaseComplete = 1,
    MTD_MAX = 2
};

enum class FNavigationSystemRunMode : uint8_t
{
    InvalidMode = 0,
    GameMode = 1,
    EditorMode = 2,
    SimulationMode = 3,
    PIEMode = 4,
    FNavigationSystemRunMode_MAX = 5
};

enum class ENavigationQueryResult : uint8_t
{
    Invalid = 0,
    Error = 1,
    Fail = 2,
    Success = 3,
    ENavigationQueryResult_MAX = 4
};

enum class ENavPathEvent : uint8_t
{
    Cleared = 0,
    NewPath = 1,
    UpdatedDueToGoalMoved = 2,
    UpdatedDueToNavigationChanged = 3,
    Invalidated = 4,
    RePathFailed = 5,
    MetaPathUpdate = 6,
    Custom = 7,
    ENavPathEvent_MAX = 8
};

enum class ENavDataGatheringModeConfig : uint8_t
{
    Invalid = 0,
    Instant = 1,
    Lazy = 2,
    ENavDataGatheringModeConfig_MAX = 3
};

enum class ENavDataGatheringMode : uint8_t
{
    Default = 0,
    Instant = 1,
    Lazy = 2,
    ENavDataGatheringMode_MAX = 3
};

enum class ENavigationOptionFlag : uint8_t
{
    Default = 0,
    Enable = 1,
    Disable = 2,
    MAX = 3
};

enum class ENavLinkDirection : uint8_t
{
    BothWays = 0,
    LeftToRight = 1,
    RightToLeft = 2,
    ENavLinkDirection_MAX = 3
};

enum class EEmitterRenderMode : uint8_t
{
    ERM_Normal = 0,
    ERM_Point = 1,
    ERM_Cross = 2,
    ERM_LightsOnly = 3,
    ERM_None = 4,
    ERM_MAX = 5
};

enum class EParticleSubUVInterpMethod : uint8_t
{
    PSUVIM_None = 0,
    PSUVIM_Linear = 1,
    PSUVIM_Linear_Blend = 2,
    PSUVIM_Random = 3,
    PSUVIM_Random_Blend = 4,
    PSUVIM_MAX = 5
};

enum class EParticleBurstMethod : uint8_t
{
    EPBM_Instant = 0,
    EPBM_Interpolated = 1,
    EPBM_MAX = 2
};

enum class EParticleSystemInsignificanceReaction : uint8_t
{
    Auto = 0,
    Complete = 1,
    DisableTick = 2,
    DisableTickAndKill = 3,
    Num = 4,
    EParticleSystemInsignificanceReaction_MAX = 5
};

enum class EParticleSignificanceLevel : uint8_t
{
    Low = 0,
    Medium = 1,
    High = 2,
    Critical = 3,
    Num = 4,
    EParticleSignificanceLevel_MAX = 5
};

enum class EParticleDetailMode : uint8_t
{
    PDM_Low = 0,
    PDM_Medium = 1,
    PDM_High = 2,
    PDM_MAX = 3
};

enum class EParticleSourceSelectionMethod : uint8_t
{
    EPSSM_Random = 0,
    EPSSM_Sequential = 1,
    EPSSM_MAX = 2
};

enum class EModuleType : uint8_t
{
    EPMT_General = 0,
    EPMT_TypeData = 1,
    EPMT_Beam = 2,
    EPMT_Trail = 3,
    EPMT_Spawn = 4,
    EPMT_Required = 5,
    EPMT_Event = 6,
    EPMT_Light = 7,
    EPMT_SubUV = 8,
    EPMT_MAX = 9
};

enum class EAttractorParticleSelectionMethod : uint8_t
{
    EAPSM_Random = 0,
    EAPSM_Sequential = 1,
    EAPSM_MAX = 2
};

enum class Beam2SourceTargetTangentMethod : uint8_t
{
    PEB2STTM_Direct = 0,
    PEB2STTM_UserSet = 1,
    PEB2STTM_Distribution = 2,
    PEB2STTM_Emitter = 3,
    PEB2STTM_MAX = 4
};

enum class Beam2SourceTargetMethod : uint8_t
{
    PEB2STM_Default = 0,
    PEB2STM_UserSet = 1,
    PEB2STM_Emitter = 2,
    PEB2STM_Particle = 3,
    PEB2STM_Actor = 4,
    PEB2STM_MAX = 5
};

enum class BeamModifierType : uint8_t
{
    PEB2MT_Source = 0,
    PEB2MT_Target = 1,
    PEB2MT_MAX = 2
};

enum class EParticleCameraOffsetUpdateMethod : uint8_t
{
    EPCOUM_DirectSet = 0,
    EPCOUM_Additive = 1,
    EPCOUM_Scalar = 2,
    EPCOUM_MAX = 3
};

enum class EParticleCollisionComplete : uint8_t
{
    EPCC_Kill = 0,
    EPCC_Freeze = 1,
    EPCC_HaltCollisions = 2,
    EPCC_FreezeTranslation = 3,
    EPCC_FreezeRotation = 4,
    EPCC_FreezeMovement = 5,
    EPCC_MAX = 6
};

enum class EParticleCollisionResponse : uint8_t
{
    Bounce = 0,
    Stop = 1,
    Kill = 2,
    EParticleCollisionResponse_MAX = 3
};

enum class ELocationBoneSocketSelectionMethod : uint8_t
{
    BONESOCKETSEL_Sequential = 0,
    BONESOCKETSEL_Random = 1,
    BONESOCKETSEL_MAX = 2
};

enum class ELocationBoneSocketSource : uint8_t
{
    BONESOCKETSOURCE_Bones = 0,
    BONESOCKETSOURCE_Sockets = 1,
    BONESOCKETSOURCE_MAX = 2
};

enum class ELocationEmitterSelectionMethod : uint8_t
{
    ELESM_Random = 0,
    ELESM_Sequential = 1,
    ELESM_MAX = 2
};

enum class CylinderHeightAxis : uint8_t
{
    PMLPC_HEIGHTAXIS_X = 0,
    PMLPC_HEIGHTAXIS_Y = 1,
    PMLPC_HEIGHTAXIS_Z = 2,
    PMLPC_HEIGHTAXIS_MAX = 3
};

enum class ELocationSkelVertSurfaceSource : uint8_t
{
    VERTSURFACESOURCE_Vert = 0,
    VERTSURFACESOURCE_Surface = 1,
    VERTSURFACESOURCE_MAX = 2
};

enum class EOrbitChainMode : uint8_t
{
    EOChainMode_Add = 0,
    EOChainMode_Scale = 1,
    EOChainMode_Link = 2,
    EOChainMode_MAX = 3
};

enum class EParticleAxisLock : uint8_t
{
    EPAL_NONE = 0,
    EPAL_X = 1,
    EPAL_Y = 2,
    EPAL_Z = 3,
    EPAL_NEGATIVE_X = 4,
    EPAL_NEGATIVE_Y = 5,
    EPAL_NEGATIVE_Z = 6,
    EPAL_ROTATE_X = 7,
    EPAL_ROTATE_Y = 8,
    EPAL_ROTATE_Z = 9,
    EPAL_MAX = 10
};

enum class EEmitterDynamicParameterValue : uint8_t
{
    EDPV_UserSet = 0,
    EDPV_AutoSet = 1,
    EDPV_VelocityX = 2,
    EDPV_VelocityY = 3,
    EDPV_VelocityZ = 4,
    EDPV_VelocityMag = 5,
    EDPV_MAX = 6
};

enum class EEmitterNormalsMode : uint8_t
{
    ENM_CameraFacing = 0,
    ENM_Spherical = 1,
    ENM_Cylindrical = 2,
    ENM_MAX = 3
};

enum class EParticleSortMode : uint8_t
{
    PSORTMODE_None = 0,
    PSORTMODE_ViewProjDepth = 1,
    PSORTMODE_DistanceToView = 2,
    PSORTMODE_Age_OldestFirst = 3,
    PSORTMODE_Age_NewestFirst = 4,
    PSORTMODE_MAX = 5
};

enum class EParticleUVFlipMode : uint8_t
{
    None = 0,
    FlipUV = 1,
    FlipUOnly = 2,
    FlipVOnly = 3,
    RandomFlipUV = 4,
    RandomFlipUOnly = 5,
    RandomFlipVOnly = 6,
    RandomFlipUVIndependent = 7,
    EParticleUVFlipMode_MAX = 8
};

enum class ETrail2SourceMethod : uint8_t
{
    PET2SRCM_Default = 0,
    PET2SRCM_Particle = 1,
    PET2SRCM_Actor = 2,
    PET2SRCM_MAX = 3
};

enum class EBeamTaperMethod : uint8_t
{
    PEBTM_None = 0,
    PEBTM_Full = 1,
    PEBTM_Partial = 2,
    PEBTM_MAX = 3
};

enum class EBeam2Method : uint8_t
{
    PEB2M_Distance = 0,
    PEB2M_Target = 1,
    PEB2M_Branch = 2,
    PEB2M_MAX = 3
};

enum class EMeshCameraFacingOptions : uint8_t
{
    XAxisFacing_NoUp = 0,
    XAxisFacing_ZUp = 1,
    XAxisFacing_NegativeZUp = 2,
    XAxisFacing_YUp = 3,
    XAxisFacing_NegativeYUp = 4,
    LockedAxis_ZAxisFacing = 5,
    LockedAxis_NegativeZAxisFacing = 6,
    LockedAxis_YAxisFacing = 7,
    LockedAxis_NegativeYAxisFacing = 8,
    VelocityAligned_ZAxisFacing = 9,
    VelocityAligned_NegativeZAxisFacing = 10,
    VelocityAligned_YAxisFacing = 11,
    VelocityAligned_NegativeYAxisFacing = 12,
    EMeshCameraFacingOptions_MAX = 13
};

enum class EMeshCameraFacingUpAxis : uint8_t
{
    CameraFacing_NoneUP = 0,
    CameraFacing_ZUp = 1,
    CameraFacing_NegativeZUp = 2,
    CameraFacing_YUp = 3,
    CameraFacing_NegativeYUp = 4,
    CameraFacing_MAX = 5
};

enum class EMeshScreenAlignment : uint8_t
{
    PSMA_MeshFaceCameraWithRoll = 0,
    PSMA_MeshFaceCameraWithSpin = 1,
    PSMA_MeshFaceCameraWithLockedAxis = 2,
    PSMA_MAX = 3
};

enum class ETrailsRenderAxisOption : uint8_t
{
    Trails_CameraUp = 0,
    Trails_SourceUp = 1,
    Trails_WorldUp = 2,
    Trails_MAX = 3
};

enum class EParticleScreenAlignment : uint8_t
{
    PSA_FacingCameraPosition = 0,
    PSA_Square = 1,
    PSA_Rectangle = 2,
    PSA_Velocity = 3,
    PSA_AwayFromCenter = 4,
    PSA_TypeSpecific = 5,
    PSA_FacingCameraDistanceBlend = 6,
    PSA_MAX = 7
};

enum class EParticleSystemOcclusionBoundsMethod : uint8_t
{
    EPSOBM_None = 0,
    EPSOBM_ParticleBounds = 1,
    EPSOBM_CustomBounds = 2,
    EPSOBM_MAX = 3
};

enum class ParticleSystemLODMethod : uint8_t
{
    PARTICLESYSTEMLODMETHOD_Automatic = 0,
    PARTICLESYSTEMLODMETHOD_DirectSet = 1,
    PARTICLESYSTEMLODMETHOD_ActivateAutomatic = 2,
    PARTICLESYSTEMLODMETHOD_MAX = 3
};

enum class EParticleSystemUpdateMode : uint8_t
{
    EPSUM_RealTime = 0,
    EPSUM_FixedTime = 1,
    EPSUM_MAX = 2
};

enum class EParticleEventType : uint8_t
{
    EPET_Any = 0,
    EPET_Spawn = 1,
    EPET_Death = 2,
    EPET_Collision = 3,
    EPET_Burst = 4,
    EPET_Blueprint = 5,
    EPET_MAX = 6
};

enum class ParticleReplayState : uint8_t
{
    PRS_Disabled = 0,
    PRS_Capturing = 1,
    PRS_Replaying = 2,
    PRS_MAX = 3
};

enum class EParticleSysParamType : uint8_t
{
    PSPT_None = 0,
    PSPT_Scalar = 1,
    PSPT_ScalarRand = 2,
    PSPT_Vector = 3,
    PSPT_VectorRand = 4,
    PSPT_Color = 5,
    PSPT_Actor = 6,
    PSPT_Material = 7,
    PSPT_MAX = 8
};

enum class ESettingsLockedAxis : uint8_t
{
    None = 0,
    X = 1,
    Y = 2,
    Z = 3,
    Invalid = 4,
    ESettingsLockedAxis_MAX = 5
};

enum class ESettingsDOF : uint8_t
{
    Full3D = 0,
    YZPlane = 1,
    XZPlane = 2,
    XYPlane = 3,
    ESettingsDOF_MAX = 4
};

enum class EFrictionCombineMode : uint8_t
{
    Average = 0,
    Min = 1,
    Multiply = 2,
    Max = 3
};

enum class ERendererStencilMask : uint8_t
{
    ERSM_Default = 0,
    ERSM_255 = 1,
    ERSM_1 = 2,
    ERSM_2 = 3,
    ERSM_4 = 4,
    ERSM_8 = 5,
    ERSM_16 = 6,
    ERSM_32 = 7,
    ERSM_64 = 8,
    ERSM_128 = 9,
    ERSM_MAX = 10
};

enum class EHasCustomNavigableGeometry : uint8_t
{
    No = 0,
    Yes = 1,
    EvenIfNotCollidable = 2,
    DontExport = 3,
    EHasCustomNavigableGeometry_MAX = 4
};

enum class ECanBeCharacterBase : uint8_t
{
    ECB_No = 0,
    ECB_Yes = 1,
    ECB_Owner = 2,
    ECB_MAX = 3
};

enum class ERichCurveExtrapolation : uint8_t
{
    RCCE_Cycle = 0,
    RCCE_CycleWithOffset = 1,
    RCCE_Oscillate = 2,
    RCCE_Linear = 3,
    RCCE_Constant = 4,
    RCCE_None = 5,
    RCCE_MAX = 6
};

enum class ERichCurveInterpMode : uint8_t
{
    RCIM_Linear = 0,
    RCIM_Constant = 1,
    RCIM_Cubic = 2,
    RCIM_None = 3,
    RCIM_MAX = 4
};

enum class EReflectionSourceType : uint8_t
{
    CapturedScene = 0,
    SpecifiedCubemap = 1,
    EReflectionSourceType_MAX = 2
};

enum class EDefaultBackBufferPixelFormat : uint8_t
{
    DBBPF_B8G8R8A8 = 0,
    DBBPF_A16B16G16R16_DEPRECATED = 1,
    DBBPF_FloatRGB_DEPRECATED = 2,
    DBBPF_FloatRGBA = 3,
    DBBPF_A2B10G10R10 = 4,
    DBBPF_MAX = 5
};

enum class EAutoExposureMethodUI : uint8_t
{
    AEM_Histogram = 0,
    AEM_Basic = 1,
    AEM_Manual = 2,
    AEM_MAX = 3
};

enum class EAlphaChannelMode : uint8_t
{
    Disabled = 0,
    LinearColorSpaceOnly = 1,
    AllowThroughTonemapper = 2,
    EAlphaChannelMode_MAX = 3
};

enum class EEarlyZPass : uint8_t
{
    None = 0,
    OpaqueOnly = 1,
    OpaqueAndMasked = 2,
    Auto = 3,
    EEarlyZPass_MAX = 4
};

enum class ECustomDepthStencil : uint8_t
{
    Disabled = 0,
    Enabled = 1,
    EnabledOnDemand = 2,
    EnabledWithStencil = 3,
    ECustomDepthStencil_MAX = 4
};

enum class EMobileMSAASampleCount : uint8_t
{
    One = 1,
    Two = 2,
    Four = 4,
    Eight = 8,
    EMobileMSAASampleCount_MAX = 9
};

enum class ECompositingSampleCount : uint8_t
{
    One = 1,
    Two = 2,
    Four = 4,
    Eight = 8,
    ECompositingSampleCount_MAX = 9
};

enum class EClearSceneOptions : uint8_t
{
    NoClear = 0,
    HardwareClear = 1,
    QuadAtMaxZ = 2,
    EClearSceneOptions_MAX = 3
};

enum class EReporterLineStyle : uint8_t
{
    Line = 0,
    Dash = 1,
    EReporterLineStyle_MAX = 2
};

enum class ELegendPosition : uint8_t
{
    Outside = 0,
    Inside = 1,
    ELegendPosition_MAX = 2
};

enum class EGraphDataStyle : uint8_t
{
    Lines = 0,
    Filled = 1,
    EGraphDataStyle_MAX = 2
};

enum class EGraphAxisStyle : uint8_t
{
    Lines = 0,
    Notches = 1,
    Grid = 2,
    EGraphAxisStyle_MAX = 3
};

enum class ERichCurveTangentWeightMode : uint8_t
{
    RCTWM_WeightedNone = 0,
    RCTWM_WeightedArrive = 1,
    RCTWM_WeightedLeave = 2,
    RCTWM_WeightedBoth = 3,
    RCTWM_MAX = 4
};

enum class ERichCurveTangentMode : uint8_t
{
    RCTM_Auto = 0,
    RCTM_User = 1,
    RCTM_Break = 2,
    RCTM_None = 3,
    RCTM_MAX = 4
};

enum class EConstraintTransform : uint8_t
{
    Absolute = 0,
    Relative = 1,
    EConstraintTransform_MAX = 2
};

enum class EControlConstraint : uint8_t
{
    Orientation = 0,
    Translation = 1,
    MAX = 2
};

enum class ERootMotionFinishVelocityMode : uint8_t
{
    MaintainLastRootMotionVelocity = 0,
    SetVelocity = 1,
    ClampVelocity = 2,
    ERootMotionFinishVelocityMode_MAX = 3
};

enum class ERootMotionSourceSettingsFlags : uint8_t
{
    UseSensitiveLiftoffCheck = 1,
    DisablePartialEndTick = 2,
    ERootMotionSourceSettingsFlags_MAX = 3
};

enum class ERootMotionSourceStatusFlags : uint8_t
{
    Prepared = 1,
    Finished = 2,
    MarkedForRemoval = 4,
    ERootMotionSourceStatusFlags_MAX = 5
};

enum class ERootMotionAccumulateMode : uint8_t
{
    Override = 0,
    Additive = 1,
    ERootMotionAccumulateMode_MAX = 2
};

enum class ELightUnits : uint8_t
{
    Unitless = 0,
    Candelas = 1,
    Lumens = 2,
    ELightUnits_MAX = 3
};

enum class EBloomMethod : uint8_t
{
    BM_SOG = 0,
    BM_FFT = 1,
    BM_MAX = 2
};

enum class EAutoExposureMethod : uint8_t
{
    AEM_Histogram = 0,
    AEM_Basic = 1,
    AEM_Manual = 2,
    AEM_MAX = 3
};

enum class EAntiAliasingMethod : uint8_t
{
    AAM_None = 0,
    AAM_FXAA = 1,
    AAM_TemporalAA = 2,
    AAM_MSAA = 3,
    AAM_MAX = 4
};

enum class EDepthOfFieldMethod : uint8_t
{
    DOFM_BokehDOF = 0,
    DOFM_Gaussian = 1,
    DOFM_CircleDOF = 2,
    DOFM_MAX = 3
};

enum class ESceneCapturePrimitiveRenderMode : uint8_t
{
    PRM_LegacySceneCapture = 0,
    PRM_RenderScenePrimitives = 1,
    PRM_UseShowOnlyList = 2,
    PRM_MAX = 3
};

enum class ERelativeTransformSpace : uint8_t
{
    RTS_World = 0,
    RTS_Actor = 1,
    RTS_Component = 2,
    RTS_ParentBoneSpace = 3,
    RTS_MAX = 4
};

enum class EDetailMode : uint8_t
{
    DM_Low = 0,
    DM_Medium = 1,
    DM_High = 2,
    DM_MAX = 3
};

enum class EMaterialProperty : uint8_t
{
    MP_EmissiveColor = 0,
    MP_Opacity = 1,
    MP_OpacityMask = 2,
    MP_DiffuseColor = 3,
    MP_SpecularColor = 4,
    MP_BaseColor = 5,
    MP_Metallic = 6,
    MP_Specular = 7,
    MP_Roughness = 8,
    MP_Normal = 9,
    MP_WorldPositionOffset = 10,
    MP_WorldDisplacement = 11,
    MP_TessellationMultiplier = 12,
    MP_SubsurfaceColor = 13,
    MP_CustomData0 = 14,
    MP_CustomData1 = 15,
    MP_AmbientOcclusion = 16,
    MP_Refraction = 17,
    MP_CustomizedUVs0 = 18,
    MP_CustomizedUVs1 = 19,
    MP_CustomizedUVs2 = 20,
    MP_CustomizedUVs3 = 21,
    MP_CustomizedUVs4 = 22,
    MP_CustomizedUVs5 = 23,
    MP_CustomizedUVs6 = 24,
    MP_CustomizedUVs7 = 25,
    MP_PixelDepthOffset = 26,
    MP_MaterialAttributes = 27,
    MP_CustomOutput = 28,
    MP_MAX = 29
};

enum class EPhysicsTransformUpdateMode : uint8_t
{
    SimulationUpatesComponentTransform = 0,
    ComponentTransformIsKinematic = 1,
    EPhysicsTransformUpdateMode_MAX = 2
};

enum class EAnimationMode : uint8_t
{
    AnimationBlueprint = 0,
    AnimationSingleNode = 1,
    AnimationCustomMode = 2,
    EAnimationMode_MAX = 3
};

enum class EKinematicBonesUpdateToPhysics : uint8_t
{
    SkipSimulatingBones = 0,
    SkipAllBones = 1,
    EKinematicBonesUpdateToPhysics_MAX = 2
};

enum class EAnimCurveType : uint8_t
{
    AttributeCurve = 0,
    MaterialCurve = 1,
    MorphTargetCurve = 2,
    MaxAnimCurveType = 3,
    EAnimCurveType_MAX = 4
};

enum class EBoneFilterActionOption : uint8_t
{
    Remove = 0,
    Keep = 1,
    Invalid = 2,
    EBoneFilterActionOption_MAX = 3
};

enum class SkeletalMeshOptimizationImportance : uint8_t
{
    SMOI_Off = 0,
    SMOI_Lowest = 1,
    SMOI_Low = 2,
    SMOI_Normal = 3,
    SMOI_High = 4,
    SMOI_Highest = 5,
    SMOI_MAX = 6
};

enum class SkeletalMeshOptimizationType : uint8_t
{
    SMOT_NumOfTriangles = 0,
    SMOT_MaxDeviation = 1,
    SMOT_TriangleOrDeviation = 2,
    SMOT_MAX = 3
};

enum class SkeletalMeshTerminationCriterion : uint8_t
{
    SMTC_NumOfTriangles = 0,
    SMTC_NumOfVerts = 1,
    SMTC_TriangleOrVert = 2,
    SMTC_MAX = 3
};

enum class EBoneTranslationRetargetingMode : uint8_t
{
    Animation = 0,
    Skeleton = 1,
    AnimationScaled = 2,
    AnimationRelative = 3,
    OrientAndScale = 4,
    EBoneTranslationRetargetingMode_MAX = 5
};

enum class EBoneSpaces : uint8_t
{
    WorldSpace = 0,
    ComponentSpace = 1,
    EBoneSpaces_MAX = 2
};

enum class EVisibilityBasedAnimTickOption : uint8_t
{
    AlwaysTickPoseAndRefreshBones = 0,
    AlwaysTickPose = 1,
    OnlyTickMontagesWhenNotRendered = 2,
    OnlyTickPoseWhenRendered = 3,
    EVisibilityBasedAnimTickOption_MAX = 4
};

enum class EPhysBodyOp : uint8_t
{
    PBO_None = 0,
    PBO_Term = 1,
    PBO_MAX = 2
};

enum class EBoneVisibilityStatus : uint8_t
{
    BVS_HiddenByParent = 0,
    BVS_Visible = 1,
    BVS_ExplicitlyHidden = 2,
    BVS_MAX = 3
};

enum class ESkyLightSourceType : uint8_t
{
    SLS_CapturedScene = 0,
    SLS_SpecifiedCubemap = 1,
    SLS_MAX = 2
};

enum class EReverbSendMethod : uint8_t
{
    Linear = 0,
    CustomCurve = 1,
    Manual = 2,
    EReverbSendMethod_MAX = 3
};

enum class EAirAbsorptionMethod : uint8_t
{
    Linear = 0,
    CustomCurve = 1,
    EAirAbsorptionMethod_MAX = 2
};

enum class ESoundSpatializationAlgorithm : uint8_t
{
    SPATIALIZATION_Default = 0,
    SPATIALIZATION_HRTF = 1,
    SPATIALIZATION_MAX = 2
};

enum class ESoundDistanceCalc : uint8_t
{
    SOUNDDISTANCE_Normal = 0,
    SOUNDDISTANCE_InfiniteXYPlane = 1,
    SOUNDDISTANCE_InfiniteXZPlane = 2,
    SOUNDDISTANCE_InfiniteYZPlane = 3,
    SOUNDDISTANCE_MAX = 4
};

enum class EAudioOutputTarget : uint8_t
{
    Speaker = 0,
    Controller = 1,
    ControllerFallbackToSpeaker = 2,
    EAudioOutputTarget_MAX = 3
};

enum class EMaxConcurrentResolutionRule : uint8_t
{
    PreventNew = 0,
    StopOldest = 1,
    StopFarthestThenPreventNew = 2,
    StopFarthestThenOldest = 3,
    StopLowestPriority = 4,
    StopQuietest = 5,
    StopLowestPriorityThenPreventNew = 6,
    EMaxConcurrentResolutionRule_MAX = 7
};

enum class ESoundGroup : uint8_t
{
    SOUNDGROUP_Default = 0,
    SOUNDGROUP_Effects = 1,
    SOUNDGROUP_UI = 2,
    SOUNDGROUP_Music = 3,
    SOUNDGROUP_Voice = 4,
    SOUNDGROUP_GameSoundGroup1 = 5,
    SOUNDGROUP_GameSoundGroup2 = 6,
    SOUNDGROUP_GameSoundGroup3 = 7,
    SOUNDGROUP_GameSoundGroup4 = 8,
    SOUNDGROUP_GameSoundGroup5 = 9,
    SOUNDGROUP_GameSoundGroup6 = 10,
    SOUNDGROUP_GameSoundGroup7 = 11,
    SOUNDGROUP_GameSoundGroup8 = 12,
    SOUNDGROUP_GameSoundGroup9 = 13,
    SOUNDGROUP_GameSoundGroup10 = 14,
    SOUNDGROUP_GameSoundGroup11 = 15,
    SOUNDGROUP_GameSoundGroup12 = 16,
    SOUNDGROUP_GameSoundGroup13 = 17,
    SOUNDGROUP_GameSoundGroup14 = 18,
    SOUNDGROUP_GameSoundGroup15 = 19,
    SOUNDGROUP_GameSoundGroup16 = 20,
    SOUNDGROUP_GameSoundGroup17 = 21,
    SOUNDGROUP_GameSoundGroup18 = 22,
    SOUNDGROUP_GameSoundGroup19 = 23,
    SOUNDGROUP_GameSoundGroup20 = 24,
    SOUNDGROUP_MAX = 25
};

enum class ModulationParamMode : uint8_t
{
    MPM_Normal = 0,
    MPM_Abs = 1,
    MPM_Direct = 2,
    MPM_MAX = 3
};

enum class ESourceBusChannels : uint8_t
{
    Mono = 0,
    Stereo = 1,
    ESourceBusChannels_MAX = 2
};

enum class EAudioRecordingExportType : uint8_t
{
    SoundWave = 0,
    WavFile = 1,
    EAudioRecordingExportType_MAX = 2
};

enum class ESubmixChannelFormat : uint8_t
{
    Device = 0,
    Stereo = 1,
    Quad = 2,
    FiveDotOne = 3,
    SevenDotOne = 4,
    Ambisonics = 5,
    Count = 6,
    ESubmixChannelFormat_MAX = 7
};

enum class EDecompressionType : uint8_t
{
    DTYPE_Setup = 0,
    DTYPE_Invalid = 1,
    DTYPE_Preview = 2,
    DTYPE_Native = 3,
    DTYPE_RealTime = 4,
    DTYPE_Procedural = 5,
    DTYPE_Xenon = 6,
    DTYPE_Streaming = 7,
    DTYPE_MAX = 8
};

enum class ESplineCoordinateSpace : uint8_t
{
    Local = 0,
    World = 1,
    ESplineCoordinateSpace_MAX = 2
};

enum class ESplinePointType : uint8_t
{
    Linear = 0,
    Curve = 1,
    Constant = 2,
    CurveClamped = 3,
    CurveCustomTangent = 4,
    ESplinePointType_MAX = 5
};

enum class ESplineMeshAxis : uint8_t
{
    X = 0,
    Y = 1,
    Z = 2,
    ESplineMeshAxis_MAX = 3
};

enum class EOptimizationType : uint8_t
{
    OT_NumOfTriangles = 0,
    OT_MaxDeviation = 1,
    OT_MAX = 2
};

enum class EImportanceLevel : uint8_t
{
    IL_Off = 0,
    IL_Lowest = 1,
    IL_Low = 2,
    IL_Normal = 3,
    IL_High = 4,
    IL_Highest = 5,
    TEMP_BROKEN2 = 6,
    EImportanceLevel_MAX = 7
};

enum class ENormalMode : uint8_t
{
    NM_PreserveSmoothingGroups = 0,
    NM_RecalculateNormals = 1,
    NM_RecalculateNormalsSmooth = 2,
    NM_RecalculateNormalsHard = 3,
    TEMP_BROKEN = 4,
    ENormalMode_MAX = 5
};

enum class EStereoLayerShape : uint8_t
{
    SLSH_QuadLayer = 0,
    SLSH_CylinderLayer = 1,
    SLSH_CubemapLayer = 2,
    SLSH_MAX = 3
};

enum class EStereoLayerType : uint8_t
{
    SLT_WorldLocked = 0,
    SLT_TrackerLocked = 1,
    SLT_FaceLocked = 2,
    SLT_MAX = 3
};

enum class EOpacitySourceMode : uint8_t
{
    OSM_Alpha = 0,
    OSM_ColorBrightness = 1,
    OSM_RedChannel = 2,
    OSM_GreenChannel = 3,
    OSM_BlueChannel = 4,
    OSM_MAX = 5
};

enum class ESubUVBoundingVertexCount : uint8_t
{
    BVC_FourVertices = 0,
    BVC_EightVertices = 1,
    BVC_MAX = 2
};

enum class EVerticalTextAligment : uint8_t
{
    EVRTA_TextTop = 0,
    EVRTA_TextCenter = 1,
    EVRTA_TextBottom = 2,
    EVRTA_QuadTop = 3,
    EVRTA_MAX = 4
};

enum class EHorizTextAligment : uint8_t
{
    EHTA_Left = 0,
    EHTA_Center = 1,
    EHTA_Right = 2,
    EHTA_MAX = 3
};

enum class ETextureCompressionQuality : uint8_t
{
    TCQ_Default = 0,
    TCQ_Lowest = 1,
    TCQ_Low = 2,
    TCQ_Medium = 3,
    TCQ_High = 4,
    TCQ_Highest = 5,
    TCQ_MAX = 6
};

enum class ETextureSourceFormat : uint8_t
{
    TSF_Invalid = 0,
    TSF_G8 = 1,
    TSF_BGRA8 = 2,
    TSF_BGRE8 = 3,
    TSF_RGBA16 = 4,
    TSF_RGBA16F = 5,
    TSF_RGBA8 = 6,
    TSF_RGBE8 = 7,
    TSF_MAX = 8
};

enum class ETextureSourceArtType : uint8_t
{
    TSAT_Uncompressed = 0,
    TSAT_PNGCompressed = 1,
    TSAT_DDSFile = 2,
    TSAT_MAX = 3
};

enum class ETextureMipCount : uint8_t
{
    TMC_ResidentMips = 0,
    TMC_AllMips = 1,
    TMC_AllMipsBiased = 2,
    TMC_MAX = 3
};

enum class ECompositeTextureMode : uint8_t
{
    CTM_Disabled = 0,
    CTM_NormalRoughnessToRed = 1,
    CTM_NormalRoughnessToGreen = 2,
    CTM_NormalRoughnessToBlue = 3,
    CTM_NormalRoughnessToAlpha = 4,
    CTM_MAX = 5
};

enum class TextureAddress : uint8_t
{
    TA_Wrap = 0,
    TA_Clamp = 1,
    TA_Mirror = 2,
    TA_MAX = 3
};

enum class TextureFilter : uint8_t
{
    TF_Nearest = 0,
    TF_Bilinear = 1,
    TF_Trilinear = 2,
    TF_Default = 3,
    TF_MAX = 4
};

enum class TextureCompressionSettings : uint8_t
{
    TC_Default = 0,
    TC_Normalmap = 1,
    TC_Masks = 2,
    TC_Grayscale = 3,
    TC_Displacementmap = 4,
    TC_VectorDisplacementmap = 5,
    TC_HDR = 6,
    TC_EditorIcon = 7,
    TC_Alpha = 8,
    TC_DistanceFieldFont = 9,
    TC_HDR_Compressed = 10,
    TC_BC7 = 11,
    TC_MAX = 12
};

enum class ETextureSamplerFilter : uint8_t
{
    Point = 0,
    Bilinear = 1,
    Trilinear = 2,
    AnisotropicPoint = 3,
    AnisotropicLinear = 4,
    ETextureSamplerFilter_MAX = 5
};

enum class ETexturePowerOfTwoSetting : uint8_t
{
    None = 0,
    PadToPowerOfTwo = 1,
    PadToSquarePowerOfTwo = 2,
    ETexturePowerOfTwoSetting_MAX = 3
};

enum class TextureMipGenSettings : uint8_t
{
    TMGS_FromTextureGroup = 0,
    TMGS_SimpleAverage = 1,
    TMGS_Sharpen0 = 2,
    TMGS_Sharpen1 = 3,
    TMGS_Sharpen2 = 4,
    TMGS_Sharpen3 = 5,
    TMGS_Sharpen4 = 6,
    TMGS_Sharpen5 = 7,
    TMGS_Sharpen6 = 8,
    TMGS_Sharpen7 = 9,
    TMGS_Sharpen8 = 10,
    TMGS_Sharpen9 = 11,
    TMGS_Sharpen10 = 12,
    TMGS_NoMipmaps = 13,
    TMGS_LeaveExistingMips = 14,
    TMGS_Blur1 = 15,
    TMGS_Blur2 = 16,
    TMGS_Blur3 = 17,
    TMGS_Blur4 = 18,
    TMGS_Blur5 = 19,
    TMGS_MAX = 20
};

enum class TextureGroup : uint8_t
{
    TEXTUREGROUP_World = 0,
    TEXTUREGROUP_WorldNormalMap = 1,
    TEXTUREGROUP_WorldSpecular = 2,
    TEXTUREGROUP_Character = 3,
    TEXTUREGROUP_CharacterNormalMap = 4,
    TEXTUREGROUP_CharacterSpecular = 5,
    TEXTUREGROUP_Weapon = 6,
    TEXTUREGROUP_WeaponNormalMap = 7,
    TEXTUREGROUP_WeaponSpecular = 8,
    TEXTUREGROUP_Vehicle = 9,
    TEXTUREGROUP_VehicleNormalMap = 10,
    TEXTUREGROUP_VehicleSpecular = 11,
    TEXTUREGROUP_Cinematic = 12,
    TEXTUREGROUP_Effects = 13,
    TEXTUREGROUP_EffectsNotFiltered = 14,
    TEXTUREGROUP_Skybox = 15,
    TEXTUREGROUP_UI = 16,
    TEXTUREGROUP_Lightmap = 17,
    TEXTUREGROUP_RenderTarget = 18,
    TEXTUREGROUP_MobileFlattened = 19,
    TEXTUREGROUP_ProcBuilding_Face = 20,
    TEXTUREGROUP_ProcBuilding_LightMap = 21,
    TEXTUREGROUP_Shadowmap = 22,
    TEXTUREGROUP_ColorLookupTable = 23,
    TEXTUREGROUP_Terrain_Heightmap = 24,
    TEXTUREGROUP_Terrain_Weightmap = 25,
    TEXTUREGROUP_Bokeh = 26,
    TEXTUREGROUP_IESLightProfile = 27,
    TEXTUREGROUP_Pixels2D = 28,
    TEXTUREGROUP_HierarchicalLOD = 29,
    TEXTUREGROUP_Impostor = 30,
    TEXTUREGROUP_ImpostorNormalDepth = 31,
    TEXTUREGROUP_Project01 = 32,
    TEXTUREGROUP_Project02 = 33,
    TEXTUREGROUP_Project03 = 34,
    TEXTUREGROUP_Project04 = 35,
    TEXTUREGROUP_Project05 = 36,
    TEXTUREGROUP_Project06 = 37,
    TEXTUREGROUP_Project07 = 38,
    TEXTUREGROUP_Project08 = 39,
    TEXTUREGROUP_Project09 = 40,
    TEXTUREGROUP_Project10 = 41,
    TEXTUREGROUP_MAX = 42
};

enum class ETextureRenderTargetFormat : uint8_t
{
    RTF_R8 = 0,
    RTF_RG8 = 1,
    RTF_RGBA8 = 2,
    RTF_R16f = 3,
    RTF_RG16f = 4,
    RTF_RGBA16f = 5,
    RTF_R32f = 6,
    RTF_RG32f = 7,
    RTF_RGBA32f = 8,
    RTF_RGB10A2 = 9,
    RTF_MAX = 10
};

enum class ETimecodeProviderSynchronizationState : uint8_t
{
    Closed = 0,
    Error = 1,
    Synchronized = 2,
    Synchronizing = 3,
    ETimecodeProviderSynchronizationState_MAX = 4
};

enum class ETimelineDirection : uint8_t
{
    Forward = 0,
    Backward = 1,
    ETimelineDirection_MAX = 2
};

enum class ETimelineLengthMode : uint8_t
{
    TL_TimelineLength = 0,
    TL_LastKeyFrame = 1,
    TL_MAX = 2
};

enum class ETimeStretchCurveMapping : uint8_t
{
    T_Original = 0,
    T_TargetMin = 1,
    T_TargetMax = 2,
    MAX = 3
};

enum class ETwitterIntegrationDelegate : uint8_t
{
    TID_AuthorizeComplete = 0,
    TID_TweetUIComplete = 1,
    TID_RequestComplete = 2,
    TID_MAX = 3
};

enum class ETwitterRequestMethod : uint8_t
{
    TRM_Get = 0,
    TRM_Post = 1,
    TRM_Delete = 2,
    TRM_MAX = 3
};

enum class EUserDefinedStructureStatus : uint8_t
{
    UDSS_UpToDate = 0,
    UDSS_Dirty = 1,
    UDSS_Error = 2,
    UDSS_Duplicate = 3,
    UDSS_MAX = 4
};

enum class EUIScalingRule : uint8_t
{
    ShortestSide = 0,
    LongestSide = 1,
    Horizontal = 2,
    Vertical = 3,
    Custom = 4,
    EUIScalingRule_MAX = 5
};

enum class ERenderFocusRule : uint8_t
{
    Always = 0,
    NonPointer = 1,
    NavigationOnly = 2,
    Never = 3,
    ERenderFocusRule_MAX = 4
};

enum class EVectorFieldConstructionOp : uint8_t
{
    VFCO_Extrude = 0,
    VFCO_Revolve = 1,
    VFCO_MAX = 2
};

enum class PageTableFormat : uint8_t
{
    PTF_16 = 0,
    PTF_32 = 1,
    PTF_MAX = 2
};

enum class EWindSourceType : uint8_t
{
    Directional = 0,
    Point = 1,
    EWindSourceType_MAX = 2
};

enum class EPSCPoolMethod : uint8_t
{
    None = 0,
    AutoRelease = 1,
    ManualRelease = 2,
    ManualRelease_OnComplete = 3,
    FreeInPool = 4,
    EPSCPoolMethod_MAX = 5
};

enum class EVolumeLightingMethod : uint8_t
{
    VLM_VolumetricLightmap = 0,
    VLM_SparseVolumeLightingSamples = 1,
    VLM_MAX = 2
};

enum class EVisibilityAggressiveness : uint8_t
{
    VIS_LeastAggressive = 0,
    VIS_ModeratelyAggressive = 1,
    VIS_MostAggressive = 2,
    VIS_Max = 3
};struct FTableRowBase
{
	public:
	    char UnknownData0[0x8];

};

struct FPerPlatformFloat
{
	public:
	    float Default; // 0x0 Size: 0x4

};

struct FPerPlatformInt
{
	public:
	    int Default; // 0x0 Size: 0x4

};

struct FPerPlatformBool
{
	public:
	    bool Default; // 0x0 Size: 0x1

};

struct FAnimNode_Base
{
	public:
	    char UnknownData0[0x10];

};

struct FPoseLinkBase
{
	public:
	    int LinkID; // 0x0 Size: 0x4
	    char UnknownData0[0xc];

};

struct FPoseLink : public FPoseLinkBase
{
	public:
	    char UnknownData0[0x10];

};

struct FAnimInstanceProxy
{
	public:
	    char UnknownData0[0x700];

};

struct FKeyHandleLookupTable
{
	public:
	    char UnknownData0[0x60];

};

struct FBranchFilter
{
	public:
	    FName BoneName; // 0x0 Size: 0x8
	    int BlendDepth; // 0x8 Size: 0x4

};

struct FInputRange
{
	public:
	    float Min; // 0x0 Size: 0x4
	    float Max; // 0x4 Size: 0x4

};

struct FInputScaleBiasClamp
{
	public:
	    bool bMapRange; // 0x0 Size: 0x1
	    bool bClampResult; // 0x1 Size: 0x1
	    bool bInterpResult; // 0x2 Size: 0x1
	    char UnknownData0[0x1]; // 0x3
	    struct FInputRange InRange; // 0x4 Size: 0x8
	    struct FInputRange OutRange; // 0xc Size: 0x8
	    float Scale; // 0x14 Size: 0x4
	    float Bias; // 0x18 Size: 0x4
	    float ClampMin; // 0x1c Size: 0x4
	    float ClampMax; // 0x20 Size: 0x4
	    float InterpSpeedIncreasing; // 0x24 Size: 0x4
	    float InterpSpeedDecreasing; // 0x28 Size: 0x4
	    char UnknownData1[0x4];

};

struct FAlphaBlend
{
	public:
	    class UCurveFloat* CustomCurve; // 0x0 Size: 0x8
	    float BlendTime; // 0x8 Size: 0x4
	    char UnknownData0[0x18]; // 0xc
	    EAlphaBlendOption BlendOption; // 0x24 Size: 0x1
	    char UnknownData1[0xb];

};

struct FInputAlphaBoolBlend
{
	public:
	    float BlendInTime; // 0x0 Size: 0x4
	    float BlendOutTime; // 0x4 Size: 0x4
	    EAlphaBlendOption BlendOption; // 0x8 Size: 0x1
	    bool bInitialized; // 0x9 Size: 0x1
	    char UnknownData0[0x6]; // 0xa
	    class UCurveFloat* CustomCurve; // 0x10 Size: 0x8
	    struct FAlphaBlend AlphaBlend; // 0x18 Size: 0x30

};

struct FInputScaleBias
{
	public:
	    float Scale; // 0x0 Size: 0x4
	    float Bias; // 0x4 Size: 0x4

};

struct FComponentSpacePoseLink : public FPoseLinkBase
{
	public:
	    char UnknownData0[0x10];

};

struct FKeyHandleMap
{
	public:
	    char UnknownData0[0x60];

};

struct FIndexedCurve
{
	public:
	    struct FKeyHandleMap KeyHandlesToIndices; // 0x8 Size: 0x60

};

struct FRealCurve : public FIndexedCurve
{
	public:
	    char PreInfinityExtrap; // 0x68 Size: 0x1
	    char PostInfinityExtrap; // 0x69 Size: 0x1
	    char UnknownData0[0x2]; // 0x6a
	    float DefaultValue; // 0x6c Size: 0x4

};

struct FRichCurveKey
{
	public:
	    char InterpMode; // 0x0 Size: 0x1
	    char TangentMode; // 0x1 Size: 0x1
	    char TangentWeightMode; // 0x2 Size: 0x1
	    char UnknownData0[0x1]; // 0x3
	    float Time; // 0x4 Size: 0x4
	    float Value; // 0x8 Size: 0x4
	    float ArriveTangent; // 0xc Size: 0x4
	    float ArriveTangentWeight; // 0x10 Size: 0x4
	    float LeaveTangent; // 0x14 Size: 0x4
	    float LeaveTangentWeight; // 0x18 Size: 0x4

};

struct FMaterialParameterInfo
{
	public:
	    FName Name; // 0x0 Size: 0x8
	    char Association; // 0x8 Size: 0x1
	    char UnknownData0[0x3]; // 0x9
	    int Index; // 0xc Size: 0x4

};

struct FTextureParameterValue
{
	public:
	    struct FMaterialParameterInfo ParameterInfo; // 0x0 Size: 0x10
	    class UTexture* ParameterValue; // 0x10 Size: 0x8
	    struct FGuid ExpressionGUID; // 0x18 Size: 0x10

};

struct FVectorParameterValue
{
	public:
	    struct FMaterialParameterInfo ParameterInfo; // 0x0 Size: 0x10
	    struct FLinearColor ParameterValue; // 0x10 Size: 0x10
	    struct FGuid ExpressionGUID; // 0x20 Size: 0x10

};

struct FScalarParameterValue
{
	public:
	    struct FMaterialParameterInfo ParameterInfo; // 0x0 Size: 0x10
	    float ParameterValue; // 0x10 Size: 0x4
	    struct FGuid ExpressionGUID; // 0x14 Size: 0x10

};

struct FCachedAnimStateData
{
	public:
	    FName StateMachineName; // 0x0 Size: 0x8
	    FName StateName; // 0x8 Size: 0x8
	    char UnknownData0[0xc];

};

struct FBoneReference
{
	public:
	    FName BoneName; // 0x0 Size: 0x8
	    char UnknownData0[0x8];

};

struct FExponentialHeightFogData
{
	public:
	    float FogDensity; // 0x0 Size: 0x4
	    float FogHeightFalloff; // 0x4 Size: 0x4
	    float FogHeightOffset; // 0x8 Size: 0x4

};

struct FParticleSysParam
{
	public:
	    FName Name; // 0x0 Size: 0x8
	    char ParamType; // 0x8 Size: 0x1
	    char UnknownData0[0x3]; // 0x9
	    float Scalar; // 0xc Size: 0x4
	    float Scalar_Low; // 0x10 Size: 0x4
	    struct FVector Vector; // 0x14 Size: 0xc
	    struct FVector Vector_Low; // 0x20 Size: 0xc
	    struct FColor Color; // 0x2c Size: 0x4
	    class AActor* Actor; // 0x30 Size: 0x8
	    class UMaterialInterface* Material; // 0x38 Size: 0x8
	    char UnknownData1[0x40];

};

struct FLightingChannels
{
	public:
	    bool bChannel0; // 0x0 Size: 0x1
	    bool bChannel1; // 0x0 Size: 0x1
	    bool bChannel2; // 0x0 Size: 0x1
	    char UnknownData0[0x-2];

};

struct FAnimNode_AssetPlayerBase : public FAnimNode_Base
{
	public:
	    int GroupIndex; // 0x10 Size: 0x4
	    char GroupRole; // 0x14 Size: 0x1
	    bool bIgnoreForRelevancyTest; // 0x15 Size: 0x1
	    char UnknownData0[0x2]; // 0x16
	    float BlendWeight; // 0x18 Size: 0x4
	    float InternalTimeAccumulator; // 0x1c Size: 0x4
	    char UnknownData1[0x10];

};

struct FPerBoneBlendWeight
{
	public:
	    int SourceIndex; // 0x0 Size: 0x4
	    float BlendWeight; // 0x4 Size: 0x4

};

struct FAnimCurveParam
{
	public:
	    FName Name; // 0x0 Size: 0x8
	    char UnknownData0[0x4];

};

struct FDirectoryPath
{
	public:
	    struct FString Path; // 0x0 Size: 0x10

};

struct FKShapeElem
{
	public:
	    float RestOffset; // 0x8 Size: 0x4
	    FName Name; // 0xc Size: 0x8
	    bool bContributeToMass; // 0x18 Size: 0x1
	    char UnknownData0[0x1b];

};

struct FKTaperedCapsuleElem : public FKShapeElem
{
	public:
	    struct FVector Center; // 0x30 Size: 0xc
	    struct FRotator Rotation; // 0x3c Size: 0xc
	    float Radius0; // 0x48 Size: 0x4
	    float Radius1; // 0x4c Size: 0x4
	    float Length; // 0x50 Size: 0x4
	    char UnknownData0[0x4];

};

struct FKSphylElem : public FKShapeElem
{
	public:
	    struct FVector Center; // 0x30 Size: 0xc
	    struct FRotator Rotation; // 0x3c Size: 0xc
	    float Radius; // 0x48 Size: 0x4
	    float Length; // 0x4c Size: 0x4

};

struct FKBoxElem : public FKShapeElem
{
	public:
	    struct FVector Center; // 0x30 Size: 0xc
	    struct FRotator Rotation; // 0x3c Size: 0xc
	    float X; // 0x48 Size: 0x4
	    float Y; // 0x4c Size: 0x4
	    float Z; // 0x50 Size: 0x4
	    char UnknownData0[0x4];

};

struct FKSphereElem : public FKShapeElem
{
	public:
	    struct FVector Center; // 0x30 Size: 0xc
	    float Radius; // 0x3c Size: 0x4

};

struct FAnimationGroupReference
{
	public:
	    FName GroupName; // 0x0 Size: 0x8
	    char GroupRole; // 0x8 Size: 0x1
	    char UnknownData0[0x3];

};

struct FRootMotionMovementParams
{
	public:
	    bool bHasRootMotion; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float BlendWeight; // 0x4 Size: 0x4
	    char UnknownData1[0x8]; // 0x8
	    struct FTransform RootMotionTransform; // 0x10 Size: 0x30

};

struct FAnimGroupInstance
{
	public:
	    char UnknownData0[0x70];

};

struct FAnimTickRecord
{
	public:
	    class UAnimationAsset* SourceAsset; // 0x0 Size: 0x8
	    char UnknownData0[0x40];

};

struct FMarkerSyncAnimPosition
{
	public:
	    FName PreviousMarkerName; // 0x0 Size: 0x8
	    FName NextMarkerName; // 0x8 Size: 0x8
	    float PositionBetweenMarkers; // 0x10 Size: 0x4

};

struct FBlendFilter
{
	public:
	    char UnknownData0[0x78];

};

struct FBlendSampleData
{
	public:
	    int SampleDataIndex; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    class UAnimSequence* Animation; // 0x8 Size: 0x8
	    float TotalWeight; // 0x10 Size: 0x4
	    float Time; // 0x14 Size: 0x4
	    float PreviousTime; // 0x18 Size: 0x4
	    float SamplePlayRate; // 0x1c Size: 0x4
	    char UnknownData1[0x20];

};

struct FAnimationRecordingSettings
{
	public:
	    bool bRecordInWorldSpace; // 0x0 Size: 0x1
	    bool bRemoveRootAnimation; // 0x1 Size: 0x1
	    bool bAutoSaveAsset; // 0x2 Size: 0x1
	    char UnknownData0[0x1]; // 0x3
	    float SampleRate; // 0x4 Size: 0x4
	    float Length; // 0x8 Size: 0x4
	    char InterpMode; // 0xc Size: 0x1
	    char TangentMode; // 0xd Size: 0x1
	    char UnknownData1[0x2];

};

struct FNamedTransform
{
	public:
	    struct FTransform Value; // 0x0 Size: 0x30
	    FName Name; // 0x30 Size: 0x8
	    char UnknownData0[0x8];

};

struct FNamedColor
{
	public:
	    struct FColor Value; // 0x0 Size: 0x4
	    FName Name; // 0x4 Size: 0x8

};

struct FNamedVector
{
	public:
	    struct FVector Value; // 0x0 Size: 0xc
	    FName Name; // 0xc Size: 0x8

};

struct FNamedFloat
{
	public:
	    float Value; // 0x0 Size: 0x4
	    FName Name; // 0x4 Size: 0x8

};

struct FAnimParentNodeAssetOverride
{
	public:
	    class UAnimationAsset* NewAsset; // 0x0 Size: 0x8
	    struct FGuid ParentNodeGuid; // 0x8 Size: 0x10

};

struct FAnimGroupInfo
{
	public:
	    FName Name; // 0x0 Size: 0x8
	    struct FLinearColor Color; // 0x8 Size: 0x10

};

struct FAnimBlueprintDebugData
{
	public:
	    char UnknownData0[0x1];

};

struct FAnimationFrameSnapshot
{
	public:
	    char UnknownData0[0x1];

};

struct FStateMachineDebugData
{
	public:
	    char UnknownData0[0xb0];

};

struct FAnimSegment
{
	public:
	    class UAnimSequenceBase* AnimReference; // 0x0 Size: 0x8
	    float StartPos; // 0x8 Size: 0x4
	    float AnimStartTime; // 0xc Size: 0x4
	    float AnimEndTime; // 0x10 Size: 0x4
	    float AnimPlayRate; // 0x14 Size: 0x4
	    int LoopingCount; // 0x18 Size: 0x4
	    char UnknownData0[0x4];

};

struct FRootMotionExtractionStep
{
	public:
	    class UAnimSequence* AnimSequence; // 0x0 Size: 0x8
	    float StartPosition; // 0x8 Size: 0x4
	    float EndPosition; // 0xc Size: 0x4

};

struct FSmartName
{
	public:
	    FName DisplayName; // 0x0 Size: 0x8
	    char UnknownData0[0x4];

};

struct FAnimCurveBase
{
	public:
	    FName LastObservedName; // 0x0 Size: 0x8
	    struct FSmartName Name; // 0x8 Size: 0xc
	    int CurveTypeFlags; // 0x14 Size: 0x4

};

struct FSlotEvaluationPose
{
	public:
	    char AdditiveType; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float Weight; // 0x4 Size: 0x4
	    char UnknownData1[0x38];

};

struct FQueuedDrawDebugItem
{
	public:
	    char ItemType; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    struct FVector StartLoc; // 0x4 Size: 0xc
	    struct FVector EndLoc; // 0x10 Size: 0xc
	    struct FVector Center; // 0x1c Size: 0xc
	    struct FRotator Rotation; // 0x28 Size: 0xc
	    float Radius; // 0x34 Size: 0x4
	    float Size; // 0x38 Size: 0x4
	    int Segments; // 0x3c Size: 0x4
	    struct FColor Color; // 0x40 Size: 0x4
	    bool bPersistentLines; // 0x44 Size: 0x1
	    char UnknownData1[0x3]; // 0x45
	    float LifeTime; // 0x48 Size: 0x4
	    float Thickness; // 0x4c Size: 0x4
	    struct FString MESSAGE; // 0x50 Size: 0x10
	    struct FVector2D TextScale; // 0x60 Size: 0x8

};

struct FAnimLinkableElement
{
	public:
	    class UAnimMontage* LinkedMontage; // 0x8 Size: 0x8
	    int SlotIndex; // 0x10 Size: 0x4
	    int SegmentIndex; // 0x14 Size: 0x4
	    char LinkMethod; // 0x18 Size: 0x1
	    char CachedLinkMethod; // 0x19 Size: 0x1
	    char UnknownData0[0x2]; // 0x1a
	    float SegmentBeginTime; // 0x1c Size: 0x4
	    float SegmentLength; // 0x20 Size: 0x4
	    float LinkValue; // 0x24 Size: 0x4
	    class UAnimSequenceBase* LinkedSequence; // 0x28 Size: 0x8

};

struct FAnimNotifyEvent : public FAnimLinkableElement
{
	public:
	    float DisplayTime; // 0x30 Size: 0x4
	    float TriggerTimeOffset; // 0x34 Size: 0x4
	    float EndTriggerTimeOffset; // 0x38 Size: 0x4
	    float TriggerWeightThreshold; // 0x3c Size: 0x4
	    FName NotifyName; // 0x40 Size: 0x8
	    class UAnimNotify* Notify; // 0x48 Size: 0x8
	    class UAnimNotifyState* NotifyStateClass; // 0x50 Size: 0x8
	    float Duration; // 0x58 Size: 0x4
	    char UnknownData0[0x4]; // 0x5c
	    struct FAnimLinkableElement EndLink; // 0x60 Size: 0x30
	    bool bConvertedFromBranchingPoint; // 0x90 Size: 0x1
	    char MontageTickType; // 0x91 Size: 0x1
	    char UnknownData1[0x2]; // 0x92
	    float NotifyTriggerChance; // 0x94 Size: 0x4
	    char NotifyFilterType; // 0x98 Size: 0x1
	    char UnknownData2[0x3]; // 0x99
	    int NotifyFilterLOD; // 0x9c Size: 0x4
	    bool bTriggerOnDedicatedServer; // 0xa0 Size: 0x1
	    bool bTriggerOnFollower; // 0xa1 Size: 0x1
	    char UnknownData3[0x2]; // 0xa2
	    int TrackIndex; // 0xa4 Size: 0x4
	    char UnknownData4[0x10];

};

struct FBranchingPointMarker
{
	public:
	    int NotifyIndex; // 0x0 Size: 0x4
	    float TriggerTime; // 0x4 Size: 0x4
	    char NotifyEventType; // 0x8 Size: 0x1
	    char UnknownData0[0x3];

};

struct FBranchingPoint : public FAnimLinkableElement
{
	public:
	    FName EventName; // 0x30 Size: 0x8
	    float DisplayTime; // 0x38 Size: 0x4
	    float TriggerTimeOffset; // 0x3c Size: 0x4

};

struct FAnimNode_ApplyMeshSpaceAdditive : public FAnimNode_Base
{
	public:
	    struct FPoseLink Base; // 0x10 Size: 0x10
	    struct FPoseLink Additive; // 0x20 Size: 0x10
	    float Alpha; // 0x30 Size: 0x4
	    struct FInputScaleBias AlphaScaleBias; // 0x34 Size: 0x8
	    int LODThreshold; // 0x3c Size: 0x4
	    char UnknownData0[0x8];

};

struct FAnimNode_SaveCachedPose : public FAnimNode_Base
{
	public:
	    struct FPoseLink Pose; // 0x10 Size: 0x10
	    FName CachePoseName; // 0x20 Size: 0x8
	    char UnknownData0[0x90];

};

struct FAnimNode_SequencePlayer : public FAnimNode_AssetPlayerBase
{
	public:
	    class UAnimSequenceBase* Sequence; // 0x30 Size: 0x8
	    float PlayRateBasis; // 0x38 Size: 0x4
	    float PlayRate; // 0x3c Size: 0x4
	    struct FInputScaleBiasClamp PlayRateScaleBiasClamp; // 0x40 Size: 0x30
	    float StartPosition; // 0x70 Size: 0x4
	    bool bLoopAnimation; // 0x74 Size: 0x1
	    char UnknownData0[0x3];

};

struct FAnimNode_StateMachine : public FAnimNode_Base
{
	public:
	    int StateMachineIndexInClass; // 0x10 Size: 0x4
	    int MaxTransitionsPerFrame; // 0x14 Size: 0x4
	    bool bSkipFirstUpdateTransition; // 0x18 Size: 0x1
	    bool bReinitializeOnBecomingRelevant; // 0x19 Size: 0x1
	    char UnknownData0[0x96];

};

struct FAnimationPotentialTransition
{
	public:
	    char UnknownData0[0x30];

};

struct FAnimationActiveTransitionEntry
{
	public:
	    class UBlendProfile* BlendProfile; // 0xb8 Size: 0x8
	    char UnknownData0[0x8];

};

struct FAnimNode_SubInput : public FAnimNode_Base
{
	public:
	    char UnknownData0[0x48];

};

struct FAnimNode_TransitionPoseEvaluator : public FAnimNode_Base
{
	public:
	    char UnknownData0[0x38];
	    int FramesToCachePose; // 0x48 Size: 0x4
	    char UnknownData1[0x4]; // 0x4c
	    char DataSource; // 0x50 Size: 0x1
	    char EvaluatorMode; // 0x51 Size: 0x1
	    char UnknownData2[0x6];

};

struct FAnimNode_TransitionResult : public FAnimNode_Base
{
	public:
	    bool bCanEnterTransition; // 0x10 Size: 0x1
	    char UnknownData0[0x17];

};

struct FAnimNode_UseCachedPose : public FAnimNode_Base
{
	public:
	    struct FPoseLink LinkToCachingNode; // 0x10 Size: 0x10
	    FName CachePoseName; // 0x20 Size: 0x8

};

struct FExposedValueCopyRecord
{
	public:
	    FName SourcePropertyName; // 0x0 Size: 0x8
	    FName SourceSubPropertyName; // 0x8 Size: 0x8
	    int SourceArrayIndex; // 0x10 Size: 0x4
	    bool bInstanceIsTarget; // 0x14 Size: 0x1
	    EPostCopyOperation PostCopyOperation; // 0x15 Size: 0x1
	    ECopyType CopyType; // 0x16 Size: 0x1
	    char UnknownData0[0x1]; // 0x17
	    class UProperty* DestProperty; // 0x18 Size: 0x8
	    int DestArrayIndex; // 0x20 Size: 0x4
	    int Size; // 0x24 Size: 0x4
	    class UProperty* CachedSourceProperty; // 0x28 Size: 0x8
	    class UProperty* CachedSourceStructSubProperty; // 0x30 Size: 0x8

};

struct FAnimNode_ConvertLocalToComponentSpace : public FAnimNode_Base
{
	public:
	    struct FPoseLink LocalPose; // 0x10 Size: 0x10

};

struct FAnimNode_ConvertComponentToLocalSpace : public FAnimNode_Base
{
	public:
	    struct FComponentSpacePoseLink ComponentPose; // 0x10 Size: 0x10

};

struct FAnimNotifyEventReference
{
	public:
	    class UObject* NotifySource; // 0x8 Size: 0x8

};

struct FCompressedSegment
{
	public:
	    char UnknownData0[0x10];

};

struct FTrackToSkeletonMap
{
	public:
	    int BoneTreeIndex; // 0x0 Size: 0x4

};

struct FAnimSingleNodeInstanceProxy : public FAnimInstanceProxy
{
	public:
	    char UnknownData0[0x850];

};

struct FAnimNode_SingleNode : public FAnimNode_Base
{
	public:
	    struct FPoseLink SourcePose; // 0x10 Size: 0x10
	    char UnknownData0[0x10];

};

struct FAnimationStateBase
{
	public:
	    FName StateName; // 0x0 Size: 0x8

};

struct FAnimationTransitionBetweenStates : public FAnimationStateBase
{
	public:
	    int PreviousState; // 0x8 Size: 0x4
	    int NextState; // 0xc Size: 0x4
	    float CrossfadeDuration; // 0x10 Size: 0x4
	    int StartNotify; // 0x14 Size: 0x4
	    int EndNotify; // 0x18 Size: 0x4
	    int InterruptNotify; // 0x1c Size: 0x4
	    EAlphaBlendOption BlendMode; // 0x20 Size: 0x1
	    char UnknownData0[0x7]; // 0x21
	    class UCurveFloat* CustomCurve; // 0x28 Size: 0x8
	    class UBlendProfile* BlendProfile; // 0x30 Size: 0x8
	    char LogicType; // 0x38 Size: 0x1
	    char UnknownData1[0x7];

};

struct FAnimationTransitionRule
{
	public:
	    FName RuleToExecute; // 0x0 Size: 0x8
	    bool TransitionReturnVal; // 0x8 Size: 0x1
	    char UnknownData0[0x3]; // 0x9
	    int TransitionIndex; // 0xc Size: 0x4

};

struct FAnimSyncMarker
{
	public:
	    FName MarkerName; // 0x0 Size: 0x8
	    float Time; // 0x8 Size: 0x4

};

struct FAnimNotifyTrack
{
	public:
	    FName TrackName; // 0x0 Size: 0x8
	    struct FLinearColor TrackColor; // 0x8 Size: 0x10
	    char UnknownData0[0x20];

};

struct FAssetImportInfo
{
	public:
	    char UnknownData0[0x1];

};

struct FPrimaryAssetRules
{
	public:
	    int Priority; // 0x0 Size: 0x4
	    bool bApplyRecursively; // 0x4 Size: 0x1
	    char UnknownData0[0x3]; // 0x5
	    int ChunkId; // 0x8 Size: 0x4
	    EPrimaryAssetCookRule CookRule; // 0xc Size: 0x1
	    char UnknownData1[0x3];

};

struct FPrimaryAssetRulesCustomOverride
{
	public:
	    struct FPrimaryAssetType PrimaryAssetType; // 0x0 Size: 0x8
	    struct FDirectoryPath FilterDirectory; // 0x8 Size: 0x10
	    struct FString FilterString; // 0x18 Size: 0x10
	    struct FPrimaryAssetRules Rules; // 0x28 Size: 0x10

};

struct FPrimaryAssetRulesOverride
{
	public:
	    struct FPrimaryAssetId PrimaryAssetId; // 0x0 Size: 0x10
	    struct FPrimaryAssetRules Rules; // 0x10 Size: 0x10

};

struct FAssetManagerRedirect
{
	public:
	    struct FString Old; // 0x0 Size: 0x10
	    struct FString New; // 0x10 Size: 0x10

};

struct FAssetMapping
{
	public:
	    class UAnimationAsset* SourceAsset; // 0x0 Size: 0x8
	    class UAnimationAsset* TargetAsset; // 0x8 Size: 0x8

};

struct FAtmospherePrecomputeParameters
{
	public:
	    float DensityHeight; // 0x0 Size: 0x4
	    float DecayHeight; // 0x4 Size: 0x4
	    int MaxScatteringOrder; // 0x8 Size: 0x4
	    int TransmittanceTexWidth; // 0xc Size: 0x4
	    int TransmittanceTexHeight; // 0x10 Size: 0x4
	    int IrradianceTexWidth; // 0x14 Size: 0x4
	    int IrradianceTexHeight; // 0x18 Size: 0x4
	    int InscatterAltitudeSampleNum; // 0x1c Size: 0x4
	    int InscatterMuNum; // 0x20 Size: 0x4
	    int InscatterMuSNum; // 0x24 Size: 0x4
	    int InscatterNuNum; // 0x28 Size: 0x4

};

struct FAudioComponentParam
{
	public:
	    FName ParamName; // 0x0 Size: 0x8
	    float FloatParam; // 0x8 Size: 0x4
	    bool BoolParam; // 0xc Size: 0x1
	    char UnknownData0[0x3]; // 0xd
	    int IntParam; // 0x10 Size: 0x4
	    char UnknownData1[0x4]; // 0x14
	    class USoundWave* SoundWaveParam; // 0x18 Size: 0x8

};

struct FAudioQualitySettings
{
	public:
	    struct FText DisplayName; // 0x0 Size: 0x18
	    int MaxChannels; // 0x18 Size: 0x4
	    char UnknownData0[0x4];

};

struct FInteriorSettings
{
	public:
	    bool bIsWorldSettings; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float ExteriorVolume; // 0x4 Size: 0x4
	    float ExteriorTime; // 0x8 Size: 0x4
	    float ExteriorLPF; // 0xc Size: 0x4
	    float ExteriorLPFTime; // 0x10 Size: 0x4
	    float InteriorVolume; // 0x14 Size: 0x4
	    float InteriorTime; // 0x18 Size: 0x4
	    float InteriorLPF; // 0x1c Size: 0x4
	    float InteriorLPFTime; // 0x20 Size: 0x4

};

struct FReverbSettings
{
	public:
	    bool bApplyReverb; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class UReverbEffect* ReverbEffect; // 0x8 Size: 0x8
	    class USoundEffectSubmixPreset* ReverbPluginEffect; // 0x10 Size: 0x8
	    float Volume; // 0x18 Size: 0x4
	    float FadeTime; // 0x1c Size: 0x4

};

struct FFilePath
{
	public:
	    struct FString FilePath; // 0x0 Size: 0x10

};

struct FLaunchOnTestSettings
{
	public:
	    struct FFilePath LaunchOnTestmap; // 0x0 Size: 0x10
	    struct FString DeviceID; // 0x10 Size: 0x10

};

struct FEditorMapPerformanceTestDefinition
{
	public:
	    struct FSoftObjectPath PerformanceTestmap; // 0x0 Size: 0x18
	    int TestTimer; // 0x18 Size: 0x4
	    char UnknownData0[0x4];

};

struct FBuildPromotionNewProjectSettings
{
	public:
	    struct FDirectoryPath NewProjectFolderOverride; // 0x0 Size: 0x10
	    struct FString NewProjectNameOverride; // 0x10 Size: 0x10

};

struct FBuildPromotionOpenAssetSettings
{
	public:
	    struct FFilePath BlueprintAsset; // 0x0 Size: 0x10
	    struct FFilePath MaterialAsset; // 0x10 Size: 0x10
	    struct FFilePath ParticleSystemAsset; // 0x20 Size: 0x10
	    struct FFilePath SkeletalMeshAsset; // 0x30 Size: 0x10
	    struct FFilePath StaticMeshAsset; // 0x40 Size: 0x10
	    struct FFilePath TextureAsset; // 0x50 Size: 0x10

};

struct FImportFactorySettingValues
{
	public:
	    struct FString SettingName; // 0x0 Size: 0x10
	    struct FString Value; // 0x10 Size: 0x10

};

struct FBlueprintEditorPromotionSettings
{
	public:
	    struct FFilePath FirstMeshPath; // 0x0 Size: 0x10
	    struct FFilePath SecondMeshPath; // 0x10 Size: 0x10
	    struct FFilePath DefaultParticleAsset; // 0x20 Size: 0x10

};

struct FParticleEditorPromotionSettings
{
	public:
	    struct FFilePath DefaultParticleAsset; // 0x0 Size: 0x10

};

struct FMaterialEditorPromotionSettings
{
	public:
	    struct FFilePath DefaultMaterialAsset; // 0x0 Size: 0x10
	    struct FFilePath DefaultDiffuseTexture; // 0x10 Size: 0x10
	    struct FFilePath DefaultNormalTexture; // 0x20 Size: 0x10

};

struct FExternalToolDefinition
{
	public:
	    struct FString ToolName; // 0x0 Size: 0x10
	    struct FFilePath ExecutablePath; // 0x10 Size: 0x10
	    struct FString CommandLineOptions; // 0x20 Size: 0x10
	    struct FDirectoryPath WorkingDirectory; // 0x30 Size: 0x10
	    struct FString ScriptExtension; // 0x40 Size: 0x10
	    struct FDirectoryPath ScriptDirectory; // 0x50 Size: 0x10

};

struct FNavAvoidanceData
{
	public:
	    char UnknownData0[0x3c];

};

struct FBlendProfileBoneEntry
{
	public:
	    struct FBoneReference BoneReference; // 0x0 Size: 0x10
	    float BlendScale; // 0x10 Size: 0x4

};

struct FPerBoneInterpolation
{
	public:
	    struct FBoneReference BoneReference; // 0x0 Size: 0x10
	    float InterpolationSpeedPerSec; // 0x10 Size: 0x4

};

struct FEditorElement
{
	public:
	    int Indices; // 0x0 Size: 0x4
	    char UnknownData0[0x8]; // 0x4
	    float Weights; // 0xc Size: 0x4
	    char UnknownData1[0x8];

};

struct FGridBlendSample
{
	public:
	    struct FEditorElement GridElement; // 0x0 Size: 0x18
	    float BlendWeight; // 0x18 Size: 0x4

};

struct FBlendSample
{
	public:
	    class UAnimSequence* Animation; // 0x0 Size: 0x8
	    struct FVector SampleValue; // 0x8 Size: 0xc
	    float RateScale; // 0x14 Size: 0x4

};

struct FBlendParameter
{
	public:
	    struct FString DisplayName; // 0x0 Size: 0x10
	    float Min; // 0x10 Size: 0x4
	    float Max; // 0x14 Size: 0x4
	    int GridNum; // 0x18 Size: 0x4
	    char UnknownData0[0x4];

};

struct FInterpolationParameter
{
	public:
	    float InterpolationTime; // 0x0 Size: 0x4
	    char InterpolationType; // 0x4 Size: 0x1
	    char UnknownData0[0x3];

};

struct FBPEditorBookmarkNode
{
	public:
	    struct FGuid NodeGuid; // 0x0 Size: 0x10
	    struct FGuid ParentGuid; // 0x10 Size: 0x10
	    struct FText DisplayName; // 0x20 Size: 0x18

};

struct FEditedDocumentInfo
{
	public:
	    struct FSoftObjectPath EditedObjectPath; // 0x0 Size: 0x18
	    struct FVector2D SavedViewOffset; // 0x18 Size: 0x8
	    float SavedZoomAmount; // 0x20 Size: 0x4
	    char UnknownData0[0x4]; // 0x24
	    class UObject* EditedObject; // 0x28 Size: 0x8

};

struct FBPVariableMetaDataEntry
{
	public:
	    FName DataKey; // 0x0 Size: 0x8
	    struct FString DataValue; // 0x8 Size: 0x10

};

struct FEdGraphTerminalType
{
	public:
	    FName TerminalCategory; // 0x0 Size: 0x8
	    FName TerminalSubCategory; // 0x8 Size: 0x8
	    TWeakObjectPtr<UObject*> TerminalSubCategoryObject; // 0x10 Size: 0x8
	    bool bTerminalIsConst; // 0x18 Size: 0x1
	    bool bTerminalIsWeakPointer; // 0x19 Size: 0x1
	    char UnknownData0[0x2];

};

struct FEdGraphPinType
{
	public:
	    FName PinCategory; // 0x0 Size: 0x8
	    FName PinSubCategory; // 0x8 Size: 0x8
	    TWeakObjectPtr<UObject*> PinSubCategoryObject; // 0x10 Size: 0x8
	    struct FSimpleMemberReference PinSubCategoryMemberReference; // 0x18 Size: 0x20
	    struct FEdGraphTerminalType PinValueType; // 0x38 Size: 0x1c
	    EPinContainerType ContainerType; // 0x54 Size: 0x1
	    bool bIsArray; // 0x55 Size: 0x1
	    bool bIsReference; // 0x55 Size: 0x1
	    bool bIsConst; // 0x55 Size: 0x1
	    bool bIsWeakPointer; // 0x55 Size: 0x1
	    char UnknownData0[0x-1];

};

struct FBlueprintMacroCosmeticInfo
{
	public:
	    char UnknownData0[0x1];

};

struct FBlueprintComponentChangedPropertyInfo
{
	public:
	    FName PropertyName; // 0x0 Size: 0x8
	    int ArrayIndex; // 0x8 Size: 0x4
	    char UnknownData0[0x4]; // 0xc
	    class UStruct* PropertyScope; // 0x10 Size: 0x8

};

struct FEventGraphFastCallPair
{
	public:
	    class UFunction* FunctionToPatch; // 0x0 Size: 0x8
	    int EventGraphCallOffset; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FBlueprintDebugData
{
	public:
	    char UnknownData0[0x1];

};

struct FPointerToUberGraphFrame
{
	public:
	    char UnknownData0[0x8];

};

struct FDebuggingInfoForSingleFunction
{
	public:
	    char UnknownData0[0x190];

};

struct FNodeToCodeAssociation
{
	public:
	    char UnknownData0[0x14];

};

struct FWalkableSlopeOverride
{
	public:
	    char WalkableSlopeBehavior; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float WalkableSlopeAngle; // 0x4 Size: 0x4
	    char UnknownData1[0x8];

};

struct FResponseChannel
{
	public:
	    FName Channel; // 0x0 Size: 0x8
	    char Response; // 0x8 Size: 0x1
	    char UnknownData0[0x3];

};

struct FCollisionResponseContainer
{
	public:
	    char WorldStatic; // 0x0 Size: 0x1
	    char WorldDynamic; // 0x1 Size: 0x1
	    char Pawn; // 0x2 Size: 0x1
	    char Visibility; // 0x3 Size: 0x1
	    char Camera; // 0x4 Size: 0x1
	    char PhysicsBody; // 0x5 Size: 0x1
	    char Vehicle; // 0x6 Size: 0x1
	    char Destructible; // 0x7 Size: 0x1
	    char EngineTraceChannel1; // 0x8 Size: 0x1
	    char EngineTraceChannel2; // 0x9 Size: 0x1
	    char EngineTraceChannel3; // 0xa Size: 0x1
	    char EngineTraceChannel4; // 0xb Size: 0x1
	    char EngineTraceChannel5; // 0xc Size: 0x1
	    char EngineTraceChannel6; // 0xd Size: 0x1
	    char GameTraceChannel1; // 0xe Size: 0x1
	    char GameTraceChannel2; // 0xf Size: 0x1
	    char GameTraceChannel3; // 0x10 Size: 0x1
	    char GameTraceChannel4; // 0x11 Size: 0x1
	    char GameTraceChannel5; // 0x12 Size: 0x1
	    char GameTraceChannel6; // 0x13 Size: 0x1
	    char GameTraceChannel7; // 0x14 Size: 0x1
	    char GameTraceChannel8; // 0x15 Size: 0x1
	    char GameTraceChannel9; // 0x16 Size: 0x1
	    char GameTraceChannel10; // 0x17 Size: 0x1
	    char GameTraceChannel11; // 0x18 Size: 0x1
	    char GameTraceChannel12; // 0x19 Size: 0x1
	    char GameTraceChannel13; // 0x1a Size: 0x1
	    char GameTraceChannel14; // 0x1b Size: 0x1
	    char GameTraceChannel15; // 0x1c Size: 0x1
	    char GameTraceChannel16; // 0x1d Size: 0x1
	    char GameTraceChannel17; // 0x1e Size: 0x1
	    char GameTraceChannel18; // 0x1f Size: 0x1

};

struct FAnimCurveType
{
	public:
	    char UnknownData0[0x2];

};

struct FBookmarkBaseJumpToSettings
{
	public:
	    char UnknownData0[0x1];

};

struct FBookmarkJumpToSettings : public FBookmarkBaseJumpToSettings
{
	public:
	    char UnknownData0[0x1];

};

struct FBookmark2DJumpToSettings
{
	public:
	    char UnknownData0[0x1];

};

struct FGeomSelection
{
	public:
	    int Type; // 0x0 Size: 0x4
	    int Index; // 0x4 Size: 0x4
	    int SelectionIndex; // 0x8 Size: 0x4

};

struct FCachedAnimTransitionData
{
	public:
	    FName StateMachineName; // 0x0 Size: 0x8
	    FName FromStateName; // 0x8 Size: 0x8
	    FName ToStateName; // 0x10 Size: 0x8
	    char UnknownData0[0xc];

};

struct FCachedAnimRelevancyData
{
	public:
	    FName StateMachineName; // 0x0 Size: 0x8
	    FName StateName; // 0x8 Size: 0x8
	    char UnknownData0[0xc];

};

struct FCachedAnimAssetPlayerData
{
	public:
	    FName StateMachineName; // 0x0 Size: 0x8
	    FName StateName; // 0x8 Size: 0x8
	    char UnknownData0[0x8];

};

struct FFOscillator
{
	public:
	    float Amplitude; // 0x0 Size: 0x4
	    float Frequency; // 0x4 Size: 0x4
	    char InitialOffset; // 0x8 Size: 0x1
	    EOscillatorWaveform Waveform; // 0x9 Size: 0x1
	    char UnknownData0[0x2];

};

struct FVOscillator
{
	public:
	    struct FFOscillator X; // 0x0 Size: 0xc
	    struct FFOscillator Y; // 0xc Size: 0xc
	    struct FFOscillator Z; // 0x18 Size: 0xc

};

struct FROscillator
{
	public:
	    struct FFOscillator Pitch; // 0x0 Size: 0xc
	    struct FFOscillator Yaw; // 0xc Size: 0xc
	    struct FFOscillator Roll; // 0x18 Size: 0xc

};

struct FDummySpacerCameraTypes
{
	public:
	    char UnknownData0[0x1];

};

struct FWeightedBlendable
{
	public:
	    float Weight; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    class UObject* Object; // 0x8 Size: 0x8

};

struct FCanvasIcon
{
	public:
	    class UTexture* Texture; // 0x0 Size: 0x8
	    float U; // 0x8 Size: 0x4
	    float V; // 0xc Size: 0x4
	    float UL; // 0x10 Size: 0x4
	    float VL; // 0x14 Size: 0x4

};

struct FWrappedStringElement
{
	public:
	    struct FString Value; // 0x0 Size: 0x10
	    struct FVector2D LineExtent; // 0x10 Size: 0x8

};

struct FTextSizingParameters
{
	public:
	    float DrawX; // 0x0 Size: 0x4
	    float DrawY; // 0x4 Size: 0x4
	    float DrawXL; // 0x8 Size: 0x4
	    float DrawYL; // 0xc Size: 0x4
	    struct FVector2D Scaling; // 0x10 Size: 0x8
	    class UFont* DrawFont; // 0x18 Size: 0x8
	    struct FVector2D SpacingAdjust; // 0x20 Size: 0x8

};

struct FBasedMovementInfo
{
	public:
	    class UPrimitiveComponent* MovementBase; // 0x0 Size: 0x8
	    FName BoneName; // 0x8 Size: 0x8
	    struct FVector_NetQuantize100 Location; // 0x10 Size: 0xc
	    struct FRotator Rotation; // 0x1c Size: 0xc
	    bool bServerHasBaseComponent; // 0x28 Size: 0x1
	    bool bRelativeRotation; // 0x29 Size: 0x1
	    bool bServerHasVelocity; // 0x2a Size: 0x1
	    char UnknownData0[0x5];

};

struct FRootMotionSourceSettings
{
	public:
	    char Flags; // 0x0 Size: 0x1

};

struct FRootMotionSourceGroup
{
	public:
	    bool bHasAdditiveSources; // 0xe8 Size: 0x1
	    bool bHasOverrideSources; // 0xe8 Size: 0x1
	    bool bIsAdditiveVelocityApplied; // 0xe8 Size: 0x1
	    Yea, we fucked up; // 0x0
	    struct FRootMotionSourceSettings LastAccumulatedSettings; // 0xe9 Size: 0x1
	    char UnknownData1[0x2]; // 0xea
	    struct FVector_NetQuantize10 LastPreAdditiveVelocity; // 0xec Size: 0xc

};

struct FRepRootMotionMontage
{
	public:
	    bool bIsActive; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class UAnimMontage* AnimMontage; // 0x8 Size: 0x8
	    float Position; // 0x10 Size: 0x4
	    struct FVector_NetQuantize100 Location; // 0x14 Size: 0xc
	    struct FRotator Rotation; // 0x20 Size: 0xc
	    char UnknownData1[0x4]; // 0x2c
	    class UPrimitiveComponent* MovementBase; // 0x30 Size: 0x8
	    FName MovementBaseBoneName; // 0x38 Size: 0x8
	    bool bRelativePosition; // 0x40 Size: 0x1
	    bool bRelativeRotation; // 0x41 Size: 0x1
	    char UnknownData2[0x6]; // 0x42
	    struct FRootMotionSourceGroup AuthoritativeRootMotion; // 0x48 Size: 0xf8
	    struct FVector_NetQuantize10 Acceleration; // 0x140 Size: 0xc
	    struct FVector_NetQuantize10 LinearVelocity; // 0x14c Size: 0xc

};

struct FSimulatedRootMotionReplicatedMove
{
	public:
	    float Time; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    struct FRepRootMotionMontage RootMotion; // 0x8 Size: 0x158

};

struct FCharacterMovementComponentPostPhysicsTickFunction : public FTickFunction
{
	public:
	    char UnknownData0[0x58];

};

struct FFindFloorResult
{
	public:
	    bool bBlockingHit; // 0x0 Size: 0x1
	    bool bWalkableFloor; // 0x0 Size: 0x1
	    bool bLineTrace; // 0x0 Size: 0x1
	    char UnknownData0[0x1]; // 0x3
	    float FloorDist; // 0x4 Size: 0x4
	    float LineDist; // 0x8 Size: 0x4
	    struct FHitResult HitResult; // 0xc Size: 0x88

};

struct FCustomChannelSetup
{
	public:
	    char Channel; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    FName Name; // 0x4 Size: 0x8
	    char DefaultResponse; // 0xc Size: 0x1
	    bool bTraceType; // 0xd Size: 0x1
	    bool bStaticObject; // 0xe Size: 0x1
	    char UnknownData1[0x1];

};

struct FBlueprintComponentDelegateBinding
{
	public:
	    FName ComponentPropertyName; // 0x0 Size: 0x8
	    FName DelegatePropertyName; // 0x8 Size: 0x8
	    FName FunctionNameToBind; // 0x10 Size: 0x8

};

struct FMeshUVChannelInfo
{
	public:
	    bool bInitialized; // 0x0 Size: 0x1
	    bool bOverrideDensities; // 0x1 Size: 0x1
	    char UnknownData0[0x2]; // 0x2
	    float LocalUVDensities; // 0x4 Size: 0x4
	    char UnknownData1[0xc];

};

struct FConstraintDrive
{
	public:
	    float Stiffness; // 0x0 Size: 0x4
	    float Damping; // 0x4 Size: 0x4
	    float MaxForce; // 0x8 Size: 0x4
	    bool bEnablePositionDrive; // 0xc Size: 0x1
	    bool bEnableVelocityDrive; // 0xc Size: 0x1
	    char UnknownData0[0x2];

};

struct FAngularDriveConstraint
{
	public:
	    struct FConstraintDrive TwistDrive; // 0x0 Size: 0x10
	    struct FConstraintDrive SwingDrive; // 0x10 Size: 0x10
	    struct FConstraintDrive SlerpDrive; // 0x20 Size: 0x10
	    struct FRotator OrientationTarget; // 0x30 Size: 0xc
	    struct FVector AngularVelocityTarget; // 0x3c Size: 0xc
	    char AngularDriveMode; // 0x48 Size: 0x1
	    char UnknownData0[0x3];

};

struct FLinearDriveConstraint
{
	public:
	    struct FVector PositionTarget; // 0x0 Size: 0xc
	    struct FVector VelocityTarget; // 0xc Size: 0xc
	    struct FConstraintDrive XDrive; // 0x18 Size: 0x10
	    struct FConstraintDrive YDrive; // 0x28 Size: 0x10
	    struct FConstraintDrive ZDrive; // 0x38 Size: 0x10
	    bool bEnablePositionDrive; // 0x48 Size: 0x1
	    char UnknownData0[0x3];

};

struct FConstraintBaseParams
{
	public:
	    float Stiffness; // 0x0 Size: 0x4
	    float Damping; // 0x4 Size: 0x4
	    float Restitution; // 0x8 Size: 0x4
	    float ContactDistance; // 0xc Size: 0x4
	    bool bSoftConstraint; // 0x10 Size: 0x1
	    char UnknownData0[0x3];

};

struct FTwistConstraint : public FConstraintBaseParams
{
	public:
	    float TwistLimitDegrees; // 0x14 Size: 0x4
	    char TwistMotion; // 0x18 Size: 0x1
	    char UnknownData0[0x3];

};

struct FConeConstraint : public FConstraintBaseParams
{
	public:
	    float Swing1LimitDegrees; // 0x14 Size: 0x4
	    float Swing2LimitDegrees; // 0x18 Size: 0x4
	    char Swing1Motion; // 0x1c Size: 0x1
	    char Swing2Motion; // 0x1d Size: 0x1
	    char UnknownData0[0x2];

};

struct FLinearConstraint : public FConstraintBaseParams
{
	public:
	    float Limit; // 0x14 Size: 0x4
	    char XMotion; // 0x18 Size: 0x1
	    char YMotion; // 0x19 Size: 0x1
	    char ZMotion; // 0x1a Size: 0x1
	    char UnknownData0[0x1];

};

struct FConstraintProfileProperties
{
	public:
	    float ProjectionLinearTolerance; // 0x0 Size: 0x4
	    float ProjectionAngularTolerance; // 0x4 Size: 0x4
	    float LinearBreakThreshold; // 0x8 Size: 0x4
	    float AngularBreakThreshold; // 0xc Size: 0x4
	    struct FLinearConstraint LinearLimit; // 0x10 Size: 0x1c
	    struct FConeConstraint ConeLimit; // 0x2c Size: 0x20
	    struct FTwistConstraint TwistLimit; // 0x4c Size: 0x1c
	    struct FLinearDriveConstraint LinearDrive; // 0x68 Size: 0x4c
	    struct FAngularDriveConstraint AngularDrive; // 0xb4 Size: 0x4c
	    bool bDisableCollision; // 0x100 Size: 0x1
	    bool bParentDominates; // 0x100 Size: 0x1
	    bool bEnableProjection; // 0x100 Size: 0x1
	    bool bAngularBreakable; // 0x100 Size: 0x1
	    bool bLinearBreakable; // 0x100 Size: 0x1
	    char UnknownData0[0x-1];

};

struct FConstraintInstance
{
	public:
	    FName JointName; // 0x18 Size: 0x8
	    FName ConstraintBone1; // 0x20 Size: 0x8
	    FName ConstraintBone2; // 0x28 Size: 0x8
	    struct FVector Pos1; // 0x30 Size: 0xc
	    struct FVector PriAxis1; // 0x3c Size: 0xc
	    struct FVector SecAxis1; // 0x48 Size: 0xc
	    struct FVector Pos2; // 0x54 Size: 0xc
	    struct FVector PriAxis2; // 0x60 Size: 0xc
	    struct FVector SecAxis2; // 0x6c Size: 0xc
	    struct FRotator AngularRotationOffset; // 0x78 Size: 0xc
	    bool bScaleLinearLimits; // 0x84 Size: 0x1
	    char UnknownData0[0x7]; // 0x85
	    struct FConstraintProfileProperties ProfileInstance; // 0x8c Size: 0x104
	    char UnknownData1[0x28];

};

struct FCullDistanceSizePair
{
	public:
	    float Size; // 0x0 Size: 0x4
	    float CullDistance; // 0x4 Size: 0x4

};

struct FNamedCurveValue
{
	public:
	    FName Name; // 0x0 Size: 0x8
	    float Value; // 0x8 Size: 0x4

};

struct FDataTableCategoryHandle
{
	public:
	    class UDataTable* DataTable; // 0x0 Size: 0x8
	    FName ColumnName; // 0x8 Size: 0x8
	    FName RowContents; // 0x10 Size: 0x8

};

struct FDebugDisplayProperty
{
	public:
	    class UObject* Obj; // 0x0 Size: 0x8
	    class UObject* WithinClass; // 0x8 Size: 0x8
	    char UnknownData0[0x10];

};

struct FDebugTextInfo
{
	public:
	    class AActor* SrcActor; // 0x0 Size: 0x8
	    struct FVector SrcActorOffset; // 0x8 Size: 0xc
	    struct FVector SrcActorDesiredOffset; // 0x14 Size: 0xc
	    struct FString DebugText; // 0x20 Size: 0x10
	    float TimeRemaining; // 0x30 Size: 0x4
	    float Duration; // 0x34 Size: 0x4
	    struct FColor TextColor; // 0x38 Size: 0x4
	    bool bAbsoluteLocation; // 0x3c Size: 0x1
	    bool bKeepAttachedToActor; // 0x3c Size: 0x1
	    bool bDrawShadow; // 0x3c Size: 0x1
	    char UnknownData0[0x1]; // 0x3f
	    struct FVector OrigActorLocation; // 0x40 Size: 0xc
	    char UnknownData1[0x4]; // 0x4c
	    class UFont* Font; // 0x50 Size: 0x8
	    float FontScale; // 0x58 Size: 0x4
	    char UnknownData2[0x4];

};

struct FLevelNameAndTime
{
	public:
	    struct FString LevelName; // 0x0 Size: 0x10
	    uint32_t LevelChangeTimeInMS; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FRawDistributionFloat : public FRawDistribution
{
	public:
	    float MinValue; // 0x28 Size: 0x4
	    float MaxValue; // 0x2c Size: 0x4
	    class UDistributionFloat* Distribution; // 0x30 Size: 0x8

};

struct FRawDistributionVector : public FRawDistribution
{
	public:
	    float MinValue; // 0x28 Size: 0x4
	    float MaxValue; // 0x2c Size: 0x4
	    struct FVector MinValueVec; // 0x30 Size: 0xc
	    struct FVector MaxValueVec; // 0x3c Size: 0xc
	    class UDistributionVector* Distribution; // 0x48 Size: 0x8

};

struct FGraphReference
{
	public:
	    class UEdGraph* MacroGraph; // 0x0 Size: 0x8
	    class UBlueprint* GraphBlueprint; // 0x8 Size: 0x8
	    struct FGuid GraphGuid; // 0x10 Size: 0x10

};

struct FEdGraphPinReference
{
	public:
	    TWeakObjectPtr<UEdGraphNode*> OwningNode; // 0x0 Size: 0x8
	    struct FGuid PinId; // 0x8 Size: 0x10

};

struct FEdGraphSchemaAction_NewNode : public FEdGraphSchemaAction
{
	public:
	    class UEdGraphNode* NodeTemplate; // 0x100 Size: 0x8

};

struct FPluginRedirect
{
	public:
	    struct FString OldPluginName; // 0x0 Size: 0x10
	    struct FString NewPluginName; // 0x10 Size: 0x10

};

struct FStructRedirect
{
	public:
	    FName OldStructName; // 0x0 Size: 0x8
	    FName NewStructName; // 0x8 Size: 0x8

};

struct FClassRedirect
{
	public:
	    FName ObjectName; // 0x0 Size: 0x8
	    FName OldClassName; // 0x8 Size: 0x8
	    FName NewClassName; // 0x10 Size: 0x8
	    FName OldSubobjName; // 0x18 Size: 0x8
	    FName NewSubobjName; // 0x20 Size: 0x8
	    FName NewClassClass; // 0x28 Size: 0x8
	    FName NewClassPackage; // 0x30 Size: 0x8
	    bool InstanceOnly; // 0x38 Size: 0x1
	    char UnknownData0[0x3];

};

struct FGameNameRedirect
{
	public:
	    FName OldGameName; // 0x0 Size: 0x8
	    FName NewGameName; // 0x8 Size: 0x8

};

struct FScreenMessageString
{
	public:
	    uint64_t Key; // 0x0 Size: 0x8
	    struct FString ScreenMessage; // 0x8 Size: 0x10
	    struct FColor DisplayColor; // 0x18 Size: 0x4
	    float TimeToDisplay; // 0x1c Size: 0x4
	    float CurrentTimeDisplayed; // 0x20 Size: 0x4
	    struct FVector2D TextScale; // 0x24 Size: 0x8
	    char UnknownData0[0x4];

};

struct FDropNoteInfo
{
	public:
	    struct FVector Location; // 0x0 Size: 0xc
	    struct FRotator Rotation; // 0xc Size: 0xc
	    struct FString Comment; // 0x18 Size: 0x10

};

struct FStatColorMapEntry
{
	public:
	    float In; // 0x0 Size: 0x4
	    struct FColor Out; // 0x4 Size: 0x4

};

struct FNamedNetDriver
{
	public:
	    class UNetDriver* NetDriver; // 0x0 Size: 0x8
	    char UnknownData0[0x8];

};

struct FLevelStreamingStatus
{
	public:
	    FName PackageName; // 0x0 Size: 0x8
	    bool bShouldBeLoaded; // 0x8 Size: 0x1
	    bool bShouldBeVisible; // 0x8 Size: 0x1
	    char UnknownData0[0x2]; // 0xa
	    uint32_t LODIndex; // 0xc Size: 0x4

};

struct FNetDriverDefinition
{
	public:
	    FName DefName; // 0x0 Size: 0x8
	    FName DriverClassName; // 0x8 Size: 0x8
	    FName DriverClassNameFallback; // 0x10 Size: 0x8

};

struct FExposureSettings
{
	public:
	    float FixedEV100; // 0x0 Size: 0x4
	    bool bFixed; // 0x4 Size: 0x1
	    char UnknownData0[0x3];

};

struct FPrimitiveComponentPostPhysicsTickFunction : public FTickFunction
{
	public:
	    char UnknownData0[0x58];

};

struct FTickPrerequisite
{
	public:
	    char UnknownData0[0x10];

};

struct FCanvasUVTri
{
	public:
	    struct FVector2D V0_Pos; // 0x0 Size: 0x8
	    struct FVector2D V0_UV; // 0x8 Size: 0x8
	    struct FLinearColor V0_Color; // 0x10 Size: 0x10
	    struct FVector2D V1_Pos; // 0x20 Size: 0x8
	    struct FVector2D V1_UV; // 0x28 Size: 0x8
	    struct FLinearColor V1_Color; // 0x30 Size: 0x10
	    struct FVector2D V2_Pos; // 0x40 Size: 0x8
	    struct FVector2D V2_UV; // 0x48 Size: 0x8
	    struct FLinearColor V2_Color; // 0x50 Size: 0x10

};

struct FDepthFieldGlowInfo
{
	public:
	    bool bEnableGlow; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    struct FLinearColor GlowColor; // 0x4 Size: 0x10
	    struct FVector2D GlowOuterRadius; // 0x14 Size: 0x8
	    struct FVector2D GlowInnerRadius; // 0x1c Size: 0x8

};

struct FFontRenderInfo
{
	public:
	    bool bClipText; // 0x0 Size: 0x1
	    bool bEnableShadow; // 0x0 Size: 0x1
	    char UnknownData0[0x2]; // 0x2
	    struct FDepthFieldGlowInfo GlowInfo; // 0x4 Size: 0x24

};

struct FRedirector
{
	public:
	    FName OldName; // 0x0 Size: 0x8
	    FName NewName; // 0x8 Size: 0x8

};

struct FCollectionReference
{
	public:
	    FName CollectionName; // 0x0 Size: 0x8

};

struct FComponentReference
{
	public:
	    class AActor* OtherActor; // 0x0 Size: 0x8
	    FName ComponentProperty; // 0x8 Size: 0x8
	    char UnknownData0[0x8];

};

struct FConstrainComponentPropName
{
	public:
	    FName ComponentName; // 0x0 Size: 0x8

};

struct FDamageEvent
{
	public:
	    class UDamageType* DamageTypeClass; // 0x8 Size: 0x8

};

struct FRadialDamageParams
{
	public:
	    float BaseDamage; // 0x0 Size: 0x4
	    float MinimumDamage; // 0x4 Size: 0x4
	    float InnerRadius; // 0x8 Size: 0x4
	    float OuterRadius; // 0xc Size: 0x4
	    float DamageFalloff; // 0x10 Size: 0x4

};

struct FPointDamageEvent : public FDamageEvent
{
	public:
	    float Damage; // 0x10 Size: 0x4
	    struct FVector_NetQuantizeNormal ShotDirection; // 0x14 Size: 0xc
	    struct FHitResult HitInfo; // 0x20 Size: 0x88

};

struct FMeshBuildSettings
{
	public:
	    bool bUseMikkTSpace; // 0x0 Size: 0x1
	    bool bRecomputeNormals; // 0x0 Size: 0x1
	    bool bRecomputeTangents; // 0x0 Size: 0x1
	    bool bRemoveDegenerates; // 0x0 Size: 0x1
	    bool bBuildAdjacencyBuffer; // 0x0 Size: 0x1
	    bool bBuildReversedIndexBuffer; // 0x0 Size: 0x1
	    bool bUseHighPrecisionTangentBasis; // 0x0 Size: 0x1
	    bool bUseFullPrecisionUVs; // 0x0 Size: 0x1
	    bool bGenerateLightmapUVs; // 0x1 Size: 0x1
	    bool bGenerateDistanceFieldAsIfTwoSided; // 0x1 Size: 0x1
	    Yea, we fucked up; // 0x0
	    int MinLightmapResolution; // 0x4 Size: 0x4
	    int SrcLightmapIndex; // 0x8 Size: 0x4
	    int DstLightmapIndex; // 0xc Size: 0x4
	    float BuildScale; // 0x10 Size: 0x4
	    struct FVector BuildScale3D; // 0x14 Size: 0xc
	    float DistanceFieldResolutionScale; // 0x20 Size: 0x4
	    char UnknownData1[0x4]; // 0x24
	    class UStaticMesh* DistanceFieldReplacementMesh; // 0x28 Size: 0x8

};

struct FPOV
{
	public:
	    struct FVector Location; // 0x0 Size: 0xc
	    struct FRotator Rotation; // 0xc Size: 0xc
	    float FOV; // 0x18 Size: 0x4

};

struct FAnimSlotDesc
{
	public:
	    FName SlotName; // 0x0 Size: 0x8
	    int NumChannels; // 0x8 Size: 0x4

};

struct FMTDResult
{
	public:
	    struct FVector Direction; // 0x0 Size: 0xc
	    float Distance; // 0xc Size: 0x4

};

struct FOverlapResult
{
	public:
	    TWeakObjectPtr<AActor*> Actor; // 0x0 Size: 0x8
	    TWeakObjectPtr<UPrimitiveComponent*> Component; // 0x8 Size: 0x8
	    bool bBlockingHit; // 0x14 Size: 0x1
	    char UnknownData0[0x7];

};

struct FPrimitiveMaterialRef
{
	public:
	    class UPrimitiveComponent* Primitive; // 0x0 Size: 0x8
	    class UDecalComponent* Decal; // 0x8 Size: 0x8
	    int ElementIndex; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FSwarmDebugOptions
{
	public:
	    bool bDistributionEnabled; // 0x0 Size: 0x1
	    bool bForceContentExport; // 0x0 Size: 0x1
	    bool bInitialized; // 0x0 Size: 0x1
	    char UnknownData0[0x1];

};

struct FLightmassDebugOptions
{
	public:
	    bool bDebugMode; // 0x0 Size: 0x1
	    bool bStatsEnabled; // 0x0 Size: 0x1
	    bool bGatherBSPSurfacesAcrossComponents; // 0x0 Size: 0x1
	    char UnknownData0[0x1]; // 0x3
	    float CoplanarTolerance; // 0x4 Size: 0x4
	    bool bUseImmediateImport; // 0x8 Size: 0x1
	    bool bImmediateProcessMappings; // 0x8 Size: 0x1
	    bool bSortMappings; // 0x8 Size: 0x1
	    bool bDumpBinaryFiles; // 0x8 Size: 0x1
	    bool bDebugMaterials; // 0x8 Size: 0x1
	    bool bPadMappings; // 0x8 Size: 0x1
	    bool bDebugPaddings; // 0x8 Size: 0x1
	    bool bOnlyCalcDebugTexelMappings; // 0x8 Size: 0x1
	    bool bUseRandomColors; // 0x9 Size: 0x1
	    bool bColorBordersGreen; // 0x9 Size: 0x1
	    bool bColorByExecutionTime; // 0x9 Size: 0x1
	    Yea, we fucked up; // 0x1
	    float ExecutionTimeDivisor; // 0xc Size: 0x4

};

struct FLightmassPrimitiveSettings
{
	public:
	    bool bUseTwoSidedLighting; // 0x0 Size: 0x1
	    bool bShadowIndirectOnly; // 0x0 Size: 0x1
	    bool bUseEmissiveForStaticLighting; // 0x0 Size: 0x1
	    bool bUseVertexNormalForHemisphereGather; // 0x0 Size: 0x1
	    float EmissiveLightFalloffExponent; // 0x4 Size: 0x4
	    float EmissiveLightExplicitInfluenceRadius; // 0x8 Size: 0x4
	    float EmissiveBoost; // 0xc Size: 0x4
	    float DiffuseBoost; // 0x10 Size: 0x4
	    float FullyOccludedSamplesFraction; // 0x14 Size: 0x4

};

struct FLightmassLightSettings
{
	public:
	    float IndirectLightingSaturation; // 0x0 Size: 0x4
	    float ShadowExponent; // 0x4 Size: 0x4
	    bool bUseAreaShadowsForStationaryLight; // 0x8 Size: 0x1
	    char UnknownData0[0x3];

};

struct FLightmassDirectionalLightSettings : public FLightmassLightSettings
{
	public:
	    float LightSourceAngle; // 0xc Size: 0x4

};

struct FLightmassPointLightSettings : public FLightmassLightSettings
{
	public:
	    char UnknownData0[0xc];

};

struct FBasedPosition
{
	public:
	    class AActor* Base; // 0x0 Size: 0x8
	    struct FVector Position; // 0x8 Size: 0xc
	    struct FVector CachedBaseLocation; // 0x14 Size: 0xc
	    struct FRotator CachedBaseRotation; // 0x20 Size: 0xc
	    struct FVector CachedTransPosition; // 0x2c Size: 0xc

};

struct FFractureEffect
{
	public:
	    class UParticleSystem* ParticleSystem; // 0x0 Size: 0x8
	    class USoundBase* Sound; // 0x8 Size: 0x8

};

struct FRigidBodyContactInfo
{
	public:
	    struct FVector ContactPosition; // 0x0 Size: 0xc
	    struct FVector ContactNormal; // 0xc Size: 0xc
	    float ContactPenetration; // 0x18 Size: 0x4
	    char UnknownData0[0x4]; // 0x1c
	    class UPhysicalMaterial* PhysMaterial; // 0x20 Size: 0x8
	    char UnknownData1[0x8];

};

struct FRigidBodyErrorCorrection
{
	public:
	    float PingExtrapolation; // 0x0 Size: 0x4
	    float PingLimit; // 0x4 Size: 0x4
	    float ErrorPerLinearDifference; // 0x8 Size: 0x4
	    float ErrorPerAngularDifference; // 0xc Size: 0x4
	    float MaxRestoredStateError; // 0x10 Size: 0x4
	    float MaxLinearHardSnapDistance; // 0x14 Size: 0x4
	    float PositionLerp; // 0x18 Size: 0x4
	    float AngleLerp; // 0x1c Size: 0x4
	    float LinearVelocityCoefficient; // 0x20 Size: 0x4
	    float AngularVelocityCoefficient; // 0x24 Size: 0x4
	    float ErrorAccumulationSeconds; // 0x28 Size: 0x4
	    float ErrorAccumulationDistanceSq; // 0x2c Size: 0x4
	    float ErrorAccumulationSimilarity; // 0x30 Size: 0x4

};

struct FRigidBodyState
{
	public:
	    struct FVector_NetQuantize100 Position; // 0x0 Size: 0xc
	    char UnknownData0[0x4]; // 0xc
	    struct FQuat Quaternion; // 0x10 Size: 0x10
	    struct FVector_NetQuantize100 LinVel; // 0x20 Size: 0xc
	    struct FVector_NetQuantize100 AngVel; // 0x2c Size: 0xc
	    char Flags; // 0x38 Size: 0x1
	    char UnknownData1[0x7];

};

struct FFontCharacter
{
	public:
	    int StartU; // 0x0 Size: 0x4
	    int StartV; // 0x4 Size: 0x4
	    int USize; // 0x8 Size: 0x4
	    int VSize; // 0xc Size: 0x4
	    char TextureIndex; // 0x10 Size: 0x1
	    char UnknownData0[0x3]; // 0x11
	    int VerticalOffset; // 0x14 Size: 0x4

};

struct FFontImportOptionsData
{
	public:
	    struct FString FontName; // 0x0 Size: 0x10
	    float Height; // 0x10 Size: 0x4
	    bool bEnableAntialiasing; // 0x14 Size: 0x1
	    bool bEnableBold; // 0x14 Size: 0x1
	    bool bEnableItalic; // 0x14 Size: 0x1
	    bool bEnableUnderline; // 0x14 Size: 0x1
	    bool bAlphaOnly; // 0x14 Size: 0x1
	    Yea, we fucked up; // 0x0
	    char CharacterSet; // 0x18 Size: 0x1
	    char UnknownData1[0x7]; // 0x19
	    struct FString Chars; // 0x20 Size: 0x10
	    struct FString UnicodeRange; // 0x30 Size: 0x10
	    struct FString CharsFilePath; // 0x40 Size: 0x10
	    struct FString CharsFileWildcard; // 0x50 Size: 0x10
	    bool bCreatePrintableOnly; // 0x60 Size: 0x1
	    bool bIncludeASCIIRange; // 0x60 Size: 0x1
	    char UnknownData2[0x2]; // 0x62
	    struct FLinearColor ForegroundColor; // 0x64 Size: 0x10
	    bool bEnableDropShadow; // 0x74 Size: 0x1
	    char UnknownData3[0x3]; // 0x75
	    int TexturePageWidth; // 0x78 Size: 0x4
	    int TexturePageMaxHeight; // 0x7c Size: 0x4
	    int XPadding; // 0x80 Size: 0x4
	    int YPadding; // 0x84 Size: 0x4
	    int ExtendBoxTop; // 0x88 Size: 0x4
	    int ExtendBoxBottom; // 0x8c Size: 0x4
	    int ExtendBoxRight; // 0x90 Size: 0x4
	    int ExtendBoxLeft; // 0x94 Size: 0x4
	    bool bEnableLegacyMode; // 0x98 Size: 0x1
	    char UnknownData4[0x3]; // 0x99
	    int Kerning; // 0x9c Size: 0x4
	    bool bUseDistanceFieldAlpha; // 0xa0 Size: 0x1
	    char UnknownData5[0x3]; // 0xa1
	    int DistanceFieldScaleFactor; // 0xa4 Size: 0x4
	    float DistanceFieldScanRadiusScale; // 0xa8 Size: 0x4
	    char UnknownData6[0x4];

};

struct FForceFeedbackAttenuationSettings : public FBaseAttenuationSettings
{
	public:
	    char UnknownData0[0xb0];

};

struct FPredictProjectilePathPointData
{
	public:
	    struct FVector Location; // 0x0 Size: 0xc
	    struct FVector Velocity; // 0xc Size: 0xc
	    float Time; // 0x18 Size: 0x4

};

struct FActiveHapticFeedbackEffect
{
	public:
	    class UHapticFeedbackEffect_Base* HapticEffect; // 0x0 Size: 0x8
	    char UnknownData0[0x10];

};

struct FClusterNode
{
	public:
	    struct FVector BoundMin; // 0x0 Size: 0xc
	    int FirstChild; // 0xc Size: 0x4
	    struct FVector BoundMax; // 0x10 Size: 0xc
	    int LastChild; // 0x1c Size: 0x4
	    int FirstInstance; // 0x20 Size: 0x4
	    int LastInstance; // 0x24 Size: 0x4
	    struct FVector MinInstanceScale; // 0x28 Size: 0xc
	    struct FVector MaxInstanceScale; // 0x34 Size: 0xc

};

struct FClusterNode_DEPRECATED
{
	public:
	    struct FVector BoundMin; // 0x0 Size: 0xc
	    int FirstChild; // 0xc Size: 0x4
	    struct FVector BoundMax; // 0x10 Size: 0xc
	    int LastChild; // 0x1c Size: 0x4
	    int FirstInstance; // 0x20 Size: 0x4
	    int LastInstance; // 0x24 Size: 0x4

};

struct FHLODProxyMesh
{
	public:
	    TLazyObjectPtr<ALODActor*> LODActor; // 0x0 Size: 0x1c
	    char UnknownData0[0x4]; // 0x1c
	    class UStaticMesh* StaticMesh; // 0x20 Size: 0x8
	    FName Key; // 0x28 Size: 0x8

};

struct FComponentKey
{
	public:
	    class UObject* OwnerClass; // 0x0 Size: 0x8
	    FName SCSVariableName; // 0x8 Size: 0x8
	    struct FGuid AssociatedGuid; // 0x10 Size: 0x10

};

struct FBlueprintInputDelegateBinding
{
	public:
	    bool bConsumeInput; // 0x0 Size: 0x1
	    bool bExecuteWhenPaused; // 0x0 Size: 0x1
	    bool bOverrideParentBinding; // 0x0 Size: 0x1
	    char UnknownData0[0x1];

};

struct FBlueprintInputActionDelegateBinding : public FBlueprintInputDelegateBinding
{
	public:
	    FName InputActionName; // 0x4 Size: 0x8
	    char InputKeyEvent; // 0xc Size: 0x1
	    char UnknownData0[0x3]; // 0xd
	    FName FunctionNameToBind; // 0x10 Size: 0x8

};

struct FBlueprintInputAxisDelegateBinding : public FBlueprintInputDelegateBinding
{
	public:
	    FName InputAxisName; // 0x4 Size: 0x8
	    FName FunctionNameToBind; // 0xc Size: 0x8

};

struct FBlueprintInputAxisKeyDelegateBinding : public FBlueprintInputDelegateBinding
{
	public:
	    char UnknownData0[0x4];
	    struct FKey AxisKey; // 0x8 Size: 0x18
	    FName FunctionNameToBind; // 0x20 Size: 0x8

};

struct FCachedKeyToActionInfo
{
	public:
	    class UPlayerInput* PlayerInput; // 0x0 Size: 0x8
	    char UnknownData0[0x68];

};

struct FBlueprintInputKeyDelegateBinding : public FBlueprintInputDelegateBinding
{
	public:
	    char UnknownData0[0x4];
	    struct FInputChord InputChord; // 0x8 Size: 0x20
	    char InputKeyEvent; // 0x28 Size: 0x1
	    char UnknownData1[0x3]; // 0x29
	    FName FunctionNameToBind; // 0x2c Size: 0x8
	    char UnknownData2[0x4];

};

struct FBlueprintInputTouchDelegateBinding : public FBlueprintInputDelegateBinding
{
	public:
	    char InputKeyEvent; // 0x4 Size: 0x1
	    char UnknownData0[0x3]; // 0x5
	    FName FunctionNameToBind; // 0x8 Size: 0x8

};

struct FInstancedStaticMeshMappingInfo
{
	public:
	    char UnknownData0[0x8];

};

struct FInstancedStaticMeshInstanceData
{
	public:
	    struct FMatrix Transform; // 0x0 Size: 0x40

};

struct FIntegralKey
{
	public:
	    float Time; // 0x0 Size: 0x4
	    int Value; // 0x4 Size: 0x4

};

struct FCurveEdEntry
{
	public:
	    class UObject* CurveObject; // 0x0 Size: 0x8
	    struct FColor CurveColor; // 0x8 Size: 0x4
	    char UnknownData0[0x4]; // 0xc
	    struct FString CurveName; // 0x10 Size: 0x10
	    int bHideCurve; // 0x20 Size: 0x4
	    int bColorCurve; // 0x24 Size: 0x4
	    int bFloatingPointColorCurve; // 0x28 Size: 0x4
	    int bClamp; // 0x2c Size: 0x4
	    float ClampLow; // 0x30 Size: 0x4
	    float ClampHigh; // 0x34 Size: 0x4

};

struct FInterpEdSelKey
{
	public:
	    class UInterpGroup* Group; // 0x0 Size: 0x8
	    class UInterpTrack* Track; // 0x8 Size: 0x8
	    int KeyIndex; // 0x10 Size: 0x4
	    float UnsnappedPosition; // 0x14 Size: 0x4

};

struct FCameraPreviewInfo
{
	public:
	    class APawn* PawnClass; // 0x0 Size: 0x8
	    class UAnimSequence* AnimSeq; // 0x8 Size: 0x8
	    struct FVector Location; // 0x10 Size: 0xc
	    struct FRotator Rotation; // 0x1c Size: 0xc
	    class APawn* PawnInst; // 0x28 Size: 0x8

};

struct FSupportedSubTrackInfo
{
	public:
	    class UInterpTrack* SupportedClass; // 0x0 Size: 0x8
	    struct FString SubTrackName; // 0x8 Size: 0x10
	    int GroupIndex; // 0x18 Size: 0x4
	    char UnknownData0[0x4];

};

struct FAnimControlTrackKey
{
	public:
	    float StartTime; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    class UAnimSequence* AnimSeq; // 0x8 Size: 0x8
	    float AnimStartOffset; // 0x10 Size: 0x4
	    float AnimEndOffset; // 0x14 Size: 0x4
	    float AnimPlayRate; // 0x18 Size: 0x4
	    bool bLooping; // 0x1c Size: 0x1
	    bool bReverse; // 0x1c Size: 0x1
	    char UnknownData1[0x2];

};

struct FBoolTrackKey
{
	public:
	    float Time; // 0x0 Size: 0x4
	    bool Value; // 0x4 Size: 0x1
	    char UnknownData0[0x3];

};

struct FDirectorTrackCut
{
	public:
	    float Time; // 0x0 Size: 0x4
	    float TransitionTime; // 0x4 Size: 0x4
	    FName TargetCamGroup; // 0x8 Size: 0x8
	    int ShotNumber; // 0x10 Size: 0x4

};

struct FEventTrackKey
{
	public:
	    float Time; // 0x0 Size: 0x4
	    FName EventName; // 0x4 Size: 0x8

};

struct FInterpLookupPoint
{
	public:
	    FName GroupName; // 0x0 Size: 0x8
	    float Time; // 0x8 Size: 0x4

};

struct FParticleReplayTrackKey
{
	public:
	    float Time; // 0x0 Size: 0x4
	    float Duration; // 0x4 Size: 0x4
	    int ClipIDNumber; // 0x8 Size: 0x4

};

struct FSoundTrackKey
{
	public:
	    float Time; // 0x0 Size: 0x4
	    float Volume; // 0x4 Size: 0x4
	    float Pitch; // 0x8 Size: 0x4
	    char UnknownData0[0x4]; // 0xc
	    class USoundBase* Sound; // 0x10 Size: 0x8

};

struct FToggleTrackKey
{
	public:
	    float Time; // 0x0 Size: 0x4
	    char ToggleAction; // 0x4 Size: 0x1
	    char UnknownData0[0x3];

};

struct FVisibilityTrackKey
{
	public:
	    float Time; // 0x0 Size: 0x4
	    char Action; // 0x4 Size: 0x1
	    char ActiveCondition; // 0x5 Size: 0x1
	    char UnknownData0[0x2];

};

struct FVectorSpringState
{
	public:
	    char UnknownData0[0x18];

};

struct FFloatSpringState
{
	public:
	    char UnknownData0[0x8];

};

struct FDrawToRenderTargetContext
{
	public:
	    class UTextureRenderTarget2D* RenderTarget; // 0x0 Size: 0x8
	    char UnknownData0[0x8];

};

struct FLatentActionManager
{
	public:
	    char UnknownData0[0x60];

};

struct FLayerActorStats
{
	public:
	    class UObject* Type; // 0x0 Size: 0x8
	    int Total; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FReplicatedStaticActorDestructionInfo
{
	public:
	    class UObject* ObjClass; // 0x20 Size: 0x8

};

struct FMaterialProxySettings
{
	public:
	    struct FIntPoint TextureSize; // 0x0 Size: 0x8
	    float GutterSpace; // 0x8 Size: 0x4
	    float MetallicConstant; // 0xc Size: 0x4
	    float RoughnessConstant; // 0x10 Size: 0x4
	    float SpecularConstant; // 0x14 Size: 0x4
	    float OpacityConstant; // 0x18 Size: 0x4
	    float OpacityMaskConstant; // 0x1c Size: 0x4
	    float AmbientOcclusionConstant; // 0x20 Size: 0x4
	    char TextureSizingType; // 0x24 Size: 0x1
	    char MaterialMergeType; // 0x25 Size: 0x1
	    char BlendMode; // 0x26 Size: 0x1
	    bool bNormalMap; // 0x27 Size: 0x1
	    bool bMetallicMap; // 0x27 Size: 0x1
	    bool bRoughnessMap; // 0x27 Size: 0x1
	    bool bSpecularMap; // 0x27 Size: 0x1
	    bool bEmissiveMap; // 0x27 Size: 0x1
	    bool bOpacityMap; // 0x27 Size: 0x1
	    bool bOpacityMaskMap; // 0x27 Size: 0x1
	    bool bAmbientOcclusionMap; // 0x27 Size: 0x1
	    Yea, we fucked up; // 0x0
	    struct FIntPoint DiffuseTextureSize; // 0x28 Size: 0x8
	    struct FIntPoint NormalTextureSize; // 0x30 Size: 0x8
	    struct FIntPoint MetallicTextureSize; // 0x38 Size: 0x8
	    struct FIntPoint RoughnessTextureSize; // 0x40 Size: 0x8
	    struct FIntPoint SpecularTextureSize; // 0x48 Size: 0x8
	    struct FIntPoint EmissiveTextureSize; // 0x50 Size: 0x8
	    struct FIntPoint OpacityTextureSize; // 0x58 Size: 0x8
	    struct FIntPoint OpacityMaskTextureSize; // 0x60 Size: 0x8
	    struct FIntPoint AmbientOcclusionTextureSize; // 0x68 Size: 0x8

};

struct FLevelSimplificationDetails
{
	public:
	    bool bCreatePackagePerAsset; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float DetailsPercentage; // 0x4 Size: 0x4
	    struct FMaterialProxySettings StaticMeshMaterialSettings; // 0x8 Size: 0x70
	    bool bOverrideLandscapeExportLOD; // 0x78 Size: 0x1
	    char UnknownData1[0x3]; // 0x79
	    int LandscapeExportLOD; // 0x7c Size: 0x4
	    struct FMaterialProxySettings LandscapeMaterialSettings; // 0x80 Size: 0x70
	    bool bBakeFoliageToLandscape; // 0xf0 Size: 0x1
	    bool bBakeGrassToLandscape; // 0xf1 Size: 0x1
	    bool bGenerateMeshNormalMap; // 0xf2 Size: 0x1
	    bool bGenerateMeshMetallicMap; // 0xf3 Size: 0x1
	    bool bGenerateMeshRoughnessMap; // 0xf4 Size: 0x1
	    bool bGenerateMeshSpecularMap; // 0xf5 Size: 0x1
	    bool bGenerateLandscapeNormalMap; // 0xf6 Size: 0x1
	    bool bGenerateLandscapeMetallicMap; // 0xf7 Size: 0x1
	    bool bGenerateLandscapeRoughnessMap; // 0xf8 Size: 0x1
	    bool bGenerateLandscapeSpecularMap; // 0xf9 Size: 0x1
	    char UnknownData2[0x2];

};

struct FStreamableTextureInstance
{
	public:
	    char UnknownData0[0x28];

};

struct FDynamicTextureInstance : public FStreamableTextureInstance
{
	public:
	    class UTexture2D* Texture; // 0x28 Size: 0x8
	    bool bAttached; // 0x30 Size: 0x1
	    char UnknownData0[0x3]; // 0x31
	    float OriginalRadius; // 0x34 Size: 0x4

};

struct FBatchedPoint
{
	public:
	    struct FVector Position; // 0x0 Size: 0xc
	    struct FLinearColor Color; // 0xc Size: 0x10
	    float PointSize; // 0x1c Size: 0x4
	    float RemainingLifeTime; // 0x20 Size: 0x4
	    char DepthPriority; // 0x24 Size: 0x1
	    char UnknownData0[0x3];

};

struct FBatchedLine
{
	public:
	    struct FVector Start; // 0x0 Size: 0xc
	    struct FVector End; // 0xc Size: 0xc
	    struct FLinearColor Color; // 0x18 Size: 0x10
	    float Thickness; // 0x28 Size: 0x4
	    float RemainingLifeTime; // 0x2c Size: 0x4
	    char DepthPriority; // 0x30 Size: 0x1
	    char UnknownData0[0x3];

};

struct FClientReceiveData
{
	public:
	    class APlayerController* LocalPC; // 0x0 Size: 0x8
	    FName MessageType; // 0x8 Size: 0x8
	    int MessageIndex; // 0x10 Size: 0x4
	    char UnknownData0[0x4]; // 0x14
	    struct FString MessageString; // 0x18 Size: 0x10
	    class APlayerState* RelatedPlayerState_1; // 0x28 Size: 0x8
	    class APlayerState* RelatedPlayerState_2; // 0x30 Size: 0x8
	    class UObject* OptionalObject; // 0x38 Size: 0x8

};

struct FParameterGroupData
{
	public:
	    struct FString GroupName; // 0x0 Size: 0x10
	    int GroupSortPriority; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FMaterialParameterCollectionInfo
{
	public:
	    struct FGuid StateId; // 0x0 Size: 0x10
	    class UMaterialParameterCollection* ParameterCollection; // 0x10 Size: 0x8

};

struct FMaterialFunctionInfo
{
	public:
	    struct FGuid StateId; // 0x0 Size: 0x10
	    class UMaterialFunctionInterface* Function; // 0x10 Size: 0x8

};

struct FMaterialSpriteElement
{
	public:
	    class UMaterialInterface* Material; // 0x0 Size: 0x8
	    class UCurveFloat* DistanceToOpacityCurve; // 0x8 Size: 0x8
	    bool bSizeIsInScreenSpace; // 0x10 Size: 0x1
	    char UnknownData0[0x3]; // 0x11
	    float BaseSizeX; // 0x14 Size: 0x4
	    float BaseSizeY; // 0x18 Size: 0x4
	    char UnknownData1[0x4]; // 0x1c
	    class UCurveFloat* DistanceToSizeCurve; // 0x20 Size: 0x8

};

struct FCustomInput
{
	public:
	    FName InputName; // 0x0 Size: 0x8
	    struct FExpressionInput Input; // 0x8 Size: 0xc
	    char UnknownData0[0x8];

};

struct FFunctionExpressionOutput
{
	public:
	    class UMaterialExpressionFunctionOutput* ExpressionOutput; // 0x0 Size: 0x8
	    struct FGuid ExpressionOutputId; // 0x8 Size: 0x10
	    struct FExpressionOutput Output; // 0x18 Size: 0x8

};

struct FFunctionExpressionInput
{
	public:
	    class UMaterialExpressionFunctionInput* ExpressionInput; // 0x0 Size: 0x8
	    struct FGuid ExpressionInputId; // 0x8 Size: 0x10
	    struct FExpressionInput Input; // 0x18 Size: 0xc
	    char UnknownData0[0xc];

};

struct FFontParameterValue
{
	public:
	    struct FMaterialParameterInfo ParameterInfo; // 0x0 Size: 0x10
	    class UFont* FontValue; // 0x10 Size: 0x8
	    int FontPage; // 0x18 Size: 0x4
	    struct FGuid ExpressionGUID; // 0x1c Size: 0x10
	    char UnknownData0[0x4];

};

struct FScalarParameterAtlasInstanceData
{
	public:
	    bool bIsUsedAsAtlasPosition; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct TSoftObjectPtr<struct UCurveLinearColor*> Curve; // 0x8 Size: 0x28
	    struct TSoftObjectPtr<struct UCurveLinearColorAtlas*> Atlas; // 0x30 Size: 0x28

};

struct FMaterialInstanceBasePropertyOverrides
{
	public:
	    bool bOverride_OpacityMaskClipValue; // 0x0 Size: 0x1
	    bool bOverride_BlendMode; // 0x0 Size: 0x1
	    bool bOverride_ShadingModel; // 0x0 Size: 0x1
	    bool bOverride_DitheredLODTransition; // 0x0 Size: 0x1
	    bool bOverride_CastDynamicShadowAsMasked; // 0x0 Size: 0x1
	    bool bOverride_TwoSided; // 0x0 Size: 0x1
	    bool TwoSided; // 0x0 Size: 0x1
	    bool DitheredLODTransition; // 0x0 Size: 0x1
	    bool bCastDynamicShadowAsMasked; // 0x1 Size: 0x1
	    Yea, we fucked up; // 0x0
	    char BlendMode; // 0x2 Size: 0x1
	    char ShadingModel; // 0x3 Size: 0x1
	    float OpacityMaskClipValue; // 0x4 Size: 0x4

};

struct FMaterialTextureInfo
{
	public:
	    float SamplingScale; // 0x0 Size: 0x4
	    int UVChannelIndex; // 0x4 Size: 0x4
	    FName TextureName; // 0x8 Size: 0x8

};

struct FLightmassMaterialInterfaceSettings
{
	public:
	    bool bCastShadowAsMasked; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float EmissiveBoost; // 0x4 Size: 0x4
	    float DiffuseBoost; // 0x8 Size: 0x4
	    float ExportResolutionScale; // 0xc Size: 0x4
	    bool bOverrideCastShadowAsMasked; // 0x10 Size: 0x1
	    bool bOverrideEmissiveBoost; // 0x10 Size: 0x1
	    bool bOverrideDiffuseBoost; // 0x10 Size: 0x1
	    bool bOverrideExportResolutionScale; // 0x10 Size: 0x1

};

struct FCollectionParameterBase
{
	public:
	    FName ParameterName; // 0x0 Size: 0x8
	    struct FGuid ID; // 0x8 Size: 0x10

};

struct FCollectionVectorParameter : public FCollectionParameterBase
{
	public:
	    struct FLinearColor DefaultValue; // 0x18 Size: 0x10

};

struct FCollectionScalarParameter : public FCollectionParameterBase
{
	public:
	    float DefaultValue; // 0x18 Size: 0x4

};

struct FCameraCutInfo
{
	public:
	    struct FVector Location; // 0x0 Size: 0xc
	    float Timestamp; // 0xc Size: 0x4

};

struct FMemberReference
{
	public:
	    class UObject* MemberParent; // 0x0 Size: 0x8
	    struct FString MemberScope; // 0x8 Size: 0x10
	    FName MemberName; // 0x18 Size: 0x8
	    struct FGuid MemberGuid; // 0x20 Size: 0x10
	    bool bSelfContext; // 0x30 Size: 0x1
	    bool bWasDeprecated; // 0x31 Size: 0x1
	    char UnknownData0[0x6];

};

struct FMeshInstancingSettings
{
	public:
	    class AActor* ActorClassToUse; // 0x0 Size: 0x8
	    int InstanceReplacementThreshold; // 0x8 Size: 0x4
	    EMeshInstancingReplacementMethod MeshReplacementMethod; // 0xc Size: 0x1
	    bool bSkipMeshesWithVertexColors; // 0xd Size: 0x1
	    bool bUseHLODVolumes; // 0xe Size: 0x1
	    char UnknownData0[0x1];

};

struct FMeshMergingSettings
{
	public:
	    int TargetLightMapResolution; // 0x0 Size: 0x4
	    EUVOutput OutputUVs; // 0x4 Size: 0x1
	    char UnknownData0[0x7]; // 0x5
	    struct FMaterialProxySettings MaterialSettings; // 0xc Size: 0x70
	    int GutterSize; // 0x7c Size: 0x4
	    int SpecificLOD; // 0x80 Size: 0x4
	    EMeshLODSelectionType LODSelectionType; // 0x84 Size: 0x1
	    bool bGenerateLightMapUV; // 0x85 Size: 0x1
	    bool bComputedLightMapResolution; // 0x85 Size: 0x1
	    bool bPivotPointAtZero; // 0x85 Size: 0x1
	    bool bMergePhysicsData; // 0x85 Size: 0x1
	    bool bMergeMaterials; // 0x85 Size: 0x1
	    bool bBakeVertexDataToMesh; // 0x85 Size: 0x1
	    bool bUseVertexDataForBakingMaterial; // 0x85 Size: 0x1
	    bool bUseTextureBinning; // 0x85 Size: 0x1
	    bool bReuseMeshLightmapUVs; // 0x86 Size: 0x1
	    bool bMergeEquivalentMaterials; // 0x86 Size: 0x1
	    bool bUseLandscapeCulling; // 0x86 Size: 0x1
	    bool bIncludeImposters; // 0x86 Size: 0x1
	    bool bAllowDistanceField; // 0x86 Size: 0x1
	    char UnknownData1[0x-a];

};

struct FMeshProxySettings
{
	public:
	    int ScreenSize; // 0x0 Size: 0x4
	    float VoxelSize; // 0x4 Size: 0x4
	    struct FMaterialProxySettings MaterialSettings; // 0x8 Size: 0x70
	    float MergeDistance; // 0x78 Size: 0x4
	    struct FColor UnresolvedGeometryColor; // 0x7c Size: 0x4
	    float MaxRayCastDist; // 0x80 Size: 0x4
	    float HardAngleThreshold; // 0x84 Size: 0x4
	    int LightMapResolution; // 0x88 Size: 0x4
	    char NormalCalculationMethod; // 0x8c Size: 0x1
	    char LandscapeCullingPrecision; // 0x8d Size: 0x1
	    bool bCalculateCorrectLODModel; // 0x8e Size: 0x1
	    bool bOverrideVoxelSize; // 0x8e Size: 0x1
	    bool bOverrideTransferDistance; // 0x8e Size: 0x1
	    bool bUseHardAngleThreshold; // 0x8e Size: 0x1
	    bool bComputeLightMapResolution; // 0x8e Size: 0x1
	    bool bRecalculateNormals; // 0x8e Size: 0x1
	    bool bUseLandscapeCulling; // 0x8e Size: 0x1
	    bool bAllowAdjacency; // 0x8e Size: 0x1
	    bool bAllowDistanceField; // 0x8f Size: 0x1
	    bool bReuseMeshLightmapUVs; // 0x8f Size: 0x1
	    bool bCreateCollision; // 0x8f Size: 0x1
	    bool bAllowVertexColors; // 0x8f Size: 0x1
	    bool bGenerateLightmapUVs; // 0x8f Size: 0x1
	    char UnknownData0[0x-b];

};

struct FMeshReductionSettings
{
	public:
	    float PercentTriangles; // 0x0 Size: 0x4
	    float PercentVertices; // 0x4 Size: 0x4
	    float MaxDeviation; // 0x8 Size: 0x4
	    float PixelError; // 0xc Size: 0x4
	    float WeldingThreshold; // 0x10 Size: 0x4
	    float HardAngleThreshold; // 0x14 Size: 0x4
	    int BaseLODModel; // 0x18 Size: 0x4
	    char SilhouetteImportance; // 0x1c Size: 0x1
	    char TextureImportance; // 0x1d Size: 0x1
	    char ShadingImportance; // 0x1e Size: 0x1
	    bool bRecalculateNormals; // 0x1f Size: 0x1
	    bool bGenerateUniqueLightmapUVs; // 0x1f Size: 0x1
	    bool bKeepSymmetry; // 0x1f Size: 0x1
	    bool bVisibilityAided; // 0x1f Size: 0x1
	    bool bCullOccluded; // 0x1f Size: 0x1
	    Yea, we fucked up; // 0x0
	    EStaticMeshReductionTerimationCriterion TerminationCriterion; // 0x20 Size: 0x1
	    char VisibilityAggressiveness; // 0x21 Size: 0x1
	    char VertexColorImportance; // 0x22 Size: 0x1
	    char UnknownData1[0x1];

};

struct FPurchaseInfo
{
	public:
	    struct FString Identifier; // 0x0 Size: 0x10
	    struct FString DisplayName; // 0x10 Size: 0x10
	    struct FString DisplayDescription; // 0x20 Size: 0x10
	    struct FString DisplayPrice; // 0x30 Size: 0x10

};

struct FNameCurveKey
{
	public:
	    float Time; // 0x0 Size: 0x4
	    FName Value; // 0x4 Size: 0x8

};

struct FNavAvoidanceMask
{
	public:
	    bool bGroup0; // 0x0 Size: 0x1
	    bool bGroup1; // 0x0 Size: 0x1
	    bool bGroup2; // 0x0 Size: 0x1
	    bool bGroup3; // 0x0 Size: 0x1
	    bool bGroup4; // 0x0 Size: 0x1
	    bool bGroup5; // 0x0 Size: 0x1
	    bool bGroup6; // 0x0 Size: 0x1
	    bool bGroup7; // 0x0 Size: 0x1
	    bool bGroup8; // 0x1 Size: 0x1
	    bool bGroup9; // 0x1 Size: 0x1
	    bool bGroup10; // 0x1 Size: 0x1
	    bool bGroup11; // 0x1 Size: 0x1
	    bool bGroup12; // 0x1 Size: 0x1
	    bool bGroup13; // 0x1 Size: 0x1
	    bool bGroup14; // 0x1 Size: 0x1
	    bool bGroup15; // 0x1 Size: 0x1
	    bool bGroup16; // 0x2 Size: 0x1
	    bool bGroup17; // 0x2 Size: 0x1
	    bool bGroup18; // 0x2 Size: 0x1
	    bool bGroup19; // 0x2 Size: 0x1
	    bool bGroup20; // 0x2 Size: 0x1
	    bool bGroup21; // 0x2 Size: 0x1
	    bool bGroup22; // 0x2 Size: 0x1
	    bool bGroup23; // 0x2 Size: 0x1
	    bool bGroup24; // 0x3 Size: 0x1
	    bool bGroup25; // 0x3 Size: 0x1
	    bool bGroup26; // 0x3 Size: 0x1
	    bool bGroup27; // 0x3 Size: 0x1
	    bool bGroup28; // 0x3 Size: 0x1
	    bool bGroup29; // 0x3 Size: 0x1
	    bool bGroup30; // 0x3 Size: 0x1
	    bool bGroup31; // 0x3 Size: 0x1
	    char UnknownData0[0x-1c];

};

struct FMovementProperties
{
	public:
	    bool bCanCrouch; // 0x0 Size: 0x1
	    bool bCanJump; // 0x0 Size: 0x1
	    bool bCanWalk; // 0x0 Size: 0x1
	    bool bCanSwim; // 0x0 Size: 0x1
	    bool bCanFly; // 0x0 Size: 0x1
	    char UnknownData0[0x-4];

};

struct FNavAgentProperties : public FMovementProperties
{
	public:
	    char UnknownData0[0x3];
	    float AgentRadius; // 0x4 Size: 0x4
	    float AgentHeight; // 0x8 Size: 0x4
	    float AgentStepHeight; // 0xc Size: 0x4
	    float NavWalkingSearchHeightScale; // 0x10 Size: 0x4
	    char UnknownData1[0x4]; // 0x14
	    struct FSoftClassPath PreferredNavData; // 0x18 Size: 0x18

};

struct FNavDataConfig : public FNavAgentProperties
{
	public:
	    FName Name; // 0x30 Size: 0x8
	    struct FColor Color; // 0x38 Size: 0x4
	    struct FVector DefaultQueryExtent; // 0x3c Size: 0xc
	    class AActor* NavigationDataClass; // 0x48 Size: 0x8
	    struct FSoftClassPath NavigationDataClassName; // 0x50 Size: 0x18

};

struct FNavAgentSelector
{
	public:
	    bool bSupportsAgent0; // 0x0 Size: 0x1
	    bool bSupportsAgent1; // 0x0 Size: 0x1
	    bool bSupportsAgent2; // 0x0 Size: 0x1
	    bool bSupportsAgent3; // 0x0 Size: 0x1
	    bool bSupportsAgent4; // 0x0 Size: 0x1
	    bool bSupportsAgent5; // 0x0 Size: 0x1
	    bool bSupportsAgent6; // 0x0 Size: 0x1
	    bool bSupportsAgent7; // 0x0 Size: 0x1
	    bool bSupportsAgent8; // 0x1 Size: 0x1
	    bool bSupportsAgent9; // 0x1 Size: 0x1
	    bool bSupportsAgent10; // 0x1 Size: 0x1
	    bool bSupportsAgent11; // 0x1 Size: 0x1
	    bool bSupportsAgent12; // 0x1 Size: 0x1
	    bool bSupportsAgent13; // 0x1 Size: 0x1
	    bool bSupportsAgent14; // 0x1 Size: 0x1
	    bool bSupportsAgent15; // 0x1 Size: 0x1
	    char UnknownData0[0x-c];

};

struct FNavigationLinkBase
{
	public:
	    float LeftProjectHeight; // 0x0 Size: 0x4
	    float MaxFallDownLength; // 0x4 Size: 0x4
	    char Direction; // 0x8 Size: 0x1
	    char UnknownData0[0x7]; // 0x9
	    float SnapRadius; // 0x10 Size: 0x4
	    float SnapHeight; // 0x14 Size: 0x4
	    struct FNavAgentSelector SupportedAgents; // 0x18 Size: 0x4
	    bool bSupportsAgent0; // 0x1c Size: 0x1
	    bool bSupportsAgent1; // 0x1c Size: 0x1
	    bool bSupportsAgent2; // 0x1c Size: 0x1
	    bool bSupportsAgent3; // 0x1c Size: 0x1
	    bool bSupportsAgent4; // 0x1c Size: 0x1
	    bool bSupportsAgent5; // 0x1c Size: 0x1
	    bool bSupportsAgent6; // 0x1c Size: 0x1
	    bool bSupportsAgent7; // 0x1c Size: 0x1
	    bool bSupportsAgent8; // 0x1d Size: 0x1
	    bool bSupportsAgent9; // 0x1d Size: 0x1
	    bool bSupportsAgent10; // 0x1d Size: 0x1
	    bool bSupportsAgent11; // 0x1d Size: 0x1
	    bool bSupportsAgent12; // 0x1d Size: 0x1
	    bool bSupportsAgent13; // 0x1d Size: 0x1
	    bool bSupportsAgent14; // 0x1d Size: 0x1
	    bool bSupportsAgent15; // 0x1d Size: 0x1
	    bool bUseSnapHeight; // 0x20 Size: 0x1
	    bool bSnapToCheapestArea; // 0x20 Size: 0x1
	    bool bCustomFlag0; // 0x20 Size: 0x1
	    bool bCustomFlag1; // 0x20 Size: 0x1
	    bool bCustomFlag2; // 0x20 Size: 0x1
	    bool bCustomFlag3; // 0x20 Size: 0x1
	    bool bCustomFlag4; // 0x20 Size: 0x1
	    bool bCustomFlag5; // 0x20 Size: 0x1
	    bool bCustomFlag6; // 0x21 Size: 0x1
	    bool bCustomFlag7; // 0x21 Size: 0x1
	    Yea, we fucked up; // 0x1
	    class UNavAreaBase* AreaClass; // 0x28 Size: 0x8
	    char UnknownData2[0x8];

};

struct FNavigationSegmentLink : public FNavigationLinkBase
{
	public:
	    struct FVector LeftStart; // 0x38 Size: 0xc
	    struct FVector LeftEnd; // 0x44 Size: 0xc
	    struct FVector RightStart; // 0x50 Size: 0xc
	    struct FVector RightEnd; // 0x5c Size: 0xc

};

struct FNavigationLink : public FNavigationLinkBase
{
	public:
	    struct FVector Left; // 0x38 Size: 0xc
	    struct FVector Right; // 0x44 Size: 0xc

};

struct FChannelDefinition
{
	public:
	    FName ChannelName; // 0x0 Size: 0x8
	    FName ClassName; // 0x8 Size: 0x8
	    class UObject* ChannelClass; // 0x10 Size: 0x8
	    int StaticChannelIndex; // 0x18 Size: 0x4
	    bool bTickOnCreate; // 0x1c Size: 0x1
	    bool bServerOpen; // 0x1d Size: 0x1
	    bool bClientOpen; // 0x1e Size: 0x1
	    bool bInitialServer; // 0x1f Size: 0x1
	    bool bInitialClient; // 0x20 Size: 0x1
	    char UnknownData0[0x7];

};

struct FPacketSimulationSettings
{
	public:
	    int PktLoss; // 0x0 Size: 0x4
	    int PktLossMaxSize; // 0x4 Size: 0x4
	    int PktLossMinSize; // 0x8 Size: 0x4
	    int PktOrder; // 0xc Size: 0x4
	    int PktDup; // 0x10 Size: 0x4
	    int PktLag; // 0x14 Size: 0x4
	    int PktLagVariance; // 0x18 Size: 0x4

};

struct FNodeItem
{
	public:
	    FName ParentName; // 0x0 Size: 0x8
	    char UnknownData0[0x8]; // 0x8
	    struct FTransform Transform; // 0x10 Size: 0x30

};

struct FParticleBurst
{
	public:
	    int Count; // 0x0 Size: 0x4
	    int CountLow; // 0x4 Size: 0x4
	    float Time; // 0x8 Size: 0x4

};

struct FParticleCurvePair
{
	public:
	    struct FString CurveName; // 0x0 Size: 0x10
	    class UObject* CurveObject; // 0x10 Size: 0x8

};

struct FBeamModifierOptions
{
	public:
	    bool bModify; // 0x0 Size: 0x1
	    bool bScale; // 0x0 Size: 0x1
	    bool bLock; // 0x0 Size: 0x1
	    char UnknownData0[0x1];

};

struct FLocationBoneSocketInfo
{
	public:
	    FName BoneSocketName; // 0x0 Size: 0x8
	    struct FVector Offset; // 0x8 Size: 0xc

};

struct FOrbitOptions
{
	public:
	    bool bProcessDuringSpawn; // 0x0 Size: 0x1
	    bool bProcessDuringUpdate; // 0x0 Size: 0x1
	    bool bUseEmitterTime; // 0x0 Size: 0x1
	    char UnknownData0[0x1];

};

struct FEmitterDynamicParameter
{
	public:
	    FName ParamName; // 0x0 Size: 0x8
	    bool bUseEmitterTime; // 0x8 Size: 0x1
	    bool bSpawnTimeOnly; // 0x8 Size: 0x1
	    char UnknownData0[0x2]; // 0xa
	    char ValueMethod; // 0xc Size: 0x1
	    bool bScaleVelocityByParamValue; // 0x10 Size: 0x1
	    char UnknownData1[0xa]; // 0xe
	    struct FRawDistributionFloat ParamValue; // 0x18 Size: 0x38

};

struct FBeamTargetData
{
	public:
	    FName TargetName; // 0x0 Size: 0x8
	    float TargetPercentage; // 0x8 Size: 0x4

};

struct FGPUSpriteLocalVectorFieldInfo
{
	public:
	    class UVectorField* Field; // 0x0 Size: 0x8
	    char UnknownData0[0x8]; // 0x8
	    struct FTransform Transform; // 0x10 Size: 0x30
	    struct FRotator MinInitialRotation; // 0x40 Size: 0xc
	    struct FRotator MaxInitialRotation; // 0x4c Size: 0xc
	    struct FRotator RotationRate; // 0x58 Size: 0xc
	    float Intensity; // 0x64 Size: 0x4
	    float Tightness; // 0x68 Size: 0x4
	    bool bIgnoreComponentTransform; // 0x6c Size: 0x1
	    bool bTileX; // 0x6c Size: 0x1
	    bool bTileY; // 0x6c Size: 0x1
	    bool bTileZ; // 0x6c Size: 0x1
	    bool bUseFixDT; // 0x6c Size: 0x1
	    char UnknownData1[0x-1];

};

struct FNamedEmitterMaterial
{
	public:
	    FName Name; // 0x0 Size: 0x8
	    class UMaterialInterface* Material; // 0x8 Size: 0x8

};

struct FParticleSystemLOD
{
	public:
	    char UnknownData0[0x1];

};

struct FParticleSystemWorldManagerTickFunction : public FTickFunction
{
	public:
	    char UnknownData0[0x58];

};

struct FParticleSystemReplayFrame
{
	public:
	    char UnknownData0[0x10];

};

struct FParticleEmitterReplayFrame
{
	public:
	    char UnknownData0[0x10];

};

struct FPhysicalAnimationData
{
	public:
	    FName BodyName; // 0x0 Size: 0x8
	    bool bIsLocalSimulation; // 0x8 Size: 0x1
	    char UnknownData0[0x3]; // 0x9
	    float OrientationStrength; // 0xc Size: 0x4
	    float AngularVelocityStrength; // 0x10 Size: 0x4
	    float PositionStrength; // 0x14 Size: 0x4
	    float VelocityStrength; // 0x18 Size: 0x4
	    float MaxLinearForce; // 0x1c Size: 0x4
	    float MaxAngularForce; // 0x20 Size: 0x4

};

struct FTireFrictionScalePair
{
	public:
	    class UTireType* TireType; // 0x0 Size: 0x8
	    float FrictionScale; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FPhysicalAnimationProfile
{
	public:
	    FName ProfileName; // 0x0 Size: 0x8
	    struct FPhysicalAnimationData PhysicalAnimationData; // 0x8 Size: 0x24

};

struct FPhysicsConstraintProfileHandle
{
	public:
	    struct FConstraintProfileProperties ProfileProperties; // 0x0 Size: 0x104
	    FName ProfileName; // 0x104 Size: 0x8

};

struct FPhysicalSurfaceName
{
	public:
	    char Type; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    FName Name; // 0x4 Size: 0x8

};

struct FInputAxisKeyMapping
{
	public:
	    FName AxisName; // 0x0 Size: 0x8
	    float Scale; // 0x8 Size: 0x4
	    char UnknownData0[0x4]; // 0xc
	    struct FKey Key; // 0x10 Size: 0x18

};

struct FInputActionKeyMapping
{
	public:
	    FName ActionName; // 0x0 Size: 0x8
	    bool bShift; // 0x8 Size: 0x1
	    bool bCtrl; // 0x8 Size: 0x1
	    bool bAlt; // 0x8 Size: 0x1
	    bool bCmd; // 0x8 Size: 0x1
	    char UnknownData0[0x4]; // 0xc
	    struct FKey Key; // 0x10 Size: 0x18

};

struct FInputAxisProperties
{
	public:
	    float DeadZone; // 0x0 Size: 0x4
	    float Sensitivity; // 0x4 Size: 0x4
	    float Exponent; // 0x8 Size: 0x4
	    bool bInvert; // 0xc Size: 0x1
	    char UnknownData0[0x3];

};

struct FInputAxisConfigEntry
{
	public:
	    FName AxisKeyName; // 0x0 Size: 0x8
	    struct FInputAxisProperties AxisProperties; // 0x8 Size: 0x10

};

struct FKeyBind
{
	public:
	    struct FKey Key; // 0x0 Size: 0x18
	    struct FString Command; // 0x18 Size: 0x10
	    bool Control; // 0x28 Size: 0x1
	    bool Shift; // 0x28 Size: 0x1
	    bool Alt; // 0x28 Size: 0x1
	    bool Cmd; // 0x28 Size: 0x1
	    bool bIgnoreCtrl; // 0x28 Size: 0x1
	    bool bIgnoreShift; // 0x28 Size: 0x1
	    bool bIgnoreAlt; // 0x28 Size: 0x1
	    bool bIgnoreCmd; // 0x28 Size: 0x1
	    bool bDisabled; // 0x29 Size: 0x1
	    char UnknownData0[0x-1];

};

struct FPlayerMuteList
{
	public:
	    bool bHasVoiceHandshakeCompleted; // 0x30 Size: 0x1
	    char UnknownData0[0x3]; // 0x31
	    int VoiceChannelIdx; // 0x34 Size: 0x4

};

struct FPreviewAttachedObjectPair
{
	public:
	    struct TSoftObjectPtr<struct UObject*> AttachedObject; // 0x0 Size: 0x28
	    class UObject* Object; // 0x28 Size: 0x8
	    FName AttachedTo; // 0x30 Size: 0x8

};

struct FPreviewMeshCollectionEntry
{
	public:
	    struct TSoftObjectPtr<struct USkeletalMesh*> SkeletalMesh; // 0x0 Size: 0x28

};

struct FSpriteCategoryInfo
{
	public:
	    FName Category; // 0x0 Size: 0x8
	    struct FText DisplayName; // 0x8 Size: 0x18
	    struct FText Description; // 0x20 Size: 0x18

};

struct FRigTransformConstraint
{
	public:
	    char TranformType; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    FName ParentSpace; // 0x4 Size: 0x8
	    float Weight; // 0xc Size: 0x4

};

struct FNode
{
	public:
	    FName Name; // 0x0 Size: 0x8
	    FName ParentName; // 0x8 Size: 0x8
	    struct FTransform Transform; // 0x10 Size: 0x30
	    struct FString DisplayName; // 0x40 Size: 0x10
	    bool bAdvanced; // 0x50 Size: 0x1
	    char UnknownData0[0xf];

};

struct FRootMotionFinishVelocitySettings
{
	public:
	    ERootMotionFinishVelocityMode Mode; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    struct FVector SetVelocity; // 0x4 Size: 0xc
	    float ClampVelocity; // 0x10 Size: 0x4

};

struct FRootMotionSourceStatus
{
	public:
	    char Flags; // 0x0 Size: 0x1

};

struct FRootMotionSource
{
	public:
	    __int64/*UInt16Property*/ Priority; // 0x10 Size: 0x2
	    __int64/*UInt16Property*/ LocalID; // 0x12 Size: 0x2
	    ERootMotionAccumulateMode AccumulateMode; // 0x14 Size: 0x1
	    char UnknownData0[0x3]; // 0x15
	    FName InstanceName; // 0x18 Size: 0x8
	    float StartTime; // 0x20 Size: 0x4
	    float CurrentTime; // 0x24 Size: 0x4
	    float PreviousTime; // 0x28 Size: 0x4
	    float Duration; // 0x2c Size: 0x4
	    struct FRootMotionSourceStatus Status; // 0x30 Size: 0x1
	    struct FRootMotionSourceSettings Settings; // 0x31 Size: 0x1
	    bool bInLocalSpace; // 0x32 Size: 0x1
	    char UnknownData1[0xd]; // 0x33
	    struct FRootMotionMovementParams RootMotionParams; // 0x40 Size: 0x40
	    struct FRootMotionFinishVelocitySettings FinishVelocityParams; // 0x80 Size: 0x14
	    char UnknownData2[0xc];

};

struct FRootMotionSource_JumpForce : public FRootMotionSource
{
	public:
	    struct FRotator Rotation; // 0x98 Size: 0xc
	    float Distance; // 0xa4 Size: 0x4
	    float Height; // 0xa8 Size: 0x4
	    bool bDisableTimeout; // 0xac Size: 0x1
	    char UnknownData0[0x3]; // 0xad
	    class UCurveVector* PathOffsetCurve; // 0xb0 Size: 0x8
	    class UCurveFloat* TimeMappingCurve; // 0xb8 Size: 0x8
	    char UnknownData1[0x10];

};

struct FRootMotionSource_MoveToDynamicForce : public FRootMotionSource
{
	public:
	    struct FVector StartLocation; // 0x98 Size: 0xc
	    struct FVector InitialTargetLocation; // 0xa4 Size: 0xc
	    struct FVector TargetLocation; // 0xb0 Size: 0xc
	    bool bRestrictSpeedToExpected; // 0xbc Size: 0x1
	    char UnknownData0[0x3]; // 0xbd
	    class UCurveVector* PathOffsetCurve; // 0xc0 Size: 0x8
	    class UCurveFloat* TimeMappingCurve; // 0xc8 Size: 0x8

};

struct FRootMotionSource_MoveToForce : public FRootMotionSource
{
	public:
	    struct FVector StartLocation; // 0x98 Size: 0xc
	    struct FVector TargetLocation; // 0xa4 Size: 0xc
	    bool bRestrictSpeedToExpected; // 0xb0 Size: 0x1
	    char UnknownData0[0x7]; // 0xb1
	    class UCurveVector* PathOffsetCurve; // 0xb8 Size: 0x8

};

struct FRootMotionSource_RadialForce : public FRootMotionSource
{
	public:
	    struct FVector Location; // 0x98 Size: 0xc
	    char UnknownData0[0x4]; // 0xa4
	    class AActor* LocationActor; // 0xa8 Size: 0x8
	    float Radius; // 0xb0 Size: 0x4
	    float Strength; // 0xb4 Size: 0x4
	    bool bIsPush; // 0xb8 Size: 0x1
	    bool bNoZForce; // 0xb9 Size: 0x1
	    char UnknownData1[0x6]; // 0xba
	    class UCurveFloat* StrengthDistanceFalloff; // 0xc0 Size: 0x8
	    class UCurveFloat* StrengthOverTime; // 0xc8 Size: 0x8
	    bool bUseFixedWorldDirection; // 0xd0 Size: 0x1
	    char UnknownData2[0x3]; // 0xd1
	    struct FRotator FixedWorldDirection; // 0xd4 Size: 0xc

};

struct FRootMotionSource_ConstantForce : public FRootMotionSource
{
	public:
	    struct FVector Force; // 0x98 Size: 0xc
	    char UnknownData0[0x4]; // 0xa4
	    class UCurveFloat* StrengthOverTime; // 0xa8 Size: 0x8

};

struct FCameraExposureSettings
{
	public:
	    char Method; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float LowPercent; // 0x4 Size: 0x4
	    float HighPercent; // 0x8 Size: 0x4
	    float MinBrightness; // 0xc Size: 0x4
	    float MaxBrightness; // 0x10 Size: 0x4
	    float SpeedUp; // 0x14 Size: 0x4
	    float SpeedDown; // 0x18 Size: 0x4
	    float Bias; // 0x1c Size: 0x4
	    float HistogramLogMin; // 0x20 Size: 0x4
	    float HistogramLogMax; // 0x24 Size: 0x4
	    float CalibrationConstant; // 0x28 Size: 0x4

};

struct FLensImperfectionSettings
{
	public:
	    class UTexture* DirtMask; // 0x0 Size: 0x8
	    float DirtMaskIntensity; // 0x8 Size: 0x4
	    struct FLinearColor DirtMaskTint; // 0xc Size: 0x10
	    char UnknownData0[0x4];

};

struct FConvolutionBloomSettings
{
	public:
	    class UTexture2D* Texture; // 0x0 Size: 0x8
	    float Size; // 0x8 Size: 0x4
	    struct FVector2D CenterUV; // 0xc Size: 0x8
	    float PreFilterMin; // 0x14 Size: 0x4
	    float PreFilterMax; // 0x18 Size: 0x4
	    float PreFilterMult; // 0x1c Size: 0x4
	    float BufferScale; // 0x20 Size: 0x4
	    char UnknownData0[0x4];

};

struct FGaussianSumBloomSettings
{
	public:
	    float Intensity; // 0x0 Size: 0x4
	    float Threshold; // 0x4 Size: 0x4
	    float SizeScale; // 0x8 Size: 0x4
	    float Filter1Size; // 0xc Size: 0x4
	    float Filter2Size; // 0x10 Size: 0x4
	    float Filter3Size; // 0x14 Size: 0x4
	    float Filter4Size; // 0x18 Size: 0x4
	    float Filter5Size; // 0x1c Size: 0x4
	    float Filter6Size; // 0x20 Size: 0x4
	    struct FLinearColor Filter1Tint; // 0x24 Size: 0x10
	    struct FLinearColor Filter2Tint; // 0x34 Size: 0x10
	    struct FLinearColor Filter3Tint; // 0x44 Size: 0x10
	    struct FLinearColor Filter4Tint; // 0x54 Size: 0x10
	    struct FLinearColor Filter5Tint; // 0x64 Size: 0x10
	    struct FLinearColor Filter6Tint; // 0x74 Size: 0x10

};

struct FLensBloomSettings
{
	public:
	    struct FGaussianSumBloomSettings GaussianSum; // 0x0 Size: 0x84
	    char UnknownData0[0x4]; // 0x84
	    struct FConvolutionBloomSettings Convolution; // 0x88 Size: 0x28
	    char Method; // 0xb0 Size: 0x1
	    char UnknownData1[0x7];

};

struct FLensSettings
{
	public:
	    struct FLensBloomSettings Bloom; // 0x0 Size: 0xb8
	    struct FLensImperfectionSettings Imperfections; // 0xb8 Size: 0x20
	    float ChromaticAberration; // 0xd8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFilmStockSettings
{
	public:
	    float Slope; // 0x0 Size: 0x4
	    float Toe; // 0x4 Size: 0x4
	    float Shoulder; // 0x8 Size: 0x4
	    float BlackClip; // 0xc Size: 0x4
	    float WhiteClip; // 0x10 Size: 0x4

};

struct FColorGradePerRangeSettings
{
	public:
	    struct FVector4 Saturation; // 0x0 Size: 0x10
	    struct FVector4 Contrast; // 0x10 Size: 0x10
	    struct FVector4 Gamma; // 0x20 Size: 0x10
	    struct FVector4 Gain; // 0x30 Size: 0x10
	    struct FVector4 Offset; // 0x40 Size: 0x10

};

struct FColorGradingSettings
{
	public:
	    struct FColorGradePerRangeSettings Global; // 0x0 Size: 0x50
	    struct FColorGradePerRangeSettings Shadows; // 0x50 Size: 0x50
	    struct FColorGradePerRangeSettings Midtones; // 0xa0 Size: 0x50
	    struct FColorGradePerRangeSettings Highlights; // 0xf0 Size: 0x50
	    float ShadowsMax; // 0x140 Size: 0x4
	    float HighlightsMin; // 0x144 Size: 0x4
	    char UnknownData0[0x8];

};

struct FEngineShowFlagsSetting
{
	public:
	    struct FString ShowFlagName; // 0x0 Size: 0x10
	    bool Enabled; // 0x10 Size: 0x1
	    char UnknownData0[0x7];

};

struct FSimpleCurveKey
{
	public:
	    float Time; // 0x0 Size: 0x4
	    float Value; // 0x4 Size: 0x4

};

struct FSingleAnimationPlayData
{
	public:
	    class UAnimationAsset* AnimToPlay; // 0x0 Size: 0x8
	    bool bSavedLooping; // 0x8 Size: 0x1
	    bool bSavedPlaying; // 0x8 Size: 0x1
	    char UnknownData0[0x2]; // 0xa
	    float SavedPosition; // 0xc Size: 0x4
	    float SavedPlayRate; // 0x10 Size: 0x4
	    char UnknownData1[0x4];

};

struct FSkeletalMaterial
{
	public:
	    class UMaterialInterface* MaterialInterface; // 0x0 Size: 0x8
	    FName MaterialSlotName; // 0x8 Size: 0x8
	    struct FMeshUVChannelInfo UVChannelData; // 0x10 Size: 0x14
	    char UnknownData0[0x4];

};

struct FClothPhysicsProperties_Legacy
{
	public:
	    float VerticalResistance; // 0x0 Size: 0x4
	    float HorizontalResistance; // 0x4 Size: 0x4
	    float BendResistance; // 0x8 Size: 0x4
	    float ShearResistance; // 0xc Size: 0x4
	    float Friction; // 0x10 Size: 0x4
	    float Damping; // 0x14 Size: 0x4
	    float TetherStiffness; // 0x18 Size: 0x4
	    float TetherLimit; // 0x1c Size: 0x4
	    float Drag; // 0x20 Size: 0x4
	    float StiffnessFrequency; // 0x24 Size: 0x4
	    float GravityScale; // 0x28 Size: 0x4
	    float MassScale; // 0x2c Size: 0x4
	    float InertiaBlend; // 0x30 Size: 0x4
	    float SelfCollisionThickness; // 0x34 Size: 0x4
	    float SelfCollisionSquashScale; // 0x38 Size: 0x4
	    float SelfCollisionStiffness; // 0x3c Size: 0x4
	    float SolverFrequency; // 0x40 Size: 0x4
	    float FiberCompression; // 0x44 Size: 0x4
	    float FiberExpansion; // 0x48 Size: 0x4
	    float FiberResistance; // 0x4c Size: 0x4

};

struct FClothingAssetData_Legacy
{
	public:
	    FName AssetName; // 0x0 Size: 0x8
	    struct FString ApexFileName; // 0x8 Size: 0x10
	    bool bClothPropertiesChanged; // 0x18 Size: 0x1
	    char UnknownData0[0x3]; // 0x19
	    struct FClothPhysicsProperties_Legacy PhysicsProperties; // 0x1c Size: 0x50
	    char UnknownData1[0xc];

};

struct FSkeletalMeshOptimizationSettings
{
	public:
	    char TerminationCriterion; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float NumOfTrianglesPercentage; // 0x4 Size: 0x4
	    float NumOfVertPercentage; // 0x8 Size: 0x4
	    float MaxDeviationPercentage; // 0xc Size: 0x4
	    char ReductionMethod; // 0x10 Size: 0x1
	    char SilhouetteImportance; // 0x11 Size: 0x1
	    char TextureImportance; // 0x12 Size: 0x1
	    char ShadingImportance; // 0x13 Size: 0x1
	    char SkinningImportance; // 0x14 Size: 0x1
	    bool bRemapMorphTargets; // 0x15 Size: 0x1
	    bool bRecalcNormals; // 0x15 Size: 0x1
	    char UnknownData1[0x1]; // 0x17
	    float WeldingThreshold; // 0x18 Size: 0x4
	    float NormalsThreshold; // 0x1c Size: 0x4
	    int MaxBonesPerVertex; // 0x20 Size: 0x4
	    bool bEnforceBoneBoundaries; // 0x24 Size: 0x1
	    char UnknownData2[0x3]; // 0x25
	    float VolumeImportance; // 0x28 Size: 0x4
	    bool bLockEdges; // 0x2c Size: 0x1
	    char UnknownData3[0x3]; // 0x2d
	    int BaseLOD; // 0x30 Size: 0x4

};

struct FSkeletalMeshClothBuildParams
{
	public:
	    TWeakObjectPtr<UClothingAssetBase*> TargetAsset; // 0x0 Size: 0x8
	    int TargetLod; // 0x8 Size: 0x4
	    bool bRemapParameters; // 0xc Size: 0x1
	    char UnknownData0[0x3]; // 0xd
	    struct FString AssetName; // 0x10 Size: 0x10
	    int LODIndex; // 0x20 Size: 0x4
	    int SourceSection; // 0x24 Size: 0x4
	    bool bRemoveFromMesh; // 0x28 Size: 0x1
	    char UnknownData1[0x7]; // 0x29
	    struct TSoftObjectPtr<struct UPhysicsAsset*> PhysicsAsset; // 0x30 Size: 0x28

};

struct FBoneMirrorExport
{
	public:
	    FName BoneName; // 0x0 Size: 0x8
	    FName SourceBoneName; // 0x8 Size: 0x8
	    char BoneFlipAxis; // 0x10 Size: 0x1
	    char UnknownData0[0x3];

};

struct FBoneMirrorInfo
{
	public:
	    int SourceIndex; // 0x0 Size: 0x4
	    char BoneFlipAxis; // 0x4 Size: 0x1
	    char UnknownData0[0x3];

};

struct FSkeletalMeshComponentClothTickFunction : public FTickFunction
{
	public:
	    char UnknownData0[0x58];

};

struct FSkeletalMeshComponentEndPhysicsTickFunction : public FTickFunction
{
	public:
	    char UnknownData0[0x58];

};

struct FBoneFilter
{
	public:
	    bool bExcludeSelf; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    FName BoneName; // 0x4 Size: 0x8

};

struct FSkeletalMeshSamplingRegionBuiltData
{
	public:
	    char UnknownData0[0x78];

};

struct FSkeletalMeshSamplingLODBuiltData
{
	public:
	    char UnknownData0[0x48];

};

struct FSkeletalMeshSamplingRegionBoneFilter
{
	public:
	    FName BoneName; // 0x0 Size: 0x8
	    bool bIncludeOrExclude; // 0x8 Size: 0x1
	    bool bApplyToChildren; // 0x8 Size: 0x1
	    char UnknownData0[0x2];

};

struct FSkeletalMeshSamplingRegionMaterialFilter
{
	public:
	    FName MaterialName; // 0x0 Size: 0x8

};

struct FVirtualBone
{
	public:
	    FName SourceBoneName; // 0x0 Size: 0x8
	    FName TargetBoneName; // 0x8 Size: 0x8
	    FName VirtualBoneName; // 0x10 Size: 0x8

};

struct FNameMapping
{
	public:
	    FName NodeName; // 0x0 Size: 0x8
	    FName BoneName; // 0x8 Size: 0x8

};

struct FBoneNode
{
	public:
	    FName Name; // 0x0 Size: 0x8
	    int ParentIndex; // 0x8 Size: 0x4
	    char TranslationRetargetingMode; // 0xc Size: 0x1
	    char UnknownData0[0x3];

};

struct FSkelMeshSkinWeightInfo
{
	public:
	    int Bones; // 0x0 Size: 0x4
	    char UnknownData0[0x1c]; // 0x4
	    char Weights; // 0x20 Size: 0x1
	    char UnknownData1[0x7];

};

struct FSmartNameContainer
{
	public:
	    char UnknownData0[0x50];

};

struct FSmartNameMapping
{
	public:
	    char UnknownData0[0x60];

};

struct FCurveMetaData
{
	public:
	    char UnknownData0[0x20];

};

struct FPassiveSoundMixModifier
{
	public:
	    class USoundMix* SoundMix; // 0x0 Size: 0x8
	    float MinVolumeThreshold; // 0x8 Size: 0x4
	    float MaxVolumeThreshold; // 0xc Size: 0x4

};

struct FSoundClassProperties
{
	public:
	    float Volume; // 0x0 Size: 0x4
	    float Pitch; // 0x4 Size: 0x4
	    float StereoBleed; // 0x8 Size: 0x4
	    float LFEBleed; // 0xc Size: 0x4
	    float VoiceCenterChannelVolume; // 0x10 Size: 0x4
	    float RadioFilterVolume; // 0x14 Size: 0x4
	    float RadioFilterVolumeThreshold; // 0x18 Size: 0x4
	    bool bApplyEffects; // 0x1c Size: 0x1
	    bool bAlwaysPlay; // 0x1c Size: 0x1
	    bool bIsUISound; // 0x1c Size: 0x1
	    bool bIsMusic; // 0x1c Size: 0x1
	    bool bReverb; // 0x1c Size: 0x1
	    Yea, we fucked up; // 0x0
	    float Default2DReverbSendAmount; // 0x20 Size: 0x4
	    bool bCenterChannelOnly; // 0x24 Size: 0x1
	    bool bApplyAmbientVolumes; // 0x24 Size: 0x1
	    char UnknownData1[0x2]; // 0x26
	    char OutputTarget; // 0x28 Size: 0x1
	    char UnknownData2[0x3];

};

struct FSoundClassEditorData
{
	public:
	    char UnknownData0[0x8];

};

struct FSoundConcurrencySettings
{
	public:
	    int MaxCount; // 0x0 Size: 0x4
	    bool bLimitToOwner; // 0x4 Size: 0x1
	    char UnknownData0[0x3]; // 0x5
	    char ResolutionRule; // 0x8 Size: 0x1
	    char UnknownData1[0x3]; // 0x9
	    float VolumeScale; // 0xc Size: 0x4

};

struct FSoundNodeEditorData
{
	public:
	    char UnknownData0[0x8];

};

struct FSourceEffectChainEntry
{
	public:
	    class USoundEffectSourcePreset* Preset; // 0x0 Size: 0x8
	    bool bBypass; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FSoundGroup
{
	public:
	    char SoundGroup; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FString DisplayName; // 0x8 Size: 0x10
	    bool bAlwaysDecompressOnLoad; // 0x18 Size: 0x1
	    char UnknownData1[0x3]; // 0x19
	    float DecompressedDuration; // 0x1c Size: 0x4

};

struct FSoundClassAdjuster
{
	public:
	    class USoundClass* SoundClassObject; // 0x0 Size: 0x8
	    float VolumeAdjuster; // 0x8 Size: 0x4
	    float PitchAdjuster; // 0xc Size: 0x4
	    bool bApplyToChildren; // 0x10 Size: 0x1
	    char UnknownData0[0x3]; // 0x11
	    float VoiceCenterChannelVolumeAdjuster; // 0x14 Size: 0x4

};

struct FAudioEQEffect
{
	public:
	    float FrequencyCenter0; // 0x8 Size: 0x4
	    float Gain0; // 0xc Size: 0x4
	    float Bandwidth0; // 0x10 Size: 0x4
	    float FrequencyCenter1; // 0x14 Size: 0x4
	    float Gain1; // 0x18 Size: 0x4
	    float Bandwidth1; // 0x1c Size: 0x4
	    float FrequencyCenter2; // 0x20 Size: 0x4
	    float Gain2; // 0x24 Size: 0x4
	    float Bandwidth2; // 0x28 Size: 0x4
	    float FrequencyCenter3; // 0x2c Size: 0x4
	    float Gain3; // 0x30 Size: 0x4
	    float Bandwidth3; // 0x34 Size: 0x4

};

struct FDistanceDatum
{
	public:
	    float FadeInDistanceStart; // 0x0 Size: 0x4
	    float FadeInDistanceEnd; // 0x4 Size: 0x4
	    float FadeOutDistanceStart; // 0x8 Size: 0x4
	    float FadeOutDistanceEnd; // 0xc Size: 0x4
	    float Volume; // 0x10 Size: 0x4

};

struct FModulatorContinuousParams
{
	public:
	    FName ParameterName; // 0x0 Size: 0x8
	    float Default; // 0x8 Size: 0x4
	    float MinInput; // 0xc Size: 0x4
	    float MaxInput; // 0x10 Size: 0x4
	    float MinOutput; // 0x14 Size: 0x4
	    float MaxOutput; // 0x18 Size: 0x4
	    char ParamMode; // 0x1c Size: 0x1
	    char UnknownData0[0x3];

};

struct FSoundSourceBusSendInfo
{
	public:
	    float SendLevel; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    class USoundSourceBus* SoundSourceBus; // 0x8 Size: 0x8

};

struct FSoundSubmixSendInfo
{
	public:
	    float SendLevel; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    class USoundSubmix* SoundSubmix; // 0x8 Size: 0x8

};

struct FStreamedAudioPlatformData
{
	public:
	    char UnknownData0[0x20];

};

struct FSplinePoint
{
	public:
	    float InputKey; // 0x0 Size: 0x4
	    struct FVector Position; // 0x4 Size: 0xc
	    struct FVector ArriveTangent; // 0x10 Size: 0xc
	    struct FVector LeaveTangent; // 0x1c Size: 0xc
	    struct FRotator Rotation; // 0x28 Size: 0xc
	    struct FVector Scale; // 0x34 Size: 0xc
	    char Type; // 0x40 Size: 0x1
	    char UnknownData0[0x3];

};

struct FSplineMeshParams
{
	public:
	    struct FVector StartPos; // 0x0 Size: 0xc
	    struct FVector StartTangent; // 0xc Size: 0xc
	    struct FVector2D StartScale; // 0x18 Size: 0x8
	    float StartRoll; // 0x20 Size: 0x4
	    struct FVector2D StartOffset; // 0x24 Size: 0x8
	    struct FVector EndPos; // 0x2c Size: 0xc
	    struct FVector EndTangent; // 0x38 Size: 0xc
	    struct FVector2D EndScale; // 0x44 Size: 0x8
	    float EndRoll; // 0x4c Size: 0x4
	    struct FVector2D EndOffset; // 0x50 Size: 0x8

};

struct FStaticMaterial
{
	public:
	    class UMaterialInterface* MaterialInterface; // 0x0 Size: 0x8
	    FName MaterialSlotName; // 0x8 Size: 0x8
	    FName ImportedMaterialSlotName; // 0x10 Size: 0x8
	    struct FMeshUVChannelInfo UVChannelData; // 0x18 Size: 0x14
	    char UnknownData0[0x4];

};

struct FAssetEditorOrbitCameraPosition
{
	public:
	    bool bIsSet; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    struct FVector CamOrbitPoint; // 0x4 Size: 0xc
	    struct FVector CamOrbitZoom; // 0x10 Size: 0xc
	    struct FRotator CamOrbitRotation; // 0x1c Size: 0xc

};

struct FMeshSectionInfoMap
{
	public:
	    __int64/*MapProperty*/ Map; // 0x0 Size: 0x50

};

struct FMeshSectionInfo
{
	public:
	    int MaterialIndex; // 0x0 Size: 0x4
	    bool bEnableCollision; // 0x4 Size: 0x1
	    bool bCastShadow; // 0x5 Size: 0x1
	    char UnknownData0[0x2];

};

struct FStaticMeshSourceModel
{
	public:
	    struct FMeshBuildSettings BuildSettings; // 0x0 Size: 0x30
	    struct FMeshReductionSettings ReductionSettings; // 0x30 Size: 0x24
	    float LODDistance; // 0x54 Size: 0x4
	    struct FPerPlatformFloat ScreenSize; // 0x58 Size: 0x4
	    char UnknownData0[0x4]; // 0x5c
	    struct FString SourceImportFilename; // 0x60 Size: 0x10

};

struct FStaticMeshOptimizationSettings
{
	public:
	    char ReductionMethod; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float NumOfTrianglesPercentage; // 0x4 Size: 0x4
	    float MaxDeviationPercentage; // 0x8 Size: 0x4
	    float WeldingThreshold; // 0xc Size: 0x4
	    bool bRecalcNormals; // 0x10 Size: 0x1
	    char UnknownData1[0x3]; // 0x11
	    float NormalsThreshold; // 0x14 Size: 0x4
	    char SilhouetteImportance; // 0x18 Size: 0x1
	    char TextureImportance; // 0x19 Size: 0x1
	    char ShadingImportance; // 0x1a Size: 0x1
	    char UnknownData2[0x1];

};

struct FPaintedVertex
{
	public:
	    struct FVector Position; // 0x0 Size: 0xc
	    char UnknownData0[0x4]; // 0xc
	    struct FVector4 Normal; // 0x10 Size: 0x10
	    struct FColor Color; // 0x20 Size: 0x4
	    char UnknownData1[0xc];

};

struct FStaticTerrainLayerWeightParameter
{
	public:
	    struct FMaterialParameterInfo ParameterInfo; // 0x0 Size: 0x10
	    bool bOverride; // 0x10 Size: 0x1
	    char UnknownData0[0x3]; // 0x11
	    struct FGuid ExpressionGUID; // 0x14 Size: 0x10
	    int WeightmapIndex; // 0x24 Size: 0x4
	    bool bWeightBasedBlend; // 0x28 Size: 0x1
	    char UnknownData1[0x3];

};

struct FStaticComponentMaskParameter
{
	public:
	    struct FMaterialParameterInfo ParameterInfo; // 0x0 Size: 0x10
	    bool R; // 0x10 Size: 0x1
	    bool G; // 0x11 Size: 0x1
	    bool B; // 0x12 Size: 0x1
	    bool A; // 0x13 Size: 0x1
	    bool bOverride; // 0x14 Size: 0x1
	    char UnknownData0[0x3]; // 0x15
	    struct FGuid ExpressionGUID; // 0x18 Size: 0x10

};

struct FStaticSwitchParameter
{
	public:
	    struct FMaterialParameterInfo ParameterInfo; // 0x0 Size: 0x10
	    bool Value; // 0x10 Size: 0x1
	    bool bOverride; // 0x11 Size: 0x1
	    char UnknownData0[0x2]; // 0x12
	    struct FGuid ExpressionGUID; // 0x14 Size: 0x10

};

struct FStringCurveKey
{
	public:
	    float Time; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    struct FString Value; // 0x8 Size: 0x10

};

struct FSubsurfaceProfileStruct
{
	public:
	    float ScatterRadius; // 0x0 Size: 0x4
	    struct FLinearColor SubsurfaceColor; // 0x4 Size: 0x10
	    struct FLinearColor FalloffColor; // 0x14 Size: 0x10
	    struct FLinearColor BoundaryColorBleed; // 0x24 Size: 0x10
	    float ExtinctionScale; // 0x34 Size: 0x4
	    float NormalScale; // 0x38 Size: 0x4
	    float ScatteringDistribution; // 0x3c Size: 0x4
	    float IOR; // 0x40 Size: 0x4
	    float Roughness0; // 0x44 Size: 0x4
	    float Roughness1; // 0x48 Size: 0x4
	    float LobeMix; // 0x4c Size: 0x4

};

struct FTexturePlatformData
{
	public:
	    char UnknownData0[0x20];

};

struct FTextureSource
{
	public:
	    char UnknownData0[0x80];

};

struct FTextureLODGroup
{
	public:
	    char Group; // 0x0 Size: 0x1
	    char UnknownData0[0xb]; // 0x1
	    int LODBias; // 0xc Size: 0x4
	    int LODBias_Smaller; // 0x10 Size: 0x4
	    int LODBias_Smallest; // 0x14 Size: 0x4
	    char UnknownData1[0x4]; // 0x18
	    int NumStreamedMips; // 0x1c Size: 0x4
	    char MipGenSettings; // 0x20 Size: 0x1
	    char UnknownData2[0x3]; // 0x21
	    int MinLODSize; // 0x24 Size: 0x4
	    int MaxLODSize; // 0x28 Size: 0x4
	    int MaxLODSize_Smaller; // 0x2c Size: 0x4
	    int MaxLODSize_Smallest; // 0x30 Size: 0x4
	    int OptionalLODBias; // 0x34 Size: 0x4
	    int OptionalMaxLODSize; // 0x38 Size: 0x4
	    char UnknownData3[0x4]; // 0x3c
	    FName MinMagFilter; // 0x40 Size: 0x8
	    FName MipFilter; // 0x48 Size: 0x8

};

struct FStreamingTextureBuildInfo
{
	public:
	    uint32_t PackedRelativeBox; // 0x0 Size: 0x4
	    int TextureLevelIndex; // 0x4 Size: 0x4
	    float TexelFactor; // 0x8 Size: 0x4

};

struct FStreamingTexturePrimitiveInfo
{
	public:
	    class UTexture2D* Texture; // 0x0 Size: 0x8
	    struct FBoxSphereBounds Bounds; // 0x8 Size: 0x1c
	    float TexelFactor; // 0x24 Size: 0x4
	    uint32_t PackedRelativeBox; // 0x28 Size: 0x4
	    char UnknownData0[0x4];

};

struct FTimelineLinearColorTrack
{
	public:
	    class UCurveLinearColor* LinearColorCurve; // 0x0 Size: 0x8
	    __int64/*DelegateProperty*/ InterpFunc; // 0x8 Size: 0x10
	    FName TrackName; // 0x18 Size: 0x8
	    FName LinearColorPropertyName; // 0x20 Size: 0x8
	    class UStructProperty* LinearColorProperty; // 0x28 Size: 0x8
	    char UnknownData0[0x10];

};

struct FTimelineFloatTrack
{
	public:
	    class UCurveFloat* FloatCurve; // 0x0 Size: 0x8
	    __int64/*DelegateProperty*/ InterpFunc; // 0x8 Size: 0x10
	    FName TrackName; // 0x18 Size: 0x8
	    FName FloatPropertyName; // 0x20 Size: 0x8
	    class UFloatProperty* FloatProperty; // 0x28 Size: 0x8
	    char UnknownData0[0x10];

};

struct FTimelineVectorTrack
{
	public:
	    class UCurveVector* VectorCurve; // 0x0 Size: 0x8
	    __int64/*DelegateProperty*/ InterpFunc; // 0x8 Size: 0x10
	    FName TrackName; // 0x18 Size: 0x8
	    FName VectorPropertyName; // 0x20 Size: 0x8
	    class UStructProperty* VectorProperty; // 0x28 Size: 0x8
	    char UnknownData0[0x10];

};

struct FTimelineEventEntry
{
	public:
	    float Time; // 0x0 Size: 0x4
	    __int64/*DelegateProperty*/ EventFunc; // 0x4 Size: 0x10

};

struct FTTTrackBase
{
	public:
	    FName TrackName; // 0x8 Size: 0x8
	    bool bIsExternalCurve; // 0x10 Size: 0x1
	    char UnknownData0[0x7];

};

struct FTTPropertyTrack : public FTTTrackBase
{
	public:
	    FName PropertyName; // 0x18 Size: 0x8

};

struct FTTLinearColorTrack : public FTTPropertyTrack
{
	public:
	    class UCurveLinearColor* CurveLinearColor; // 0x20 Size: 0x8

};

struct FTTVectorTrack : public FTTPropertyTrack
{
	public:
	    class UCurveVector* CurveVector; // 0x20 Size: 0x8

};

struct FTTFloatTrack : public FTTPropertyTrack
{
	public:
	    class UCurveFloat* CurveFloat; // 0x20 Size: 0x8

};

struct FTTEventTrack : public FTTTrackBase
{
	public:
	    FName FunctionName; // 0x18 Size: 0x8
	    class UCurveFloat* CurveKeys; // 0x20 Size: 0x8

};

struct FTimeStretchCurveInstance
{
	public:
	    bool bHasValidData; // 0x0 Size: 0x1
	    char UnknownData0[0x2f];

};

struct FTimeStretchCurveMarker
{
	public:
	    float Time; // 0x0 Size: 0x4
	    char UnknownData0[0x8]; // 0x4
	    float Alpha; // 0xc Size: 0x4

};

struct FTouchInputControl
{
	public:
	    class UTexture2D* Image1; // 0x0 Size: 0x8
	    class UTexture2D* Image2; // 0x8 Size: 0x8
	    struct FVector2D Center; // 0x10 Size: 0x8
	    struct FVector2D VisualSize; // 0x18 Size: 0x8
	    struct FVector2D ThumbSize; // 0x20 Size: 0x8
	    struct FVector2D InteractionSize; // 0x28 Size: 0x8
	    struct FVector2D InputScale; // 0x30 Size: 0x8
	    struct FKey MainInputKey; // 0x38 Size: 0x18
	    struct FKey AltInputKey; // 0x50 Size: 0x18

};

struct FHardwareCursorReference
{
	public:
	    FName CursorPath; // 0x0 Size: 0x8
	    struct FVector2D HotSpot; // 0x8 Size: 0x8

};

struct FVirtualTextureLayer
{
	public:
	    char Format; // 0x0 Size: 0x1
	    bool bCompressed; // 0x1 Size: 0x1
	    bool bHasAlpha; // 0x2 Size: 0x1
	    char CompressionSettings; // 0x3 Size: 0x1

};

struct FVoiceSettings
{
	public:
	    class USceneComponent* ComponentToAttachTo; // 0x0 Size: 0x8
	    class USoundAttenuation* AttenuationSettings; // 0x8 Size: 0x8
	    class USoundEffectSourcePresetChain* SourceEffectChain; // 0x10 Size: 0x8

};

struct FLevelStreamingWrapper
{
	public:
	    class ULevelStreaming* StreamingLevel; // 0x0 Size: 0x8

};

struct FLevelCollection
{
	public:
	    class AGameStateBase* GameState; // 0x8 Size: 0x8
	    class UNetDriver* NetDriver; // 0x10 Size: 0x8
	    class UDemoNetDriver* DemoNetDriver; // 0x18 Size: 0x8
	    class ULevel* PersistentLevel; // 0x20 Size: 0x8
	    __int64/*SetProperty*/ Levels; // 0x28 Size: 0x50

};

struct FStartAsyncSimulationFunction : public FTickFunction
{
	public:
	    char UnknownData0[0x58];

};

struct FEndPhysicsTickFunction : public FTickFunction
{
	public:
	    char UnknownData0[0x58];

};

struct FStartPhysicsTickFunction : public FTickFunction
{
	public:
	    char UnknownData0[0x58];

};

struct FLevelViewportInfo
{
	public:
	    struct FVector CamPosition; // 0x0 Size: 0xc
	    struct FRotator CamRotation; // 0xc Size: 0xc
	    float CamOrthoZoom; // 0x18 Size: 0x4
	    bool CamUpdated; // 0x1c Size: 0x1
	    char UnknownData0[0x3];

};

struct FWorldPSCPool
{
	public:
	    __int64/*MapProperty*/ WorldParticleSystemPools; // 0x0 Size: 0x50
	    char UnknownData0[0x8];

};

struct FPSCPoolElem
{
	public:
	    class UParticleSystemComponent* PSC; // 0x0 Size: 0x8
	    char UnknownData0[0x8];

};

struct FBroadphaseSettings
{
	public:
	    bool bUseMBPOnClient; // 0x0 Size: 0x1
	    bool bUseMBPOnServer; // 0x1 Size: 0x1
	    char UnknownData0[0x2]; // 0x2
	    struct FBox MBPBounds; // 0x4 Size: 0x1c
	    uint32_t MBPNumSubdivs; // 0x20 Size: 0x4

};

struct FHierarchicalSimplification
{
	public:
	    float TransitionScreenSize; // 0x0 Size: 0x4
	    float OverrideDrawDistance; // 0x4 Size: 0x4
	    bool bUseOverrideDrawDistance; // 0x8 Size: 0x1
	    bool bAllowSpecificExclusion; // 0x8 Size: 0x1
	    bool bSimplifyMesh; // 0x8 Size: 0x1
	    bool bOnlyGenerateClustersForVolumes; // 0x8 Size: 0x1
	    bool bReusePreviousLevelClusters; // 0x8 Size: 0x1
	    Yea, we fucked up; // 0x0
	    struct FMeshProxySettings ProxySetting; // 0xc Size: 0x90
	    struct FMeshMergingSettings MergeSetting; // 0x9c Size: 0x88
	    float DesiredBoundRadius; // 0x124 Size: 0x4
	    float DesiredFillingPercentage; // 0x128 Size: 0x4
	    int MinNumberOfActorsToBuild; // 0x12c Size: 0x4

};

struct FNetViewer
{
	public:
	    class UNetConnection* Connection; // 0x0 Size: 0x8
	    class AActor* InViewer; // 0x8 Size: 0x8
	    class AActor* ViewTarget; // 0x10 Size: 0x8
	    struct FVector ViewLocation; // 0x18 Size: 0xc
	    struct FVector ViewDir; // 0x24 Size: 0xc

};

struct FLightmassWorldInfoSettings
{
	public:
	    float StaticLightingLevelScale; // 0x0 Size: 0x4
	    int NumIndirectLightingBounces; // 0x4 Size: 0x4
	    int NumSkyLightingBounces; // 0x8 Size: 0x4
	    float IndirectLightingQuality; // 0xc Size: 0x4
	    float IndirectLightingSmoothness; // 0x10 Size: 0x4
	    struct FColor EnvironmentColor; // 0x14 Size: 0x4
	    float EnvironmentIntensity; // 0x18 Size: 0x4
	    float EmissiveBoost; // 0x1c Size: 0x4
	    float DiffuseBoost; // 0x20 Size: 0x4
	    char VolumeLightingMethod; // 0x24 Size: 0x1
	    bool bUseAmbientOcclusion; // 0x25 Size: 0x1
	    bool bGenerateAmbientOcclusionMaterialMask; // 0x25 Size: 0x1
	    bool bVisualizeMaterialDiffuse; // 0x25 Size: 0x1
	    bool bVisualizeAmbientOcclusion; // 0x25 Size: 0x1
	    bool bCompressLightmaps; // 0x25 Size: 0x1
	    Yea, we fucked up; // 0x0
	    float VolumetricLightmapDetailCellSize; // 0x28 Size: 0x4
	    float VolumetricLightmapMaximumBrickMemoryMb; // 0x2c Size: 0x4
	    float VolumetricLightmapSphericalHarmonicSmoothing; // 0x30 Size: 0x4
	    float VolumeLightSamplePlacementScale; // 0x34 Size: 0x4
	    float DirectIlluminationOcclusionFraction; // 0x38 Size: 0x4
	    float IndirectIlluminationOcclusionFraction; // 0x3c Size: 0x4
	    float OcclusionExponent; // 0x40 Size: 0x4
	    float FullyOccludedSamplesFraction; // 0x44 Size: 0x4
	    float MaxOcclusionDistance; // 0x48 Size: 0x4

};

struct FDefault__UserDefinedStruct
{
	public:

};


}