#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FFrameMetrics
{
	public:
	    float TotalElapsedTime; // 0x0 Size: 0x4
	    float FrameDelta; // 0x4 Size: 0x4
	    int FrameNumber; // 0x8 Size: 0x4
	    int NumDroppedFrames; // 0xc Size: 0x4

};

struct FCapturedPixels
{
	public:
	    char UnknownData0[0x10];

};

struct FOnReceiveCapturedPixels__DelegateSignature
{
	public:
	    struct FCapturedPixels Pixels; // 0x0 Size: 0x10
	    FName StreamName; // 0x10 Size: 0x8
	    struct FFrameMetrics FrameMetrics; // 0x18 Size: 0x10

};



enum class EHDRCaptureGamut : uint8_t
{
    HCGM_Rec709 = 0,
    HCGM_P3DCI = 1,
    HCGM_Rec2020 = 2,
    HCGM_ACES = 3,
    HCGM_ACEScg = 4,
    HCGM_Linear = 5,
    HCGM_MAX = 6
};

enum class EMovieSceneCaptureProtocolState : uint8_t
{
    Idle = 0,
    Initialized = 1,
    Capturing = 2,
    Finalizing = 3,
    EMovieSceneCaptureProtocolState_MAX = 4
};struct FCaptureResolution
{
	public:
	    int ResX; // 0x0 Size: 0x4
	    int ResY; // 0x4 Size: 0x4

};

struct FMovieSceneCaptureSettings
{
	public:
	    struct FDirectoryPath OutputDirectory; // 0x0 Size: 0x10
	    class AGameModeBase* GameModeOverride; // 0x10 Size: 0x8
	    struct FString OutputFormat; // 0x18 Size: 0x10
	    bool bOverwriteExisting; // 0x28 Size: 0x1
	    bool bUseRelativeFrameNumbers; // 0x29 Size: 0x1
	    char UnknownData0[0x2]; // 0x2a
	    int HandleFrames; // 0x2c Size: 0x4
	    char ZeroPadFrameNumbers; // 0x30 Size: 0x1
	    char UnknownData1[0x3]; // 0x31
	    struct FFrameRate FrameRate; // 0x34 Size: 0x8
	    struct FCaptureResolution Resolution; // 0x3c Size: 0x8
	    bool bEnableTextureStreaming; // 0x44 Size: 0x1
	    bool bCinematicEngineScalability; // 0x45 Size: 0x1
	    bool bCinematicMode; // 0x46 Size: 0x1
	    bool bAllowMovement; // 0x47 Size: 0x1
	    bool bAllowTurning; // 0x48 Size: 0x1
	    bool bShowPlayer; // 0x49 Size: 0x1
	    bool bShowHUD; // 0x4a Size: 0x1
	    char UnknownData2[0x5];

};


}