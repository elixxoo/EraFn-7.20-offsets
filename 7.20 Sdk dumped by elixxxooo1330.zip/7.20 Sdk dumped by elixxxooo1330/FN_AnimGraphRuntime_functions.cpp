#include "../SDK.hpp"

static void UKismetAnimationLibrary::K2_TwoBoneIK(struct FVector RootPos, struct FVector JointPos, struct FVector EndPos, struct FVector JointTarget, struct FVector Effector, struct FVector OutJointPos, struct FVector OutEndPos, bool bAllowStretching, float StartStretchRatio, float MaxStretchScale)
{
	struct {
            struct FVector RootPos;
            struct FVector JointPos;
            struct FVector EndPos;
            struct FVector JointTarget;
            struct FVector Effector;
            struct FVector OutJointPos;
            struct FVector OutEndPos;
            bool bAllowStretching;
            float StartStretchRatio;
            float MaxStretchScale;            void ReturnValue;
	} params{ RootPos, JointPos, EndPos, JointTarget, Effector, OutJointPos, OutEndPos, bAllowStretching, StartStretchRatio, MaxStretchScale };

    static auto fn = UObject::FindObject("/Script/AnimGraphRuntime.KismetAnimationLibrary:K2_TwoBoneIK");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FVector UKismetAnimationLibrary::K2_MakePerlinNoiseVectorAndRemap(float X, float Y, float Z, float RangeOutMinX, float RangeOutMaxX, float RangeOutMinY, float RangeOutMaxY, float RangeOutMinZ, float RangeOutMaxZ)
{
	struct {
            float X;
            float Y;
            float Z;
            float RangeOutMinX;
            float RangeOutMaxX;
            float RangeOutMinY;
            float RangeOutMaxY;
            float RangeOutMinZ;
            float RangeOutMaxZ;
            struct FVector ReturnValue;
	} params{ X, Y, Z, RangeOutMinX, RangeOutMaxX, RangeOutMinY, RangeOutMaxY, RangeOutMinZ, RangeOutMaxZ };

    static auto fn = UObject::FindObject("/Script/AnimGraphRuntime.KismetAnimationLibrary:K2_MakePerlinNoiseVectorAndRemap");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static float UKismetAnimationLibrary::K2_MakePerlinNoiseAndRemap(float Value, float RangeOutMin, float RangeOutMax)
{
	struct {
            float Value;
            float RangeOutMin;
            float RangeOutMax;
            float ReturnValue;
	} params{ Value, RangeOutMin, RangeOutMax };

    static auto fn = UObject::FindObject("/Script/AnimGraphRuntime.KismetAnimationLibrary:K2_MakePerlinNoiseAndRemap");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FTransform UKismetAnimationLibrary::K2_LookAt(struct FTransform CurrentTransform, struct FVector TargetPosition, struct FVector LookAtVector, bool bUseUpVector, struct FVector UpVector, float ClampConeInDegree)
{
	struct {
            struct FTransform CurrentTransform;
            struct FVector TargetPosition;
            struct FVector LookAtVector;
            bool bUseUpVector;
            struct FVector UpVector;
            float ClampConeInDegree;
            struct FTransform ReturnValue;
	} params{ CurrentTransform, TargetPosition, LookAtVector, bUseUpVector, UpVector, ClampConeInDegree };

    static auto fn = UObject::FindObject("/Script/AnimGraphRuntime.KismetAnimationLibrary:K2_LookAt");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static float UKismetAnimationLibrary::K2_DistanceBetweenTwoSocketsAndMapRange(class USkeletalMeshComponent* Component, FName SocketOrBoneNameA, char SocketSpaceA, FName SocketOrBoneNameB, char SocketSpaceB, bool bRemapRange, float InRangeMin, float InRangeMax, float OutRangeMin, float OutRangeMax)
{
	struct {
            class USkeletalMeshComponent* Component;
            FName SocketOrBoneNameA;
            char SocketSpaceA;
            FName SocketOrBoneNameB;
            char SocketSpaceB;
            bool bRemapRange;
            float InRangeMin;
            float InRangeMax;
            float OutRangeMin;
            float OutRangeMax;
            float ReturnValue;
	} params{ Component, SocketOrBoneNameA, SocketSpaceA, SocketOrBoneNameB, SocketSpaceB, bRemapRange, InRangeMin, InRangeMax, OutRangeMin, OutRangeMax };

    static auto fn = UObject::FindObject("/Script/AnimGraphRuntime.KismetAnimationLibrary:K2_DistanceBetweenTwoSocketsAndMapRange");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FVector UKismetAnimationLibrary::K2_DirectionBetweenSockets(class USkeletalMeshComponent* Component, FName SocketOrBoneNameFrom, FName SocketOrBoneNameTo)
{
	struct {
            class USkeletalMeshComponent* Component;
            FName SocketOrBoneNameFrom;
            FName SocketOrBoneNameTo;
            struct FVector ReturnValue;
	} params{ Component, SocketOrBoneNameFrom, SocketOrBoneNameTo };

    static auto fn = UObject::FindObject("/Script/AnimGraphRuntime.KismetAnimationLibrary:K2_DirectionBetweenSockets");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UPlayMontageCallbackProxy::OnNotifyEndReceived(FName NotifyName, struct FBranchingPointNotifyPayload BranchingPointNotifyPayload)
{
	struct {
            FName NotifyName;
            struct FBranchingPointNotifyPayload BranchingPointNotifyPayload;
	} params{ NotifyName, BranchingPointNotifyPayload };

    static auto fn = UObject::FindObject("/Script/AnimGraphRuntime.PlayMontageCallbackProxy:OnNotifyEndReceived");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UPlayMontageCallbackProxy::OnNotifyBeginReceived(FName NotifyName, struct FBranchingPointNotifyPayload BranchingPointNotifyPayload)
{
	struct {
            FName NotifyName;
            struct FBranchingPointNotifyPayload BranchingPointNotifyPayload;
	} params{ NotifyName, BranchingPointNotifyPayload };

    static auto fn = UObject::FindObject("/Script/AnimGraphRuntime.PlayMontageCallbackProxy:OnNotifyBeginReceived");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UPlayMontageCallbackProxy::OnMontageEnded(class UAnimMontage* Montage, bool bInterrupted)
{
	struct {
            class UAnimMontage* Montage;
            bool bInterrupted;
	} params{ Montage, bInterrupted };

    static auto fn = UObject::FindObject("/Script/AnimGraphRuntime.PlayMontageCallbackProxy:OnMontageEnded");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UPlayMontageCallbackProxy::OnMontageBlendingOut(class UAnimMontage* Montage, bool bInterrupted)
{
	struct {
            class UAnimMontage* Montage;
            bool bInterrupted;
	} params{ Montage, bInterrupted };

    static auto fn = UObject::FindObject("/Script/AnimGraphRuntime.PlayMontageCallbackProxy:OnMontageBlendingOut");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


static class UPlayMontageCallbackProxy* UPlayMontageCallbackProxy::CreateProxyObjectForPlayMontage(class USkeletalMeshComponent* InSkeletalMeshComponent, class UAnimMontage* MontageToPlay, float PlayRate, float StartingPosition, FName StartingSection)
{
	struct {
            class USkeletalMeshComponent* InSkeletalMeshComponent;
            class UAnimMontage* MontageToPlay;
            float PlayRate;
            float StartingPosition;
            FName StartingSection;
            class UPlayMontageCallbackProxy* ReturnValue;
	} params{ InSkeletalMeshComponent, MontageToPlay, PlayRate, StartingPosition, StartingSection };

    static auto fn = UObject::FindObject("/Script/AnimGraphRuntime.PlayMontageCallbackProxy:CreateProxyObjectForPlayMontage");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

