#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FAnalyticsEventAttr
{
	public:
	    struct FString Name; // 0x0 Size: 0x10
	    struct FString Value; // 0x10 Size: 0x10

};


}