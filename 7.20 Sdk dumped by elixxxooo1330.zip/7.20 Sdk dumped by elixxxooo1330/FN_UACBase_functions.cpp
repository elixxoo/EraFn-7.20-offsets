#include "../SDK.hpp"

void UUACNetworkComponent::SendPacketToServer(char Type, TArray<char> Packet)
{
	struct {
            char Type;
            TArray<char> Packet;
	} params{ Type, Packet };

    static auto fn = UObject::FindObject("/Script/UACBase.UACNetworkComponent:SendPacketToServer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUACNetworkComponent::SendPacketToClient(char Type, TArray<char> Packet)
{
	struct {
            char Type;
            TArray<char> Packet;
	} params{ Type, Packet };

    static auto fn = UObject::FindObject("/Script/UACBase.UACNetworkComponent:SendPacketToClient");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUACNetworkComponent::SendClientHello(uint32_t SessionKey)
{
	struct {
            uint32_t SessionKey;
	} params{ SessionKey };

    static auto fn = UObject::FindObject("/Script/UACBase.UACNetworkComponent:SendClientHello");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

