#include "../SDK.hpp"

class UCineCameraComponent* ACineCameraActor::GetCineCameraComponent()
{
	struct {
            class UCineCameraComponent* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CinematicCamera.CineCameraActor:GetCineCameraComponent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UCineCameraComponent::SetLensPresetByName(struct FString InPresetName)
{
	struct {
            struct FString InPresetName;
	} params{ InPresetName };

    static auto fn = UObject::FindObject("/Script/CinematicCamera.CineCameraComponent:SetLensPresetByName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCineCameraComponent::SetFilmbackPresetByName(struct FString InPresetName)
{
	struct {
            struct FString InPresetName;
	} params{ InPresetName };

    static auto fn = UObject::FindObject("/Script/CinematicCamera.CineCameraComponent:SetFilmbackPresetByName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


float UCineCameraComponent::GetVerticalFieldOfView()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CinematicCamera.CineCameraComponent:GetVerticalFieldOfView");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FString UCineCameraComponent::GetLensPresetName()
{
	struct {
            struct FString ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CinematicCamera.CineCameraComponent:GetLensPresetName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UCineCameraComponent::GetHorizontalFieldOfView()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CinematicCamera.CineCameraComponent:GetHorizontalFieldOfView");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FString UCineCameraComponent::GetFilmbackPresetName()
{
	struct {
            struct FString ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CinematicCamera.CineCameraComponent:GetFilmbackPresetName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

