#include "../SDK.hpp"

void UControlRig::SetGlobalTransform(FName JointName, struct FTransform InTransform)
{
	struct {
            FName JointName;
            struct FTransform InTransform;
	} params{ JointName, InTransform };

    static auto fn = UObject::FindObject("/Script/ControlRig.ControlRig:SetGlobalTransform");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


struct FTransform UControlRig::GetGlobalTransform(FName JointName)
{
	struct {
            FName JointName;
            struct FTransform ReturnValue;
	} params{ JointName };

    static auto fn = UObject::FindObject("/Script/ControlRig.ControlRig:GetGlobalTransform");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


float UControlRig::GetDeltaTime()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/ControlRig.ControlRig:GetDeltaTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UControlRigComponent::OnPreInitialize()
{
    static auto fn = UObject::FindObject("/Script/ControlRig.ControlRigComponent:OnPreInitialize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UControlRigComponent::OnPreEvaluate()
{
    static auto fn = UObject::FindObject("/Script/ControlRig.ControlRigComponent:OnPreEvaluate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UControlRigComponent::OnPostInitialize()
{
    static auto fn = UObject::FindObject("/Script/ControlRig.ControlRigComponent:OnPostInitialize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UControlRigComponent::OnPostEvaluate()
{
    static auto fn = UObject::FindObject("/Script/ControlRig.ControlRigComponent:OnPostEvaluate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


class UControlRig* UControlRigComponent::BP_GetControlRig()
{
	struct {
            class UControlRig* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/ControlRig.ControlRigComponent:BP_GetControlRig");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void AControlRigControl::OnTransformChanged(struct FTransform NewTransform)
{
	struct {
            struct FTransform NewTransform;
	} params{ NewTransform };

    static auto fn = UObject::FindObject("/Script/ControlRig.ControlRigControl:OnTransformChanged");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void AControlRigControl::OnSelectionChanged(bool bIsSelected)
{
	struct {
            bool bIsSelected;
	} params{ bIsSelected };

    static auto fn = UObject::FindObject("/Script/ControlRig.ControlRigControl:OnSelectionChanged");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void AControlRigControl::OnManipulatingChanged(bool bIsManipulating)
{
	struct {
            bool bIsManipulating;
	} params{ bIsManipulating };

    static auto fn = UObject::FindObject("/Script/ControlRig.ControlRigControl:OnManipulatingChanged");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void AControlRigControl::OnHoveredChanged(bool bIsSelected)
{
	struct {
            bool bIsSelected;
	} params{ bIsSelected };

    static auto fn = UObject::FindObject("/Script/ControlRig.ControlRigControl:OnHoveredChanged");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void AControlRigControl::OnEnabledChanged(bool bIsEnabled)
{
	struct {
            bool bIsEnabled;
	} params{ bIsEnabled };

    static auto fn = UObject::FindObject("/Script/ControlRig.ControlRigControl:OnEnabledChanged");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

