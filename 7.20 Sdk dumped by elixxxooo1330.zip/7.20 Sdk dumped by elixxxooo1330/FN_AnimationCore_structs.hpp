#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class ETransformConstraintType : uint8_t
{
    Translation = 0,
    Rotation = 1,
    Scale = 2,
    Parent = 3,
    ETransformConstraintType_MAX = 4
};

enum class EConstraintType : uint8_t
{
    Transform = 0,
    Aim = 1,
    MAX = 2
};struct FNodeObject
{
	public:
	    FName Name; // 0x0 Size: 0x8
	    FName ParentName; // 0x8 Size: 0x8

};

struct FFilterOptionPerAxis
{
	public:
	    bool bX; // 0x0 Size: 0x1
	    bool bY; // 0x1 Size: 0x1
	    bool bZ; // 0x2 Size: 0x1

};

struct FConstraintDescription
{
	public:
	    bool bTranslation; // 0x0 Size: 0x1
	    bool bRotation; // 0x1 Size: 0x1
	    bool bScale; // 0x2 Size: 0x1
	    bool bParent; // 0x3 Size: 0x1
	    struct FFilterOptionPerAxis TranslationAxes; // 0x4 Size: 0x3
	    struct FFilterOptionPerAxis RotationAxes; // 0x7 Size: 0x3
	    struct FFilterOptionPerAxis ScaleAxes; // 0xa Size: 0x3

};

struct FTransformConstraint
{
	public:
	    struct FConstraintDescription Operator; // 0x0 Size: 0xd
	    char UnknownData0[0x3]; // 0xd
	    FName SourceNode; // 0x10 Size: 0x8
	    FName TargetNode; // 0x18 Size: 0x8
	    float Weight; // 0x20 Size: 0x4
	    bool bMaintainOffset; // 0x24 Size: 0x1
	    char UnknownData1[0x3];

};

struct FConstraintOffset
{
	public:
	    struct FVector Translation; // 0x0 Size: 0xc
	    char UnknownData0[0x4]; // 0xc
	    struct FQuat Rotation; // 0x10 Size: 0x10
	    struct FVector Scale; // 0x20 Size: 0xc
	    char UnknownData1[0x4]; // 0x2c
	    struct FTransform Parent; // 0x30 Size: 0x30

};

struct FTransformFilter
{
	public:
	    struct FFilterOptionPerAxis TranslationFilter; // 0x0 Size: 0x3
	    struct FFilterOptionPerAxis RotationFilter; // 0x3 Size: 0x3
	    struct FFilterOptionPerAxis ScaleFilter; // 0x6 Size: 0x3

};

struct FEulerTransform
{
	public:
	    struct FVector Location; // 0x0 Size: 0xc
	    struct FRotator Rotation; // 0xc Size: 0xc
	    struct FVector Scale; // 0x18 Size: 0xc

};

struct FAxis
{
	public:
	    struct FVector Axis; // 0x0 Size: 0xc
	    bool bInLocalSpace; // 0xc Size: 0x1
	    char UnknownData0[0x3];

};

struct FConstraintDescriptor
{
	public:
	    EConstraintType Type; // 0x0 Size: 0x1
	    char UnknownData0[0xf];

};

struct FConstraintData
{
	public:
	    struct FConstraintDescriptor Constraint; // 0x0 Size: 0x10
	    float Weight; // 0x10 Size: 0x4
	    bool bMaintainOffset; // 0x14 Size: 0x1
	    char UnknownData0[0xb]; // 0x15
	    struct FTransform Offset; // 0x20 Size: 0x30
	    struct FTransform CurrentTransform; // 0x50 Size: 0x30

};

struct FConstraintDescriptionEx
{
	public:
	    struct FFilterOptionPerAxis AxesFilterOption; // 0x8 Size: 0x3
	    char UnknownData0[0x5];

};

struct FAimConstraintDescription : public FConstraintDescriptionEx
{
	public:
	    struct FAxis LookAt_Axis; // 0x10 Size: 0x10
	    struct FAxis LookUp_Axis; // 0x20 Size: 0x10
	    bool bUseLookUp; // 0x30 Size: 0x1
	    char UnknownData0[0x3]; // 0x31
	    struct FVector LookUpTarget; // 0x34 Size: 0xc

};

struct FTransformConstraintDescription : public FConstraintDescriptionEx
{
	public:
	    ETransformConstraintType TransformType; // 0x10 Size: 0x1
	    char UnknownData0[0x7];

};


}