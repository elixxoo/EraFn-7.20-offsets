#pragma once

#include "../SDK.hpp"

namespace SDK {


class UMeshReconstructorBase : public UObject
{
	public:
	    void StopReconstruction(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void StartReconstruction(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void PauseReconstruction(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool IsReconstructionStarted(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool IsReconstructionPaused(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void DisconnectMRMesh(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ConnectMRMesh(class UMRMeshComponent* Mesh); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MRMesh.MeshReconstructorBase");
			return (class UClass*)ptr;
		};

};

class UMRMeshComponent : public UPrimitiveComponent
{
	public:
	    char UnknownData0[0x8];
	    class UMaterialInterface* Material; // 0x578 Size: 0x8
	    bool bCreateMeshProxySections; // 0x580 Size: 0x1
	    bool bUpdateNavMeshOnMeshUpdate; // 0x581 Size: 0x1
	    char UnknownData1[0x6]; // 0x582
	    TArray<class UBodySetup*> BodySetups; // 0x588 Size: 0x10
	    char UnknownData2[0x598]; // 0x598
	    bool IsConnected(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void ForceNavMeshUpdate(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void Clear(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7a21];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MRMesh.MRMeshComponent");
			return (class UClass*)ptr;
		};

};


}