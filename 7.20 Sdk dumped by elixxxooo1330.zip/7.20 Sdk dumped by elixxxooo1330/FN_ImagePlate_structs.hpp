#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FImagePlateParameters
{
	public:
	    class UMaterialInterface* Material; // 0x0 Size: 0x8
	    FName TextureParameterName; // 0x8 Size: 0x8
	    bool bFillScreen; // 0x10 Size: 0x1
	    char UnknownData0[0x3]; // 0x11
	    struct FVector2D FillScreenAmount; // 0x14 Size: 0x8
	    struct FVector2D FixedSize; // 0x1c Size: 0x8
	    char UnknownData1[0x4]; // 0x24
	    class UTexture* RenderTexture; // 0x28 Size: 0x8
	    class UMaterialInstanceDynamic* DynamicMaterial; // 0x30 Size: 0x8

};

struct FMovieSceneImagePlateSectionParams
{
	public:
	    struct FFrameNumber SectionStartTime; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    class UImagePlateFileSequence* FileSequence; // 0x8 Size: 0x8
	    bool bReuseExistingTexture; // 0x10 Size: 0x1
	    char UnknownData1[0x7];

};

struct FMovieSceneImagePlateSectionTemplate : public FMovieSceneEvalTemplate
{
	public:
	    struct FMovieScenePropertySectionData PropertyData; // 0x20 Size: 0x28
	    struct FMovieSceneImagePlateSectionParams Params; // 0x48 Size: 0x18

};


}