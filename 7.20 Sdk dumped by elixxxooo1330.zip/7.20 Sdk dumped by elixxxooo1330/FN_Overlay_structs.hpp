#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FOverlayItem
{
	public:
	    struct FTimespan StartTime; // 0x0 Size: 0x8
	    struct FTimespan EndTime; // 0x8 Size: 0x8
	    struct FString Text; // 0x10 Size: 0x10
	    struct FVector2D Position; // 0x20 Size: 0x8

};


}