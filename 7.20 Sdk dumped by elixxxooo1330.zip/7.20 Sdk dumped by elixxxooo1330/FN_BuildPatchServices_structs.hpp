#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FChunkPartData
{
	public:
	    struct FGuid Guid; // 0x0 Size: 0x10
	    uint32_t Offset; // 0x10 Size: 0x4
	    uint32_t Size; // 0x14 Size: 0x4

};

struct FSHAHashData
{
	public:
	    char Hash; // 0x0 Size: 0x1
	    char UnknownData0[0x13];

};

struct FChunkInfoData
{
	public:
	    struct FGuid Guid; // 0x0 Size: 0x10
	    uint64_t Hash; // 0x10 Size: 0x8
	    struct FSHAHashData ShaHash; // 0x18 Size: 0x14
	    char UnknownData0[0x4]; // 0x2c
	    int64_t FileSize; // 0x30 Size: 0x8
	    char GroupNumber; // 0x38 Size: 0x1
	    char UnknownData1[0x7];

};

struct FCustomFieldData
{
	public:
	    struct FString Key; // 0x0 Size: 0x10
	    struct FString Value; // 0x10 Size: 0x10

};


}