#include "../SDK.hpp"

static void UKismetProceduralMeshLibrary::SliceProceduralMesh(class UProceduralMeshComponent* InProcMesh, struct FVector PlanePosition, struct FVector PlaneNormal, bool bCreateOtherHalf, class UProceduralMeshComponent* OutOtherHalfProcMesh, EProcMeshSliceCapOption CapOption, class UMaterialInterface* CapMaterial)
{
	struct {
            class UProceduralMeshComponent* InProcMesh;
            struct FVector PlanePosition;
            struct FVector PlaneNormal;
            bool bCreateOtherHalf;
            class UProceduralMeshComponent* OutOtherHalfProcMesh;
            EProcMeshSliceCapOption CapOption;
            class UMaterialInterface* CapMaterial;            void ReturnValue;
	} params{ InProcMesh, PlanePosition, PlaneNormal, bCreateOtherHalf, OutOtherHalfProcMesh, CapOption, CapMaterial };

    static auto fn = UObject::FindObject("/Script/ProceduralMeshComponent.KismetProceduralMeshLibrary:SliceProceduralMesh");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UKismetProceduralMeshLibrary::GetSectionFromStaticMesh(class UStaticMesh* InMesh, int LODIndex, int SectionIndex, TArray<struct FVector> Vertices, TArray<int> Triangles, TArray<struct FVector> Normals, TArray<struct FVector2D> UVs, TArray<struct FProcMeshTangent> Tangents)
{
	struct {
            class UStaticMesh* InMesh;
            int LODIndex;
            int SectionIndex;
            TArray<struct FVector> Vertices;
            TArray<int> Triangles;
            TArray<struct FVector> Normals;
            TArray<struct FVector2D> UVs;
            TArray<struct FProcMeshTangent> Tangents;            void ReturnValue;
	} params{ InMesh, LODIndex, SectionIndex, Vertices, Triangles, Normals, UVs, Tangents };

    static auto fn = UObject::FindObject("/Script/ProceduralMeshComponent.KismetProceduralMeshLibrary:GetSectionFromStaticMesh");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UKismetProceduralMeshLibrary::GetSectionFromProceduralMesh(class UProceduralMeshComponent* InProcMesh, int SectionIndex, TArray<struct FVector> Vertices, TArray<int> Triangles, TArray<struct FVector> Normals, TArray<struct FVector2D> UVs, TArray<struct FProcMeshTangent> Tangents)
{
	struct {
            class UProceduralMeshComponent* InProcMesh;
            int SectionIndex;
            TArray<struct FVector> Vertices;
            TArray<int> Triangles;
            TArray<struct FVector> Normals;
            TArray<struct FVector2D> UVs;
            TArray<struct FProcMeshTangent> Tangents;            void ReturnValue;
	} params{ InProcMesh, SectionIndex, Vertices, Triangles, Normals, UVs, Tangents };

    static auto fn = UObject::FindObject("/Script/ProceduralMeshComponent.KismetProceduralMeshLibrary:GetSectionFromProceduralMesh");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UKismetProceduralMeshLibrary::GenerateBoxMesh(struct FVector BoxRadius, TArray<struct FVector> Vertices, TArray<int> Triangles, TArray<struct FVector> Normals, TArray<struct FVector2D> UVs, TArray<struct FProcMeshTangent> Tangents)
{
	struct {
            struct FVector BoxRadius;
            TArray<struct FVector> Vertices;
            TArray<int> Triangles;
            TArray<struct FVector> Normals;
            TArray<struct FVector2D> UVs;
            TArray<struct FProcMeshTangent> Tangents;            void ReturnValue;
	} params{ BoxRadius, Vertices, Triangles, Normals, UVs, Tangents };

    static auto fn = UObject::FindObject("/Script/ProceduralMeshComponent.KismetProceduralMeshLibrary:GenerateBoxMesh");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UKismetProceduralMeshLibrary::CreateGridMeshWelded(int NumX, int NumY, TArray<int> Triangles, TArray<struct FVector> Vertices, TArray<struct FVector2D> UVs, float GridSpacing)
{
	struct {
            int NumX;
            int NumY;
            TArray<int> Triangles;
            TArray<struct FVector> Vertices;
            TArray<struct FVector2D> UVs;
            float GridSpacing;            void ReturnValue;
	} params{ NumX, NumY, Triangles, Vertices, UVs, GridSpacing };

    static auto fn = UObject::FindObject("/Script/ProceduralMeshComponent.KismetProceduralMeshLibrary:CreateGridMeshWelded");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UKismetProceduralMeshLibrary::CreateGridMeshTriangles(int NumX, int NumY, bool bWinding, TArray<int> Triangles)
{
	struct {
            int NumX;
            int NumY;
            bool bWinding;
            TArray<int> Triangles;            void ReturnValue;
	} params{ NumX, NumY, bWinding, Triangles };

    static auto fn = UObject::FindObject("/Script/ProceduralMeshComponent.KismetProceduralMeshLibrary:CreateGridMeshTriangles");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UKismetProceduralMeshLibrary::CreateGridMeshSplit(int NumX, int NumY, TArray<int> Triangles, TArray<struct FVector> Vertices, TArray<struct FVector2D> UVs, TArray<struct FVector2D> UV1s, float GridSpacing)
{
	struct {
            int NumX;
            int NumY;
            TArray<int> Triangles;
            TArray<struct FVector> Vertices;
            TArray<struct FVector2D> UVs;
            TArray<struct FVector2D> UV1s;
            float GridSpacing;            void ReturnValue;
	} params{ NumX, NumY, Triangles, Vertices, UVs, UV1s, GridSpacing };

    static auto fn = UObject::FindObject("/Script/ProceduralMeshComponent.KismetProceduralMeshLibrary:CreateGridMeshSplit");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UKismetProceduralMeshLibrary::CopyProceduralMeshFromStaticMeshComponent(class UStaticMeshComponent* StaticMeshComponent, int LODIndex, class UProceduralMeshComponent* ProcMeshComponent, bool bCreateCollision)
{
	struct {
            class UStaticMeshComponent* StaticMeshComponent;
            int LODIndex;
            class UProceduralMeshComponent* ProcMeshComponent;
            bool bCreateCollision;            void ReturnValue;
	} params{ StaticMeshComponent, LODIndex, ProcMeshComponent, bCreateCollision };

    static auto fn = UObject::FindObject("/Script/ProceduralMeshComponent.KismetProceduralMeshLibrary:CopyProceduralMeshFromStaticMeshComponent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UKismetProceduralMeshLibrary::ConvertQuadToTriangles(TArray<int> Triangles, int Vert0, int Vert1, int Vert2, int Vert3)
{
	struct {
            TArray<int> Triangles;
            int Vert0;
            int Vert1;
            int Vert2;
            int Vert3;            void ReturnValue;
	} params{ Triangles, Vert0, Vert1, Vert2, Vert3 };

    static auto fn = UObject::FindObject("/Script/ProceduralMeshComponent.KismetProceduralMeshLibrary:ConvertQuadToTriangles");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UKismetProceduralMeshLibrary::CalculateTangentsForMesh(TArray<struct FVector> Vertices, TArray<int> Triangles, TArray<struct FVector2D> UVs, TArray<struct FVector> Normals, TArray<struct FProcMeshTangent> Tangents)
{
	struct {
            TArray<struct FVector> Vertices;
            TArray<int> Triangles;
            TArray<struct FVector2D> UVs;
            TArray<struct FVector> Normals;
            TArray<struct FProcMeshTangent> Tangents;            void ReturnValue;
	} params{ Vertices, Triangles, UVs, Normals, Tangents };

    static auto fn = UObject::FindObject("/Script/ProceduralMeshComponent.KismetProceduralMeshLibrary:CalculateTangentsForMesh");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UProceduralMeshComponent::UpdateMeshSection_LinearColor(int SectionIndex, TArray<struct FVector> Vertices, TArray<struct FVector> Normals, TArray<struct FVector2D> UV0, TArray<struct FVector2D> UV1, TArray<struct FVector2D> UV2, TArray<struct FVector2D> UV3, TArray<struct FLinearColor> VertexColors, TArray<struct FProcMeshTangent> Tangents)
{
	struct {
            int SectionIndex;
            TArray<struct FVector> Vertices;
            TArray<struct FVector> Normals;
            TArray<struct FVector2D> UV0;
            TArray<struct FVector2D> UV1;
            TArray<struct FVector2D> UV2;
            TArray<struct FVector2D> UV3;
            TArray<struct FLinearColor> VertexColors;
            TArray<struct FProcMeshTangent> Tangents;
	} params{ SectionIndex, Vertices, Normals, UV0, UV1, UV2, UV3, VertexColors, Tangents };

    static auto fn = UObject::FindObject("/Script/ProceduralMeshComponent.ProceduralMeshComponent:UpdateMeshSection_LinearColor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UProceduralMeshComponent::UpdateMeshSection(int SectionIndex, TArray<struct FVector> Vertices, TArray<struct FVector> Normals, TArray<struct FVector2D> UV0, TArray<struct FColor> VertexColors, TArray<struct FProcMeshTangent> Tangents)
{
	struct {
            int SectionIndex;
            TArray<struct FVector> Vertices;
            TArray<struct FVector> Normals;
            TArray<struct FVector2D> UV0;
            TArray<struct FColor> VertexColors;
            TArray<struct FProcMeshTangent> Tangents;
	} params{ SectionIndex, Vertices, Normals, UV0, VertexColors, Tangents };

    static auto fn = UObject::FindObject("/Script/ProceduralMeshComponent.ProceduralMeshComponent:UpdateMeshSection");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UProceduralMeshComponent::SetMeshSectionVisible(int SectionIndex, bool bNewVisibility)
{
	struct {
            int SectionIndex;
            bool bNewVisibility;
	} params{ SectionIndex, bNewVisibility };

    static auto fn = UObject::FindObject("/Script/ProceduralMeshComponent.ProceduralMeshComponent:SetMeshSectionVisible");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UProceduralMeshComponent::IsMeshSectionVisible(int SectionIndex)
{
	struct {
            int SectionIndex;
            bool ReturnValue;
	} params{ SectionIndex };

    static auto fn = UObject::FindObject("/Script/ProceduralMeshComponent.ProceduralMeshComponent:IsMeshSectionVisible");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


int UProceduralMeshComponent::GetNumSections()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/ProceduralMeshComponent.ProceduralMeshComponent:GetNumSections");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UProceduralMeshComponent::CreateMeshSection_LinearColor(int SectionIndex, TArray<struct FVector> Vertices, TArray<int> Triangles, TArray<struct FVector> Normals, TArray<struct FVector2D> UV0, TArray<struct FVector2D> UV1, TArray<struct FVector2D> UV2, TArray<struct FVector2D> UV3, TArray<struct FLinearColor> VertexColors, TArray<struct FProcMeshTangent> Tangents, bool bCreateCollision)
{
	struct {
            int SectionIndex;
            TArray<struct FVector> Vertices;
            TArray<int> Triangles;
            TArray<struct FVector> Normals;
            TArray<struct FVector2D> UV0;
            TArray<struct FVector2D> UV1;
            TArray<struct FVector2D> UV2;
            TArray<struct FVector2D> UV3;
            TArray<struct FLinearColor> VertexColors;
            TArray<struct FProcMeshTangent> Tangents;
            bool bCreateCollision;
	} params{ SectionIndex, Vertices, Triangles, Normals, UV0, UV1, UV2, UV3, VertexColors, Tangents, bCreateCollision };

    static auto fn = UObject::FindObject("/Script/ProceduralMeshComponent.ProceduralMeshComponent:CreateMeshSection_LinearColor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UProceduralMeshComponent::CreateMeshSection(int SectionIndex, TArray<struct FVector> Vertices, TArray<int> Triangles, TArray<struct FVector> Normals, TArray<struct FVector2D> UV0, TArray<struct FColor> VertexColors, TArray<struct FProcMeshTangent> Tangents, bool bCreateCollision)
{
	struct {
            int SectionIndex;
            TArray<struct FVector> Vertices;
            TArray<int> Triangles;
            TArray<struct FVector> Normals;
            TArray<struct FVector2D> UV0;
            TArray<struct FColor> VertexColors;
            TArray<struct FProcMeshTangent> Tangents;
            bool bCreateCollision;
	} params{ SectionIndex, Vertices, Triangles, Normals, UV0, VertexColors, Tangents, bCreateCollision };

    static auto fn = UObject::FindObject("/Script/ProceduralMeshComponent.ProceduralMeshComponent:CreateMeshSection");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UProceduralMeshComponent::ClearMeshSection(int SectionIndex)
{
	struct {
            int SectionIndex;
	} params{ SectionIndex };

    static auto fn = UObject::FindObject("/Script/ProceduralMeshComponent.ProceduralMeshComponent:ClearMeshSection");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UProceduralMeshComponent::ClearCollisionConvexMeshes()
{
    static auto fn = UObject::FindObject("/Script/ProceduralMeshComponent.ProceduralMeshComponent:ClearCollisionConvexMeshes");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UProceduralMeshComponent::ClearAllMeshSections()
{
    static auto fn = UObject::FindObject("/Script/ProceduralMeshComponent.ProceduralMeshComponent:ClearAllMeshSections");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UProceduralMeshComponent::AddCollisionConvexMesh(TArray<struct FVector> ConvexVerts)
{
	struct {
            TArray<struct FVector> ConvexVerts;
	} params{ ConvexVerts };

    static auto fn = UObject::FindObject("/Script/ProceduralMeshComponent.ProceduralMeshComponent:AddCollisionConvexMesh");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

