#pragma once

#include "../SDK.hpp"

namespace SDK {


class UMeshDescription : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MeshDescription.MeshDescription");
			return (class UClass*)ptr;
		};

};


}