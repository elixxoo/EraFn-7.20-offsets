#pragma once

#include "../SDK.hpp"

namespace SDK {


class UAnimCustomInstance : public UAnimInstance
{
	public:
	    char UnknownData0[0x270];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AnimGraphRuntime.AnimCustomInstance");
			return (class UClass*)ptr;
		};

};

class UAnimSequencerInstance : public UAnimCustomInstance
{
	public:
	    char UnknownData0[0x270];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AnimGraphRuntime.AnimSequencerInstance");
			return (class UClass*)ptr;
		};

};

class UAnimNotify_PlayMontageNotify : public UAnimNotify
{
	public:
	    FName NotifyName; // 0x38 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AnimGraphRuntime.AnimNotify_PlayMontageNotify");
			return (class UClass*)ptr;
		};

};

class UAnimNotify_PlayMontageNotifyWindow : public UAnimNotifyState
{
	public:
	    FName NotifyName; // 0x30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AnimGraphRuntime.AnimNotify_PlayMontageNotifyWindow");
			return (class UClass*)ptr;
		};

};

class UKismetAnimationLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void K2_TwoBoneIK(struct FVector RootPos, struct FVector JointPos, struct FVector EndPos, struct FVector JointTarget, struct FVector Effector, struct FVector OutJointPos, struct FVector OutEndPos, bool bAllowStretching, float StartStretchRatio, float MaxStretchScale); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static struct FVector K2_MakePerlinNoiseVectorAndRemap(float X, float Y, float Z, float RangeOutMinX, float RangeOutMaxX, float RangeOutMinY, float RangeOutMaxY, float RangeOutMinZ, float RangeOutMaxZ); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static float K2_MakePerlinNoiseAndRemap(float Value, float RangeOutMin, float RangeOutMax); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static struct FTransform K2_LookAt(struct FTransform CurrentTransform, struct FVector TargetPosition, struct FVector LookAtVector, bool bUseUpVector, struct FVector UpVector, float ClampConeInDegree); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static float K2_DistanceBetweenTwoSocketsAndMapRange(class USkeletalMeshComponent* Component, FName SocketOrBoneNameA, char SocketSpaceA, FName SocketOrBoneNameB, char SocketSpaceB, bool bRemapRange, float InRangeMin, float InRangeMax, float OutRangeMin, float OutRangeMax); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static struct FVector K2_DirectionBetweenSockets(class USkeletalMeshComponent* Component, FName SocketOrBoneNameFrom, FName SocketOrBoneNameTo); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AnimGraphRuntime.KismetAnimationLibrary");
			return (class UClass*)ptr;
		};

};

class UPlayMontageCallbackProxy : public UObject
{
	public:
	    MulticastDelegateProperty OnCompleted; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnBlendOut; // 0x38 Size: 0x10
	    MulticastDelegateProperty OnInterrupted; // 0x48 Size: 0x10
	    MulticastDelegateProperty OnNotifyBegin; // 0x58 Size: 0x10
	    MulticastDelegateProperty OnNotifyEnd; // 0x68 Size: 0x10
	    char UnknownData0[0x78]; // 0x78
	    void OnNotifyEndReceived(FName NotifyName, struct FBranchingPointNotifyPayload BranchingPointNotifyPayload); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnNotifyBeginReceived(FName NotifyName, struct FBranchingPointNotifyPayload BranchingPointNotifyPayload); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnMontageEnded(class UAnimMontage* Montage, bool bInterrupted); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnMontageBlendingOut(class UAnimMontage* Montage, bool bInterrupted); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static class UPlayMontageCallbackProxy* CreateProxyObjectForPlayMontage(class USkeletalMeshComponent* InSkeletalMeshComponent, class UAnimMontage* MontageToPlay, float PlayRate, float StartingPosition, FName StartingSection); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7f39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AnimGraphRuntime.PlayMontageCallbackProxy");
			return (class UClass*)ptr;
		};

};


}