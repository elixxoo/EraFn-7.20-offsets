#pragma once

#include "../SDK.hpp"

namespace SDK {


class AQosBeaconClient : public AOnlineBeaconClient
{
	public:
	    void ServerQosRequest(struct FString InSessionId); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void ClientQosResponse(EQosResponseType Response); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7bf9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Qos.QosBeaconClient");
			return (class UClass*)ptr;
		};

};

class AQosBeaconHost : public AOnlineBeaconHostObject
{
	public:
	    char UnknownData0[0x368];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Qos.QosBeaconHost");
			return (class UClass*)ptr;
		};

};

class UQosEvaluator : public UObject
{
	public:
	    char UnknownData0[0x20];
	    bool bInProgress; // 0x48 Size: 0x1
	    bool bCancelOperation; // 0x49 Size: 0x1
	    char UnknownData1[0x6]; // 0x4a
	    TArray<struct FDatacenterQosInstance> Datacenters; // 0x50 Size: 0x10
	    char UnknownData2[0x20];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Qos.QosEvaluator");
			return (class UClass*)ptr;
		};

};

class UQosRegionManager : public UObject
{
	public:
	    int NumTestsPerRegion; // 0x28 Size: 0x4
	    float PingTimeout; // 0x2c Size: 0x4
	    TArray<struct FQosRegionInfo> RegionDefinitions; // 0x30 Size: 0x10
	    TArray<struct FQosDatacenterInfo> DatacenterDefinitions; // 0x40 Size: 0x10
	    struct FDateTime LastCheckTimestamp; // 0x50 Size: 0x8
	    class UQosEvaluator* Evaluator; // 0x58 Size: 0x8
	    EQosCompletionResult QosEvalResult; // 0x60 Size: 0x1
	    char UnknownData0[0x7]; // 0x61
	    TArray<struct FRegionQosInstance> RegionOptions; // 0x68 Size: 0x10
	    struct FString ForceRegionId; // 0x78 Size: 0x10
	    bool bRegionForcedViaCommandline; // 0x88 Size: 0x1
	    char UnknownData1[0x7]; // 0x89
	    struct FString SelectedRegionId; // 0x90 Size: 0x10
	    char UnknownData2[0x20];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Qos.QosRegionManager");
			return (class UClass*)ptr;
		};

};


}