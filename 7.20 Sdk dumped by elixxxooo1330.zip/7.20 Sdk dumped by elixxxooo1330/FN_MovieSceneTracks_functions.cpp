#include "../SDK.hpp"

struct FTransform UMovieSceneTransformOrigin::BP_GetTransformOrigin()
{
	struct {
            struct FTransform ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieSceneTracks.MovieSceneTransformOrigin:BP_GetTransformOrigin");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

