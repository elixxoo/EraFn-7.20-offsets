#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class EExternalAccountType : uint8_t
{
    None = 0,
    Facebook = 1,
    Google = 2,
    Epic_PSN = 3,
    Epic_XBL = 4,
    Epic_Erebus = 5,
    Epic_Facebook = 6,
    Epic_Google = 7,
    EExternalAccountType_MAX = 8
};

enum class ECreateAccountResult : uint8_t
{
    NotStarted = 0,
    Pending = 1,
    Success = 2,
    Console_LoginFailed = 3,
    Console_DuplicateAuthAssociation = 4,
    DuplicateAccount = 5,
    GenericError = 6,
    ECreateAccountResult_MAX = 7
};

enum class ELoginResult : uint8_t
{
    NotStarted = 0,
    Pending = 1,
    Success = 2,
    Console_LoginFailed = 3,
    Console_AuthFailed = 4,
    Console_MissingAuthAssociation = 5,
    Console_DuplicateAuthAssociation = 6,
    Console_AddedAuthAssociation = 7,
    Console_AuthAssociationFailure = 8,
    Console_NotEntitled = 9,
    Console_EntitlementCheckFailed = 10,
    Console_PrivilegeCheck = 11,
    Console_PatchOrUpdateRequired = 12,
    AuthFailed = 13,
    AuthFailed_RefreshInvalid = 14,
    AuthFailed_InvalidMFA = 15,
    AuthFailed_RequiresMFA = 16,
    AuthParentalLock = 17,
    PlatformNotAllowed = 18,
    NotEntitled = 19,
    Banned = 20,
    EULACheckFailed = 21,
    WaitingRoomFailed = 22,
    ServiceUnavailable = 23,
    GenericError = 24,
    RejoinCheckFailure = 25,
    ConnectionFailed = 26,
    NetworkConnectionUnavailable = 27,
    ExternalAuth_AddedAuthAssociation = 28,
    ExternalAuth_ConnectionTimeout = 29,
    ExternalAuth_AuthFailure = 30,
    ExternalAuth_AssociationFailure = 31,
    ExternalAuth_MissingAuthAssociation = 32,
    FailedToCreateParty = 33,
    ProfileQueryFailed = 34,
    QueryKeychainFailed = 35,
    ClientSettingsDownloadFailed = 36,
    ELoginResult_MAX = 37
};

enum class EConsoleAuthLinkState : uint8_t
{
    NotOnConsole = 0,
    ConsoleNotLoggedIn = 1,
    EpicNotLoggedIn = 2,
    ThisEpicAccountLinked = 3,
    OtherEpicAccountLinked = 4,
    NoEpicAccountLinked = 5,
    PrimaryIdNotLinked = 6,
    SecondaryIdNotLinked = 7,
    EConsoleAuthLinkState_MAX = 8
};struct FExternalAccountServiceConfig
{
	public:
	    EExternalAccountType Type; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    FName ExternalServiceName; // 0x4 Size: 0x8

};

struct FWebEnvUrl
{
	public:
	    struct FString URL; // 0x0 Size: 0x10
	    struct FString RedirectUrl; // 0x10 Size: 0x10
	    struct FString Environment; // 0x20 Size: 0x10

};

struct FGiftMessage
{
	public:
	    struct FString GiftCode; // 0x0 Size: 0x10
	    struct FString SenderName; // 0x10 Size: 0x10
	    char UnknownData0[0x10];

};

struct FExchangeAccessParams
{
	public:
	    struct FString EntitlementId; // 0x0 Size: 0x10
	    struct FString ReceiptId; // 0x10 Size: 0x10
	    struct FString VendorReceipt; // 0x20 Size: 0x10
	    struct FString AppStore; // 0x30 Size: 0x10

};

struct FOnlineAccountTexts_FailedLoginConsole
{
	public:
	    struct FText AgeRestriction; // 0x0 Size: 0x18
	    struct FText Generic; // 0x18 Size: 0x18
	    struct FText MissingAuthAssociation; // 0x30 Size: 0x18
	    struct FText NeedPremiumAccount; // 0x48 Size: 0x18
	    struct FText OnlinePlayRestriction; // 0x60 Size: 0x18
	    struct FText PatchAvailable; // 0x78 Size: 0x18
	    struct FText PleaseSignIn; // 0x90 Size: 0x18
	    struct FText SystemUpdateAvailable; // 0xa8 Size: 0x18
	    struct FText UI; // 0xc0 Size: 0x18
	    struct FText UnableToComplete; // 0xd8 Size: 0x18
	    struct FText UnableToSignIn; // 0xf0 Size: 0x18
	    struct FText UnableToStartPrivCheck; // 0x108 Size: 0x18
	    struct FText UnexpectedError; // 0x120 Size: 0x18

};

struct FOnlineAccountTexts
{
	public:
	    struct FText AllGiftCodesUsed; // 0x0 Size: 0x18
	    struct FText AssociateConsoleAuth; // 0x18 Size: 0x18
	    struct FText AutoLoginFailed; // 0x30 Size: 0x18
	    struct FText BannedFromGame; // 0x48 Size: 0x18
	    struct FText CheckEntitledToPlay; // 0x60 Size: 0x18
	    struct FText CheckingRejoin; // 0x78 Size: 0x18
	    struct FText CheckServiceAvailability; // 0x90 Size: 0x18
	    struct FText ConsolePrivileges; // 0xa8 Size: 0x18
	    struct FText CreateAccountCompleted; // 0xc0 Size: 0x18
	    struct FText CreateAccountFailure; // 0xd8 Size: 0x18
	    struct FText CreateHeadless; // 0xf0 Size: 0x18
	    struct FText DoQosPingTests; // 0x108 Size: 0x18
	    struct FText DowntimeMinutesWarningText; // 0x120 Size: 0x18
	    struct FText DowntimeSecondsWarningText; // 0x138 Size: 0x18
	    struct FText DuplicateAuthAssociaton; // 0x150 Size: 0x18
	    struct FText EulaCheck; // 0x168 Size: 0x18
	    struct FText ExchangeConsoleGiftsForAccess; // 0x180 Size: 0x18
	    struct FText ExchangeConsolePurchaseForAccess; // 0x198 Size: 0x18
	    struct FText FailedAccountCreate; // 0x1b0 Size: 0x18
	    struct FText FailedEulaCheck_EulaAcceptanceFailed; // 0x1c8 Size: 0x18
	    struct FText FailedEulaCheck_MustAcceptEula; // 0x1e0 Size: 0x18
	    struct FText FailedLoginCredentialsMsg; // 0x1f8 Size: 0x18
	    struct FText FailedLoginParentalLock; // 0x210 Size: 0x18
	    struct FText FailedLoginNoRealId; // 0x228 Size: 0x18
	    struct FText FailedLoginLockoutMsg; // 0x240 Size: 0x18
	    struct FText FailedLoginRequiresMFA; // 0x258 Size: 0x18
	    struct FText FailedLoginRequiresAuthAppMFA; // 0x270 Size: 0x18
	    struct FText FailedInvalidMFA; // 0x288 Size: 0x18
	    struct FText FailedLoginMsg; // 0x2a0 Size: 0x18
	    struct FText FailedLoginMsg_InvalidRefreshToken; // 0x2b8 Size: 0x18
	    struct FText FailedLoginTencent_UnableToSignIn; // 0x2d0 Size: 0x18
	    struct FText FailedLoginTencent_NotSignedInToWeGame; // 0x2e8 Size: 0x18
	    struct FText FailedLoginTencent_FailedToInitializeWeGame; // 0x300 Size: 0x18
	    struct FText FailedLoginTencent_WeGameSystemOffline; // 0x318 Size: 0x18
	    struct FText FailedStartLogin; // 0x330 Size: 0x18
	    struct FText FounderChatExitedText; // 0x348 Size: 0x18
	    struct FText FounderChatJoinedText; // 0x360 Size: 0x18
	    struct FText GameDisplayName; // 0x378 Size: 0x18
	    struct FText GeneralLoginFailure; // 0x390 Size: 0x18
	    struct FText GlobalChatExitedText; // 0x3a8 Size: 0x18
	    struct FText GlobalChatJoinedText; // 0x3c0 Size: 0x18
	    struct FText HeadlessAccountFailed; // 0x3d8 Size: 0x18
	    struct FText InMatchShutdownTimeWarningText; // 0x3f0 Size: 0x18
	    struct FText InvalidUser; // 0x408 Size: 0x18
	    struct FText LoggedOutofMCP; // 0x420 Size: 0x18
	    struct FText DisconnectedFromMCP; // 0x438 Size: 0x18
	    struct FText LoggedOutReturnedToTitle; // 0x450 Size: 0x18
	    struct FText LoggedOutSwitchedProfile; // 0x468 Size: 0x18
	    struct FText LoggingIn; // 0x480 Size: 0x18
	    struct FText LoggingInConsoleAuth; // 0x498 Size: 0x18
	    struct FText LoggingOut; // 0x4b0 Size: 0x18
	    struct FText LoginConsole; // 0x4c8 Size: 0x18
	    struct FText LoginFailure; // 0x4e0 Size: 0x18
	    struct FText Logout_Unlink; // 0x4f8 Size: 0x18
	    struct FText LogoutCompleted; // 0x510 Size: 0x18
	    struct FText LostConnection; // 0x528 Size: 0x18
	    struct FText MCPTimeout; // 0x540 Size: 0x18
	    struct FText LightswitchCheckNetworkFailureMsg; // 0x558 Size: 0x18
	    struct FText NetworkConnectionUnavailable; // 0x570 Size: 0x18
	    struct FText NoPlayEntitlement; // 0x588 Size: 0x18
	    struct FText NoServerAccess; // 0x5a0 Size: 0x18
	    struct FText PlayAccessRevoked; // 0x5b8 Size: 0x18
	    struct FText PremiumAccountName_Default; // 0x5d0 Size: 0x18
	    struct FText PremiumAccountName_PS4; // 0x5e8 Size: 0x18
	    struct FText PremiumAccountName_Switch; // 0x600 Size: 0x18
	    struct FText PremiumAccountName_XboxOne; // 0x618 Size: 0x18
	    struct FText RedeemOfflinePurchases; // 0x630 Size: 0x18
	    struct FText ServiceDowntime; // 0x648 Size: 0x18
	    struct FText SignInCompleting; // 0x660 Size: 0x18
	    struct FText SignIntoConsoleServices; // 0x678 Size: 0x18
	    struct FText TokenExpired; // 0x690 Size: 0x18
	    struct FText UnableToConnect; // 0x6a8 Size: 0x18
	    struct FText UnableToJoinWaitingRoomLoginQueue; // 0x6c0 Size: 0x18
	    struct FText UnexpectedConsoleAuthFailure; // 0x6d8 Size: 0x18
	    struct FText UnlinkConsoleFailed; // 0x6f0 Size: 0x18
	    struct FText UserLoginFailed; // 0x708 Size: 0x18
	    struct FText WaitingRoom; // 0x720 Size: 0x18
	    struct FText WaitingRoomError; // 0x738 Size: 0x18
	    struct FText WaitingRoomFailure; // 0x750 Size: 0x18
	    struct FText WaitingRoomWaiting; // 0x768 Size: 0x18
	    struct FOnlineAccountTexts_FailedLoginConsole FailedLoginConsole; // 0x780 Size: 0x138
	    struct FText LoggingInExternalAuth; // 0x8b8 Size: 0x18
	    struct FText CreateDeviceAuth; // 0x8d0 Size: 0x18
	    struct FText ExtAuthCanceled; // 0x8e8 Size: 0x18
	    struct FText ExtAuthFailure; // 0x900 Size: 0x18
	    struct FText ExtAuthAssociationFailure; // 0x918 Size: 0x18
	    struct FText ExtAuthTimeout; // 0x930 Size: 0x18
	    struct FText ExtAuthMissingAuthAssociation; // 0x948 Size: 0x18
	    struct FText UnableToQueryReceipts; // 0x960 Size: 0x18

};


}