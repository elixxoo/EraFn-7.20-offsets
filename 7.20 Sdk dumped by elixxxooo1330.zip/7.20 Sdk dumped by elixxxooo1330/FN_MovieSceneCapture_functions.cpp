#include "../SDK.hpp"

bool UMovieSceneCaptureProtocolBase::IsCapturing()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.MovieSceneCaptureProtocolBase:IsCapturing");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


EMovieSceneCaptureProtocolState UMovieSceneCaptureProtocolBase::GetState()
{
	struct {
            EMovieSceneCaptureProtocolState ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.MovieSceneCaptureProtocolBase:GetState");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UMovieSceneCapture::SetImageCaptureProtocolType(class UMovieSceneCaptureProtocolBase* ProtocolType)
{
	struct {
            class UMovieSceneCaptureProtocolBase* ProtocolType;
	} params{ ProtocolType };

    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.MovieSceneCapture:SetImageCaptureProtocolType");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMovieSceneCapture::SetAudioCaptureProtocolType(class UMovieSceneCaptureProtocolBase* ProtocolType)
{
	struct {
            class UMovieSceneCaptureProtocolBase* ProtocolType;
	} params{ ProtocolType };

    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.MovieSceneCapture:SetAudioCaptureProtocolType");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


class UMovieSceneCaptureProtocolBase* UMovieSceneCapture::GetImageCaptureProtocol()
{
	struct {
            class UMovieSceneCaptureProtocolBase* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.MovieSceneCapture:GetImageCaptureProtocol");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UMovieSceneCaptureProtocolBase* UMovieSceneCapture::GetAudioCaptureProtocol()
{
	struct {
            class UMovieSceneCaptureProtocolBase* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.MovieSceneCapture:GetAudioCaptureProtocol");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

static bool UMovieSceneCaptureEnvironment::IsCaptureInProgress()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.MovieSceneCaptureEnvironment:IsCaptureInProgress");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static int UMovieSceneCaptureEnvironment::GetCaptureFrameNumber()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.MovieSceneCaptureEnvironment:GetCaptureFrameNumber");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static float UMovieSceneCaptureEnvironment::GetCaptureElapsedTime()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.MovieSceneCaptureEnvironment:GetCaptureElapsedTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static class UMovieSceneImageCaptureProtocolBase* UMovieSceneCaptureEnvironment::FindImageCaptureProtocol()
{
	struct {
            class UMovieSceneImageCaptureProtocolBase* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.MovieSceneCaptureEnvironment:FindImageCaptureProtocol");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static class UMovieSceneAudioCaptureProtocolBase* UMovieSceneCaptureEnvironment::FindAudioCaptureProtocol()
{
	struct {
            class UMovieSceneAudioCaptureProtocolBase* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.MovieSceneCaptureEnvironment:FindAudioCaptureProtocol");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UUserDefinedCaptureProtocol::StopCapturingFinalPixels()
{
    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.UserDefinedCaptureProtocol:StopCapturingFinalPixels");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UUserDefinedCaptureProtocol::StartCapturingFinalPixels(FName StreamName)
{
	struct {
            FName StreamName;
	} params{ StreamName };

    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.UserDefinedCaptureProtocol:StartCapturingFinalPixels");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserDefinedCaptureProtocol::ResolveBuffer(class UTexture* Buffer, FName BufferName, __int64/*DelegateProperty*/ Handler)
{
	struct {
            class UTexture* Buffer;
            FName BufferName;
            __int64/*DelegateProperty*/ Handler;
	} params{ Buffer, BufferName, Handler };

    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.UserDefinedCaptureProtocol:ResolveBuffer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserDefinedCaptureProtocol::PushBufferToStream(class UTexture* Buffer, FName StreamName)
{
	struct {
            class UTexture* Buffer;
            FName StreamName;
	} params{ Buffer, StreamName };

    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.UserDefinedCaptureProtocol:PushBufferToStream");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserDefinedCaptureProtocol::OnWarmUp()
{
    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.UserDefinedCaptureProtocol:OnWarmUp");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UUserDefinedCaptureProtocol::OnTick()
{
    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.UserDefinedCaptureProtocol:OnTick");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UUserDefinedCaptureProtocol::OnStartCapture()
{
    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.UserDefinedCaptureProtocol:OnStartCapture");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


bool UUserDefinedCaptureProtocol::OnSetup()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.UserDefinedCaptureProtocol:OnSetup");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UUserDefinedCaptureProtocol::OnPreTick()
{
    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.UserDefinedCaptureProtocol:OnPreTick");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UUserDefinedCaptureProtocol::OnPauseCapture()
{
    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.UserDefinedCaptureProtocol:OnPauseCapture");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UUserDefinedCaptureProtocol::OnFinalize()
{
    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.UserDefinedCaptureProtocol:OnFinalize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UUserDefinedCaptureProtocol::OnCaptureFrame()
{
    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.UserDefinedCaptureProtocol:OnCaptureFrame");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


bool UUserDefinedCaptureProtocol::OnCanFinalize()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.UserDefinedCaptureProtocol:OnCanFinalize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UUserDefinedCaptureProtocol::OnBeginFinalize()
{
    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.UserDefinedCaptureProtocol:OnBeginFinalize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


struct FFrameMetrics UUserDefinedCaptureProtocol::GetCurrentFrameMetrics()
{
	struct {
            struct FFrameMetrics ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.UserDefinedCaptureProtocol:GetCurrentFrameMetrics");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FString UUserDefinedCaptureProtocol::GenerateFilename(struct FFrameMetrics InFrameMetrics)
{
	struct {
            struct FFrameMetrics InFrameMetrics;
            struct FString ReturnValue;
	} params{ InFrameMetrics };

    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.UserDefinedCaptureProtocol:GenerateFilename");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UUserDefinedCaptureProtocol::BindToStream(FName StreamName, __int64/*DelegateProperty*/ Handler)
{
	struct {
            FName StreamName;
            __int64/*DelegateProperty*/ Handler;
	} params{ StreamName, Handler };

    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.UserDefinedCaptureProtocol:BindToStream");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UUserDefinedImageCaptureProtocol::WriteImageToDisk(struct FCapturedPixels PixelData, FName StreamName, struct FFrameMetrics FrameMetrics, bool bCopyImageData)
{
	struct {
            struct FCapturedPixels PixelData;
            FName StreamName;
            struct FFrameMetrics FrameMetrics;
            bool bCopyImageData;
	} params{ PixelData, StreamName, FrameMetrics, bCopyImageData };

    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.UserDefinedImageCaptureProtocol:WriteImageToDisk");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


struct FString UUserDefinedImageCaptureProtocol::GenerateFilenameForCurrentFrame()
{
	struct {
            struct FString ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.UserDefinedImageCaptureProtocol:GenerateFilenameForCurrentFrame");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FString UUserDefinedImageCaptureProtocol::GenerateFilenameForBuffer(class UTexture* Buffer, FName StreamName)
{
	struct {
            class UTexture* Buffer;
            FName StreamName;
            struct FString ReturnValue;
	} params{ Buffer, StreamName };

    static auto fn = UObject::FindObject("/Script/MovieSceneCapture.UserDefinedImageCaptureProtocol:GenerateFilenameForBuffer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

