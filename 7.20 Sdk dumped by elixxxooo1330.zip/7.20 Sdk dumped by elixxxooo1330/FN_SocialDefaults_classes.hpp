#pragma once

#include "../SDK.hpp"

namespace SDK {


class UChatColorSchemeDataAsset : public UDataAsset
{
	public:
	    struct FChatColorScheme ChatColorData; // 0x30 Size: 0x120

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialDefaults.ChatColorSchemeDataAsset");
			return (class UClass*)ptr;
		};

};

class USocialActionButtonStyleDataAsset : public UDataAsset
{
	public:
	    struct FButtonStyle Style; // 0x30 Size: 0x278

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialDefaults.SocialActionButtonStyleDataAsset");
			return (class UClass*)ptr;
		};

};

class USocialChatChromeColorSchemeDataAsset : public UDataAsset
{
	public:
	    struct FChatChromeColorScheme Style; // 0x30 Size: 0x50

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialDefaults.SocialChatChromeColorSchemeDataAsset");
			return (class UClass*)ptr;
		};

};

class USocialChatChromeMarginsDataAsset : public UDataAsset
{
	public:
	    struct FChatChromeMargins Style; // 0x30 Size: 0x64
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialDefaults.SocialChatChromeMarginsDataAsset");
			return (class UClass*)ptr;
		};

};

class USocialChatChromeStyleDataAsset : public UDataAsset
{
	public:
	    struct FChatChromeStyle Style; // 0x30 Size: 0x7c8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialDefaults.SocialChatChromeStyleDataAsset");
			return (class UClass*)ptr;
		};

};

class USocialChatMarkupStyleDataAsset : public UDataAsset
{
	public:
	    struct FChatMarkupStyle Style; // 0x30 Size: 0x608

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialDefaults.SocialChatMarkupStyleDataAsset");
			return (class UClass*)ptr;
		};

};

class USocialChatStyleDataAsset : public UDataAsset
{
	public:
	    struct FChatStyle Style; // 0x30 Size: 0x1360

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialDefaults.SocialChatStyleDataAsset");
			return (class UClass*)ptr;
		};

};

class USocialCheckBoxStyleDataAsset : public UDataAsset
{
	public:
	    struct FCheckBoxStyle Style; // 0x30 Size: 0x580

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialDefaults.SocialCheckBoxStyleDataAsset");
			return (class UClass*)ptr;
		};

};

class USocialFontStyleDataAsset : public UDataAsset
{
	public:
	    struct FSocialFontStyle Style; // 0x30 Size: 0x210

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialDefaults.SocialFontStyleDataAsset");
			return (class UClass*)ptr;
		};

};

class USocialListMarginsDataAsset : public UDataAsset
{
	public:
	    struct FSocialListMargins Style; // 0x30 Size: 0x200

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialDefaults.SocialListMarginsDataAsset");
			return (class UClass*)ptr;
		};

};

class USocialListStyleDataAsset : public UDataAsset
{
	public:
	    struct FSocialListStyle Style; // 0x30 Size: 0x26f8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialDefaults.SocialListStyleDataAsset");
			return (class UClass*)ptr;
		};

};

class USocialProfanityDataAsset : public UDataAsset
{
	public:
	    TArray<struct FProfanityData> ProfanityData; // 0x30 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialDefaults.SocialProfanityDataAsset");
			return (class UClass*)ptr;
		};

};

class USocialRadioBoxStyleDataAsset : public UDataAsset
{
	public:
	    struct FCheckBoxStyle Style; // 0x30 Size: 0x580

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialDefaults.SocialRadioBoxStyleDataAsset");
			return (class UClass*)ptr;
		};

};

class USocialScrollBarStyleDataAsset : public UDataAsset
{
	public:
	    struct FScrollBarStyle Style; // 0x30 Size: 0x4d0

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialDefaults.SocialScrollBarStyleDataAsset");
			return (class UClass*)ptr;
		};

};

class USocialSoundSchemaDataAsset : public UDataAsset
{
	public:
	    struct FSocialSoundSchema SoundSchema; // 0x30 Size: 0x48

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialDefaults.SocialSoundSchemaDataAsset");
			return (class UClass*)ptr;
		};

};

class USocialStyleDataAsset : public UDataAsset
{
	public:
	    class USocialFontStyleDataAsset* SmallFontStyle; // 0x30 Size: 0x8
	    class USocialFontStyleDataAsset* NormalFontStyle; // 0x38 Size: 0x8
	    class USocialFontStyleDataAsset* LargeFontStyle; // 0x40 Size: 0x8
	    class USocialFontStyleDataAsset* ChatFontStyle; // 0x48 Size: 0x8
	    class USocialListStyleDataAsset* SocialListStyle; // 0x50 Size: 0x8
	    class USocialListMarginsDataAsset* SocialListMargins; // 0x58 Size: 0x8
	    class USocialChatStyleDataAsset* ChatStyle; // 0x60 Size: 0x8
	    class USocialChatChromeStyleDataAsset* ChatChromeStyle; // 0x68 Size: 0x8
	    class USocialChatChromeMarginsDataAsset* ChatChromeMargins; // 0x70 Size: 0x8
	    class USocialChatChromeColorSchemeDataAsset* ChatChromeColorScheme; // 0x78 Size: 0x8
	    class UChatColorSchemeDataAsset* ChatColorScheme; // 0x80 Size: 0x8
	    class USocialSoundSchemaDataAsset* SoundSchema; // 0x88 Size: 0x8
	    class USocialActionButtonStyleDataAsset* ActionButtonStyle; // 0x90 Size: 0x8
	    class USocialCheckBoxStyleDataAsset* CheckBoxStyle; // 0x98 Size: 0x8
	    class USocialRadioBoxStyleDataAsset* RadioBoxStyle; // 0xa0 Size: 0x8
	    class USocialScrollBarStyleDataAsset* ScrollBoxStyle; // 0xa8 Size: 0x8
	    class USocialChatMarkupStyleDataAsset* MarkupStyle; // 0xb0 Size: 0x8
	    class USocialProfanityDataAsset* ProfanityDataAsset; // 0xb8 Size: 0x8
	    char UnknownData0[0x66d0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialDefaults.SocialStyleDataAsset");
			return (class UClass*)ptr;
		};

};


}