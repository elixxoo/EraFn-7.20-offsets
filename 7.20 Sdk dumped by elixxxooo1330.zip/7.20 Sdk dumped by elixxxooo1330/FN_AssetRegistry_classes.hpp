#pragma once

#include "../SDK.hpp"

namespace SDK {


class UAssetRegistryImpl : public UObject
{
	public:
	    char UnknownData0[0x7b0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AssetRegistry.AssetRegistryImpl");
			return (class UClass*)ptr;
		};

};

class UAssetRegistryHelpers : public UObject
{
	public:
	    static struct FSoftObjectPath ToSoftObjectPath(struct FAssetData InAssetData); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static struct FARFilter SetFilterTagsAndValues(struct FARFilter InFilter, TArray<struct FTagAndValue> InTagsAndValues); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static bool IsValid(struct FAssetData InAssetData); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static bool IsUAsset(struct FAssetData InAssetData); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static bool IsRedirector(struct FAssetData InAssetData); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static bool IsAssetLoaded(struct FAssetData InAssetData); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static bool GetTagValue(struct FAssetData InAssetData, FName InTagName, struct FString OutTagValue); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static struct FString GetFullName(struct FAssetData InAssetData); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static struct FString GetExportTextName(struct FAssetData InAssetData); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static class UObject* GetClass(struct FAssetData InAssetData); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static __int64/*InterfaceProperty*/ GetAssetRegistry(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static class UObject* GetAsset(struct FAssetData InAssetData); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    static struct FAssetData CreateAssetData(class UObject* InAsset, bool bAllowBlueprintClass); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AssetRegistry.AssetRegistryHelpers");
			return (class UClass*)ptr;
		};

};

class UAssetRegistry : public UInterface
{
	public:
	    void UseFilterToExcludeAssets(TArray<struct FAssetData> AssetDataList, struct FARFilter Filter); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void SearchAllAssets(bool bSynchronousSearch); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void ScanPathsSynchronous(TArray<struct FString> InPaths, bool bForceRescan); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void ScanModifiedAssetFiles(TArray<struct FString> InFilePaths); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void ScanFilesSynchronous(TArray<struct FString> InFilePaths, bool bForceRescan); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void RunAssetsThroughFilter(TArray<struct FAssetData> AssetDataList, struct FARFilter Filter); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void PrioritizeSearchPath(struct FString PathToPrioritize); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool IsLoadingAssets(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool HasAssets(FName PackagePath, bool bRecursive); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void GetSubPaths(struct FString InBasePath, TArray<struct FString> OutPathList, bool bInRecurse); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool GetAssetsByPath(FName PackagePath, TArray<struct FAssetData> OutAssetData, bool bRecursive, bool bIncludeOnlyOnDiskAssets); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    bool GetAssetsByPackageName(FName PackageName, TArray<struct FAssetData> OutAssetData, bool bIncludeOnlyOnDiskAssets); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    bool GetAssetsByClass(FName ClassName, TArray<struct FAssetData> OutAssetData, bool bSearchSubClasses); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    bool GetAssets(struct FARFilter Filter, TArray<struct FAssetData> OutAssetData); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    struct FAssetData GetAssetByObjectPath(FName ObjectPath, bool bIncludeOnlyOnDiskAssets); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void GetAllCachedPaths(TArray<struct FString> OutPathList); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    bool GetAllAssets(TArray<struct FAssetData> OutAssetData, bool bIncludeOnlyOnDiskAssets); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AssetRegistry.AssetRegistry");
			return (class UClass*)ptr;
		};

};


}