#pragma once

#include "../SDK.hpp"

namespace SDK {


class UConsoleSettings : public UObject
{
	public:
	    int MaxScrollbackSize; // 0x28 Size: 0x4
	    char UnknownData0[0x4]; // 0x2c
	    TArray<struct FAutoCompleteCommand> ManualAutoCompleteList; // 0x30 Size: 0x10
	    TArray<struct FString> AutoCompleteMapPaths; // 0x40 Size: 0x10
	    float BackgroundOpacityPercentage; // 0x50 Size: 0x4
	    bool bOrderTopToBottom; // 0x54 Size: 0x1
	    char UnknownData1[0x3]; // 0x55
	    struct FColor InputColor; // 0x58 Size: 0x4
	    struct FColor HistoryColor; // 0x5c Size: 0x4
	    struct FColor AutoCompleteCommandColor; // 0x60 Size: 0x4
	    struct FColor AutoCompleteCVarColor; // 0x64 Size: 0x4
	    struct FColor AutoCompleteFadedColor; // 0x68 Size: 0x4
	    char UnknownData2[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EngineSettings.ConsoleSettings");
			return (class UClass*)ptr;
		};

};

class UGameMapsSettings : public UObject
{
	public:
	    struct FSoftObjectPath EditorStartupMap; // 0x28 Size: 0x18
	    struct FString LocalMapOptions; // 0x40 Size: 0x10
	    struct FSoftObjectPath TransitionMap; // 0x50 Size: 0x18
	    bool bUseSplitscreen; // 0x68 Size: 0x1
	    char TwoPlayerSplitscreenLayout; // 0x69 Size: 0x1
	    char ThreePlayerSplitscreenLayout; // 0x6a Size: 0x1
	    EFourPlayerSplitScreenType FourPlayerSplitscreenLayout; // 0x6b Size: 0x1
	    bool bOffsetPlayerGamepadIds; // 0x6c Size: 0x1
	    char UnknownData0[0x3]; // 0x6d
	    struct FSoftClassPath GameInstanceClass; // 0x70 Size: 0x18
	    TArray<struct FSubLevelStrippingInfo> SubLevelClassesToStrip; // 0x88 Size: 0x10
	    struct FSoftObjectPath GameDefaultMap; // 0x98 Size: 0x18
	    struct FSoftObjectPath ServerDefaultMap; // 0xb0 Size: 0x18
	    struct FSoftClassPath GlobalDefaultGameMode; // 0xc8 Size: 0x18
	    struct FSoftClassPath GlobalDefaultServerGameMode; // 0xe0 Size: 0x18
	    TArray<struct FGameModeName> GameModeMapPrefixes; // 0xf8 Size: 0x10
	    TArray<struct FGameModeName> GameModeClassAliases; // 0x108 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EngineSettings.GameMapsSettings");
			return (class UClass*)ptr;
		};

};

class UGameNetworkManagerSettings : public UObject
{
	public:
	    int MinDynamicBandwidth; // 0x28 Size: 0x4
	    int MaxDynamicBandwidth; // 0x2c Size: 0x4
	    int TotalNetBandwidth; // 0x30 Size: 0x4
	    int BadPingThreshold; // 0x34 Size: 0x4
	    bool bIsStandbyCheckingEnabled; // 0x38 Size: 0x1
	    char UnknownData0[0x3]; // 0x39
	    float StandbyRxCheatTime; // 0x3c Size: 0x4
	    float StandbyTxCheatTime; // 0x40 Size: 0x4
	    float PercentMissingForRxStandby; // 0x44 Size: 0x4
	    float PercentMissingForTxStandby; // 0x48 Size: 0x4
	    float PercentForBadPing; // 0x4c Size: 0x4
	    float JoinInProgressStandbyWaitTime; // 0x50 Size: 0x4
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EngineSettings.GameNetworkManagerSettings");
			return (class UClass*)ptr;
		};

};

class UGameSessionSettings : public UObject
{
	public:
	    int MaxSpectators; // 0x28 Size: 0x4
	    int MaxPlayers; // 0x2c Size: 0x4
	    bool bRequiresPushToTalk; // 0x30 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EngineSettings.GameSessionSettings");
			return (class UClass*)ptr;
		};

};

class UGeneralEngineSettings : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EngineSettings.GeneralEngineSettings");
			return (class UClass*)ptr;
		};

};

class UGeneralProjectSettings : public UObject
{
	public:
	    struct FString CompanyName; // 0x28 Size: 0x10
	    struct FString CompanyDistinguishedName; // 0x38 Size: 0x10
	    struct FString CopyrightNotice; // 0x48 Size: 0x10
	    struct FString Description; // 0x58 Size: 0x10
	    struct FString Homepage; // 0x68 Size: 0x10
	    struct FString LicensingTerms; // 0x78 Size: 0x10
	    struct FString PrivacyPolicy; // 0x88 Size: 0x10
	    struct FGuid ProjectID; // 0x98 Size: 0x10
	    struct FString ProjectName; // 0xa8 Size: 0x10
	    struct FString ProjectVersion; // 0xb8 Size: 0x10
	    struct FString SupportContact; // 0xc8 Size: 0x10
	    struct FText ProjectDisplayedTitle; // 0xd8 Size: 0x18
	    struct FText ProjectDebugTitleInfo; // 0xf0 Size: 0x18
	    bool bShouldWindowPreserveAspectRatio; // 0x108 Size: 0x1
	    bool bUseBorderlessWindow; // 0x109 Size: 0x1
	    bool bStartInVR; // 0x10a Size: 0x1
	    bool bStartInAR; // 0x10b Size: 0x1
	    bool bSupportAR; // 0x10c Size: 0x1
	    bool bAllowWindowResize; // 0x10d Size: 0x1
	    bool bAllowClose; // 0x10e Size: 0x1
	    bool bAllowMaximize; // 0x10f Size: 0x1
	    bool bAllowMinimize; // 0x110 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EngineSettings.GeneralProjectSettings");
			return (class UClass*)ptr;
		};

};

class UHudSettings : public UObject
{
	public:
	    bool bShowHUD; // 0x28 Size: 0x1
	    char UnknownData0[0x7]; // 0x29
	    TArray<FName> DebugDisplay; // 0x30 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EngineSettings.HudSettings");
			return (class UClass*)ptr;
		};

};


}