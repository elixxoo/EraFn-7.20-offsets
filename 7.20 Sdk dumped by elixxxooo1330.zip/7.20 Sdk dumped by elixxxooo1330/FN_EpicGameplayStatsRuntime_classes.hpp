#pragma once

#include "../SDK.hpp"

namespace SDK {


class UBlueprintGameplayStatsLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static bool NotEqual_GameplayStatTagGameplayStatTag(struct FGameplayStatTag A, struct FGameplayStatTag B); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_GameplayStatTagGameplayStatTag(struct FGameplayStatTag A, struct FGameplayStatTag B); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EpicGameplayStatsRuntime.BlueprintGameplayStatsLibrary");
			return (class UClass*)ptr;
		};

};

class UGameplayTagTableManager : public UDataAsset
{
	public:
	    TArray<struct FManagedGameplayTagDataTableItem> Tables; // 0x30 Size: 0x10
	    char UnknownData0[0x58];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EpicGameplayStatsRuntime.GameplayTagTableManager");
			return (class UClass*)ptr;
		};

};


}