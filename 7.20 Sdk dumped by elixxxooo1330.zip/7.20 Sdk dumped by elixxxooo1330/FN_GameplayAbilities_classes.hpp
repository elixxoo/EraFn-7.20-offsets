#pragma once

#include "../SDK.hpp"

namespace SDK {


class UAbilitySystemBlueprintLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static bool TargetDataHasOrigin(struct FGameplayAbilityTargetDataHandle TargetData, int Index); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static bool TargetDataHasHitResult(struct FGameplayAbilityTargetDataHandle HitResult, int Index); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static bool TargetDataHasEndPoint(struct FGameplayAbilityTargetDataHandle TargetData, int Index); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static bool TargetDataHasActor(struct FGameplayAbilityTargetDataHandle TargetData, int Index); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static struct FGameplayEffectSpecHandle SetStackCountToMax(struct FGameplayEffectSpecHandle SpecHandle); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static struct FGameplayEffectSpecHandle SetStackCount(struct FGameplayEffectSpecHandle SpecHandle, int StackCount); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static struct FGameplayEffectSpecHandle SetDuration(struct FGameplayEffectSpecHandle SpecHandle, float Duration); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static void SendGameplayEventToActor(class AActor* Actor, struct FGameplayTag EventTag, struct FGameplayEventData Payload); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static bool NotEqual_GameplayAttributeGameplayAttribute(struct FGameplayAttribute AttributeA, struct FGameplayAttribute AttributeB); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static struct FGameplayEffectSpecHandle MakeSpecHandle(class UGameplayEffect* InGameplayEffect, class AActor* InInstigator, class AActor* InEffectCauser, float InLevel); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static struct FGameplayTargetDataFilterHandle MakeFilterHandle(struct FGameplayTargetDataFilter Filter, class AActor* FilterActor); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static bool IsValid(struct FGameplayAttribute Attribute); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    static bool IsInstigatorLocallyControlledPlayer(struct FGameplayCueParameters Parameters); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    static bool IsInstigatorLocallyControlled(struct FGameplayCueParameters Parameters); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    static bool HasHitResult(struct FGameplayCueParameters Parameters); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    static struct FTransform GetTargetDataOrigin(struct FGameplayAbilityTargetDataHandle TargetData, int Index); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    static struct FTransform GetTargetDataEndPointTransform(struct FGameplayAbilityTargetDataHandle TargetData, int Index); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    static struct FVector GetTargetDataEndPoint(struct FGameplayAbilityTargetDataHandle TargetData, int Index); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    static struct FVector GetOrigin(struct FGameplayCueParameters Parameters); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    static float GetModifiedAttributeMagnitude(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayAttribute Attribute); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    static struct FTransform GetInstigatorTransform(struct FGameplayCueParameters Parameters); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    static class AActor* GetInstigatorActor(struct FGameplayCueParameters Parameters); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    static struct FHitResult GetHitResultFromTargetData(struct FGameplayAbilityTargetDataHandle HitResult, int Index); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    static struct FHitResult GetHitResult(struct FGameplayCueParameters Parameters); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    static bool GetGameplayCueEndLocationAndNormal(class AActor* TargetActor, struct FGameplayCueParameters Parameters, struct FVector Location, struct FVector Normal); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    static bool GetGameplayCueDirection(class AActor* TargetActor, struct FGameplayCueParameters Parameters, struct FVector Direction); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    static float GetFloatAttributeFromAbilitySystemComponent(class UAbilitySystemComponent* AbilitySystem, struct FGameplayAttribute Attribute, bool bSuccessfullyFoundAttribute); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    static float GetFloatAttributeBaseFromAbilitySystemComponent(class UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayAttribute Attribute, bool bSuccessfullyFoundAttribute); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    static float GetFloatAttributeBase(class AActor* Actor, struct FGameplayAttribute Attribute, bool bSuccessfullyFoundAttribute); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    static float GetFloatAttribute(class AActor* Actor, struct FGameplayAttribute Attribute, bool bSuccessfullyFoundAttribute); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    static struct FGameplayEffectContextHandle GetEffectContext(struct FGameplayEffectSpecHandle SpecHandle); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    static int GetDataCountFromTargetData(struct FGameplayAbilityTargetDataHandle TargetData); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    static TArray<struct FGameplayEffectSpecHandle> GetAllLinkedGameplayEffectSpecHandles(struct FGameplayEffectSpecHandle SpecHandle); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    static TArray<class AActor*> GetAllActorsFromTargetData(struct FGameplayAbilityTargetDataHandle TargetData); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    static TArray<class AActor*> GetActorsFromTargetData(struct FGameplayAbilityTargetDataHandle TargetData, int Index); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    static int GetActorCount(struct FGameplayCueParameters Parameters); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    static class AActor* GetActorByIndex(struct FGameplayCueParameters Parameters, int Index); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    static float GetActiveGameplayEffectTotalDuration(struct FActiveGameplayEffectHandle ActiveHandle); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    static float GetActiveGameplayEffectStartTime(struct FActiveGameplayEffectHandle ActiveHandle); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    static int GetActiveGameplayEffectStackLimitCount(struct FActiveGameplayEffectHandle ActiveHandle); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    static int GetActiveGameplayEffectStackCount(struct FActiveGameplayEffectHandle ActiveHandle); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    static float GetActiveGameplayEffectRemainingDuration(class UObject* WorldContextObject, struct FActiveGameplayEffectHandle ActiveHandle); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    static float GetActiveGameplayEffectExpectedEndTime(struct FActiveGameplayEffectHandle ActiveHandle); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    static struct FString GetActiveGameplayEffectDebugString(struct FActiveGameplayEffectHandle ActiveHandle); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    static class UAbilitySystemComponent* GetAbilitySystemComponent(class AActor* Actor); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    static void ForwardGameplayCueToTarget(__int64/*InterfaceProperty*/ TargetCueInterface, char EventType, struct FGameplayCueParameters Parameters); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    static struct FGameplayAbilityTargetDataHandle FilterTargetData(struct FGameplayAbilityTargetDataHandle TargetDataHandle, struct FGameplayTargetDataFilterHandle ActorFilterClass); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    static float EvaluateAttributeValueWithTagsAndBase(class UAbilitySystemComponent* AbilitySystem, struct FGameplayAttribute Attribute, struct FGameplayTagContainer SourceTags, struct FGameplayTagContainer TargetTags, float BaseValue, bool bSuccess); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    static float EvaluateAttributeValueWithTags(class UAbilitySystemComponent* AbilitySystem, struct FGameplayAttribute Attribute, struct FGameplayTagContainer SourceTags, struct FGameplayTagContainer TargetTags, bool bSuccess); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_GameplayAttributeGameplayAttribute(struct FGameplayAttribute AttributeA, struct FGameplayAttribute AttributeB); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    static void EffectContextSetOrigin(struct FGameplayEffectContextHandle EffectContext, struct FVector Origin); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    static bool EffectContextIsValid(struct FGameplayEffectContextHandle EffectContext); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    static bool EffectContextIsInstigatorLocallyControlled(struct FGameplayEffectContextHandle EffectContext); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    static bool EffectContextHasHitResult(struct FGameplayEffectContextHandle EffectContext); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    static class UObject* EffectContextGetSourceObject(struct FGameplayEffectContextHandle EffectContext); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    static class AActor* EffectContextGetOriginalInstigatorActor(struct FGameplayEffectContextHandle EffectContext); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    static struct FVector EffectContextGetOrigin(struct FGameplayEffectContextHandle EffectContext); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    static class AActor* EffectContextGetInstigatorActor(struct FGameplayEffectContextHandle EffectContext); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    static struct FHitResult EffectContextGetHitResult(struct FGameplayEffectContextHandle EffectContext); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    static class AActor* EffectContextGetEffectCauser(struct FGameplayEffectContextHandle EffectContext); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    static void EffectContextAddHitResult(struct FGameplayEffectContextHandle EffectContext, struct FHitResult HitResult, bool bReset); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    static bool DoesTargetDataContainActor(struct FGameplayAbilityTargetDataHandle TargetData, int Index, class AActor* Actor); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    static bool DoesGameplayCueMeetTagRequirements(struct FGameplayCueParameters Parameters, struct FGameplayTagRequirements SourceTagReqs, struct FGameplayTagRequirements TargetTagReqs); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x7fe1]; // 0x7fe1
	    static struct FGameplayEffectSpecHandle CloneSpecHandle(class AActor* InNewInstigator, class AActor* InEffectCauser, struct FGameplayEffectSpecHandle GameplayEffectSpecHandle_Clone); // 0x0 Size: 0x7fe1
	    char UnknownData63[0x7fe1]; // 0x7fe1
	    static struct FGameplayEffectSpecHandle AssignTagSetByCallerMagnitude(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTag DataTag, float Magnitude); // 0x0 Size: 0x7fe1
	    char UnknownData64[0x7fe1]; // 0x7fe1
	    static struct FGameplayEffectSpecHandle AssignSetByCallerMagnitude(struct FGameplayEffectSpecHandle SpecHandle, FName DataName, float Magnitude); // 0x0 Size: 0x7fe1
	    char UnknownData65[0x7fe1]; // 0x7fe1
	    static struct FGameplayAbilityTargetDataHandle AppendTargetDataHandle(struct FGameplayAbilityTargetDataHandle TargetHandle, struct FGameplayAbilityTargetDataHandle HandleToAdd); // 0x0 Size: 0x7fe1
	    char UnknownData66[0x7fe1]; // 0x7fe1
	    static struct FGameplayEffectSpecHandle AddLinkedGameplayEffectSpec(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayEffectSpecHandle LinkedGameplayEffectSpec); // 0x0 Size: 0x7fe1
	    char UnknownData67[0x7fe1]; // 0x7fe1
	    static struct FGameplayEffectSpecHandle AddLinkedGameplayEffect(struct FGameplayEffectSpecHandle SpecHandle, class UGameplayEffect* LinkedGameplayEffect); // 0x0 Size: 0x7fe1
	    char UnknownData68[0x7fe1]; // 0x7fe1
	    static struct FGameplayEffectSpecHandle AddGrantedTags(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTagContainer NewGameplayTags); // 0x0 Size: 0x7fe1
	    char UnknownData69[0x7fe1]; // 0x7fe1
	    static struct FGameplayEffectSpecHandle AddGrantedTag(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTag NewGameplayTag); // 0x0 Size: 0x7fe1
	    char UnknownData70[0x7fe1]; // 0x7fe1
	    static struct FGameplayEffectSpecHandle AddAssetTags(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTagContainer NewGameplayTags); // 0x0 Size: 0x7fe1
	    char UnknownData71[0x7fe1]; // 0x7fe1
	    static struct FGameplayEffectSpecHandle AddAssetTag(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTag NewGameplayTag); // 0x0 Size: 0x7fe1
	    char UnknownData72[0x7fe1]; // 0x7fe1
	    static struct FGameplayAbilityTargetDataHandle AbilityTargetDataFromLocations(struct FGameplayAbilityTargetingLocationInfo SourceLocation, struct FGameplayAbilityTargetingLocationInfo TargetLocation); // 0x0 Size: 0x7fe1
	    char UnknownData73[0x7fe1]; // 0x7fe1
	    static struct FGameplayAbilityTargetDataHandle AbilityTargetDataFromHitResult(struct FHitResult HitResult); // 0x0 Size: 0x7fe1
	    char UnknownData74[0x7fe1]; // 0x7fe1
	    static struct FGameplayAbilityTargetDataHandle AbilityTargetDataFromActorArray(TArray<class AActor*> ActorArray, bool OneTargetPerHandle); // 0x0 Size: 0x7fe1
	    char UnknownData75[0x7fe1]; // 0x7fe1
	    static struct FGameplayAbilityTargetDataHandle AbilityTargetDataFromActor(class AActor* Actor); // 0x0 Size: 0x7fe1
	    char UnknownData76[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary");
			return (class UClass*)ptr;
		};

};

class UAbilitySystemComponent : public UGameplayTasksComponent
{
	public:
	    char UnknownData0[0x10];
	    TArray<struct FAttributeDefaults> DefaultStartingData; // 0x178 Size: 0x10
	    TArray<class UAttributeSet*> SpawnedAttributes; // 0x188 Size: 0x10
	    char UnknownData1[0x1c0]; // 0x198
	    float OutgoingDuration; // 0x358 Size: 0x4
	    float IncomingDuration; // 0x35c Size: 0x4
	    char UnknownData2[0x20]; // 0x360
	    TArray<struct FString> ClientDebugStrings; // 0x380 Size: 0x10
	    TArray<struct FString> ServerDebugStrings; // 0x390 Size: 0x10
	    bool UserAbilityActivationInhibited; // 0x3f8 Size: 0x1
	    bool ReplicationProxyEnabled; // 0x3f9 Size: 0x1
	    bool bSuppressGrantAbility; // 0x3fa Size: 0x1
	    bool bSuppressGameplayCues; // 0x3fb Size: 0x1
	    char UnknownData3[0x5c]; // 0x3a4
	    TArray<class AGameplayAbilityTargetActor*> SpawnedTargetActors; // 0x400 Size: 0x10
	    char UnknownData4[0x28]; // 0x410
	    class AActor* OwnerActor; // 0x438 Size: 0x8
	    class AActor* AvatarActor; // 0x440 Size: 0x8
	    char UnknownData5[0x10]; // 0x448
	    struct FGameplayAbilitySpecContainer ActivatableAbilities; // 0x458 Size: 0xc8
	    char UnknownData6[0x30]; // 0x520
	    TArray<class UGameplayAbility*> AllReplicatedInstancedAbilities; // 0x550 Size: 0x10
	    char UnknownData7[0x1d0]; // 0x560
	    struct FGameplayAbilityRepAnimMontage RepAnimMontageInfo; // 0x730 Size: 0x30
	    bool bCachedIsNetSimulated; // 0x760 Size: 0x1
	    bool bPendingMontageRep; // 0x761 Size: 0x1
	    char UnknownData8[0x6]; // 0x762
	    struct FGameplayAbilityLocalAnimMontage LocalAnimMontageInfo; // 0x768 Size: 0x30
	    char UnknownData9[0xa0]; // 0x798
	    struct FActiveGameplayEffectsContainer ActiveGameplayEffects; // 0x838 Size: 0x428
	    struct FActiveGameplayCueContainer ActiveGameplayCues; // 0xc60 Size: 0xd0
	    struct FActiveGameplayCueContainer MinimalReplicationGameplayCues; // 0xd30 Size: 0xd0
	    char UnknownData10[0x128]; // 0xe00
	    TArray<char> BlockedAbilityBindings; // 0xf28 Size: 0x10
	    char UnknownData11[0x128]; // 0xf38
	    struct FMinimalReplicationTagCountMap MinimalReplicationTags; // 0x1060 Size: 0x60
	    char UnknownData12[0x10]; // 0x10c0
	    struct FReplicatedPredictionKeyMap ReplicatedPredictionKeyMap; // 0x10d0 Size: 0xc0
	    char UnknownData13[0x1190]; // 0x1190
	    bool TryActivateAbilityByClass(class UGameplayAbility* InAbilityToActivate, bool bAllowRemoteActivation); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    bool TryActivateAbilitiesByTag(struct FGameplayTagContainer GameplayTagContainer, bool bAllowRemoteActivation); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void TargetConfirm(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void TargetCancel(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void SetUserAbilityActivationInhibited(bool NewInhibit); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void SetActiveGameplayEffectLevelUsingQuery(struct FGameplayEffectQuery Query, int NewLevel); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void SetActiveGameplayEffectLevel(struct FActiveGameplayEffectHandle ActiveHandle, int NewLevel); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void ServerTryActivateAbilityWithEventData(struct FGameplayAbilitySpecHandle AbilityToActivate, bool InputPressed, struct FPredictionKey PredictionKey, struct FGameplayEventData TriggerEventData); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void ServerTryActivateAbility(struct FGameplayAbilitySpecHandle AbilityToActivate, bool InputPressed, struct FPredictionKey PredictionKey); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void ServerSetReplicatedTargetDataCancelled(struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FPredictionKey CurrentPredictionKey); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void ServerSetReplicatedTargetData(struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FGameplayAbilityTargetDataHandle ReplicatedTargetDataHandle, struct FGameplayTag ApplicationTag, struct FPredictionKey CurrentPredictionKey); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void ServerSetReplicatedEventWithPayload(char EventType, struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FPredictionKey CurrentPredictionKey, struct FVector_NetQuantize100 VectorPayload); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void ServerSetReplicatedEvent(char EventType, struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FPredictionKey CurrentPredictionKey); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void ServerSetInputReleased(struct FGameplayAbilitySpecHandle AbilityHandle); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void ServerSetInputPressed(struct FGameplayAbilitySpecHandle AbilityHandle); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void ServerPrintDebug_RequestWithStrings(TArray<struct FString> Strings); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    void ServerPrintDebug_Request(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    void ServerEndAbility(struct FGameplayAbilitySpecHandle AbilityToEnd, struct FGameplayAbilityActivationInfo ActivationInfo, struct FPredictionKey PredictionKey); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    void ServerCurrentMontageSetPlayRate(class UAnimMontage* ClientAnimMontage, float InPlayRate); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    void ServerCurrentMontageSetNextSectionName(class UAnimMontage* ClientAnimMontage, float ClientPosition, FName SectionName, FName NextSectionName); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    void ServerCurrentMontageJumpToSectionName(class UAnimMontage* ClientAnimMontage, FName SectionName); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    void ServerCancelAbility(struct FGameplayAbilitySpecHandle AbilityToCancel, struct FGameplayAbilityActivationInfo ActivationInfo); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    void ServerAbilityRPCBatch(struct FServerAbilityRPCBatch BatchInfo); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    void RemoveActiveGameplayEffectBySourceEffect(class UGameplayEffect* GameplayEffect, class UAbilitySystemComponent* InstigatorAbilitySystemComponent, int StacksToRemove); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    bool RemoveActiveGameplayEffect(struct FActiveGameplayEffectHandle Handle, int StacksToRemove); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    int RemoveActiveEffectsWithTags(struct FGameplayTagContainer Tags); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    int RemoveActiveEffectsWithSourceTags(struct FGameplayTagContainer Tags); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    int RemoveActiveEffectsWithGrantedTags(struct FGameplayTagContainer Tags); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    int RemoveActiveEffectsWithAppliedTags(struct FGameplayTagContainer Tags); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    void OnRep_ServerDebugString(); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    void OnRep_ReplicatedAnimMontage(); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    void OnRep_OwningActor(); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    void OnRep_ClientDebugString(); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    void OnRep_ActivateAbilities(); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    void NetMulticast_InvokeGameplayCuesExecuted_WithParams(struct FGameplayTagContainer GameplayCueTags, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    void NetMulticast_InvokeGameplayCuesExecuted(struct FGameplayTagContainer GameplayCueTags, struct FPredictionKey PredictionKey, struct FGameplayEffectContextHandle EffectContext); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    void NetMulticast_InvokeGameplayCuesAddedAndWhileActive_WithParams(struct FGameplayTagContainer GameplayCueTags, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    void NetMulticast_InvokeGameplayCueExecuted_WithParams(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    void NetMulticast_InvokeGameplayCueExecuted_FromSpec(struct FGameplayEffectSpecForRPC Spec, struct FPredictionKey PredictionKey); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    void NetMulticast_InvokeGameplayCueExecuted(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayEffectContextHandle EffectContext); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    void NetMulticast_InvokeGameplayCueAddedAndWhileActive_WithParams(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    void NetMulticast_InvokeGameplayCueAddedAndWhileActive_FromSpec(struct FGameplayEffectSpecForRPC Spec, struct FPredictionKey PredictionKey); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    void NetMulticast_InvokeGameplayCueAdded_WithParams(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayCueParameters Parameters); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    void NetMulticast_InvokeGameplayCueAdded(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayEffectContextHandle EffectContext); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    struct FGameplayEffectSpecHandle MakeOutgoingSpec(class UGameplayEffect* GameplayEffectClass, float Level, struct FGameplayEffectContextHandle Context); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    struct FGameplayEffectContextHandle MakeEffectContext(); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    void K2_InitStats(class UAttributeSet* Attributes, class UDataTable* DataTable); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    bool IsGameplayCueActive(struct FGameplayTag GameplayCueTag); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    bool GetUserAbilityActivationInhibited(); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x7fe1]; // 0x7fe1
	    float GetGameplayEffectMagnitude(struct FActiveGameplayEffectHandle Handle, struct FGameplayAttribute Attribute); // 0x0 Size: 0x7fe1
	    char UnknownData63[0x7fe1]; // 0x7fe1
	    int GetGameplayEffectCount(class UGameplayEffect* SourceGameplayEffect, class UAbilitySystemComponent* OptionalInstigatorFilterComponent, bool bEnforceOnGoingCheck); // 0x0 Size: 0x7fe1
	    char UnknownData64[0x7fe1]; // 0x7fe1
	    TArray<struct FActiveGameplayEffectHandle> GetActiveEffects(struct FGameplayEffectQuery Query); // 0x0 Size: 0x7fe1
	    char UnknownData65[0x7fe1]; // 0x7fe1
	    void ClientTryActivateAbility(struct FGameplayAbilitySpecHandle AbilityToActivate); // 0x0 Size: 0x7fe1
	    char UnknownData66[0x7fe1]; // 0x7fe1
	    void ClientSetReplicatedEvent(char EventType, struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey); // 0x0 Size: 0x7fe1
	    char UnknownData67[0x7fe1]; // 0x7fe1
	    void ClientPrintDebug_Response(TArray<struct FString> Strings, int GameFlags); // 0x0 Size: 0x7fe1
	    char UnknownData68[0x7fe1]; // 0x7fe1
	    void ClientEndAbility(struct FGameplayAbilitySpecHandle AbilityToEnd, struct FGameplayAbilityActivationInfo ActivationInfo); // 0x0 Size: 0x7fe1
	    char UnknownData69[0x7fe1]; // 0x7fe1
	    void ClientCancelAbility(struct FGameplayAbilitySpecHandle AbilityToCancel, struct FGameplayAbilityActivationInfo ActivationInfo); // 0x0 Size: 0x7fe1
	    char UnknownData70[0x7fe1]; // 0x7fe1
	    void ClientActivateAbilitySucceedWithEventData(struct FGameplayAbilitySpecHandle AbilityToActivate, struct FPredictionKey PredictionKey, struct FGameplayEventData TriggerEventData); // 0x0 Size: 0x7fe1
	    char UnknownData71[0x7fe1]; // 0x7fe1
	    void ClientActivateAbilitySucceed(struct FGameplayAbilitySpecHandle AbilityToActivate, struct FPredictionKey PredictionKey); // 0x0 Size: 0x7fe1
	    char UnknownData72[0x7fe1]; // 0x7fe1
	    void ClientActivateAbilityFailed(struct FGameplayAbilitySpecHandle AbilityToActivate, int16_t PredictionKey); // 0x0 Size: 0x7fe1
	    char UnknownData73[0x7fe1]; // 0x7fe1
	    struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectToTarget(class UGameplayEffect* GameplayEffectClass, class UAbilitySystemComponent* Target, float Level, struct FGameplayEffectContextHandle Context); // 0x0 Size: 0x7fe1
	    char UnknownData74[0x7fe1]; // 0x7fe1
	    struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectToSelf(class UGameplayEffect* GameplayEffectClass, float Level, struct FGameplayEffectContextHandle EffectContext); // 0x0 Size: 0x7fe1
	    char UnknownData75[0x7fe1]; // 0x7fe1
	    struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectSpecToTarget(struct FGameplayEffectSpecHandle SpecHandle, class UAbilitySystemComponent* Target); // 0x0 Size: 0x7fe1
	    char UnknownData76[0x7fe1]; // 0x7fe1
	    struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectSpecToSelf(struct FGameplayEffectSpecHandle SpecHandle); // 0x0 Size: 0x7fe1
	    char UnknownData77[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ AbilityConfirmOrCancel__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData78[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ AbilityAbilityKey__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData79[0x-6e51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemComponent");
			return (class UClass*)ptr;
		};

};

class AAbilitySystemDebugHUD : public AHUD
{
	public:
	    char UnknownData0[0x420];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemDebugHUD");
			return (class UClass*)ptr;
		};

};

class UAbilitySystemGlobals : public UObject
{
	public:
	    struct FSoftClassPath AbilitySystemGlobalsClassName; // 0x28 Size: 0x18
	    char UnknownData0[0x28]; // 0x40
	    struct FGameplayTag ActivateFailIsDeadTag; // 0x68 Size: 0x8
	    FName ActivateFailIsDeadName; // 0x70 Size: 0x8
	    struct FGameplayTag ActivateFailCooldownTag; // 0x78 Size: 0x8
	    FName ActivateFailCooldownName; // 0x80 Size: 0x8
	    struct FGameplayTag ActivateFailCostTag; // 0x88 Size: 0x8
	    FName ActivateFailCostName; // 0x90 Size: 0x8
	    struct FGameplayTag ActivateFailTagsBlockedTag; // 0x98 Size: 0x8
	    FName ActivateFailTagsBlockedName; // 0xa0 Size: 0x8
	    struct FGameplayTag ActivateFailTagsMissingTag; // 0xa8 Size: 0x8
	    FName ActivateFailTagsMissingName; // 0xb0 Size: 0x8
	    struct FGameplayTag ActivateFailNetworkingTag; // 0xb8 Size: 0x8
	    FName ActivateFailNetworkingName; // 0xc0 Size: 0x8
	    int MinimalReplicationTagCountBits; // 0xc8 Size: 0x4
	    bool bAllowGameplayModEvaluationChannels; // 0xcc Size: 0x1
	    EGameplayModEvaluationChannel DefaultGameplayModEvaluationChannel; // 0xcd Size: 0x1
	    char UnknownData1[0x2]; // 0xce
	    FName GameplayModEvaluationChannelAliases; // 0xd0 Size: 0x8
	    char UnknownData2[0x48]; // 0xd8
	    struct FSoftObjectPath GlobalCurveTableName; // 0x120 Size: 0x18
	    class UCurveTable* GlobalCurveTable; // 0x138 Size: 0x8
	    struct FSoftObjectPath GlobalAttributeMetaDataTableName; // 0x140 Size: 0x18
	    class UDataTable* GlobalAttributeMetaDataTable; // 0x158 Size: 0x8
	    struct FSoftObjectPath GlobalAttributeSetDefaultsTableName; // 0x160 Size: 0x18
	    TArray<struct FSoftObjectPath> GlobalAttributeSetDefaultsTableNames; // 0x178 Size: 0x10
	    TArray<class UCurveTable*> GlobalAttributeDefaultsTables; // 0x188 Size: 0x10
	    struct FSoftObjectPath GlobalGameplayCueManagerClass; // 0x198 Size: 0x18
	    struct FSoftObjectPath GlobalGameplayCueManagerName; // 0x1b0 Size: 0x18
	    TArray<struct FString> GameplayCueNotifyPaths; // 0x1c8 Size: 0x10
	    struct FSoftObjectPath GameplayTagResponseTableName; // 0x1d8 Size: 0x18
	    class UGameplayTagReponseTable* GameplayTagResponseTable; // 0x1f0 Size: 0x8
	    bool PredictTargetGameplayEffects; // 0x1f8 Size: 0x1
	    char UnknownData3[0x7]; // 0x1f9
	    class UGameplayCueManager* GlobalGameplayCueManager; // 0x200 Size: 0x8
	    char UnknownData4[0x208]; // 0x208
	    void ToggleIgnoreAbilitySystemCosts(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ToggleIgnoreAbilitySystemCooldowns(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7d99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemGlobals");
			return (class UClass*)ptr;
		};

};

class UAbilitySystemInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemInterface");
			return (class UClass*)ptr;
		};

};

class UAbilitySystemReplicationProxyInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemReplicationProxyInterface");
			return (class UClass*)ptr;
		};

};

class UAttributeSet : public UObject
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AttributeSet");
			return (class UClass*)ptr;
		};

};

class UAbilitySystemTestAttributeSet : public UAttributeSet
{
	public:
	    float MaxHealth; // 0x30 Size: 0x4
	    float Health; // 0x34 Size: 0x4
	    float Mana; // 0x38 Size: 0x4
	    float MaxMana; // 0x3c Size: 0x4
	    float Damage; // 0x40 Size: 0x4
	    float SpellDamage; // 0x44 Size: 0x4
	    float PhysicalDamage; // 0x48 Size: 0x4
	    float CritChance; // 0x4c Size: 0x4
	    float CritMultiplier; // 0x50 Size: 0x4
	    float ArmorDamageReduction; // 0x54 Size: 0x4
	    float DodgeChance; // 0x58 Size: 0x4
	    float LifeSteal; // 0x5c Size: 0x4
	    float Strength; // 0x60 Size: 0x4
	    float StackingAttribute1; // 0x64 Size: 0x4
	    float StackingAttribute2; // 0x68 Size: 0x4
	    float NoStackAttribute; // 0x6c Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemTestAttributeSet");
			return (class UClass*)ptr;
		};

};

class AAbilitySystemTestPawn : public ADefaultPawn
{
	public:
	    char UnknownData0[0x18];
	    class UAbilitySystemComponent* AbilitySystemComponent; // 0x3d0 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilitySystemTestPawn");
			return (class UClass*)ptr;
		};

};

class UAbilityTask : public UGameplayTask
{
	public:
	    class UGameplayAbility* Ability; // 0x68 Size: 0x8
	    class UAbilitySystemComponent* AbilitySystemComponent; // 0x70 Size: 0x8
	    char UnknownData0[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_ApplyRootMotion_Base : public UAbilityTask
{
	public:
	    FName ForceName; // 0x80 Size: 0x8
	    ERootMotionFinishVelocityMode FinishVelocityMode; // 0x88 Size: 0x1
	    char UnknownData0[0x3]; // 0x89
	    struct FVector FinishSetVelocity; // 0x8c Size: 0xc
	    float FinishClampVelocity; // 0x98 Size: 0x4
	    char UnknownData1[0x4]; // 0x9c
	    class UCharacterMovementComponent* MovementComponent; // 0xa0 Size: 0x8
	    char UnknownData2[0x10];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_ApplyRootMotion_Base");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_ApplyRootMotionConstantForce : public UAbilityTask_ApplyRootMotion_Base
{
	public:
	    MulticastDelegateProperty OnFinish; // 0xb8 Size: 0x10
	    struct FVector WorldDirection; // 0xc8 Size: 0xc
	    float Strength; // 0xd4 Size: 0x4
	    float Duration; // 0xd8 Size: 0x4
	    bool bIsAdditive; // 0xdc Size: 0x1
	    char UnknownData0[0x3]; // 0xdd
	    class UCurveFloat* StrengthOverTime; // 0xe0 Size: 0x8
	    char UnknownData1[0xe8]; // 0xe8
	    static class UAbilityTask_ApplyRootMotionConstantForce* ApplyRootMotionConstantForce(class UGameplayAbility* OwningAbility, FName TaskInstanceName, struct FVector WorldDirection, float Strength, float Duration, bool bIsAdditive, class UCurveFloat* StrengthOverTime, ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7ef9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_ApplyRootMotionConstantForce");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_ApplyRootMotionJumpForce : public UAbilityTask_ApplyRootMotion_Base
{
	public:
	    MulticastDelegateProperty OnFinish; // 0xb8 Size: 0x10
	    MulticastDelegateProperty OnLanded; // 0xc8 Size: 0x10
	    struct FRotator Rotation; // 0xd8 Size: 0xc
	    float Distance; // 0xe4 Size: 0x4
	    float Height; // 0xe8 Size: 0x4
	    float Duration; // 0xec Size: 0x4
	    float MinimumLandedTriggerTime; // 0xf0 Size: 0x4
	    bool bFinishOnLanded; // 0xf4 Size: 0x1
	    char UnknownData0[0x3]; // 0xf5
	    class UCurveVector* PathOffsetCurve; // 0xf8 Size: 0x8
	    class UCurveFloat* TimeMappingCurve; // 0x100 Size: 0x8
	    char UnknownData1[0x108]; // 0x108
	    void OnLandedCallback(struct FHitResult Hit); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void Finish(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static class UAbilityTask_ApplyRootMotionJumpForce* ApplyRootMotionJumpForce(class UGameplayAbility* OwningAbility, FName TaskInstanceName, struct FRotator Rotation, float Distance, float Height, float Duration, float MinimumLandedTriggerTime, bool bFinishOnLanded, ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish, class UCurveVector* PathOffsetCurve, class UCurveFloat* TimeMappingCurve); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7ed1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_ApplyRootMotionJumpForce");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_ApplyRootMotionMoveToActorForce : public UAbilityTask_ApplyRootMotion_Base
{
	public:
	    MulticastDelegateProperty OnFinished; // 0xb8 Size: 0x10
	    char UnknownData0[0x8]; // 0xc8
	    struct FVector StartLocation; // 0xd0 Size: 0xc
	    struct FVector TargetLocation; // 0xdc Size: 0xc
	    class AActor* TargetActor; // 0xe8 Size: 0x8
	    struct FVector TargetLocationOffset; // 0xf0 Size: 0xc
	    ERootMotionMoveToActorTargetOffsetType OffsetAlignment; // 0xfc Size: 0x1
	    char UnknownData1[0x3]; // 0xfd
	    float Duration; // 0x100 Size: 0x4
	    bool bDisableDestinationReachedInterrupt; // 0x104 Size: 0x1
	    bool bSetNewMovementMode; // 0x105 Size: 0x1
	    char NewMovementMode; // 0x106 Size: 0x1
	    bool bRestrictSpeedToExpected; // 0x107 Size: 0x1
	    class UCurveVector* PathOffsetCurve; // 0x108 Size: 0x8
	    class UCurveFloat* TimeMappingCurve; // 0x110 Size: 0x8
	    class UCurveFloat* TargetLerpSpeedHorizontalCurve; // 0x118 Size: 0x8
	    class UCurveFloat* TargetLerpSpeedVerticalCurve; // 0x120 Size: 0x8
	    char UnknownData2[0x128]; // 0x128
	    void OnTargetActorSwapped(class AActor* OriginalTarget, class AActor* NewTarget); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnRep_TargetLocation(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static class UAbilityTask_ApplyRootMotionMoveToActorForce* ApplyRootMotionMoveToTargetDataActorForce(class UGameplayAbility* OwningAbility, FName TaskInstanceName, struct FGameplayAbilityTargetDataHandle TargetDataHandle, int TargetDataIndex, int TargetActorIndex, struct FVector TargetLocationOffset, ERootMotionMoveToActorTargetOffsetType OffsetAlignment, float Duration, class UCurveFloat* TargetLerpSpeedHorizontal, class UCurveFloat* TargetLerpSpeedVertical, bool bSetNewMovementMode, char MovementMode, bool bRestrictSpeedToExpected, class UCurveVector* PathOffsetCurve, class UCurveFloat* TimeMappingCurve, ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish, bool bDisableDestinationReachedInterrupt); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static class UAbilityTask_ApplyRootMotionMoveToActorForce* ApplyRootMotionMoveToActorForce(class UGameplayAbility* OwningAbility, FName TaskInstanceName, class AActor* TargetActor, struct FVector TargetLocationOffset, ERootMotionMoveToActorTargetOffsetType OffsetAlignment, float Duration, class UCurveFloat* TargetLerpSpeedHorizontal, class UCurveFloat* TargetLerpSpeedVertical, bool bSetNewMovementMode, char MovementMode, bool bRestrictSpeedToExpected, class UCurveVector* PathOffsetCurve, class UCurveFloat* TimeMappingCurve, ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish, bool bDisableDestinationReachedInterrupt); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7eb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_ApplyRootMotionMoveToForce : public UAbilityTask_ApplyRootMotion_Base
{
	public:
	    MulticastDelegateProperty OnTimedOut; // 0xb8 Size: 0x10
	    MulticastDelegateProperty OnTimedOutAndDestinationReached; // 0xc8 Size: 0x10
	    struct FVector StartLocation; // 0xd8 Size: 0xc
	    struct FVector TargetLocation; // 0xe4 Size: 0xc
	    float Duration; // 0xf0 Size: 0x4
	    bool bSetNewMovementMode; // 0xf4 Size: 0x1
	    char NewMovementMode; // 0xf5 Size: 0x1
	    bool bRestrictSpeedToExpected; // 0xf6 Size: 0x1
	    char UnknownData0[0x1]; // 0xf7
	    class UCurveVector* PathOffsetCurve; // 0xf8 Size: 0x8
	    char UnknownData1[0x100]; // 0x100
	    static class UAbilityTask_ApplyRootMotionMoveToForce* ApplyRootMotionMoveToForce(class UGameplayAbility* OwningAbility, FName TaskInstanceName, struct FVector TargetLocation, float Duration, bool bSetNewMovementMode, char MovementMode, bool bRestrictSpeedToExpected, class UCurveVector* PathOffsetCurve, ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7ed9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_ApplyRootMotionMoveToForce");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_ApplyRootMotionRadialForce : public UAbilityTask_ApplyRootMotion_Base
{
	public:
	    MulticastDelegateProperty OnFinish; // 0xb8 Size: 0x10
	    struct FVector Location; // 0xc8 Size: 0xc
	    char UnknownData0[0x4]; // 0xd4
	    class AActor* LocationActor; // 0xd8 Size: 0x8
	    float Strength; // 0xe0 Size: 0x4
	    float Duration; // 0xe4 Size: 0x4
	    float Radius; // 0xe8 Size: 0x4
	    bool bIsPush; // 0xec Size: 0x1
	    bool bIsAdditive; // 0xed Size: 0x1
	    bool bNoZForce; // 0xee Size: 0x1
	    char UnknownData1[0x1]; // 0xef
	    class UCurveFloat* StrengthDistanceFalloff; // 0xf0 Size: 0x8
	    class UCurveFloat* StrengthOverTime; // 0xf8 Size: 0x8
	    bool bUseFixedWorldDirection; // 0x100 Size: 0x1
	    char UnknownData2[0x3]; // 0x101
	    struct FRotator FixedWorldDirection; // 0x104 Size: 0xc
	    char UnknownData3[0x110]; // 0x110
	    static class UAbilityTask_ApplyRootMotionRadialForce* ApplyRootMotionRadialForce(class UGameplayAbility* OwningAbility, FName TaskInstanceName, struct FVector Location, class AActor* LocationActor, float Strength, float Duration, float Radius, bool bIsPush, bool bIsAdditive, bool bNoZForce, class UCurveFloat* StrengthDistanceFalloff, class UCurveFloat* StrengthOverTime, bool bUseFixedWorldDirection, struct FRotator FixedWorldDirection, ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7ed1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_ApplyRootMotionRadialForce");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_MoveToLocation : public UAbilityTask
{
	public:
	    MulticastDelegateProperty OnTargetLocationReached; // 0x80 Size: 0x10
	    char UnknownData0[0x4]; // 0x90
	    struct FVector StartLocation; // 0x94 Size: 0xc
	    struct FVector TargetLocation; // 0xa0 Size: 0xc
	    float DurationOfMovement; // 0xac Size: 0x4
	    char UnknownData1[0x8]; // 0xb0
	    class UCurveFloat* LerpCurve; // 0xb8 Size: 0x8
	    class UCurveVector* LerpCurveVector; // 0xc0 Size: 0x8
	    char UnknownData2[0xc8]; // 0xc8
	    static class UAbilityTask_MoveToLocation* MoveToLocation(class UGameplayAbility* OwningAbility, FName TaskInstanceName, struct FVector Location, float Duration, class UCurveFloat* OptionalInterpolationCurve, class UCurveVector* OptionalVectorInterpolationCurve); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7f19];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_MoveToLocation");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_NetworkSyncPoint : public UAbilityTask
{
	public:
	    MulticastDelegateProperty OnSync; // 0x80 Size: 0x10
	    char UnknownData0[0x90]; // 0x90
	    static class UAbilityTask_NetworkSyncPoint* WaitNetSync(class UGameplayAbility* OwningAbility, EAbilityTaskNetSyncType SyncType); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnSignalCallback(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f49];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_NetworkSyncPoint");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_PlayMontageAndWait : public UAbilityTask
{
	public:
	    MulticastDelegateProperty OnCompleted; // 0x80 Size: 0x10
	    MulticastDelegateProperty OnBlendOut; // 0x90 Size: 0x10
	    MulticastDelegateProperty OnInterrupted; // 0xa0 Size: 0x10
	    MulticastDelegateProperty OnCancelled; // 0xb0 Size: 0x10
	    char UnknownData0[0x28]; // 0xc0
	    class UAnimMontage* MontageToPlay; // 0xe8 Size: 0x8
	    float Rate; // 0xf0 Size: 0x4
	    FName StartSection; // 0xf4 Size: 0x8
	    float AnimRootMotionTranslationScale; // 0xfc Size: 0x4
	    bool bStopWhenAbilityEnds; // 0x100 Size: 0x1
	    char UnknownData1[0x101]; // 0x101
	    void OnMontageInterrupted(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnMontageEnded(class UAnimMontage* Montage, bool bInterrupted); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnMontageBlendingOut(class UAnimMontage* Montage, bool bInterrupted); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static class UAbilityTask_PlayMontageAndWait* CreatePlayMontageAndWaitProxy(class UGameplayAbility* OwningAbility, FName TaskInstanceName, class UAnimMontage* MontageToPlay, float Rate, FName StartSection, bool bStopWhenAbilityEnds, float AnimRootMotionTranslationScale); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7ed9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_PlayMontageAndWait");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_Repeat : public UAbilityTask
{
	public:
	    MulticastDelegateProperty OnPerformAction; // 0x80 Size: 0x10
	    MulticastDelegateProperty OnFinished; // 0x90 Size: 0x10
	    char UnknownData0[0xa0]; // 0xa0
	    static class UAbilityTask_Repeat* RepeatAction(class UGameplayAbility* OwningAbility, float TimeBetweenActions, int TotalActionCount); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_Repeat");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_SpawnActor : public UAbilityTask
{
	public:
	    MulticastDelegateProperty Success; // 0x80 Size: 0x10
	    MulticastDelegateProperty DidNotSpawn; // 0x90 Size: 0x10
	    char UnknownData0[0xa0]; // 0xa0
	    static class UAbilityTask_SpawnActor* SpawnActor(class UGameplayAbility* OwningAbility, struct FGameplayAbilityTargetDataHandle TargetData, class AActor* Class); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void FinishSpawningActor(class UGameplayAbility* OwningAbility, struct FGameplayAbilityTargetDataHandle TargetData, class AActor* SpawnedActor); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool BeginSpawningActor(class UGameplayAbility* OwningAbility, struct FGameplayAbilityTargetDataHandle TargetData, class AActor* Class, class AActor* SpawnedActor); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7f21];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_SpawnActor");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_StartAbilityState : public UAbilityTask
{
	public:
	    MulticastDelegateProperty OnStateEnded; // 0x80 Size: 0x10
	    MulticastDelegateProperty OnStateInterrupted; // 0x90 Size: 0x10
	    char UnknownData0[0xa0]; // 0xa0
	    static class UAbilityTask_StartAbilityState* StartAbilityState(class UGameplayAbility* OwningAbility, FName StateName, bool bEndCurrentState); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_StartAbilityState");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_VisualizeTargeting : public UAbilityTask
{
	public:
	    MulticastDelegateProperty TimeElapsed; // 0x80 Size: 0x10
	    char UnknownData0[0x90]; // 0x90
	    static class UAbilityTask_VisualizeTargeting* VisualizeTargetingUsingActor(class UGameplayAbility* OwningAbility, class AGameplayAbilityTargetActor* TargetActor, FName TaskInstanceName, float Duration); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static class UAbilityTask_VisualizeTargeting* VisualizeTargeting(class UGameplayAbility* OwningAbility, class AGameplayAbilityTargetActor* Class, FName TaskInstanceName, float Duration); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void FinishSpawningActor(class UGameplayAbility* OwningAbility, class AGameplayAbilityTargetActor* SpawnedActor); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool BeginSpawningActor(class UGameplayAbility* OwningAbility, class AGameplayAbilityTargetActor* Class, class AGameplayAbilityTargetActor* SpawnedActor); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7f39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_VisualizeTargeting");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitAbilityActivate : public UAbilityTask
{
	public:
	    MulticastDelegateProperty OnActivate; // 0x80 Size: 0x10
	    char UnknownData0[0x90]; // 0x90
	    static class UAbilityTask_WaitAbilityActivate* WaitForAbilityActivateWithTagRequirements(class UGameplayAbility* OwningAbility, struct FGameplayTagRequirements TagRequirements, bool IncludeTriggeredAbilities, bool TriggerOnce); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static class UAbilityTask_WaitAbilityActivate* WaitForAbilityActivate_Query(class UGameplayAbility* OwningAbility, struct FGameplayTagQuery Query, bool IncludeTriggeredAbilities, bool TriggerOnce); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static class UAbilityTask_WaitAbilityActivate* WaitForAbilityActivate(class UGameplayAbility* OwningAbility, struct FGameplayTag WithTag, struct FGameplayTag WithoutTag, bool IncludeTriggeredAbilities, bool TriggerOnce); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnAbilityActivate(class UGameplayAbility* ActivatedAbility); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7ea9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitAbilityActivate");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitAbilityCommit : public UAbilityTask
{
	public:
	    MulticastDelegateProperty OnCommit; // 0x80 Size: 0x10
	    char UnknownData0[0x90]; // 0x90
	    static class UAbilityTask_WaitAbilityCommit* WaitForAbilityCommit_Query(class UGameplayAbility* OwningAbility, struct FGameplayTagQuery Query, bool TriggerOnce); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static class UAbilityTask_WaitAbilityCommit* WaitForAbilityCommit(class UGameplayAbility* OwningAbility, struct FGameplayTag WithTag, struct FGameplayTag WithoutTage, bool TriggerOnce); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnAbilityCommit(class UGameplayAbility* ActivatedAbility); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7ee9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitAbilityCommit");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitAttributeChange : public UAbilityTask
{
	public:
	    MulticastDelegateProperty OnChange; // 0x80 Size: 0x10
	    char UnknownData0[0x48]; // 0x90
	    class UAbilitySystemComponent* ExternalOwner; // 0xd8 Size: 0x8
	    char UnknownData1[0xe0]; // 0xe0
	    static class UAbilityTask_WaitAttributeChange* WaitForAttributeChangeWithComparison(class UGameplayAbility* OwningAbility, struct FGameplayAttribute InAttribute, struct FGameplayTag InWithTag, struct FGameplayTag InWithoutTag, char InComparisonType, float InComparisonValue, bool TriggerOnce, class AActor* OptionalExternalOwner); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static class UAbilityTask_WaitAttributeChange* WaitForAttributeChange(class UGameplayAbility* OwningAbility, struct FGameplayAttribute Attribute, struct FGameplayTag WithSrcTag, struct FGameplayTag WithoutSrcTag, bool TriggerOnce, class AActor* OptionalExternalOwner); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7f01];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitAttributeChange");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitAttributeChangeRatioThreshold : public UAbilityTask
{
	public:
	    MulticastDelegateProperty OnChange; // 0x80 Size: 0x10
	    char UnknownData0[0x78]; // 0x90
	    class UAbilitySystemComponent* ExternalOwner; // 0x108 Size: 0x8
	    char UnknownData1[0x110]; // 0x110
	    static class UAbilityTask_WaitAttributeChangeRatioThreshold* WaitForAttributeChangeRatioThreshold(class UGameplayAbility* OwningAbility, struct FGameplayAttribute AttributeNumerator, struct FGameplayAttribute AttributeDenominator, char ComparisonType, float ComparisonValue, bool bTriggerOnce, class AActor* OptionalExternalOwner); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7ed1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitAttributeChangeRatioThreshold");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitAttributeChangeThreshold : public UAbilityTask
{
	public:
	    MulticastDelegateProperty OnChange; // 0x80 Size: 0x10
	    char UnknownData0[0x40]; // 0x90
	    class UAbilitySystemComponent* ExternalOwner; // 0xd0 Size: 0x8
	    char UnknownData1[0xd8]; // 0xd8
	    static class UAbilityTask_WaitAttributeChangeThreshold* WaitForAttributeChangeThreshold(class UGameplayAbility* OwningAbility, struct FGameplayAttribute Attribute, char ComparisonType, float ComparisonValue, bool bTriggerOnce, class AActor* OptionalExternalOwner); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f09];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitAttributeChangeThreshold");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitCancel : public UAbilityTask
{
	public:
	    MulticastDelegateProperty OnCancel; // 0x80 Size: 0x10
	    char UnknownData0[0x90]; // 0x90
	    static class UAbilityTask_WaitCancel* WaitCancel(class UGameplayAbility* OwningAbility); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnLocalCancelCallback(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnCancelCallback(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7f49];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitCancel");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitConfirm : public UAbilityTask
{
	public:
	    MulticastDelegateProperty OnConfirm; // 0x80 Size: 0x10
	    char UnknownData0[0x90]; // 0x90
	    static class UAbilityTask_WaitConfirm* WaitConfirm(class UGameplayAbility* OwningAbility); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnConfirmCallback(class UGameplayAbility* InAbility); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitConfirm");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitConfirmCancel : public UAbilityTask
{
	public:
	    MulticastDelegateProperty OnConfirm; // 0x80 Size: 0x10
	    MulticastDelegateProperty OnCancel; // 0x90 Size: 0x10
	    char UnknownData0[0xa0]; // 0xa0
	    static class UAbilityTask_WaitConfirmCancel* WaitConfirmCancel(class UGameplayAbility* OwningAbility); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnLocalConfirmCallback(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnLocalCancelCallback(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnConfirmCallback(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnCancelCallback(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7f39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitConfirmCancel");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitDelay : public UAbilityTask
{
	public:
	    MulticastDelegateProperty OnFinish; // 0x80 Size: 0x10
	    char UnknownData0[0x90]; // 0x90
	    static class UAbilityTask_WaitDelay* WaitDelay(class UGameplayAbility* OwningAbility, float Time); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f49];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitDelay");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitGameplayEffectApplied : public UAbilityTask
{
	public:
	    char UnknownData0[0x128];
	    class UAbilitySystemComponent* ExternalOwner; // 0x1a8 Size: 0x8
	    char UnknownData1[0x1b0]; // 0x1b0
	    void OnApplyGameplayEffectCallback(class UAbilitySystemComponent* Target, struct FGameplayEffectSpec SpecApplied, struct FActiveGameplayEffectHandle ActiveHandle); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7e29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayEffectApplied");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitGameplayEffectApplied_Self : public UAbilityTask_WaitGameplayEffectApplied
{
	public:
	    MulticastDelegateProperty OnApplied; // 0x1b8 Size: 0x10
	    char UnknownData0[0x1c8]; // 0x1c8
	    static class UAbilityTask_WaitGameplayEffectApplied_Self* WaitGameplayEffectAppliedToSelf_Query(class UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle SourceFilter, struct FGameplayTagQuery SourceTagQuery, struct FGameplayTagQuery TargetTagQuery, bool TriggerOnce, class AActor* OptionalExternalOwner, bool ListenForPeriodicEffect); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static class UAbilityTask_WaitGameplayEffectApplied_Self* WaitGameplayEffectAppliedToSelf(class UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle SourceFilter, struct FGameplayTagRequirements SourceTagRequirements, struct FGameplayTagRequirements TargetTagRequirements, bool TriggerOnce, class AActor* OptionalExternalOwner, bool ListenForPeriodicEffect); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7e09];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Self");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitGameplayEffectApplied_Target : public UAbilityTask_WaitGameplayEffectApplied
{
	public:
	    MulticastDelegateProperty OnApplied; // 0x1b8 Size: 0x10
	    char UnknownData0[0x1c8]; // 0x1c8
	    static class UAbilityTask_WaitGameplayEffectApplied_Target* WaitGameplayEffectAppliedToTarget_Query(class UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle SourceFilter, struct FGameplayTagQuery SourceTagQuery, struct FGameplayTagQuery TargetTagQuery, bool TriggerOnce, class AActor* OptionalExternalOwner, bool ListenForPeriodicEffect); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static class UAbilityTask_WaitGameplayEffectApplied_Target* WaitGameplayEffectAppliedToTarget(class UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle TargetFilter, struct FGameplayTagRequirements SourceTagRequirements, struct FGameplayTagRequirements TargetTagRequirements, bool TriggerOnce, class AActor* OptionalExternalOwner, bool ListenForPeriodicEffects); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7e09];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Target");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitGameplayEffectBlockedImmunity : public UAbilityTask
{
	public:
	    MulticastDelegateProperty bLocked; // 0x80 Size: 0x10
	    char UnknownData0[0x88]; // 0x90
	    class UAbilitySystemComponent* ExternalOwner; // 0x118 Size: 0x8
	    char UnknownData1[0x120]; // 0x120
	    static class UAbilityTask_WaitGameplayEffectBlockedImmunity* WaitGameplayEffectBlockedByImmunity(class UGameplayAbility* OwningAbility, struct FGameplayTagRequirements SourceTagRequirements, struct FGameplayTagRequirements TargetTagRequirements, class AActor* OptionalExternalTarget, bool OnlyTriggerOnce); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7eb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayEffectBlockedImmunity");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitGameplayEffectRemoved : public UAbilityTask
{
	public:
	    MulticastDelegateProperty OnRemoved; // 0x80 Size: 0x10
	    MulticastDelegateProperty InvalidHandle; // 0x90 Size: 0x10
	    char UnknownData0[0xa0]; // 0xa0
	    static class UAbilityTask_WaitGameplayEffectRemoved* WaitForGameplayEffectRemoved(class UGameplayAbility* OwningAbility, struct FActiveGameplayEffectHandle Handle); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnGameplayEffectRemoved(struct FGameplayEffectRemovalInfo InGameplayEffectRemovalInfo); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f21];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayEffectRemoved");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitGameplayEffectStackChange : public UAbilityTask
{
	public:
	    MulticastDelegateProperty OnChange; // 0x80 Size: 0x10
	    MulticastDelegateProperty InvalidHandle; // 0x90 Size: 0x10
	    char UnknownData0[0xa0]; // 0xa0
	    static class UAbilityTask_WaitGameplayEffectStackChange* WaitForGameplayEffectStackChange(class UGameplayAbility* OwningAbility, struct FActiveGameplayEffectHandle Handle); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnGameplayEffectStackChange(struct FActiveGameplayEffectHandle Handle, int NewCount, int OldCount); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayEffectStackChange");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitGameplayEvent : public UAbilityTask
{
	public:
	    MulticastDelegateProperty EventReceived; // 0x80 Size: 0x10
	    char UnknownData0[0x8]; // 0x90
	    class UAbilitySystemComponent* OptionalExternalTarget; // 0x98 Size: 0x8
	    char UnknownData1[0xa0]; // 0xa0
	    static class UAbilityTask_WaitGameplayEvent* WaitGameplayEvent(class UGameplayAbility* OwningAbility, struct FGameplayTag EventTag, class AActor* OptionalExternalTarget, bool OnlyTriggerOnce, bool OnlyMatchExact); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f31];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayEvent");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitGameplayTag : public UAbilityTask
{
	public:
	    char UnknownData0[0x10];
	    class UAbilitySystemComponent* OptionalExternalTarget; // 0x90 Size: 0x8
	    char UnknownData1[0x98]; // 0x98
	    void GameplayTagCallback(struct FGameplayTag Tag, int NewCount); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayTag");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitGameplayTagAdded : public UAbilityTask_WaitGameplayTag
{
	public:
	    MulticastDelegateProperty Added; // 0xa8 Size: 0x10
	    char UnknownData0[0xb8]; // 0xb8
	    static class UAbilityTask_WaitGameplayTagAdded* WaitGameplayTagAdd(class UGameplayAbility* OwningAbility, struct FGameplayTag Tag, class AActor* InOptionalExternalTarget, bool OnlyTriggerOnce); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayTagAdded");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitGameplayTagRemoved : public UAbilityTask_WaitGameplayTag
{
	public:
	    MulticastDelegateProperty Removed; // 0xa8 Size: 0x10
	    char UnknownData0[0xb8]; // 0xb8
	    static class UAbilityTask_WaitGameplayTagRemoved* WaitGameplayTagRemove(class UGameplayAbility* OwningAbility, struct FGameplayTag Tag, class AActor* InOptionalExternalTarget, bool OnlyTriggerOnce); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitGameplayTagRemoved");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitInputPress : public UAbilityTask
{
	public:
	    MulticastDelegateProperty OnPress; // 0x80 Size: 0x10
	    char UnknownData0[0x90]; // 0x90
	    static class UAbilityTask_WaitInputPress* WaitInputPress(class UGameplayAbility* OwningAbility, bool bTestAlreadyPressed); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnPressCallback(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitInputPress");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitInputRelease : public UAbilityTask
{
	public:
	    MulticastDelegateProperty OnRelease; // 0x80 Size: 0x10
	    char UnknownData0[0x90]; // 0x90
	    static class UAbilityTask_WaitInputRelease* WaitInputRelease(class UGameplayAbility* OwningAbility, bool bTestAlreadyReleased); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnReleaseCallback(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitInputRelease");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitMovementModeChange : public UAbilityTask
{
	public:
	    MulticastDelegateProperty OnChange; // 0x80 Size: 0x10
	    char UnknownData0[0x90]; // 0x90
	    void OnMovementModeChange(class ACharacter* Character, char PrevMovementMode, char PreviousCustomMode); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static class UAbilityTask_WaitMovementModeChange* CreateWaitMovementModeChange(class UGameplayAbility* OwningAbility, char NewMode); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitMovementModeChange");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitOverlap : public UAbilityTask
{
	public:
	    MulticastDelegateProperty OnOverlap; // 0x80 Size: 0x10
	    char UnknownData0[0x90]; // 0x90
	    static class UAbilityTask_WaitOverlap* WaitForOverlap(class UGameplayAbility* OwningAbility); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnHitCallback(class UPrimitiveComponent* HitComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult Hit); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitOverlap");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitTargetData : public UAbilityTask
{
	public:
	    MulticastDelegateProperty ValidData; // 0x80 Size: 0x10
	    MulticastDelegateProperty Cancelled; // 0x90 Size: 0x10
	    class AGameplayAbilityTargetActor* TargetClass; // 0xa0 Size: 0x8
	    class AGameplayAbilityTargetActor* TargetActor; // 0xa8 Size: 0x8
	    char UnknownData0[0xb0]; // 0xb0
	    static class UAbilityTask_WaitTargetData* WaitTargetDataUsingActor(class UGameplayAbility* OwningAbility, FName TaskInstanceName, char ConfirmationType, class AGameplayAbilityTargetActor* TargetActor); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static class UAbilityTask_WaitTargetData* WaitTargetData(class UGameplayAbility* OwningAbility, FName TaskInstanceName, char ConfirmationType, class AGameplayAbilityTargetActor* Class); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnTargetDataReplicatedCancelledCallback(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnTargetDataReplicatedCallback(struct FGameplayAbilityTargetDataHandle Data, struct FGameplayTag ActivationTag); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnTargetDataReadyCallback(struct FGameplayAbilityTargetDataHandle Data); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnTargetDataCancelledCallback(struct FGameplayAbilityTargetDataHandle Data); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void FinishSpawningActor(class UGameplayAbility* OwningAbility, class AGameplayAbilityTargetActor* SpawnedActor); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool BeginSpawningActor(class UGameplayAbility* OwningAbility, class AGameplayAbilityTargetActor* Class, class AGameplayAbilityTargetActor* SpawnedActor); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7f21];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitTargetData");
			return (class UClass*)ptr;
		};

};

class UAbilityTask_WaitVelocityChange : public UAbilityTask
{
	public:
	    MulticastDelegateProperty OnVelocityChage; // 0x80 Size: 0x10
	    class UMovementComponent* CachedMovementComponent; // 0x90 Size: 0x8
	    char UnknownData0[0x98]; // 0x98
	    static class UAbilityTask_WaitVelocityChange* CreateWaitVelocityChange(class UGameplayAbility* OwningAbility, struct FVector Direction, float MinimumMagnitude); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.AbilityTask_WaitVelocityChange");
			return (class UClass*)ptr;
		};

};

class UGameplayAbility : public UObject
{
	public:
	    char UnknownData0[0x80];
	    struct FGameplayTagContainer AbilityTags; // 0xa8 Size: 0x20
	    bool bReplicateInputDirectly; // 0xc8 Size: 0x1
	    bool RemoteInstanceEnded; // 0xc9 Size: 0x1
	    char UnknownData1[0x4]; // 0xca
	    char ReplicationPolicy; // 0xce Size: 0x1
	    char InstancingPolicy; // 0xcf Size: 0x1
	    bool bServerRespectsRemoteAbilityCancellation; // 0xd0 Size: 0x1
	    bool bRetriggerInstancedAbility; // 0xd1 Size: 0x1
	    char UnknownData2[0x6]; // 0xd2
	    struct FGameplayAbilityActivationInfo CurrentActivationInfo; // 0xd8 Size: 0x20
	    struct FGameplayEventData CurrentEventData; // 0xf8 Size: 0xa8
	    char NetExecutionPolicy; // 0x1a0 Size: 0x1
	    char UnknownData3[0x7]; // 0x1a1
	    class UGameplayEffect* CostGameplayEffectClass; // 0x1a8 Size: 0x8
	    TArray<struct FAbilityTriggerData> AbilityTriggers; // 0x1b0 Size: 0x10
	    class UGameplayEffect* CooldownGameplayEffectClass; // 0x1c0 Size: 0x8
	    struct FGameplayTagQuery CancelAbilitiesMatchingTagQuery; // 0x1c8 Size: 0x48
	    struct FGameplayTagContainer CancelAbilitiesWithTag; // 0x210 Size: 0x20
	    struct FGameplayTagContainer BlockAbilitiesWithTag; // 0x230 Size: 0x20
	    struct FGameplayTagContainer ActivationOwnedTags; // 0x250 Size: 0x20
	    struct FGameplayTagContainer ActivationRequiredTags; // 0x270 Size: 0x20
	    struct FGameplayTagContainer ActivationBlockedTags; // 0x290 Size: 0x20
	    struct FGameplayTagContainer SourceRequiredTags; // 0x2b0 Size: 0x20
	    struct FGameplayTagContainer SourceBlockedTags; // 0x2d0 Size: 0x20
	    struct FGameplayTagContainer TargetRequiredTags; // 0x2f0 Size: 0x20
	    struct FGameplayTagContainer TargetBlockedTags; // 0x310 Size: 0x20
	    char UnknownData4[0x20]; // 0x330
	    TArray<class UGameplayTask*> ActiveTasks; // 0x350 Size: 0x10
	    char UnknownData5[0x10]; // 0x360
	    class UAnimMontage* CurrentMontage; // 0x370 Size: 0x8
	    bool bIsActive; // 0x3d8 Size: 0x1
	    bool bIsCancelable; // 0x3d9 Size: 0x1
	    bool bIsBlockingOtherAbilities; // 0x3da Size: 0x1
	    bool bMarkPendingKillOnAbilityEnd; // 0x3f0 Size: 0x1
	    char UnknownData6[0x37c]; // 0x37c
	    void SetShouldBlockOtherAbilities(bool bShouldBlockAbilities); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetCanBeCanceled(bool bCanBeCanceled); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SendGameplayEvent(struct FGameplayTag EventTag, struct FGameplayEventData Payload); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void RemoveGrantedByEffect(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void MontageStop(float OverrideBlendOutTime); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void MontageSetNextSectionName(FName FromSectionName, FName ToSectionName); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void MontageJumpToSection(FName SectionName); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    struct FGameplayAbilityTargetingLocationInfo MakeTargetLocationInfoFromOwnerSkeletalMeshComponent(FName SocketName); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    struct FGameplayAbilityTargetingLocationInfo MakeTargetLocationInfoFromOwnerActor(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    struct FGameplayEffectSpecHandle MakeOutgoingGameplayEffectSpec(class UGameplayEffect* GameplayEffectClass, float Level); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    bool K2_ShouldAbilityRespondToEvent(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayEventData Payload); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void K2_RemoveGameplayCue(struct FGameplayTag GameplayCueTag); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void K2_OnEndAbility(bool bWasCancelled); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void K2_ExecuteGameplayCueWithParams(struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters GameplayCueParameters); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void K2_ExecuteGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayEffectContextHandle Context); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void K2_EndAbility(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void K2_CommitExecute(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    bool K2_CommitAbilityCost(bool BroadcastCommitEvent); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    bool K2_CommitAbilityCooldown(bool BroadcastCommitEvent, bool ForceCooldown); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    bool K2_CommitAbility(); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    bool K2_CheckAbilityCost(); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    bool K2_CheckAbilityCooldown(); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void K2_CancelAbility(); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    bool K2_CanActivateAbility(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayTagContainer RelevantTags); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    TArray<struct FActiveGameplayEffectHandle> K2_ApplyGameplayEffectSpecToTarget(struct FGameplayEffectSpecHandle EffectSpecHandle, struct FGameplayAbilityTargetDataHandle TargetData); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    struct FActiveGameplayEffectHandle K2_ApplyGameplayEffectSpecToOwner(struct FGameplayEffectSpecHandle EffectSpecHandle); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    void K2_AddGameplayCueWithParams(struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters GameplayCueParameter, bool bRemoveOnAbilityEnd); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    void K2_AddGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayEffectContextHandle Context, bool bRemoveOnAbilityEnd); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    void K2_ActivateAbilityFromEvent(struct FGameplayEventData EventData); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    void K2_ActivateAbility(); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    void InvalidateClientPredictionKey(); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    class USkeletalMeshComponent* GetOwningComponentFromActorInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    class AActor* GetOwningActorFromActorInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    struct FGameplayEffectContextHandle GetGrantedByEffectContext(); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    class UObject* GetCurrentSourceObject(); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    class UAnimMontage* GetCurrentMontage(); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    float GetCooldownTimeRemaining(); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    struct FGameplayEffectContextHandle GetContextFromOwner(struct FGameplayAbilityTargetDataHandle OptionalTargetData); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    class AActor* GetAvatarActorFromActorInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    struct FGameplayAbilityActorInfo GetActorInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    class UAbilitySystemComponent* GetAbilitySystemComponentFromActorInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    int GetAbilityLevel(); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    void EndTaskByInstanceName(FName InstanceName); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    void EndAbilityState(FName OptionalStateNameToEnd); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    void ConfirmTaskByInstanceName(FName InstanceName, bool bEndTask); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    void CancelTaskByInstanceName(FName InstanceName); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    void BP_RemoveGameplayEffectFromOwnerWithHandle(struct FActiveGameplayEffectHandle Handle, int StacksToRemove); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    void BP_RemoveGameplayEffectFromOwnerWithGrantedTags(struct FGameplayTagContainer WithGrantedTags, int StacksToRemove); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    void BP_RemoveGameplayEffectFromOwnerWithAssetTags(struct FGameplayTagContainer WithAssetTags, int StacksToRemove); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    TArray<struct FActiveGameplayEffectHandle> BP_ApplyGameplayEffectToTarget(struct FGameplayAbilityTargetDataHandle TargetData, class UGameplayEffect* GameplayEffectClass, int GameplayEffectLevel, int Stacks); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectToOwner(class UGameplayEffect* GameplayEffectClass, int GameplayEffectLevel, int Stacks); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x-7be9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility");
			return (class UClass*)ptr;
		};

};

class UGameplayAbility_CharacterJump : public UGameplayAbility
{
	public:
	    char UnknownData0[0x3f8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility_CharacterJump");
			return (class UClass*)ptr;
		};

};

class UGameplayAbility_Montage : public UGameplayAbility
{
	public:
	    class UAnimMontage* MontageToPlay; // 0x3f8 Size: 0x8
	    float PlayRate; // 0x400 Size: 0x4
	    FName SectionName; // 0x404 Size: 0x8
	    char UnknownData0[0x4]; // 0x40c
	    TArray<class UGameplayEffect*> GameplayEffectClassesWhileAnimating; // 0x410 Size: 0x10
	    TArray<class UGameplayEffect*> GameplayEffectsWhileAnimating; // 0x420 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayAbility_Montage");
			return (class UClass*)ptr;
		};

};

class UGameplayAbilityBlueprint : public UBlueprint
{
	public:
	    char UnknownData0[0xe0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayAbilityBlueprint");
			return (class UClass*)ptr;
		};

};

class UGameplayAbilitySet : public UDataAsset
{
	public:
	    TArray<struct FGameplayAbilityBindInfo> Abilities; // 0x30 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayAbilitySet");
			return (class UClass*)ptr;
		};

};

class AGameplayAbilityTargetActor : public AActor
{
	public:
	    bool ShouldProduceTargetDataOnServer; // 0x330 Size: 0x1
	    char UnknownData0[0xf]; // 0x331
	    struct FGameplayAbilityTargetingLocationInfo StartLocation; // 0x340 Size: 0x70
	    char UnknownData1[0x30]; // 0x3b0
	    class APlayerController* MasterPC; // 0x3e0 Size: 0x8
	    class UGameplayAbility* OwningAbility; // 0x3e8 Size: 0x8
	    bool bDestroyOnConfirmation; // 0x3f0 Size: 0x1
	    char UnknownData2[0x7]; // 0x3f1
	    class AActor* SourceActor; // 0x3f8 Size: 0x8
	    struct FWorldReticleParameters ReticleParams; // 0x400 Size: 0xc
	    char UnknownData3[0x4]; // 0x40c
	    class AGameplayAbilityWorldReticle* ReticleClass; // 0x410 Size: 0x8
	    struct FGameplayTargetDataFilterHandle Filter; // 0x418 Size: 0x10
	    bool bDebug; // 0x428 Size: 0x1
	    char UnknownData4[0x17]; // 0x429
	    class UAbilitySystemComponent* GenericDelegateBoundASC; // 0x440 Size: 0x8
	    char UnknownData5[0x448]; // 0x448
	    void ConfirmTargeting(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void CancelTargeting(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7b91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayAbilityTargetActor");
			return (class UClass*)ptr;
		};

};

class AGameplayAbilityTargetActor_Trace : public AGameplayAbilityTargetActor
{
	public:
	    float MaxRange; // 0x448 Size: 0x4
	    struct FCollisionProfileName TraceProfile; // 0x44c Size: 0x8
	    bool bTraceAffectsAimPitch; // 0x454 Size: 0x1
	    char UnknownData0[0xb];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayAbilityTargetActor_Trace");
			return (class UClass*)ptr;
		};

};

class AGameplayAbilityTargetActor_GroundTrace : public AGameplayAbilityTargetActor_Trace
{
	public:
	    float CollisionRadius; // 0x460 Size: 0x4
	    float CollisionHeight; // 0x464 Size: 0x4
	    char UnknownData0[0x18];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayAbilityTargetActor_GroundTrace");
			return (class UClass*)ptr;
		};

};

class AGameplayAbilityTargetActor_ActorPlacement : public AGameplayAbilityTargetActor_GroundTrace
{
	public:
	    class UObject* PlacedActorClass; // 0x480 Size: 0x8
	    class UMaterialInterface* PlacedActorMaterial; // 0x488 Size: 0x8
	    char UnknownData0[0x10];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayAbilityTargetActor_ActorPlacement");
			return (class UClass*)ptr;
		};

};

class AGameplayAbilityTargetActor_Radius : public AGameplayAbilityTargetActor
{
	public:
	    float Radius; // 0x448 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayAbilityTargetActor_Radius");
			return (class UClass*)ptr;
		};

};

class AGameplayAbilityTargetActor_SingleLineTrace : public AGameplayAbilityTargetActor_Trace
{
	public:
	    char UnknownData0[0x460];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayAbilityTargetActor_SingleLineTrace");
			return (class UClass*)ptr;
		};

};

class AGameplayAbilityWorldReticle : public AActor
{
	public:
	    struct FWorldReticleParameters Parameters; // 0x330 Size: 0xc
	    bool bFaceOwnerFlat; // 0x33c Size: 0x1
	    bool bSnapToTargetedActor; // 0x33d Size: 0x1
	    bool bIsTargetValid; // 0x33e Size: 0x1
	    bool bIsTargetAnActor; // 0x33f Size: 0x1
	    class APlayerController* MasterPC; // 0x340 Size: 0x8
	    class AActor* TargetingActor; // 0x348 Size: 0x8
	    char UnknownData0[0x350]; // 0x350
	    void SetReticleMaterialParamVector(FName ParamName, struct FVector Value); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetReticleMaterialParamFloat(FName ParamName, float Value); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnValidTargetChanged(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnTargetingAnActor(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnParametersInitialized(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void FaceTowardSource(bool bFaceIn2D); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7c91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayAbilityWorldReticle");
			return (class UClass*)ptr;
		};

};

class AGameplayAbilityWorldReticle_ActorVisualization : public AGameplayAbilityWorldReticle
{
	public:
	    class UCapsuleComponent* CollisionComponent; // 0x350 Size: 0x8
	    TArray<class UActorComponent*> VisualizationComponents; // 0x358 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayAbilityWorldReticle_ActorVisualization");
			return (class UClass*)ptr;
		};

};

class UGameplayCueInterface : public UInterface
{
	public:
	    void ForwardGameplayCueToParent(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void BlueprintCustomHandler(char EventType, struct FGameplayCueParameters Parameters); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayCueInterface");
			return (class UClass*)ptr;
		};

};

class UGameplayCueManager : public UDataAsset
{
	public:
	    char UnknownData0[0x18];
	    struct FGameplayCueObjectLibrary RuntimeGameplayCueObjectLibrary; // 0x48 Size: 0x50
	    struct FGameplayCueObjectLibrary EditorGameplayCueObjectLibrary; // 0x98 Size: 0x50
	    char UnknownData1[0x1b8]; // 0xe8
	    TArray<class UObject*> LoadedGameplayCueNotifyClasses; // 0x2a0 Size: 0x10
	    TArray<class AGameplayCueNotify_Actor*> GameplayCueClassesForPreallocation; // 0x2b0 Size: 0x10
	    TArray<struct FGameplayCuePendingExecute> PendingExecuteCues; // 0x2c0 Size: 0x10
	    int GameplayCueSendContextCount; // 0x2d0 Size: 0x4
	    char UnknownData2[0x4]; // 0x2d4
	    TArray<struct FPreallocationInfo> PreallocationInfoList_Internal; // 0x2d8 Size: 0x10
	    char UnknownData3[0x18];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayCueManager");
			return (class UClass*)ptr;
		};

};

class AGameplayCueNotify_Actor : public AActor
{
	public:
	    bool bAutoDestroyOnRemove; // 0x330 Size: 0x1
	    char UnknownData0[0x3]; // 0x331
	    float AutoDestroyDelay; // 0x334 Size: 0x4
	    bool WarnIfTimelineIsStillRunning; // 0x338 Size: 0x1
	    bool WarnIfLatentActionIsStillRunning; // 0x339 Size: 0x1
	    char UnknownData1[0x2]; // 0x33a
	    struct FGameplayTag GameplayCueTag; // 0x33c Size: 0x8
	    char UnknownData2[0x4]; // 0x344
	    struct FGameplayTagReferenceHelper ReferenceHelper; // 0x348 Size: 0x10
	    FName GameplayCueName; // 0x358 Size: 0x8
	    bool bAutoAttachToOwner; // 0x360 Size: 0x1
	    bool IsOverride; // 0x361 Size: 0x1
	    bool bUniqueInstancePerInstigator; // 0x362 Size: 0x1
	    bool bUniqueInstancePerSourceObject; // 0x363 Size: 0x1
	    bool bAllowMultipleOnActiveEvents; // 0x364 Size: 0x1
	    bool bAllowMultipleWhileActiveEvents; // 0x365 Size: 0x1
	    char UnknownData3[0x2]; // 0x366
	    int NumPreallocatedInstances; // 0x368 Size: 0x4
	    char UnknownData4[0x36c]; // 0x36c
	    bool WhileActive(class AActor* MyTarget, struct FGameplayCueParameters Parameters); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool OnRemove(class AActor* MyTarget, struct FGameplayCueParameters Parameters); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnOwnerDestroyed(class AActor* DestroyedActor); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool OnExecute(class AActor* MyTarget, struct FGameplayCueParameters Parameters); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool OnActive(class AActor* MyTarget, struct FGameplayCueParameters Parameters); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void K2_HandleGameplayCue(class AActor* MyTarget, char EventType, struct FGameplayCueParameters Parameters); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void K2_EndGameplayCue(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x-7c41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayCueNotify_Actor");
			return (class UClass*)ptr;
		};

};

class UGameplayCueNotify_Static : public UObject
{
	public:
	    struct FGameplayTag GameplayCueTag; // 0x28 Size: 0x8
	    struct FGameplayTagReferenceHelper ReferenceHelper; // 0x30 Size: 0x10
	    FName GameplayCueName; // 0x40 Size: 0x8
	    bool IsOverride; // 0x48 Size: 0x1
	    char UnknownData0[0x49]; // 0x49
	    bool WhileActive(class AActor* MyTarget, struct FGameplayCueParameters Parameters); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool OnRemove(class AActor* MyTarget, struct FGameplayCueParameters Parameters); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool OnExecute(class AActor* MyTarget, struct FGameplayCueParameters Parameters); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool OnActive(class AActor* MyTarget, struct FGameplayCueParameters Parameters); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void K2_HandleGameplayCue(class AActor* MyTarget, char EventType, struct FGameplayCueParameters Parameters); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7f91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayCueNotify_Static");
			return (class UClass*)ptr;
		};

};

class UGameplayCueNotify_HitImpact : public UGameplayCueNotify_Static
{
	public:
	    class USoundBase* Sound; // 0x50 Size: 0x8
	    class UParticleSystem* ParticleSystem; // 0x58 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayCueNotify_HitImpact");
			return (class UClass*)ptr;
		};

};

class UGameplayCueSet : public UDataAsset
{
	public:
	    TArray<struct FGameplayCueNotifyData> GameplayCueData; // 0x30 Size: 0x10
	    char UnknownData0[0x50];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayCueSet");
			return (class UClass*)ptr;
		};

};

class UGameplayCueTranslator : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayCueTranslator");
			return (class UClass*)ptr;
		};

};

class UGameplayCueTranslator_Test : public UGameplayCueTranslator
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayCueTranslator_Test");
			return (class UClass*)ptr;
		};

};

class UGameplayEffect : public UObject
{
	public:
	    char UnknownData0[0x8];
	    EGameplayEffectDurationType DurationPolicy; // 0x30 Size: 0x1
	    char UnknownData1[0x7]; // 0x31
	    struct FGameplayEffectModifierMagnitude DurationMagnitude; // 0x38 Size: 0x190
	    struct FScalableFloat Period; // 0x1c8 Size: 0x20
	    bool bExecutePeriodicEffectOnApplication; // 0x1e8 Size: 0x1
	    char UnknownData2[0x7]; // 0x1e9
	    TArray<struct FGameplayModifierInfo> Modifiers; // 0x1f0 Size: 0x10
	    TArray<struct FGameplayEffectExecutionDefinition> Executions; // 0x200 Size: 0x10
	    struct FScalableFloat ChanceToApplyToTarget; // 0x210 Size: 0x20
	    TArray<class UGameplayEffectCustomApplicationRequirement*> ApplicationRequirements; // 0x230 Size: 0x10
	    TArray<class UGameplayEffect*> TargetEffectClasses; // 0x240 Size: 0x10
	    TArray<struct FConditionalGameplayEffect> ConditionalGameplayEffects; // 0x250 Size: 0x10
	    TArray<class UGameplayEffect*> OverflowEffects; // 0x260 Size: 0x10
	    bool bDenyOverflowApplication; // 0x270 Size: 0x1
	    bool bClearStackOnOverflow; // 0x271 Size: 0x1
	    char UnknownData3[0x6]; // 0x272
	    TArray<class UGameplayEffect*> PrematureExpirationEffectClasses; // 0x278 Size: 0x10
	    TArray<class UGameplayEffect*> RoutineExpirationEffectClasses; // 0x288 Size: 0x10
	    bool bRequireModifierSuccessToTriggerCues; // 0x298 Size: 0x1
	    bool bSuppressStackingCues; // 0x299 Size: 0x1
	    char UnknownData4[0x6]; // 0x29a
	    TArray<struct FGameplayEffectCue> GameplayCues; // 0x2a0 Size: 0x10
	    class UGameplayEffectUIData* UIData; // 0x2b0 Size: 0x8
	    struct FInheritedTagContainer InheritableGameplayEffectTags; // 0x2b8 Size: 0x60
	    struct FInheritedTagContainer InheritableOwnedTagsContainer; // 0x318 Size: 0x60
	    struct FGameplayTagRequirements OngoingTagRequirements; // 0x378 Size: 0x40
	    struct FGameplayTagRequirements ApplicationTagRequirements; // 0x3b8 Size: 0x40
	    struct FInheritedTagContainer RemoveGameplayEffectsWithTags; // 0x3f8 Size: 0x60
	    struct FGameplayTagRequirements GrantedApplicationImmunityTags; // 0x458 Size: 0x40
	    struct FGameplayEffectQuery GrantedApplicationImmunityQuery; // 0x498 Size: 0x138
	    char UnknownData5[0x1]; // 0x5d0
	    EGameplayEffectStackingType StackingType; // 0x5d1 Size: 0x1
	    char UnknownData6[0x2]; // 0x5d2
	    int StackLimitCount; // 0x5d4 Size: 0x4
	    EGameplayEffectStackingDurationPolicy StackDurationRefreshPolicy; // 0x5d8 Size: 0x1
	    EGameplayEffectStackingPeriodPolicy StackPeriodResetPolicy; // 0x5d9 Size: 0x1
	    EGameplayEffectStackingExpirationPolicy StackExpirationPolicy; // 0x5da Size: 0x1
	    char UnknownData7[0x5]; // 0x5db
	    TArray<struct FGameplayAbilitySpecDef> GrantedAbilities; // 0x5e0 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayEffect");
			return (class UClass*)ptr;
		};

};

class UGameplayEffectCalculation : public UObject
{
	public:
	    TArray<struct FGameplayEffectAttributeCaptureDefinition> RelevantAttributesToCapture; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayEffectCalculation");
			return (class UClass*)ptr;
		};

};

class UGameplayEffectCustomApplicationRequirement : public UObject
{
	public:
	    bool CanApplyGameplayEffect(class UGameplayEffect* GameplayEffect, struct FGameplayEffectSpec Spec, class UAbilitySystemComponent* ASC); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayEffectCustomApplicationRequirement");
			return (class UClass*)ptr;
		};

};

class UGameplayEffectExecutionCalculation : public UGameplayEffectCalculation
{
	public:
	    bool bRequiresPassedInTags; // 0x38 Size: 0x1
	    char UnknownData0[0x39]; // 0x39
	    void Execute(struct FGameplayEffectCustomExecutionParameters ExecutionParams, struct FGameplayEffectCustomExecutionOutput OutExecutionOutput); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7fa1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayEffectExecutionCalculation");
			return (class UClass*)ptr;
		};

};

class UGameplayEffectTemplate : public UGameplayEffect
{
	public:
	    char UnknownData0[0x5f0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayEffectTemplate");
			return (class UClass*)ptr;
		};

};

class UGameplayEffectUIData : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayEffectUIData");
			return (class UClass*)ptr;
		};

};

class UGameplayEffectUIData_TextOnly : public UGameplayEffectUIData
{
	public:
	    struct FText Description; // 0x28 Size: 0x18

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayEffectUIData_TextOnly");
			return (class UClass*)ptr;
		};

};

class UGameplayModMagnitudeCalculation : public UGameplayEffectCalculation
{
	public:
	    bool bAllowNonNetAuthorityDependencyRegistration; // 0x38 Size: 0x1
	    char UnknownData0[0x39]; // 0x39
	    float CalculateBaseMagnitude(struct FGameplayEffectSpec Spec); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7fa1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayModMagnitudeCalculation");
			return (class UClass*)ptr;
		};

};

class UGameplayTagReponseTable : public UDataAsset
{
	public:
	    TArray<struct FGameplayTagResponseTableEntry> Entries; // 0x30 Size: 0x10
	    char UnknownData0[0x40]; // 0x40
	    void TagResponseEvent(struct FGameplayTag Tag, int NewCount, class UAbilitySystemComponent* ASC, int idx); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7e11];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.GameplayTagReponseTable");
			return (class UClass*)ptr;
		};

};

class UTickableAttributeSetInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/GameplayAbilities.TickableAttributeSetInterface");
			return (class UClass*)ptr;
		};

};


}