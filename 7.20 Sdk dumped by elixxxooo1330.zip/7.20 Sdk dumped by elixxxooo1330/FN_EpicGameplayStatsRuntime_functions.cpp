#include "../SDK.hpp"

static bool UBlueprintGameplayStatsLibrary::NotEqual_GameplayStatTagGameplayStatTag(struct FGameplayStatTag A, struct FGameplayStatTag B)
{
	struct {
            struct FGameplayStatTag A;
            struct FGameplayStatTag B;
            bool ReturnValue;
	} params{ A, B };

    static auto fn = UObject::FindObject("/Script/EpicGameplayStatsRuntime.BlueprintGameplayStatsLibrary:NotEqual_GameplayStatTagGameplayStatTag");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UBlueprintGameplayStatsLibrary::EqualEqual_GameplayStatTagGameplayStatTag(struct FGameplayStatTag A, struct FGameplayStatTag B)
{
	struct {
            struct FGameplayStatTag A;
            struct FGameplayStatTag B;
            bool ReturnValue;
	} params{ A, B };

    static auto fn = UObject::FindObject("/Script/EpicGameplayStatsRuntime.BlueprintGameplayStatsLibrary:EqualEqual_GameplayStatTagGameplayStatTag");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

