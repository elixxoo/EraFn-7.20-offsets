#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FOnImageWriteComplete__DelegateSignature
{
	public:
	    bool bSuccess; // 0x0 Size: 0x1

};



enum class EDesiredImageFormat : uint8_t
{
    PNG = 0,
    JPG = 1,
    BMP = 2,
    EXR = 3,
    EDesiredImageFormat_MAX = 4
};struct FImageWriteOptions
{
	public:
	    EDesiredImageFormat Format; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    __int64/*DelegateProperty*/ OnComplete; // 0x4 Size: 0x10
	    int CompressionQuality; // 0x14 Size: 0x4
	    bool bOverwriteFile; // 0x18 Size: 0x1
	    bool bAsync; // 0x19 Size: 0x1
	    char UnknownData1[0x46];

};


}