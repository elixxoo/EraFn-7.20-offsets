#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FOnNiagaraScriptCompilationComplete__DelegateSignature
{
	public:

};

struct FNiagaraDataInterfaceGPUParamInfo
{
	public:
	    struct FString DataInterfaceHLSLSymbol; // 0x0 Size: 0x10
	    struct FString DIClassName; // 0x10 Size: 0x10

};


}