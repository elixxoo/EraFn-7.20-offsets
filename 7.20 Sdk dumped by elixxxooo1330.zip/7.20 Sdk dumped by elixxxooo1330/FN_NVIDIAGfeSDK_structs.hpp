#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class EGfeSDKHighlightSignificance : uint8_t
{
    ExtremelyBad = 1,
    VeryBad = 2,
    Bad = 4,
    Neutral = 8,
    Good = 16,
    VeryGood = 32,
    ExtremelyGood = 64,
    MAX = 128
};

enum class EGfeSDKHighlightType : uint8_t
{
    Milestone = 1,
    Achievement = 2,
    Incident = 4,
    StateChange = 8,
    MAX = 16
};

enum class EGfeSDKPermission : uint8_t
{
    Granted = 0,
    Denied = 1,
    MustAsk = 2,
    Unknown = 3,
    MAX = 4
};

enum class EGfeSDKScope : uint8_t
{
    Highlights = 0,
    HighlightsRecordVideo = 1,
    HighlightsRecordScreenshot = 2,
    MAX = 3
};

enum class EGfeSDKReturnCode : uint8_t
{
    Success = 0,
    SuccessIpcOldSdk = 1,
    SuccessIpcOldGfe = 2,
    Error = 3,
    ErrorGfeVersion = 4,
    ErrorSdkVersion = 5,
    ErrorModuleNotLoaded = 6,
    EGfeSDKReturnCode_MAX = 7
};struct FGfeSDKHighlightGroupView
{
	public:
	    struct FString GroupID; // 0x0 Size: 0x10
	    EGfeSDKHighlightType TagsFilter; // 0x10 Size: 0x1
	    EGfeSDKHighlightSignificance SignificanceFilter; // 0x11 Size: 0x1
	    char UnknownData0[0x6];

};

struct FGfeSDKHighlightVideoParams
{
	public:
	    struct FString GroupID; // 0x0 Size: 0x10
	    struct FString HighlightId; // 0x10 Size: 0x10
	    int StartDelta; // 0x20 Size: 0x4
	    int EndDelta; // 0x24 Size: 0x4

};

struct FGfeSDKHighlightScreenshotParams
{
	public:
	    struct FString GroupID; // 0x0 Size: 0x10
	    struct FString HighlightId; // 0x10 Size: 0x10

};

struct FGfeSDKHighlightCloseGroupParams
{
	public:
	    struct FString GroupID; // 0x0 Size: 0x10
	    bool DestroyHighlights; // 0x10 Size: 0x1
	    char UnknownData0[0x7];

};

struct FGfeSDKHighlightOpenGroupParams
{
	public:
	    struct FString GroupID; // 0x0 Size: 0x10
	    __int64/*MapProperty*/ GroupDescriptionTranslationTable; // 0x10 Size: 0x50

};

struct FGfeSDKPermissionsChangedData
{
	public:
	    __int64/*MapProperty*/ ScopePermissions; // 0x0 Size: 0x50

};

struct FGfeSDKHighlightDefinition
{
	public:
	    struct FString ID; // 0x0 Size: 0x10
	    bool UserDefaultInterest; // 0x10 Size: 0x1
	    EGfeSDKHighlightType HighlightTags; // 0x11 Size: 0x1
	    EGfeSDKHighlightSignificance Significance; // 0x12 Size: 0x1
	    char UnknownData0[0x5]; // 0x13
	    __int64/*MapProperty*/ NameTranslationTable; // 0x18 Size: 0x50

};

struct FGfeSDKCreateResponse
{
	public:
	    __int64/*UInt16Property*/ VersionMajor; // 0x0 Size: 0x2
	    __int64/*UInt16Property*/ VersionMinor; // 0x2 Size: 0x2
	    char UnknownData0[0x4]; // 0x4
	    struct FString NVIDIAGfeVersion; // 0x8 Size: 0x10
	    __int64/*MapProperty*/ ScopePermissions; // 0x18 Size: 0x50

};


}