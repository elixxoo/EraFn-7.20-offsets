#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FStructSerializerMapTestStruct
{
	public:
	    __int64/*MapProperty*/ IntToStr; // 0x0 Size: 0x50
	    __int64/*MapProperty*/ StrToStr; // 0x50 Size: 0x50
	    __int64/*MapProperty*/ StrToVec; // 0xa0 Size: 0x50

};

struct FStructSerializerBuiltinTestStruct
{
	public:
	    struct FGuid Guid; // 0x0 Size: 0x10
	    FName Name; // 0x10 Size: 0x8
	    struct FString String; // 0x18 Size: 0x10
	    struct FRotator Rotator; // 0x28 Size: 0xc
	    char UnknownData0[0x4]; // 0x34
	    struct FText Text; // 0x38 Size: 0x18
	    struct FVector Vector; // 0x50 Size: 0xc
	    char UnknownData1[0x4];

};

struct FStructSerializerObjectTestStruct
{
	public:
	    class UObject* Class; // 0x0 Size: 0x8
	    class UObject* ObjectPtr; // 0x8 Size: 0x8

};

struct FStructSerializerBooleanTestStruct
{
	public:
	    bool BoolFalse; // 0x0 Size: 0x1
	    bool BoolTrue; // 0x1 Size: 0x1
	    char UnknownData0[0x2]; // 0x2
	    uint32_t Bitfield; // 0x4 Size: 0x4

};

struct FStructSerializerNumericTestStruct
{
	public:
	    int8_t Int8; // 0x0 Size: 0x1
	    char UnknownData0[0x1]; // 0x1
	    int16_t Int16; // 0x2 Size: 0x2
	    int Int32; // 0x4 Size: 0x4
	    int64_t Int64; // 0x8 Size: 0x8
	    char UInt8; // 0x10 Size: 0x1
	    char UnknownData1[0x1]; // 0x11
	    __int64/*UInt16Property*/ UInt16; // 0x12 Size: 0x2
	    uint32_t UInt32; // 0x14 Size: 0x4
	    uint64_t UInt64; // 0x18 Size: 0x8
	    float Float; // 0x20 Size: 0x4
	    char UnknownData2[0x4]; // 0x24
	    double Double; // 0x28 Size: 0x8

};


}