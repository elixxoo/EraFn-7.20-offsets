#pragma once

#include "../SDK.hpp"

namespace SDK {


class UAndroidPermissionCallbackProxy : public UObject
{
	public:
	    MulticastDelegateProperty OnPermissionsGrantedDynamicDelegate; // 0x28 Size: 0x10
	    char UnknownData0[0x10];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AndroidPermission.AndroidPermissionCallbackProxy");
			return (class UClass*)ptr;
		};

};

class UAndroidPermissionFunctionLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static bool CheckPermission(struct FString Permission); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static class UAndroidPermissionCallbackProxy* AcquirePermissions(TArray<struct FString> Permissions); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AndroidPermission.AndroidPermissionFunctionLibrary");
			return (class UClass*)ptr;
		};

};


}