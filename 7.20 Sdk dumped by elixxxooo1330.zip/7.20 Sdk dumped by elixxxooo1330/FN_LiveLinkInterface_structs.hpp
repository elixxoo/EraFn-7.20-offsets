#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class ELiveLinkSourceMode : uint8_t
{
    Default = 0,
    Interpolated = 1,
    TimeSynchronized = 2,
    ELiveLinkSourceMode_MAX = 3
};struct FLiveLinkMetaData
{
	public:
	    __int64/*MapProperty*/ StringMetadata; // 0x0 Size: 0x50
	    char UnknownData0[0x10];

};

struct FLiveLinkWorldTime
{
	public:
	    double Time; // 0x0 Size: 0x8
	    double Offset; // 0x8 Size: 0x8

};

struct FLiveLinkCurveElement
{
	public:
	    FName CurveName; // 0x0 Size: 0x8
	    float CurveValue; // 0x8 Size: 0x4

};

struct FLiveLinkSourceHandle
{
	public:
	    char UnknownData0[0x18];

};

struct FLiveLinkInterpolationSettings
{
	public:
	    float InterpolationOffset; // 0x0 Size: 0x4

};

struct FLiveLinkTimeSynchronizationSettings
{
	public:
	    struct FFrameRate FrameRate; // 0x0 Size: 0x8

};

struct FLiveLinkFrameRate : public FFrameRate
{
	public:
	    char UnknownData0[0x8];

};

struct FLiveLinkTimeCode_Base_DEPRECATED
{
	public:
	    int Seconds; // 0x0 Size: 0x4
	    int Frames; // 0x4 Size: 0x4
	    struct FLiveLinkFrameRate FrameRate; // 0x8 Size: 0x8

};

struct FLiveLinkTimeCode : public FLiveLinkTimeCode_Base_DEPRECATED
{
	public:
	    char UnknownData0[0x10];

};

struct FLiveLinkSubjectName
{
	public:
	    FName Name; // 0x0 Size: 0x8

};


}