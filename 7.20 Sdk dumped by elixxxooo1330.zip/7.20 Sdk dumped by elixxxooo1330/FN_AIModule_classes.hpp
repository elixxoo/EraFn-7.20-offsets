#pragma once

#include "../SDK.hpp"

namespace SDK {


class UAIHotSpotManager : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AIHotSpotManager");
			return (class UClass*)ptr;
		};

};

class AAIController : public AController
{
	public:
	    char UnknownData0[0x38];
	    bool bStopAILogicOnUnposses; // 0x3e8 Size: 0x1
	    bool bLOSflag; // 0x3e8 Size: 0x1
	    bool bSkipExtraLOSChecks; // 0x3e8 Size: 0x1
	    bool bAllowStrafe; // 0x3e8 Size: 0x1
	    bool bWantsPlayerState; // 0x3e8 Size: 0x1
	    bool bSetControlRotationFromPawnOrientation; // 0x3e8 Size: 0x1
	    char UnknownData1[0x2]; // 0x3ee
	    class UPathFollowingComponent* PathFollowingComponent; // 0x3f0 Size: 0x8
	    class UBrainComponent* BrainComponent; // 0x3f8 Size: 0x8
	    class UAIPerceptionComponent* PerceptionComponent; // 0x400 Size: 0x8
	    class UPawnActionsComponent* ActionsComp; // 0x408 Size: 0x8
	    class UBlackboardComponent* Blackboard; // 0x410 Size: 0x8
	    class UGameplayTasksComponent* CachedGameplayTasksComponent; // 0x418 Size: 0x8
	    class UNavigationQueryFilter* DefaultNavigationFilterClass; // 0x420 Size: 0x8
	    MulticastDelegateProperty ReceiveMoveCompleted; // 0x428 Size: 0x10
	    char UnknownData2[0x438]; // 0x438
	    bool UseBlackboard(class UBlackboardData* BlackboardAsset, class UBlackboardComponent* BlackboardComponent); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void UnclaimTaskResource(class UGameplayTaskResource* ResourceClass); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetPathFollowingComponent(class UPathFollowingComponent* NewPFComponent); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetMoveBlockDetection(bool bEnable); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool RunBehaviorTree(class UBehaviorTree* BTAsset); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnUsingBlackBoard(class UBlackboardComponent* BlackboardComp, class UBlackboardData* BlackboardAsset); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnUnpossess(class APawn* UnpossessedPawn); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnPossess(class APawn* PossessedPawn); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnGameplayTaskResourcesClaimed(struct FGameplayResourceSet NewlyClaimed, struct FGameplayResourceSet FreshlyReleased); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    char MoveToLocation(struct FVector Dest, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bProjectDestinationToNavigation, bool bCanStrafe, class UNavigationQueryFilter* FilterClass, bool bAllowPartialPath); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    char MoveToActor(class AActor* Goal, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bCanStrafe, class UNavigationQueryFilter* FilterClass, bool bAllowPartialPath); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void K2_SetFocus(class AActor* NewFocus); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void K2_SetFocalPoint(struct FVector FP); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void K2_ClearFocus(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    bool HasPartialPath(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    class UPathFollowingComponent* GetPathFollowingComponent(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    char GetMoveStatus(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    struct FVector GetImmediateMoveDestination(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    class AActor* GetFocusActor(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    struct FVector GetFocalPointOnActor(class AActor* Actor); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    struct FVector GetFocalPoint(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    class UAIPerceptionComponent* GetAIPerceptionComponent(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void ClaimTaskResource(class UGameplayTaskResource* ResourceClass); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x-7ba1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AIController");
			return (class UClass*)ptr;
		};

};

class UAIPerceptionComponent : public UActorComponent
{
	public:
	    TArray<class UAISenseConfig*> SensesConfig; // 0xf8 Size: 0x10
	    class UAISense* DominantSense; // 0x108 Size: 0x8
	    char UnknownData0[0x10]; // 0x110
	    class AAIController* AIOwner; // 0x120 Size: 0x8
	    char UnknownData1[0x80]; // 0x128
	    MulticastDelegateProperty OnPerceptionUpdated; // 0x1a8 Size: 0x10
	    MulticastDelegateProperty OnTargetPerceptionUpdated; // 0x1b8 Size: 0x10
	    char UnknownData2[0x1c8]; // 0x1c8
	    void SetSenseEnabled(class UAISense* SenseClass, bool bEnable); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void RequestStimuliListenerUpdate(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnOwnerEndPlay(class AActor* Actor, char EndPlayReason); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void GetPerceivedHostileActors(TArray<class AActor*> OutActors); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void GetPerceivedActors(class UAISense* SenseToUse, TArray<class AActor*> OutActors); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void GetKnownPerceivedActors(class UAISense* SenseToUse, TArray<class AActor*> OutActors); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void GetCurrentlyPerceivedActors(class UAISense* SenseToUse, TArray<class AActor*> OutActors); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool GetActorsPerception(class AActor* Actor, struct FActorPerceptionBlueprintInfo Info); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7e19];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AIPerceptionComponent");
			return (class UClass*)ptr;
		};

};

class UBrainComponent : public UActorComponent
{
	public:
	    char UnknownData0[0x8];
	    class UBlackboardComponent* BlackboardComp; // 0x100 Size: 0x8
	    class AAIController* AIOwner; // 0x108 Size: 0x8
	    char UnknownData1[0x110]; // 0x110
	    void StopLogic(struct FString Reason); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void RestartLogic(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool IsRunning(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool IsPaused(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7e89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BrainComponent");
			return (class UClass*)ptr;
		};

};

class UBehaviorTreeComponent : public UBrainComponent
{
	public:
	    char UnknownData0[0x20];
	    TArray<class UBTNode*> NodeInstances; // 0x178 Size: 0x10
	    char UnknownData1[0x188]; // 0x188
	    void SetDynamicSubtree(struct FGameplayTag InjectTag, class UBehaviorTree* BehaviorAsset); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    float GetTagCooldownEndTime(struct FGameplayTag CooldownTag); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void AddCooldownTagDuration(struct FGameplayTag CooldownTag, float CooldownDuration, bool bAddToExistingDuration); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7d39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BehaviorTreeComponent");
			return (class UClass*)ptr;
		};

};

class UAISubsystem : public UObject
{
	public:
	    char UnknownData0[0x8];
	    class UAISystem* AISystem; // 0x30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AISubsystem");
			return (class UClass*)ptr;
		};

};

class UAISense : public UObject
{
	public:
	    float DefaultExpirationAge; // 0x28 Size: 0x4
	    EAISenseNotifyType NotifyType; // 0x2c Size: 0x1
	    bool bWantsNewPawnNotification; // 0x30 Size: 0x1
	    bool bAutoRegisterAllPawnsAsSources; // 0x30 Size: 0x1
	    char UnknownData0[0x9]; // 0x2f
	    class UAIPerceptionSystem* PerceptionSystemInstance; // 0x38 Size: 0x8
	    char UnknownData1[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AISense");
			return (class UClass*)ptr;
		};

};

class UAISense_Hearing : public UAISense
{
	public:
	    TArray<struct FAINoiseEvent> NoiseEvents; // 0x80 Size: 0x10
	    float SpeedOfSoundSq; // 0x90 Size: 0x4
	    char UnknownData0[0x94]; // 0x94
	    static void ReportNoiseEvent(class UObject* WorldContextObject, struct FVector NoiseLocation, float Loudness, class AActor* Instigator, float MaxRange, FName Tag); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7ef9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AISense_Hearing");
			return (class UClass*)ptr;
		};

};

class UAISystem : public UAISystemBase
{
	public:
	    struct FSoftClassPath PerceptionSystemClassName; // 0x58 Size: 0x18
	    struct FSoftClassPath HotSpotManagerClassName; // 0x70 Size: 0x18
	    float AcceptanceRadius; // 0x88 Size: 0x4
	    float PathfollowingRegularPathPointAcceptanceRadius; // 0x8c Size: 0x4
	    float PathfollowingNavLinkAcceptanceRadius; // 0x90 Size: 0x4
	    bool bFinishMoveOnGoalOverlap; // 0x94 Size: 0x1
	    bool bAcceptPartialPaths; // 0x95 Size: 0x1
	    bool bAllowStrafing; // 0x96 Size: 0x1
	    bool bEnableBTAITasks; // 0x97 Size: 0x1
	    bool bAllowControllersAsEQSQuerier; // 0x98 Size: 0x1
	    bool bEnableDebuggerPlugin; // 0x99 Size: 0x1
	    char DefaultSightCollisionChannel; // 0x9a Size: 0x1
	    char UnknownData0[0x5]; // 0x9b
	    class UBehaviorTreeManager* BehaviorTreeManager; // 0xa0 Size: 0x8
	    class UEnvQueryManager* EnvironmentQueryManager; // 0xa8 Size: 0x8
	    class UAIPerceptionSystem* PerceptionSystem; // 0xb0 Size: 0x8
	    TArray<class UAIAsyncTaskBlueprintProxy*> AllProxyObjects; // 0xb8 Size: 0x10
	    class UAIHotSpotManager* HotSpotManager; // 0xc8 Size: 0x8
	    class UNavLocalGridManager* NavLocalGrids; // 0xd0 Size: 0x8
	    char UnknownData1[0xd8]; // 0xd8
	    void AILoggingVerbose(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void AIIgnorePlayers(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7eb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AISystem");
			return (class UClass*)ptr;
		};

};

class UPathFollowingComponent : public UActorComponent
{
	public:
	    char UnknownData0[0x38];
	    class UNavMovementComponent* MovementComp; // 0x130 Size: 0x8
	    char UnknownData1[0x8]; // 0x138
	    class ANavigationData* MyNavData; // 0x140 Size: 0x8
	    char UnknownData2[0x148]; // 0x148
	    void OnNavDataRegistered(class ANavigationData* NavData); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnActorBump(class AActor* SelfActor, class AActor* OtherActor, struct FVector NormalImpulse, struct FHitResult Hit); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    struct FVector GetPathDestination(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    char GetPathActionType(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7d41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.PathFollowingComponent");
			return (class UClass*)ptr;
		};

};

class UCrowdFollowingComponent : public UPathFollowingComponent
{
	public:
	    char UnknownData0[0x8];
	    class UCharacterMovementComponent* CharacterMovement; // 0x2a8 Size: 0x8
	    struct FVector CrowdAgentMoveDirection; // 0x2b0 Size: 0xc
	    char UnknownData1[0x2bc]; // 0x2bc
	    void SuspendCrowdSteering(bool bSuspend); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d01];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.CrowdFollowingComponent");
			return (class UClass*)ptr;
		};

};

class ANavLinkProxy : public AActor
{
	public:
	    char UnknownData0[0x10];
	    TArray<struct FNavigationLink> PointLinks; // 0x340 Size: 0x10
	    TArray<struct FNavigationSegmentLink> SegmentLinks; // 0x350 Size: 0x10
	    class UNavLinkCustomComponent* SmartLinkComp; // 0x360 Size: 0x8
	    bool bSmartLinkIsRelevant; // 0x368 Size: 0x1
	    char UnknownData1[0x7]; // 0x369
	    MulticastDelegateProperty OnSmartLinkReached; // 0x370 Size: 0x10
	    char UnknownData2[0x380]; // 0x380
	    void SetSmartLinkEnabled(bool bEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void ResumePathFollowing(class AActor* Agent); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void ReceiveSmartLinkReached(class AActor* Agent, struct FVector Destination); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool IsSmartLinkEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool HasMovingAgents(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7c61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.NavLinkProxy");
			return (class UClass*)ptr;
		};

};

class UAITask : public UGameplayTask
{
	public:
	    class AAIController* OwnerController; // 0x68 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AITask");
			return (class UClass*)ptr;
		};

};

class UAITask_MoveTo : public UAITask
{
	public:
	    MulticastDelegateProperty OnRequestFailed; // 0x70 Size: 0x10
	    MulticastDelegateProperty OnMoveFinished; // 0x80 Size: 0x10
	    struct FAIMoveRequest MoveRequest; // 0x90 Size: 0x40
	    char UnknownData0[0xd0]; // 0xd0
	    static class UAITask_MoveTo* AIMoveTo(class AAIController* Controller, struct FVector GoalLocation, class AActor* GoalActor, float AcceptanceRadius, char StopOnOverlap, char AcceptPartialPath, bool bUsePathfinding, bool bLockAILogic, bool bUseContinuosGoalTracking); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7ed1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AITask_MoveTo");
			return (class UClass*)ptr;
		};

};

class UAIDataProvider : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AIDataProvider");
			return (class UClass*)ptr;
		};

};

class UAIPerceptionSystem : public UAISubsystem
{
	public:
	    char UnknownData0[0x50];
	    TArray<class UAISense*> Senses; // 0x88 Size: 0x10
	    float PerceptionAgingRate; // 0x98 Size: 0x4
	    char UnknownData1[0x9c]; // 0x9c
	    static void ReportPerceptionEvent(class UObject* WorldContextObject, class UAISenseEvent* PerceptionEvent); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void ReportEvent(class UAISenseEvent* PerceptionEvent); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static bool RegisterPerceptionStimuliSource(class UObject* WorldContextObject, class UAISense* Sense, class AActor* Target); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnPerceptionStimuliSourceEndPlay(class AActor* Actor, char EndPlayReason); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static class UAISense* GetSenseClassForStimulus(class UObject* WorldContextObject, struct FAIStimulus Stimulus); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7ea9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AIPerceptionSystem");
			return (class UClass*)ptr;
		};

};

class UBTNode : public UObject
{
	public:
	    char UnknownData0[0x8];
	    struct FString NodeName; // 0x30 Size: 0x10
	    class UBehaviorTree* TreeAsset; // 0x40 Size: 0x8
	    class UBTCompositeNode* ParentNode; // 0x48 Size: 0x8
	    char UnknownData1[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTNode");
			return (class UClass*)ptr;
		};

};

class UBTAuxiliaryNode : public UBTNode
{
	public:
	    char UnknownData0[0x60];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTAuxiliaryNode");
			return (class UClass*)ptr;
		};

};

class UBTService : public UBTAuxiliaryNode
{
	public:
	    float Interval; // 0x60 Size: 0x4
	    float RandomDeviation; // 0x64 Size: 0x4
	    bool bCallTickOnSearchStart; // 0x68 Size: 0x1
	    bool bRestartTimerOnEachActivation; // 0x68 Size: 0x1
	    char UnknownData0[0x6];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTService");
			return (class UClass*)ptr;
		};

};

class UBTDecorator : public UBTAuxiliaryNode
{
	public:
	    bool bInverseCondition; // 0x60 Size: 0x1
	    char UnknownData0[0x3]; // 0x61
	    char FlowAbortMode; // 0x64 Size: 0x1
	    char UnknownData1[0x3];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTDecorator");
			return (class UClass*)ptr;
		};

};

class UBTDecorator_BlackboardBase : public UBTDecorator
{
	public:
	    struct FBlackboardKeySelector BlackboardKey; // 0x68 Size: 0x28

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTDecorator_BlackboardBase");
			return (class UClass*)ptr;
		};

};

class UBTService_BlackboardBase : public UBTService
{
	public:
	    struct FBlackboardKeySelector BlackboardKey; // 0x70 Size: 0x28

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTService_BlackboardBase");
			return (class UClass*)ptr;
		};

};

class UBTTaskNode : public UBTNode
{
	public:
	    TArray<class UBTService*> Services; // 0x58 Size: 0x10
	    bool bIgnoreRestartSelf; // 0x68 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTTaskNode");
			return (class UClass*)ptr;
		};

};

class UBTTask_BlackboardBase : public UBTTaskNode
{
	public:
	    struct FBlackboardKeySelector BlackboardKey; // 0x70 Size: 0x28

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTTask_BlackboardBase");
			return (class UClass*)ptr;
		};

};

class UBTTask_GameplayTaskBase : public UBTTaskNode
{
	public:
	    bool bWaitForGameplayTask; // 0x70 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTTask_GameplayTaskBase");
			return (class UClass*)ptr;
		};

};

class UBTTask_MoveTo : public UBTTask_BlackboardBase
{
	public:
	    float AcceptableRadius; // 0x98 Size: 0x4
	    char UnknownData0[0x4]; // 0x9c
	    class UNavigationQueryFilter* FilterClass; // 0xa0 Size: 0x8
	    float ObservedBlackboardValueTolerance; // 0xa8 Size: 0x4
	    bool bObserveBlackboardValue; // 0xac Size: 0x1
	    bool bAllowStrafe; // 0xac Size: 0x1
	    bool bAllowPartialPath; // 0xac Size: 0x1
	    bool bTrackMovingGoal; // 0xac Size: 0x1
	    bool bProjectGoalLocation; // 0xac Size: 0x1
	    bool bReachTestIncludesAgentRadius; // 0xac Size: 0x1
	    bool bReachTestIncludesGoalRadius; // 0xac Size: 0x1
	    bool bStopOnOverlap; // 0xac Size: 0x1
	    bool bStopOnOverlapNeedsUpdate; // 0xad Size: 0x1
	    char UnknownData1[0x-5];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTTask_MoveTo");
			return (class UClass*)ptr;
		};

};

class UCrowdManager : public UCrowdManagerBase
{
	public:
	    class ANavigationData* MyNavData; // 0x28 Size: 0x8
	    TArray<struct FCrowdAvoidanceConfig> AvoidanceConfig; // 0x30 Size: 0x10
	    TArray<struct FCrowdAvoidanceSamplingPattern> SamplingPatterns; // 0x40 Size: 0x10
	    int MaxAgents; // 0x50 Size: 0x4
	    float MaxAgentRadius; // 0x54 Size: 0x4
	    int MaxAvoidedAgents; // 0x58 Size: 0x4
	    int MaxAvoidedWalls; // 0x5c Size: 0x4
	    float NavmeshCheckInterval; // 0x60 Size: 0x4
	    float PathOptimizationInterval; // 0x64 Size: 0x4
	    float SeparationDirClamp; // 0x68 Size: 0x4
	    float PathOffsetRadiusMultiplier; // 0x6c Size: 0x4
	    bool bResolveCollisions; // 0x70 Size: 0x1
	    char UnknownData0[0x7f];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.CrowdManager");
			return (class UClass*)ptr;
		};

};

class UEnvQueryContext : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryContext");
			return (class UClass*)ptr;
		};

};

class UEnvQueryNode : public UObject
{
	public:
	    int VerNum; // 0x28 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryNode");
			return (class UClass*)ptr;
		};

};

class UEnvQueryGenerator : public UEnvQueryNode
{
	public:
	    struct FString OptionName; // 0x30 Size: 0x10
	    class UEnvQueryItemType* ItemType; // 0x40 Size: 0x8
	    bool bAutoSortTests; // 0x48 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryGenerator");
			return (class UClass*)ptr;
		};

};

class UEnvQueryGenerator_ActorsOfClass : public UEnvQueryGenerator
{
	public:
	    class AActor* SearchedActorClass; // 0x50 Size: 0x8
	    struct FAIDataProviderBoolValue GenerateOnlyActorsInRadius; // 0x58 Size: 0x30
	    struct FAIDataProviderFloatValue SearchRadius; // 0x88 Size: 0x30
	    class UEnvQueryContext* SearchCenter; // 0xb8 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryGenerator_ActorsOfClass");
			return (class UClass*)ptr;
		};

};

class UEnvQueryGenerator_ProjectedPoints : public UEnvQueryGenerator
{
	public:
	    struct FEnvTraceData ProjectionData; // 0x50 Size: 0x30

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryGenerator_ProjectedPoints");
			return (class UClass*)ptr;
		};

};

class UEnvQueryGenerator_OnCircle : public UEnvQueryGenerator_ProjectedPoints
{
	public:
	    struct FAIDataProviderFloatValue CircleRadius; // 0x80 Size: 0x30
	    struct FAIDataProviderFloatValue SpaceBetween; // 0xb0 Size: 0x30
	    struct FAIDataProviderIntValue NumberOfPoints; // 0xe0 Size: 0x30
	    EPointOnCircleSpacingMethod PointOnCircleSpacingMethod; // 0x110 Size: 0x1
	    char UnknownData0[0x7]; // 0x111
	    struct FEnvDirection ArcDirection; // 0x118 Size: 0x20
	    struct FAIDataProviderFloatValue ArcAngle; // 0x138 Size: 0x30
	    float AngleRadians; // 0x168 Size: 0x4
	    char UnknownData1[0x4]; // 0x16c
	    class UEnvQueryContext* CircleCenter; // 0x170 Size: 0x8
	    bool bIgnoreAnyContextActorsWhenGeneratingCircle; // 0x178 Size: 0x1
	    char UnknownData2[0x7]; // 0x179
	    struct FAIDataProviderFloatValue CircleCenterZOffset; // 0x180 Size: 0x30
	    struct FEnvTraceData TraceData; // 0x1b0 Size: 0x30
	    bool bDefineArc; // 0x1e0 Size: 0x1
	    char UnknownData3[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryGenerator_OnCircle");
			return (class UClass*)ptr;
		};

};

class UEnvQueryItemType : public UObject
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryItemType");
			return (class UClass*)ptr;
		};

};

class UEnvQueryItemType_VectorBase : public UEnvQueryItemType
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryItemType_VectorBase");
			return (class UClass*)ptr;
		};

};

class UEnvQueryItemType_ActorBase : public UEnvQueryItemType_VectorBase
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryItemType_ActorBase");
			return (class UClass*)ptr;
		};

};

class UEnvQueryItemType_Point : public UEnvQueryItemType_VectorBase
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryItemType_Point");
			return (class UClass*)ptr;
		};

};

class UEnvQueryTest : public UEnvQueryNode
{
	public:
	    int TestOrder; // 0x30 Size: 0x4
	    char TestPurpose; // 0x34 Size: 0x1
	    char UnknownData0[0x3]; // 0x35
	    struct FString TestComment; // 0x38 Size: 0x10
	    char MultipleContextFilterOp; // 0x48 Size: 0x1
	    char MultipleContextScoreOp; // 0x49 Size: 0x1
	    char FilterType; // 0x4a Size: 0x1
	    char UnknownData1[0x5]; // 0x4b
	    struct FAIDataProviderBoolValue BoolValue; // 0x50 Size: 0x30
	    struct FAIDataProviderFloatValue FloatValueMin; // 0x80 Size: 0x30
	    struct FAIDataProviderFloatValue FloatValueMax; // 0xb0 Size: 0x30
	    char UnknownData2[0x1]; // 0xe0
	    char ScoringEquation; // 0xe1 Size: 0x1
	    char ClampMinType; // 0xe2 Size: 0x1
	    char ClampMaxType; // 0xe3 Size: 0x1
	    EEQSNormalizationType NormalizationType; // 0xe4 Size: 0x1
	    char UnknownData3[0x3]; // 0xe5
	    struct FAIDataProviderFloatValue ScoreClampMin; // 0xe8 Size: 0x30
	    struct FAIDataProviderFloatValue ScoreClampMax; // 0x118 Size: 0x30
	    struct FAIDataProviderFloatValue ScoringFactor; // 0x148 Size: 0x30
	    struct FAIDataProviderFloatValue ReferenceValue; // 0x178 Size: 0x30
	    bool bDefineReferenceValue; // 0x1a8 Size: 0x1
	    bool bWorkOnFloatValues; // 0x1b8 Size: 0x1
	    char UnknownData4[0x16];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryTest");
			return (class UClass*)ptr;
		};

};

class UGenericTeamAgentInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.GenericTeamAgentInterface");
			return (class UClass*)ptr;
		};

};

class UAIAsyncTaskBlueprintProxy : public UObject
{
	public:
	    MulticastDelegateProperty OnSuccess; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnFail; // 0x38 Size: 0x10
	    char UnknownData0[0x48]; // 0x48
	    void OnMoveCompleted(struct FAIRequestID RequestId, char MovementResult); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AIAsyncTaskBlueprintProxy");
			return (class UClass*)ptr;
		};

};

class UAIBlueprintHelperLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void UnlockAIResourcesWithAnimation(class UAnimInstance* AnimInstance, bool bUnlockMovement, bool UnlockAILogic); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static class APawn* SpawnAIFromClass(class UObject* WorldContextObject, class APawn* PawnClass, class UBehaviorTree* BehaviorTree, struct FVector Location, struct FRotator Rotation, bool bNoCollisionFail); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static void SimpleMoveToLocation(class AController* Controller, struct FVector Goal); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static void SimpleMoveToActor(class AController* Controller, class AActor* Goal); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static void SendAIMessage(class APawn* Target, FName MESSAGE, class UObject* MessageSource, bool bSuccess); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static void LockAIResourcesWithAnimation(class UAnimInstance* AnimInstance, bool bLockMovement, bool LockAILogic); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static bool IsValidAIRotation(struct FRotator Rotation); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static bool IsValidAILocation(struct FVector Location); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static bool IsValidAIDirection(struct FVector DirectionVector); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static class UNavigationPath* GetCurrentPath(class AController* Controller); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static class UBlackboardComponent* GetBlackboard(class AActor* Target); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static class AAIController* GetAIController(class AActor* ControlledActor); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    static class UAIAsyncTaskBlueprintProxy* CreateMoveToProxyObject(class UObject* WorldContextObject, class APawn* Pawn, struct FVector Destination, class AActor* TargetActor, float AcceptanceRadius, bool bStopOnOverlap); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AIBlueprintHelperLibrary");
			return (class UClass*)ptr;
		};

};

class UAIDataProvider_QueryParams : public UAIDataProvider
{
	public:
	    FName ParamName; // 0x28 Size: 0x8
	    float FloatValue; // 0x30 Size: 0x4
	    int IntValue; // 0x34 Size: 0x4
	    bool BoolValue; // 0x38 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AIDataProvider_QueryParams");
			return (class UClass*)ptr;
		};

};

class UAIDataProvider_Random : public UAIDataProvider_QueryParams
{
	public:
	    float Min; // 0x40 Size: 0x4
	    float Max; // 0x44 Size: 0x4
	    bool bInteger; // 0x48 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AIDataProvider_Random");
			return (class UClass*)ptr;
		};

};

class UAIPerceptionListenerInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AIPerceptionListenerInterface");
			return (class UClass*)ptr;
		};

};

class UAIPerceptionStimuliSourceComponent : public UActorComponent
{
	public:
	    bool bAutoRegisterAsSource; // 0xf8 Size: 0x1
	    char UnknownData0[0x7]; // 0xf9
	    TArray<class UAISense*> RegisterAsSourceForSenses; // 0x100 Size: 0x10
	    char UnknownData1[0x110]; // 0x110
	    void UnregisterFromSense(class UAISense* SenseClass); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void UnregisterFromPerceptionSystem(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void RegisterWithPerceptionSystem(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void RegisterForSense(class UAISense* SenseClass); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7ed1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AIPerceptionStimuliSourceComponent");
			return (class UClass*)ptr;
		};

};

class UAIResourceInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AIResourceInterface");
			return (class UClass*)ptr;
		};

};

class UAIResource_Movement : public UGameplayTaskResource
{
	public:
	    char UnknownData0[0x38];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AIResource_Movement");
			return (class UClass*)ptr;
		};

};

class UAIResource_Logic : public UGameplayTaskResource
{
	public:
	    char UnknownData0[0x38];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AIResource_Logic");
			return (class UClass*)ptr;
		};

};

class UAISense_Blueprint : public UAISense
{
	public:
	    class UUserDefinedStruct* ListenerDataType; // 0x80 Size: 0x8
	    TArray<class UAIPerceptionComponent*> ListenerContainer; // 0x88 Size: 0x10
	    TArray<class UAISenseEvent*> UnprocessedEvents; // 0x98 Size: 0x10
	    char UnknownData0[0xa8]; // 0xa8
	    float OnUpdate(TArray<class UAISenseEvent*> EventsToProcess); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnListenerUpdated(class AActor* ActorListener, class UAIPerceptionComponent* PerceptionComponent); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnListenerUnregistered(class AActor* ActorListener, class UAIPerceptionComponent* PerceptionComponent); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnListenerRegistered(class AActor* ActorListener, class UAIPerceptionComponent* PerceptionComponent); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void K2_OnNewPawn(class APawn* NewPawn); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void GetAllListenerComponents(TArray<class UAIPerceptionComponent*> ListenerComponents); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void GetAllListenerActors(TArray<class AActor*> ListenerActors); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7f39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AISense_Blueprint");
			return (class UClass*)ptr;
		};

};

class UAISense_Damage : public UAISense
{
	public:
	    TArray<struct FAIDamageEvent> RegisteredEvents; // 0x80 Size: 0x10
	    char UnknownData0[0x90]; // 0x90
	    static void ReportDamageEvent(class UObject* WorldContextObject, class AActor* DamagedActor, class AActor* Instigator, float DamageAmount, struct FVector EventLocation, struct FVector HitLocation); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AISense_Damage");
			return (class UClass*)ptr;
		};

};

class UAISense_Prediction : public UAISense
{
	public:
	    TArray<struct FAIPredictionEvent> RegisteredEvents; // 0x80 Size: 0x10
	    char UnknownData0[0x90]; // 0x90
	    static void RequestPawnPredictionEvent(class APawn* Requestor, class AActor* PredictedActor, float PredictionTime); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static void RequestControllerPredictionEvent(class AAIController* Requestor, class AActor* PredictedActor, float PredictionTime); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AISense_Prediction");
			return (class UClass*)ptr;
		};

};

class UAISense_Sight : public UAISense
{
	public:
	    char UnknownData0[0xb0];
	    int MaxTracesPerTick; // 0x130 Size: 0x4
	    int MinQueriesPerTimeSliceCheck; // 0x134 Size: 0x4
	    double MaxTimeSlicePerTick; // 0x138 Size: 0x8
	    float HighImportanceQueryDistanceThreshold; // 0x140 Size: 0x4
	    char UnknownData1[0x4]; // 0x144
	    float MaxQueryImportance; // 0x148 Size: 0x4
	    float SightLimitQueryImportance; // 0x14c Size: 0x4
	    char UnknownData2[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AISense_Sight");
			return (class UClass*)ptr;
		};

};

class UAISense_Team : public UAISense
{
	public:
	    TArray<struct FAITeamStimulusEvent> RegisteredEvents; // 0x80 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AISense_Team");
			return (class UClass*)ptr;
		};

};

class UAISense_Touch : public UAISense
{
	public:
	    TArray<struct FAITouchEvent> RegisteredEvents; // 0x80 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AISense_Touch");
			return (class UClass*)ptr;
		};

};

class UAISenseBlueprintListener : public UUserDefinedStruct
{
	public:
	    char UnknownData0[0xf0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AISenseBlueprintListener");
			return (class UClass*)ptr;
		};

};

class UAISenseConfig : public UObject
{
	public:
	    struct FColor DebugColor; // 0x28 Size: 0x4
	    float MaxAge; // 0x2c Size: 0x4
	    bool bStartsEnabled; // 0x30 Size: 0x1
	    char UnknownData0[0x17];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AISenseConfig");
			return (class UClass*)ptr;
		};

};

class UAISenseConfig_Blueprint : public UAISenseConfig
{
	public:
	    class UAISense_Blueprint* Implementation; // 0x48 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AISenseConfig_Blueprint");
			return (class UClass*)ptr;
		};

};

class UAISenseConfig_Damage : public UAISenseConfig
{
	public:
	    class UAISense_Damage* Implementation; // 0x48 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AISenseConfig_Damage");
			return (class UClass*)ptr;
		};

};

class UAISenseConfig_Hearing : public UAISenseConfig
{
	public:
	    class UAISense_Hearing* Implementation; // 0x48 Size: 0x8
	    float HearingRange; // 0x50 Size: 0x4
	    float LoSHearingRange; // 0x54 Size: 0x4
	    bool bUseLoSHearing; // 0x58 Size: 0x1
	    char UnknownData0[0x3]; // 0x59
	    struct FAISenseAffiliationFilter DetectionByAffiliation; // 0x5c Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AISenseConfig_Hearing");
			return (class UClass*)ptr;
		};

};

class UAISenseConfig_Prediction : public UAISenseConfig
{
	public:
	    char UnknownData0[0x48];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AISenseConfig_Prediction");
			return (class UClass*)ptr;
		};

};

class UAISenseConfig_Sight : public UAISenseConfig
{
	public:
	    class UAISense_Sight* Implementation; // 0x48 Size: 0x8
	    float SightRadius; // 0x50 Size: 0x4
	    float LoseSightRadius; // 0x54 Size: 0x4
	    float PeripheralVisionAngleDegrees; // 0x58 Size: 0x4
	    struct FAISenseAffiliationFilter DetectionByAffiliation; // 0x5c Size: 0x4
	    float AutoSuccessRangeFromLastSeenLocation; // 0x60 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AISenseConfig_Sight");
			return (class UClass*)ptr;
		};

};

class UAISenseConfig_Team : public UAISenseConfig
{
	public:
	    char UnknownData0[0x48];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AISenseConfig_Team");
			return (class UClass*)ptr;
		};

};

class UAISenseConfig_Touch : public UAISenseConfig
{
	public:
	    char UnknownData0[0x48];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AISenseConfig_Touch");
			return (class UClass*)ptr;
		};

};

class UAISenseEvent : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AISenseEvent");
			return (class UClass*)ptr;
		};

};

class UAISenseEvent_Damage : public UAISenseEvent
{
	public:
	    struct FAIDamageEvent Event; // 0x28 Size: 0x30

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AISenseEvent_Damage");
			return (class UClass*)ptr;
		};

};

class UAISenseEvent_Hearing : public UAISenseEvent
{
	public:
	    struct FAINoiseEvent Event; // 0x28 Size: 0x30

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AISenseEvent_Hearing");
			return (class UClass*)ptr;
		};

};

class UAISightTargetInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AISightTargetInterface");
			return (class UClass*)ptr;
		};

};

class UAITask_LockLogic : public UAITask
{
	public:
	    char UnknownData0[0x70];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AITask_LockLogic");
			return (class UClass*)ptr;
		};

};

class UAITask_RunEQS : public UAITask
{
	public:
	    static class UAITask_RunEQS* RunEQS(class AAIController* Controller, class UEnvQuery* QueryTemplate); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7ef9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.AITask_RunEQS");
			return (class UClass*)ptr;
		};

};

class UBehaviorTree : public UObject
{
	public:
	    class UBTCompositeNode* RootNode; // 0x28 Size: 0x8
	    class UBlackboardData* BlackboardAsset; // 0x30 Size: 0x8
	    TArray<class UBTDecorator*> RootDecorators; // 0x38 Size: 0x10
	    TArray<struct FBTDecoratorLogic> RootDecoratorOps; // 0x48 Size: 0x10
	    char UnknownData0[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BehaviorTree");
			return (class UClass*)ptr;
		};

};

class UBehaviorTreeManager : public UObject
{
	public:
	    int MaxDebuggerSteps; // 0x28 Size: 0x4
	    char UnknownData0[0x4]; // 0x2c
	    TArray<struct FBehaviorTreeTemplateInfo> LoadedTemplates; // 0x30 Size: 0x10
	    TArray<class UBehaviorTreeComponent*> ActiveComponents; // 0x40 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BehaviorTreeManager");
			return (class UClass*)ptr;
		};

};

class UBehaviorTreeTypes : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BehaviorTreeTypes");
			return (class UClass*)ptr;
		};

};

class UBlackboardComponent : public UActorComponent
{
	public:
	    class UBrainComponent* BrainComp; // 0xf8 Size: 0x8
	    class UBlackboardData* BlackboardAsset; // 0x100 Size: 0x8
	    char UnknownData0[0x20]; // 0x108
	    TArray<class UBlackboardKeyType*> KeyInstances; // 0x128 Size: 0x10
	    char UnknownData1[0x138]; // 0x138
	    void SetValueAsVector(FName KeyName, struct FVector VectorValue); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetValueAsString(FName KeyName, struct FString StringValue); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetValueAsRotator(FName KeyName, struct FRotator VectorValue); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetValueAsObject(FName KeyName, class UObject* ObjectValue); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetValueAsName(FName KeyName, FName NameValue); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetValueAsInt(FName KeyName, int IntValue); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetValueAsFloat(FName KeyName, float FloatValue); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetValueAsEnum(FName KeyName, char EnumValue); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetValueAsClass(FName KeyName, class UObject* ClassValue); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetValueAsBool(FName KeyName, bool BoolValue); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    bool IsVectorValueSet(FName KeyName); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    struct FVector GetValueAsVector(FName KeyName); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    struct FString GetValueAsString(FName KeyName); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    struct FRotator GetValueAsRotator(FName KeyName); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    class UObject* GetValueAsObject(FName KeyName); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    FName GetValueAsName(FName KeyName); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    int GetValueAsInt(FName KeyName); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    float GetValueAsFloat(FName KeyName); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    char GetValueAsEnum(FName KeyName); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    class UObject* GetValueAsClass(FName KeyName); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    bool GetValueAsBool(FName KeyName); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    bool GetRotationFromEntry(FName KeyName, struct FRotator ResultRotation); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    bool GetLocationFromEntry(FName KeyName, struct FVector ResultLocation); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void ClearValue(FName KeyName); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x-7df1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BlackboardComponent");
			return (class UClass*)ptr;
		};

};

class UBlackboardData : public UDataAsset
{
	public:
	    class UBlackboardData* Parent; // 0x30 Size: 0x8
	    TArray<struct FBlackboardEntry> Keys; // 0x38 Size: 0x10
	    bool bHasSynchronizedKeys; // 0x48 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BlackboardData");
			return (class UClass*)ptr;
		};

};

class UBlackboardKeyType : public UObject
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BlackboardKeyType");
			return (class UClass*)ptr;
		};

};

class UBlackboardKeyType_Bool : public UBlackboardKeyType
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BlackboardKeyType_Bool");
			return (class UClass*)ptr;
		};

};

class UBlackboardKeyType_Class : public UBlackboardKeyType
{
	public:
	    class UObject* BASEClass; // 0x30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BlackboardKeyType_Class");
			return (class UClass*)ptr;
		};

};

class UBlackboardKeyType_Enum : public UBlackboardKeyType
{
	public:
	    class UEnum* EnumType; // 0x30 Size: 0x8
	    struct FString EnumName; // 0x38 Size: 0x10
	    bool bIsEnumNameValid; // 0x48 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BlackboardKeyType_Enum");
			return (class UClass*)ptr;
		};

};

class UBlackboardKeyType_Float : public UBlackboardKeyType
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BlackboardKeyType_Float");
			return (class UClass*)ptr;
		};

};

class UBlackboardKeyType_Int : public UBlackboardKeyType
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BlackboardKeyType_Int");
			return (class UClass*)ptr;
		};

};

class UBlackboardKeyType_Name : public UBlackboardKeyType
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BlackboardKeyType_Name");
			return (class UClass*)ptr;
		};

};

class UBlackboardKeyType_NativeEnum : public UBlackboardKeyType
{
	public:
	    struct FString EnumName; // 0x30 Size: 0x10
	    class UEnum* EnumType; // 0x40 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BlackboardKeyType_NativeEnum");
			return (class UClass*)ptr;
		};

};

class UBlackboardKeyType_Object : public UBlackboardKeyType
{
	public:
	    class UObject* BASEClass; // 0x30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BlackboardKeyType_Object");
			return (class UClass*)ptr;
		};

};

class UBlackboardKeyType_Rotator : public UBlackboardKeyType
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BlackboardKeyType_Rotator");
			return (class UClass*)ptr;
		};

};

class UBlackboardKeyType_String : public UBlackboardKeyType
{
	public:
	    struct FString StringValue; // 0x30 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BlackboardKeyType_String");
			return (class UClass*)ptr;
		};

};

class UBlackboardKeyType_Vector : public UBlackboardKeyType
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BlackboardKeyType_Vector");
			return (class UClass*)ptr;
		};

};

class UBTCompositeNode : public UBTNode
{
	public:
	    TArray<struct FBTCompositeChild> Children; // 0x58 Size: 0x10
	    TArray<class UBTService*> Services; // 0x68 Size: 0x10
	    bool bApplyDecoratorScope; // 0x88 Size: 0x1
	    char UnknownData0[0x17];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTCompositeNode");
			return (class UClass*)ptr;
		};

};

class UBTComposite_Selector : public UBTCompositeNode
{
	public:
	    char UnknownData0[0x90];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTComposite_Selector");
			return (class UClass*)ptr;
		};

};

class UBTComposite_Sequence : public UBTCompositeNode
{
	public:
	    char UnknownData0[0x90];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTComposite_Sequence");
			return (class UClass*)ptr;
		};

};

class UBTComposite_SimpleParallel : public UBTCompositeNode
{
	public:
	    char FinishMode; // 0x90 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTComposite_SimpleParallel");
			return (class UClass*)ptr;
		};

};

class UBTDecorator_Blackboard : public UBTDecorator_BlackboardBase
{
	public:
	    int IntValue; // 0x90 Size: 0x4
	    float FloatValue; // 0x94 Size: 0x4
	    struct FString StringValue; // 0x98 Size: 0x10
	    struct FString CachedDescription; // 0xa8 Size: 0x10
	    char OperationType; // 0xb8 Size: 0x1
	    char NotifyObserver; // 0xb9 Size: 0x1
	    char UnknownData0[0x6];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTDecorator_Blackboard");
			return (class UClass*)ptr;
		};

};

class UBTDecorator_BlueprintBase : public UBTDecorator
{
	public:
	    class AAIController* AIOwner; // 0x68 Size: 0x8
	    class AActor* ActorOwner; // 0x70 Size: 0x8
	    TArray<FName> ObservedKeyNames; // 0x78 Size: 0x10
	    bool bShowPropertyDetails; // 0x98 Size: 0x1
	    bool bCheckConditionOnlyBlackBoardChanges; // 0x98 Size: 0x1
	    bool bIsObservingBB; // 0x98 Size: 0x1
	    char UnknownData0[0x8b]; // 0x8b
	    void ReceiveTickAI(class AAIController* OwnerController, class APawn* ControlledPawn, float DeltaSeconds); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void ReceiveTick(class AActor* OwnerActor, float DeltaSeconds); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void ReceiveObserverDeactivatedAI(class AAIController* OwnerController, class APawn* ControlledPawn); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void ReceiveObserverDeactivated(class AActor* OwnerActor); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void ReceiveObserverActivatedAI(class AAIController* OwnerController, class APawn* ControlledPawn); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ReceiveObserverActivated(class AActor* OwnerActor); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ReceiveExecutionStartAI(class AAIController* OwnerController, class APawn* ControlledPawn); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void ReceiveExecutionStart(class AActor* OwnerActor); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void ReceiveExecutionFinishAI(class AAIController* OwnerController, class APawn* ControlledPawn, char NodeResult); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void ReceiveExecutionFinish(class AActor* OwnerActor, char NodeResult); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    bool PerformConditionCheckAI(class AAIController* OwnerController, class APawn* ControlledPawn); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    bool PerformConditionCheck(class AActor* OwnerActor); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    bool IsDecoratorObserverActive(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    bool IsDecoratorExecutionActive(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x-7f41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTDecorator_BlueprintBase");
			return (class UClass*)ptr;
		};

};

class UBTDecorator_CheckGameplayTagsOnActor : public UBTDecorator
{
	public:
	    struct FBlackboardKeySelector ActorToCheck; // 0x68 Size: 0x28
	    EGameplayContainerMatchType TagsToMatch; // 0x90 Size: 0x1
	    char UnknownData0[0x7]; // 0x91
	    struct FGameplayTagContainer GameplayTags; // 0x98 Size: 0x20
	    struct FString CachedDescription; // 0xb8 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTDecorator_CheckGameplayTagsOnActor");
			return (class UClass*)ptr;
		};

};

class UBTDecorator_CompareBBEntries : public UBTDecorator
{
	public:
	    char Operator; // 0x68 Size: 0x1
	    char UnknownData0[0x7]; // 0x69
	    struct FBlackboardKeySelector BlackboardKeyA; // 0x70 Size: 0x28
	    struct FBlackboardKeySelector BlackboardKeyB; // 0x98 Size: 0x28

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTDecorator_CompareBBEntries");
			return (class UClass*)ptr;
		};

};

class UBTDecorator_ConditionalLoop : public UBTDecorator_Blackboard
{
	public:
	    char UnknownData0[0xc0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTDecorator_ConditionalLoop");
			return (class UClass*)ptr;
		};

};

class UBTDecorator_ConeCheck : public UBTDecorator
{
	public:
	    float ConeHalfAngle; // 0x68 Size: 0x4
	    char UnknownData0[0x4]; // 0x6c
	    struct FBlackboardKeySelector ConeOrigin; // 0x70 Size: 0x28
	    struct FBlackboardKeySelector ConeDirection; // 0x98 Size: 0x28
	    struct FBlackboardKeySelector Observed; // 0xc0 Size: 0x28
	    char UnknownData1[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTDecorator_ConeCheck");
			return (class UClass*)ptr;
		};

};

class UBTDecorator_Cooldown : public UBTDecorator
{
	public:
	    float CoolDownTime; // 0x68 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTDecorator_Cooldown");
			return (class UClass*)ptr;
		};

};

class UBTDecorator_DoesPathExist : public UBTDecorator
{
	public:
	    struct FBlackboardKeySelector BlackboardKeyA; // 0x68 Size: 0x28
	    struct FBlackboardKeySelector BlackboardKeyB; // 0x90 Size: 0x28
	    bool bUseSelf; // 0xb8 Size: 0x1
	    char UnknownData0[0x3]; // 0xb9
	    char PathQueryType; // 0xbc Size: 0x1
	    char UnknownData1[0x3]; // 0xbd
	    class UNavigationQueryFilter* FilterClass; // 0xc0 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTDecorator_DoesPathExist");
			return (class UClass*)ptr;
		};

};

class UBTDecorator_ForceSuccess : public UBTDecorator
{
	public:
	    char UnknownData0[0x68];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTDecorator_ForceSuccess");
			return (class UClass*)ptr;
		};

};

class UBTDecorator_IsAtLocation : public UBTDecorator_BlackboardBase
{
	public:
	    float AcceptableRadius; // 0x90 Size: 0x4
	    char UnknownData0[0x4]; // 0x94
	    struct FAIDataProviderFloatValue ParametrizedAcceptableRadius; // 0x98 Size: 0x30
	    FAIDistanceType GeometricDistanceType; // 0xc8 Size: 0x1
	    bool bUseParametrizedRadius; // 0xcc Size: 0x1
	    bool bUseNavAgentGoalLocation; // 0xcc Size: 0x1
	    bool bPathFindingBasedTest; // 0xcc Size: 0x1
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTDecorator_IsAtLocation");
			return (class UClass*)ptr;
		};

};

class UBTDecorator_IsBBEntryOfClass : public UBTDecorator_BlackboardBase
{
	public:
	    class UObject* TestClass; // 0x90 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTDecorator_IsBBEntryOfClass");
			return (class UClass*)ptr;
		};

};

class UBTDecorator_KeepInCone : public UBTDecorator
{
	public:
	    float ConeHalfAngle; // 0x68 Size: 0x4
	    char UnknownData0[0x4]; // 0x6c
	    struct FBlackboardKeySelector ConeOrigin; // 0x70 Size: 0x28
	    struct FBlackboardKeySelector Observed; // 0x98 Size: 0x28
	    bool bUseSelfAsOrigin; // 0xc0 Size: 0x1
	    bool bUseSelfAsObserved; // 0xc0 Size: 0x1
	    char UnknownData1[0x6];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTDecorator_KeepInCone");
			return (class UClass*)ptr;
		};

};

class UBTDecorator_Loop : public UBTDecorator
{
	public:
	    int NumLoops; // 0x68 Size: 0x4
	    bool bInfiniteLoop; // 0x6c Size: 0x1
	    char UnknownData0[0x3]; // 0x6d
	    float InfiniteLoopTimeoutTime; // 0x70 Size: 0x4
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTDecorator_Loop");
			return (class UClass*)ptr;
		};

};

class UBTDecorator_ReachedMoveGoal : public UBTDecorator
{
	public:
	    char UnknownData0[0x68];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTDecorator_ReachedMoveGoal");
			return (class UClass*)ptr;
		};

};

class UBTDecorator_SetTagCooldown : public UBTDecorator
{
	public:
	    struct FGameplayTag CooldownTag; // 0x68 Size: 0x8
	    float CooldownDuration; // 0x70 Size: 0x4
	    bool bAddToExistingDuration; // 0x74 Size: 0x1
	    char UnknownData0[0x3];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTDecorator_SetTagCooldown");
			return (class UClass*)ptr;
		};

};

class UBTDecorator_TagCooldown : public UBTDecorator
{
	public:
	    struct FGameplayTag CooldownTag; // 0x68 Size: 0x8
	    float CooldownDuration; // 0x70 Size: 0x4
	    bool bAddToExistingDuration; // 0x74 Size: 0x1
	    bool bActivatesCooldown; // 0x75 Size: 0x1
	    char UnknownData0[0x2];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTDecorator_TagCooldown");
			return (class UClass*)ptr;
		};

};

class UBTDecorator_TimeLimit : public UBTDecorator
{
	public:
	    float TimeLimit; // 0x68 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTDecorator_TimeLimit");
			return (class UClass*)ptr;
		};

};

class UBTFunctionLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void StopUsingExternalEvent(class UBTNode* NodeOwner); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void StartUsingExternalEvent(class UBTNode* NodeOwner, class AActor* OwningActor); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static void SetBlackboardValueAsVector(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key, struct FVector Value); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static void SetBlackboardValueAsString(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key, struct FString Value); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static void SetBlackboardValueAsRotator(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key, struct FRotator Value); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static void SetBlackboardValueAsObject(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key, class UObject* Value); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static void SetBlackboardValueAsName(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key, FName Value); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static void SetBlackboardValueAsInt(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key, int Value); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static void SetBlackboardValueAsFloat(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key, float Value); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static void SetBlackboardValueAsEnum(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key, char Value); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static void SetBlackboardValueAsClass(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key, class UObject* Value); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static void SetBlackboardValueAsBool(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key, bool Value); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    static class UBlackboardComponent* GetOwnersBlackboard(class UBTNode* NodeOwner); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    static class UBehaviorTreeComponent* GetOwnerComponent(class UBTNode* NodeOwner); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    static struct FVector GetBlackboardValueAsVector(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    static struct FString GetBlackboardValueAsString(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    static struct FRotator GetBlackboardValueAsRotator(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    static class UObject* GetBlackboardValueAsObject(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    static FName GetBlackboardValueAsName(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    static int GetBlackboardValueAsInt(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    static float GetBlackboardValueAsFloat(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    static char GetBlackboardValueAsEnum(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    static class UObject* GetBlackboardValueAsClass(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    static bool GetBlackboardValueAsBool(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    static class AActor* GetBlackboardValueAsActor(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    static void ClearBlackboardValueAsVector(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    static void ClearBlackboardValue(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTFunctionLibrary");
			return (class UClass*)ptr;
		};

};

class UBTService_BlueprintBase : public UBTService
{
	public:
	    class AAIController* AIOwner; // 0x70 Size: 0x8
	    class AActor* ActorOwner; // 0x78 Size: 0x8
	    bool bShowPropertyDetails; // 0x90 Size: 0x1
	    bool bShowEventDetails; // 0x90 Size: 0x1
	    char UnknownData0[0x82]; // 0x82
	    void ReceiveTickAI(class AAIController* OwnerController, class APawn* ControlledPawn, float DeltaSeconds); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void ReceiveTick(class AActor* OwnerActor, float DeltaSeconds); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void ReceiveSearchStartAI(class AAIController* OwnerController, class APawn* ControlledPawn); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void ReceiveSearchStart(class AActor* OwnerActor); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void ReceiveDeactivationAI(class AAIController* OwnerController, class APawn* ControlledPawn); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ReceiveDeactivation(class AActor* OwnerActor); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ReceiveActivationAI(class AAIController* OwnerController, class APawn* ControlledPawn); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void ReceiveActivation(class AActor* OwnerActor); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool IsServiceActive(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7f49];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTService_BlueprintBase");
			return (class UClass*)ptr;
		};

};

class UBTService_DefaultFocus : public UBTService_BlackboardBase
{
	public:
	    char FocusPriority; // 0x98 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTService_DefaultFocus");
			return (class UClass*)ptr;
		};

};

class UBTService_RunEQS : public UBTService_BlackboardBase
{
	public:
	    struct FEQSParametrizedQueryExecutionRequest EQSRequest; // 0x98 Size: 0x48
	    char UnknownData0[0x10];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTService_RunEQS");
			return (class UClass*)ptr;
		};

};

class UBTTask_BlueprintBase : public UBTTaskNode
{
	public:
	    class AAIController* AIOwner; // 0x70 Size: 0x8
	    class AActor* ActorOwner; // 0x78 Size: 0x8
	    bool bShowPropertyDetails; // 0x98 Size: 0x1
	    char UnknownData0[0x81]; // 0x81
	    void SetFinishOnMessageWithId(FName MessageName, int RequestId); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetFinishOnMessage(FName MessageName); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void ReceiveTickAI(class AAIController* OwnerController, class APawn* ControlledPawn, float DeltaSeconds); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void ReceiveTick(class AActor* OwnerActor, float DeltaSeconds); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ReceiveExecute(class AActor* OwnerActor); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ReceiveAbortAI(class AAIController* OwnerController, class APawn* ControlledPawn); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void ReceiveAbort(class AActor* OwnerActor); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool IsTaskExecuting(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool IsTaskAborting(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void FinishExecute(bool bSuccess); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void FinishAbort(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7f41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTTask_BlueprintBase");
			return (class UClass*)ptr;
		};

};

class UBTTask_FinishWithResult : public UBTTaskNode
{
	public:
	    char Result; // 0x70 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTTask_FinishWithResult");
			return (class UClass*)ptr;
		};

};

class UBTTask_MakeNoise : public UBTTaskNode
{
	public:
	    float Loudnes; // 0x70 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTTask_MakeNoise");
			return (class UClass*)ptr;
		};

};

class UBTTask_MoveDirectlyToward : public UBTTask_MoveTo
{
	public:
	    bool bDisablePathUpdateOnGoalLocationChange; // 0xb0 Size: 0x1
	    bool bProjectVectorGoalToNavigation; // 0xb0 Size: 0x1
	    bool bUpdatedDeprecatedProperties; // 0xb0 Size: 0x1
	    char UnknownData0[0x5];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTTask_MoveDirectlyToward");
			return (class UClass*)ptr;
		};

};

class UBTTask_PawnActionBase : public UBTTaskNode
{
	public:
	    char UnknownData0[0x70];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTTask_PawnActionBase");
			return (class UClass*)ptr;
		};

};

class UBTTask_PlayAnimation : public UBTTaskNode
{
	public:
	    class UAnimationAsset* AnimationToPlay; // 0x70 Size: 0x8
	    bool bLooping; // 0x78 Size: 0x1
	    bool bNonBlocking; // 0x78 Size: 0x1
	    char UnknownData0[0x6]; // 0x7a
	    class UBehaviorTreeComponent* MyOwnerComp; // 0x80 Size: 0x8
	    class USkeletalMeshComponent* CachedSkelMesh; // 0x88 Size: 0x8
	    char UnknownData1[0x20];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTTask_PlayAnimation");
			return (class UClass*)ptr;
		};

};

class UBTTask_PlaySound : public UBTTaskNode
{
	public:
	    class USoundCue* SoundToPlay; // 0x70 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTTask_PlaySound");
			return (class UClass*)ptr;
		};

};

class UBTTask_PushPawnAction : public UBTTask_PawnActionBase
{
	public:
	    class UPawnAction* Action; // 0x70 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTTask_PushPawnAction");
			return (class UClass*)ptr;
		};

};

class UBTTask_RotateToFaceBBEntry : public UBTTask_BlackboardBase
{
	public:
	    float Precision; // 0x98 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTTask_RotateToFaceBBEntry");
			return (class UClass*)ptr;
		};

};

class UBTTask_RunBehavior : public UBTTaskNode
{
	public:
	    class UBehaviorTree* BehaviorAsset; // 0x70 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTTask_RunBehavior");
			return (class UClass*)ptr;
		};

};

class UBTTask_RunBehaviorDynamic : public UBTTaskNode
{
	public:
	    struct FGameplayTag InjectionTag; // 0x70 Size: 0x8
	    class UBehaviorTree* DefaultBehaviorAsset; // 0x78 Size: 0x8
	    class UBehaviorTree* BehaviorAsset; // 0x80 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTTask_RunBehaviorDynamic");
			return (class UClass*)ptr;
		};

};

class UBTTask_RunEQSQuery : public UBTTask_BlackboardBase
{
	public:
	    class UEnvQuery* QueryTemplate; // 0x98 Size: 0x8
	    TArray<struct FEnvNamedValue> QueryParams; // 0xa0 Size: 0x10
	    TArray<struct FAIDynamicParam> QueryConfig; // 0xb0 Size: 0x10
	    char RunMode; // 0xc0 Size: 0x1
	    char UnknownData0[0x7]; // 0xc1
	    struct FBlackboardKeySelector EQSQueryBlackboardKey; // 0xc8 Size: 0x28
	    bool bUseBBKey; // 0xf0 Size: 0x1
	    char UnknownData1[0x7]; // 0xf1
	    struct FEQSParametrizedQueryExecutionRequest EQSRequest; // 0xf8 Size: 0x48
	    char UnknownData2[0x10];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTTask_RunEQSQuery");
			return (class UClass*)ptr;
		};

};

class UBTTask_SetTagCooldown : public UBTTaskNode
{
	public:
	    struct FGameplayTag CooldownTag; // 0x70 Size: 0x8
	    bool bAddToExistingDuration; // 0x78 Size: 0x1
	    char UnknownData0[0x3]; // 0x79
	    float CooldownDuration; // 0x7c Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTTask_SetTagCooldown");
			return (class UClass*)ptr;
		};

};

class UBTTask_Wait : public UBTTaskNode
{
	public:
	    float WaitTime; // 0x70 Size: 0x4
	    float RandomDeviation; // 0x74 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTTask_Wait");
			return (class UClass*)ptr;
		};

};

class UBTTask_WaitBlackboardTime : public UBTTask_Wait
{
	public:
	    struct FBlackboardKeySelector BlackboardKey; // 0x78 Size: 0x28

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.BTTask_WaitBlackboardTime");
			return (class UClass*)ptr;
		};

};

class UCrowdAgentInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.CrowdAgentInterface");
			return (class UClass*)ptr;
		};

};

class ADetourCrowdAIController : public AAIController
{
	public:
	    char UnknownData0[0x440];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.DetourCrowdAIController");
			return (class UClass*)ptr;
		};

};

class UEnvQuery : public UDataAsset
{
	public:
	    FName QueryName; // 0x30 Size: 0x8
	    TArray<class UEnvQueryOption*> Options; // 0x38 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQuery");
			return (class UClass*)ptr;
		};

};

class UEnvQueryContext_BlueprintBase : public UEnvQueryContext
{
	public:
	    void ProvideSingleLocation(class UObject* QuerierObject, class AActor* QuerierActor, struct FVector ResultingLocation); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void ProvideSingleActor(class UObject* QuerierObject, class AActor* QuerierActor, class AActor* ResultingActor); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void ProvideLocationsSet(class UObject* QuerierObject, class AActor* QuerierActor, TArray<struct FVector> ResultingLocationSet); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void ProvideActorsSet(class UObject* QuerierObject, class AActor* QuerierActor, TArray<class AActor*> ResultingActorsSet); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7fb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryContext_BlueprintBase");
			return (class UClass*)ptr;
		};

};

class UEnvQueryContext_Item : public UEnvQueryContext
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryContext_Item");
			return (class UClass*)ptr;
		};

};

class UEnvQueryContext_Querier : public UEnvQueryContext
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryContext_Querier");
			return (class UClass*)ptr;
		};

};

class UEnvQueryDebugHelpers : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryDebugHelpers");
			return (class UClass*)ptr;
		};

};

class UEnvQueryGenerator_BlueprintBase : public UEnvQueryGenerator
{
	public:
	    struct FText GeneratorsActionDescription; // 0x50 Size: 0x18
	    class UEnvQueryContext* Context; // 0x68 Size: 0x8
	    class UEnvQueryItemType* GeneratedItemType; // 0x70 Size: 0x8
	    char UnknownData0[0x78]; // 0x78
	    class UObject* GetQuerier(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void DoItemGeneration(TArray<struct FVector> ContextLocations); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void AddGeneratedVector(struct FVector GeneratedVector); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void AddGeneratedActor(class AActor* GeneratedActor); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7f61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryGenerator_BlueprintBase");
			return (class UClass*)ptr;
		};

};

class UEnvQueryGenerator_Composite : public UEnvQueryGenerator
{
	public:
	    TArray<class UEnvQueryGenerator*> Generators; // 0x50 Size: 0x10
	    bool bAllowDifferentItemTypes; // 0x60 Size: 0x1
	    bool bHasMatchingItemType; // 0x60 Size: 0x1
	    char UnknownData0[0x6]; // 0x62
	    class UEnvQueryItemType* ForcedItemType; // 0x68 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryGenerator_Composite");
			return (class UClass*)ptr;
		};

};

class UEnvQueryGenerator_Cone : public UEnvQueryGenerator_ProjectedPoints
{
	public:
	    struct FAIDataProviderFloatValue AlignedPointsDistance; // 0x80 Size: 0x30
	    struct FAIDataProviderFloatValue ConeDegrees; // 0xb0 Size: 0x30
	    struct FAIDataProviderFloatValue AngleStep; // 0xe0 Size: 0x30
	    struct FAIDataProviderFloatValue Range; // 0x110 Size: 0x30
	    class UEnvQueryContext* CenterActor; // 0x140 Size: 0x8
	    bool bIncludeContextLocation; // 0x148 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryGenerator_Cone");
			return (class UClass*)ptr;
		};

};

class UEnvQueryGenerator_CurrentLocation : public UEnvQueryGenerator
{
	public:
	    class UEnvQueryContext* QueryContext; // 0x50 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryGenerator_CurrentLocation");
			return (class UClass*)ptr;
		};

};

class UEnvQueryGenerator_Donut : public UEnvQueryGenerator_ProjectedPoints
{
	public:
	    struct FAIDataProviderFloatValue InnerRadius; // 0x80 Size: 0x30
	    struct FAIDataProviderFloatValue OuterRadius; // 0xb0 Size: 0x30
	    struct FAIDataProviderIntValue NumberOfRings; // 0xe0 Size: 0x30
	    struct FAIDataProviderIntValue PointsPerRing; // 0x110 Size: 0x30
	    struct FEnvDirection ArcDirection; // 0x140 Size: 0x20
	    struct FAIDataProviderFloatValue ArcAngle; // 0x160 Size: 0x30
	    bool bUseSpiralPattern; // 0x190 Size: 0x1
	    char UnknownData0[0x7]; // 0x191
	    class UEnvQueryContext* Center; // 0x198 Size: 0x8
	    bool bDefineArc; // 0x1a0 Size: 0x1
	    char UnknownData1[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryGenerator_Donut");
			return (class UClass*)ptr;
		};

};

class UEnvQueryGenerator_SimpleGrid : public UEnvQueryGenerator_ProjectedPoints
{
	public:
	    struct FAIDataProviderFloatValue GridSize; // 0x80 Size: 0x30
	    struct FAIDataProviderFloatValue SpaceBetween; // 0xb0 Size: 0x30
	    class UEnvQueryContext* GenerateAround; // 0xe0 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryGenerator_SimpleGrid");
			return (class UClass*)ptr;
		};

};

class UEnvQueryGenerator_PathingGrid : public UEnvQueryGenerator_SimpleGrid
{
	public:
	    struct FAIDataProviderBoolValue PathToItem; // 0xe8 Size: 0x30
	    class UNavigationQueryFilter* NavigationFilter; // 0x118 Size: 0x8
	    struct FAIDataProviderFloatValue ScanRangeMultiplier; // 0x120 Size: 0x30

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryGenerator_PathingGrid");
			return (class UClass*)ptr;
		};

};

class UEnvQueryInstanceBlueprintWrapper : public UObject
{
	public:
	    char UnknownData0[0x8];
	    int QueryID; // 0x30 Size: 0x4
	    char UnknownData1[0x24]; // 0x34
	    class UEnvQueryItemType* ItemType; // 0x58 Size: 0x8
	    int OptionIndex; // 0x60 Size: 0x4
	    char UnknownData2[0x4]; // 0x64
	    MulticastDelegateProperty OnQueryFinishedEvent; // 0x68 Size: 0x10
	    char UnknownData3[0x78]; // 0x78
	    void SetNamedParam(FName ParamName, float Value); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    TArray<struct FVector> GetResultsAsLocations(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    TArray<class AActor*> GetResultsAsActors(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool GetQueryResultsAsLocations(TArray<struct FVector> ResultLocations); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool GetQueryResultsAsActors(TArray<class AActor*> ResultActors); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    float GetItemScore(int ItemIndex); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ EQSQueryDoneSignature__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7f69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryInstanceBlueprintWrapper");
			return (class UClass*)ptr;
		};

};

class UEnvQueryItemType_Actor : public UEnvQueryItemType_ActorBase
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryItemType_Actor");
			return (class UClass*)ptr;
		};

};

class UEnvQueryItemType_Direction : public UEnvQueryItemType_VectorBase
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryItemType_Direction");
			return (class UClass*)ptr;
		};

};

class UEnvQueryManager : public UAISubsystem
{
	public:
	    char UnknownData0[0x70];
	    TArray<struct FEnvQueryInstanceCache> InstanceCache; // 0xa8 Size: 0x10
	    TArray<class UEnvQueryContext*> LocalContexts; // 0xb8 Size: 0x10
	    TArray<class UEnvQueryInstanceBlueprintWrapper*> GCShieldedWrappers; // 0xc8 Size: 0x10
	    char UnknownData1[0x54]; // 0xd8
	    float MaxAllowedTestingTime; // 0x12c Size: 0x4
	    bool bTestQueriesUsingBreadth; // 0x130 Size: 0x1
	    char UnknownData2[0x3]; // 0x131
	    int QueryCountWarningThreshold; // 0x134 Size: 0x4
	    double QueryCountWarningInterval; // 0x138 Size: 0x8
	    char UnknownData3[0x140]; // 0x140
	    static class UEnvQueryInstanceBlueprintWrapper* RunEQSQuery(class UObject* WorldContextObject, class UEnvQuery* QueryTemplate, class UObject* Querier, char RunMode, class UEnvQueryInstanceBlueprintWrapper* WrapperClass); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7ea1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryManager");
			return (class UClass*)ptr;
		};

};

class UEnvQueryOption : public UObject
{
	public:
	    class UEnvQueryGenerator* Generator; // 0x28 Size: 0x8
	    TArray<class UEnvQueryTest*> Tests; // 0x30 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryOption");
			return (class UClass*)ptr;
		};

};

class UEnvQueryTest_Distance : public UEnvQueryTest
{
	public:
	    char TestMode; // 0x1c0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1c1
	    class UEnvQueryContext* DistanceTo; // 0x1c8 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryTest_Distance");
			return (class UClass*)ptr;
		};

};

class UEnvQueryTest_Dot : public UEnvQueryTest
{
	public:
	    struct FEnvDirection LineA; // 0x1c0 Size: 0x20
	    struct FEnvDirection LineB; // 0x1e0 Size: 0x20
	    EEnvTestDot TestMode; // 0x200 Size: 0x1
	    bool bAbsoluteValue; // 0x201 Size: 0x1
	    char UnknownData0[0x6];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryTest_Dot");
			return (class UClass*)ptr;
		};

};

class UEnvQueryTest_GameplayTags : public UEnvQueryTest
{
	public:
	    struct FGameplayTagQuery TagQueryToMatch; // 0x1c0 Size: 0x48
	    bool bUpdatedToUseQuery; // 0x208 Size: 0x1
	    EGameplayContainerMatchType TagsToMatch; // 0x209 Size: 0x1
	    char UnknownData0[0x6]; // 0x20a
	    struct FGameplayTagContainer GameplayTags; // 0x210 Size: 0x20

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryTest_GameplayTags");
			return (class UClass*)ptr;
		};

};

class UEnvQueryTest_Overlap : public UEnvQueryTest
{
	public:
	    struct FEnvOverlapData OverlapData; // 0x1c0 Size: 0x20

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryTest_Overlap");
			return (class UClass*)ptr;
		};

};

class UEnvQueryTest_Pathfinding : public UEnvQueryTest
{
	public:
	    char TestMode; // 0x1c0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1c1
	    class UEnvQueryContext* Context; // 0x1c8 Size: 0x8
	    struct FAIDataProviderBoolValue PathFromContext; // 0x1d0 Size: 0x30
	    struct FAIDataProviderBoolValue SkipUnreachable; // 0x200 Size: 0x30
	    class UNavigationQueryFilter* FilterClass; // 0x230 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryTest_Pathfinding");
			return (class UClass*)ptr;
		};

};

class UEnvQueryTest_PathfindingBatch : public UEnvQueryTest_Pathfinding
{
	public:
	    struct FAIDataProviderFloatValue ScanRangeMultiplier; // 0x238 Size: 0x30

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryTest_PathfindingBatch");
			return (class UClass*)ptr;
		};

};

class UEnvQueryTest_Project : public UEnvQueryTest
{
	public:
	    struct FEnvTraceData ProjectionData; // 0x1c0 Size: 0x30

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryTest_Project");
			return (class UClass*)ptr;
		};

};

class UEnvQueryTest_Random : public UEnvQueryTest
{
	public:
	    char UnknownData0[0x1c0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryTest_Random");
			return (class UClass*)ptr;
		};

};

class UEnvQueryTest_Trace : public UEnvQueryTest
{
	public:
	    struct FEnvTraceData TraceData; // 0x1c0 Size: 0x30
	    struct FAIDataProviderBoolValue TraceFromContext; // 0x1f0 Size: 0x30
	    struct FAIDataProviderFloatValue ItemHeightOffset; // 0x220 Size: 0x30
	    struct FAIDataProviderFloatValue ContextHeightOffset; // 0x250 Size: 0x30
	    class UEnvQueryContext* Context; // 0x280 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryTest_Trace");
			return (class UClass*)ptr;
		};

};

class UEnvQueryTypes : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EnvQueryTypes");
			return (class UClass*)ptr;
		};

};

class UEQSQueryResultSourceInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EQSQueryResultSourceInterface");
			return (class UClass*)ptr;
		};

};

class UEQSRenderingComponent : public UPrimitiveComponent
{
	public:
	    char UnknownData0[0x5b0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EQSRenderingComponent");
			return (class UClass*)ptr;
		};

};

class AEQSTestingPawn : public ACharacter
{
	public:
	    class UEnvQuery* QueryTemplate; // 0x750 Size: 0x8
	    TArray<struct FEnvNamedValue> QueryParams; // 0x758 Size: 0x10
	    TArray<struct FAIDynamicParam> QueryConfig; // 0x768 Size: 0x10
	    float TimeLimitPerStep; // 0x778 Size: 0x4
	    int StepToDebugDraw; // 0x77c Size: 0x4
	    EEnvQueryHightlightMode HighlightMode; // 0x780 Size: 0x1
	    bool bDrawLabels; // 0x784 Size: 0x1
	    bool bDrawFailedItems; // 0x784 Size: 0x1
	    bool bReRunQueryOnlyOnFinishedMove; // 0x784 Size: 0x1
	    bool bShouldBeVisibleInGame; // 0x784 Size: 0x1
	    bool bTickDuringGame; // 0x784 Size: 0x1
	    char UnknownData0[0x2]; // 0x786
	    char QueryingMode; // 0x788 Size: 0x1
	    char UnknownData1[0x7]; // 0x789
	    struct FNavAgentProperties NavAgentProperties; // 0x790 Size: 0x30
	    char UnknownData2[0x20];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.EQSTestingPawn");
			return (class UClass*)ptr;
		};

};

class AGridPathAIController : public AAIController
{
	public:
	    char UnknownData0[0x440];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.GridPathAIController");
			return (class UClass*)ptr;
		};

};

class UGridPathFollowingComponent : public UPathFollowingComponent
{
	public:
	    class UNavLocalGridManager* GridManager; // 0x2a0 Size: 0x8
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.GridPathFollowingComponent");
			return (class UClass*)ptr;
		};

};

class UNavFilter_AIControllerDefault : public UNavigationQueryFilter
{
	public:
	    char UnknownData0[0x48];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.NavFilter_AIControllerDefault");
			return (class UClass*)ptr;
		};

};

class UNavLocalGridManager : public UObject
{
	public:
	    static bool SetLocalNavigationGridDensity(class UObject* WorldContextObject, float CellSize); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void RemoveLocalNavigationGrid(class UObject* WorldContextObject, int GridId, bool bRebuildGrids); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static bool FindLocalNavigationGridPath(class UObject* WorldContextObject, struct FVector Start, struct FVector End, TArray<struct FVector> PathPoints); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static int AddLocalNavigationGridForPoints(class UObject* WorldContextObject, TArray<struct FVector> Locations, int Radius2D, float Height, bool bRebuildGrids); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static int AddLocalNavigationGridForPoint(class UObject* WorldContextObject, struct FVector Location, int Radius2D, float Height, bool bRebuildGrids); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static int AddLocalNavigationGridForCapsule(class UObject* WorldContextObject, struct FVector Location, float CapsuleRadius, float CapsuleHalfHeight, int Radius2D, float Height, bool bRebuildGrids); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static int AddLocalNavigationGridForBox(class UObject* WorldContextObject, struct FVector Location, struct FVector Extent, struct FRotator Rotation, int Radius2D, float Height, bool bRebuildGrids); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7f89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.NavLocalGridManager");
			return (class UClass*)ptr;
		};

};

class UPathFollowingManager : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.PathFollowingManager");
			return (class UClass*)ptr;
		};

};

class UPawnAction : public UObject
{
	public:
	    class UPawnAction* ChildAction; // 0x28 Size: 0x8
	    class UPawnAction* ParentAction; // 0x30 Size: 0x8
	    class UPawnActionsComponent* OwnerComponent; // 0x38 Size: 0x8
	    class UObject* Instigator; // 0x40 Size: 0x8
	    class UBrainComponent* BrainComp; // 0x48 Size: 0x8
	    bool bAllowNewSameClassInstance; // 0x80 Size: 0x1
	    bool bReplaceActiveSameClassInstance; // 0x80 Size: 0x1
	    bool bShouldPauseMovement; // 0x80 Size: 0x1
	    bool bAlwaysNotifyOnFinished; // 0x80 Size: 0x1
	    char UnknownData0[0x54]; // 0x54
	    char GetActionPriority(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void Finish(char WithResult); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static class UPawnAction* CreateActionInstance(class UObject* WorldContextObject, class UPawnAction* ActionClass); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7f49];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.PawnAction");
			return (class UClass*)ptr;
		};

};

class UPawnAction_BlueprintBase : public UPawnAction
{
	public:
	    void ActionTick(class APawn* ControlledPawn, float DeltaSeconds); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void ActionStart(class APawn* ControlledPawn); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void ActionResume(class APawn* ControlledPawn); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void ActionPause(class APawn* ControlledPawn); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void ActionFinished(class APawn* ControlledPawn, char WithResult); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7f49];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.PawnAction_BlueprintBase");
			return (class UClass*)ptr;
		};

};

class UPawnAction_Move : public UPawnAction
{
	public:
	    class AActor* GoalActor; // 0x98 Size: 0x8
	    struct FVector GoalLocation; // 0xa0 Size: 0xc
	    float AcceptableRadius; // 0xac Size: 0x4
	    class UNavigationQueryFilter* FilterClass; // 0xb0 Size: 0x8
	    bool bAllowStrafe; // 0xb8 Size: 0x1
	    bool bFinishOnOverlap; // 0xb8 Size: 0x1
	    bool bUsePathfinding; // 0xb8 Size: 0x1
	    bool bAllowPartialPath; // 0xb8 Size: 0x1
	    bool bProjectGoalToNavigation; // 0xb8 Size: 0x1
	    bool bUpdatePathToGoal; // 0xb8 Size: 0x1
	    bool bAbortChildActionOnPathChange; // 0xb8 Size: 0x1
	    char UnknownData0[0x29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.PawnAction_Move");
			return (class UClass*)ptr;
		};

};

class UPawnAction_Repeat : public UPawnAction
{
	public:
	    class UPawnAction* ActionToRepeat; // 0x98 Size: 0x8
	    class UPawnAction* RecentActionCopy; // 0xa0 Size: 0x8
	    char ChildFailureHandlingMode; // 0xa8 Size: 0x1
	    char UnknownData0[0xf];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.PawnAction_Repeat");
			return (class UClass*)ptr;
		};

};

class UPawnAction_Sequence : public UPawnAction
{
	public:
	    TArray<class UPawnAction*> ActionSequence; // 0x98 Size: 0x10
	    char ChildFailureHandlingMode; // 0xa8 Size: 0x1
	    char UnknownData0[0x7]; // 0xa9
	    class UPawnAction* RecentActionCopy; // 0xb0 Size: 0x8
	    char UnknownData1[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.PawnAction_Sequence");
			return (class UClass*)ptr;
		};

};

class UPawnAction_Wait : public UPawnAction
{
	public:
	    float TimeToWait; // 0x98 Size: 0x4
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.PawnAction_Wait");
			return (class UClass*)ptr;
		};

};

class UPawnActionsComponent : public UActorComponent
{
	public:
	    class APawn* ControlledPawn; // 0xf8 Size: 0x8
	    TArray<struct FPawnActionStack> ActionStacks; // 0x100 Size: 0x10
	    TArray<struct FPawnActionEvent> ActionEvents; // 0x110 Size: 0x10
	    class UPawnAction* CurrentAction; // 0x120 Size: 0x8
	    char UnknownData0[0x128]; // 0x128
	    bool K2_PushAction(class UPawnAction* NewAction, char Priority, class UObject* Instigator); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static bool K2_PerformAction(class APawn* Pawn, class UPawnAction* Action, char Priority); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    char K2_ForceAbortAction(class UPawnAction* ActionToAbort); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    char K2_AbortAction(class UPawnAction* ActionToAbort); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7eb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.PawnActionsComponent");
			return (class UClass*)ptr;
		};

};

class UPawnSensingComponent : public UActorComponent
{
	public:
	    float HearingThreshold; // 0xf8 Size: 0x4
	    float LOSHearingThreshold; // 0xfc Size: 0x4
	    float SightRadius; // 0x100 Size: 0x4
	    float SensingInterval; // 0x104 Size: 0x4
	    float HearingMaxSoundAge; // 0x108 Size: 0x4
	    bool bEnableSensingUpdates; // 0x10c Size: 0x1
	    bool bOnlySensePlayers; // 0x10c Size: 0x1
	    bool bSeePawns; // 0x10c Size: 0x1
	    bool bHearNoises; // 0x10c Size: 0x1
	    char UnknownData0[0x8]; // 0x110
	    MulticastDelegateProperty OnSeePawn; // 0x118 Size: 0x10
	    MulticastDelegateProperty OnHearNoise; // 0x128 Size: 0x10
	    float PeripheralVisionAngle; // 0x138 Size: 0x4
	    float PeripheralVisionCosine; // 0x13c Size: 0x4
	    char UnknownData1[0x140]; // 0x140
	    void SetSensingUpdatesEnabled(bool bEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetSensingInterval(float NewSensingInterval); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetPeripheralVisionAngle(float NewPeripheralVisionAngle); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ SeePawnDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ HearNoiseDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    float GetPeripheralVisionCosine(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    float GetPeripheralVisionAngle(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7ea1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.PawnSensingComponent");
			return (class UClass*)ptr;
		};

};

class UVisualLoggerExtension : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AIModule.VisualLoggerExtension");
			return (class UClass*)ptr;
		};

};


}