#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class EServerClientFlag : uint8_t
{
    No = 0,
    ServerOnly = 1,
    ClientOnly = 2,
    Yes = 3,
    EServerClientFlag_MAX = 4
};struct FMcpLootEntry
{
	public:
	    struct FString ItemType; // 0x0 Size: 0x10
	    struct FString ItemGuid; // 0x10 Size: 0x10
	    int Quantity; // 0x20 Size: 0x4
	    char UnknownData0[0x4]; // 0x24
	    struct FJsonObjectWrapper Attributes; // 0x28 Size: 0x20
	    struct FString ItemProfile; // 0x48 Size: 0x10

};

struct FBaseUrlContext
{
	public:
	    char UnknownData0[0x38];

};

struct FClientUrlContext : public FBaseUrlContext
{
	public:
	    char UnknownData0[0x38];

};

struct FDedicatedServerUrlContext : public FBaseUrlContext
{
	public:
	    char UnknownData0[0x38];

};

struct FMcpChangeAttributesRequest
{
	public:
	    struct FString ItemId; // 0x0 Size: 0x10
	    struct FJsonObjectWrapper Attributes; // 0x10 Size: 0x20

};

struct FMcpChangeQuantityRequest
{
	public:
	    struct FString ItemId; // 0x0 Size: 0x10
	    int DeltaQuantity; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FMcpRemoveItemRequest
{
	public:
	    struct FString ItemId; // 0x0 Size: 0x10

};

struct FMcpAddItemRequest
{
	public:
	    struct FString ItemId; // 0x0 Size: 0x10
	    struct FString TemplateId; // 0x10 Size: 0x10
	    int Quantity; // 0x20 Size: 0x4
	    char UnknownData0[0x4]; // 0x24
	    struct FJsonObjectWrapper Attributes; // 0x28 Size: 0x20

};

struct FPublicUrlContext : public FBaseUrlContext
{
	public:
	    char UnknownData0[0x38];

};

struct FProfileHttpRequest
{
	public:
	    class UMcpProfile* SourceProfile; // 0x0 Size: 0x8
	    char UnknownData0[0x28];

};

struct FProfileEntry
{
	public:
	    struct FString ProfileId; // 0x0 Size: 0x10
	    class UMcpProfile* ProfileObject; // 0x10 Size: 0x8
	    bool bWaitingForRefreshAllProfilesResponse; // 0x18 Size: 0x1
	    char UnknownData0[0x7];

};

struct FProfileGroupEntry
{
	public:
	    class UMcpProfileGroup* ProfileGroup; // 0x18 Size: 0x8

};

struct FMcpItemIdAndQuantity : public FMcpLootEntry
{
	public:
	    char UnknownData0[0x58];

};


}