#include "../SDK.hpp"

void ALandscapeProxy::SetLandscapeMaterialVectorParameterValue(FName ParameterName, struct FLinearColor Value)
{
	struct {
            FName ParameterName;
            struct FLinearColor Value;
	} params{ ParameterName, Value };

    static auto fn = UObject::FindObject("/Script/Landscape.LandscapeProxy:SetLandscapeMaterialVectorParameterValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ALandscapeProxy::SetLandscapeMaterialTextureParameterValue(FName ParameterName, class UTexture* Value)
{
	struct {
            FName ParameterName;
            class UTexture* Value;
	} params{ ParameterName, Value };

    static auto fn = UObject::FindObject("/Script/Landscape.LandscapeProxy:SetLandscapeMaterialTextureParameterValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ALandscapeProxy::SetLandscapeMaterialScalarParameterValue(FName ParameterName, float Value)
{
	struct {
            FName ParameterName;
            float Value;
	} params{ ParameterName, Value };

    static auto fn = UObject::FindObject("/Script/Landscape.LandscapeProxy:SetLandscapeMaterialScalarParameterValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ALandscapeProxy::EditorSetLandscapeMaterial(class UMaterialInterface* NewLandscapeMaterial)
{
	struct {
            class UMaterialInterface* NewLandscapeMaterial;
	} params{ NewLandscapeMaterial };

    static auto fn = UObject::FindObject("/Script/Landscape.LandscapeProxy:EditorSetLandscapeMaterial");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ALandscapeProxy::EditorApplySpline(class USplineComponent* InSplineComponent, float StartWidth, float EndWidth, float StartSideFalloff, float EndSideFalloff, float StartRoll, float EndRoll, int NumSubdivisions, bool bRaiseHeights, bool bLowerHeights, class ULandscapeLayerInfoObject* PaintLayer)
{
	struct {
            class USplineComponent* InSplineComponent;
            float StartWidth;
            float EndWidth;
            float StartSideFalloff;
            float EndSideFalloff;
            float StartRoll;
            float EndRoll;
            int NumSubdivisions;
            bool bRaiseHeights;
            bool bLowerHeights;
            class ULandscapeLayerInfoObject* PaintLayer;
	} params{ InSplineComponent, StartWidth, EndWidth, StartSideFalloff, EndSideFalloff, StartRoll, EndRoll, NumSubdivisions, bRaiseHeights, bLowerHeights, PaintLayer };

    static auto fn = UObject::FindObject("/Script/Landscape.LandscapeProxy:EditorApplySpline");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ALandscapeProxy::ChangeUseTessellationComponentScreenSizeFalloff(bool InComponentScreenSizeToUseSubSections)
{
	struct {
            bool InComponentScreenSizeToUseSubSections;
	} params{ InComponentScreenSizeToUseSubSections };

    static auto fn = UObject::FindObject("/Script/Landscape.LandscapeProxy:ChangeUseTessellationComponentScreenSizeFalloff");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ALandscapeProxy::ChangeTessellationComponentScreenSizeFalloff(float InUseTessellationComponentScreenSizeFalloff)
{
	struct {
            float InUseTessellationComponentScreenSizeFalloff;
	} params{ InUseTessellationComponentScreenSizeFalloff };

    static auto fn = UObject::FindObject("/Script/Landscape.LandscapeProxy:ChangeTessellationComponentScreenSizeFalloff");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ALandscapeProxy::ChangeTessellationComponentScreenSize(float InTessellationComponentScreenSize)
{
	struct {
            float InTessellationComponentScreenSize;
	} params{ InTessellationComponentScreenSize };

    static auto fn = UObject::FindObject("/Script/Landscape.LandscapeProxy:ChangeTessellationComponentScreenSize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ALandscapeProxy::ChangeLODDistanceFactor(float InLODDistanceFactor)
{
	struct {
            float InLODDistanceFactor;
	} params{ InLODDistanceFactor };

    static auto fn = UObject::FindObject("/Script/Landscape.LandscapeProxy:ChangeLODDistanceFactor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ALandscapeProxy::ChangeComponentScreenSizeToUseSubSections(float InComponentScreenSizeToUseSubSections)
{
	struct {
            float InComponentScreenSizeToUseSubSections;
	} params{ InComponentScreenSizeToUseSubSections };

    static auto fn = UObject::FindObject("/Script/Landscape.LandscapeProxy:ChangeComponentScreenSizeToUseSubSections");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

class UTextureRenderTarget2D* ALandscapeBlueprintCustomBrush::Render(bool InIsHeightmap, class UTextureRenderTarget2D* InCombinedResult)
{
	struct {
            bool InIsHeightmap;
            class UTextureRenderTarget2D* InCombinedResult;
            class UTextureRenderTarget2D* ReturnValue;
	} params{ InIsHeightmap, InCombinedResult };

    static auto fn = UObject::FindObject("/Script/Landscape.LandscapeBlueprintCustomBrush:Render");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void ALandscapeBlueprintCustomBrush::Initialize(struct FIntPoint InLandscapeSize, struct FIntPoint InLandscapeRenderTargetSize)
{
	struct {
            struct FIntPoint InLandscapeSize;
            struct FIntPoint InLandscapeRenderTargetSize;
	} params{ InLandscapeSize, InLandscapeRenderTargetSize };

    static auto fn = UObject::FindObject("/Script/Landscape.LandscapeBlueprintCustomBrush:Initialize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

class UMaterialInstanceDynamic* ULandscapeComponent::GetMaterialInstanceDynamic(int InIndex)
{
	struct {
            int InIndex;
            class UMaterialInstanceDynamic* ReturnValue;
	} params{ InIndex };

    static auto fn = UObject::FindObject("/Script/Landscape.LandscapeComponent:GetMaterialInstanceDynamic");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

TArray<class USplineMeshComponent*> ULandscapeSplinesComponent::GetSplineMeshComponents()
{
	struct {
            TArray<class USplineMeshComponent*> ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/Landscape.LandscapeSplinesComponent:GetSplineMeshComponents");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

