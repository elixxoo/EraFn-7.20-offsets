#include "../SDK.hpp"

void UAnimSharingStateInstance::GetInstancedActors(TArray<class AActor*> Actors)
{
	struct {
            TArray<class AActor*> Actors;
	} params{ Actors };

    static auto fn = UObject::FindObject("/Script/AnimationSharing.AnimSharingStateInstance:GetInstancedActors");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

static bool UAnimationSharingManager::AnimSharingEnabled()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AnimationSharing.AnimationSharingManager:AnimSharingEnabled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UAnimationSharingStateProcessor::ProcessActorState(int OutState, class AActor* InActor, char CurrentState, char OnDemandState, bool bShouldProcess)
{
	struct {
            int OutState;
            class AActor* InActor;
            char CurrentState;
            char OnDemandState;
            bool bShouldProcess;
	} params{ OutState, InActor, CurrentState, OnDemandState, bShouldProcess };

    static auto fn = UObject::FindObject("/Script/AnimationSharing.AnimationSharingStateProcessor:ProcessActorState");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


class UEnum* UAnimationSharingStateProcessor::GetAnimationStateEnum()
{
	struct {
            class UEnum* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AnimationSharing.AnimationSharingStateProcessor:GetAnimationStateEnum");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

