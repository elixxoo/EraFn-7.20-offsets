#pragma once

#include "../SDK.hpp"

namespace SDK {


class UMIDIDeviceController : public UObject
{
	public:
	    MulticastDelegateProperty OnMIDIEvent; // 0x28 Size: 0x10
	    int DeviceID; // 0x38 Size: 0x4
	    char UnknownData0[0x4]; // 0x3c
	    struct FString DeviceName; // 0x40 Size: 0x10
	    char UnknownData1[0x10];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MIDIDevice.MIDIDeviceController");
			return (class UClass*)ptr;
		};

};

class UMIDIDeviceManager : public UBlueprintFunctionLibrary
{
	public:
	    static void FindMIDIDevices(TArray<struct FFoundMIDIDevice> OutMIDIDevices); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static class UMIDIDeviceController* CreateMIDIDeviceController(int DeviceID, int MIDIBufferSize); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MIDIDevice.MIDIDeviceManager");
			return (class UClass*)ptr;
		};

};


}