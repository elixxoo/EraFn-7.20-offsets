#pragma once

#include "../SDK.hpp"

namespace SDK {


class UOnlineAccountCommon : public UObject
{
	public:
	    char UnknownData0[0x10];
	    struct FString AvailabilityServiceGameName; // 0x38 Size: 0x10
	    bool bRequireLightswitchAtStartup; // 0x48 Size: 0x1
	    char UnknownData1[0x7]; // 0x49
	    struct FString EulaKey; // 0x50 Size: 0x10
	    TArray<struct FWebEnvUrl> WebCreateEpicAccountUrl; // 0x60 Size: 0x10
	    bool bAllowLocalLogout; // 0x70 Size: 0x1
	    char UnknownData2[0x3]; // 0x71
	    float SkipRedeemOfflinePurchasesChance; // 0x74 Size: 0x4
	    bool bShouldGrantFreeAccess; // 0x78 Size: 0x1
	    bool bUseGameSubAccessRedemption; // 0x7a Size: 0x1
	    bool bAllowHomeSharingAccess; // 0x7b Size: 0x1
	    bool bRequireUGCPrivilege; // 0x7c Size: 0x1
	    char UnknownData3[0x29c]; // 0x7c
	    float AccessGrantDelaySeconds; // 0x318 Size: 0x4
	    char UnknownData4[0x4]; // 0x31c
	    class UWaitingRoomState* WaitingRoomState; // 0x320 Size: 0x8
	    bool bAutoCreateHeadlessAccount; // 0x618 Size: 0x1
	    char UnknownData5[0x327];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Account.OnlineAccountCommon");
			return (class UClass*)ptr;
		};

};

class UExternalAccountProvider : public UObject
{
	public:
	    TArray<struct FExternalAccountServiceConfig> Services; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Account.ExternalAccountProvider");
			return (class UClass*)ptr;
		};

};

class UWaitingRoomState : public UObject
{
	public:
	    char UnknownData0[0x34];
	    int GracePeriodMins; // 0x5c Size: 0x4
	    char UnknownData1[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Account.WaitingRoomState");
			return (class UClass*)ptr;
		};

};


}