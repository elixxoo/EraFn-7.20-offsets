#include "../SDK.hpp"

void UGameplayTasksComponent::OnRep_SimulatedTasks()
{
    static auto fn = UObject::FindObject("/Script/GameplayTasks.GameplayTasksComponent:OnRep_SimulatedTasks");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


static EGameplayTaskRunResult UGameplayTasksComponent::K2_RunGameplayTask(__int64/*InterfaceProperty*/ TaskOwner, class UGameplayTask* Task, char Priority, TArray<class UGameplayTaskResource*> AdditionalRequiredResources, TArray<class UGameplayTaskResource*> AdditionalClaimedResources)
{
	struct {
            __int64/*InterfaceProperty*/ TaskOwner;
            class UGameplayTask* Task;
            char Priority;
            TArray<class UGameplayTaskResource*> AdditionalRequiredResources;
            TArray<class UGameplayTaskResource*> AdditionalClaimedResources;
            EGameplayTaskRunResult ReturnValue;
	} params{ TaskOwner, Task, Priority, AdditionalRequiredResources, AdditionalClaimedResources };

    static auto fn = UObject::FindObject("/Script/GameplayTasks.GameplayTasksComponent:K2_RunGameplayTask");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UGameplayTask::ReadyForActivation()
{
    static auto fn = UObject::FindObject("/Script/GameplayTasks.GameplayTask:ReadyForActivation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UGameplayTask::EndTask()
{
    static auto fn = UObject::FindObject("/Script/GameplayTasks.GameplayTask:EndTask");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

static class UGameplayTask_ClaimResource* UGameplayTask_ClaimResource::ClaimResources(__int64/*InterfaceProperty*/ InTaskOwner, TArray<class UGameplayTaskResource*> ResourceClasses, char Priority, FName TaskInstanceName)
{
	struct {
            __int64/*InterfaceProperty*/ InTaskOwner;
            TArray<class UGameplayTaskResource*> ResourceClasses;
            char Priority;
            FName TaskInstanceName;
            class UGameplayTask_ClaimResource* ReturnValue;
	} params{ InTaskOwner, ResourceClasses, Priority, TaskInstanceName };

    static auto fn = UObject::FindObject("/Script/GameplayTasks.GameplayTask_ClaimResource:ClaimResources");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UGameplayTask_ClaimResource* UGameplayTask_ClaimResource::ClaimResource(__int64/*InterfaceProperty*/ InTaskOwner, class UGameplayTaskResource* ResourceClass, char Priority, FName TaskInstanceName)
{
	struct {
            __int64/*InterfaceProperty*/ InTaskOwner;
            class UGameplayTaskResource* ResourceClass;
            char Priority;
            FName TaskInstanceName;
            class UGameplayTask_ClaimResource* ReturnValue;
	} params{ InTaskOwner, ResourceClass, Priority, TaskInstanceName };

    static auto fn = UObject::FindObject("/Script/GameplayTasks.GameplayTask_ClaimResource:ClaimResource");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UGameplayTask_SpawnActor* UGameplayTask_SpawnActor::SpawnActor(__int64/*InterfaceProperty*/ TaskOwner, struct FVector SpawnLocation, struct FRotator SpawnRotation, class AActor* Class, bool bSpawnOnlyOnAuthority)
{
	struct {
            __int64/*InterfaceProperty*/ TaskOwner;
            struct FVector SpawnLocation;
            struct FRotator SpawnRotation;
            class AActor* Class;
            bool bSpawnOnlyOnAuthority;
            class UGameplayTask_SpawnActor* ReturnValue;
	} params{ TaskOwner, SpawnLocation, SpawnRotation, Class, bSpawnOnlyOnAuthority };

    static auto fn = UObject::FindObject("/Script/GameplayTasks.GameplayTask_SpawnActor:SpawnActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UGameplayTask_SpawnActor::FinishSpawningActor(class UObject* WorldContextObject, class AActor* SpawnedActor)
{
	struct {
            class UObject* WorldContextObject;
            class AActor* SpawnedActor;
	} params{ WorldContextObject, SpawnedActor };

    static auto fn = UObject::FindObject("/Script/GameplayTasks.GameplayTask_SpawnActor:FinishSpawningActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UGameplayTask_SpawnActor::BeginSpawningActor(class UObject* WorldContextObject, class AActor* SpawnedActor)
{
	struct {
            class UObject* WorldContextObject;
            class AActor* SpawnedActor;
            bool ReturnValue;
	} params{ WorldContextObject, SpawnedActor };

    static auto fn = UObject::FindObject("/Script/GameplayTasks.GameplayTask_SpawnActor:BeginSpawningActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UGameplayTask_WaitDelay* UGameplayTask_WaitDelay::TaskWaitDelay(__int64/*InterfaceProperty*/ TaskOwner, float Time, char Priority)
{
	struct {
            __int64/*InterfaceProperty*/ TaskOwner;
            float Time;
            char Priority;
            class UGameplayTask_WaitDelay* ReturnValue;
	} params{ TaskOwner, Time, Priority };

    static auto fn = UObject::FindObject("/Script/GameplayTasks.GameplayTask_WaitDelay:TaskWaitDelay");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


