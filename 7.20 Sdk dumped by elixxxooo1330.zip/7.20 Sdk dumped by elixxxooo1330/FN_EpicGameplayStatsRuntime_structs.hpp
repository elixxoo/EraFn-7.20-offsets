#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class EEpicLeaderboardUpdateFunction : uint8_t
{
    Min = 0,
    Max = 1,
    Sum = 2,
    MostRecent = 3
};

enum class EEpicLeaderboardTimeWindow : uint8_t
{
    Daily = 0,
    Weekly = 1,
    Monthly = 2,
    AllTime = 3,
    EEpicLeaderboardTimeWindow_MAX = 4
};

enum class EEpicLeaderboardDataType : uint8_t
{
    Integer = 0,
    Double = 1,
    EEpicLeaderboardDataType_MAX = 2
};struct FGameplayStatTag : public FGameplayTag
{
	public:
	    struct FGameplayTag Tag; // 0x8 Size: 0x8

};

struct FManagedGameplayTagDataTableItem
{
	public:
	    struct FGameplayTag RootTag; // 0x0 Size: 0x8
	    class UDataTable* DataTable; // 0x8 Size: 0x8

};

struct FTagTableManagerHelper
{
	public:
	    char UnknownData0[0x1];

};


}