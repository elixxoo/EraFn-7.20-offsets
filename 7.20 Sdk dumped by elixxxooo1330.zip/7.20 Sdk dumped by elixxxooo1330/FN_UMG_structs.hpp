#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class ESlateVisibility : uint8_t
{
    Visible = 0,
    Collapsed = 1,
    Hidden = 2,
    HitTestInvisible = 3,
    SelfHitTestInvisible = 4,
    ESlateVisibility_MAX = 5
};struct FEventReply
{
	public:
	    char UnknownData0[0xb8];

};

struct FWidgetTransform
{
	public:
	    struct FVector2D Translation; // 0x0 Size: 0x8
	    struct FVector2D Scale; // 0x8 Size: 0x8
	    struct FVector2D Shear; // 0x10 Size: 0x8
	    float Angle; // 0x18 Size: 0x4

};

struct FOnWidgetAnimationPlaybackStatusChanged__DelegateSignature
{
	public:

};

struct FWidgetAnimationDynamicEvent__DelegateSignature
{
	public:

};

struct FWidgetAnimationDynamicEvents__DelegateSignature
{
	public:

};

struct FOnConstructEvent__DelegateSignature
{
	public:

};

struct FOnInputAction__DelegateSignature
{
	public:

};

struct FDownloadImageDelegate__DelegateSignature
{
	public:
	    class UTexture2DDynamic* Texture; // 0x0 Size: 0x8

};

struct FOnDragDropMulticast__DelegateSignature
{
	public:
	    class UDragDropOperation* Operation; // 0x0 Size: 0x8

};

struct FPaintContext
{
	public:
	    char UnknownData0[0x30];

};

struct FCustomWidgetNavigationDelegate__DelegateSignature
{
	public:
	    EUINavigation Navigation; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class UWidget* ReturnValue; // 0x8 Size: 0x8

};

struct FOnButtonClickedEvent__DelegateSignature
{
	public:

};

struct FOnButtonPressedEvent__DelegateSignature
{
	public:

};

struct FOnButtonReleasedEvent__DelegateSignature
{
	public:

};

struct FOnButtonHoverEvent__DelegateSignature
{
	public:

};

struct FOnCheckBoxComponentStateChanged__DelegateSignature
{
	public:
	    bool bIsChecked; // 0x0 Size: 0x1

};

struct FShapedTextOptions
{
	public:
	    bool bOverride_TextShapingMethod; // 0x0 Size: 0x1
	    bool bOverride_TextFlowDirection; // 0x0 Size: 0x1
	    Yea, we fucked up; // 0x0
	    ETextShapingMethod TextShapingMethod; // 0x1 Size: 0x1
	    ETextFlowDirection TextFlowDirection; // 0x2 Size: 0x1

};



enum class EVirtualKeyboardType : uint8_t
{
    Default = 0,
    Number = 1,
    Web = 2,
    Email = 3,
    Password = 4,
    AlphaNumeric = 5,
    EVirtualKeyboardType_MAX = 6
};struct FOnExpandableAreaExpansionChanged__DelegateSignature
{
	public:
	    class UExpandableArea* Area; // 0x0 Size: 0x8
	    bool bIsExpanded; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FOnListEntryGeneratedDynamic__DelegateSignature
{
	public:
	    class UUserWidget* Widget; // 0x0 Size: 0x8

};

struct FOnListEntryReleasedDynamic__DelegateSignature
{
	public:
	    class UUserWidget* Widget; // 0x0 Size: 0x8

};

struct FSimpleListItemEventDynamic__DelegateSignature
{
	public:
	    class UObject* Item; // 0x0 Size: 0x8

};

struct FOnListItemSelectionChangedDynamic__DelegateSignature
{
	public:
	    class UObject* Item; // 0x0 Size: 0x8
	    bool bIsSelected; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FOnItemIsHoveredChangedDynamic__DelegateSignature
{
	public:
	    class UObject* Item; // 0x0 Size: 0x8
	    bool bIsHovered; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FOnListItemScrolledIntoViewDynamic__DelegateSignature
{
	public:
	    class UObject* Item; // 0x0 Size: 0x8
	    class UUserWidget* Widget; // 0x8 Size: 0x8

};

struct FOnMenuOpenChangedEvent__DelegateSignature
{
	public:
	    bool bIsOpen; // 0x0 Size: 0x1

};

struct FOnUserScrolledEvent__DelegateSignature
{
	public:
	    float CurrentOffset; // 0x0 Size: 0x4

};

struct FOnMouseCaptureBeginEvent__DelegateSignature
{
	public:

};

struct FOnMouseCaptureEndEvent__DelegateSignature
{
	public:

};

struct FOnControllerCaptureBeginEvent__DelegateSignature
{
	public:

};

struct FOnControllerCaptureEndEvent__DelegateSignature
{
	public:

};

struct FOnFloatValueChangedEvent__DelegateSignature
{
	public:
	    float Value; // 0x0 Size: 0x4

};

struct FOnItemExpansionChangedDynamic__DelegateSignature
{
	public:
	    class UObject* Item; // 0x0 Size: 0x8
	    bool bIsExpanded; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FOnHoveredWidgetChanged__DelegateSignature
{
	public:
	    class UWidgetComponent* WidgetComponent; // 0x0 Size: 0x8
	    class UWidgetComponent* PreviousWidgetComponent; // 0x8 Size: 0x8

};



enum class EWidgetAnimationEvent : uint8_t
{
    Started = 0,
    Finished = 1,
    EWidgetAnimationEvent_MAX = 2
};

enum class EUMGSequencePlayMode : uint8_t
{
    Forward = 0,
    Reverse = 1,
    PingPong = 2,
    EUMGSequencePlayMode_MAX = 3
};struct FAnimationEventBinding
{
	public:
	    class UWidgetAnimation* Animation; // 0x0 Size: 0x8
	    __int64/*DelegateProperty*/ Delegate; // 0x8 Size: 0x10
	    EWidgetAnimationEvent AnimationEvent; // 0x18 Size: 0x1
	    char UnknownData0[0x3]; // 0x19
	    FName UserTag; // 0x1c Size: 0x8
	    char UnknownData1[0x4];

};



enum class EWidgetTickFrequency : uint8_t
{
    Never = 0,
    Auto = 1,
    EWidgetTickFrequency_MAX = 2
};struct FNamedSlotBinding
{
	public:
	    FName Name; // 0x0 Size: 0x8
	    class UWidget* Content; // 0x8 Size: 0x8

};



enum class EDragPivot : uint8_t
{
    MouseDown = 0,
    TopLeft = 1,
    TopCenter = 2,
    TopRight = 3,
    CenterLeft = 4,
    CenterCenter = 5,
    CenterRight = 6,
    BottomLeft = 7,
    BottomCenter = 8,
    BottomRight = 9,
    EDragPivot_MAX = 10
};

enum class EDynamicBoxType : uint8_t
{
    Horizontal = 0,
    Vertical = 1,
    Wrap = 2,
    Overlay = 3,
    EDynamicBoxType_MAX = 4
};

enum class ESlateSizeRule : uint8_t
{
    Automatic = 0,
    Fill = 1,
    ESlateSizeRule_MAX = 2
};

enum class EWidgetDesignFlags : uint8_t
{
    None = 0,
    Designing = 1,
    ShowOutline = 2,
    ExecutePreConstruct = 4,
    EWidgetDesignFlags_MAX = 5
};

enum class EBindingKind : uint8_t
{
    Function = 0,
    Property = 1,
    EBindingKind_MAX = 2
};

enum class EWidgetGeometryMode : uint8_t
{
    Plane = 0,
    Cylinder = 1,
    EWidgetGeometryMode_MAX = 2
};

enum class EWidgetBlendMode : uint8_t
{
    Opaque = 0,
    Masked = 1,
    Transparent = 2,
    EWidgetBlendMode_MAX = 3
};

enum class EWidgetTimingPolicy : uint8_t
{
    RealTime = 0,
    GameTime = 1,
    EWidgetTimingPolicy_MAX = 2
};

enum class EWidgetSpace : uint8_t
{
    World = 0,
    Screen = 1,
    EWidgetSpace_MAX = 2
};

enum class EWidgetInteractionSource : uint8_t
{
    World = 0,
    Mouse = 1,
    CenterScreen = 2,
    Custom = 3,
    EWidgetInteractionSource_MAX = 4
};struct FAnchorData
{
	public:
	    struct FMargin Offsets; // 0x0 Size: 0x10
	    struct FAnchors Anchors; // 0x10 Size: 0x10
	    struct FVector2D Alignment; // 0x20 Size: 0x8

};

struct FDynamicPropertyPath : public FCachedPropertyPath
{
	public:
	    char UnknownData0[0x28];

};

struct FMovieScene2DTransformMask
{
	public:
	    uint32_t Mask; // 0x0 Size: 0x4

};

struct FRichTextStyleRow : public FTableRowBase
{
	public:
	    struct FTextBlockStyle TextStyle; // 0x8 Size: 0x1e0

};

struct FRichImageRow : public FTableRowBase
{
	public:
	    struct FSlateBrush Brush; // 0x8 Size: 0x88

};

struct FSlateMeshVertex
{
	public:
	    struct FVector2D Position; // 0x0 Size: 0x8
	    struct FColor Color; // 0x8 Size: 0x4
	    struct FVector2D UV0; // 0xc Size: 0x8
	    struct FVector2D UV1; // 0x14 Size: 0x8
	    struct FVector2D UV2; // 0x1c Size: 0x8
	    struct FVector2D UV3; // 0x24 Size: 0x8
	    struct FVector2D UV4; // 0x2c Size: 0x8
	    struct FVector2D UV5; // 0x34 Size: 0x8

};

struct FSlateChildSize
{
	public:
	    float Value; // 0x0 Size: 0x4
	    char SizeRule; // 0x4 Size: 0x1
	    char UnknownData0[0x3];

};

struct FWidgetAnimationBinding
{
	public:
	    FName WidgetName; // 0x0 Size: 0x8
	    FName SlotWidgetName; // 0x8 Size: 0x8
	    struct FGuid AnimationGuid; // 0x10 Size: 0x10
	    bool bIsRootWidget; // 0x20 Size: 0x1
	    char UnknownData0[0x3];

};

struct FBlueprintWidgetAnimationDelegateBinding
{
	public:
	    EWidgetAnimationEvent Action; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    FName AnimationToBind; // 0x4 Size: 0x8
	    FName FunctionNameToBind; // 0xc Size: 0x8
	    FName UserTag; // 0x14 Size: 0x8

};

struct FDelegateRuntimeBinding
{
	public:
	    struct FString ObjectName; // 0x0 Size: 0x10
	    FName PropertyName; // 0x10 Size: 0x8
	    FName FunctionName; // 0x18 Size: 0x8
	    struct FDynamicPropertyPath SourcePath; // 0x20 Size: 0x28
	    EBindingKind Kind; // 0x48 Size: 0x1
	    char UnknownData0[0x7];

};

struct FWidgetNavigationData
{
	public:
	    EUINavigationRule Rule; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    FName WidgetToFocus; // 0x4 Size: 0x8
	    TWeakObjectPtr<UWidget*> Widget; // 0xc Size: 0x8
	    __int64/*DelegateProperty*/ CustomDelegate; // 0x14 Size: 0x10

};


}