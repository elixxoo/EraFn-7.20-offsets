#pragma once

#include "../SDK.hpp"

namespace SDK {


class UReplicationGraph : public UReplicationDriver
{
	public:
	    class UNetReplicationGraphConnection* ReplicationConnectionManagerClass; // 0x28 Size: 0x8
	    class UNetDriver* NetDriver; // 0x30 Size: 0x8
	    TArray<class UNetReplicationGraphConnection*> Connections; // 0x38 Size: 0x10
	    TArray<class UNetReplicationGraphConnection*> PendingConnections; // 0x48 Size: 0x10
	    char UnknownData0[0x40]; // 0x58
	    TArray<class UReplicationGraphNode*> GlobalGraphNodes; // 0x98 Size: 0x10
	    TArray<class UReplicationGraphNode*> PrepareForReplicationNodes; // 0xa8 Size: 0x10
	    char UnknownData1[0x3a8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ReplicationGraph.ReplicationGraph");
			return (class UClass*)ptr;
		};

};

class UBasicReplicationGraph : public UReplicationGraph
{
	public:
	    class UReplicationGraphNode_GridSpatialization2D* GridNode; // 0x458 Size: 0x8
	    class UReplicationGraphNode_ActorList* AlwaysRelevantNode; // 0x460 Size: 0x8
	    TArray<struct FConnectionAlwaysRelevantNodePair> AlwaysRelevantForConnectionList; // 0x468 Size: 0x10
	    TArray<class AActor*> ActorsWithoutNetConnection; // 0x478 Size: 0x10
	    char UnknownData0[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ReplicationGraph.BasicReplicationGraph");
			return (class UClass*)ptr;
		};

};

class UReplicationGraphNode : public UObject
{
	public:
	    TArray<class UReplicationGraphNode*> AllChildNodes; // 0x28 Size: 0x10
	    char UnknownData0[0x18];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ReplicationGraph.ReplicationGraphNode");
			return (class UClass*)ptr;
		};

};

class UReplicationGraphNode_ActorList : public UReplicationGraphNode
{
	public:
	    char UnknownData0[0xf8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ReplicationGraph.ReplicationGraphNode_ActorList");
			return (class UClass*)ptr;
		};

};

class UReplicationGraphNode_ActorListFrequencyBuckets : public UReplicationGraphNode
{
	public:
	    char UnknownData0[0x138];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ReplicationGraph.ReplicationGraphNode_ActorListFrequencyBuckets");
			return (class UClass*)ptr;
		};

};

class UReplicationGraphNode_DynamicSpatialFrequency : public UReplicationGraphNode_ActorList
{
	public:
	    char UnknownData0[0x128];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ReplicationGraph.ReplicationGraphNode_DynamicSpatialFrequency");
			return (class UClass*)ptr;
		};

};

class UReplicationGraphNode_ConnectionDormanyNode : public UReplicationGraphNode_ActorList
{
	public:
	    char UnknownData0[0x190];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ReplicationGraph.ReplicationGraphNode_ConnectionDormanyNode");
			return (class UClass*)ptr;
		};

};

class UReplicationGraphNode_DormancyNode : public UReplicationGraphNode_ActorList
{
	public:
	    char UnknownData0[0x148];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ReplicationGraph.ReplicationGraphNode_DormancyNode");
			return (class UClass*)ptr;
		};

};

class UReplicationGraphNode_GridCell : public UReplicationGraphNode_ActorList
{
	public:
	    char UnknownData0[0x48];
	    class UReplicationGraphNode* DynamicNode; // 0x140 Size: 0x8
	    class UReplicationGraphNode_DormancyNode* DormancyNode; // 0x148 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ReplicationGraph.ReplicationGraphNode_GridCell");
			return (class UClass*)ptr;
		};

};

class UReplicationGraphNode_GridSpatialization2D : public UReplicationGraphNode
{
	public:
	    char UnknownData0[0x210];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ReplicationGraph.ReplicationGraphNode_GridSpatialization2D");
			return (class UClass*)ptr;
		};

};

class UReplicationGraphNode_AlwaysRelevant : public UReplicationGraphNode
{
	public:
	    class UReplicationGraphNode* ChildNode; // 0x50 Size: 0x8
	    char UnknownData0[0x10];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ReplicationGraph.ReplicationGraphNode_AlwaysRelevant");
			return (class UClass*)ptr;
		};

};

class UReplicationGraphNode_AlwaysRelevant_ForConnection : public UReplicationGraphNode_ActorList
{
	public:
	    char UnknownData0[0x18];
	    class AActor* LastViewer; // 0x110 Size: 0x8
	    class AActor* LastViewTarget; // 0x118 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ReplicationGraph.ReplicationGraphNode_AlwaysRelevant_ForConnection");
			return (class UClass*)ptr;
		};

};

class UReplicationGraphNode_TearOff_ForConnection : public UReplicationGraphNode
{
	public:
	    TArray<struct FTearOffActorInfo> TearOffActors; // 0x50 Size: 0x10
	    char UnknownData0[0x18];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ReplicationGraph.ReplicationGraphNode_TearOff_ForConnection");
			return (class UClass*)ptr;
		};

};

class UNetReplicationGraphConnection : public UReplicationConnectionDriver
{
	public:
	    class UNetConnection* NetConnection; // 0x28 Size: 0x8
	    char UnknownData0[0x140]; // 0x30
	    class AReplicationGraphDebugActor* DebugActor; // 0x170 Size: 0x8
	    char UnknownData1[0x18]; // 0x178
	    TArray<class UReplicationGraphNode*> ConnectionGraphNodes; // 0x190 Size: 0x10
	    class UReplicationGraphNode_TearOff_ForConnection* TearOffNode; // 0x1a0 Size: 0x8
	    char UnknownData2[0x70];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ReplicationGraph.NetReplicationGraphConnection");
			return (class UClass*)ptr;
		};

};

class AReplicationGraphDebugActor : public AActor
{
	public:
	    class UReplicationGraph* ReplicationGraph; // 0x330 Size: 0x8
	    class UNetReplicationGraphConnection* ConnectionManager; // 0x338 Size: 0x8
	    char UnknownData0[0x340]; // 0x340
	    void ServerStopDebugging(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void ServerStartDebugging(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void ServerSetPeriodFrameForClass(class UObject* Class, int PeriodFrame); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void ServerSetCullDistanceForClass(class UObject* Class, float CullDistance); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void ServerSetConditionalActorBreakpoint(class AActor* Actor); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ServerPrintAllActorInfo(struct FString Str); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ServerCellInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void ClientCellInfo(struct FVector CellLocation, struct FVector CellExtent, TArray<class AActor*> Actors); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7ca1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ReplicationGraph.ReplicationGraphDebugActor");
			return (class UClass*)ptr;
		};

};


}