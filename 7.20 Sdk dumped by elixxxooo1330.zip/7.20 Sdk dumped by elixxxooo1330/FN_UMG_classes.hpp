#pragma once

#include "../SDK.hpp"

namespace SDK {


class UVisual : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.Visual");
			return (class UClass*)ptr;
		};

};

class UWidget : public UVisual
{
	public:
	    class UPanelSlot* Slot; // 0x28 Size: 0x8
	    __int64/*DelegateProperty*/ bIsEnabledDelegate; // 0x30 Size: 0x10
	    struct FText ToolTipText; // 0x40 Size: 0x18
	    __int64/*DelegateProperty*/ ToolTipTextDelegate; // 0x58 Size: 0x10
	    class UWidget* ToolTipWidget; // 0x68 Size: 0x8
	    __int64/*DelegateProperty*/ ToolTipWidgetDelegate; // 0x70 Size: 0x10
	    __int64/*DelegateProperty*/ VisibilityDelegate; // 0x80 Size: 0x10
	    struct FWidgetTransform RenderTransform; // 0x90 Size: 0x1c
	    struct FVector2D RenderTransformPivot; // 0xac Size: 0x8
	    bool bIsVariable; // 0xb4 Size: 0x1
	    bool bCreatedByConstructionScript; // 0xb4 Size: 0x1
	    bool bIsEnabled; // 0xb4 Size: 0x1
	    bool bOverride_Cursor; // 0xb4 Size: 0x1
	    bool bIsVolatile; // 0xb4 Size: 0x1
	    char UnknownData0[0x4]; // 0xb9
	    char Cursor; // 0xb5 Size: 0x1
	    EWidgetClipping Clipping; // 0xb6 Size: 0x1
	    ESlateVisibility Visibility; // 0xb7 Size: 0x1
	    float RenderOpacity; // 0xb8 Size: 0x4
	    char UnknownData1[0x4]; // 0xbc
	    class UWidgetNavigation* Navigation; // 0xc0 Size: 0x8
	    char UnknownData2[0x28]; // 0xc8
	    TArray<class UPropertyBinding*> NativeBindings; // 0xf0 Size: 0x10
	    char UnknownData3[0x100]; // 0x100
	    void SetVisibility(ESlateVisibility InVisibility); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetUserFocus(class APlayerController* PlayerController); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetToolTipText(struct FText InToolTipText); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetToolTip(class UWidget* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetRenderTranslation(struct FVector2D Translation); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetRenderTransformPivot(struct FVector2D Pivot); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetRenderTransform(struct FWidgetTransform InTransform); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetRenderShear(struct FVector2D Shear); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetRenderScale(struct FVector2D Scale); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetRenderOpacity(float InOpacity); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void SetRenderAngle(float Angle); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void SetNavigationRule(EUINavigation Direction, EUINavigationRule Rule, FName WidgetToFocus); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void SetKeyboardFocus(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void SetIsEnabled(bool bInIsEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void SetCursor(char InCursor); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void SetClipping(EWidgetClipping InClipping); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void SetAllNavigationRules(EUINavigationRule Rule, FName WidgetToFocus); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void ResetCursor(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void RemoveFromParent(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnReply__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnPointerEvent__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    bool IsVisible(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    bool IsHovered(); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void InvalidateLayoutAndVolatility(); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    bool HasUserFocusedDescendants(class APlayerController* PlayerController); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    bool HasUserFocus(class APlayerController* PlayerController); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    bool HasMouseCaptureByUser(int UserIndex, int PointerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    bool HasMouseCapture(); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    bool HasKeyboardFocus(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    bool HasFocusedDescendants(); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    bool HasAnyUserFocus(); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ GetWidget__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    ESlateVisibility GetVisibility(); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ GetText__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ GetSlateVisibility__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ GetSlateColor__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ GetSlateBrush__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    float GetRenderOpacity(); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    class UPanelWidget* GetParent(); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    class APlayerController* GetOwningPlayer(); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    class ULocalPlayer* GetOwningLocalPlayer(); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ GetMouseCursor__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ GetLinearColor__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    bool GetIsEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ GetInt32__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    class UGameInstance* GetGameInstance(); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ GetFloat__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    struct FVector2D GetDesiredSize(); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    EWidgetClipping GetClipping(); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ GetCheckBoxState__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    struct FGeometry GetCachedGeometry(); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ GetBool__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ GenerateWidgetForString__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ GenerateWidgetForObject__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    void ForceVolatile(bool bForce); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    void ForceLayoutPrepass(); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x-7ee1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.Widget");
			return (class UClass*)ptr;
		};

};

class USlider : public UWidget
{
	public:
	    float Value; // 0x100 Size: 0x4
	    __int64/*DelegateProperty*/ ValueDelegate; // 0x104 Size: 0x10
	    char UnknownData0[0x4]; // 0x114
	    struct FSliderStyle WidgetStyle; // 0x118 Size: 0x340
	    char Orientation; // 0x458 Size: 0x1
	    char UnknownData1[0x3]; // 0x459
	    struct FLinearColor SliderBarColor; // 0x45c Size: 0x10
	    struct FLinearColor SliderHandleColor; // 0x46c Size: 0x10
	    bool IndentHandle; // 0x47c Size: 0x1
	    bool Locked; // 0x47d Size: 0x1
	    bool MouseUsesStep; // 0x47e Size: 0x1
	    bool RequiresControllerLock; // 0x47f Size: 0x1
	    float StepSize; // 0x480 Size: 0x4
	    bool IsFocusable; // 0x484 Size: 0x1
	    char UnknownData2[0x3]; // 0x485
	    MulticastDelegateProperty OnMouseCaptureBegin; // 0x488 Size: 0x10
	    MulticastDelegateProperty OnMouseCaptureEnd; // 0x498 Size: 0x10
	    MulticastDelegateProperty OnControllerCaptureBegin; // 0x4a8 Size: 0x10
	    MulticastDelegateProperty OnControllerCaptureEnd; // 0x4b8 Size: 0x10
	    MulticastDelegateProperty OnValueChanged; // 0x4c8 Size: 0x10
	    char UnknownData3[0x4d8]; // 0x4d8
	    void SetValue(float InValue); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetStepSize(float InValue); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetSliderHandleColor(struct FLinearColor InValue); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetSliderBarColor(struct FLinearColor InValue); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetLocked(bool InValue); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetIndentHandle(bool InValue); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    float GetValue(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7af9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.Slider");
			return (class UClass*)ptr;
		};

};

class UUserWidget : public UWidget
{
	public:
	    char UnknownData0[0x8];
	    struct FLinearColor ColorAndOpacity; // 0x108 Size: 0x10
	    __int64/*DelegateProperty*/ ColorAndOpacityDelegate; // 0x118 Size: 0x10
	    struct FSlateColor ForegroundColor; // 0x128 Size: 0x28
	    __int64/*DelegateProperty*/ ForegroundColorDelegate; // 0x150 Size: 0x10
	    struct FMargin Padding; // 0x160 Size: 0x10
	    TArray<class UUMGSequencePlayer*> ActiveSequencePlayers; // 0x170 Size: 0x10
	    TArray<class UUMGSequencePlayer*> StoppedSequencePlayers; // 0x180 Size: 0x10
	    TArray<struct FNamedSlotBinding> NamedSlotBindings; // 0x190 Size: 0x10
	    class UWidgetTree* WidgetTree; // 0x1a0 Size: 0x8
	    int Priority; // 0x1a8 Size: 0x4
	    bool bSupportsKeyboardFocus; // 0x1ac Size: 0x1
	    bool bIsFocusable; // 0x1ac Size: 0x1
	    bool bStopAction; // 0x1ac Size: 0x1
	    bool bHasScriptImplementedTick; // 0x1ac Size: 0x1
	    bool bHasScriptImplementedPaint; // 0x1ac Size: 0x1
	    bool bCookedWidgetTree; // 0x1ac Size: 0x1
	    char UnknownData1[0x6]; // 0x1b2
	    EWidgetTickFrequency TickFrequency; // 0x1b8 Size: 0x1
	    char UnknownData2[0x7]; // 0x1b9
	    class UInputComponent* InputComponent; // 0x1c0 Size: 0x8
	    TArray<struct FAnimationEventBinding> AnimationCallbacks; // 0x1c8 Size: 0x10
	    char UnknownData3[0x1d8]; // 0x1d8
	    void UnregisterInputComponent(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void UnbindFromAnimationStarted(class UWidgetAnimation* Animation, __int64/*DelegateProperty*/ Delegate); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void UnbindFromAnimationFinished(class UWidgetAnimation* Animation, __int64/*DelegateProperty*/ Delegate); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void UnbindAllFromAnimationStarted(class UWidgetAnimation* Animation); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void UnbindAllFromAnimationFinished(class UWidgetAnimation* Animation); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void Tick(struct FGeometry MyGeometry, float InDeltaTime); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void StopListeningForInputAction(FName ActionName, char EventType); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void StopListeningForAllInputActions(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void StopAnimationsAndLatentActions(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void StopAnimation(class UWidgetAnimation* InAnimation); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void StopAllAnimations(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void SetPositionInViewport(struct FVector2D Position, bool bRemoveDPIScale); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void SetPlaybackSpeed(class UWidgetAnimation* InAnimation, float PlaybackSpeed); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void SetPadding(struct FMargin InPadding); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void SetOwningPlayer(class APlayerController* LocalPlayerController); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void SetNumLoopsToPlay(class UWidgetAnimation* InAnimation, int NumLoopsToPlay); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void SetInputActionPriority(int NewPriority); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void SetInputActionBlocking(bool bShouldBlock); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void SetForegroundColor(struct FSlateColor InForegroundColor); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void SetDesiredSizeInViewport(struct FVector2D Size); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void SetColorAndOpacity(struct FLinearColor InColorAndOpacity); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void SetAnchorsInViewport(struct FAnchors Anchors); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void SetAlignmentInViewport(struct FVector2D Alignment); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void ReverseAnimation(class UWidgetAnimation* InAnimation); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void RemoveFromViewport(); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void RegisterInputComponent(); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    void PreConstruct(bool IsDesignTime); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    void PlaySound(class USoundBase* SoundToPlay); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    class UUMGSequencePlayer* PlayAnimationTimeRange(class UWidgetAnimation* InAnimation, float StartAtTime, float EndAtTime, int NumLoopsToPlay, char PlayMode, float PlaybackSpeed); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    class UUMGSequencePlayer* PlayAnimationReverse(class UWidgetAnimation* InAnimation, float PlaybackSpeed); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    class UUMGSequencePlayer* PlayAnimationForward(class UWidgetAnimation* InAnimation, float PlaybackSpeed); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    class UUMGSequencePlayer* PlayAnimation(class UWidgetAnimation* InAnimation, float StartAtTime, int NumLoopsToPlay, char PlayMode, float PlaybackSpeed); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    float PauseAnimation(class UWidgetAnimation* InAnimation); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    struct FEventReply OnTouchStarted(struct FGeometry MyGeometry, struct FPointerEvent InTouchEvent); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    struct FEventReply OnTouchMoved(struct FGeometry MyGeometry, struct FPointerEvent InTouchEvent); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    struct FEventReply OnTouchGesture(struct FGeometry MyGeometry, struct FPointerEvent GestureEvent); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    struct FEventReply OnTouchForceChanged(struct FGeometry MyGeometry, struct FPointerEvent InTouchEvent); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    struct FEventReply OnTouchEnded(struct FGeometry MyGeometry, struct FPointerEvent InTouchEvent); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    void OnRemovedFromFocusPath(struct FFocusEvent InFocusEvent); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    struct FEventReply OnPreviewMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    struct FEventReply OnPreviewKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    void OnPaint(struct FPaintContext Context); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    struct FEventReply OnMouseWheel(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    struct FEventReply OnMouseMove(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    void OnMouseLeave(struct FPointerEvent MouseEvent); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    void OnMouseEnter(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    void OnMouseCaptureLost(); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    struct FEventReply OnMouseButtonUp(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    struct FEventReply OnMouseButtonDoubleClick(struct FGeometry InMyGeometry, struct FPointerEvent InMouseEvent); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    struct FEventReply OnMotionDetected(struct FGeometry MyGeometry, struct FMotionEvent InMotionEvent); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    struct FEventReply OnKeyUp(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    struct FEventReply OnKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    struct FEventReply OnKeyChar(struct FGeometry MyGeometry, struct FCharacterEvent InCharacterEvent); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    void OnInitialized(); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    void OnFocusLost(struct FFocusEvent InFocusEvent); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    bool OnDrop(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, class UDragDropOperation* Operation); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    bool OnDragOver(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, class UDragDropOperation* Operation); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x7fe1]; // 0x7fe1
	    void OnDragLeave(struct FPointerEvent PointerEvent, class UDragDropOperation* Operation); // 0x0 Size: 0x7fe1
	    char UnknownData63[0x7fe1]; // 0x7fe1
	    void OnDragEnter(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, class UDragDropOperation* Operation); // 0x0 Size: 0x7fe1
	    char UnknownData64[0x7fe1]; // 0x7fe1
	    void OnDragDetected(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, class UDragDropOperation* Operation); // 0x0 Size: 0x7fe1
	    char UnknownData65[0x7fe1]; // 0x7fe1
	    void OnDragCancelled(struct FPointerEvent PointerEvent, class UDragDropOperation* Operation); // 0x0 Size: 0x7fe1
	    char UnknownData66[0x7fe1]; // 0x7fe1
	    void OnAnimationStarted(class UWidgetAnimation* Animation); // 0x0 Size: 0x7fe1
	    char UnknownData67[0x7fe1]; // 0x7fe1
	    void OnAnimationFinished(class UWidgetAnimation* Animation); // 0x0 Size: 0x7fe1
	    char UnknownData68[0x7fe1]; // 0x7fe1
	    struct FEventReply OnAnalogValueChanged(struct FGeometry MyGeometry, struct FAnalogInputEvent InAnalogInputEvent); // 0x0 Size: 0x7fe1
	    char UnknownData69[0x7fe1]; // 0x7fe1
	    void OnAddedToFocusPath(struct FFocusEvent InFocusEvent); // 0x0 Size: 0x7fe1
	    char UnknownData70[0x7fe1]; // 0x7fe1
	    void ListenForInputAction(FName ActionName, char EventType, bool bConsume, __int64/*DelegateProperty*/ Callback); // 0x0 Size: 0x7fe1
	    char UnknownData71[0x7fe1]; // 0x7fe1
	    bool IsPlayingAnimation(); // 0x0 Size: 0x7fe1
	    char UnknownData72[0x7fe1]; // 0x7fe1
	    bool IsListeningForInputAction(FName ActionName); // 0x0 Size: 0x7fe1
	    char UnknownData73[0x7fe1]; // 0x7fe1
	    bool IsInViewport(); // 0x0 Size: 0x7fe1
	    char UnknownData74[0x7fe1]; // 0x7fe1
	    bool IsInteractable(); // 0x0 Size: 0x7fe1
	    char UnknownData75[0x7fe1]; // 0x7fe1
	    bool IsAnyAnimationPlaying(); // 0x0 Size: 0x7fe1
	    char UnknownData76[0x7fe1]; // 0x7fe1
	    bool IsAnimationPlayingForward(class UWidgetAnimation* InAnimation); // 0x0 Size: 0x7fe1
	    char UnknownData77[0x7fe1]; // 0x7fe1
	    bool IsAnimationPlaying(class UWidgetAnimation* InAnimation); // 0x0 Size: 0x7fe1
	    char UnknownData78[0x7fe1]; // 0x7fe1
	    class APawn* GetOwningPlayerPawn(); // 0x0 Size: 0x7fe1
	    char UnknownData79[0x7fe1]; // 0x7fe1
	    bool GetIsVisible(); // 0x0 Size: 0x7fe1
	    char UnknownData80[0x7fe1]; // 0x7fe1
	    float GetAnimationCurrentTime(class UWidgetAnimation* InAnimation); // 0x0 Size: 0x7fe1
	    char UnknownData81[0x7fe1]; // 0x7fe1
	    struct FAnchors GetAnchorsInViewport(); // 0x0 Size: 0x7fe1
	    char UnknownData82[0x7fe1]; // 0x7fe1
	    struct FVector2D GetAlignmentInViewport(); // 0x0 Size: 0x7fe1
	    char UnknownData83[0x7fe1]; // 0x7fe1
	    void Destruct(); // 0x0 Size: 0x7fe1
	    char UnknownData84[0x7fe1]; // 0x7fe1
	    void Construct(); // 0x0 Size: 0x7fe1
	    char UnknownData85[0x7fe1]; // 0x7fe1
	    void CancelLatentActions(); // 0x0 Size: 0x7fe1
	    char UnknownData86[0x7fe1]; // 0x7fe1
	    void BindToAnimationStarted(class UWidgetAnimation* Animation, __int64/*DelegateProperty*/ Delegate); // 0x0 Size: 0x7fe1
	    char UnknownData87[0x7fe1]; // 0x7fe1
	    void BindToAnimationFinished(class UWidgetAnimation* Animation, __int64/*DelegateProperty*/ Delegate); // 0x0 Size: 0x7fe1
	    char UnknownData88[0x7fe1]; // 0x7fe1
	    void BindToAnimationEvent(class UWidgetAnimation* Animation, __int64/*DelegateProperty*/ Delegate, EWidgetAnimationEvent AnimationEvent, FName UserTag); // 0x0 Size: 0x7fe1
	    char UnknownData89[0x7fe1]; // 0x7fe1
	    void AddToViewport(int ZOrder); // 0x0 Size: 0x7fe1
	    char UnknownData90[0x7fe1]; // 0x7fe1
	    bool AddToPlayerScreen(int ZOrder); // 0x0 Size: 0x7fe1
	    char UnknownData91[0x-7db9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.UserWidget");
			return (class UClass*)ptr;
		};

};

class UPanelWidget : public UWidget
{
	public:
	    TArray<class UPanelSlot*> Slots; // 0x100 Size: 0x10
	    char UnknownData0[0x110]; // 0x110
	    bool RemoveChildAt(int Index); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool RemoveChild(class UWidget* Content); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool HasChild(class UWidget* Content); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool HasAnyChildren(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    int GetChildrenCount(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    int GetChildIndex(class UWidget* Content); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    class UWidget* GetChildAt(int Index); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void ClearChildren(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    class UPanelSlot* AddChild(class UWidget* Content); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7ec9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.PanelWidget");
			return (class UClass*)ptr;
		};

};

class UContentWidget : public UPanelWidget
{
	public:
	    class UPanelSlot* SetContent(class UWidget* Content); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    class UPanelSlot* GetContentSlot(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    class UWidget* GetContent(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7ec9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.ContentWidget");
			return (class UClass*)ptr;
		};

};

class UBorder : public UContentWidget
{
	public:
	    char HorizontalAlignment; // 0x118 Size: 0x1
	    char VerticalAlignment; // 0x119 Size: 0x1
	    bool bShowEffectWhenDisabled; // 0x11a Size: 0x1
	    char UnknownData0[0x1]; // 0x11b
	    struct FLinearColor ContentColorAndOpacity; // 0x11c Size: 0x10
	    __int64/*DelegateProperty*/ ContentColorAndOpacityDelegate; // 0x12c Size: 0x10
	    struct FMargin Padding; // 0x13c Size: 0x10
	    char UnknownData1[0x4]; // 0x14c
	    struct FSlateBrush Background; // 0x150 Size: 0x88
	    __int64/*DelegateProperty*/ BackgroundDelegate; // 0x1d8 Size: 0x10
	    struct FLinearColor BrushColor; // 0x1e8 Size: 0x10
	    __int64/*DelegateProperty*/ BrushColorDelegate; // 0x1f8 Size: 0x10
	    struct FVector2D DesiredSizeScale; // 0x208 Size: 0x8
	    __int64/*DelegateProperty*/ OnMouseButtonDownEvent; // 0x210 Size: 0x10
	    __int64/*DelegateProperty*/ OnMouseButtonUpEvent; // 0x220 Size: 0x10
	    __int64/*DelegateProperty*/ OnMouseMoveEvent; // 0x230 Size: 0x10
	    __int64/*DelegateProperty*/ OnMouseDoubleClickEvent; // 0x240 Size: 0x10
	    char UnknownData2[0x250]; // 0x250
	    void SetVerticalAlignment(char InVerticalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetPadding(struct FMargin InPadding); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetHorizontalAlignment(char InHorizontalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetDesiredSizeScale(struct FVector2D InScale); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetContentColorAndOpacity(struct FLinearColor InContentColorAndOpacity); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetBrushFromTexture(class UTexture2D* Texture); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetBrushFromMaterial(class UMaterialInterface* Material); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetBrushFromAsset(class USlateBrushAsset* Asset); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetBrushColor(struct FLinearColor InBrushColor); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetBrush(struct FSlateBrush InBrush); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    class UMaterialInstanceDynamic* GetDynamicMaterial(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x-7d81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.Border");
			return (class UClass*)ptr;
		};

};

class UButton : public UContentWidget
{
	public:
	    class USlateWidgetStyleAsset* Style; // 0x118 Size: 0x8
	    struct FButtonStyle WidgetStyle; // 0x120 Size: 0x278
	    struct FLinearColor ColorAndOpacity; // 0x398 Size: 0x10
	    struct FLinearColor BackgroundColor; // 0x3a8 Size: 0x10
	    char ClickMethod; // 0x3b8 Size: 0x1
	    char TouchMethod; // 0x3b9 Size: 0x1
	    char PressMethod; // 0x3ba Size: 0x1
	    bool IsFocusable; // 0x3bb Size: 0x1
	    char UnknownData0[0x4]; // 0x3bc
	    MulticastDelegateProperty OnClicked; // 0x3c0 Size: 0x10
	    MulticastDelegateProperty OnPressed; // 0x3d0 Size: 0x10
	    MulticastDelegateProperty OnReleased; // 0x3e0 Size: 0x10
	    MulticastDelegateProperty OnHovered; // 0x3f0 Size: 0x10
	    MulticastDelegateProperty OnUnhovered; // 0x400 Size: 0x10
	    char UnknownData1[0x410]; // 0x410
	    void SetTouchMethod(char InTouchMethod); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetStyle(struct FButtonStyle InStyle); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetPressMethod(char InPressMethod); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetColorAndOpacity(struct FLinearColor InColorAndOpacity); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetClickMethod(char InClickMethod); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetBackgroundColor(struct FLinearColor InBackgroundColor); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool IsPressed(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7bc1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.Button");
			return (class UClass*)ptr;
		};

};

class UTextLayoutWidget : public UWidget
{
	public:
	    struct FShapedTextOptions ShapedTextOptions; // 0x100 Size: 0x3
	    char Justification; // 0x103 Size: 0x1
	    ETextWrappingPolicy WrappingPolicy; // 0x104 Size: 0x1
	    bool AutoWrapText; // 0x105 Size: 0x1
	    char UnknownData0[0x2]; // 0x106
	    float WrapTextAt; // 0x108 Size: 0x4
	    struct FMargin Margin; // 0x10c Size: 0x10
	    float LineHeightPercentage; // 0x11c Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.TextLayoutWidget");
			return (class UClass*)ptr;
		};

};

class UTextBlock : public UTextLayoutWidget
{
	public:
	    struct FText Text; // 0x120 Size: 0x18
	    __int64/*DelegateProperty*/ TextDelegate; // 0x138 Size: 0x10
	    struct FSlateColor ColorAndOpacity; // 0x148 Size: 0x28
	    __int64/*DelegateProperty*/ ColorAndOpacityDelegate; // 0x170 Size: 0x10
	    struct FSlateFontInfo Font; // 0x180 Size: 0x50
	    struct FVector2D ShadowOffset; // 0x1d0 Size: 0x8
	    struct FLinearColor ShadowColorAndOpacity; // 0x1d8 Size: 0x10
	    __int64/*DelegateProperty*/ ShadowColorAndOpacityDelegate; // 0x1e8 Size: 0x10
	    float MinDesiredWidth; // 0x1f8 Size: 0x4
	    bool bWrapWithInvalidationPanel; // 0x1fc Size: 0x1
	    bool bAutoWrapText; // 0x1fd Size: 0x1
	    bool bSimpleTextMode; // 0x1fe Size: 0x1
	    char UnknownData0[0x1ff]; // 0x1ff
	    void SetText(struct FText InText); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetShadowOffset(struct FVector2D InShadowOffset); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetShadowColorAndOpacity(struct FLinearColor InShadowColorAndOpacity); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetOpacity(float InOpacity); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetMinDesiredWidth(float InMinDesiredWidth); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetJustification(char InJustification); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetFont(struct FSlateFontInfo InFontInfo); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetColorAndOpacity(struct FSlateColor InColorAndOpacity); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetAutoWrapText(bool InAutoTextWrap); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    struct FText GetText(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    class UMaterialInstanceDynamic* GetDynamicOutlineMaterial(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    class UMaterialInstanceDynamic* GetDynamicFontMaterial(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7dd1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.TextBlock");
			return (class UClass*)ptr;
		};

};

class UScrollBox : public UPanelWidget
{
	public:
	    struct FScrollBoxStyle WidgetStyle; // 0x118 Size: 0x228
	    struct FScrollBarStyle WidgetBarStyle; // 0x340 Size: 0x4d0
	    class USlateWidgetStyleAsset* Style; // 0x810 Size: 0x8
	    class USlateWidgetStyleAsset* BarStyle; // 0x818 Size: 0x8
	    char Orientation; // 0x820 Size: 0x1
	    ESlateVisibility ScrollBarVisibility; // 0x821 Size: 0x1
	    EConsumeMouseWheel ConsumeMouseWheel; // 0x822 Size: 0x1
	    char UnknownData0[0x1]; // 0x823
	    struct FVector2D ScrollbarThickness; // 0x824 Size: 0x8
	    bool AlwaysShowScrollbar; // 0x82c Size: 0x1
	    bool AllowOverscroll; // 0x82d Size: 0x1
	    EDescendantScrollDestination NavigationDestination; // 0x82e Size: 0x1
	    char UnknownData1[0x1]; // 0x82f
	    float NavigationScrollPadding; // 0x830 Size: 0x4
	    bool bAllowRightClickDragScrolling; // 0x834 Size: 0x1
	    char UnknownData2[0x3]; // 0x835
	    MulticastDelegateProperty OnUserScrolled; // 0x838 Size: 0x10
	    char UnknownData3[0x848]; // 0x848
	    void SetScrollOffset(float NewScrollOffset); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetScrollBarVisibility(ESlateVisibility NewScrollBarVisibility); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetScrollbarThickness(struct FVector2D NewScrollbarThickness); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetOrientation(char NewOrientation); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetAlwaysShowScrollbar(bool NewAlwaysShowScrollbar); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetAllowOverscroll(bool NewAllowOverscroll); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void ScrollWidgetIntoView(class UWidget* WidgetToFind, bool AnimateScroll, EDescendantScrollDestination ScrollDestination); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void ScrollToStart(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void ScrollToEnd(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    float GetViewOffsetFraction(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    float GetScrollOffset(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x-7781];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.ScrollBox");
			return (class UClass*)ptr;
		};

};

class UImage : public UWidget
{
	public:
	    struct FSlateBrush Brush; // 0x100 Size: 0x88
	    __int64/*DelegateProperty*/ BrushDelegate; // 0x188 Size: 0x10
	    struct FLinearColor ColorAndOpacity; // 0x198 Size: 0x10
	    __int64/*DelegateProperty*/ ColorAndOpacityDelegate; // 0x1a8 Size: 0x10
	    __int64/*DelegateProperty*/ OnMouseButtonDownEvent; // 0x1b8 Size: 0x10
	    char UnknownData0[0x1c8]; // 0x1c8
	    void SetOpacity(float InOpacity); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetColorAndOpacity(struct FLinearColor InColorAndOpacity); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetBrushTintColor(struct FSlateColor TintColor); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetBrushSize(struct FVector2D DesiredSize); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetBrushFromTextureDynamic(class UTexture2DDynamic* Texture, bool bMatchSize); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetBrushFromTexture(class UTexture2D* Texture, bool bMatchSize); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetBrushFromSoftTexture(struct TSoftObjectPtr<struct UTexture2D*> SoftTexture, bool bMatchSize); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetBrushFromSoftMaterial(struct TSoftObjectPtr<struct UMaterialInterface*> SoftMaterial); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetBrushFromMaterial(class UMaterialInterface* Material); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetBrushFromAtlasInterface(__int64/*InterfaceProperty*/ AtlasRegion, bool bMatchSize); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetBrushFromAsset(class USlateBrushAsset* Asset); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetBrush(struct FSlateBrush InBrush); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    class UMaterialInstanceDynamic* GetDynamicMaterial(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x-7de1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.Image");
			return (class UClass*)ptr;
		};

};

class UListViewBase : public UWidget
{
	public:
	    class UUserWidget* EntryWidgetClass; // 0x100 Size: 0x8
	    MulticastDelegateProperty BP_OnEntryGenerated; // 0x108 Size: 0x10
	    MulticastDelegateProperty BP_OnEntryReleased; // 0x118 Size: 0x10
	    char UnknownData0[0x128]; // 0x128
	    void ScrollToTop(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void ScrollToBottom(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void RegenerateAllEntries(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    TArray<class UUserWidget*> GetDisplayedEntryWidgets(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7dd9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.ListViewBase");
			return (class UClass*)ptr;
		};

};

class UListView : public UListViewBase
{
	public:
	    char UnknownData0[0xa8];
	    char SelectionMode; // 0x2b0 Size: 0x1
	    EConsumeMouseWheel ConsumeMouseWheel; // 0x2b1 Size: 0x1
	    bool bClearSelectionOnClick; // 0x2b2 Size: 0x1
	    bool bIsFocusable; // 0x2b3 Size: 0x1
	    float EntrySpacing; // 0x2b4 Size: 0x4
	    bool bReturnFocusToSelection; // 0x2b8 Size: 0x1
	    char UnknownData1[0x7]; // 0x2b9
	    TArray<class UObject*> ListItems; // 0x2c0 Size: 0x10
	    char UnknownData2[0x10]; // 0x2d0
	    MulticastDelegateProperty BP_OnItemClicked; // 0x2e0 Size: 0x10
	    MulticastDelegateProperty BP_OnItemDoubleClicked; // 0x2f0 Size: 0x10
	    MulticastDelegateProperty BP_OnItemIsHoveredChanged; // 0x300 Size: 0x10
	    MulticastDelegateProperty BP_OnItemSelectionChanged; // 0x310 Size: 0x10
	    MulticastDelegateProperty BP_OnItemScrolledIntoView; // 0x320 Size: 0x10
	    char UnknownData3[0x330]; // 0x330
	    void SetSelectionMode(char SelectionMode); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetSelectedIndex(int Index); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ScrollIndexIntoView(int Index); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void NavigateToIndex(int Index); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool IsRefreshPending(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    int GetNumItems(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    TArray<class UObject*> GetListItems(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    class UObject* GetItemAt(int Index); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    int GetIndexForItem(class UObject* Item); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void ClearListItems(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void BP_SetSelectedItem(class UObject* Item); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void BP_SetListItems(TArray<class UObject*> InListItems); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void BP_SetItemSelection(class UObject* Item, bool bSelected); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void BP_ScrollItemIntoView(class UObject* Item); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void BP_NavigateToItem(class UObject* Item); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    bool BP_IsItemVisible(class UObject* Item); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    bool BP_GetSelectedItems(TArray<class UObject*> Items); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    class UObject* BP_GetSelectedItem(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    int BP_GetNumItemsSelected(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void BP_ClearSelection(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void BP_CancelScrollIntoView(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void AddItem(class UObject* Item); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x-7cb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.ListView");
			return (class UClass*)ptr;
		};

};

class UPanelSlot : public UVisual
{
	public:
	    class UPanelWidget* Parent; // 0x28 Size: 0x8
	    class UWidget* Content; // 0x30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.PanelSlot");
			return (class UClass*)ptr;
		};

};

class UTileView : public UListView
{
	public:
	    float EntryHeight; // 0x330 Size: 0x4
	    float EntryWidth; // 0x334 Size: 0x4
	    EListItemAlignment TileAlignment; // 0x338 Size: 0x1
	    bool bWrapHorizontalNavigation; // 0x339 Size: 0x1
	    char UnknownData0[0x33a]; // 0x33a
	    void SetEntryWidth(float NewWidth); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetEntryHeight(float NewHeight); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7c91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.TileView");
			return (class UClass*)ptr;
		};

};

class UTreeView : public UListView
{
	public:
	    char UnknownData0[0x10];
	    __int64/*DelegateProperty*/ BP_OnGetItemChildren; // 0x340 Size: 0x10
	    MulticastDelegateProperty BP_OnItemExpansionChanged; // 0x350 Size: 0x10
	    char UnknownData1[0x360]; // 0x360
	    void SetItemExpansion(class UObject* Item, bool bExpandItem); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void ExpandAll(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void CollapseAll(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7c59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.TreeView");
			return (class UClass*)ptr;
		};

};

class UWidgetSwitcher : public UPanelWidget
{
	public:
	    int ActiveWidgetIndex; // 0x118 Size: 0x4
	    char UnknownData0[0x11c]; // 0x11c
	    void SetActiveWidgetIndex(int Index); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetActiveWidget(class UWidget* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    class UWidget* GetWidgetAtIndex(int Index); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    int GetNumWidgets(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    int GetActiveWidgetIndex(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    class UWidget* GetActiveWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7eb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.WidgetSwitcher");
			return (class UClass*)ptr;
		};

};

class UAsyncTaskDownloadImage : public UBlueprintAsyncActionBase
{
	public:
	    MulticastDelegateProperty OnSuccess; // 0x30 Size: 0x10
	    MulticastDelegateProperty OnFail; // 0x40 Size: 0x10
	    char UnknownData0[0x50]; // 0x50
	    static class UAsyncTaskDownloadImage* DownloadImage(struct FString URL); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.AsyncTaskDownloadImage");
			return (class UClass*)ptr;
		};

};

class UBackgroundBlur : public UContentWidget
{
	public:
	    struct FMargin Padding; // 0x118 Size: 0x10
	    char HorizontalAlignment; // 0x128 Size: 0x1
	    char VerticalAlignment; // 0x129 Size: 0x1
	    bool bApplyAlphaToBlur; // 0x12a Size: 0x1
	    char UnknownData0[0x1]; // 0x12b
	    float BlurStrength; // 0x12c Size: 0x4
	    bool bOverrideAutoRadiusCalculation; // 0x130 Size: 0x1
	    char UnknownData1[0x3]; // 0x131
	    int BlurRadius; // 0x134 Size: 0x4
	    struct FSlateBrush LowQualityFallbackBrush; // 0x138 Size: 0x88
	    char UnknownData2[0x1c0]; // 0x1c0
	    void SetVerticalAlignment(char InVerticalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetPadding(struct FMargin InPadding); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetLowQualityFallbackBrush(struct FSlateBrush InBrush); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetHorizontalAlignment(char InHorizontalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetBlurStrength(float InStrength); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetBlurRadius(int InBlurRadius); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetApplyAlphaToBlur(bool bInApplyAlphaToBlur); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7e11];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.BackgroundBlur");
			return (class UClass*)ptr;
		};

};

class UBackgroundBlurSlot : public UPanelSlot
{
	public:
	    struct FMargin Padding; // 0x38 Size: 0x10
	    char HorizontalAlignment; // 0x48 Size: 0x1
	    char VerticalAlignment; // 0x49 Size: 0x1
	    char UnknownData0[0x4a]; // 0x4a
	    void SetVerticalAlignment(char InVerticalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetPadding(struct FMargin InPadding); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetHorizontalAlignment(char InHorizontalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.BackgroundBlurSlot");
			return (class UClass*)ptr;
		};

};

class UPropertyBinding : public UObject
{
	public:
	    TWeakObjectPtr<UObject*> SourceObject; // 0x28 Size: 0x8
	    struct FDynamicPropertyPath SourcePath; // 0x30 Size: 0x28
	    FName DestinationProperty; // 0x58 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.PropertyBinding");
			return (class UClass*)ptr;
		};

};

class UBoolBinding : public UPropertyBinding
{
	public:
	    bool GetValue(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.BoolBinding");
			return (class UClass*)ptr;
		};

};

class UBorderSlot : public UPanelSlot
{
	public:
	    struct FMargin Padding; // 0x38 Size: 0x10
	    char HorizontalAlignment; // 0x48 Size: 0x1
	    char VerticalAlignment; // 0x49 Size: 0x1
	    char UnknownData0[0x4a]; // 0x4a
	    void SetVerticalAlignment(char InVerticalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetPadding(struct FMargin InPadding); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetHorizontalAlignment(char InHorizontalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.BorderSlot");
			return (class UClass*)ptr;
		};

};

class UBrushBinding : public UPropertyBinding
{
	public:
	    struct FSlateBrush GetValue(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7f79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.BrushBinding");
			return (class UClass*)ptr;
		};

};

class UButtonSlot : public UPanelSlot
{
	public:
	    struct FMargin Padding; // 0x38 Size: 0x10
	    char HorizontalAlignment; // 0x48 Size: 0x1
	    char VerticalAlignment; // 0x49 Size: 0x1
	    char UnknownData0[0x4a]; // 0x4a
	    void SetVerticalAlignment(char InVerticalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetPadding(struct FMargin InPadding); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetHorizontalAlignment(char InHorizontalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.ButtonSlot");
			return (class UClass*)ptr;
		};

};

class UCanvasPanel : public UPanelWidget
{
	public:
	    class UCanvasPanelSlot* AddChildToCanvas(class UWidget* Content); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7eb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.CanvasPanel");
			return (class UClass*)ptr;
		};

};

class UCanvasPanelSlot : public UPanelSlot
{
	public:
	    struct FAnchorData LayoutData; // 0x38 Size: 0x28
	    bool bAutoSize; // 0x60 Size: 0x1
	    char UnknownData0[0x3]; // 0x61
	    int ZOrder; // 0x64 Size: 0x4
	    char UnknownData1[0x68]; // 0x68
	    void SetZOrder(int InZOrder); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetSize(struct FVector2D InSize); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetPosition(struct FVector2D InPosition); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetOffsets(struct FMargin InOffset); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetMinimum(struct FVector2D InMinimumAnchors); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetMaximum(struct FVector2D InMaximumAnchors); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetLayout(struct FAnchorData InLayoutData); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetAutoSize(bool InbAutoSize); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetAnchors(struct FAnchors InAnchors); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetAlignment(struct FVector2D InAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    int GetZOrder(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    struct FVector2D GetSize(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    struct FVector2D GetPosition(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    struct FMargin GetOffsets(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    struct FAnchorData GetLayout(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    bool GetAutoSize(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    struct FAnchors GetAnchors(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    struct FVector2D GetAlignment(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x-7f71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.CanvasPanelSlot");
			return (class UClass*)ptr;
		};

};

class UCheckBox : public UContentWidget
{
	public:
	    ECheckBoxState CheckedState; // 0x118 Size: 0x1
	    char UnknownData0[0x3]; // 0x119
	    __int64/*DelegateProperty*/ CheckedStateDelegate; // 0x11c Size: 0x10
	    char UnknownData1[0x4]; // 0x12c
	    struct FCheckBoxStyle WidgetStyle; // 0x130 Size: 0x580
	    class USlateWidgetStyleAsset* Style; // 0x6b0 Size: 0x8
	    class USlateBrushAsset* UncheckedImage; // 0x6b8 Size: 0x8
	    class USlateBrushAsset* UncheckedHoveredImage; // 0x6c0 Size: 0x8
	    class USlateBrushAsset* UncheckedPressedImage; // 0x6c8 Size: 0x8
	    class USlateBrushAsset* CheckedImage; // 0x6d0 Size: 0x8
	    class USlateBrushAsset* CheckedHoveredImage; // 0x6d8 Size: 0x8
	    class USlateBrushAsset* CheckedPressedImage; // 0x6e0 Size: 0x8
	    class USlateBrushAsset* UndeterminedImage; // 0x6e8 Size: 0x8
	    class USlateBrushAsset* UndeterminedHoveredImage; // 0x6f0 Size: 0x8
	    class USlateBrushAsset* UndeterminedPressedImage; // 0x6f8 Size: 0x8
	    char HorizontalAlignment; // 0x700 Size: 0x1
	    char UnknownData2[0x3]; // 0x701
	    struct FMargin Padding; // 0x704 Size: 0x10
	    char UnknownData3[0x4]; // 0x714
	    struct FSlateColor BorderBackgroundColor; // 0x718 Size: 0x28
	    bool IsFocusable; // 0x740 Size: 0x1
	    char UnknownData4[0x7]; // 0x741
	    MulticastDelegateProperty OnCheckStateChanged; // 0x748 Size: 0x10
	    char UnknownData5[0x758]; // 0x758
	    void SetIsChecked(bool InIsChecked); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetCheckedState(ECheckBoxState InCheckedState); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool IsPressed(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool IsChecked(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    ECheckBoxState GetCheckedState(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7879];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.CheckBox");
			return (class UClass*)ptr;
		};

};

class UCheckedStateBinding : public UPropertyBinding
{
	public:
	    ECheckBoxState GetValue(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7f79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.CheckedStateBinding");
			return (class UClass*)ptr;
		};

};

class UCircularThrobber : public UWidget
{
	public:
	    int NumberOfPieces; // 0x100 Size: 0x4
	    float Period; // 0x104 Size: 0x4
	    float Radius; // 0x108 Size: 0x4
	    char UnknownData0[0x4]; // 0x10c
	    class USlateBrushAsset* PieceImage; // 0x110 Size: 0x8
	    struct FSlateBrush Image; // 0x118 Size: 0x88
	    bool bEnableRadius; // 0x1a0 Size: 0x1
	    char UnknownData1[0x1a1]; // 0x1a1
	    void SetRadius(float InRadius); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetPeriod(float InPeriod); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetNumberOfPieces(int InNumberOfPieces); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7e29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.CircularThrobber");
			return (class UClass*)ptr;
		};

};

class UColorBinding : public UPropertyBinding
{
	public:
	    struct FSlateColor GetSlateValue(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    struct FLinearColor GetLinearValue(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.ColorBinding");
			return (class UClass*)ptr;
		};

};

class UComboBox : public UWidget
{
	public:
	    TArray<class UObject*> Items; // 0x100 Size: 0x10
	    __int64/*DelegateProperty*/ OnGenerateWidgetEvent; // 0x110 Size: 0x10
	    bool bIsFocusable; // 0x120 Size: 0x1
	    char UnknownData0[0x17];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.ComboBox");
			return (class UClass*)ptr;
		};

};

class UComboBoxString : public UWidget
{
	public:
	    TArray<struct FString> DefaultOptions; // 0x100 Size: 0x10
	    struct FString SelectedOption; // 0x110 Size: 0x10
	    struct FComboBoxStyle WidgetStyle; // 0x120 Size: 0x3d8
	    struct FTableRowStyle ItemStyle; // 0x4f8 Size: 0x6b8
	    struct FMargin ContentPadding; // 0xbb0 Size: 0x10
	    float MaxListHeight; // 0xbc0 Size: 0x4
	    bool HasDownArrow; // 0xbc4 Size: 0x1
	    bool EnableGamepadNavigationMode; // 0xbc5 Size: 0x1
	    char UnknownData0[0x2]; // 0xbc6
	    struct FSlateFontInfo Font; // 0xbc8 Size: 0x50
	    struct FSlateColor ForegroundColor; // 0xc18 Size: 0x28
	    bool bIsFocusable; // 0xc40 Size: 0x1
	    char UnknownData1[0x3]; // 0xc41
	    __int64/*DelegateProperty*/ OnGenerateWidgetEvent; // 0xc44 Size: 0x10
	    char UnknownData2[0x4]; // 0xc54
	    MulticastDelegateProperty OnSelectionChanged; // 0xc58 Size: 0x10
	    MulticastDelegateProperty OnOpening; // 0xc68 Size: 0x10
	    char UnknownData3[0xc78]; // 0xc78
	    void SetSelectedOption(struct FString Option); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool RemoveOption(struct FString Option); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void RefreshOptions(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnSelectionChangedEvent__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnOpeningEvent__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    struct FString GetSelectedOption(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    int GetOptionCount(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    struct FString GetOptionAtIndex(int Index); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    int FindOptionIndex(struct FString Option); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void ClearSelection(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void ClearOptions(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void AddOption(struct FString Option); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x-7329];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.ComboBoxString");
			return (class UClass*)ptr;
		};

};

class UDragDropOperation : public UObject
{
	public:
	    struct FString Tag; // 0x28 Size: 0x10
	    class UObject* Payload; // 0x38 Size: 0x8
	    class UWidget* DefaultDragVisual; // 0x40 Size: 0x8
	    EDragPivot Pivot; // 0x48 Size: 0x1
	    char UnknownData0[0x3]; // 0x49
	    struct FVector2D Offset; // 0x4c Size: 0x8
	    char UnknownData1[0x4]; // 0x54
	    MulticastDelegateProperty OnDrop; // 0x58 Size: 0x10
	    MulticastDelegateProperty OnDragCancelled; // 0x68 Size: 0x10
	    MulticastDelegateProperty OnDragged; // 0x78 Size: 0x10
	    char UnknownData2[0x88]; // 0x88
	    void Drop(struct FPointerEvent PointerEvent); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void Dragged(struct FPointerEvent PointerEvent); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void DragCancelled(struct FPointerEvent PointerEvent); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7f59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.DragDropOperation");
			return (class UClass*)ptr;
		};

};

class UDynamicEntryBox : public UWidget
{
	public:
	    EDynamicBoxType EntryBoxType; // 0x100 Size: 0x1
	    char UnknownData0[0x3]; // 0x101
	    struct FVector2D EntrySpacing; // 0x104 Size: 0x8
	    char UnknownData1[0x4]; // 0x10c
	    TArray<struct FVector2D> SpacingPattern; // 0x110 Size: 0x10
	    struct FSlateChildSize EntrySizeRule; // 0x120 Size: 0x8
	    char EntryHorizontalAlignment; // 0x128 Size: 0x1
	    char EntryVerticalAlignment; // 0x129 Size: 0x1
	    char UnknownData2[0x2]; // 0x12a
	    int MaxElementSize; // 0x12c Size: 0x4
	    char UnknownData3[0x10]; // 0x130
	    class UUserWidget* EntryWidgetClass; // 0x140 Size: 0x8
	    char UnknownData4[0x148]; // 0x148
	    void SetEntrySpacing(struct FVector2D InEntrySpacing); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void Reset(bool bDeleteWidgets); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void RemoveEntry(class UUserWidget* EntryWidget); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    int GetNumEntries(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    TArray<class UUserWidget*> GetAllEntries(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    class UUserWidget* BP_CreateEntryOfClass(class UUserWidget* EntryClass); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    class UUserWidget* BP_CreateEntry(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x-7e11];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.DynamicEntryBox");
			return (class UClass*)ptr;
		};

};

class UEditableText : public UWidget
{
	public:
	    struct FText Text; // 0x100 Size: 0x18
	    __int64/*DelegateProperty*/ TextDelegate; // 0x118 Size: 0x10
	    struct FText HintText; // 0x128 Size: 0x18
	    __int64/*DelegateProperty*/ HintTextDelegate; // 0x140 Size: 0x10
	    struct FEditableTextStyle WidgetStyle; // 0x150 Size: 0x218
	    class USlateWidgetStyleAsset* Style; // 0x368 Size: 0x8
	    class USlateBrushAsset* BackgroundImageSelected; // 0x370 Size: 0x8
	    class USlateBrushAsset* BackgroundImageComposing; // 0x378 Size: 0x8
	    class USlateBrushAsset* CaretImage; // 0x380 Size: 0x8
	    struct FSlateFontInfo Font; // 0x388 Size: 0x50
	    struct FSlateColor ColorAndOpacity; // 0x3d8 Size: 0x28
	    bool IsReadOnly; // 0x400 Size: 0x1
	    bool IsPassword; // 0x401 Size: 0x1
	    char UnknownData0[0x2]; // 0x402
	    float MinimumDesiredWidth; // 0x404 Size: 0x4
	    bool IsCaretMovedWhenGainFocus; // 0x408 Size: 0x1
	    bool SelectAllTextWhenFocused; // 0x409 Size: 0x1
	    bool RevertTextOnEscape; // 0x40a Size: 0x1
	    bool ClearKeyboardFocusOnCommit; // 0x40b Size: 0x1
	    bool SelectAllTextOnCommit; // 0x40c Size: 0x1
	    bool AllowContextMenu; // 0x40d Size: 0x1
	    char KeyboardType; // 0x40e Size: 0x1
	    struct FVirtualKeyboardOptions VirtualKeyboardOptions; // 0x40f Size: 0x1
	    EVirtualKeyboardDismissAction VirtualKeyboardDismissAction; // 0x410 Size: 0x1
	    char Justification; // 0x411 Size: 0x1
	    struct FShapedTextOptions ShapedTextOptions; // 0x412 Size: 0x3
	    char UnknownData1[0x3]; // 0x415
	    MulticastDelegateProperty OnTextChanged; // 0x418 Size: 0x10
	    MulticastDelegateProperty OnTextCommitted; // 0x428 Size: 0x10
	    char UnknownData2[0x438]; // 0x438
	    void SetText(struct FText InText); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetIsReadOnly(bool InbIsReadyOnly); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetIsPassword(bool InbIsPassword); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetHintText(struct FText InHintText); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnEditableTextCommittedEvent__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnEditableTextChangedEvent__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    struct FText GetText(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7b99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.EditableText");
			return (class UClass*)ptr;
		};

};

class UEditableTextBox : public UWidget
{
	public:
	    struct FText Text; // 0x100 Size: 0x18
	    __int64/*DelegateProperty*/ TextDelegate; // 0x118 Size: 0x10
	    struct FEditableTextBoxStyle WidgetStyle; // 0x128 Size: 0x7f0
	    class USlateWidgetStyleAsset* Style; // 0x918 Size: 0x8
	    struct FText HintText; // 0x920 Size: 0x18
	    __int64/*DelegateProperty*/ HintTextDelegate; // 0x938 Size: 0x10
	    struct FSlateFontInfo Font; // 0x948 Size: 0x50
	    struct FLinearColor ForegroundColor; // 0x998 Size: 0x10
	    struct FLinearColor BackgroundColor; // 0x9a8 Size: 0x10
	    struct FLinearColor ReadOnlyForegroundColor; // 0x9b8 Size: 0x10
	    bool IsReadOnly; // 0x9c8 Size: 0x1
	    bool IsPassword; // 0x9c9 Size: 0x1
	    char UnknownData0[0x2]; // 0x9ca
	    float MinimumDesiredWidth; // 0x9cc Size: 0x4
	    struct FMargin Padding; // 0x9d0 Size: 0x10
	    bool IsCaretMovedWhenGainFocus; // 0x9e0 Size: 0x1
	    bool SelectAllTextWhenFocused; // 0x9e1 Size: 0x1
	    bool RevertTextOnEscape; // 0x9e2 Size: 0x1
	    bool ClearKeyboardFocusOnCommit; // 0x9e3 Size: 0x1
	    bool SelectAllTextOnCommit; // 0x9e4 Size: 0x1
	    bool AllowContextMenu; // 0x9e5 Size: 0x1
	    char KeyboardType; // 0x9e6 Size: 0x1
	    struct FVirtualKeyboardOptions VirtualKeyboardOptions; // 0x9e7 Size: 0x1
	    EVirtualKeyboardDismissAction VirtualKeyboardDismissAction; // 0x9e8 Size: 0x1
	    char Justification; // 0x9e9 Size: 0x1
	    struct FShapedTextOptions ShapedTextOptions; // 0x9ea Size: 0x3
	    char UnknownData1[0x3]; // 0x9ed
	    MulticastDelegateProperty OnTextChanged; // 0x9f0 Size: 0x10
	    MulticastDelegateProperty OnTextCommitted; // 0xa00 Size: 0x10
	    char UnknownData2[0xa10]; // 0xa10
	    void SetText(struct FText InText); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetIsReadOnly(bool bReadOnly); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetIsPassword(bool bIsPassword); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetHintText(struct FText InText); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetError(struct FText InError); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnEditableTextBoxCommittedEvent__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnEditableTextBoxChangedEvent__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool HasError(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    struct FText GetText(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void ClearError(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-75c1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.EditableTextBox");
			return (class UClass*)ptr;
		};

};

class UExpandableArea : public UWidget
{
	public:
	    char UnknownData0[0x8];
	    struct FExpandableAreaStyle Style; // 0x108 Size: 0x120
	    struct FSlateBrush BorderBrush; // 0x228 Size: 0x88
	    struct FSlateColor BorderColor; // 0x2b0 Size: 0x28
	    bool bIsExpanded; // 0x2d8 Size: 0x1
	    char UnknownData1[0x3]; // 0x2d9
	    float MaxHeight; // 0x2dc Size: 0x4
	    struct FMargin HeaderPadding; // 0x2e0 Size: 0x10
	    struct FMargin AreaPadding; // 0x2f0 Size: 0x10
	    MulticastDelegateProperty OnExpansionChanged; // 0x300 Size: 0x10
	    class UWidget* HeaderContent; // 0x310 Size: 0x8
	    class UWidget* BodyContent; // 0x318 Size: 0x8
	    char UnknownData2[0x320]; // 0x320
	    void SetIsExpanded_Animated(bool IsExpanded); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetIsExpanded(bool IsExpanded); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool GetIsExpanded(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7cb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.ExpandableArea");
			return (class UClass*)ptr;
		};

};

class UFloatBinding : public UPropertyBinding
{
	public:
	    float GetValue(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.FloatBinding");
			return (class UClass*)ptr;
		};

};

class UGridPanel : public UPanelWidget
{
	public:
	    TArray<float> ColumnFill; // 0x118 Size: 0x10
	    TArray<float> RowFill; // 0x128 Size: 0x10
	    char UnknownData0[0x138]; // 0x138
	    void SetRowFill(int ColumnIndex, float Coefficient); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetColumnFill(int ColumnIndex, float Coefficient); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    class UGridSlot* AddChildToGrid(class UWidget* Content); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7e99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.GridPanel");
			return (class UClass*)ptr;
		};

};

class UGridSlot : public UPanelSlot
{
	public:
	    struct FMargin Padding; // 0x38 Size: 0x10
	    char HorizontalAlignment; // 0x48 Size: 0x1
	    char VerticalAlignment; // 0x49 Size: 0x1
	    char UnknownData0[0x2]; // 0x4a
	    int Row; // 0x4c Size: 0x4
	    int RowSpan; // 0x50 Size: 0x4
	    int Column; // 0x54 Size: 0x4
	    int ColumnSpan; // 0x58 Size: 0x4
	    int Layer; // 0x5c Size: 0x4
	    struct FVector2D Nudge; // 0x60 Size: 0x8
	    char UnknownData1[0x68]; // 0x68
	    void SetVerticalAlignment(char InVerticalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetRowSpan(int InRowSpan); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetRow(int InRow); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetPadding(struct FMargin InPadding); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetLayer(int InLayer); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetHorizontalAlignment(char InHorizontalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetColumnSpan(int InColumnSpan); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetColumn(int InColumn); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7f71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.GridSlot");
			return (class UClass*)ptr;
		};

};

class UHorizontalBox : public UPanelWidget
{
	public:
	    class UHorizontalBoxSlot* AddChildToHorizontalBox(class UWidget* Content); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7eb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.HorizontalBox");
			return (class UClass*)ptr;
		};

};

class UHorizontalBoxSlot : public UPanelSlot
{
	public:
	    struct FMargin Padding; // 0x38 Size: 0x10
	    struct FSlateChildSize Size; // 0x48 Size: 0x8
	    char HorizontalAlignment; // 0x50 Size: 0x1
	    char VerticalAlignment; // 0x51 Size: 0x1
	    char UnknownData0[0x52]; // 0x52
	    void SetVerticalAlignment(char InVerticalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetSize(struct FSlateChildSize InSize); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetPadding(struct FMargin InPadding); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetHorizontalAlignment(char InHorizontalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.HorizontalBoxSlot");
			return (class UClass*)ptr;
		};

};

class UInputKeySelector : public UWidget
{
	public:
	    struct FButtonStyle WidgetStyle; // 0x100 Size: 0x278
	    struct FTextBlockStyle TextStyle; // 0x378 Size: 0x1e0
	    struct FInputChord SelectedKey; // 0x558 Size: 0x20
	    struct FSlateFontInfo Font; // 0x578 Size: 0x50
	    struct FMargin Margin; // 0x5c8 Size: 0x10
	    struct FLinearColor ColorAndOpacity; // 0x5d8 Size: 0x10
	    struct FText KeySelectionText; // 0x5e8 Size: 0x18
	    struct FText NoKeySpecifiedText; // 0x600 Size: 0x18
	    bool bAllowModifierKeys; // 0x618 Size: 0x1
	    bool bAllowGamepadKeys; // 0x619 Size: 0x1
	    char UnknownData0[0x6]; // 0x61a
	    TArray<struct FKey> EscapeKeys; // 0x620 Size: 0x10
	    MulticastDelegateProperty OnKeySelected; // 0x630 Size: 0x10
	    MulticastDelegateProperty OnIsSelectingKeyChanged; // 0x640 Size: 0x10
	    char UnknownData1[0x650]; // 0x650
	    void SetTextBlockVisibility(ESlateVisibility InVisibility); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetSelectedKey(struct FInputChord InSelectedKey); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetNoKeySpecifiedText(struct FText InNoKeySpecifiedText); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetKeySelectionText(struct FText InKeySelectionText); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetEscapeKeys(TArray<struct FKey> InKeys); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetAllowModifierKeys(bool bInAllowModifierKeys); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetAllowGamepadKeys(bool bInAllowGamepadKeys); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnKeySelected__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnIsSelectingKeyChanged__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    bool GetIsSelectingKey(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x-7981];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.InputKeySelector");
			return (class UClass*)ptr;
		};

};

class UInt32Binding : public UPropertyBinding
{
	public:
	    int GetValue(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.Int32Binding");
			return (class UClass*)ptr;
		};

};

class UInvalidationBox : public UContentWidget
{
	public:
	    bool bCanCache; // 0x118 Size: 0x1
	    bool CacheRelativeTransforms; // 0x119 Size: 0x1
	    char UnknownData0[0x11a]; // 0x11a
	    void SetCanCache(bool CanCache); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void InvalidateCache(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool GetCanCache(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7eb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.InvalidationBox");
			return (class UClass*)ptr;
		};

};

class UNativeUserListEntry : public UInterface
{
	public:
	    bool IsListItemSelected(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    bool IsListItemExpanded(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    class UListViewBase* GetOwningListView(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.NativeUserListEntry");
			return (class UClass*)ptr;
		};

};

class UUserListEntry : public UNativeUserListEntry
{
	public:
	    void BP_OnItemSelectionChanged(bool bIsSelected); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void BP_OnItemExpansionChanged(bool bIsExpanded); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void BP_OnEntryReleased(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.UserListEntry");
			return (class UClass*)ptr;
		};

};

class UUserObjectListEntry : public UUserListEntry
{
	public:
	    void OnListItemObjectSet(class UObject* ListItemObject); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    class UObject* GetListItemObject(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.UserObjectListEntry");
			return (class UClass*)ptr;
		};

};

class UListViewDesignerPreviewItem : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.ListViewDesignerPreviewItem");
			return (class UClass*)ptr;
		};

};

class UMenuAnchor : public UContentWidget
{
	public:
	    class UUserWidget* MenuClass; // 0x118 Size: 0x8
	    __int64/*DelegateProperty*/ OnGetMenuContentEvent; // 0x120 Size: 0x10
	    char Placement; // 0x130 Size: 0x1
	    bool ShouldDeferPaintingAfterWindowContent; // 0x131 Size: 0x1
	    bool UseApplicationMenuStack; // 0x132 Size: 0x1
	    char UnknownData0[0x5]; // 0x133
	    MulticastDelegateProperty OnMenuOpenChanged; // 0x138 Size: 0x10
	    char UnknownData1[0x148]; // 0x148
	    void ToggleOpen(bool bFocusOnOpen); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool ShouldOpenDueToClick(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void Open(bool bFocusMenu); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool IsOpen(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool HasOpenSubMenus(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    struct FVector2D GetMenuPosition(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void Close(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7e89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.MenuAnchor");
			return (class UClass*)ptr;
		};

};

class UMouseCursorBinding : public UPropertyBinding
{
	public:
	    char GetValue(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.MouseCursorBinding");
			return (class UClass*)ptr;
		};

};

class UMovieScene2DTransformSection : public UMovieSceneSection
{
	public:
	    struct FMovieScene2DTransformMask TransformMask; // 0xe0 Size: 0x4
	    char UnknownData0[0x4]; // 0xe4
	    struct FMovieSceneFloatChannel* Translation; // 0xe8 Size: 0xa0
	    char UnknownData1[0xa0]; // 0x188
	    struct FMovieSceneFloatChannel Rotation; // 0x228 Size: 0xa0
	    struct FMovieSceneFloatChannel* Scale; // 0x2c8 Size: 0xa0
	    char UnknownData2[0xa0]; // 0x368
	    struct FMovieSceneFloatChannel* Shear; // 0x408 Size: 0xa0
	    char UnknownData3[0xa8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.MovieScene2DTransformSection");
			return (class UClass*)ptr;
		};

};

class UMovieScene2DTransformTrack : public UMovieScenePropertyTrack
{
	public:
	    char UnknownData0[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.MovieScene2DTransformTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneMarginSection : public UMovieSceneSection
{
	public:
	    struct FMovieSceneFloatChannel TopCurve; // 0xe0 Size: 0xa0
	    struct FMovieSceneFloatChannel LeftCurve; // 0x180 Size: 0xa0
	    struct FMovieSceneFloatChannel RightCurve; // 0x220 Size: 0xa0
	    struct FMovieSceneFloatChannel BottomCurve; // 0x2c0 Size: 0xa0

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.MovieSceneMarginSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneMarginTrack : public UMovieScenePropertyTrack
{
	public:
	    char UnknownData0[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.MovieSceneMarginTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneWidgetMaterialTrack : public UMovieSceneMaterialTrack
{
	public:
	    TArray<FName> BrushPropertyNamePath; // 0x68 Size: 0x10
	    FName TrackName; // 0x78 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.MovieSceneWidgetMaterialTrack");
			return (class UClass*)ptr;
		};

};

class UMultiLineEditableText : public UTextLayoutWidget
{
	public:
	    struct FText Text; // 0x120 Size: 0x18
	    struct FText HintText; // 0x138 Size: 0x18
	    __int64/*DelegateProperty*/ HintTextDelegate; // 0x150 Size: 0x10
	    struct FTextBlockStyle WidgetStyle; // 0x160 Size: 0x1e0
	    bool bIsReadOnly; // 0x340 Size: 0x1
	    char UnknownData0[0x7]; // 0x341
	    struct FSlateFontInfo Font; // 0x348 Size: 0x50
	    bool SelectAllTextWhenFocused; // 0x398 Size: 0x1
	    bool ClearTextSelectionOnFocusLoss; // 0x399 Size: 0x1
	    bool RevertTextOnEscape; // 0x39a Size: 0x1
	    bool ClearKeyboardFocusOnCommit; // 0x39b Size: 0x1
	    bool AllowContextMenu; // 0x39c Size: 0x1
	    struct FVirtualKeyboardOptions VirtualKeyboardOptions; // 0x39d Size: 0x1
	    EVirtualKeyboardDismissAction VirtualKeyboardDismissAction; // 0x39e Size: 0x1
	    char UnknownData1[0x1]; // 0x39f
	    MulticastDelegateProperty OnTextChanged; // 0x3a0 Size: 0x10
	    MulticastDelegateProperty OnTextCommitted; // 0x3b0 Size: 0x10
	    char UnknownData2[0x3c0]; // 0x3c0
	    void SetText(struct FText InText); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetIsReadOnly(bool bReadOnly); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnMultiLineEditableTextCommittedEvent__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnMultiLineEditableTextChangedEvent__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    struct FText GetText(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7c11];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.MultiLineEditableText");
			return (class UClass*)ptr;
		};

};

class UMultiLineEditableTextBox : public UTextLayoutWidget
{
	public:
	    struct FText Text; // 0x120 Size: 0x18
	    struct FText HintText; // 0x138 Size: 0x18
	    __int64/*DelegateProperty*/ HintTextDelegate; // 0x150 Size: 0x10
	    struct FEditableTextBoxStyle WidgetStyle; // 0x160 Size: 0x7f0
	    struct FTextBlockStyle TextStyle; // 0x950 Size: 0x1e0
	    bool bIsReadOnly; // 0xb30 Size: 0x1
	    bool AllowContextMenu; // 0xb31 Size: 0x1
	    struct FVirtualKeyboardOptions VirtualKeyboardOptions; // 0xb32 Size: 0x1
	    EVirtualKeyboardDismissAction VirtualKeyboardDismissAction; // 0xb33 Size: 0x1
	    char UnknownData0[0x4]; // 0xb34
	    class USlateWidgetStyleAsset* Style; // 0xb38 Size: 0x8
	    struct FSlateFontInfo Font; // 0xb40 Size: 0x50
	    struct FLinearColor ForegroundColor; // 0xb90 Size: 0x10
	    struct FLinearColor BackgroundColor; // 0xba0 Size: 0x10
	    struct FLinearColor ReadOnlyForegroundColor; // 0xbb0 Size: 0x10
	    MulticastDelegateProperty OnTextChanged; // 0xbc0 Size: 0x10
	    MulticastDelegateProperty OnTextCommitted; // 0xbd0 Size: 0x10
	    char UnknownData1[0xbe0]; // 0xbe0
	    void SetText(struct FText InText); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetIsReadOnly(bool bReadOnly); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetError(struct FText InError); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnMultiLineEditableTextBoxCommittedEvent__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnMultiLineEditableTextBoxChangedEvent__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    struct FText GetText(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-73f1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.MultiLineEditableTextBox");
			return (class UClass*)ptr;
		};

};

class UNamedSlot : public UContentWidget
{
	public:
	    char UnknownData0[0x128];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.NamedSlot");
			return (class UClass*)ptr;
		};

};

class UNamedSlotInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.NamedSlotInterface");
			return (class UClass*)ptr;
		};

};

class UNativeWidgetHost : public UWidget
{
	public:
	    char UnknownData0[0x110];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.NativeWidgetHost");
			return (class UClass*)ptr;
		};

};

class UOverlay : public UPanelWidget
{
	public:
	    class UOverlaySlot* AddChildToOverlay(class UWidget* Content); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7eb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.Overlay");
			return (class UClass*)ptr;
		};

};

class UOverlaySlot : public UPanelSlot
{
	public:
	    char UnknownData0[0x8];
	    struct FMargin Padding; // 0x40 Size: 0x10
	    char HorizontalAlignment; // 0x50 Size: 0x1
	    char VerticalAlignment; // 0x51 Size: 0x1
	    char UnknownData1[0x52]; // 0x52
	    void SetVerticalAlignment(char InVerticalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetPadding(struct FMargin InPadding); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetHorizontalAlignment(char InHorizontalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7f89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.OverlaySlot");
			return (class UClass*)ptr;
		};

};

class UProgressBar : public UWidget
{
	public:
	    struct FProgressBarStyle WidgetStyle; // 0x100 Size: 0x1a0
	    class USlateWidgetStyleAsset* Style; // 0x2a0 Size: 0x8
	    class USlateBrushAsset* BackgroundImage; // 0x2a8 Size: 0x8
	    class USlateBrushAsset* FillImage; // 0x2b0 Size: 0x8
	    class USlateBrushAsset* MarqueeImage; // 0x2b8 Size: 0x8
	    float Percent; // 0x2c0 Size: 0x4
	    char BarFillType; // 0x2c4 Size: 0x1
	    bool bIsMarquee; // 0x2c5 Size: 0x1
	    char UnknownData0[0x2]; // 0x2c6
	    struct FVector2D BorderPadding; // 0x2c8 Size: 0x8
	    __int64/*DelegateProperty*/ PercentDelegate; // 0x2d0 Size: 0x10
	    struct FLinearColor FillColorAndOpacity; // 0x2e0 Size: 0x10
	    __int64/*DelegateProperty*/ FillColorAndOpacityDelegate; // 0x2f0 Size: 0x10
	    char UnknownData1[0x300]; // 0x300
	    void SetPercent(float InPercent); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetIsMarquee(bool InbIsMarquee); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetFillColorAndOpacity(struct FLinearColor InColor); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7cd1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.ProgressBar");
			return (class UClass*)ptr;
		};

};

class URetainerBox : public UContentWidget
{
	public:
	    bool RenderOnInvalidation; // 0x118 Size: 0x1
	    bool RenderOnPhase; // 0x119 Size: 0x1
	    char UnknownData0[0x2]; // 0x11a
	    int Phase; // 0x11c Size: 0x4
	    int PhaseCount; // 0x120 Size: 0x4
	    char UnknownData1[0x4]; // 0x124
	    class UMaterialInterface* EffectMaterial; // 0x128 Size: 0x8
	    FName TextureParameter; // 0x130 Size: 0x8
	    char UnknownData2[0x138]; // 0x138
	    void SetTextureParameter(FName TextureParameter); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetRenderingPhase(int RenderPhase, int TotalPhases); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetEffectMaterial(class UMaterialInterface* EffectMaterial); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void RequestRender(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    class UMaterialInstanceDynamic* GetEffectMaterial(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7e99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.RetainerBox");
			return (class UClass*)ptr;
		};

};

class URichTextBlock : public UTextLayoutWidget
{
	public:
	    struct FText Text; // 0x120 Size: 0x18
	    class UDataTable* TextStyleSet; // 0x138 Size: 0x8
	    TArray<class URichTextBlockDecorator*> DecoratorClasses; // 0x140 Size: 0x10
	    char UnknownData0[0x1f0]; // 0x150
	    TArray<class URichTextBlockDecorator*> InstanceDecorators; // 0x340 Size: 0x10
	    char UnknownData1[0x350]; // 0x350
	    void SetText(struct FText InText); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    class URichTextBlockDecorator* GetDecoratorByClass(class URichTextBlockDecorator* DecoratorClass); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7c81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.RichTextBlock");
			return (class UClass*)ptr;
		};

};

class URichTextBlockDecorator : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.RichTextBlockDecorator");
			return (class UClass*)ptr;
		};

};

class URichTextBlockImageDecorator : public URichTextBlockDecorator
{
	public:
	    class UDataTable* ImageSet; // 0x28 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.RichTextBlockImageDecorator");
			return (class UClass*)ptr;
		};

};

class USafeZone : public UContentWidget
{
	public:
	    bool PadLeft; // 0x118 Size: 0x1
	    bool PadRight; // 0x119 Size: 0x1
	    bool PadTop; // 0x11a Size: 0x1
	    bool PadBottom; // 0x11b Size: 0x1
	    char UnknownData0[0x11c]; // 0x11c
	    void SetSidesToPad(bool InPadLeft, bool InPadRight, bool InPadTop, bool InPadBottom); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7eb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.SafeZone");
			return (class UClass*)ptr;
		};

};

class USafeZoneSlot : public UPanelSlot
{
	public:
	    bool bIsTitleSafe; // 0x38 Size: 0x1
	    char UnknownData0[0x3]; // 0x39
	    struct FMargin SafeAreaScale; // 0x3c Size: 0x10
	    char HAlign; // 0x4c Size: 0x1
	    char VAlign; // 0x4d Size: 0x1
	    char UnknownData1[0x2]; // 0x4e
	    struct FMargin Padding; // 0x50 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.SafeZoneSlot");
			return (class UClass*)ptr;
		};

};

class UScaleBox : public UContentWidget
{
	public:
	    char Stretch; // 0x118 Size: 0x1
	    char StretchDirection; // 0x119 Size: 0x1
	    char UnknownData0[0x2]; // 0x11a
	    float UserSpecifiedScale; // 0x11c Size: 0x4
	    bool IgnoreInheritedScale; // 0x120 Size: 0x1
	    bool bSingleLayoutPass; // 0x121 Size: 0x1
	    char UnknownData1[0x122]; // 0x122
	    void SetUserSpecifiedScale(float InUserSpecifiedScale); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetStretchDirection(char InStretchDirection); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetStretch(char InStretch); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetIgnoreInheritedScale(bool bInIgnoreInheritedScale); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7ea9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.ScaleBox");
			return (class UClass*)ptr;
		};

};

class UScaleBoxSlot : public UPanelSlot
{
	public:
	    struct FMargin Padding; // 0x38 Size: 0x10
	    char HorizontalAlignment; // 0x48 Size: 0x1
	    char VerticalAlignment; // 0x49 Size: 0x1
	    char UnknownData0[0x4a]; // 0x4a
	    void SetVerticalAlignment(char InVerticalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetPadding(struct FMargin InPadding); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetHorizontalAlignment(char InHorizontalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.ScaleBoxSlot");
			return (class UClass*)ptr;
		};

};

class UScrollBar : public UWidget
{
	public:
	    struct FScrollBarStyle WidgetStyle; // 0x100 Size: 0x4d0
	    class USlateWidgetStyleAsset* Style; // 0x5d0 Size: 0x8
	    bool bAlwaysShowScrollbar; // 0x5d8 Size: 0x1
	    char Orientation; // 0x5d9 Size: 0x1
	    char UnknownData0[0x2]; // 0x5da
	    struct FVector2D Thickness; // 0x5dc Size: 0x8
	    char UnknownData1[0x5e4]; // 0x5e4
	    void SetState(float InOffsetFraction, float InThumbSizeFraction); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-79e9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.ScrollBar");
			return (class UClass*)ptr;
		};

};

class UScrollBoxSlot : public UPanelSlot
{
	public:
	    struct FMargin Padding; // 0x38 Size: 0x10
	    char HorizontalAlignment; // 0x48 Size: 0x1
	    char VerticalAlignment; // 0x49 Size: 0x1
	    char UnknownData0[0x4a]; // 0x4a
	    void SetVerticalAlignment(char InVerticalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetPadding(struct FMargin InPadding); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetHorizontalAlignment(char InHorizontalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7f89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.ScrollBoxSlot");
			return (class UClass*)ptr;
		};

};

class USizeBox : public UContentWidget
{
	public:
	    bool bOverride_WidthOverride; // 0x118 Size: 0x1
	    bool bOverride_HeightOverride; // 0x118 Size: 0x1
	    bool bOverride_MinDesiredWidth; // 0x118 Size: 0x1
	    bool bOverride_MinDesiredHeight; // 0x118 Size: 0x1
	    bool bOverride_MaxDesiredWidth; // 0x118 Size: 0x1
	    bool bOverride_MaxDesiredHeight; // 0x118 Size: 0x1
	    bool bOverride_MaxAspectRatio; // 0x118 Size: 0x1
	    char UnknownData0[0x3]; // 0x11f
	    float WidthOverride; // 0x11c Size: 0x4
	    float HeightOverride; // 0x120 Size: 0x4
	    float MinDesiredWidth; // 0x124 Size: 0x4
	    float MinDesiredHeight; // 0x128 Size: 0x4
	    float MaxDesiredWidth; // 0x12c Size: 0x4
	    float MaxDesiredHeight; // 0x130 Size: 0x4
	    float MaxAspectRatio; // 0x134 Size: 0x4
	    char UnknownData1[0x138]; // 0x138
	    void SetWidthOverride(float InWidthOverride); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetMinDesiredWidth(float InMinDesiredWidth); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetMinDesiredHeight(float InMinDesiredHeight); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetMaxDesiredWidth(float InMaxDesiredWidth); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetMaxDesiredHeight(float InMaxDesiredHeight); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetMaxAspectRatio(float InMaxAspectRatio); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetHeightOverride(float InHeightOverride); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void ClearWidthOverride(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void ClearMinDesiredWidth(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void ClearMinDesiredHeight(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void ClearMaxDesiredWidth(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void ClearMaxDesiredHeight(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void ClearMaxAspectRatio(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void ClearHeightOverride(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x-7e99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.SizeBox");
			return (class UClass*)ptr;
		};

};

class USizeBoxSlot : public UPanelSlot
{
	public:
	    struct FMargin Padding; // 0x38 Size: 0x10
	    char HorizontalAlignment; // 0x48 Size: 0x1
	    char VerticalAlignment; // 0x49 Size: 0x1
	    char UnknownData0[0x4a]; // 0x4a
	    void SetVerticalAlignment(char InVerticalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetPadding(struct FMargin InPadding); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetHorizontalAlignment(char InHorizontalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.SizeBoxSlot");
			return (class UClass*)ptr;
		};

};

class USlateBlueprintLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static struct FVector2D TransformVectorLocalToAbsolute(struct FGeometry Geometry, struct FVector2D LocalVector); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static struct FVector2D TransformVectorAbsoluteToLocal(struct FGeometry Geometry, struct FVector2D AbsoluteVector); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static float TransformScalarLocalToAbsolute(struct FGeometry Geometry, float LocalScalar); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static float TransformScalarAbsoluteToLocal(struct FGeometry Geometry, float AbsoluteScalar); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static void ScreenToWidgetLocal(class UObject* WorldContextObject, struct FGeometry Geometry, struct FVector2D ScreenPosition, struct FVector2D LocalCoordinate); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static void ScreenToWidgetAbsolute(class UObject* WorldContextObject, struct FVector2D ScreenPosition, struct FVector2D AbsoluteCoordinate); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static void ScreenToViewport(class UObject* WorldContextObject, struct FVector2D ScreenPosition, struct FVector2D ViewportPosition); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static void LocalToViewport(class UObject* WorldContextObject, struct FGeometry Geometry, struct FVector2D LocalCoordinate, struct FVector2D PixelPosition, struct FVector2D ViewportPosition); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static struct FVector2D LocalToAbsolute(struct FGeometry Geometry, struct FVector2D LocalCoordinate); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static bool IsUnderLocation(struct FGeometry Geometry, struct FVector2D AbsoluteCoordinate); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static struct FVector2D GetLocalSize(struct FGeometry Geometry); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static struct FVector2D GetAbsoluteSize(struct FGeometry Geometry); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_SlateBrush(struct FSlateBrush A, struct FSlateBrush B); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    static void AbsoluteToViewport(class UObject* WorldContextObject, struct FVector2D AbsoluteDesktopCoordinate, struct FVector2D PixelPosition, struct FVector2D ViewportPosition); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    static struct FVector2D AbsoluteToLocal(struct FGeometry Geometry, struct FVector2D AbsoluteCoordinate); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.SlateBlueprintLibrary");
			return (class UClass*)ptr;
		};

};

class USlateVectorArtData : public UObject
{
	public:
	    TArray<struct FSlateMeshVertex> VertexData; // 0x28 Size: 0x10
	    TArray<uint32_t> IndexData; // 0x38 Size: 0x10
	    class UMaterialInterface* Material; // 0x48 Size: 0x8
	    struct FVector2D ExtentMin; // 0x50 Size: 0x8
	    struct FVector2D ExtentMax; // 0x58 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.SlateVectorArtData");
			return (class UClass*)ptr;
		};

};

class USpacer : public UWidget
{
	public:
	    struct FVector2D Size; // 0x100 Size: 0x8
	    char UnknownData0[0x108]; // 0x108
	    void SetSize(struct FVector2D InSize); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7ec9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.Spacer");
			return (class UClass*)ptr;
		};

};

class USpinBox : public UWidget
{
	public:
	    float Value; // 0x100 Size: 0x4
	    __int64/*DelegateProperty*/ ValueDelegate; // 0x104 Size: 0x10
	    char UnknownData0[0x4]; // 0x114
	    struct FSpinBoxStyle WidgetStyle; // 0x118 Size: 0x2e8
	    class USlateWidgetStyleAsset* Style; // 0x400 Size: 0x8
	    float Delta; // 0x408 Size: 0x4
	    float SliderExponent; // 0x40c Size: 0x4
	    struct FSlateFontInfo Font; // 0x410 Size: 0x50
	    char Justification; // 0x460 Size: 0x1
	    char UnknownData1[0x3]; // 0x461
	    float MinDesiredWidth; // 0x464 Size: 0x4
	    bool ClearKeyboardFocusOnCommit; // 0x468 Size: 0x1
	    bool SelectAllTextOnCommit; // 0x469 Size: 0x1
	    char UnknownData2[0x6]; // 0x46a
	    struct FSlateColor ForegroundColor; // 0x470 Size: 0x28
	    MulticastDelegateProperty OnValueChanged; // 0x498 Size: 0x10
	    MulticastDelegateProperty OnValueCommitted; // 0x4a8 Size: 0x10
	    MulticastDelegateProperty OnBeginSliderMovement; // 0x4b8 Size: 0x10
	    MulticastDelegateProperty OnEndSliderMovement; // 0x4c8 Size: 0x10
	    bool bOverride_MinValue; // 0x4d8 Size: 0x1
	    bool bOverride_MaxValue; // 0x4d8 Size: 0x1
	    bool bOverride_MinSliderValue; // 0x4d8 Size: 0x1
	    bool bOverride_MaxSliderValue; // 0x4d8 Size: 0x1
	    float MinValue; // 0x4dc Size: 0x4
	    float MaxValue; // 0x4e0 Size: 0x4
	    float MinSliderValue; // 0x4e4 Size: 0x4
	    float MaxSliderValue; // 0x4e8 Size: 0x4
	    char UnknownData3[0x4ec]; // 0x4ec
	    void SetValue(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetMinValue(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetMinSliderValue(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetMaxValue(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetMaxSliderValue(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetForegroundColor(struct FSlateColor InForegroundColor); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnSpinBoxValueCommittedEvent__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnSpinBoxValueChangedEvent__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnSpinBoxBeginSliderMovement__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    float GetValue(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    float GetMinValue(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    float GetMinSliderValue(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    float GetMaxValue(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    float GetMaxSliderValue(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void ClearMinValue(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void ClearMinSliderValue(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void ClearMaxValue(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void ClearMaxSliderValue(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x-7ae1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.SpinBox");
			return (class UClass*)ptr;
		};

};

class UTextBinding : public UPropertyBinding
{
	public:
	    struct FText GetTextValue(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    struct FString GetStringValue(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.TextBinding");
			return (class UClass*)ptr;
		};

};

class UThrobber : public UWidget
{
	public:
	    int NumberOfPieces; // 0x100 Size: 0x4
	    bool bAnimateHorizontally; // 0x104 Size: 0x1
	    bool bAnimateVertically; // 0x105 Size: 0x1
	    bool bAnimateOpacity; // 0x106 Size: 0x1
	    char UnknownData0[0x1]; // 0x107
	    class USlateBrushAsset* PieceImage; // 0x108 Size: 0x8
	    struct FSlateBrush Image; // 0x110 Size: 0x88
	    char UnknownData1[0x198]; // 0x198
	    void SetNumberOfPieces(int InNumberOfPieces); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetAnimateVertically(bool bInAnimateVertically); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetAnimateOpacity(bool bInAnimateOpacity); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetAnimateHorizontally(bool bInAnimateHorizontally); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7e39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.Throbber");
			return (class UClass*)ptr;
		};

};

class UUMGSequencePlayer : public UObject
{
	public:
	    char UnknownData0[0x348];
	    class UWidgetAnimation* Animation; // 0x370 Size: 0x8
	    char UnknownData1[0x378]; // 0x378
	    void SetUserTag(FName InUserTag); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    FName GetUserTag(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-78f1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.UMGSequencePlayer");
			return (class UClass*)ptr;
		};

};

class UUniformGridPanel : public UPanelWidget
{
	public:
	    struct FMargin SlotPadding; // 0x118 Size: 0x10
	    float MinDesiredSlotWidth; // 0x128 Size: 0x4
	    float MinDesiredSlotHeight; // 0x12c Size: 0x4
	    char UnknownData0[0x130]; // 0x130
	    void SetSlotPadding(struct FMargin InSlotPadding); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetMinDesiredSlotWidth(float InMinDesiredSlotWidth); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetMinDesiredSlotHeight(float InMinDesiredSlotHeight); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    class UUniformGridSlot* AddChildToUniformGrid(class UWidget* Content); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7ea1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.UniformGridPanel");
			return (class UClass*)ptr;
		};

};

class UUniformGridSlot : public UPanelSlot
{
	public:
	    char HorizontalAlignment; // 0x38 Size: 0x1
	    char VerticalAlignment; // 0x39 Size: 0x1
	    char UnknownData0[0x2]; // 0x3a
	    int Row; // 0x3c Size: 0x4
	    int Column; // 0x40 Size: 0x4
	    char UnknownData1[0x44]; // 0x44
	    void SetVerticalAlignment(char InVerticalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetRow(int InRow); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetHorizontalAlignment(char InHorizontalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetColumn(int InColumn); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7f91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.UniformGridSlot");
			return (class UClass*)ptr;
		};

};

class UVerticalBox : public UPanelWidget
{
	public:
	    class UVerticalBoxSlot* AddChildToVerticalBox(class UWidget* Content); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7eb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.VerticalBox");
			return (class UClass*)ptr;
		};

};

class UVerticalBoxSlot : public UPanelSlot
{
	public:
	    struct FMargin Padding; // 0x38 Size: 0x10
	    struct FSlateChildSize Size; // 0x48 Size: 0x8
	    char HorizontalAlignment; // 0x50 Size: 0x1
	    char VerticalAlignment; // 0x51 Size: 0x1
	    char UnknownData0[0x52]; // 0x52
	    void SetVerticalAlignment(char InVerticalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetSize(struct FSlateChildSize InSize); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetPadding(struct FMargin InPadding); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetHorizontalAlignment(char InHorizontalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.VerticalBoxSlot");
			return (class UClass*)ptr;
		};

};

class UViewport : public UContentWidget
{
	public:
	    struct FLinearColor BackgroundColor; // 0x118 Size: 0x10
	    char UnknownData0[0x128]; // 0x128
	    class AActor* Spawn(class AActor* ActorClass); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetViewRotation(struct FRotator Rotation); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetViewLocation(struct FVector Location); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    struct FRotator GetViewRotation(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    class UWorld* GetViewportWorld(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    struct FVector GetViewLocation(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7ea1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.Viewport");
			return (class UClass*)ptr;
		};

};

class UVisibilityBinding : public UPropertyBinding
{
	public:
	    ESlateVisibility GetValue(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.VisibilityBinding");
			return (class UClass*)ptr;
		};

};

class UWidgetAnimation : public UMovieSceneSequence
{
	public:
	    class UMovieScene* MovieScene; // 0x348 Size: 0x8
	    TArray<struct FWidgetAnimationBinding> AnimationBindings; // 0x350 Size: 0x10
	    bool bLegacyFinishOnStop; // 0x360 Size: 0x1
	    char UnknownData0[0x7]; // 0x361
	    struct FString DisplayLabel; // 0x368 Size: 0x10
	    char UnknownData1[0x378]; // 0x378
	    void UnbindFromAnimationStarted(class UUserWidget* Widget, __int64/*DelegateProperty*/ Delegate); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void UnbindFromAnimationFinished(class UUserWidget* Widget, __int64/*DelegateProperty*/ Delegate); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void UnbindAllFromAnimationStarted(class UUserWidget* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void UnbindAllFromAnimationFinished(class UUserWidget* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    float GetStartTime(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    float GetEndTime(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void BindToAnimationStarted(class UUserWidget* Widget, __int64/*DelegateProperty*/ Delegate); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void BindToAnimationFinished(class UUserWidget* Widget, __int64/*DelegateProperty*/ Delegate); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7c69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.WidgetAnimation");
			return (class UClass*)ptr;
		};

};

class UWidgetAnimationDelegateBinding : public UDynamicBlueprintBinding
{
	public:
	    TArray<struct FBlueprintWidgetAnimationDelegateBinding> WidgetAnimationDelegateBindings; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.WidgetAnimationDelegateBinding");
			return (class UClass*)ptr;
		};

};

class UWidgetBinding : public UPropertyBinding
{
	public:
	    class UWidget* GetValue(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.WidgetBinding");
			return (class UClass*)ptr;
		};

};

class UWidgetBlueprintGeneratedClass : public UBlueprintGeneratedClass
{
	public:
	    class UWidgetTree* WidgetTree; // 0x2e0 Size: 0x8
	    bool bAllowTemplate; // 0x2e8 Size: 0x1
	    bool bAllowDynamicCreation; // 0x2e8 Size: 0x1
	    bool bValidTemplate; // 0x2e8 Size: 0x1
	    bool bTemplateInitialized; // 0x2e8 Size: 0x1
	    bool bCookedTemplate; // 0x2e8 Size: 0x1
	    bool bClassRequiresNativeTick; // 0x2e8 Size: 0x1
	    char UnknownData0[0x2]; // 0x2ee
	    TArray<struct FDelegateRuntimeBinding> Bindings; // 0x2f0 Size: 0x10
	    TArray<class UWidgetAnimation*> Animations; // 0x300 Size: 0x10
	    TArray<FName> NamedSlots; // 0x310 Size: 0x10
	    struct TSoftObjectPtr<struct UUserWidget*> TemplateAsset; // 0x320 Size: 0x28
	    class UUserWidget* Template; // 0x348 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.WidgetBlueprintGeneratedClass");
			return (class UClass*)ptr;
		};

};

class UWidgetBlueprintLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static struct FEventReply UnlockMouse(struct FEventReply Reply); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static struct FEventReply Unhandled(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static void SetWindowTitleBarState(class UWidget* TitleBarContent, EWindowTitleBarMode Mode, bool bTitleBarDragEnabled, bool bWindowButtonsVisible, bool bTitleBarVisible); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static void SetWindowTitleBarOnCloseClickedDelegate(__int64/*DelegateProperty*/ Delegate); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static void SetWindowTitleBarCloseButtonActive(bool bActive); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static struct FEventReply SetUserFocus(struct FEventReply Reply, class UWidget* FocusWidget, bool bInAllUsers); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static struct FEventReply SetMousePosition(struct FEventReply Reply, struct FVector2D NewMousePosition); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static void SetInputMode_UIOnlyEx(class APlayerController* PlayerController, class UWidget* InWidgetToFocus, EMouseLockMode InMouseLockMode); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static void SetInputMode_UIOnly(class APlayerController* Target, class UWidget* InWidgetToFocus, bool bLockMouseToViewport); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static void SetInputMode_GameOnly(class APlayerController* PlayerController); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static void SetInputMode_GameAndUIEx(class APlayerController* PlayerController, class UWidget* InWidgetToFocus, EMouseLockMode InMouseLockMode, bool bHideCursorDuringCapture); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static void SetInputMode_GameAndUI(class APlayerController* Target, class UWidget* InWidgetToFocus, bool bLockMouseToViewport, bool bHideCursorDuringCapture); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    static bool SetHardwareCursor(class UObject* WorldContextObject, char CursorShape, FName CursorName, struct FVector2D HotSpot); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    static void SetFocusToGameViewport(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    static void SetBrushResourceToTexture(struct FSlateBrush Brush, class UTexture2D* Texture); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    static void SetBrushResourceToMaterial(struct FSlateBrush Brush, class UMaterialInterface* Material); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    static void RestorePreviousWindowTitleBarState(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    static struct FEventReply ReleaseMouseCapture(struct FEventReply Reply); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    static struct FEventReply ReleaseJoystickCapture(struct FEventReply Reply, bool bInAllJoysticks); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnGameWindowCloseButtonClickedDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    static struct FSlateBrush NoResourceBrush(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    static struct FSlateBrush MakeBrushFromTexture(class UTexture2D* Texture, int Width, int Height); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    static struct FSlateBrush MakeBrushFromMaterial(class UMaterialInterface* Material, int Width, int Height); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    static struct FSlateBrush MakeBrushFromAsset(class USlateBrushAsset* BrushAsset); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    static struct FEventReply LockMouse(struct FEventReply Reply, class UWidget* CapturingWidget); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    static bool IsDragDropping(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    static struct FEventReply Handled(); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    static void GetSafeZonePadding(class UObject* WorldContextObject, struct FVector4 SafePadding, struct FVector2D SafePaddingScale, struct FVector4 SpillOverPadding); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    static struct FKeyEvent GetKeyEventFromAnalogInputEvent(struct FAnalogInputEvent Event); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    static struct FInputEvent GetInputEventFromPointerEvent(struct FPointerEvent Event); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    static struct FInputEvent GetInputEventFromNavigationEvent(struct FNavigationEvent Event); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    static struct FInputEvent GetInputEventFromKeyEvent(struct FKeyEvent Event); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    static struct FInputEvent GetInputEventFromCharacterEvent(struct FCharacterEvent Event); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    static class UMaterialInstanceDynamic* GetDynamicMaterial(struct FSlateBrush Brush); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    static class UDragDropOperation* GetDragDroppingContent(); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    static class UTexture2D* GetBrushResourceAsTexture2D(struct FSlateBrush Brush); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    static class UMaterialInterface* GetBrushResourceAsMaterial(struct FSlateBrush Brush); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    static class UObject* GetBrushResource(struct FSlateBrush Brush); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    static void GetAllWidgetsWithInterface(class UObject* WorldContextObject, class UInterface* Interface, TArray<class UUserWidget*> FoundWidgets, bool TopLevelOnly); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    static void GetAllWidgetsOfClass(class UObject* WorldContextObject, TArray<class UUserWidget*> FoundWidgets, class UUserWidget* WidgetClass, bool TopLevelOnly); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    static struct FEventReply EndDragDrop(struct FEventReply Reply); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    static void DrawTextFormatted(struct FPaintContext Context, struct FText Text, struct FVector2D Position, class UFont* Font, int FontSize, FName FontTypeFace, struct FLinearColor Tint); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    static void DrawText(struct FPaintContext Context, struct FString inString, struct FVector2D Position, struct FLinearColor Tint); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    static void DrawLines(struct FPaintContext Context, TArray<struct FVector2D> Points, struct FLinearColor Tint, bool bAntiAlias); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    static void DrawLine(struct FPaintContext Context, struct FVector2D PositionA, struct FVector2D PositionB, struct FLinearColor Tint, bool bAntiAlias); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    static void DrawBox(struct FPaintContext Context, struct FVector2D Position, struct FVector2D Size, class USlateBrushAsset* Brush, struct FLinearColor Tint); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    static void DismissAllMenus(); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    static struct FEventReply DetectDragIfPressed(struct FPointerEvent PointerEvent, class UWidget* WidgetDetectingDrag, struct FKey DragKey); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    static struct FEventReply DetectDrag(struct FEventReply Reply, class UWidget* WidgetDetectingDrag, struct FKey DragKey); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    static class UDragDropOperation* CreateDragDropOperation(class UDragDropOperation* OperationClass); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    static class UUserWidget* Create(class UObject* WorldContextObject, class UUserWidget* WidgetType, class APlayerController* OwningPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    static struct FEventReply ClearUserFocus(struct FEventReply Reply, bool bInAllUsers); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    static struct FEventReply CaptureMouse(struct FEventReply Reply, class UWidget* CapturingWidget); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    static struct FEventReply CaptureJoystick(struct FEventReply Reply, class UWidget* CapturingWidget, bool bInAllJoysticks); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    static void CancelDragDrop(); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary");
			return (class UClass*)ptr;
		};

};

class UWidgetComponent : public UMeshComponent
{
	public:
	    EWidgetSpace Space; // 0x5a0 Size: 0x1
	    EWidgetTimingPolicy TimingPolicy; // 0x5a1 Size: 0x1
	    char UnknownData0[0x6]; // 0x5a2
	    class UUserWidget* WidgetClass; // 0x5a8 Size: 0x8
	    struct FIntPoint DrawSize; // 0x5b0 Size: 0x8
	    bool bManuallyRedraw; // 0x5b8 Size: 0x1
	    bool bRedrawRequested; // 0x5b9 Size: 0x1
	    char UnknownData1[0x2]; // 0x5ba
	    float RedrawTime; // 0x5bc Size: 0x4
	    char UnknownData2[0x8]; // 0x5c0
	    struct FIntPoint CurrentDrawSize; // 0x5c8 Size: 0x8
	    bool bDrawAtDesiredSize; // 0x5d0 Size: 0x1
	    char UnknownData3[0x3]; // 0x5d1
	    struct FVector2D Pivot; // 0x5d4 Size: 0x8
	    bool bReceiveHardwareInput; // 0x5dc Size: 0x1
	    bool bWindowFocusable; // 0x5dd Size: 0x1
	    bool bApplyGammaCorrection; // 0x5de Size: 0x1
	    char UnknownData4[0x1]; // 0x5df
	    class ULocalPlayer* OwnerPlayer; // 0x5e0 Size: 0x8
	    struct FLinearColor BackgroundColor; // 0x5e8 Size: 0x10
	    struct FLinearColor TintColorAndOpacity; // 0x5f8 Size: 0x10
	    float OpacityFromTexture; // 0x608 Size: 0x4
	    EWidgetBlendMode BlendMode; // 0x60c Size: 0x1
	    bool bIsTwoSided; // 0x60d Size: 0x1
	    bool TickWhenOffscreen; // 0x60e Size: 0x1
	    char UnknownData5[0x1]; // 0x60f
	    class UUserWidget* Widget; // 0x610 Size: 0x8
	    char UnknownData6[0x20]; // 0x618
	    class UBodySetup* BodySetup; // 0x638 Size: 0x8
	    class UMaterialInterface* TranslucentMaterial; // 0x640 Size: 0x8
	    class UMaterialInterface* TranslucentMaterial_OneSided; // 0x648 Size: 0x8
	    class UMaterialInterface* OpaqueMaterial; // 0x650 Size: 0x8
	    class UMaterialInterface* OpaqueMaterial_OneSided; // 0x658 Size: 0x8
	    class UMaterialInterface* MaskedMaterial; // 0x660 Size: 0x8
	    class UMaterialInterface* MaskedMaterial_OneSided; // 0x668 Size: 0x8
	    class UTextureRenderTarget2D* RenderTarget; // 0x670 Size: 0x8
	    class UMaterialInstanceDynamic* MaterialInstance; // 0x678 Size: 0x8
	    bool bAddedToScreen; // 0x680 Size: 0x1
	    bool bEditTimeUsable; // 0x681 Size: 0x1
	    char UnknownData7[0x2]; // 0x682
	    FName SharedLayerName; // 0x684 Size: 0x8
	    int LayerZOrder; // 0x68c Size: 0x4
	    EWidgetGeometryMode GeometryMode; // 0x690 Size: 0x1
	    char UnknownData8[0x3]; // 0x691
	    float CylinderArcAngle; // 0x694 Size: 0x4
	    char UnknownData9[0x698]; // 0x698
	    void SetWidget(class UUserWidget* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetTintColorAndOpacity(struct FLinearColor NewTintColorAndOpacity); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetOwnerPlayer(class ULocalPlayer* LocalPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetManuallyRedraw(bool bUseManualRedraw); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void SetDrawSize(struct FVector2D Size); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void SetBackgroundColor(struct FLinearColor NewBackgroundColor); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void RequestRedraw(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    class UUserWidget* GetUserWidgetObject(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    class UTextureRenderTarget2D* GetRenderTarget(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    class ULocalPlayer* GetOwnerPlayer(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    class UMaterialInstanceDynamic* GetMaterialInstance(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    struct FVector2D GetDrawSize(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x-7921];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.WidgetComponent");
			return (class UClass*)ptr;
		};

};

class UWidgetInteractionComponent : public USceneComponent
{
	public:
	    MulticastDelegateProperty OnHoveredWidgetChanged; // 0x248 Size: 0x10
	    char UnknownData0[0x10]; // 0x258
	    int VirtualUserIndex; // 0x268 Size: 0x4
	    float PointerIndex; // 0x26c Size: 0x4
	    char TraceChannel; // 0x270 Size: 0x1
	    char UnknownData1[0x3]; // 0x271
	    float InteractionDistance; // 0x274 Size: 0x4
	    EWidgetInteractionSource InteractionSource; // 0x278 Size: 0x1
	    bool bEnableHitTesting; // 0x279 Size: 0x1
	    bool bShowDebug; // 0x27a Size: 0x1
	    char UnknownData2[0x1]; // 0x27b
	    struct FLinearColor DebugColor; // 0x27c Size: 0x10
	    char UnknownData3[0x7c]; // 0x28c
	    struct FHitResult CustomHitResult; // 0x308 Size: 0x88
	    struct FVector2D LocalHitLocation; // 0x390 Size: 0x8
	    struct FVector2D LastLocalHitLocation; // 0x398 Size: 0x8
	    class UWidgetComponent* HoveredWidgetComponent; // 0x3a0 Size: 0x8
	    struct FHitResult LastHitResult; // 0x3a8 Size: 0x88
	    bool bIsHoveredWidgetInteractable; // 0x430 Size: 0x1
	    bool bIsHoveredWidgetFocusable; // 0x431 Size: 0x1
	    bool bIsHoveredWidgetHitTestVisible; // 0x432 Size: 0x1
	    char UnknownData4[0x433]; // 0x433
	    void SetCustomHitResult(struct FHitResult HitResult); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool SendKeyChar(struct FString Characters, bool bRepeat); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ScrollWheel(float ScrollDelta); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void ReleasePointerKey(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool ReleaseKey(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void PressPointerKey(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    bool PressKey(struct FKey Key, bool bRepeat); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    bool PressAndReleaseKey(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    bool IsOverInteractableWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    bool IsOverHitTestVisibleWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    bool IsOverFocusableWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    struct FHitResult GetLastHitResult(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    class UWidgetComponent* GetHoveredWidgetComponent(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    struct FVector2D Get2DHitLocation(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x-7ba1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.WidgetInteractionComponent");
			return (class UClass*)ptr;
		};

};

class UWidgetLayoutLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static class UVerticalBoxSlot* SlotAsVerticalBoxSlot(class UWidget* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static class UUniformGridSlot* SlotAsUniformGridSlot(class UWidget* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static class UOverlaySlot* SlotAsOverlaySlot(class UWidget* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static class UHorizontalBoxSlot* SlotAsHorizontalBoxSlot(class UWidget* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static class UGridSlot* SlotAsGridSlot(class UWidget* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static class UCanvasPanelSlot* SlotAsCanvasSlot(class UWidget* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static class UBorderSlot* SlotAsBorderSlot(class UWidget* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static void RemoveAllWidgets(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static bool ProjectWorldLocationToWidgetPosition(class APlayerController* PlayerController, struct FVector WorldLocation, struct FVector2D ScreenPosition); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static struct FGeometry GetViewportWidgetGeometry(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static struct FVector2D GetViewportSize(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static float GetViewportScale(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    static struct FGeometry GetPlayerScreenWidgetGeometry(class APlayerController* PlayerController); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    static bool GetMousePositionScaledByDPI(class APlayerController* Player, float LocationX, float LocationY); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    static struct FVector2D GetMousePositionOnViewport(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    static struct FVector2D GetMousePositionOnPlatform(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.WidgetLayoutLibrary");
			return (class UClass*)ptr;
		};

};

class UWidgetNavigation : public UObject
{
	public:
	    struct FWidgetNavigationData Up; // 0x28 Size: 0x24
	    struct FWidgetNavigationData Down; // 0x4c Size: 0x24
	    struct FWidgetNavigationData Left; // 0x70 Size: 0x24
	    struct FWidgetNavigationData Right; // 0x94 Size: 0x24
	    struct FWidgetNavigationData Next; // 0xb8 Size: 0x24
	    struct FWidgetNavigationData Previous; // 0xdc Size: 0x24

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.WidgetNavigation");
			return (class UClass*)ptr;
		};

};

class UWidgetSwitcherSlot : public UPanelSlot
{
	public:
	    struct FMargin Padding; // 0x38 Size: 0x10
	    char HorizontalAlignment; // 0x48 Size: 0x1
	    char VerticalAlignment; // 0x49 Size: 0x1
	    char UnknownData0[0x4a]; // 0x4a
	    void SetVerticalAlignment(char InVerticalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetPadding(struct FMargin InPadding); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetHorizontalAlignment(char InHorizontalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7f89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.WidgetSwitcherSlot");
			return (class UClass*)ptr;
		};

};

class UWidgetTree : public UObject
{
	public:
	    class UWidget* RootWidget; // 0x28 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.WidgetTree");
			return (class UClass*)ptr;
		};

};

class UWindowTitleBarArea : public UContentWidget
{
	public:
	    bool bWindowButtonsEnabled; // 0x118 Size: 0x1
	    bool bDoubleClickTogglesFullscreen; // 0x119 Size: 0x1
	    char UnknownData0[0x11a]; // 0x11a
	    void SetVerticalAlignment(char InVerticalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetPadding(struct FMargin InPadding); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetHorizontalAlignment(char InHorizontalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7ea9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.WindowTitleBarArea");
			return (class UClass*)ptr;
		};

};

class UWindowTitleBarAreaSlot : public UPanelSlot
{
	public:
	    struct FMargin Padding; // 0x38 Size: 0x10
	    char HorizontalAlignment; // 0x48 Size: 0x1
	    char VerticalAlignment; // 0x49 Size: 0x1
	    char UnknownData0[0x4a]; // 0x4a
	    void SetVerticalAlignment(char InVerticalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetPadding(struct FMargin InPadding); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetHorizontalAlignment(char InHorizontalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.WindowTitleBarAreaSlot");
			return (class UClass*)ptr;
		};

};

class UWrapBox : public UPanelWidget
{
	public:
	    struct FVector2D InnerSlotPadding; // 0x118 Size: 0x8
	    float WrapWidth; // 0x120 Size: 0x4
	    bool bExplicitWrapWidth; // 0x124 Size: 0x1
	    char UnknownData0[0x125]; // 0x125
	    void SetInnerSlotPadding(struct FVector2D InPadding); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    class UWrapBoxSlot* AddChildWrapBox(class UWidget* Content); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7ea9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.WrapBox");
			return (class UClass*)ptr;
		};

};

class UWrapBoxSlot : public UPanelSlot
{
	public:
	    struct FMargin Padding; // 0x38 Size: 0x10
	    bool bFillEmptySpace; // 0x48 Size: 0x1
	    char UnknownData0[0x3]; // 0x49
	    float FillSpanWhenLessThan; // 0x4c Size: 0x4
	    char HorizontalAlignment; // 0x50 Size: 0x1
	    char VerticalAlignment; // 0x51 Size: 0x1
	    char UnknownData1[0x52]; // 0x52
	    void SetVerticalAlignment(char InVerticalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetPadding(struct FMargin InPadding); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetHorizontalAlignment(char InHorizontalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetFillSpanWhenLessThan(float InFillSpanWhenLessThan); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetFillEmptySpace(bool InbFillEmptySpace); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.WrapBoxSlot");
			return (class UClass*)ptr;
		};

};

class UDefault__WidgetBlueprintGeneratedClass
{
	public:

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UMG.Default__WidgetBlueprintGeneratedClass");
			return (class UClass*)ptr;
		};

};


}