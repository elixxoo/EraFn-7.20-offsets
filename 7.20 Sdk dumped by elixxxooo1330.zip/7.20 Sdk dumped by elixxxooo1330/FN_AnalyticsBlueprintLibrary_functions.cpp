#include "../SDK.hpp"

static bool UAnalyticsBlueprintLibrary::StartSessionWithAttributes(TArray<struct FAnalyticsEventAttr> Attributes)
{
	struct {
            TArray<struct FAnalyticsEventAttr> Attributes;
            bool ReturnValue;
	} params{ Attributes };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:StartSessionWithAttributes");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAnalyticsBlueprintLibrary::StartSession()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:StartSession");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::SetUserId(struct FString UserId)
{
	struct {
            struct FString UserId;            void ReturnValue;
	} params{ UserId };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:SetUserId");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::SetSessionId(struct FString SessionId)
{
	struct {
            struct FString SessionId;            void ReturnValue;
	} params{ SessionId };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:SetSessionId");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::SetLocation(struct FString Location)
{
	struct {
            struct FString Location;            void ReturnValue;
	} params{ Location };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:SetLocation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::SetGender(struct FString Gender)
{
	struct {
            struct FString Gender;            void ReturnValue;
	} params{ Gender };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:SetGender");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::SetBuildInfo(struct FString BuildInfo)
{
	struct {
            struct FString BuildInfo;            void ReturnValue;
	} params{ BuildInfo };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:SetBuildInfo");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::SetAge(int Age)
{
	struct {
            int Age;            void ReturnValue;
	} params{ Age };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:SetAge");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::RecordSimpleItemPurchaseWithAttributes(struct FString ItemId, int ItemQuantity, TArray<struct FAnalyticsEventAttr> Attributes)
{
	struct {
            struct FString ItemId;
            int ItemQuantity;
            TArray<struct FAnalyticsEventAttr> Attributes;            void ReturnValue;
	} params{ ItemId, ItemQuantity, Attributes };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:RecordSimpleItemPurchaseWithAttributes");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::RecordSimpleItemPurchase(struct FString ItemId, int ItemQuantity)
{
	struct {
            struct FString ItemId;
            int ItemQuantity;            void ReturnValue;
	} params{ ItemId, ItemQuantity };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:RecordSimpleItemPurchase");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::RecordSimpleCurrencyPurchaseWithAttributes(struct FString GameCurrencyType, int GameCurrencyAmount, TArray<struct FAnalyticsEventAttr> Attributes)
{
	struct {
            struct FString GameCurrencyType;
            int GameCurrencyAmount;
            TArray<struct FAnalyticsEventAttr> Attributes;            void ReturnValue;
	} params{ GameCurrencyType, GameCurrencyAmount, Attributes };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:RecordSimpleCurrencyPurchaseWithAttributes");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::RecordSimpleCurrencyPurchase(struct FString GameCurrencyType, int GameCurrencyAmount)
{
	struct {
            struct FString GameCurrencyType;
            int GameCurrencyAmount;            void ReturnValue;
	} params{ GameCurrencyType, GameCurrencyAmount };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:RecordSimpleCurrencyPurchase");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::RecordProgressWithFullHierarchyAndAttributes(struct FString ProgressType, TArray<struct FString> ProgressNames, TArray<struct FAnalyticsEventAttr> Attributes)
{
	struct {
            struct FString ProgressType;
            TArray<struct FString> ProgressNames;
            TArray<struct FAnalyticsEventAttr> Attributes;            void ReturnValue;
	} params{ ProgressType, ProgressNames, Attributes };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:RecordProgressWithFullHierarchyAndAttributes");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::RecordProgressWithAttributes(struct FString ProgressType, struct FString ProgressName, TArray<struct FAnalyticsEventAttr> Attributes)
{
	struct {
            struct FString ProgressType;
            struct FString ProgressName;
            TArray<struct FAnalyticsEventAttr> Attributes;            void ReturnValue;
	} params{ ProgressType, ProgressName, Attributes };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:RecordProgressWithAttributes");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::RecordProgress(struct FString ProgressType, struct FString ProgressName)
{
	struct {
            struct FString ProgressType;
            struct FString ProgressName;            void ReturnValue;
	} params{ ProgressType, ProgressName };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:RecordProgress");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::RecordItemPurchase(struct FString ItemId, struct FString Currency, int PerItemCost, int ItemQuantity)
{
	struct {
            struct FString ItemId;
            struct FString Currency;
            int PerItemCost;
            int ItemQuantity;            void ReturnValue;
	} params{ ItemId, Currency, PerItemCost, ItemQuantity };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:RecordItemPurchase");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::RecordEventWithAttributes(struct FString EventName, TArray<struct FAnalyticsEventAttr> Attributes)
{
	struct {
            struct FString EventName;
            TArray<struct FAnalyticsEventAttr> Attributes;            void ReturnValue;
	} params{ EventName, Attributes };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:RecordEventWithAttributes");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::RecordEventWithAttribute(struct FString EventName, struct FString AttributeName, struct FString AttributeValue)
{
	struct {
            struct FString EventName;
            struct FString AttributeName;
            struct FString AttributeValue;            void ReturnValue;
	} params{ EventName, AttributeName, AttributeValue };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:RecordEventWithAttribute");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::RecordEvent(struct FString EventName)
{
	struct {
            struct FString EventName;            void ReturnValue;
	} params{ EventName };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:RecordEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::RecordErrorWithAttributes(struct FString Error, TArray<struct FAnalyticsEventAttr> Attributes)
{
	struct {
            struct FString Error;
            TArray<struct FAnalyticsEventAttr> Attributes;            void ReturnValue;
	} params{ Error, Attributes };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:RecordErrorWithAttributes");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::RecordError(struct FString Error)
{
	struct {
            struct FString Error;            void ReturnValue;
	} params{ Error };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:RecordError");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::RecordCurrencyPurchase(struct FString GameCurrencyType, int GameCurrencyAmount, struct FString RealCurrencyType, float RealMoneyCost, struct FString PaymentProvider)
{
	struct {
            struct FString GameCurrencyType;
            int GameCurrencyAmount;
            struct FString RealCurrencyType;
            float RealMoneyCost;
            struct FString PaymentProvider;            void ReturnValue;
	} params{ GameCurrencyType, GameCurrencyAmount, RealCurrencyType, RealMoneyCost, PaymentProvider };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:RecordCurrencyPurchase");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::RecordCurrencyGivenWithAttributes(struct FString GameCurrencyType, int GameCurrencyAmount, TArray<struct FAnalyticsEventAttr> Attributes)
{
	struct {
            struct FString GameCurrencyType;
            int GameCurrencyAmount;
            TArray<struct FAnalyticsEventAttr> Attributes;            void ReturnValue;
	} params{ GameCurrencyType, GameCurrencyAmount, Attributes };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:RecordCurrencyGivenWithAttributes");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::RecordCurrencyGiven(struct FString GameCurrencyType, int GameCurrencyAmount)
{
	struct {
            struct FString GameCurrencyType;
            int GameCurrencyAmount;            void ReturnValue;
	} params{ GameCurrencyType, GameCurrencyAmount };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:RecordCurrencyGiven");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FAnalyticsEventAttr UAnalyticsBlueprintLibrary::MakeEventAttribute(struct FString AttributeName, struct FString AttributeValue)
{
	struct {
            struct FString AttributeName;
            struct FString AttributeValue;
            struct FAnalyticsEventAttr ReturnValue;
	} params{ AttributeName, AttributeValue };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:MakeEventAttribute");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FString UAnalyticsBlueprintLibrary::GetUserId()
{
	struct {
            struct FString ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:GetUserId");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static struct FString UAnalyticsBlueprintLibrary::GetSessionId()
{
	struct {
            struct FString ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:GetSessionId");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::FlushEvents()
{
    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:FlushEvents");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static void UAnalyticsBlueprintLibrary::EndSession()
{
    static auto fn = UObject::FindObject("/Script/AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary:EndSession");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

