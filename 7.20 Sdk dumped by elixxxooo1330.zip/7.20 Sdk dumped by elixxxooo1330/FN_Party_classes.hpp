#pragma once

#include "../SDK.hpp"

namespace SDK {


class UChatroom : public UObject
{
	public:
	    struct FString CurrentChatRoomId; // 0x28 Size: 0x10
	    int MaxChatRoomRetries; // 0x38 Size: 0x4
	    int NumChatRoomRetries; // 0x3c Size: 0x4
	    char UnknownData0[0x18];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Party.Chatroom");
			return (class UClass*)ptr;
		};

};

class USocialManager : public UObject
{
	public:
	    char UnknownData0[0x18];
	    TArray<class USocialToolkit*> SocialToolkits; // 0x40 Size: 0x10
	    char UnknownData1[0x140];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Party.SocialManager");
			return (class UClass*)ptr;
		};

};

class USocialParty : public UObject
{
	public:
	    char UnknownData0[0x30];
	    class APartyBeaconClient* ReservationBeaconClientClass; // 0x58 Size: 0x8
	    char UnknownData1[0x10]; // 0x60
	    struct FUniqueNetIdRepl OwningLocalUserId; // 0x70 Size: 0x28
	    struct FUniqueNetIdRepl CurrentLeaderId; // 0x98 Size: 0x28
	    __int64/*MapProperty*/ PartyMembersById; // 0xc0 Size: 0x50
	    char UnknownData2[0x80]; // 0x110
	    class APartyBeaconClient* ReservationBeaconClient; // 0x190 Size: 0x8
	    char UnknownData3[0xc8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Party.SocialParty");
			return (class UClass*)ptr;
		};

};

class UPartyMember : public UObject
{
	public:
	    char UnknownData0[0x40];
	    class USocialUser* SocialUser; // 0x68 Size: 0x8
	    char UnknownData1[0x68];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Party.PartyMember");
			return (class UClass*)ptr;
		};

};

class USocialToolkit : public UObject
{
	public:
	    char UnknownData0[0x38];
	    class USocialUser* LocalUser; // 0x60 Size: 0x8
	    TArray<class USocialUser*> AllUsers; // 0x68 Size: 0x10
	    char UnknownData1[0x50]; // 0x78
	    class ULocalPlayer* LocalPlayerOwner; // 0xc8 Size: 0x8
	    class USocialChatManager* SocialChatManager; // 0xd0 Size: 0x8
	    char UnknownData2[0xf0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Party.SocialToolkit");
			return (class UClass*)ptr;
		};

};

class USocialChatManager : public UObject
{
	public:
	    __int64/*MapProperty*/ DirectChannelsByTargetUser; // 0x28 Size: 0x50
	    __int64/*MapProperty*/ ChatRoomsById; // 0x78 Size: 0x50
	    __int64/*MapProperty*/ ReadOnlyChannelsByDisplayName; // 0xc8 Size: 0x50
	    char UnknownData0[0x60];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Party.SocialChatManager");
			return (class UClass*)ptr;
		};

};

class USocialChatChannel : public UObject
{
	public:
	    char UnknownData0[0xe8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Party.SocialChatChannel");
			return (class UClass*)ptr;
		};

};

class USocialChatRoom : public USocialChatChannel
{
	public:
	    char UnknownData0[0xf8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Party.SocialChatRoom");
			return (class UClass*)ptr;
		};

};

class USocialPartyChatRoom : public USocialChatRoom
{
	public:
	    char UnknownData0[0xf8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Party.SocialPartyChatRoom");
			return (class UClass*)ptr;
		};

};

class USocialPrivateMessageChannel : public USocialChatChannel
{
	public:
	    class USocialUser* TargetUser; // 0xe8 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Party.SocialPrivateMessageChannel");
			return (class UClass*)ptr;
		};

};

class USocialReadOnlyChatChannel : public USocialChatChannel
{
	public:
	    char UnknownData0[0xe8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Party.SocialReadOnlyChatChannel");
			return (class UClass*)ptr;
		};

};

class USocialSettings : public UObject
{
	public:
	    TArray<FName> OssNamesWithEnvironmentIdPrefix; // 0x28 Size: 0x10
	    int DefaultMaxPartySize; // 0x38 Size: 0x4
	    bool bPreferPlatformInvites; // 0x3c Size: 0x1
	    char UnknownData0[0x3];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Party.SocialSettings");
			return (class UClass*)ptr;
		};

};

class USocialUser : public UObject
{
	public:
	    char UnknownData0[0x138];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Party.SocialUser");
			return (class UClass*)ptr;
		};

};


}