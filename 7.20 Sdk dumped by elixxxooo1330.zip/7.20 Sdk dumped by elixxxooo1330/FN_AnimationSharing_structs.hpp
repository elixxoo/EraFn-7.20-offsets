#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FTickAnimationSharingFunction : public FTickFunction
{
	public:
	    char UnknownData0[0x58];

};

struct FAnimationSharingScalability
{
	public:
	    struct FPerPlatformBool UseBlendTransitions; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    struct FPerPlatformFloat BlendSignificanceValue; // 0x4 Size: 0x4
	    struct FPerPlatformInt MaximumNumberConcurrentBlends; // 0x8 Size: 0x4
	    struct FPerPlatformFloat TickSignificanceValue; // 0xc Size: 0x4

};

struct FAnimationSetup
{
	public:
	    class UAnimSharingStateInstance* AnimBlueprint; // 0x0 Size: 0x8
	    struct TSoftObjectPtr<struct UAnimSequence*> AnimSequence; // 0x8 Size: 0x28
	    struct FPerPlatformInt NumRandomizedInstances; // 0x30 Size: 0x4
	    struct FPerPlatformBool Enabled; // 0x34 Size: 0x1
	    char UnknownData0[0x3];

};


}