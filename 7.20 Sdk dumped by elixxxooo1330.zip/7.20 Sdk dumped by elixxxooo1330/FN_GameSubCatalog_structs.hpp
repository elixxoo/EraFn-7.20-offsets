#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class ECatalogRequirementType : uint8_t
{
    RequireFulfillment = 0,
    DenyOnFulfillment = 1,
    RequireItemOwnership = 2,
    DenyOnItemOwnership = 3,
    ECatalogRequirementType_MAX = 4
};

enum class ECatalogOfferType : uint8_t
{
    StaticPrice = 0,
    DynamicBundle = 1,
    ECatalogOfferType_MAX = 2
};

enum class ECatalogSaleType : uint8_t
{
    NotOnSale = 0,
    UndecoratedNewPrice = 1,
    AmountOff = 2,
    PercentOff = 3,
    PercentOn = 4,
    Strikethrough = 5,
    MAX = 6
};

enum class EAppStore : uint8_t
{
    DebugStore = 0,
    EpicPurchasingService = 1,
    IOSAppStore = 2,
    WeGameStore = 3,
    GooglePlayAppStore = 4,
    KindleStore = 5,
    PlayStationStore = 6,
    XboxLiveStore = 7,
    NintendoEShop = 8,
    SamsungGalaxyAppStore = 9,
    MAX = 10
};

enum class EStoreCurrencyType : uint8_t
{
    RealMoney = 0,
    MtxCurrency = 1,
    GameItem = 2,
    Other = 3,
    MAX = 4
};struct FCatalogOfferRequirement
{
	public:
	    ECatalogRequirementType RequirementType; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    int MinQuantity; // 0x4 Size: 0x4
	    struct FString RequiredId; // 0x8 Size: 0x10

};

struct FItemQuantity
{
	public:
	    struct FString TemplateId; // 0x0 Size: 0x10
	    int Quantity; // 0x10 Size: 0x4
	    char UnknownData0[0x4]; // 0x14
	    struct FJsonObjectWrapper Attributes; // 0x18 Size: 0x20

};

struct FCatalogMetaAssetInfo
{
	public:
	    struct FString StructName; // 0x0 Size: 0x10
	    struct FJsonObjectWrapper Payload; // 0x10 Size: 0x20

};

struct FCatalogDynamicBundleItem
{
	public:
	    struct FItemQuantity Item; // 0x0 Size: 0x38
	    bool bCanOwnMultiple; // 0x38 Size: 0x1
	    char UnknownData0[0x3]; // 0x39
	    int RegularPrice; // 0x3c Size: 0x4
	    int DiscountedPrice; // 0x40 Size: 0x4
	    int AlreadyOwnedPriceReduction; // 0x44 Size: 0x4
	    struct FText Title; // 0x48 Size: 0x18
	    struct FText Description; // 0x60 Size: 0x18

};

struct FCatalogItemPrice
{
	public:
	    char CurrencyType; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FString CurrencySubType; // 0x8 Size: 0x10
	    int RegularPrice; // 0x18 Size: 0x4
	    int FinalPrice; // 0x1c Size: 0x4
	    struct FText PriceTextOverride; // 0x20 Size: 0x18
	    char SaleType; // 0x38 Size: 0x1
	    char UnknownData1[0x7]; // 0x39
	    struct FDateTime SaleExpiration; // 0x40 Size: 0x8

};

struct FCatalogKeyValue
{
	public:
	    struct FString Key; // 0x0 Size: 0x10
	    struct FString Value; // 0x10 Size: 0x10

};

struct FCatalogItemSalePrice
{
	public:
	    int SalePrice; // 0x0 Size: 0x4
	    char SaleType; // 0x4 Size: 0x1
	    char UnknownData0[0x3]; // 0x5
	    struct FDateTime StartTime; // 0x8 Size: 0x8
	    struct FDateTime EndTime; // 0x10 Size: 0x8

};

struct FCatalogPurchaseInfo
{
	public:
	    struct FString OfferId; // 0x0 Size: 0x10
	    int PurchaseQuantity; // 0x10 Size: 0x4
	    char Currency; // 0x14 Size: 0x1
	    char UnknownData0[0x3]; // 0x15
	    struct FString CurrencySubType; // 0x18 Size: 0x10
	    int ExpectedTotalPrice; // 0x28 Size: 0x4
	    char UnknownData1[0x4]; // 0x2c
	    struct FString GameContext; // 0x30 Size: 0x10

};

struct FCatalogReceiptInfo
{
	public:
	    char AppStore; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FString AppStoreId; // 0x8 Size: 0x10
	    struct FString ReceiptId; // 0x18 Size: 0x10
	    struct FString ReceiptInfo; // 0x28 Size: 0x10
	    struct FString PurchaseCorrelationId; // 0x38 Size: 0x10
	    char UnknownData1[0x8];

};

struct FKeychainDownload
{
	public:
	    char UnknownData0[0x10];

};


}