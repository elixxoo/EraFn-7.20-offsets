#pragma once

#include "../SDK.hpp"

namespace SDK {


class UAthenaAccountContext : public UBlueprintContextBase
{
	public:
	    void SimulateBattleBookPurchase(int NumLevelsToPurchase, int BonusLevelsGranted, bool bOverLimit); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    bool ShouldReplaceBattleStarsWithAlternateReward(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool IsAtMaxBattlePassTier(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    int GetCurrentSeasonNumber(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    struct FText GetCurrentSeasonName(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    class UAthenaSeasonItemDefinition* GetCurrentSeasonDefinition(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void GetBattleBookPurchaseLimit(int MaxNumLevelsPossibleToPurchase, int BonusLevelsGranted); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaAccountContext");
			return (class UClass*)ptr;
		};

};

class UFortHUDElementWidget : public UCommonUserWidget
{
	public:
	    struct FGameplayTagContainer HUDElementTag; // 0x230 Size: 0x20
	    char UnknownData0[0x250]; // 0x250
	    void OnVisibilitySetEvent(ESlateVisibility InVisibility); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void HandleOnHUDResetToDefaults(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HandleOnHUDElementVisibilityChanged(struct FGameplayTagContainer HiddenHUDElementTags); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHUDElementWidget");
			return (class UClass*)ptr;
		};

};

class UAthenaAIKillsBase : public UFortHUDElementWidget
{
	public:
	    class UTextBlock* KillsText; // 0x258 Size: 0x8
	    class UObject* KillsSource; // 0x260 Size: 0x8
	    bool bCustomKillSource; // 0x268 Size: 0x1
	    char UnknownData0[0x269]; // 0x269
	    void SetKillsSourcePlayerState(class AFortPlayerStateAthena* InPlayerState); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetKillsSourcePlayerController(class AFortPlayerControllerAthena* InPlayerController); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaAIKillsBase");
			return (class UClass*)ptr;
		};

};

class UAthenaAwardAlertBase : public UUserWidget
{
	public:
	    class UAthenaPlayerViewModel* PlayerVM; // 0x228 Size: 0x8
	    char UnknownData0[0x230]; // 0x230
	    void SetDataSource(class UAthenaPlayerViewModel* PlayerViewModel); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnAwardGranted(class UFortAwardItemDefinition* AwardDefinition); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7db1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaAwardAlertBase");
			return (class UClass*)ptr;
		};

};

class UFortActivatablePanel : public UCommonActivatablePanel
{
	public:
	    bool bIsPushedOnToContentPanelStack; // 0x318 Size: 0x1
	    bool bIsAlreadyOnContentPanelStack; // 0x319 Size: 0x1
	    EInputPriority InputPriority; // 0x31a Size: 0x1
	    bool bIsClosableByPlayerInput; // 0x31b Size: 0x1
	    char UnknownData0[0x31c]; // 0x31c
	    void RestoreScrollWidget(class UWidget* FallbackWidget); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void RestoreCenterWidget(class UWidget* FallbackWidget); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7ca1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortActivatablePanel");
			return (class UClass*)ptr;
		};

};

class UFortUIStateWidget_NUI : public UFortActivatablePanel
{
	public:
	    char UnknownData0[0x8];
	    TArray<struct FContentPushState> StackStates; // 0x348 Size: 0x10
	    char UnknownData1[0x358]; // 0x358
	    void SetFrontEndVisibility(bool bHideHeader, bool bHideFooter, bool bHideChatWidget); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void RequestOpenSocialMenu(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void PushContentWidgetInternal(class UWidget* Widget, struct FContentPushState State); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void PushContentWidgetAdvanced(class UWidget* Widget, bool bHideHeader, bool bHideFooter, bool bHideChatWidget); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void PushContentWidget(class UWidget* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    class UWidget* PopContentWidgetInternal(struct FContentPushState State); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    class UWidget* PopContentWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void PopAllContentWidgets(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnLoadingScreenVisibilityChanged(bool IsVisible); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnHUDScaleChanged(float HUDScale); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void OnFrontEndVisibilityUpdated(bool bHideHeader, bool bHideFooter, bool bHideChatWidget); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void OnExitState(EFortUIState NextUIState); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void OnEnterState(EFortUIState PreviousUIState); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void DynamicHandleLoadingScreenVisibilityChanged(bool IsVisible); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x-7c89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUIStateWidget_NUI");
			return (class UClass*)ptr;
		};

};

class UAthenaHUDBase : public UFortUIStateWidget_NUI
{
	public:
	    char UnknownData0[0x10];
	    class UAthenaPlayerViewModel* PlayerViewModel; // 0x368 Size: 0x8
	    char UnknownData1[0x370]; // 0x370
	    void ViewModelChanged(class UAthenaPlayerViewModel* ViewModel); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetQuickBarNative(bool bShouldDoQuickBarNative); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetFullScreenMapVisibility(bool bIsVisible); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnPlaylistExtensionWidgetCreated(EPlaylistUIExtensionSlot ExtensionSlot, class UUserWidget* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleVolumeUnloaded(class APlayerState* ClientState, class AFortVolume* Volume); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void HandleVolumeStateChanged(EVolumeState NewState, class AFortVolume* Volume); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void HandleVolumeLoaded(class APlayerState* ClientState, class AFortVolume* Volume); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void HandleExitVolume(class APlayerState* ClientState, class AFortVolume* Volume); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void HandleEnteredVolume(class APlayerState* ClientState, class AFortVolume* Volume); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void HandleCursorModeChanging(bool bCursorModeEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x-7c61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaHUDBase");
			return (class UClass*)ptr;
		};

};

class UAthenaSpectatorHUDBase : public UAthenaHUDBase
{
	public:
	    class UAthenaSpectatorNameplateLayerBase* NameplateLayer; // 0x380 Size: 0x8
	    char UnknownData0[0x388]; // 0x388
	    void OnUnableToPerformAction(struct FGameplayTagContainer FailedReason, struct FText FailureText); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnSpectatorViewTargetChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnPlayerTargetingChanged(bool bIsTargeting); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnNameplatesEnabledChanged(bool bInNameplatesEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnIndicatorModeChanged(bool bIndicatorsEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnCursorModeChanged(bool bCursorModeEnabled, FName ActionName, class UUserWidget* CursorModeContentWidget); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7c59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaSpectatorHUDBase");
			return (class UClass*)ptr;
		};

};

class UAthenaBroadcastHUDBase : public UAthenaSpectatorHUDBase
{
	public:
	    class UWidgetSwitcher* KillFeedSwitcher; // 0x388 Size: 0x8
	    class UAthenaSpectatorHUDControlsBase* BroadcastHUDControls; // 0x390 Size: 0x8
	    class UAthenaBroadcastMatchStatusWidget* MatchStatusWidget; // 0x398 Size: 0x8
	    class UAthenaBroadcastSquadStatusWidget* SquadStatusWidget; // 0x3a0 Size: 0x8
	    class UCommonWidgetSwitcher* EventMatchInfoSwitcher; // 0x3a8 Size: 0x8
	    struct FDataTableRowHandle ToggleMatchStatusActionRowHandle; // 0x3b0 Size: 0x10
	    struct FDataTableRowHandle ToggleSquadStatusActionRowHandle; // 0x3c0 Size: 0x10
	    struct FDataTableRowHandle ToggleActiveGridScreenActionRowHandle; // 0x3d0 Size: 0x10
	    struct FDataTableRowHandle ToggleEliminatedGridScreenActionRowHandle; // 0x3e0 Size: 0x10
	    struct FDataTableRowHandle ToggleMatchStatusScreenActionRowHandle; // 0x3f0 Size: 0x10
	    struct FDataTableRowHandle ToggleScoreboardScreenActionRowHandle; // 0x400 Size: 0x10
	    char UnknownData0[0x410]; // 0x410
	    void OnToggleSquadStatusActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnToggleScoreboardScreenActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnToggleMatchStatusScreenActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnToggleMatchStatusActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnToggleEliminatedGridScreenActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnToggleActiveGridScreenActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7bd1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaBroadcastHUDBase");
			return (class UClass*)ptr;
		};

};

class UFortActorIndicatorWidget : public UFortHUDElementWidget
{
	public:
	    char UnknownData0[0x8];
	    class AActor* IndicatedActor; // 0x260 Size: 0x8
	    class UPrimitiveComponent* IndicatedActorComponent; // 0x268 Size: 0x8
	    struct FVector RelativeLocation; // 0x270 Size: 0xc
	    float MaxDistance; // 0x27c Size: 0x4
	    bool bClampOnScreen; // 0x280 Size: 0x1
	    bool bShowClampToScreenArrow; // 0x281 Size: 0x1
	    bool bUseScreenSpacePosition; // 0x282 Size: 0x1
	    char UnknownData1[0x1]; // 0x283
	    struct FVector2D ScreenSpaceRelativeOffset; // 0x284 Size: 0x8
	    char UnknownData2[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortActorIndicatorWidget");
			return (class UClass*)ptr;
		};

};

class UAthenaBroadcastHUDMenuStatusBase : public UFortActorIndicatorWidget
{
	public:
	    float ZOffset; // 0x290 Size: 0x4
	    char UnknownData0[0x294]; // 0x294
	    void MapActivated(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void InventoryActivated(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d49];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaBroadcastHUDMenuStatusBase");
			return (class UClass*)ptr;
		};

};

class UAthenaBroadcastHUDMenuStatusLayerBase : public UFortHUDElementWidget
{
	public:
	    class UAthenaBroadcastHUDMenuStatusBase* HUDMenuStatusWidgetClass; // 0x258 Size: 0x8
	    char UnknownData0[0x260]; // 0x260
	    void RemoveHUDMenuStatus(class UAthenaBroadcastHUDMenuStatusBase* HUDMenuStatusWidget); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void AddHUDMenuStatus(class UAthenaBroadcastHUDMenuStatusBase* HUDMenuStatusWidget); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaBroadcastHUDMenuStatusLayerBase");
			return (class UClass*)ptr;
		};

};

class UAthenaBroadcastKillFeedBase : public UFortHUDElementWidget
{
	public:
	    class UFortDynamicEntryBox* KillFeedEntryBox; // 0x258 Size: 0x8
	    float MaxTimeToShowEntry; // 0x260 Size: 0x4
	    char UnknownData0[0x264]; // 0x264
	    void AddKillFeedEntry(struct FAthenaBroadcastKillFeedEntryInfo KillFeedEntryInfo); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7d79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaBroadcastKillFeedBase");
			return (class UClass*)ptr;
		};

};

class UAthenaBroadcastKillFeedItemBase : public UFortHUDElementWidget
{
	public:
	    class UCommonTextBlock* InstigatorNameText; // 0x258 Size: 0x8
	    class UImage* IconImage; // 0x260 Size: 0x8
	    class UCommonTextBlock* VictimNameText; // 0x268 Size: 0x8
	    class URetainerBox* RetainerBox; // 0x270 Size: 0x8
	    class UObject* EliminationIcon; // 0x278 Size: 0x8
	    class UObject* DbnoIcon; // 0x280 Size: 0x8
	    class UObject* StormIcon; // 0x288 Size: 0x8
	    class UObject* FallDamageIcon; // 0x290 Size: 0x8
	    class UObject* ExplosionIcon; // 0x298 Size: 0x8
	    EAthenaBroadcastKillFeedEntryType DesignTime_EntryType; // 0x2a0 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaBroadcastKillFeedItemBase");
			return (class UClass*)ptr;
		};

};

class UAthenaBroadcastMapPanelBase : public UFortActivatablePanel
{
	public:
	    void OnMapIconAdded(class UFortSpectateClickableMapIcon* MapIconIn); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7ca1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaBroadcastMapPanelBase");
			return (class UClass*)ptr;
		};

};

class UAthenaBroadcastMatchStatusWidget : public UCommonUserWidget
{
	public:
	    void OnStormPhaseChanged(int StormPhase); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7da9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaBroadcastMatchStatusWidget");
			return (class UClass*)ptr;
		};

};

class UAthenaBroadcastPlayerLocationWidget : public UFortHUDElementWidget
{
	public:
	    class UCommonTextBlock* PlayerLocationText; // 0x258 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaBroadcastPlayerLocationWidget");
			return (class UClass*)ptr;
		};

};

class UAthenaEventMatchSquadWidgetBase : public UCommonUserWidget
{
	public:
	    TWeakObjectPtr<UAthenaRemoteSquadViewData*> SquadData; // 0x230 Size: 0x8
	    char UnknownData0[0x238]; // 0x238
	    void SetStormcapDamageVisible(bool InVisible); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetSquadIdVisible(bool InVisible); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnSquadPlaceChanged(class UAthenaRemoteSquadViewData* InSquadData, int InSquadPlace); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnSquadKillscoreChanged(class UAthenaRemoteSquadViewData* InSquadData, int InSquadKills); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnSquadIdChanged(class UAthenaRemoteSquadViewData* InSquadData, char InSquadId); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnSquadColorChanged(class UAthenaRemoteSquadViewData* InSquadData, struct FLinearColor InSquadColor); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnPlayerAdded(class UAthenaRemoteSquadViewData* InSquadData, class UAthenaRemotePlayerViewData* InPlayerData); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7da9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaEventMatchSquadWidgetBase");
			return (class UClass*)ptr;
		};

};

class UAthenaBroadcastSquadStatusWidget : public UAthenaEventMatchSquadWidgetBase
{
	public:
	    TWeakObjectPtr<AFortPlayerState*> FollowedPlayer; // 0x238 Size: 0x8
	    char UnknownData0[0x240]; // 0x240
	    void OnFollowedPlayerChanged(class AFortPlayerState* NewFollowedPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void HandleFollowedPlayerChanged(class AFortPlayerControllerSpectating* SpectatorController, class AFortPlayerState* NewFollowedPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7da1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaBroadcastSquadStatusWidget");
			return (class UClass*)ptr;
		};

};

class UFortChallengeBundleCategoryInfo : public UObject
{
	public:
	    TArray<class UFortChallengeBundleScheduleDefinition*> BundleScheduleDefinitions; // 0x28 Size: 0x10
	    TArray<class UFortChallengeBundleInfo*> BundleInfos; // 0x38 Size: 0x10
	    class AFortPlayerController* FortPC; // 0x48 Size: 0x8
	    char UnknownData0[0x50]; // 0x50
	    int GetNumberOfBundles(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    class UFortChallengeBundleScheduleDefinition* GetFirstScheduleDefinition(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool GetExpirationDate(struct FDateTime ExpirationDate); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    TArray<class UFortChallengeBundleInfo*> GetChallengeBundleInfos(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7f91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortChallengeBundleCategoryInfo");
			return (class UClass*)ptr;
		};

};

class UFortChallengeBundleInfo : public UObject
{
	public:
	    class UFortChallengeBundleItem* BundleItem; // 0x28 Size: 0x8
	    class UFortChallengeBundleItemDefinition* BundleDefinition; // 0x30 Size: 0x8
	    class UFortChallengeBundleCategoryInfo* BundleCategoryInfo; // 0x38 Size: 0x8
	    class UFortChallengeBundleScheduleDefinition* BundleScheduleDefinition; // 0x40 Size: 0x8
	    EChallengeScheduleUnlockType BundleUnlockType; // 0x48 Size: 0x1
	    char UnknownData0[0x3]; // 0x49
	    int BundleUnlockValue; // 0x4c Size: 0x4
	    class AFortPlayerController* FortPC; // 0x50 Size: 0x8
	    char UnknownData1[0x58]; // 0x58
	    bool OwnsBattlePass(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool IsUnlocked(struct FFortChallengeBundleInfoLockedReason LockedReason); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool IsRewardThresholdAchieved(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool IsQuestUnlocked(class UFortQuestItemDefinition* LockedQuest, struct FFortChallengeBundleInfoLockedReason LockedReason); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool IsQuestDefALinearChain(class UFortQuestItemDefinition* InQuestDef, int ChainLength, int CurrentChainIndex); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool IsLinearChainQuest(class UFortQuestItem* BundleQuest, int ChainLength, int CurrentChainIndex); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool IsCompleted(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool HasQuestReward(class UFortItemDefinition* ItemDef, int OutRecievedCount, int OutTotalCount); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool HasAnyAssociatedSecretQuestsAndAllAreComplete(class UFortQuestItem* BundleQuest); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    bool HasAnyAssociatedSecretQuests(class UFortQuestItem* BundleQuest); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    class UFortItem* GetRewardItem(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void GetQuests(class UFortQuestManager* QuestManager, EChallengeBundleQuestVisualStyle QuestStyle, TArray<class UFortQuestItem*> OwnedQuests, TArray<class UFortQuestItemDefinition*> UnownedQuests, bool bGetAllQuestsInChain); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    class UFortChallengeBundleCategoryInfo* GetOwningBundleCategoryInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    class UFortChallengeBundleItemDefinition* GetBundleDefinition(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void GetAchievedCount(int OutTotalAchievedCount, int OutTotalRequiredCount, float OutAchievedPercent, float OutThresholdPercent); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    static struct FText FormatLockedReason(class AFortPlayerController* InFortPC, struct FFortChallengeBundleInfoLockedReason InReason, struct FTimespan TimeSinceStart); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x-7f89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortChallengeBundleInfo");
			return (class UClass*)ptr;
		};

};

class UFortChallengeBundleTreeItemWidget : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    TWeakObjectPtr<UObject*> ScheduleOrBundle; // 0xb30 Size: 0x8
	    char UnknownData1[0xb38]; // 0xb38
	    void SetupAsChallengeBundleSchedule(class UFortChallengeBundleCategoryInfo* Schedule); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetupAsChallengeBundle(class UFortChallengeBundleInfo* Bundle); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnBundleUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleBundleUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    class UFortChallengeBundleInfo* GetChallengeBundleInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-74a9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortChallengeBundleTreeItemWidget");
			return (class UClass*)ptr;
		};

};

class UFortChallengeBundleWidget : public UCommonActivatablePanel
{
	public:
	    class UFortChallengeBundleInfo* ChallengeBundleInfo; // 0x318 Size: 0x8
	    char UnknownData0[0x320]; // 0x320
	    void Setup(class UFortChallengeBundleInfo* Info); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnSetup(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnBundleUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void MoveToPrevBundle(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void MoveToNextBundle(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool HasSiblingBundles(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void HandleBundleUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    class UFortChallengeBundleInfo* GetChallengeBundleInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7cc1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortChallengeBundleWidget");
			return (class UClass*)ptr;
		};

};

class UAthenaChallengeBundleScheduleScreenBase : public UFortActivatablePanel
{
	public:
	    char UnknownData0[0x10];
	    __int64/*MapProperty*/ ScheduleCategoryCache; // 0x350 Size: 0x50
	    char UnknownData1[0x3a0]; // 0x3a0
	    void RequestRefreshNavigation(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnRefreshNavigation(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnChallengesChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void GetChallengeCategoryInfos(TArray<class UFortChallengeBundleCategoryInfo*> OutCategoryInfos); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7c39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaChallengeBundleScheduleScreenBase");
			return (class UClass*)ptr;
		};

};

class UAthenaCompassBase : public UFortHUDElementWidget
{
	public:
	    class UMaterialInstanceDynamic* CompassMaterial; // 0x258 Size: 0x8
	    TArray<struct FSlateBrush> MarkerBrushes; // 0x260 Size: 0x10
	    struct FSlateBrush HeadingIndicatorBrush; // 0x270 Size: 0x88
	    struct FSlateBrush StormIndicatorBrush; // 0x2f8 Size: 0x88
	    float MarkerVerticalOffset; // 0x380 Size: 0x4
	    char UnknownData0[0x4]; // 0x384
	    class UAthenaPlayerViewModel* VM; // 0x388 Size: 0x8
	    struct FSlateFontInfo HeadingFont; // 0x390 Size: 0x50
	    char UnknownData1[0x3e0]; // 0x3e0
	    void BindToModel(class UAthenaPlayerViewModel* ViewModel); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7be1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaCompassBase");
			return (class UClass*)ptr;
		};

};

class UAthenaCountdownWidgetBase : public UFortHUDElementWidget
{
	public:
	    void OnDisplayWarningMessage(struct FText FirstLineText, struct FText SecondLineText); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void OnCountdownUpdate(int TimeRemaining, struct FText CountdownUpdateText); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnCountdownStarted(int TimeRemaining, struct FText CountdownIntroText); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnCountdownFinished(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleGamePhaseStepChanged(EAthenaGamePhaseStep Step); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleCountdownUpdate(int TimeRemaining); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleCountdownStarted(int TimeRemaining); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void HandleCountdownFinished(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7d89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaCountdownWidgetBase");
			return (class UClass*)ptr;
		};

};

class UFortItemPickerBase : public UCommonUserWidget
{
	public:
	    MulticastDelegateProperty OnSelectionChangedEvent; // 0x230 Size: 0x10
	    MulticastDelegateProperty OnSelectionCommittedEvent; // 0x240 Size: 0x10
	    MulticastDelegateProperty OnItemClicked; // 0x250 Size: 0x10
	    MulticastDelegateProperty OnItemClickedDoubleClicked; // 0x260 Size: 0x10
	    MulticastDelegateProperty OnItemHoveredEvent; // 0x270 Size: 0x10
	    MulticastDelegateProperty OnItemUnhovered; // 0x280 Size: 0x10
	    class UFortItemTileView* PickerTileView; // 0x290 Size: 0x8
	    bool bConfirmSelectionIfAlreadySelectedAfterOneClick; // 0x298 Size: 0x1
	    char UnknownData0[0x7]; // 0x299
	    class UObject* NewlySelectedItem; // 0x2a0 Size: 0x8
	    __int64/*InterfaceProperty*/ ItemViewContext; // 0x2a8 Size: 0x10
	    char UnknownData1[0x2b8]; // 0x2b8
	    bool TryCommitSelectedItem(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetSelectedItem(class UFortItem* ItemToSelect); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool SetSelectedIndex(int Index); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnItemSelectionEvent__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    class UFortItem* GetSelectedItem(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    int GetIndexForItem(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void ClearSelection(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void CenterSelectedItemTileWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool CanItemBeComitted(class UFortItem* ItemToCommit); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7cf9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemPickerBase");
			return (class UClass*)ptr;
		};

};

class UAthenaCustomizationPicker : public UFortItemPickerBase
{
	public:
	    MulticastDelegateProperty OnCosmeticSelectionSaving; // 0x2e8 Size: 0x10
	    MulticastDelegateProperty OnCosmeticSelectionSaved; // 0x2f8 Size: 0x10
	    MulticastDelegateProperty OnShowSaveButton; // 0x308 Size: 0x10
	    MulticastDelegateProperty OnHideSaveButton; // 0x318 Size: 0x10
	    class UCommonButton* FilterTabButtonType; // 0x328 Size: 0x8
	    class UCommonButtonStyle* FilterTabButtonStyle; // 0x330 Size: 0x8
	    TArray<struct FFortAthenaItemManagementInventoryFilterTabLabelInfo> FilterTabLabelInfoArray; // 0x338 Size: 0x10
	    class UFortTabListWidgetBase* FilterTabList; // 0x348 Size: 0x8
	    FName CurrentFilterName; // 0x350 Size: 0x8
	    EAthenaCustomizationCategory CustomizeCategory; // 0x358 Size: 0x1
	    char UnknownData0[0x3]; // 0x359
	    int SubslotIndex; // 0x35c Size: 0x4
	    bool bAllowCommits; // 0x360 Size: 0x1
	    char UnknownData1[0x17]; // 0x361
	    class UFortItem* ItemListeningTo; // 0x378 Size: 0x8
	    char UnknownData2[0x380]; // 0x380
	    void SetFilter(FName FilterName); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void RefreshView(bool CategoryChanging, bool FilterChanged); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnUpdateSaveButtonVisuals__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnNoItemsAvailableInFilter(struct FText EmptyDisplayText); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnItemsAvailableInFilter(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnCosmeticChangeSaveEvent__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void HandleSelectedItemHasChanged(bool ItemChanged, bool AmmoChanged, bool IngredientsChanged); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void HandleFilterTabSelected(FName TabNameID); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void HandleFilterTabButtonCreated(FName TabNameID, class UCommonButton* TabButton); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void HandleDifferentFilterSetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    struct FText GetQualifiedFilterDisplayName(EAthenaFilterDisplayType InTopFilterDisplaySetting); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void EndCustomizationCategory(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void BeginCustomizationCategory(EAthenaCustomizationCategory Category, int SubslotToEdit); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x-7c61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaCustomizationPicker");
			return (class UClass*)ptr;
		};

};

class UFortItemTileButton : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    class UFortMultiSizeItemCard* ItemWidget; // 0xb30 Size: 0x8
	    TWeakObjectPtr<UFortItem*> Item; // 0xb38 Size: 0x8
	    EFortItemCardSize ItemCardSize; // 0xb40 Size: 0x1
	    bool IsRewardCard; // 0xb41 Size: 0x1
	    char UnknownData1[0x6]; // 0xb42
	    __int64/*InterfaceProperty*/ ItemViewContext; // 0xb48 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemTileButton");
			return (class UClass*)ptr;
		};

};

class UFortItemPickerButton : public UFortItemTileButton
{
	public:
	    char UnknownData0[0xb58];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemPickerButton");
			return (class UClass*)ptr;
		};

};

class UAthenaCustomizationPickerTileButton : public UFortItemPickerButton
{
	public:
	    char UnknownData0[0xb60];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaCustomizationPickerTileButton");
			return (class UClass*)ptr;
		};

};

class UFortActivatablePanelWithItemPreview : public UFortActivatablePanel
{
	public:
	    char UnknownData0[0x8];
	    class UFortItemView* ItemViewObject; // 0x348 Size: 0x8
	    struct FDataTableRowHandle ItemViewUnifiedSupportsCameraControlInputAction; // 0x350 Size: 0x10
	    struct FDataTableRowHandle ItemViewUnifiedZoomInputAction; // 0x360 Size: 0x10
	    struct FDataTableRowHandle ItemViewZoomOutInputAction; // 0x370 Size: 0x10
	    struct FDataTableRowHandle ItemViewZoomInInputAction; // 0x380 Size: 0x10
	    struct FDataTableRowHandle ItemViewRotateInputAction; // 0x390 Size: 0x10
	    bool AllowItemRotation; // 0x428 Size: 0x1
	    bool AllowItemZooming; // 0x429 Size: 0x1
	    bool AutomaticallyRegisterCameraView; // 0x42a Size: 0x1
	    char UnknownData1[0x8d]; // 0x3a3
	    class UDataTable* ActionDataTable; // 0x430 Size: 0x8
	    char UnknownData2[0x438]; // 0x438
	    void OnVaultItemsViewed(TArray<class UFortItem*> Items); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnItemPreviewChanged(class AActor* NewPrefab, class UFortItem* NewItem); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnCosmeticSpecialActionPressed_7(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnCosmeticSpecialActionPressed_6(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnCosmeticSpecialActionPressed_5(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnCosmeticSpecialActionPressed_4(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnCosmeticSpecialActionPressed_3(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnCosmeticSpecialActionPressed_2(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnCosmeticSpecialActionPressed_1(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void OnCosmeticSpecialActionPressed_0(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    class UWidget* GetWidgetForFramingViewedItem(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x-7ba9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortActivatablePanelWithItemPreview");
			return (class UClass*)ptr;
		};

};

class UAthenaCustomizationScreenBase : public UFortActivatablePanelWithItemPreview
{
	public:
	    struct FText CategoryDisplayNames; // 0x438 Size: 0x18
	    char UnknownData0[0x198]; // 0x450
	    struct FText ItemTypeDisplayNames; // 0x5e8 Size: 0x18
	    char UnknownData1[0x1a8]; // 0x600
	    int64_t LastProfileRev; // 0x7a8 Size: 0x8
	    char UnknownData2[0x7b0]; // 0x7b0
	    void ShiftItemsVariantOption(class UAthenaCosmeticAccountItem* Item, int VariantChannelIndex); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void ProcessLoadoutChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleLoadoutChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleInventoryUpdated(__int64/*SetProperty*/ ItemChangeFlags, int64_t ProfileRevision); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    struct FText GetItemTypeDisplayNames(EAthenaCustomizationCategory InCategory); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    class UFortItem* GetFavoriteItemForCategory(EAthenaCustomizationCategory CustomizationType, int SubslotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    struct FText GetCategoryDisplayName(EAthenaCustomizationCategory InCategory); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7831];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaCustomizationScreenBase");
			return (class UClass*)ptr;
		};

};

class UAthenaCustomizationSlotSelectorButton : public UCommonButton
{
	public:
	    EAthenaCustomizationCategory CustomizationType; // 0xb28 Size: 0x1
	    char UnknownData0[0x3]; // 0xb29
	    int SubslotIndex; // 0xb2c Size: 0x4
	    class UFortMultiSizeItemCard* ItemWidget; // 0xb30 Size: 0x8
	    char UnknownData1[0xb38]; // 0xb38
	    void SetCustomizationType(EAthenaCustomizationCategory NewType, int InSubslotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7499];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaCustomizationSlotSelectorButton");
			return (class UClass*)ptr;
		};

};

class UAthenaEliminationOverlayBase : public UUserWidget
{
	public:
	    char UnknownData0[0x228];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaEliminationOverlayBase");
			return (class UClass*)ptr;
		};

};

class UBacchusHUDElement : public UFortHUDElementWidget
{
	public:
	    char UnknownData0[0x8];
	    bool bIsInLayoutMode; // 0x260 Size: 0x1
	    char UnknownData1[0x3]; // 0x261
	    struct FGameplayTag VisualType; // 0x264 Size: 0x8
	    char UnknownData2[0x4]; // 0x26c
	    struct FText WidgetName; // 0x270 Size: 0x18
	    bool bHideWhenNotUsingTouch; // 0x288 Size: 0x1
	    bool bAlwaysShow; // 0x289 Size: 0x1
	    EBacchusHUDStateType OnInBuildMode; // 0x28a Size: 0x1
	    EBacchusHUDStateType OnInCombatMode; // 0x28b Size: 0x1
	    EBacchusHUDStateType OnInEditMode; // 0x28c Size: 0x1
	    EBacchusHUDStateType OnInCreativeMode; // 0x28d Size: 0x1
	    EBacchusHUDStateType IsFreeFalling; // 0x28e Size: 0x1
	    EBacchusHUDStateType IsGliding; // 0x28f Size: 0x1
	    EBacchusHUDStateType CanOpenChute; // 0x290 Size: 0x1
	    EBacchusHUDStateType InLockedBus; // 0x291 Size: 0x1
	    EBacchusHUDStateType InUnlockedBus; // 0x292 Size: 0x1
	    EBacchusHUDStateType OnTargeting; // 0x293 Size: 0x1
	    EBacchusHUDStateType OnUsingScopeTargeting; // 0x294 Size: 0x1
	    EBacchusHUDStateType OnCanTarget; // 0x295 Size: 0x1
	    EBacchusHUDStateType OnCanUseScopeTargeting; // 0x296 Size: 0x1
	    EBacchusHUDStateType OnCrouching; // 0x297 Size: 0x1
	    EBacchusHUDStateType OnCanUseSecondaryAbility; // 0x298 Size: 0x1
	    EBacchusHUDStateType OnDBNO; // 0x299 Size: 0x1
	    EBacchusHUDStateType OnControllingRCPawn; // 0x29a Size: 0x1
	    EBacchusHUDStateType OnInVehicle; // 0x29b Size: 0x1
	    EBacchusHUDStateType OnDrivingVehicle; // 0x29c Size: 0x1
	    char UnknownData3[0x3]; // 0x29d
	    struct FHUDLayoutDataEntry DefaultEntry; // 0x2a0 Size: 0xe0
	    char UnknownData4[0x380]; // 0x380
	    void OnHUDStateUpdate(struct FFortHUDState NewState); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleInputMethodChanged(ECommonInputType CurrentInputType); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    struct FGameplayTag BP_GetMobileVisualType(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7c61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.BacchusHUDElement");
			return (class UClass*)ptr;
		};

};

class UAthenaEquippedItemBase : public UBacchusHUDElement
{
	public:
	    EEquippedWeaponDisplay CurrentMode; // 0x380 Size: 0x1
	    char UnknownData0[0x7]; // 0x381
	    class UAthenaPlayerViewModel* VM; // 0x388 Size: 0x8
	    char UnknownData1[0x390]; // 0x390
	    void WeaponTypeChanged(EEquippedWeaponDisplay Mode); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void UtilityItemTypeChanged(class AFortWeapon* Weapon, class UFortWeaponItemDefinition* Item); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void UtilityItemCountChanged(int Remaining); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetViewModel(class UAthenaPlayerViewModel* ViewModel); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ResourceTypeChanged(class UFortResourceItemDefinition* Item, int ResourceCount); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ResourceCountChanged(int ResourceCount); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnWorldItemsChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnWeaponChanged(class AFortWeapon* NewWeapon, class AFortWeapon* PrevWeapon); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnViewTargetChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnLocalAmmoChanged(int LocalCount, int LocalRemaining); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void OnBuildingMaterialChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void HasAmmoChanged(bool bHasAmmo); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void AmmoTypeChanged(class AFortWeaponRanged* RangedWeapon, class UFortWorldItemDefinition* Item); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void AmmoChanged(int MagazineAmmoCount, int BackupAmmoCount, int TotalRemaining); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x-7c41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaEquippedItemBase");
			return (class UClass*)ptr;
		};

};

class UAthenaEventGamesBase : public UFortActivatablePanel
{
	public:
	    char UnknownData0[0x340];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaEventGamesBase");
			return (class UClass*)ptr;
		};

};

class UAthenaEventScreenBase : public UFortActivatablePanel
{
	public:
	    void OnSquadDataAdded(class UAthenaRemoteSquadViewData* InPlayerData); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void OnPlayerDataAdded(class UAthenaRemotePlayerViewData* InPlayerData); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7ca1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaEventScreenBase");
			return (class UClass*)ptr;
		};

};

class UAthenaEventMatchActiveGridScreenBase : public UAthenaEventScreenBase
{
	public:
	    class UAthenaEventMatchTeamWidgetBase* TeamWidgetClass; // 0x340 Size: 0x8
	    TArray<class UAthenaEventMatchTeamWidgetBase*> ActiveTeams; // 0x348 Size: 0x10
	    int MaxNumColumns; // 0x358 Size: 0x4
	    int MaxTeamCount; // 0x35c Size: 0x4
	    int MaxTeamSize; // 0x360 Size: 0x4
	    char UnknownData0[0x364]; // 0x364
	    void OnTeamEliminated_BP(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnTeamEliminated(int InSquadId); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnTeamChanged_BP(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7c79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaEventMatchActiveGridScreenBase");
			return (class UClass*)ptr;
		};

};

class UAthenaEventMatchEliminatedGridScreenBase : public UAthenaEventScreenBase
{
	public:
	    class UAthenaEventMatchTeamWidgetBase* TeamWidgetClass; // 0x340 Size: 0x8
	    TArray<class UAthenaEventMatchTeamWidgetBase*> EliminatedTeams; // 0x348 Size: 0x10
	    int MaxNumColumns; // 0x358 Size: 0x4
	    int MaxTeamCount; // 0x35c Size: 0x4
	    int MaxTeamSize; // 0x360 Size: 0x4
	    char UnknownData0[0x364]; // 0x364
	    void OnTeamEliminated_BP(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnPlayerEliminatedStateChanged(class UAthenaRemotePlayerViewData* InPlayerData, bool bInIsEliminated); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7c79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaEventMatchEliminatedGridScreenBase");
			return (class UClass*)ptr;
		};

};

class UAthenaEventMatchPlayerWidgetBase : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    TWeakObjectPtr<UAthenaRemotePlayerViewData*> PlayerData; // 0xb30 Size: 0x8
	    char UnknownData1[0xb38]; // 0xb38
	    void SetPlayerData(class UAthenaRemotePlayerViewData* InPlayerData); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnTeamColorChanged(class UAthenaRemotePlayerViewData* InPlayerData, struct FLinearColor InTeamColor); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnStormcapScoreChanged(class UAthenaRemotePlayerViewData* InPlayerData, float InScore); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnSquadIdChanged(class UAthenaRemotePlayerViewData* InPlayerData, char InSquadId); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnShieldHealed(class UAthenaRemotePlayerViewData* InPlayerData, float InShieldPercent); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnShieldDamaged(class UAthenaRemotePlayerViewData* InPlayerData, float InShieldPercent); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnPlayerStateChanged(class UAthenaRemotePlayerViewData* InPlayerData, class AFortPlayerStateAthena* InPlayerState); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnPlayerPawnChanged(class UAthenaRemotePlayerViewData* InPlayerData, class AFortPlayerPawn* InPlayerPawn); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnPlayerNameChanged(class UAthenaRemotePlayerViewData* InPlayerData, struct FString InPlayerName); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnPlayerDataChanged(class UAthenaRemotePlayerViewData* InPlayerData); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void OnPlaceChanged(class UAthenaRemotePlayerViewData* InPlayerData, int InPlace); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void OnMaterialCountChanged(class UAthenaRemotePlayerViewData* InPlayerData, int InCount); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void OnLocationChanged(class UAthenaRemotePlayerViewData* InPlayerData, struct FString InLocation); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void OnKillScoreChanged(class UAthenaRemotePlayerViewData* InPlayerData, int InKillScore); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void OnIsReplayRelevancyPlayerChanged(class UAthenaRemotePlayerViewData* InPlayerData, bool bInIsReplayRelevancyPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void OnIsInRelevancyChanged(class UAthenaRemotePlayerViewData* InPlayerData, bool bInIsInRelevancy); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void OnIsFollowedPlayerChanged(class UAthenaRemotePlayerViewData* InPlayerData, bool bInIsFollowedPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void OnHealthHealed(class UAthenaRemotePlayerViewData* InPlayerData, float InHealthPercent); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void OnHealthDamaged(class UAthenaRemotePlayerViewData* InPlayerData, float InHealthPercent); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void OnDisconnectedChanged(class UAthenaRemotePlayerViewData* InPlayerData, bool bIsDisconnected); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void OnDeadStateChanged(class UAthenaRemotePlayerViewData* InPlayerData, bool bIsDead); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void OnDBNOStateChanged(class UAthenaRemotePlayerViewData* InPlayerData, bool bIsDBNO); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void OnBeingRevivedStateChanged(class UAthenaRemotePlayerViewData* InPlayerData, bool bIsBeingRevived); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x-74a9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaEventMatchPlayerWidgetBase");
			return (class UClass*)ptr;
		};

};

class UAthenaEventMatchScoreboardPlayerWidgetBase : public UAthenaEventMatchPlayerWidgetBase
{
	public:
	    void SetSquadIdVisible(bool InVisible); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-74a9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaEventMatchScoreboardPlayerWidgetBase");
			return (class UClass*)ptr;
		};

};

class UAthenaEventMatchScoreboardScreenBase : public UAthenaEventScreenBase
{
	public:
	    class UCommonListView* ScoreboardListView; // 0x340 Size: 0x8
	    struct FDataTableRowHandle ToggleSquadIdsActionRowHandle; // 0x348 Size: 0x10
	    struct FDataTableRowHandle ToggleStormcapDamageActionRowHandle; // 0x358 Size: 0x10
	    struct FDataTableRowHandle SortByEliminationsActionRowHandle; // 0x368 Size: 0x10
	    struct FDataTableRowHandle SortByPlaceActionRowHandle; // 0x378 Size: 0x10
	    TArray<class UAthenaRemoteSquadViewData*> SquadDataArray; // 0x388 Size: 0x10
	    char UnknownData0[0x398]; // 0x398
	    void SetStormcapDamageVisible(bool InVisible); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetSquadIdsVisible(bool InVisible); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnToggleStormcapDamageActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnToggleSquadIdsActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnSquadKillscoreChanged(class UAthenaRemoteSquadViewData* InSquadData, int InKillScore); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnSquadEliminated(class UAthenaRemoteSquadViewData* InSquadData); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnSortByPlaceActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnSortByEliminationsActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7c41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaEventMatchScoreboardScreenBase");
			return (class UClass*)ptr;
		};

};

class UAthenaEventMatchScoreboardSquadWidget : public UAthenaEventMatchSquadWidgetBase
{
	public:
	    char UnknownData0[0x240];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaEventMatchScoreboardSquadWidget");
			return (class UClass*)ptr;
		};

};

class UAthenaEventMatchStatusScreenBase : public UAthenaEventScreenBase
{
	public:
	    void UpdateTimeSinceLastKillText(struct FText TimeSinceLastKillText); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void UpdateSupplyDropsLootedText(struct FText SupplyDropsLootedText); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void UpdateShotsFiredText(struct FText ShotsFiredText); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void UpdatePlayersRemainingText(struct FText PlayersRemainingText); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void UpdatePiecesDestroyedText(struct FText PiecesDestroyedText); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void UpdatePiecesBuiltText(struct FText PiecesBuiltText); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void UpdateMostKillsText(struct FText MostKillsText); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void UpdateMostKillsScore(struct FText MostKillsScore); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void UpdateMatchTimeText(struct FText MatchTimeText); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void UpdateLongestEliminationText(struct FText LongestEliminationText); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void UpdateLongestEliminationScore(struct FText LongestEliminationScore); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void UpdateGamePhaseTimeTitleText(struct FText GamePhaseTimeTitleText); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void UpdateGamePhaseTimeText(struct FText GamePhaseTimeText); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void UpdateGamePhaseText(struct FText GamePhaseText); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void UpdateFastestKillText(struct FText FastestKillText, struct FText FastestKillTime); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void UpdateDamageTakenText(struct FText DamageTakenText); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void UpdateDamageInflictedText(struct FText DamageInflictedText); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void UpdateDamageHealedText(struct FText DamageHealedText); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void UpdateCircleRadiusText(struct FText CircleRadiusText); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void UpdateChestsLootedText(struct FText ChestsLootedText); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void OnPlayerKillScoreChanged(class UAthenaRemotePlayerViewData* InPlayerData, int InKillScore); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void OnPlayerDeadStateChanged_BP(class UAthenaRemotePlayerViewData* InPlayerData, bool bInIsDead); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void OnPlayerDeadStateChanged(class UAthenaRemotePlayerViewData* InPlayerData, bool bInIsDead); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x-7c51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaEventMatchStatusScreenBase");
			return (class UClass*)ptr;
		};

};

class UAthenaEventMatchTeamWidgetBase : public UCommonUserWidget
{
	public:
	    TArray<class UAthenaEventMatchPlayerWidgetBase*> PlayerWidgets; // 0x230 Size: 0x10
	    char SquadId; // 0x240 Size: 0x1
	    char UnknownData0[0x3]; // 0x241
	    struct FLinearColor TeamColor; // 0x244 Size: 0x10
	    int MaxTeamSize; // 0x254 Size: 0x4
	    class UAthenaEventMatchPlayerWidgetBase* PlayerWidgetClass; // 0x258 Size: 0x8
	    char UnknownData1[0x18]; // 0x260
	    TArray<TWeakObjectPtr<UAthenaRemotePlayerViewData*>> PlayerDatas; // 0x278 Size: 0x10
	    char UnknownData2[0x288]; // 0x288
	    void OnPlayerWidgetAdded(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnPlayerDisconnectedChanged(class UAthenaRemotePlayerViewData* InPlayerData, bool bInIsDisconnected); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnPlayerDeadStateChanged(class UAthenaRemotePlayerViewData* InPlayerData, bool bInIsDead); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool IsTeamDead(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    int GetTeamKills(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7d51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaEventMatchTeamWidgetBase");
			return (class UClass*)ptr;
		};

};

class UAthenaFPSBase : public UFortHUDElementWidget
{
	public:
	    class UTextBlock* FPS; // 0x258 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaFPSBase");
			return (class UClass*)ptr;
		};

};

class UAthenaGadgetFuelWidget : public UCommonUserWidget
{
	public:
	    TWeakObjectPtr<UAthenaGadgetItemDefinition*> AthenaGadgetItemDefinition; // 0x230 Size: 0x8
	    EFortFuelGadgetVisualType FortFuelGadgetVisualType; // 0x238 Size: 0x1
	    char UnknownData0[0x7]; // 0x239
	    class UImage* FuelGaugeProgressImage; // 0x240 Size: 0x8
	    class UCommonNumericTextBlock* CurrentChargesText; // 0x248 Size: 0x8
	    char UnknownData1[0x250]; // 0x250
	    void SetItem(class UFortWorldItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaGadgetFuelWidget");
			return (class UClass*)ptr;
		};

};

class UAthenaGameOverDisplay : public UFortActivatablePanel
{
	public:
	    char UnknownData0[0x340];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaGameOverDisplay");
			return (class UClass*)ptr;
		};

};

class UAthenaGameOverScreenBase : public UFortActivatablePanel
{
	public:
	    void RequestRefreshInput(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void GoToBoss(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool CanShowGoToBoss(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7c99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaGameOverScreenBase");
			return (class UClass*)ptr;
		};

};

class UAthenaGamePhaseWidgetBase : public UFortHUDElementWidget
{
	public:
	    class UMaterialInterface* StormComingFontMaterial; // 0x258 Size: 0x8
	    float StormComingWarningTime; // 0x260 Size: 0x4
	    char UnknownData0[0x4]; // 0x264
	    class UTextBlock* TimeText; // 0x268 Size: 0x8
	    char UnknownData1[0x270]; // 0x270
	    void OnGamePhaseStepChanged(EAthenaGamePhaseStep GamePhaseStep); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HandleGamePhaseStepChanged(EAthenaGamePhaseStep GamePhaseStep); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleCountdownUpdate(int TimeRemaining); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7d69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaGamePhaseWidgetBase");
			return (class UClass*)ptr;
		};

};

class UAthenaHUDContext : public UBlueprintContextBase
{
	public:
	    char UnknownData0[0x8];
	    MulticastDelegateProperty OnLocalPlayerWon; // 0x30 Size: 0x10
	    MulticastDelegateProperty OnLocalPlayerDeathOnWin; // 0x40 Size: 0x10
	    MulticastDelegateProperty OnLocalTeamWon; // 0x50 Size: 0x10
	    MulticastDelegateProperty OnLocalPlayerLost; // 0x60 Size: 0x10
	    MulticastDelegateProperty OnLocalPlayerKilledPlayer; // 0x70 Size: 0x10
	    MulticastDelegateProperty OnLocalPlayerDBNOStateChanged; // 0x80 Size: 0x10
	    MulticastDelegateProperty OnUIGameplayCue; // 0x90 Size: 0x10
	    MulticastDelegateProperty OnLocalPlayerBeginSkydiving; // 0xa0 Size: 0x10
	    MulticastDelegateProperty OnAthenaAutoFireChanged; // 0xb0 Size: 0x10
	    MulticastDelegateProperty OnClientSettingsShowViewersChanged; // 0xc0 Size: 0x10
	    MulticastDelegateProperty OnAthenaGamePhaseChanged; // 0xd0 Size: 0x10
	    MulticastDelegateProperty OnPlayerFiredWeapon; // 0xe0 Size: 0x10
	    MulticastDelegateProperty OnLowPerformanceMode; // 0xf0 Size: 0x10
	    MulticastDelegateProperty OnPTTStateChange; // 0x100 Size: 0x10
	    MulticastDelegateProperty OnCanPTTChange; // 0x110 Size: 0x10
	    MulticastDelegateProperty ShowMobilePickerDelegate; // 0x120 Size: 0x10
	    MulticastDelegateProperty OnPlaylistUIExtensionChanged; // 0x130 Size: 0x10
	    MulticastDelegateProperty OnPlayerNameChangeDelegate; // 0x140 Size: 0x10
	    MulticastDelegateProperty OnAllWinnersAnnouncedDelegate; // 0x150 Size: 0x10
	    MulticastDelegateProperty OnSignalQualityChangeDelegate; // 0x160 Size: 0x10
	    MulticastDelegateProperty OnForwardStartedFalling; // 0x170 Size: 0x10
	    MulticastDelegateProperty OnSpecialActorListChanged; // 0x180 Size: 0x10
	    char UnknownData1[0x10]; // 0x190
	    MulticastDelegateProperty OnInventoryItemSelected; // 0x1a0 Size: 0x10
	    MulticastDelegateProperty OnInventorySwapStarted; // 0x1b0 Size: 0x10
	    MulticastDelegateProperty OnInventorySwapComplete; // 0x1c0 Size: 0x10
	    TWeakObjectPtr<UWidget*> MoveButtonWidgetPtr; // 0x1d0 Size: 0x8
	    struct FAthenaWinnerInfo WinnerInfo; // 0x1d8 Size: 0x20
	    bool bMoveButtonMode; // 0x1f8 Size: 0x1
	    bool bPendingAttachToHUD; // 0x1f9 Size: 0x1
	    char UnknownData2[0x6]; // 0x1fa
	    class UFortGameUIExtenderAthena* PlaylistUIExtender; // 0x200 Size: 0x8
	    TWeakObjectPtr<UFortItem*> LastSelectedInventoryItem; // 0x208 Size: 0x8
	    char UnknownData3[0x210]; // 0x210
	    bool UseTapToShoot(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void UseOrRleoadFromHUDStop(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void UseOrRleoadFromHUDStart(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void UpdateSelectedWidgetMoveOffsetVector(struct FVector2D VectorOffset, float fMoveScale); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void TakeMovementInputFromHUD(struct FVector MoveVector, bool bTrySprint); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void TakeLookStickInputFromHUD(struct FVector2D LookStickPosition); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void TakeLookInputFromHUD(struct FRotator LookRotator); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void TakeItemSelectionInputFromHUD(int TouchIndex, int SlotIdx, bool bIsUsing, EFortQuickBars InQuickBar, bool bReloadOrUseIfAlreadySelected, bool bStopUseImmediately); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SwapQuickBarFocusFromHUD(EFortQuickBars InQuickBar, int SlotOverride); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void StopTargettingFromHUD(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void StopItemSelectionInputFromHUD(int TouchIndex, int SlotIdx, EFortQuickBars InQuickBar); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void StartOrFinishSwap(int SlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ ShowMobilePicker__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void ShowMobilePicker(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    bool ShouldDisplayScoreUI(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    bool ShouldDisplayPlacement(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void SetTargetingToggleable(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void SetSelectWidgetToMoveMode(bool bSet); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void SetSelectedInventoryItem(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void SetResourceMaterial(char NewMaterial); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void SetPTTState(EPTTState NewPushToTalkState); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void SetLockOnStickCoords(struct FVector2D LockOnCoords); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void SelectWidgetToMove(class UWidget* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void ReloadFromHUD(); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void PushGameOverEmoteInput(); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ PTTStateChange__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ PlaylistUIExtensionChanged__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnSpecialActorListChanged__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnSignalQualityChange__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnPlayerNameChange__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnPlayerFiredWeapon__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnLowPerformanceMode__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnLocalTeamWon__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnLocalPlayerWon__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnLocalPlayerLost__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnLocalPlayerKilledPlayer__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnLocalPlayerDeathOnWin__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnLocalPlayerDBNOStateChanged__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnLocalPlayerBeginSkydiving__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnForwardStartedFalling__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    void OnClientSettingUpdatedShowViewers(); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnCanPTTChange__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnAthenaSettingsApplied__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnAthenaInventorySwapStarted__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnAthenaInventorySwapComplete__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnAthenaInventoryItemSelected__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnAthenaHUDAllWinnersAnnounced__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnAthenaGamePhaseChanged__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnAthenaAutoFireChanged__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    void OnAllWinnersAnnounced(); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    void JumpFromHudStart(int TouchIndex); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    void JumpFromHudEnd(); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    bool IsUsingScope(); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    bool IsTargeting(); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    bool IsSwapping(); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    bool IsShowViewerCountEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    bool IsOperatingTurret(); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    bool IsMovingSelectedWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    bool IsInSelectWidgetToMoveMode(); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x7fe1]; // 0x7fe1
	    bool IsInBuildMode(); // 0x0 Size: 0x7fe1
	    char UnknownData63[0x7fe1]; // 0x7fe1
	    bool IsCurrentWeaponFiring(); // 0x0 Size: 0x7fe1
	    char UnknownData64[0x7fe1]; // 0x7fe1
	    bool IsCrouching(); // 0x0 Size: 0x7fe1
	    char UnknownData65[0x7fe1]; // 0x7fe1
	    bool IsAutoRunEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData66[0x7fe1]; // 0x7fe1
	    bool IsActionBound(FName ActionName); // 0x0 Size: 0x7fe1
	    char UnknownData67[0x7fe1]; // 0x7fe1
	    bool HasWifi(); // 0x0 Size: 0x7fe1
	    char UnknownData68[0x7fe1]; // 0x7fe1
	    bool HasLockOnTarget(); // 0x0 Size: 0x7fe1
	    char UnknownData69[0x7fe1]; // 0x7fe1
	    bool HasAutofireTarget(); // 0x0 Size: 0x7fe1
	    char UnknownData70[0x7fe1]; // 0x7fe1
	    void HandleUIGameplayCue(FName CueName, char EventType, struct FGameplayCueParameters Parameters); // 0x0 Size: 0x7fe1
	    char UnknownData71[0x7fe1]; // 0x7fe1
	    void HandleLocalPlayerDBNOStateChanged(bool bIsDBNO); // 0x0 Size: 0x7fe1
	    char UnknownData72[0x7fe1]; // 0x7fe1
	    void HandleLocalPlayerBeginSkydiving(); // 0x0 Size: 0x7fe1
	    char UnknownData73[0x7fe1]; // 0x7fe1
	    void HandleGamePhaseChange(EAthenaGamePhaseStep NewGamePhase); // 0x0 Size: 0x7fe1
	    char UnknownData74[0x7fe1]; // 0x7fe1
	    void GetWinnerText(struct FText ReturnText, struct FText WinnerName); // 0x0 Size: 0x7fe1
	    char UnknownData75[0x7fe1]; // 0x7fe1
	    EAthenaVictoryUIType GetVictoryUIType(); // 0x0 Size: 0x7fe1
	    char UnknownData76[0x7fe1]; // 0x7fe1
	    struct FText GetVictoryText(); // 0x0 Size: 0x7fe1
	    char UnknownData77[0x7fe1]; // 0x7fe1
	    class USoundCue* GetVictoryMusic(); // 0x0 Size: 0x7fe1
	    char UnknownData78[0x7fe1]; // 0x7fe1
	    int GetSquadConnectedCount(); // 0x0 Size: 0x7fe1
	    char UnknownData79[0x7fe1]; // 0x7fe1
	    class UFortItem* GetSelectedInventoryItem(); // 0x0 Size: 0x7fe1
	    char UnknownData80[0x7fe1]; // 0x7fe1
	    EPTTState GetPTTState(); // 0x0 Size: 0x7fe1
	    char UnknownData81[0x7fe1]; // 0x7fe1
	    class UFortGameUIExtenderAthena* GetPlaylistUIExtender(); // 0x0 Size: 0x7fe1
	    char UnknownData82[0x7fe1]; // 0x7fe1
	    struct FString GetPlayerName(); // 0x0 Size: 0x7fe1
	    char UnknownData83[0x7fe1]; // 0x7fe1
	    struct FLinearColor GetPlayerColor(); // 0x0 Size: 0x7fe1
	    char UnknownData84[0x7fe1]; // 0x7fe1
	    void GetLocalTime(int Hours, int Minutes); // 0x0 Size: 0x7fe1
	    char UnknownData85[0x7fe1]; // 0x7fe1
	    int GetJumpPressedTouchIndex(); // 0x0 Size: 0x7fe1
	    char UnknownData86[0x7fe1]; // 0x7fe1
	    int GetInteractPressedTouchIndex(); // 0x0 Size: 0x7fe1
	    char UnknownData87[0x7fe1]; // 0x7fe1
	    bool GetInLowPerformanceMode(); // 0x0 Size: 0x7fe1
	    char UnknownData88[0x7fe1]; // 0x7fe1
	    class UAthenaPlayerViewModel* GetCurrentViewModel(); // 0x0 Size: 0x7fe1
	    char UnknownData89[0x7fe1]; // 0x7fe1
	    bool GetCanPTT(); // 0x0 Size: 0x7fe1
	    char UnknownData90[0x7fe1]; // 0x7fe1
	    TArray<FName> GetBoundActions(); // 0x0 Size: 0x7fe1
	    char UnknownData91[0x7fe1]; // 0x7fe1
	    float GetBatteryLevel(); // 0x0 Size: 0x7fe1
	    char UnknownData92[0x7fe1]; // 0x7fe1
	    void ForwardOnSpecialActorListChanged(struct FSpecialActorRepData SpecialActorData); // 0x0 Size: 0x7fe1
	    char UnknownData93[0x7fe1]; // 0x7fe1
	    void ForceFireFromHUDStop(); // 0x0 Size: 0x7fe1
	    char UnknownData94[0x7fe1]; // 0x7fe1
	    void FireFromHUDStop(int TouchIndex); // 0x0 Size: 0x7fe1
	    char UnknownData95[0x7fe1]; // 0x7fe1
	    void FireFromHUDStart(int TouchIndex); // 0x0 Size: 0x7fe1
	    char UnknownData96[0x7fe1]; // 0x7fe1
	    void ExecuteActionNameFromHUDWithEventType(FName ActionName, char KeyEvent); // 0x0 Size: 0x7fe1
	    char UnknownData97[0x7fe1]; // 0x7fe1
	    void ExecuteActionNameFromHUD(FName ActionName); // 0x0 Size: 0x7fe1
	    char UnknownData98[0x7fe1]; // 0x7fe1
	    void EndUseFromHUD(); // 0x0 Size: 0x7fe1
	    char UnknownData99[0x7fe1]; // 0x7fe1
	    void EnableAutoRunFromHUD(bool bEnable); // 0x0 Size: 0x7fe1
	    char UnknownData100[0x7fe1]; // 0x7fe1
	    float DisplayPlayerWonTime(); // 0x0 Size: 0x7fe1
	    char UnknownData101[0x7fe1]; // 0x7fe1
	    void CycleQuickbar(); // 0x0 Size: 0x7fe1
	    char UnknownData102[0x7fe1]; // 0x7fe1
	    bool CanShootInVehicle(); // 0x0 Size: 0x7fe1
	    char UnknownData103[0x7fe1]; // 0x7fe1
	    bool CanCurrentWeaponAutoFireFromReticle(); // 0x0 Size: 0x7fe1
	    char UnknownData104[0x7fe1]; // 0x7fe1
	    void CancelSwap(); // 0x0 Size: 0x7fe1
	    char UnknownData105[0x7fe1]; // 0x7fe1
	    bool CanAutoRun(); // 0x0 Size: 0x7fe1
	    char UnknownData106[0x7fe1]; // 0x7fe1
	    void BeginUseFromHUD(); // 0x0 Size: 0x7fe1
	    char UnknownData107[0x-7d99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaHUDContext");
			return (class UClass*)ptr;
		};

};

class UAthenaHUDGamePhaseChangingBase : public UFortHUDElementWidget
{
	public:
	    void UpdateMessaging(EAthenaGamePhaseStep Step, struct FText MESSAGE, struct FText TimeText); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void HandleGamePhaseStepChanged(EAthenaGamePhaseStep Step); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void GamePhaseStepChanged(EAthenaGamePhaseStep Step); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaHUDGamePhaseChangingBase");
			return (class UClass*)ptr;
		};

};

class UAthenaHUDInputWidget : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x230];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaHUDInputWidget");
			return (class UClass*)ptr;
		};

};

class UAthenaHUDPlayerActionAlertBase : public UFortHUDElementWidget
{
	public:
	    TWeakObjectPtr<AFortPlayerPawnAthena*> CurrentPlayerPawn; // 0x258 Size: 0x8
	    char UnknownData0[0x260]; // 0x260
	    void RequestNextAlert(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void AlertPlayer(EAthenaPlayerActionAlert Alert, struct FText DetailText); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaHUDPlayerActionAlertBase");
			return (class UClass*)ptr;
		};

};

class UAthenaIndicatorLayerBase : public UFortHUDElementWidget
{
	public:
	    class UFortActorCanvas* GeneralIndicators; // 0x258 Size: 0x8
	    class UAthenaPlayerViewModel* PlayerVM; // 0x260 Size: 0x8
	    class USlateVectorArtData* TeamIndicatorMesh; // 0x268 Size: 0x8
	    char UnknownData0[0x270]; // 0x270
	    void SquadIndicatorsChanged(TArray<class AFortPlayerStateAthena*> PlayerStates); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetDataSource(class UAthenaPlayerViewModel* PlayerViewModel); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    TArray<class AFortPlayerStateAthena*> GetSquadMembers(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    class UAthenaPlayerViewModel* GetPlayerViewModel(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7d61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaIndicatorLayerBase");
			return (class UClass*)ptr;
		};

};

class UAthenaInventoryEquipButtonBase : public UCommonButton
{
	public:
	    class UFortMultiSizeItemCard* ItemWidget; // 0xb28 Size: 0x8
	    class UWidget* EmptyImage; // 0xb30 Size: 0x8
	    int SlotIndex; // 0xb38 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaInventoryEquipButtonBase");
			return (class UClass*)ptr;
		};

};

class UAthenaInventoryFortItemTileButtonBase : public UFortItemTileButton
{
	public:
	    char UnknownData0[0xb58];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaInventoryFortItemTileButtonBase");
			return (class UClass*)ptr;
		};

};

class UAthenaInventoryPanelBase : public UFortActivatablePanel
{
	public:
	    class UFortItemTileView* ResourceView; // 0x340 Size: 0x8
	    class UFortItemTileView* AmmoView; // 0x348 Size: 0x8
	    class UCommonButtonGroup* EquipButtonGroup; // 0x350 Size: 0x8
	    char UnknownData0[0x358]; // 0x358
	    void SetBypassNotifications(bool bBypass); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void RequestEquip(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HandleQuickBarChangedBP(EFortQuickBars QuickBarType); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleInventoryItemSelected(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleCursorModeChangedBP(bool bCursorModeEnabled, FName ActionName, class UUserWidget* CursorModeContentWidget); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleCursorModeChanged(bool bCursorModeEnabled, FName ActionName, class UUserWidget* CursorModeContentWidget); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    class UFortItemTileView* GetTileViewForItem(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void FocusTileView(class UFortItemTileView* TileView); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void AttemptToUpdateFocus(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void AdvanceSelection(class UFortItemTileView* TileView); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7c49];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaInventoryPanelBase");
			return (class UClass*)ptr;
		};

};

class UAthenaItemSelectorScreenBase : public UFortActivatablePanelWithItemPreview
{
	public:
	    class UCommonButton* TabButtonType; // 0x438 Size: 0x8
	    __int64/*MapProperty*/ ItemCategoryButtonLabelInfo; // 0x440 Size: 0x50
	    struct FFortTabButtonLabelInfo VariantButtonLabelInfo; // 0x490 Size: 0xa0
	    class UCommonButton* Button_ConfirmSelection; // 0x530 Size: 0x8
	    class UCommonButton* Button_EditStyle; // 0x538 Size: 0x8
	    class UCommonButton* Button_ConfirmStyle; // 0x540 Size: 0x8
	    class UAthenaCustomizationPicker* Picker_ItemSelector; // 0x548 Size: 0x8
	    class UVerticalBox* ItemInfo; // 0x550 Size: 0x8
	    class UFortItemBaseWidget* Item_HeaderInfo; // 0x558 Size: 0x8
	    class UFortItem* CurrentPreviewItem; // 0x560 Size: 0x8
	    class UAthenaCosmeticItemDefinition* CurrentPreviewItemDef; // 0x568 Size: 0x8
	    TArray<struct FMcpVariantChannelInfo> CurrentPreviewVariantChannels; // 0x570 Size: 0x10
	    class UFortVariantPicker* Picker_VariantSelector; // 0x580 Size: 0x8
	    char UnknownData0[0x20]; // 0x588
	    EAthenaCustomizationCategory CustomizeCategory; // 0x5a8 Size: 0x1
	    char UnknownData1[0x3]; // 0x5a9
	    int SubslotIndex; // 0x5ac Size: 0x4
	    char UnknownData2[0x5b0]; // 0x5b0
	    void StartItemCustomization(EAthenaCustomizationCategory InCategory, int InSubslotIndex, struct FText CategoryDisplayName, struct FText ItemDisplayTypeName); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SaveAndExit(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnVariantSelectionChanged(struct FMcpVariantChannelInfo InVariant); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnTabSelectionChanged(bool bShowingVariants); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnSavingItemStarted(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnItemSelectionCommited(class UFortItem* SelectedItem); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnItemSelectedChanged(class UFortItem* SelectedItem); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnFinsihedItemSetup(struct FText CategoryDisplayName, struct FText ItemDisplayTypeName, EAthenaCustomizationCategory SelectedCategory); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnFinsihedItemSave(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void OnCurrentItemChanged(class UFortItem* SelectedItem); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void HandleSelectedTabChanged(FName SelectedTabID); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    class UFortItem* GetCurrentItem(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void ExitEditStyle(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void EnterEditStyle(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x-7a31];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaItemSelectorScreenBase");
			return (class UClass*)ptr;
		};

};

class UAthenaLeaderboardScreenBase : public UFortActivatablePanel
{
	public:
	    class UFortTabListWidgetBase* LeaderboardTabList; // 0x340 Size: 0x8
	    class UCommonRotator* MatchRotator; // 0x348 Size: 0x8
	    class UCommonRotator* LeaderboardTypeRotator; // 0x350 Size: 0x8
	    class UCommonTextBlock* ResetTimeText; // 0x358 Size: 0x8
	    class UCommonTextBlock* RefreshTimeText; // 0x360 Size: 0x8
	    class UCommonBorder* BorderLocalUserFocus; // 0x368 Size: 0x8
	    class UDataTable* LeaderboardDisplayData; // 0x370 Size: 0x8
	    __int64/*MapProperty*/ ActiveTabButtons; // 0x378 Size: 0x50
	    TArray<class UFortLeaderboardRowProxyInstance*> RowProxies; // 0x3c8 Size: 0x10
	    TArray<class UFortLeaderboardRowProxyInstance*> RowProxiesFreeList; // 0x3d8 Size: 0x10
	    class UFortLeaderboardRowProxyInstance* LocalUserRowProxy; // 0x3e8 Size: 0x8
	    struct FLeaderboardFilter CurrentLeaderboardFilter; // 0x3f0 Size: 0x30
	    bool bUseStatsV2; // 0x458 Size: 0x1
	    char UnknownData0[0x421]; // 0x421
	    void OnUpdateTabButtonText(class UCommonButton* Button, struct FAthenaPlaylistLeaderboardData PlaylistTabData); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnUpdateListHeader(struct FAthenaPlaylistLeaderboardData PlaylistTabData); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnUpdateLeaderboardListUI(bool bWasSuccessful, class UFortLeaderboardRowProxyInstance* LocalUserRow, struct FText QueryErrorStr); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnQueryStarted(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnQueryFinished(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnPlaylistChanged(FName NewPlaylistName, ECommonInputType NewInputType); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnMatchTypeChanged(int MatchTypeIndex); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnFriendsFilterChanged(int FriendsFilterIndex); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnActiveLeaderboardTabChanged(int ActiveWidgetIndex); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool CanShowFriendsOnlyLeaderboard(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7b81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaLeaderboardScreenBase");
			return (class UClass*)ptr;
		};

};

class UAthenaLevelBarBase : public UFortActorIndicatorWidget
{
	public:
	    char UnknownData0[0x290];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaLevelBarBase");
			return (class UClass*)ptr;
		};

};

class UAthenaLoadingScreenPreviewPanelBase : public UFortActivatablePanel
{
	public:
	    class UAthenaLoadingScreenItemDefinition* MyLoadingScreen; // 0x340 Size: 0x8
	    class UNativeWidgetHost* LoadingScreenSlot; // 0x348 Size: 0x8
	    char UnknownData0[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaLoadingScreenPreviewPanelBase");
			return (class UClass*)ptr;
		};

};

class UAthenaLobbyBase : public UFortActivatablePanel
{
	public:
	    char UnknownData0[0x10];
	    class UOverlay* OverlayMain; // 0x350 Size: 0x8
	    char UnknownData1[0x20]; // 0x358
	    class UFriendCodeShareButtonBase* FriendCodeFrontEndShareButton; // 0x378 Size: 0x8
	    class UCatalogMessaging* CatalogMessaging; // 0x380 Size: 0x8
	    class UCommonButton* GenericLinkButton; // 0x388 Size: 0x8
	    char UnknownData2[0x390]; // 0x390
	    void UpdateGenericLinkText(struct FText NewText); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void ShowMobileAutoFireScreen(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void ShowHighlightSummary(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ShowDailyNews(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnUpdateSocialImportButtonText(struct FText NewText); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnPlayerClicked(int PlayerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnNavigationUp(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnNavigationRight(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnNavigationLeft(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void OnLobbyChanged(EFortLobbyType LobbyType); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void OnEndCursorOverPlayer(int PlayerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void OnBeginCursorOverPlayer(int PlayerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void HandlePlaylistNameChanged(FName NewPlaylistName); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void HandleGenericLinkButtonClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void GetCurrentTournamentEvent(struct FString TournamentId, struct FString EventId); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void DynamicHandleLoadingScreenVisibilityChanged(bool IsVisible); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void DisplayStoreUpdated(class UStoreToastRequest* StoreUpdatedRequest); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x-7c51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaLobbyBase");
			return (class UClass*)ptr;
		};

};

class UFortViewModel : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortViewModel");
			return (class UClass*)ptr;
		};

};

class UFortPlayerViewModel : public UFortViewModel
{
	public:
	    char UnknownData0[0xd8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPlayerViewModel");
			return (class UClass*)ptr;
		};

};

class UAthenaPlayerViewModel : public UFortPlayerViewModel
{
	public:
	    char UnknownData0[0x160];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaPlayerViewModel");
			return (class UClass*)ptr;
		};

};

class UAthenaLocalPlayerViewModel : public UAthenaPlayerViewModel
{
	public:
	    class AFortPlayerControllerAthena* PlayerController; // 0x160 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaLocalPlayerViewModel");
			return (class UClass*)ptr;
		};

};

class UAthenaLootStoreScreenBase : public UFortActivatablePanel
{
	public:
	    char UnknownData0[0x340];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaLootStoreScreenBase");
			return (class UClass*)ptr;
		};

};

class UAthenaMapLayer : public UWidget
{
	public:
	    char UnknownData0[0x10];
	    class ULocalPlayer* LocalPlayer; // 0x110 Size: 0x8
	    char UnknownData1[0x118]; // 0x118
	    void SetLocalPlayer(class ULocalPlayer* LocalPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void FlashPlayerIcon(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void ClearTouches(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7ec9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaMapLayer");
			return (class UClass*)ptr;
		};

};

class UAthenaMatchReadyDesktopPopup : public UUserWidget
{
	public:
	    void UserDismissedDialog(bool bBringToFront); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7da1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaMatchReadyDesktopPopup");
			return (class UClass*)ptr;
		};

};

class UAthenaMinimap : public UWidget
{
	public:
	    struct FVector2D DesiredSize; // 0x100 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaMinimap");
			return (class UClass*)ptr;
		};

};

class UAthenaPartyBar : public UCommonUserWidget
{
	public:
	    class UDynamicEntryBox* EntryBox_PartyMembers; // 0x230 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaPartyBar");
			return (class UClass*)ptr;
		};

};

class UAthenaPickingLayer : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x230];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaPickingLayer");
			return (class UClass*)ptr;
		};

};

class UAthenaPlayerHitPointBarBase : public UUserWidget
{
	public:
	    class UAthenaPlayerViewModel* PlayerVM; // 0x228 Size: 0x8
	    EHealthBarType BarType; // 0x230 Size: 0x1
	    char UnknownData0[0x3]; // 0x231
	    float ValueCurrent; // 0x234 Size: 0x4
	    float ValueLast; // 0x238 Size: 0x4
	    float ValueMax; // 0x23c Size: 0x4
	    float LastToCurrentUpdateRate; // 0x240 Size: 0x4
	    char UnknownData1[0x244]; // 0x244
	    void SetDataSource(class UAthenaPlayerViewModel* PlayerViewModel); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnValueChangedWithReason(float Value, EFortHitPointModificationReason Reason); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnMaxValueChanged(float Value); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnDeltaChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnDBNOStateChanged(bool IsDBNO); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    float GetLastValuePercentage(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    float GetCurrentValuePercentage(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7d99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaPlayerHitPointBarBase");
			return (class UClass*)ptr;
		};

};

class UAthenaPlayerIndicatorBase : public UFortActorIndicatorWidget
{
	public:
	    class AFortPlayerStateAthena* PlayerState; // 0x290 Size: 0x8
	    class UAthenaPlayerViewModel* PlayerVM; // 0x298 Size: 0x8
	    char UnknownData0[0x2a0]; // 0x2a0
	    void TalkingStateChanged(class AFortPlayerStateAthena* PS, bool bTalking); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void ShowCallout(ETeamMemberState Callout); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetViewModel(class UAthenaPlayerViewModel* InPlayerVM); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void RefreshCurrentPawn(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void PlayerNameChanged(class AFortPlayerStateAthena* PS, struct FString PlayerName); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void MapIndicatorPositionChanged(class AFortPlayerStateAthena* PS); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void DBNOStateChanged(class AFortPlayerStateAthena* PS, bool bDBNO); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void BeingRevivedStateChanged(class AFortPlayerStateAthena* PS, bool bReviving); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7d41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaPlayerIndicatorBase");
			return (class UClass*)ptr;
		};

};

class UAthenaPlayerInfoBase : public UFortHUDElementWidget
{
	public:
	    class AFortPlayerStateAthena* PlayerState; // 0x258 Size: 0x8
	    struct FSlateColor Color_PlayerNameAlive; // 0x260 Size: 0x28
	    struct FSlateColor Color_PlayerNameDead; // 0x288 Size: 0x28
	    struct FSlateColor Color_PlayerNameDisconnected; // 0x2b0 Size: 0x28
	    char UnknownData0[0x8]; // 0x2d8
	    class UImage* Image_HealthBar; // 0x2e0 Size: 0x8
	    class UImage* Image_ShieldBar; // 0x2e8 Size: 0x8
	    class UImage* Image_DBNOBar; // 0x2f0 Size: 0x8
	    class UImage* Image_PlatformIcon; // 0x2f8 Size: 0x8
	    class UCommonTextBlock* Text_PlayerName; // 0x300 Size: 0x8
	    class UImage* Image_Marker; // 0x308 Size: 0x8
	    class UUserWidget* DBNOStateWidget; // 0x310 Size: 0x8
	    class UImage* Image_DeadIndicator; // 0x318 Size: 0x8
	    class UImage* Image_DisconnectedIndicator; // 0x320 Size: 0x8
	    char UnknownData1[0x328]; // 0x328
	    void TalkingStateChanged(class AFortPlayerStateAthena* PS, bool bTalking); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetPlayerState(class AFortPlayerStateAthena* InPlayerState); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SendEpicFriendInvite(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnGameModeIconChange(class AFortPlayerStateAthena* PS, class UTexture2D* NewGameModeIcon); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnDisplayAddFriend(bool bShowAnimation); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void MutedStateChanged(class AFortPlayerStateAthena* PS, bool Muted); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void MapIndicatorPositionChanged(class AFortPlayerStateAthena* PS); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool IsPlayerOnPC(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void HandleSpectatingChanged(class AFortPlayerStateZone* NewSpectatingTarget); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void DBNOStateChanged(class AFortPlayerStateAthena* PS, bool bDBNO); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void BeingRevivedStateChanged(class AFortPlayerStateAthena* PS, bool bReviving); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7cb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaPlayerInfoBase");
			return (class UClass*)ptr;
		};

};

class UAthenaPlayerKillsBase : public UFortHUDElementWidget
{
	public:
	    class UTextBlock* KillsText; // 0x258 Size: 0x8
	    class UObject* KillsSource; // 0x260 Size: 0x8
	    bool bCustomKillSource; // 0x268 Size: 0x1
	    char UnknownData0[0x269]; // 0x269
	    void SetKillsSourcePlayerState(class AFortPlayerStateAthena* InPlayerState); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetKillsSourcePlayerController(class AFortPlayerControllerAthena* InPlayerController); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaPlayerKillsBase");
			return (class UClass*)ptr;
		};

};

class UAthenaPlayersLeftBase : public UFortHUDElementWidget
{
	public:
	    void SetPlayersLeftText(struct FText PlayersText); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7d71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaPlayersLeftBase");
			return (class UClass*)ptr;
		};

};

class UAthenaPlayerVitalityBarBase : public UUserWidget
{
	public:
	    class UAthenaPlayerViewModel* PlayerVM; // 0x228 Size: 0x8
	    char UnknownData0[0x230]; // 0x230
	    void SetDataSource(class UAthenaPlayerViewModel* PlayerViewModel); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7db1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaPlayerVitalityBarBase");
			return (class UClass*)ptr;
		};

};

class UAthenaPostMatchScreenBase : public UFortActorIndicatorWidget
{
	public:
	    char UnknownData0[0x290];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaPostMatchScreenBase");
			return (class UClass*)ptr;
		};

};

class UAthenaProfileStatBox : public USizeBox
{
	public:
	    MulticastDelegateProperty OnStatViewChanged; // 0x148 Size: 0x10
	    bool bRespectParentStatView; // 0x158 Size: 0x1
	    char UnknownData0[0x7]; // 0x159
	    class UAthenaBaseStatView* StatView; // 0x160 Size: 0x8
	    char UnknownData1[0x168]; // 0x168
	    void SetStatView(class UAthenaBaseStatView* InStatView, bool RespectParentStatView); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnStatViewChanged__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    struct FFortUIStatStyle GetStatStyle(struct FGameplayTag InStat); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    class UAthenaBaseStatView* GetBaseStatView(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7e71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaProfileStatBox");
			return (class UClass*)ptr;
		};

};

class UAthenaBaseStatView : public UObject
{
	public:
	    float GetStat(struct FGameplayTag InStat); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaBaseStatView");
			return (class UClass*)ptr;
		};

};

class UAthenaWeaponStatView : public UAthenaBaseStatView
{
	public:
	    class UFortWeaponItemDefinition* GetWeaponDefinition(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7fa9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaWeaponStatView");
			return (class UClass*)ptr;
		};

};

class UAthenaMatchStatView : public UAthenaBaseStatView
{
	public:
	    char UnknownData0[0xa0];
	    TArray<class UAthenaWeaponStatView*> WeaponStatViews; // 0xc8 Size: 0x10
	    char UnknownData1[0xd8]; // 0xd8
	    TArray<class UAthenaWeaponStatView*> GetWeaponViews(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    class UAthenaWeaponStatView* GetWeaponViewHighestStat(struct FGameplayTag InStat); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    TArray<class UAthenaWeaponStatView*> GetSortedWeaponViews(struct FGameplayTag InStat); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    struct FString GetMatchID(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    struct FDateTime GetMatchEndTime(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7f09];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaMatchStatView");
			return (class UClass*)ptr;
		};

};

class UAthenaMatchSetStatView : public UAthenaMatchStatView
{
	public:
	    class UAthenaSeasonStats* OwningSeason; // 0xd8 Size: 0x8
	    FName PlaylistId; // 0xe0 Size: 0x8
	    TArray<class UAthenaMatchStatView*> BestMatches; // 0xe8 Size: 0x10
	    char UnknownData0[0xf8]; // 0xf8
	    class UAthenaSeasonStats* GetOwningSeason(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    TArray<class UAthenaMatchStatView*> GetBestMatchViews(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7ee9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaMatchSetStatView");
			return (class UClass*)ptr;
		};

};

class UAthenaProfileStatContext : public UBlueprintContextBase
{
	public:
	    MulticastDelegateProperty OnStatsProfileLoaded; // 0x28 Size: 0x10
	    char UnknownData0[0x38]; // 0x38
	    __int64/*DelegateFunction*/ OnAthenaStatsProfileLoaded__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    TArray<class UAthenaMatchStatView*> CreateMatchViews(TArray<struct FAthenaMatchStats> InRecentMatches); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    class UAthenaMatchSetStatView* CreateMatchStatView(class UAthenaSeasonStats* StatSet, FName Bucket); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    class UAthenaMatchStatView* CreateCurrentMatchStatView(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7fa1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaProfileStatContext");
			return (class UClass*)ptr;
		};

};

class UAthenaProfileStatListWidgetBase : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    class UAthenaProfileStatBox* ProfileStatBox; // 0xb30 Size: 0x8
	    char UnknownData1[0xb38]; // 0xb38
	    void OnStatChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HandleStatViewChanged(class UAthenaBaseStatView* StatView); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-74a9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaProfileStatListWidgetBase");
			return (class UClass*)ptr;
		};

};

class UAthenaProfileStatsBase : public UCommonActivatablePanel
{
	public:
	    class UAthenaProfileStatBox* ProfileStatBox; // 0x318 Size: 0x8
	    TArray<class UAthenaSeasonStats*> StatSets; // 0x320 Size: 0x10
	    class UAthenaSeasonStats* CurrentViewedStatSet; // 0x330 Size: 0x8
	    class UAthenaMatchStatView* CurrentStatView; // 0x338 Size: 0x8
	    FName CurrentPlaylist; // 0x340 Size: 0x8
	    char UnknownData0[0x348]; // 0x348
	    void Setup(struct FUniqueNetIdRepl InUniqueId); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void PrevStatSet(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnStatSetChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnStartFetchingData(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnProfileLoaded(class UFortMcpProfileAthenaStats* ProfileAthenaStats); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnNoData(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnDataRecieved(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    int NumStatSets(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void NextStatSet(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void NextPlaylist(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    struct FUniqueNetIdRepl GetUniqueID(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    class UAthenaSeasonStats* GetCurrentStatSet(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    struct FText GetCurrentPlaylistName(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x-7c71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaProfileStatsBase");
			return (class UClass*)ptr;
		};

};

class UAthenaProfileStatsRecentMatchesBase : public UCommonActivatablePanel
{
	public:
	    TArray<class UAthenaMatchStatView*> RecentMatches; // 0x318 Size: 0x10
	    char UnknownData0[0x328]; // 0x328
	    void Setup(struct FUniqueNetIdRepl InUniqueId); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnStartFetchingData(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnRecentMatcheChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnProfileLoaded(class UFortMcpProfileAthenaStats* ProfileAthenaStats); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnNoData(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnDataRecieved(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    struct FUniqueNetIdRepl GetUniqueID(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    TArray<class UAthenaMatchStatView*> GetRecentMatches(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7c91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaProfileStatsRecentMatchesBase");
			return (class UClass*)ptr;
		};

};

class UAthenaProfileStatWidgetBase : public UCommonUserWidget
{
	public:
	    struct FGameplayTag Stat; // 0x230 Size: 0x8
	    class UAthenaProfileStatBox* ProfileStatBox; // 0x238 Size: 0x8
	    char UnknownData0[0x240]; // 0x240
	    void SetStatView(class UAthenaBaseStatView* InStatView, bool RespectParentStatView); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetAsStat(struct FGameplayTag InStat); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnStatChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleStatViewChanged(class UAthenaBaseStatView* StatView); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    TArray<struct FStatGroupData> CreateWeaponGroupData(int MaxToReturn, bool bIncludeOtherCategory, bool bPercentages); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7da1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaProfileStatWidgetBase");
			return (class UClass*)ptr;
		};

};

class UAthenaQuickBarNativeCell : public UWidget
{
	public:
	    struct FVector2D SelectionOffset; // 0x100 Size: 0x8
	    float SelectionAnimLength_Seconds; // 0x108 Size: 0x4
	    char UnknownData0[0x4]; // 0x10c
	    struct FSlateBrush EmptyCell_Brush; // 0x110 Size: 0x88
	    struct FVector2D EmptyCell_Padding; // 0x198 Size: 0x8
	    struct FSlateBrush SelectedCell_Brush; // 0x1a0 Size: 0x88
	    struct FSlateBrush ItemPortrait_Brush; // 0x228 Size: 0x88
	    struct FSlateBrush AmmoType_Brush; // 0x2b0 Size: 0x88
	    struct FVector2D AmmoTypeIcon_Size; // 0x338 Size: 0x8
	    struct FVector2D AmmoTypeIcon_Padding; // 0x340 Size: 0x8
	    struct FSlateFontInfo ItemCount_Font; // 0x348 Size: 0x50
	    struct FLinearColor ItemCount_Color; // 0x398 Size: 0x10
	    float ItemCount_OutlineAlphaFactor; // 0x3a8 Size: 0x4
	    char UnknownData1[0x4]; // 0x3ac
	    struct FSlateBrush GadgetFuel_Brush; // 0x3b0 Size: 0x88
	    struct FVector2D GadgetFuel_Padding; // 0x438 Size: 0x8
	    float GadgetFuelChargeCount_OutlineAlphaFactor; // 0x440 Size: 0x4
	    char UnknownData2[0x4]; // 0x444
	    struct FSlateFontInfo GadgetFuelChargeCount_Font; // 0x448 Size: 0x50
	    struct FLinearColor GadgetFuelChargeCount_Color; // 0x498 Size: 0x10
	    char UnknownData3[0x4a8]; // 0x4a8
	    void SetItemToRepresent(class UFortItem* InItemToRepresent); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetIsSelected(bool bInSelected); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void DesiredSizeOverride(float WidthOverride, float HeightOverride); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7b29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaQuickBarNativeCell");
			return (class UClass*)ptr;
		};

};

class UAthenaRemotePlayerViewData : public UObject
{
	public:
	    MulticastDelegateProperty OnPlayerStateChanged; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnTeamColorChanged; // 0x38 Size: 0x10
	    MulticastDelegateProperty OnSquadIdChanged; // 0x48 Size: 0x10
	    MulticastDelegateProperty OnPlayerNameChanged; // 0x58 Size: 0x10
	    MulticastDelegateProperty OnKillScoreChanged; // 0x68 Size: 0x10
	    MulticastDelegateProperty OnLocationChanged; // 0x78 Size: 0x10
	    MulticastDelegateProperty OnHealthHealed; // 0x88 Size: 0x10
	    MulticastDelegateProperty OnHealthDamaged; // 0x98 Size: 0x10
	    MulticastDelegateProperty OnShieldHealed; // 0xa8 Size: 0x10
	    MulticastDelegateProperty OnShieldDamaged; // 0xb8 Size: 0x10
	    MulticastDelegateProperty OnDBNOStateChanged; // 0xc8 Size: 0x10
	    MulticastDelegateProperty OnDeadStateChanged; // 0xd8 Size: 0x10
	    MulticastDelegateProperty OnBeingRevivedStateChanged; // 0xe8 Size: 0x10
	    MulticastDelegateProperty OnDisconnectedChanged; // 0xf8 Size: 0x10
	    MulticastDelegateProperty OnPlayerPawnChanged; // 0x108 Size: 0x10
	    MulticastDelegateProperty OnWeaponChanged; // 0x118 Size: 0x10
	    MulticastDelegateProperty OnDistanceToStormChanged; // 0x128 Size: 0x10
	    MulticastDelegateProperty OnPlaceChanged; // 0x138 Size: 0x10
	    MulticastDelegateProperty OnMaterialCountChanged; // 0x148 Size: 0x10
	    MulticastDelegateProperty OnStormcapScoreChanged; // 0x158 Size: 0x10
	    MulticastDelegateProperty OnIsInRelevancyChanged; // 0x168 Size: 0x10
	    MulticastDelegateProperty OnIsFollowedPlayerChanged; // 0x178 Size: 0x10
	    MulticastDelegateProperty OnIsReplayRelevancyPlayerChanged; // 0x188 Size: 0x10
	    MulticastDelegateProperty OnVehicleStateChanged; // 0x198 Size: 0x10
	    MulticastDelegateProperty OnVehicleHealthHealed; // 0x1a8 Size: 0x10
	    MulticastDelegateProperty OnVehicleHealthDamaged; // 0x1b8 Size: 0x10
	    struct FUniqueNetIdRepl PlayerUID; // 0x1c8 Size: 0x28
	    class AFortPlayerStateAthena* PlayerState; // 0x1f0 Size: 0x8
	    char UnknownData0[0x48]; // 0x1f8
	    class AFortPlayerPawn* CachedPlayerPawn; // 0x240 Size: 0x8
	    char UnknownData1[0x248]; // 0x248
	    __int64/*DelegateFunction*/ WeaponDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ VehicleDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void UpdatePlayerPawn(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void UpdateDistanceToStorm(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ UInt8Delegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ StringDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetPlayerState(class AFortPlayerStateAthena* InPlayerState); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ PlayerStateDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ PawnDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ LinearColorDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ IntDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    float GetVehicleHealthPercent(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    class AFortAthenaVehicle* GetVehicle(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    struct FLinearColor GetTeamColor(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    float GetStormcapScore(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    char GetSquadId(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    float GetShieldPercent(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    struct FUniqueNetIdRepl GetPlayerUID(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    class AFortPlayerStateAthena* GetPlayerState(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    class AFortPlayerPawn* GetPlayerPawn(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    struct FString GetPlayerName(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    int GetPlace(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    int GetMaterialCount(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    struct FString GetLocation(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    int GetKillScore(); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    bool GetIsReplayRelevancyPlayer(); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    bool GetIsInRelevancy(); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    bool GetIsFollowedPlayer(); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    bool GetIsEliminated(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    bool GetIsDrivingVehicle(); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    bool GetIsDisconnected(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    bool GetIsDead(); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    bool GetIsDBNO(); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    bool GetIsBeingRevived(); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    bool GetInAircraft(); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    float GetHealthPercent(); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    int GetDistanceToStorm(); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    class AFortWeapon* GetCurrentWeapon(); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    void ForwardOnWeaponChanged(class AFortWeapon* InNewWeapon, class AFortWeapon* InPrevWeapon); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    void ForwardOnVehicleStateChanged(class AFortPlayerPawn* InPawn, class AFortAthenaVehicle* InNewVehicle, class AFortAthenaVehicle* InOldVehicle); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    void ForwardOnVehicleHealthChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    void ForwardOnStormcapScoreChanged(float InScore); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    void ForwardOnSquadIdChanged(char InSquadId); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    void ForwardOnPlayerNameChanged(class AFortPlayerStateAthena* InPlayerState, struct FString InPlayerName); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    void ForwardOnPlaceChanged(int InPlace); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    void ForwardOnLocationChanged(struct FString InLocation); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    void ForwardOnKillScoreChanged(class AFortPlayerStateAthena* InPlayerState, int InKillScore); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    void ForwardOnHitPointsStateChanged(class AFortPlayerStateAthena* InPlayerState, float InHealthPercent, float InShieldPercent); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    void ForwardOnDisconnectedChanged(class AFortPlayerStateAthena* InPlayerState, bool bInIsDisconnected); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    void ForwardOnDeadStateChanged(class AFortPlayerStateAthena* InPlayerState, bool bInIsDead); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    void ForwardOnDBNOStateChanged(class AFortPlayerStateAthena* InPlayerState, bool bInIsDBNO); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    void ForwardOnBeingRevivedStateChanged(class AFortPlayerStateAthena* InPlayerState, bool bInIsBeingRevived); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ FloatDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ BoolDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData55[0x-7d99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaRemotePlayerViewData");
			return (class UClass*)ptr;
		};

};

class UAthenaRemotePlayerViewModel : public UAthenaPlayerViewModel
{
	public:
	    class AFortPlayerControllerSpectating* PlayerController; // 0x160 Size: 0x8
	    TArray<class AFortPlayerStateAthena*> SquadList; // 0x168 Size: 0x10
	    char UnknownData0[0x178]; // 0x178
	    void OnFollowedPlayerChanged(class AFortPlayerControllerSpectating* SpectatorPC, class AFortPlayerState* NewFollowedPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7e69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaRemotePlayerViewModel");
			return (class UClass*)ptr;
		};

};

class UAthenaRemoteSquadViewData : public UObject
{
	public:
	    MulticastDelegateProperty OnPlayerAdded; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnSquadIdChanged; // 0x38 Size: 0x10
	    MulticastDelegateProperty OnSquadKillscoreChanged; // 0x48 Size: 0x10
	    MulticastDelegateProperty OnSquadPlaceChanged; // 0x58 Size: 0x10
	    MulticastDelegateProperty OnSquadColorChanged; // 0x68 Size: 0x10
	    MulticastDelegateProperty OnSquadEliminated; // 0x78 Size: 0x10
	    TArray<class UAthenaRemotePlayerViewData*> PlayerDataArray; // 0x88 Size: 0x10
	    char UnknownData0[0x98]; // 0x98
	    __int64/*DelegateFunction*/ UInt8Delegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ PlayerDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ LinearColorDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ IntDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandlePlayerPlaceChanged(class UAthenaRemotePlayerViewData* InPlayerData, int InPlace); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandlePlayerKillscoreChanged(class UAthenaRemotePlayerViewData* InPlayerData, int InKillScore); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void HandlePlayerDeadStateChanged(class UAthenaRemotePlayerViewData* InPlayerData, bool InEliminated); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    int GetSquadId(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    struct FLinearColor GetSquadColor(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    TArray<class UAthenaRemotePlayerViewData*> GetPlayerDatas(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    int GetPlace(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    int GetKillScore(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    bool GetIsEliminated(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ EventDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData14[0x-7f29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaRemoteSquadViewData");
			return (class UClass*)ptr;
		};

};

class UAthenaReplayBrowserEntryWidget : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    class UObject* ReplayBrowserEntryObject; // 0xb30 Size: 0x8
	    char UnknownData1[0xb38]; // 0xb38
	    void OnReplayBrowserEntryDataSet(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    struct FText GetDateTimeText(struct FDateTime DateTime); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-74a9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaReplayBrowserEntryWidget");
			return (class UClass*)ptr;
		};

};

class UAthenaReplayBrowserRowProxyInstance : public UObject
{
	public:
	    struct FAthenaReplayBrowserRowData RowData; // 0x28 Size: 0x90

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaReplayBrowserRowProxyInstance");
			return (class UClass*)ptr;
		};

};

class UAthenaReplayBrowserScreenBase : public UFortActivatablePanel
{
	public:
	    TArray<class UAthenaReplayBrowserRowProxyInstance*> RowProxies; // 0x340 Size: 0x10
	    struct FDataTableRowHandle RefreshReplayBrowserActionRowHandle; // 0x350 Size: 0x10
	    char UnknownData0[0x360]; // 0x360
	    void ShowDeleteInvalidDialog(struct FText Title, struct FText MESSAGE); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SaveAndRenameReplay(class UAthenaReplayBrowserRowProxyInstance* RowProxy, struct FString NewReplayName); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void RenameReplay(class UAthenaReplayBrowserRowProxyInstance* RowProxy, struct FString NewReplayName); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void PlayReplay(class UAthenaReplayBrowserRowProxyInstance* RowProxy); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnSaveFailed(struct FText Reason); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnRowsUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnRenameFailed(struct FText Reason); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnRefreshReplayBrowserActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnPlayFailed(struct FText Reason); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnDeleteFailed(struct FText Reason); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnActionStarted(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void OnActionFinished(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    bool IsHandlingAction(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    bool DoesReplayFolderExist(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void DeleteReplay(class UAthenaReplayBrowserRowProxyInstance* RowProxy); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void DeleteInvalidReplays(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void BrowseToReplayFolder(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    bool AreExternalActionsOutstanding(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    bool AreAnyActionsOutstanding(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x-7c69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaReplayBrowserScreenBase");
			return (class UClass*)ptr;
		};

};

class UAthenaResourcesBase : public UFortHUDElementWidget
{
	public:
	    char UnknownData0[0x258];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaResourcesBase");
			return (class UClass*)ptr;
		};

};

class UAthenaRespawnBase : public UFortHUDElementWidget
{
	public:
	    ERespawnUIState RespawnState; // 0x258 Size: 0x1
	    char UnknownData0[0x259]; // 0x259
	    void UpdateAllUI(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnUpdateRespawnState(bool bEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnGamePhaseChanged(EAthenaGamePhase GamePhase); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaRespawnBase");
			return (class UClass*)ptr;
		};

};

class UAthenaScorePopWidgetBase : public UFortHUDElementWidget
{
	public:
	    void OnNewScoreEarned(int NewScoreValue, struct FText NewScoreTypeText, int BigScoreThreshold); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void HandleNewScoreEarned(int NewPoints, EAthenaScoringEvent ScoreType); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7d89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaScorePopWidgetBase");
			return (class UClass*)ptr;
		};

};

class UAthenaSeasonStatusWidget : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x230];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaSeasonStatusWidget");
			return (class UClass*)ptr;
		};

};

class UAthenaSpectatorHitPointBarBase : public UCommonUserWidget
{
	public:
	    EHealthBarType BarType; // 0x230 Size: 0x1
	    char UnknownData0[0x3]; // 0x231
	    float LastToCurrentUpdateRate; // 0x234 Size: 0x4
	    bool bIsDBNO; // 0x238 Size: 0x1
	    char UnknownData1[0x3]; // 0x239
	    TWeakObjectPtr<UAthenaRemotePlayerViewData*> PlayerData; // 0x23c Size: 0x8
	    char UnknownData2[0x244]; // 0x244
	    void SetPlayerData(class UAthenaRemotePlayerViewData* InPlayerData); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnValueHealed(class UAthenaRemotePlayerViewData* InPlayerData, float InValuePercent); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnValueDamaged(class UAthenaRemotePlayerViewData* InPlayerData, float InValuePercent); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnEliminatedStateChanged(class UAthenaRemotePlayerViewData* InPlayerData, bool bInIsEliminated); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnDeltaValueChanged(float InDeltaValue); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnDBNOStateChanged(class UAthenaRemotePlayerViewData* InPlayerData, bool bInIsDBNO); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnDBNOChanged(bool bInIsDBNO); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnCurrentValueChanged(float InCurrentValue); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7d99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaSpectatorHitPointBarBase");
			return (class UClass*)ptr;
		};

};

class UAthenaSpectatorHUDControlsBase : public UCommonUserWidget
{
	public:
	    class UIconTextButtonSpectatorBase* HUDVisibilityButton; // 0x230 Size: 0x8
	    class UIconTextButtonSpectatorBase* PlayerListButton; // 0x238 Size: 0x8
	    class UIconTextButtonSpectatorBase* ViewSettingsButton; // 0x240 Size: 0x8
	    class UIconTextButtonSpectatorBase* PreviousPlayerButton; // 0x248 Size: 0x8
	    class UCommonTextBlock* FollowedPlayerText; // 0x250 Size: 0x8
	    class UIconTextButtonSpectatorBase* NextPlayerButton; // 0x258 Size: 0x8
	    class UIconTextButtonSpectatorBase* CurrentCameraButton; // 0x260 Size: 0x8
	    class UMenuAnchor* CameraSelectAnchor; // 0x268 Size: 0x8
	    char UnknownData0[0x270]; // 0x270
	    void OnViewSettingsButtonClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnPreviousPlayerButtonClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnPlayerListButtonClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnNextPlayerButtonClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnHUDVisibilityButtonClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnFollowedPlayerChanged(class AFortPlayerControllerSpectating* SpectatorPC, class AFortPlayerState* NewFollowedPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnCurrentCameraButtonClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnCameraTypeChanged(class AFortPlayerControllerSpectating* SpectatorPC, ESpectatorCameraType NewCameraType); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7d71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaSpectatorHUDControlsBase");
			return (class UClass*)ptr;
		};

};

class UAthenaSpectatorPlayerListBase : public UAthenaEventScreenBase
{
	public:
	    MulticastDelegateProperty OnSortMethodChanged; // 0x340 Size: 0x10
	    class UCommonListView* ListView; // 0x350 Size: 0x8
	    TArray<class UAthenaRemotePlayerViewData*> PlayerDataArray; // 0x358 Size: 0x10
	    ESpectatorPlayerListSortMethod CurrentSortMethod; // 0x368 Size: 0x1
	    char UnknownData0[0x369]; // 0x369
	    __int64/*DelegateFunction*/ SortMethodDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetSortMethod(ESpectatorPlayerListSortMethod InNewSortMethod); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void FocusListView(class UAthenaRemotePlayerViewData* ItemToFocus); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7c71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaSpectatorPlayerListBase");
			return (class UClass*)ptr;
		};

};

class UAthenaSpectatorMapPlayerListBase : public UAthenaSpectatorPlayerListBase
{
	public:
	    class UAthenaMapLayer* MapLayer; // 0x370 Size: 0x8
	    char UnknownData0[0x378]; // 0x378
	    void OnToggleOnlyShowMapPlayersActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnSortByStateActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnSortBySquadIdActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnSortByPlayerNameActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnSortByEliminationsActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnPlayerSquadIdChanged(class UAthenaRemotePlayerViewData* InPlayerData, char InSquadId); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnPlayerNameChanged(class UAthenaRemotePlayerViewData* InPlayerData, struct FString InPlayerName); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnPlayerKillScoreChanged(class UAthenaRemotePlayerViewData* InPlayerData, int InKillScore); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnPlayerIsInRelevancyChanged(class UAthenaRemotePlayerViewData* InPlayerData, bool bInIsInRelevancy); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnPlayerEliminatedStateChanged(class UAthenaRemotePlayerViewData* InPlayerData, bool bInIsEliminated); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnListItemClicked(class UObject* Item); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    ESpectatorPlayerListSortMethod GetNextSortMethod(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7c69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaSpectatorMapPlayerListBase");
			return (class UClass*)ptr;
		};

};

class UAthenaSpectatorNameplateBase : public UFortActorIndicatorWidget
{
	public:
	    float DistanceToCameraOffsetScale; // 0x290 Size: 0x4
	    float MinZOffset; // 0x294 Size: 0x4
	    float MaxZOffset; // 0x298 Size: 0x4
	    float NearDistanceThreshold; // 0x29c Size: 0x4
	    class UCommonLazyImage* WeaponIcon; // 0x2a0 Size: 0x8
	    class UImage* WeaponBackground; // 0x2a8 Size: 0x8
	    struct TSoftObjectPtr<struct UTexture2D*> EditToolIcon; // 0x2b0 Size: 0x28
	    struct TSoftObjectPtr<struct UTexture2D*> BuildingIcon; // 0x2d8 Size: 0x28
	    struct TSoftObjectPtr<struct UTexture2D*> DriverIcon; // 0x300 Size: 0x28
	    TWeakObjectPtr<UAthenaRemotePlayerViewData*> PlayerData; // 0x328 Size: 0x8
	    EAthenaSpectatorNameplateDistanceState CurrentDistanceState; // 0x330 Size: 0x1
	    char UnknownData0[0x331]; // 0x331
	    void OnWeaponChanged(class UAthenaRemotePlayerViewData* InPlayerData, class AFortWeapon* InNewWeapon); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnVehicleStateChanged_BP(class UAthenaRemotePlayerViewData* InPlayerData, class AFortAthenaVehicle* InNewVehicle, class AFortAthenaVehicle* InOldVehicle); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnVehicleStateChanged(class UAthenaRemotePlayerViewData* InPlayerData, class AFortAthenaVehicle* InNewVehicle, class AFortAthenaVehicle* InOldVehicle); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnTeamColorChanged(class UAthenaRemotePlayerViewData* InPlayerData, struct FLinearColor InTeamColor); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnSquadIdChanged(class UAthenaRemotePlayerViewData* InPlayerData, char InSquadId); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnPlayerPawnChanged(class UAthenaRemotePlayerViewData* InPlayerData, class AFortPlayerPawn* InPlayerPawn); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnPlayerNameChanged(class UAthenaRemotePlayerViewData* InPlayerData, struct FString InPlayerName); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnPlayerDataSet(class UAthenaRemotePlayerViewData* InPlayerData); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnDistanceStateChanged(EAthenaSpectatorNameplateDistanceState NewDistanceState); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7ca9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaSpectatorNameplateBase");
			return (class UClass*)ptr;
		};

};

class UAthenaSpectatorNameplateLayerBase : public UFortHUDElementWidget
{
	public:
	    class UAthenaSpectatorNameplateBase* NameplateWidgetClass; // 0x258 Size: 0x8
	    __int64/*MapProperty*/ NameplateWidgetMap; // 0x260 Size: 0x50
	    char UnknownData0[0x2b0]; // 0x2b0
	    void RemoveNameplate(class UAthenaSpectatorNameplateBase* NameplateWidget); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnPlayerDataAdded(class UAthenaRemotePlayerViewData* InPlayerData); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnNameplatesViewDistanceChanged(float NewDistance); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void AddNameplate(class UAthenaSpectatorNameplateBase* NameplateWidget); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7d31];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaSpectatorNameplateLayerBase");
			return (class UClass*)ptr;
		};

};

class UAthenaSpectatorPlayerListEntryBase : public UAthenaEventMatchPlayerWidgetBase
{
	public:
	    char UnknownData0[0xb38];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaSpectatorPlayerListEntryBase");
			return (class UClass*)ptr;
		};

};

class UAthenaSpectatorPlayerListEntryWidget : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    class UAthenaSpectatorPlayerListRowData* PlayerListRowData; // 0xb30 Size: 0x8
	    char UnknownData1[0xb38]; // 0xb38
	    void OnEntryDataSet(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-74a9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaSpectatorPlayerListEntryWidget");
			return (class UClass*)ptr;
		};

};

class UAthenaSpectatorPlayerListScreenBase : public UCommonUserWidget
{
	public:
	    TArray<class UAthenaSpectatorPlayerListRowData*> RowDataArray; // 0x230 Size: 0x10
	    char UnknownData0[0x240]; // 0x240
	    void UpdateListUI(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnPlayerDied(class AFortPlayerState* NewlyDeadPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnPlayerBecameRelevant(class AFortPlayerState* NewlyRelevantPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnPlayerBecameIrrelevant(class AFortPlayerState* NewlyIrrelevantPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnFollowedPlayerChanged(class AFortPlayerControllerSpectating* SpectatorPC, class AFortPlayerState* NewFollowedPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ClearPlayers(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7da1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaSpectatorPlayerListScreenBase");
			return (class UClass*)ptr;
		};

};

class UAthenaSpectatorUIContext : public UBlueprintContextBase
{
	public:
	    MulticastDelegateProperty OnPlayerDataAdded; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnSquadDataAdded; // 0x38 Size: 0x10
	    __int64/*MapProperty*/ PlayerDataMap; // 0x48 Size: 0x50
	    __int64/*MapProperty*/ SquadDataMap; // 0x98 Size: 0x50
	    class AFortPlayerControllerSpectating* SpectatingPC; // 0xe8 Size: 0x8
	    struct FUniqueNetIdRepl FollowedPlayerUID; // 0xf0 Size: 0x28
	    struct FUniqueNetIdRepl ReplayRelevancyPlayerUID; // 0x118 Size: 0x28
	    char UnknownData0[0x140]; // 0x140
	    __int64/*DelegateFunction*/ SquadDataDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ PlayerDataDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnPlayerStateAdded(class AFortPlayerStateAthena* FPSA); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnPlayerBecameRelevant(class AFortPlayerState* FPS); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnPlayerBecameIrrelevant(class AFortPlayerState* FPS); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnPawnForReplayRelevancyChanged(class AFortPawn* InPawnForReplayRelevancy); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnGameStateSet(class AFortGameState* InGameState); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnGamePhaseChanged(EAthenaGamePhase GamePhase); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnFollowedPlayerChanged(class AFortPlayerControllerSpectating* SpectatorPC, class AFortPlayerState* NewFollowedPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnBroadcastSpectatorPerPlayerInfoChanged(TArray<struct FFortBroadcastInfoPerPlayer> BroadcastPerPlayerInfo); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    __int64/*MapProperty*/ GetSquadDataMap(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    __int64/*MapProperty*/ GetPlayerDataMap(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    class UAthenaRemotePlayerViewData* GetPlayerData(struct FUniqueNetIdRepl PlayerUID); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    class UAthenaRemotePlayerViewData* GetFollowedPlayerData(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x-7ea1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaSpectatorUIContext");
			return (class UClass*)ptr;
		};

};

class UAthenaSquadListBase : public UFortHUDElementWidget
{
	public:
	    class UAthenaPlayerInfoBase* LocalPlayerInfo; // 0x258 Size: 0x8
	    class UDynamicEntryBox* EntryBox_SquadList; // 0x260 Size: 0x8
	    char UnknownData0[0x268]; // 0x268
	    void HandleSquadMemberDisconnected(class AFortPlayerStateAthena* Player); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7d79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaSquadListBase");
			return (class UClass*)ptr;
		};

};

class UAthenaStatsScreenBase : public UFortActivatablePanel
{
	public:
	    char UnknownData0[0x8];
	    class UCommonTabListWidget* StatsTabList; // 0x348 Size: 0x8
	    int CurrentPlaylistId; // 0x350 Size: 0x4
	    bool bWasLastQuerySuccessful; // 0x354 Size: 0x1
	    char UnknownData1[0x355]; // 0x355
	    void OnTabSelected(FName TabName); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnQueryStarted(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnQueryFinished(bool bWasSuccessful); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    struct FString GetWinsTag(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static struct FText GetTimespanAsString(struct FTimespan Timespan); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    struct FString GetThirdTierPlaceTag(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    int GetStatValue(struct FString BaseGameplayTag); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    struct FString GetStatGameplayTag(struct FString BaseStatName); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    struct FString GetSecondTierPlaceTag(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    struct FText GetLastUpdateTime(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    struct FText FormatStatValueAsElapsedTime(struct FTimespan ValueAsTimespan); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7bf9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaStatsScreenBase");
			return (class UClass*)ptr;
		};

};

class UAthenaStormSurgeWarningBase : public UFortHUDElementWidget
{
	public:
	    void OnStormCapStateChanged(EAthenaStormCapState StormCapState); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void OnStopDisplaying(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnStartDisplaying(struct FText TitleText, struct FText SubTitleText, bool bDisplaySubtitle, bool bPlayDamageActiveSound); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaStormSurgeWarningBase");
			return (class UClass*)ptr;
		};

};

class UAthenaStormSurgeWidgetBase : public UFortHUDElementWidget
{
	public:
	    void OnUpdateThresholdDisplay(struct FText ThresholdText, EStormSurgeThresholdType ThresholdType); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void OnStormCapStateChanged(EAthenaStormCapState StormCapState); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnStopDisplaying(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnStartDisplaying(struct FText TitleText); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaStormSurgeWidgetBase");
			return (class UClass*)ptr;
		};

};

class UAthenaTeamAliveCountBase : public UFortHUDElementWidget
{
	public:
	    void SetTeamSlotData(int TeamIdx, struct FAthenaTeamCountSlotData TeamSlotData); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7d71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaTeamAliveCountBase");
			return (class UClass*)ptr;
		};

};

class UAthenaTeamMemberButton : public UCommonButton
{
	public:
	    class UAthenaTeamMemberEntry* MemberEntry; // 0xb28 Size: 0x8
	    class UCommonButton* Button_AddFriend; // 0xb30 Size: 0x8
	    char UnknownData0[0xb38]; // 0xb38
	    void OpenSocialPanel(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnFriendshipStatusDetermined(EFortFriendRequestStatus RequestStatus); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-74a9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaTeamMemberButton");
			return (class UClass*)ptr;
		};

};

class UFortTeamMemberEntryBase : public UCommonUserWidget
{
	public:
	    void OnTeamMemberEstablished(struct FUniqueNetIdRepl UniqueId); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7da1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTeamMemberEntryBase");
			return (class UClass*)ptr;
		};

};

class UFortBasicTeamMemberEntry : public UFortTeamMemberEntryBase
{
	public:
	    class UFortPlayerBanner* Banner_MemberBanner; // 0x240 Size: 0x8
	    class UCommonTextBlock* Text_MemberName; // 0x248 Size: 0x8
	    class UImage* Image_LeaderIcon; // 0x250 Size: 0x8
	    class UImage* Image_PlatformIcon; // 0x258 Size: 0x8
	    class UFortVoiceChatStatusIcon* VoiceIcon_Status; // 0x260 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortBasicTeamMemberEntry");
			return (class UClass*)ptr;
		};

};

class UAthenaTeamMemberEntry : public UFortBasicTeamMemberEntry
{
	public:
	    char UnknownData0[0x18];
	    class UCommonTextBlock* Text_KillCount; // 0x280 Size: 0x8
	    class UHorizontalBox* HBox_KillCount; // 0x288 Size: 0x8
	    class UVerticalBox* VBox_MemberBanner; // 0x290 Size: 0x8
	    class UWidgetSwitcher* Switcher_MemberState; // 0x298 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaTeamMemberEntry");
			return (class UClass*)ptr;
		};

};

class UAthenaTeamScoreWidgetBase : public UFortHUDElementWidget
{
	public:
	    class AFortPlayerStateAthena* CurrPlayerState; // 0x258 Size: 0x8
	    int GoalScore; // 0x260 Size: 0x4
	    int PreviousScore; // 0x264 Size: 0x4
	    int PreviousScorePlacement; // 0x268 Size: 0x4
	    int PreviousDeltaScore; // 0x26c Size: 0x4
	    bool bPreviousIsWinner; // 0x270 Size: 0x1
	    bool bPreviousHasScore; // 0x271 Size: 0x1
	    char UnknownData0[0x272]; // 0x272
	    void OnScoreChanged(int Score); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnPlacementChanged(int Placement); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnLeaderboardChanged(int ScoreDelta, bool bIsWinner, bool bHasScore); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleUpdate(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleSpectatingChanged(class AFortPlayerStateZone* SpectatingTarget); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleScoreChanged(int Score); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7d61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaTeamScoreWidgetBase");
			return (class UClass*)ptr;
		};

};

class UAthenaTimeWidgetBase : public UFortHUDElementWidget
{
	public:
	    bool bIsDisplaying; // 0x258 Size: 0x1
	    char UnknownData0[0x3]; // 0x259
	    float CachedFinalCountdownTime; // 0x25c Size: 0x4
	    struct FTimerHandle UpdateTimerHandle; // 0x260 Size: 0x8
	    class UTextBlock* TimeText; // 0x268 Size: 0x8
	    char UnknownData1[0x270]; // 0x270
	    void UpdateTimeText(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void StopTimeDisplay(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void StartTimeDisplay(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnStopTimeDisplay(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnStartTimeDisplay(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnGamePhaseStepChanged(EAthenaGamePhaseStep GamePhaseStep); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void HandleGamePhaseChanged(EAthenaGamePhase GamePhase); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7d71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaTimeWidgetBase");
			return (class UClass*)ptr;
		};

};

class UAthenaTravelLogFormatting : public UBlueprintFunctionLibrary
{
	public:
	    static bool ShouldDisplayText(struct FAthenaTravelLogEntry Entry); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static bool IsTravelLogTextDisplayEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static struct FText FormatTravelLogEntry(class UObject* WorldContextObject, struct FAthenaTravelLogEntry Entry); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaTravelLogFormatting");
			return (class UClass*)ptr;
		};

};

class UAthenaTrickFeedBase : public UFortHUDElementWidget
{
	public:
	    class UAthenaPlayerViewModel* VM; // 0x258 Size: 0x8
	    char UnknownData0[0x260]; // 0x260
	    void UpdateTrickStats(struct FText StatsText); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void UpdateScore(class UFortVehicleTrickSet* TrickSet, int TotalScore); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void UpdateMultiplier(int Multiplier); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void TrickSequenceStarted(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void TrickSequenceFailed(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void TrickSequenceComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void TrickSequenceCanceled(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void RequestNextSequence(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void BindToModel(class UAthenaPlayerViewModel* ViewModel); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void AddTrick(struct FText TrickName); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7d61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaTrickFeedBase");
			return (class UClass*)ptr;
		};

};

class UAthenaWinConditionMsgBase : public UFortHUDElementWidget
{
	public:
	    char UnknownData0[0x258];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaWinConditionMsgBase");
			return (class UClass*)ptr;
		};

};

class UAthenaWinnersList : public UCommonUserWidget
{
	public:
	    void OnWinnersAnnounced(struct FAthenaWinnerInfo WinnerInfo); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7db1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.AthenaWinnersList");
			return (class UClass*)ptr;
		};

};

class UBacchusButton : public UBacchusHUDElement
{
	public:
	    char ClickMethod; // 0x380 Size: 0x1
	    char TouchMethod; // 0x381 Size: 0x1
	    char UnknownData0[0x2]; // 0x382
	    float ButtonSize; // 0x384 Size: 0x4
	    float ButtonDisplayScale; // 0x388 Size: 0x4
	    char UnknownData1[0x4]; // 0x38c
	    struct FText ButtonSizeName; // 0x390 Size: 0x18
	    struct FText ButtonDisplayScaleName; // 0x3a8 Size: 0x18
	    class UButton* InternalButton; // 0x3c0 Size: 0x8
	    char UnknownData2[0x3c8]; // 0x3c8
	    void SetButtonSprite(class UPaperSprite* NewSprite); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetButtonSize(float NewButtonSize); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetButtonDisplayScale(float NewDisplayScale); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7c11];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.BacchusButton");
			return (class UClass*)ptr;
		};

};

class UBacchusDPICustomScalingRule : public UDPICustomScalingRule
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.BacchusDPICustomScalingRule");
			return (class UClass*)ptr;
		};

};

class UBacchusHUDLayoutToolPanel : public UCommonActivatablePanel
{
	public:
	    class UHUDLayoutToolButtonLayer* ButtonLayer; // 0x318 Size: 0x8
	    class UHUDLayoutToolPanZoomWidget* ZoomWidget; // 0x320 Size: 0x8
	    class UImage* Background; // 0x328 Size: 0x8
	    struct FBackgroundColors CombatColors; // 0x330 Size: 0x30
	    struct FBackgroundColors BuildColors; // 0x360 Size: 0x30
	    struct FVector2D OpenPanelOffset; // 0x390 Size: 0x8
	    class UMaterialInstanceDynamic* BackgroundMID; // 0x398 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.BacchusHUDLayoutToolPanel");
			return (class UClass*)ptr;
		};

};

class UBacchusQuickbar : public UBacchusHUDElement
{
	public:
	    float SlotSize; // 0x380 Size: 0x4
	    char UnknownData0[0x4]; // 0x384
	    struct FText SlotSizeName; // 0x388 Size: 0x18
	    char UnknownData1[0x3a0]; // 0x3a0
	    void Refresh(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7c41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.BacchusQuickbar");
			return (class UClass*)ptr;
		};

};

class UBacchusQuickbarComboSlot : public UBacchusHUDElement
{
	public:
	    float SlotSize; // 0x380 Size: 0x4
	    EComboSlotType SlotType; // 0x384 Size: 0x1
	    char UnknownData0[0x3]; // 0x385
	    int SlotIndex; // 0x388 Size: 0x4
	    char UnknownData1[0x4]; // 0x38c
	    struct FText SlotTypeName; // 0x390 Size: 0x18
	    struct FText SlotIndexName; // 0x3a8 Size: 0x18
	    struct FText SlotSizeName; // 0x3c0 Size: 0x18
	    char UnknownData2[0x3d8]; // 0x3d8
	    void SetSize(float NewButtonSize); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetQuickbarType(int NewType); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void Refresh(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    EFortQuickBars GetQuickbarType(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7c09];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.BacchusQuickbarComboSlot");
			return (class UClass*)ptr;
		};

};

class UBacchusSignalQualityWidget : public UBacchusHUDElement
{
	public:
	    void SetNewSignalQuality(EBacchusSignalQuality NewSignalQuality); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void OnNewSignalQuality(float NewRawQuality); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7c59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.BacchusSignalQualityWidget");
			return (class UClass*)ptr;
		};

};

class UBarrierWidgetBase : public UFortHUDElementWidget
{
	public:
	    char UnknownData0[0x10];
	    struct FBarrierObjectState FriendlyTeamState; // 0x268 Size: 0x10
	    struct FBarrierObjectState EnemyTeamState; // 0x278 Size: 0x10
	    char UnknownData1[0x288]; // 0x288
	    void UpdateHealth(bool bFriendlyTeam, float HealthPercent, EBarrierFoodTeam FoodTeam, bool bFlashBar); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnMutatorObjectUpdated(struct FGameplayMutatorObjectDataArray MutatorArray); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnHandleSpectatingChanged(class AFortPlayerStateZone* SpectatingTarget); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnGamePhaseChanged(EAthenaGamePhase GamePhase); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7d51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.BarrierWidgetBase");
			return (class UClass*)ptr;
		};

};

class UCampaignHUDBase : public UFortUIStateWidget_NUI
{
	public:
	    char UnknownData0[0x370];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.CampaignHUDBase");
			return (class UClass*)ptr;
		};

};

class UCarmineHUDBase : public UUserWidget
{
	public:
	    void OnBossHealthBarChanged(struct FAthenaBossHealthData BossData); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7d89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.CarmineHUDBase");
			return (class UClass*)ptr;
		};

};

class UCarmineUIExtenderBase : public UFortGameUIExtenderAthena
{
	public:
	    bool bShowGoToBossCommand; // 0x30 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.CarmineUIExtenderBase");
			return (class UClass*)ptr;
		};

};

class UCMSContext : public UBlueprintContextBase
{
	public:
	    char UnknownData0[0x90];
	    struct FCmsJsonMessages CachedCmsMessages; // 0xb8 Size: 0x100
	    char UnknownData1[0x1b8]; // 0x1b8
	    void MarkPlaylistInformationAsViewed(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void MarkNewsAsViewed(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool IsNewPlaylistInformationAvailable(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool IsNewNewsAvailable(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    struct FShowdownLatestTournamentData GetLatestShowdownTournamentData(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    struct FKoreanCafeSource GetLatestPCBInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    struct FAthenaNews GetLatestNews(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    struct FAthenaNewsEntry GetLatestEmergencyNotice(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    struct FCreativeAdSource GetLatestCreativeAds(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    struct FAthenaLatestPlaylistData GetLatestAthenaPlaylistData(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x-7e21];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.CMSContext");
			return (class UClass*)ptr;
		};

};

class UCommonTagVisibilityWidget : public UContentWidget
{
	public:
	    struct FGameplayTagContainer HUDElementTag; // 0x118 Size: 0x20
	    char UnknownData0[0x138]; // 0x138
	    void OnVisibilitySetEvent(ESlateVisibility InVisibility); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void Initialize(class ULocalPlayer* OwningLocalPlayer, class APlayerController* OwningPlayerController); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HandleOnHUDResetToDefaults(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleOnHUDElementVisibilityChanged(struct FGameplayTagContainer HiddenHUDElementTags); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7e81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.CommonTagVisibilityWidget");
			return (class UClass*)ptr;
		};

};

class UCreativeHUDLContext : public UBlueprintContextBase
{
	public:
	    MulticastDelegateProperty OnRotationAxisChanged; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnDropToFloorChanged; // 0x38 Size: 0x10
	    MulticastDelegateProperty OnPrecisionChanged; // 0x48 Size: 0x10
	    MulticastDelegateProperty OnMoveToolLineOfSightBlockingChanged; // 0x58 Size: 0x10
	    class AFortCreativeMoveTool* CurrentMoveTool; // 0x68 Size: 0x8
	    char UnknownData0[0x70]; // 0x70
	    void OnWeaponEquipped(class AFortWeapon* NewWeapon, class AFortWeapon* PrevWeapon); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnPlayerPawnSet(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool IsIgnoringLOSBlockers(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    struct FRotator GetRotationAxis(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void GetPrecisionLevel(bool SnappingEnabled, char GridSnappingIndex); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    class AFortPlayerPawn* GetOwningPlayerPawn(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool GetDropToFloorEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void ForwardOnRotationAxisChanged(char AxisIndex); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void ForwardOnPrecisionChanged(bool bPrecisionOn, char GridSnapIndex); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void ForwardOnLOSChanged(bool bLOSBlockingOn); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void ForwardOnDropToFloorChanged(bool bDropToFloorOn); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x-7f71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.CreativeHUDLContext");
			return (class UClass*)ptr;
		};

};

class UCreativePerformanceHUDBase : public UFortHUDElementWidget
{
	public:
	    void SetUIMetrics(struct FVolumePerformanceMetrics VolumePerformanceMetrics); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void OnPerformanceMetricsUpdated(struct FVolumePerformanceMetrics VolumePerformanceMetrics); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnClientExitVolume(class APlayerState* ClientState, class AFortVolume* Volume); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnClientEnterVolume(class APlayerState* ClientState, class AFortVolume* Volume); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HideUIMetrics(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleVolumeStateChanged(EVolumeState NewState, class AFortVolume* Volume); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7d71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.CreativePerformanceHUDBase");
			return (class UClass*)ptr;
		};

};

class UDeimosSurvivalWidgetBase : public UFortHUDElementWidget
{
	public:
	    TArray<struct FString> SurvivalStateDefaultText; // 0x258 Size: 0x10
	    struct FGameplayTag ObjectiveTag; // 0x268 Size: 0x8
	    char UnknownData0[0x270]; // 0x270
	    void OnUpdateStateText(struct FText StateText); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnUpdateObjectiveIcon(struct FSurvivalObjectiveIconData ObjectiveIconData); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.DeimosSurvivalWidgetBase");
			return (class UClass*)ptr;
		};

};

class UDiscoCaptureWidgetBase : public UFortHUDElementWidget
{
	public:
	    struct FDiscoCaptureUIData CaptureUIData; // 0x258 Size: 0x40
	    struct FDiscoCaptureUIData PrevCaptureUIData; // 0x298 Size: 0x40
	    char UnknownData0[0x8]; // 0x2d8
	    char LastViewedTeam; // 0x2e0 Size: 0x1
	    char UnknownData1[0x2e1]; // 0x2e1
	    void UpdateDiscoCaptureUI(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void UpdateAllUI(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnUpdateCaptureUI(EDiscoCaptureUIState CaptureState, struct FText TextToDisplay, class UMaterialInstanceDynamic* ImageMID, float FillAmount); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnHandleSpectatingChanged(class AFortPlayerStateZone* SpectatingTarget); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    class AAthenaCapturePoint* GetClosestCapturePoint(class AFortPlayerPawnAthena* ViewPawn); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7cf9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.DiscoCaptureWidgetBase");
			return (class UClass*)ptr;
		};

};

class UDiscoWidgetBase : public UFortHUDElementWidget
{
	public:
	    TArray<struct FDiscoCaptureIconData> CapturePointIconList; // 0x258 Size: 0x10
	    char UnknownData0[0x20]; // 0x268
	    TArray<float> PlayScoreProgressSoundPercentagesMild; // 0x288 Size: 0x10
	    TArray<float> PlayScoreProgressSoundPercentagesMedium; // 0x298 Size: 0x10
	    TArray<float> PlayScoreProgressSoundPercentagesStrong; // 0x2a8 Size: 0x10
	    float PercentageScoreToPlayCountdown; // 0x2b8 Size: 0x4
	    float PercentageScoreToPlayFinalCountdown; // 0x2bc Size: 0x4
	    float ScoreCountdownSoundFrequency; // 0x2c0 Size: 0x4
	    bool bLocalTeamIsScoring; // 0x2c4 Size: 0x1
	    bool bEnemyTeamIsScoring; // 0x2c5 Size: 0x1
	    char LastViewedTeam; // 0x2c6 Size: 0x1
	    char UnknownData1[0x2c7]; // 0x2c7
	    void UpdateAllUI(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnUpdateTeamScore(int TeamIndex, struct FDiscoTeamScoreData ScoreData); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnUpdateCapturePoint(int IconIndex, struct FDiscoCaptureIconData IconData); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnPlayScoreProgressSound(EDiscoScoreProgressTypes ScoreProgressType, bool bIsLocalTeam); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnMutatorObjectUpdated(struct FGameplayMutatorObjectDataArray MutatorArray); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnHandleSpectatingChanged(class AFortPlayerStateZone* SpectatingTarget); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnGamePhaseChanged(EAthenaGamePhase GamePhase); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnCountdownTimerUpdate(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7d19];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.DiscoWidgetBase");
			return (class UClass*)ptr;
		};

};

class UEmergencyNoticeBase : public UCommonUserWidget
{
	public:
	    void ShowNotice(struct FText Title, struct FText Body); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void HideNotice(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7db1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.EmergencyNoticeBase");
			return (class UClass*)ptr;
		};

};

class UEnableMultiFactorModal : public UFortActivatablePanel
{
	public:
	    bool bHasEnableMFABeenClicked; // 0x340 Size: 0x1
	    bool bShouldShowConsoleVersion; // 0x341 Size: 0x1
	    char UnknownData0[0x16]; // 0x342
	    class UCommonButton* Button_EnableMFA; // 0x358 Size: 0x8
	    class UCommonButton* Button_RemindLater; // 0x360 Size: 0x8
	    class UCommonButton* Button_OptOut; // 0x368 Size: 0x8
	    class UCommonButton* Button_ConsoleMFAEnabled; // 0x370 Size: 0x8
	    char UnknownData1[0x378]; // 0x378
	    bool QueueModal(bool bAllowPermanentOptOut); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnSetScreenConfiguration(bool bIsConsole); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnSetExitButtonText(struct FText NewButtonText); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnConsoleDisplayURLProvided(struct FText UniquePlayerURLText); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void AnimationsComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7c69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.EnableMultiFactorModal");
			return (class UClass*)ptr;
		};

};

class UReportablePlayerInfo : public UObject
{
	public:
	    char UnknownData0[0x60];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.ReportablePlayerInfo");
			return (class UClass*)ptr;
		};

};

class UFeedbackReportablePlayerBase : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    struct FString DebugName; // 0xb30 Size: 0x10
	    class UReportablePlayerInfo* PlayerInfo; // 0xb40 Size: 0x8
	    class UCommonTextBlock* TextBlock_Header; // 0xb48 Size: 0x8
	    class UCommonTextBlock* TextBlock_SecondaryInfoText; // 0xb50 Size: 0x8
	    class UHorizontalBox* HorizontalBox_SecondayInfoArea; // 0xb58 Size: 0x8
	    char UnknownData1[0xb60]; // 0xb60
	    void SetSelectionState(bool bIsSelected, bool bAnimateOnSelect); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7481];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FeedbackReportablePlayerBase");
			return (class UClass*)ptr;
		};

};

class UFeedbackReportPlayerBase : public UFortActivatablePanel
{
	public:
	    TArray<class UReportablePlayerInfo*> ReportablePlayers; // 0x340 Size: 0x10
	    TArray<class UPlayerReportReasonInfo*> ReportReasons; // 0x350 Size: 0x10
	    class UReportablePlayerInfo* SelectedPlayer; // 0x360 Size: 0x8
	    class UPlayerReportReasonInfo* SelectedReportReason; // 0x368 Size: 0x8
	    int OptionalReportReasonLength; // 0x370 Size: 0x4
	    int NumPlayerEntries; // 0x374 Size: 0x4
	    class UCommonButton* Button_Cancel; // 0x378 Size: 0x8
	    class UCommonButton* Button_Send; // 0x380 Size: 0x8
	    class UCommonButtonGroup* TabButtonGroup; // 0x388 Size: 0x8
	    char UnknownData0[0x8]; // 0x390
	    class UCommonListView* ListView_ReportablePlayers; // 0x398 Size: 0x8
	    class UCommonListView* ListView_ReportReasons; // 0x3a0 Size: 0x8
	    class UEditableText* EditableText_ReasonField; // 0x3a8 Size: 0x8
	    class UMultiLineEditableText* MultiLineEditableText_ReasonField; // 0x3b0 Size: 0x8
	    class UCommonTextBlock* Text_CharCount; // 0x3b8 Size: 0x8
	    char UnknownData1[0x3c0]; // 0x3c0
	    void OnPopulateView(EPlayerReportingStep CurrentStep); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnListViewSelectionMade(EPlayerReportingStep ReportingStep, struct FText SelectedText); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnFeedbackSentCallback(bool Succeeded); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleTabClicked(EPlayerReportingStep ClickedStep); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleMessageChanged(struct FText Text); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void HandleBackAction(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void DynamicHandleReportReasonSelected(class UObject* SelectedItem); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void DynamicHandlePlayerSelected(class UObject* SelectedItem); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void CloseDialog(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7c21];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FeedbackReportPlayerBase");
			return (class UClass*)ptr;
		};

};

class UPlayerReportReasonInfo : public UObject
{
	public:
	    char UnknownData0[0x48];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.PlayerReportReasonInfo");
			return (class UClass*)ptr;
		};

};

class UFeedbackReportPlayerReasonBase : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    class UPlayerReportReasonInfo* ReportReason; // 0xb30 Size: 0x8
	    class UCommonTextBlock* TextBlock_Header; // 0xb38 Size: 0x8
	    char UnknownData1[0xb40]; // 0xb40
	    void SetSelectionState(bool bIsSelected, bool bAnimateOnSelect); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-74a1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FeedbackReportPlayerReasonBase");
			return (class UClass*)ptr;
		};

};

class UFortAbilitiesPageTileBase : public UCommonButton
{
	public:
	    class UCommonWidgetSwitcher* SwitcherAbilityBindingSwitcher; // 0xb28 Size: 0x8
	    class UFortKeybindWidget* KeybindAbilityKeybind; // 0xb30 Size: 0x8
	    class UFortKeybindWidget* KeybindAbilityKeybindCombo1; // 0xb38 Size: 0x8
	    class UFortKeybindWidget* KeybindAbilityKeybindCombo2; // 0xb40 Size: 0x8
	    int QuickBarSlot; // 0xb48 Size: 0x4
	    char UnknownData0[0xb4c]; // 0xb4c
	    void UpdateGamepadKeyBindingText(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7491];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAbilitiesPageTileBase");
			return (class UClass*)ptr;
		};

};

class UFortAbilitySystemContext : public UBlueprintContextBase
{
	public:
	    void RemoveDelegatesFromWidget(class UWidget* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void RegisterForAttributeChanged(class UWidget* Widget, class UAbilitySystemComponent* ASC, struct FGameplayAttribute Attribute, __int64/*DelegateProperty*/ Callback); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool HasMatchingGameplayTag(struct FGameplayTag TagToCheck); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAbilitySystemContext");
			return (class UClass*)ptr;
		};

};

class UFortAccountLinkingWindow : public UFortActivatablePanel
{
	public:
	    char UnknownData0[0x70];
	    class UCommonWidgetSwitcher* Switcher_Main; // 0x3b0 Size: 0x8
	    class UBackgroundBlur* HaveEpicAccountBlur; // 0x3b8 Size: 0x8
	    class UBackgroundBlur* SkipSignInBlur; // 0x3c0 Size: 0x8
	    class UCommonWidgetSwitcher* Switcher_NoThanks; // 0x3c8 Size: 0x8
	    class UCircularThrobber* Throbber_LoginDelay; // 0x3d0 Size: 0x8
	    class UCommonButton* Button_Signup; // 0x3d8 Size: 0x8
	    class UCommonButton* Button_Login; // 0x3e0 Size: 0x8
	    class UCommonButton* Button_NoThanks; // 0x3e8 Size: 0x8
	    class UCommonButton* Button_SkipSignInSignup; // 0x3f0 Size: 0x8
	    class UCommonButton* Button_SkipSignInLogin; // 0x3f8 Size: 0x8
	    class UCommonButton* Button_SkipSignInNoThanks; // 0x400 Size: 0x8
	    char UnknownData1[0x408]; // 0x408
	    void HandleSkipSignUpClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HandleSkipNoThanksClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleSkipLoginClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleSignupClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleNoThanksClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void HandleLoginClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ FortNewPlatformReceipt__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7bd9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAccountLinkingWindow");
			return (class UClass*)ptr;
		};

};

class UFortAccountNotFound : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x10];
	    class URichTextBlock* Text_Desc; // 0x240 Size: 0x8
	    class UCommonButton* Button_Back; // 0x248 Size: 0x8
	    class UCommonButton* Button_Web; // 0x250 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAccountNotFound");
			return (class UClass*)ptr;
		};

};

class UFortOptionsTab : public UCommonUserWidget
{
	public:
	    MulticastDelegateProperty OnTabSettingChanged; // 0x230 Size: 0x10
	    MulticastDelegateProperty OnTabActivated; // 0x240 Size: 0x10
	    MulticastDelegateProperty OnTabDeactivated; // 0x250 Size: 0x10
	    class UCommonListView* TabListView; // 0x260 Size: 0x8
	    ESettingTab TabType; // 0x268 Size: 0x1
	    char UnknownData0[0x7]; // 0x269
	    TArray<class UFortSettingInfo*> TabSettingsData; // 0x270 Size: 0x10
	    char UnknownData1[0x280]; // 0x280
	    void UpdateOptionsTab(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void UpdateOptions(bool UpdateQuality); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool ShouldShowSetting(struct FSettingData SettingData); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void ResetOptionsToDefault(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool IsXboxPlatform(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool IsSwitchPlatform(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool IsPS4Platform(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool IsAthena(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void ConstructSettingList(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void CenterOnTab(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x-7d61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortOptionsTab");
			return (class UClass*)ptr;
		};

};

class UFortAccountOptions : public UFortOptionsTab
{
	public:
	    bool ShouldShowSamsungStore(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void SetRefundRequestText(int RefundsRemaining, int TotalRefunds, int DaysToRefund); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetPrivacySettings(struct FMcpPrivacySettings NewPrivacySettings); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetCanReceiveGifts(bool bInCanReceiveGifts); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SaveSettingsToMcp(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void LoadSamsungOptions(TArray<struct FText> OutOptions, int CurrentOptionIdx); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ChangeSamsungStoreSetting(int SettingIdx); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool CanLocalPlayerReceiveGifts(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7d59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAccountOptions");
			return (class UClass*)ptr;
		};

};

class UFortAccountStatsContext : public UBlueprintContextBase
{
	public:
	    bool CanShowAccountStats(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAccountStatsContext");
			return (class UClass*)ptr;
		};

};

class UFortAccountWidgetBase : public UCommonUserWidget
{
	public:
	    void OnAccountInfoChanged(struct FFortPublicAccountInfo Result); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void HandleCurrentlyViewedAccountInfoChanged(struct FFortPublicAccountInfo NewInfo); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    struct FAthenaSeasonBannerLevel GetSeasonBannerInfo(int Level); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool GetNextSeasonReward(struct FFortItemQuantityPair Reward, int RewardLevel); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool GetNextSeasonChaseReward(struct FFortItemQuantityPair Reward, int RewardLevel, int StartingLevel); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7d79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAccountWidgetBase");
			return (class UClass*)ptr;
		};

};

class UFortActivatableVideoPanel : public UFortActivatablePanel
{
	public:
	    MulticastDelegateProperty OnMediaPlayerEndReached; // 0x340 Size: 0x10
	    bool bAutoPlayOnActivated; // 0x350 Size: 0x1
	    bool bAllowSkipping; // 0x351 Size: 0x1
	    char UnknownData0[0x6]; // 0x352
	    class UFortVideoPlayerWidget* VideoPlayerWidget; // 0x358 Size: 0x8
	    class UCommonButton* Button_Skip; // 0x360 Size: 0x8
	    char UnknownData1[0x368]; // 0x368
	    bool StreamVideo(struct FString VideoURL); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool LoadVideoByIndex(int VideoIndex); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool LoadVideo(FName VideoID); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7c79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortActivatableVideoPanel");
			return (class UClass*)ptr;
		};

};

class UFortActorCanvas : public UPanelWidget
{
	public:
	    struct FGameplayTagContainer DefaultHUDElementTags; // 0x118 Size: 0x20
	    bool bDrawElementsInOrder; // 0x138 Size: 0x1
	    char UnknownData0[0x139]; // 0x139
	    void OnHUDElementVisibilityChanged(struct FGameplayTagContainer HiddenHUDElementTags); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    class UFortActorCanvasSlot* AddActorIndicator(class UFortActorIndicatorWidget* Indicator); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7e71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortActorCanvas");
			return (class UClass*)ptr;
		};

};

class UFortActorCanvasSlot : public UPanelSlot
{
	public:
	    char HorizontalAlignment; // 0x38 Size: 0x1
	    char VerticalAlignment; // 0x39 Size: 0x1
	    bool bCanAutoRemove; // 0x3a Size: 0x1
	    char UnknownData0[0x3b]; // 0x3b
	    void SetVerticalAlignment(char InVerticalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetHorizontalAlignment(char InHorizontalAlignment); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetCanAutoRemove(bool bAllowAutoRemove); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7f99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortActorCanvasSlot");
			return (class UClass*)ptr;
		};

};

class UFortAffiliateEntry : public UCommonButton
{
	public:
	    char UnknownData0[0x18];
	    class UCommonTextBlock* OptionDisplayName; // 0xb40 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAffiliateEntry");
			return (class UClass*)ptr;
		};

};

class UFortAffiliateEntryData : public UObject
{
	public:
	    struct FString AffiliateName; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAffiliateEntryData");
			return (class UClass*)ptr;
		};

};

class UFortAffilateModal : public UFortActivatablePanel
{
	public:
	    class UCommonButton* AcceptButton; // 0x340 Size: 0x8
	    class UEditableText* AffiliateKey; // 0x348 Size: 0x8
	    class UListView* AffiliateSuggestionList; // 0x350 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAffilateModal");
			return (class UClass*)ptr;
		};

};

class UFortAlterationButtonWidget : public UCommonButton
{
	public:
	    class UFortAlterationInfo* AlterationInfo; // 0xb28 Size: 0x8
	    char UnknownData0[0xb30]; // 0xb30
	    void Setup(class UFortAlterationInfo* InAlterationInfo); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnSetup(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    class UFortAlterationInfo* GetAlterationInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-74b1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAlterationButtonWidget");
			return (class UClass*)ptr;
		};

};

class UFortAlterationModOptinScreenBase : public UCommonActivatablePanel
{
	public:
	    class UFortItem* ItemToOptin; // 0x318 Size: 0x8
	    char UnknownData0[0x320]; // 0x320
	    void SetupItem(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void RequestClose(bool bCancelled); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnSetupItem(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnItemConversionComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void ConvertItemAlterations(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7cb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAlterationModOptinScreenBase");
			return (class UClass*)ptr;
		};

};

class UFortAlterationModScreenBase : public UFortActivatablePanel
{
	public:
	    class UFortAlterationsWidget* AlterationsToEdit; // 0x340 Size: 0x8
	    class UFortAlterationOptionsBase* AlterationSlotOptions; // 0x348 Size: 0x8
	    class UFortItemDetailsHostPanel* ItemInspectionMainItemDetailsHostPanel; // 0x350 Size: 0x8
	    class UFortItemDetailsHostPanel* AlterationsExtraDetailsPanel; // 0x358 Size: 0x8
	    class UFortAlterationModOptinScreenBase* AlterationModOptinScreenClass; // 0x360 Size: 0x8
	    struct FDataTableRowHandle BackInputAction; // 0x368 Size: 0x10
	    TWeakObjectPtr<UFortAlterableItem*> AlterableItem; // 0x378 Size: 0x8
	    class UFortAlterationOption* CurrentAlterationOptionInternal; // 0x380 Size: 0x8
	    char UnknownData0[0x388]; // 0x388
	    void SetItemForAlterationsModding(class UFortAlterableItem* InAlterableItem); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void RefreshItemAndAlterationsBP(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnItemSlotChanged(bool SelectedSlot); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnAlterationOptionChanged(class UFortAlterationOption* CurrentAlterationOption); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnAlterationModificationSucess(int ModifiedSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnAlterationModificationStarted(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnAlterationModificationCompleted(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void HandleBackAction(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void ConfirmSelection(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void CancelSelection(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    bool AreIngredientRequirementsMent(TArray<struct FFortItemQuantityPair> RequiredIngredients); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x-7c41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAlterationModScreenBase");
			return (class UClass*)ptr;
		};

};

class UFortAlterationOption : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    struct FAlterationOption AlterationOption; // 0xb30 Size: 0x38
	    char UnknownData1[0xb68]; // 0xb68
	    void Setup(struct FAlterationOption InAlterationOption, EFortAlterationOptionType InAlterationOptionType); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnSetup(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    TArray<struct FFortItemQuantityPair> GetRequiredIngredients(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    float GetNextPipCount(float MaxPipCount); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    float GetCurrentPipCount(float MaxPipCount); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    EFortAlterationOptionType GetAlterationOptionType(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    class UFortAlterationItemDefinition* GetAlterationDefinition(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7471];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAlterationOption");
			return (class UClass*)ptr;
		};

};

class UFortAlterationOptionsBase : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x10];
	    class UFortAlterationOption* AlterationOptionClass; // 0x240 Size: 0x8
	    class UCommonButtonGroup* AlterationOptionButtons; // 0x248 Size: 0x8
	    char UnknownData1[0x20]; // 0x250
	    class UFortAlterableItem* Item; // 0x270 Size: 0x8
	    int SlotIndex; // 0x278 Size: 0x4
	    bool bUpgradeOptionExists; // 0x27c Size: 0x1
	    char UnknownData2[0x3]; // 0x27d
	    struct FAlterationOption UpgradeOption; // 0x280 Size: 0x38
	    TArray<struct FAlterationOption> RespecOptions; // 0x2b8 Size: 0x10
	    char UnknownData3[0x2c8]; // 0x2c8
	    void ProcessAlterationOptions(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnItemChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnGenerateOption(EFortAlterationOptionType OptionType, class UFortAlterationOption* OptionWidget); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool IsValidAlterationSlot(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void HandleAlterationsOptionSelected(class UCommonButton* AlterationOptionButton, int GroupIndex); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void HandleAlterationsOptionHovered(class UCommonButton* AlterationOptionButton, int GroupIndex); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool DoAlterationOptionsExist(EFortAlterationOptionType OptionType); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7d09];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAlterationOptionsBase");
			return (class UClass*)ptr;
		};

};

class UFortAlterationInfo : public UObject
{
	public:
	    class UFortItem* CorrespondingItem; // 0x28 Size: 0x8
	    int SlotIndex; // 0x30 Size: 0x4
	    char UnknownData0[0x4]; // 0x34
	    class UFortAlterationItemDefinition* AlterationDef; // 0x38 Size: 0x8
	    int RequiredMinLevel; // 0x40 Size: 0x4
	    bool bIsUpgrade; // 0x44 Size: 0x1
	    char UnknownData1[0x3]; // 0x45
	    int CurrentItemLevel; // 0x48 Size: 0x4
	    bool bFreeAlterationSlot; // 0x4c Size: 0x1
	    bool bUnlockedByEvolution; // 0x4d Size: 0x1
	    char UnknownData2[0x4e]; // 0x4e
	    bool IsFreeAlterationChoice(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool IsAlterationUnlocked(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool IsAlterationHighlighted(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    int GetSlotIndex(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    int GetRequiredLevel(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    EFortRarity GetRarity(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    float GetCurrentPipCount(float MaxPips); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    class UFortItem* GetCorrespondingItem(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    class UFortAlterationItemDefinition* GetAlterationDefintion(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x-7f91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAlterationInfo");
			return (class UClass*)ptr;
		};

};

class UFortAlterationsWidget : public UCommonUserWidget
{
	public:
	    class UFortItem* Item; // 0x230 Size: 0x8
	    EFortAlterationWidgetState State; // 0x238 Size: 0x1
	    char UnknownData0[0x7]; // 0x239
	    class UFortItem* ItemToCompareWith; // 0x240 Size: 0x8
	    bool bUseButtons; // 0x248 Size: 0x1
	    char UnknownData1[0x37]; // 0x249
	    class UCommonTextBlock* EmptyText; // 0x280 Size: 0x8
	    class UCommonButtonGroup* ButtonGroup; // 0x288 Size: 0x8
	    char UnknownData2[0x290]; // 0x290
	    void SetupInteractionEvents(class UFortAlterationButtonWidget* Buttion); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetState(EFortAlterationWidgetState InState); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetItemToCompareWith(class UFortItem* InItem); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetItem(class UFortItem* InItem, bool bInPreviewNewAlterations, bool bIntroAlterations); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ProcessAlterations(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnStateChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnItemToCompareWithChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnItemChanged(bool bIntroAlterations); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnGenerateAlteration(class UFortAlterationInfo* AlterationInfo); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void OnFocusFirstItem(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void OnAlterationSlotIndexModifiedBP(int ModifiedIndex); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void HandleAlterationsSlotSelected(class UCommonButton* InAlterationButton, int SelectedIndex); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void HandleAlterationsSlotHovered(class UCommonButton* InAlterationButton, int SelectedIndex); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x-7d39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAlterationsWidget");
			return (class UClass*)ptr;
		};

};

class UFortAlterationWidget : public UCommonUserWidget
{
	public:
	    float MaxPipCount; // 0x230 Size: 0x4
	    char UnknownData0[0x4]; // 0x234
	    class UFortAlterationInfo* AlterationInfo; // 0x238 Size: 0x8
	    char UnknownData1[0x240]; // 0x240
	    void Setup(class UFortAlterationInfo* InAlterationInfo); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnSetup(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    class UFortAlterationInfo* GetAlterationInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7da1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAlterationWidget");
			return (class UClass*)ptr;
		};

};

class UFortAnnouncementWidget : public UCommonUserWidget
{
	public:
	    class AFortClientAnnouncement* BoundAnnouncement; // 0x230 Size: 0x8
	    char UnknownData0[0x238]; // 0x238
	    void UpdateWidgetData(class AFortClientAnnouncement* Announcement); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void BindUpdateEvents(class AFortClientAnnouncement* Announcement); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void AnnouncementStopped(class AFortClientAnnouncement* Announcement); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7da9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAnnouncementWidget");
			return (class UClass*)ptr;
		};

};

class UFortArmoryScreen : public UFortActivatablePanel
{
	public:
	    char UnknownData0[0x340];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortArmoryScreen");
			return (class UClass*)ptr;
		};

};

class UFortAsyncAction_CheckForStwMfaReward : public UBlueprintAsyncActionBase
{
	public:
	    MulticastDelegateProperty OnCompleted; // 0x30 Size: 0x10
	    MulticastDelegateProperty OnFailed; // 0x40 Size: 0x10
	    class AFortPlayerController* PlayerController; // 0x50 Size: 0x8
	    char UnknownData0[0x58]; // 0x58
	    static class UFortAsyncAction_CheckForStwMfaReward* CheckForStwMfaReward(class AFortPlayerController* PlayerController); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAsyncAction_CheckForStwMfaReward");
			return (class UClass*)ptr;
		};

};

class UFortAsyncAction_CreateWidgetAsync : public UBlueprintAsyncActionBase
{
	public:
	    MulticastDelegateProperty OnComplete; // 0x30 Size: 0x10
	    char UnknownData0[0x40]; // 0x40
	    static class UFortAsyncAction_CreateWidgetAsync* CreateWidgetAsync(class UObject* WorldContextObject, __int64/*SoftClassProperty*/ UserWidgetSoftClass, class APlayerController* OwningPlayer, bool bSuspendInputUntilComplete); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f49];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAsyncAction_CreateWidgetAsync");
			return (class UClass*)ptr;
		};

};

class UFortAsyncAction_LoadBannerAsset : public UBlueprintAsyncActionBase
{
	public:
	    MulticastDelegateProperty BannerAssetLoadComplete; // 0x30 Size: 0x10
	    char UnknownData0[0x40]; // 0x40
	    static class UFortAsyncAction_LoadBannerAsset* AsyncLoadBannerAsset(class UObject* WorldContextObject, struct TSoftObjectPtr<struct UObject*> AssetToLoad, class UMaterialInstanceDynamic* MIDRef, FName BannerColorName); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAsyncAction_LoadBannerAsset");
			return (class UClass*)ptr;
		};

};

class UFortAsyncAction_LoadCurrentSubgameProfiles : public UBlueprintAsyncActionBase
{
	public:
	    MulticastDelegateProperty OnSuccess; // 0x30 Size: 0x10
	    MulticastDelegateProperty OnFailure; // 0x40 Size: 0x10
	    class AFortPlayerController* PlayerController; // 0x50 Size: 0x8
	    char UnknownData0[0x58]; // 0x58
	    static class UFortAsyncAction_LoadCurrentSubgameProfiles* LoadCurrentSubgameProfiles(class AFortPlayerController* PlayerController); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAsyncAction_LoadCurrentSubgameProfiles");
			return (class UClass*)ptr;
		};

};

class UFortAsyncAction_SetUIState : public UBlueprintAsyncActionBase
{
	public:
	    MulticastDelegateProperty OnStateEntered; // 0x30 Size: 0x10
	    class UObject* WorldContextObject; // 0x40 Size: 0x8
	    char UnknownData0[0x48]; // 0x48
	    static class UFortAsyncAction_SetUIState* SetUIState(class UObject* InWorldContextObject, EFortUIState DesiredState); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAsyncAction_SetUIState");
			return (class UClass*)ptr;
		};

};

class UFortAsyncAction_ShowAdvancedLatentConfirmation_NUI : public UBlueprintAsyncActionBase
{
	public:
	    MulticastDelegateProperty DialogResult; // 0x30 Size: 0x10
	    class UObject* WorldContextObject; // 0x40 Size: 0x8
	    struct FFortDialogDescription_NUI Description; // 0x48 Size: 0x118
	    char UnknownData0[0x160]; // 0x160
	    static class UFortAsyncAction_ShowAdvancedLatentConfirmation_NUI* ShowAdvancedLatentActionConfirmation(class UObject* InWorldContextObject, struct FSlateBrush Icon, struct FText Title, struct FText MESSAGE, TArray<struct FConfirmationDialogAction> ConfirmButtonInputActions, FName DeclineButtonInputAction, class UWidget* AdditionalContent, class UWidget* LeftAdditionalContent); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7e81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAsyncAction_ShowAdvancedLatentConfirmation_NUI");
			return (class UClass*)ptr;
		};

};

class UFortAsyncAction_ShowConfirmation_NUI : public UBlueprintAsyncActionBase
{
	public:
	    MulticastDelegateProperty DialogResult; // 0x30 Size: 0x10
	    class UObject* WorldContextObject; // 0x40 Size: 0x8
	    struct FFortDialogDescription_NUI Description; // 0x48 Size: 0x118
	    char UnknownData0[0x160]; // 0x160
	    static class UFortAsyncAction_ShowConfirmation_NUI* ShowSimpleConfirmationDialog_NUI(class UObject* InWorldContextObject, struct FSlateBrush Icon, struct FText Title, struct FText MESSAGE, bool bShowConfirm, bool bShowDecline, class UWidget* AdditionalContent, class UWidget* LeftAdditionalContent); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static class UFortAsyncAction_ShowConfirmation_NUI* ShowSimpleConfirmationDialog_CustomInput(class UObject* InWorldContextObject, struct FSlateBrush Icon, struct FText Title, struct FText MESSAGE, FName ConfirmAction, FName DeclineAction, class UWidget* AdditionalContent, class UWidget* LeftAdditionalContent); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static class UFortAsyncAction_ShowConfirmation_NUI* ShowConfirmationDialog_NUI(class UObject* InWorldContextObject, struct FSlateBrush Icon, struct FText Title, struct FText MESSAGE, TArray<struct FConfirmationDialogAction> ConfirmButtonInputActions, FName DeclineButtonInputAction, class UWidget* AdditionalContent, class UWidget* LeftAdditionalContent); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7e79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAsyncAction_ShowConfirmation_NUI");
			return (class UClass*)ptr;
		};

};

class UFortAsyncAction_ShowPartyDialog : public UBlueprintAsyncActionBase
{
	public:
	    class UObject* WorldContextObject; // 0x30 Size: 0x8
	    struct FFortDialogDescription_NUI Description; // 0x38 Size: 0x118
	    struct FFortTeamMemberInfo TeamMemberInfo; // 0x150 Size: 0x200
	    class ULocalPlayer* LocalPlayer; // 0x350 Size: 0x8
	    char UnknownData0[0x358]; // 0x358
	    static class UFortAsyncAction_ShowPartyDialog* ShowPartyMemberManageDialog(class UObject* InWorldContextObject, struct FFortTeamMemberInfo TeamMemberInfo, class ULocalPlayer* LocalPlayer, class UUserWidget* LeftAdditionalContent); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static class UFortAsyncAction_ShowPartyDialog* ShowPartyLeaderManageDialog(class UObject* InWorldContextObject, struct FFortTeamMemberInfo TeamMemberInfo, class ULocalPlayer* LocalPlayer, class UUserWidget* LeftAdditionalContent); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7c89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAsyncAction_ShowPartyDialog");
			return (class UClass*)ptr;
		};

};

class UFortAthenaMatchmakingOptions : public UFortActivatablePanel
{
	public:
	    class UFortActivatablePanel* AthenaMatchmakingKnobsModalClass; // 0x340 Size: 0x8
	    char UnknownData0[0x10]; // 0x348
	    class UFortAthenaMatchmakingTile* TileItemClass; // 0x358 Size: 0x8
	    class UCommonButtonGroup* MatchmakingTileGroup; // 0x360 Size: 0x8
	    struct FAthenaPlaylistEntry RepresentedPlaylistCMSEntry; // 0x368 Size: 0x68
	    struct FPlaylistFrontEndData RepresentedPlaylist; // 0x3d0 Size: 0x10
	    char UnknownData1[0x8]; // 0x3e0
	    class UScrollBox* StandardGameModeBox; // 0x3e8 Size: 0x8
	    class UScrollBox* LTMGameModeBox; // 0x3f0 Size: 0x8
	    class UCommonButton* TeamFillButton; // 0x3f8 Size: 0x8
	    class UCommonButton* SpectateButton; // 0x400 Size: 0x8
	    class UCommonButton* Button_ServerPrivacy; // 0x408 Size: 0x8
	    class UCommonButton* MatchmakingKnobsButton; // 0x410 Size: 0x8
	    class UCommonTextBlock* MatchmakingWarningText; // 0x418 Size: 0x8
	    char UnknownData2[0x420]; // 0x420
	    void UpdateMMButtonStatusBP(bool bPlaylistIsEnabled, EFillDisableReason FillDisableReason); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetSquadFillText(ESquadFillSetting InSquadFillSetting); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetSpectatorButtonText(ESpectatorQueueType InSpectatorQueueType); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetServerAccessText(EServerAccessSetting InServerAccessSetting); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetOwningMatchmakingWidget(class UFortAthenaMatchmakingWidget* InOwningMatchmakingWidget); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetCustomMatchOptions(__int64/*MapProperty*/ Options, FName PlaylistName); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void RepresentedPlaylistChanged(struct FPlaylistFrontEndData NewRepresentedPlaylist); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnTileDoubleClicked(class UCommonButton* ButtonClicked); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void HandleInputTypeChanged(ECommonInputType CurrentInputType); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void HandleButtonGroupSelectionChanged(class UCommonButton* Button, int Index); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void CloseMatchmakingOptions(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void CanceledPlaylist(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void AcceptedPlaylist(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x-7bc1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAthenaMatchmakingOptions");
			return (class UClass*)ptr;
		};

};

class UFortAthenaMatchmakingTile : public UCommonButton
{
	public:
	    class UEpicCMSImage* GameModeImage; // 0xb28 Size: 0x8
	    class UCommonBorder* AdSpace; // 0xb30 Size: 0x8
	    class UCommonTextBlock* AdText; // 0xb38 Size: 0x8
	    class UCommonTextBlock* SpecialAdText; // 0xb40 Size: 0x8
	    class UCommonTextBlock* GameModeName; // 0xb48 Size: 0x8
	    class UCommonTextBlock* SubGameModeName; // 0xb50 Size: 0x8
	    int BorderDisplayStyle; // 0xb58 Size: 0x4
	    char UnknownData0[0x4]; // 0xb5c
	    struct FAthenaPlaylistEntry CMSPlaylistEntry; // 0xb60 Size: 0x68
	    struct FPlaylistFrontEndData TilePlaylistData; // 0xbc8 Size: 0x10
	    char UnknownData1[0xbd8]; // 0xbd8
	    void UpdateTileAvailability(bool Available); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void TilePlaylistSetAsMatchmakingPlaylist(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetTileSize(int NumRowTiles); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetDefaultImage(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void PopulateTextFieldsFromCMS(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void PlaylistChanged(struct FPlaylistFrontEndData PlaylistToRepresent); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnCMSDataUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7409];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAthenaMatchmakingTile");
			return (class UClass*)ptr;
		};

};

class UFortAthenaMatchmakingWidget : public UCommonUserWidget
{
	public:
	    class UFortMissionGenerator* DefaultMissionGen; // 0x230 Size: 0x8
	    FName CurrentPlaylistName; // 0x238 Size: 0x8
	    class UFortPlaylistAthena* CurrentPlaylistObj; // 0x240 Size: 0x8
	    bool bCurrentSquadFill; // 0x248 Size: 0x1
	    char UnknownData0[0x7]; // 0x249
	    class UFortActivatablePanel* CreativeOptionsModalClass; // 0x250 Size: 0x8
	    char UnknownData1[0x141]; // 0x258
	    EFortMatchmakingViolatorStyle NewModeStyleOverride; // 0x399 Size: 0x1
	    char UnknownData2[0x2]; // 0x39a
	    struct FGuid ShowdownEventId; // 0x39c Size: 0x10
	    char UnknownData3[0x4]; // 0x3ac
	    struct FString TournamentEventId; // 0x3b0 Size: 0x10
	    char UnknownData4[0x8]; // 0x3c0
	    class UCommonButton* PlayButton; // 0x3c8 Size: 0x8
	    class UCommonButton* CancelButton; // 0x3d0 Size: 0x8
	    class UCommonButton* StartMatchButton; // 0x3d8 Size: 0x8
	    class UCommonButton* MatchmakingModeButton; // 0x3e0 Size: 0x8
	    class UWidget* SpinnerAndTextContainer; // 0x3e8 Size: 0x8
	    class UCommonTextBlock* MatchmakingHeaderText; // 0x3f0 Size: 0x8
	    class UCommonTextBlock* MatchmakingMessageText; // 0x3f8 Size: 0x8
	    class UCommonBorder* NewModeBorder; // 0x400 Size: 0x8
	    class UCommonTextBlock* NewModeText; // 0x408 Size: 0x8
	    class UCommonTextBlock* TextBlock_PartySizeWarning; // 0x410 Size: 0x8
	    char UnknownData5[0x418]; // 0x418
	    void UpdateCustomViolatorText(struct FText ModeName, struct FText SubText); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ShowCreativeOptions(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetSquadFillText(bool InCurrentSquadFill); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void PlaylistChanged(struct FPlaylistFrontEndData NewPlaylist, struct FText PlaylistCMSOverrideName, EFortLobbyType LobbyType); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OpenCreativeOptions_NativizeMe(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnSetPlayButtonText(struct FText PlayButtonText); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void OnSetCancelButtonText(struct FText CancelButtonText); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void OnNewModeViolatorUpdated(bool bShouldShow); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void OnMatchmakingFinishedBlueprint(bool bSuccess); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void OnAvailablePlaylistsUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x-7bc9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAthenaMatchmakingWidget");
			return (class UClass*)ptr;
		};

};

class UFortAthenaNewsPanel : public UFortActivatablePanel
{
	public:
	    char UnknownData0[0x340];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAthenaNewsPanel");
			return (class UClass*)ptr;
		};

};

class UFortAthenaNewsTile : public UCommonUserWidget
{
	public:
	    class UEpicCMSImage* CMSImage_NewsImage; // 0x230 Size: 0x8
	    class UCommonTextBlock* Text_NewsTitle; // 0x238 Size: 0x8
	    class UCommonTextBlock* Text_NewsBody; // 0x240 Size: 0x8
	    class UCommonBorder* Border_AdSpace; // 0x248 Size: 0x8
	    class UCommonTextBlock* Text_AdSpace; // 0x250 Size: 0x8
	    char UnknownData0[0x258]; // 0x258
	    void SetDefaultImage(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void PlayIntroAnim(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAthenaNewsTile");
			return (class UClass*)ptr;
		};

};

class UFortAthenaNewsWidget : public UCommonUserWidget
{
	public:
	    class UFortAthenaNewsTile* NewsTileClass; // 0x230 Size: 0x8
	    class UFortAthenaNewsTile* SpotlightNewsTileClass; // 0x238 Size: 0x8
	    class UFortAthenaNewsTile* SpecialEventNewsTileClass; // 0x240 Size: 0x8
	    class UFortAthenaNewsTile* SpotlightSpecialEventNewsTileClass; // 0x248 Size: 0x8
	    TArray<class UFortAthenaNewsTile*> NewsTiles; // 0x250 Size: 0x10
	    class UCommonTextBlock* CommonText_NewsHeader; // 0x260 Size: 0x8
	    class UScrollBox* ScrollBox_NewsContainer; // 0x268 Size: 0x8
	    class UHorizontalBox* HorizontalBox_NewsContainer; // 0x270 Size: 0x8
	    class UVerticalBox* VerticalBox_SpotlightNewsContainer; // 0x278 Size: 0x8
	    char UnknownData0[0x280]; // 0x280
	    void SingleItemConfiguration(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void ResetViewConfiguration(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void PlayNewsTilesIntro(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void LogMotDLobbyNavAction(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void LogMotDCloseAction(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleNewsStyle(EAthenaNewsStyle NewsStyle); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7d61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAthenaNewsWidget");
			return (class UClass*)ptr;
		};

};

class UFortAthenaTabsScreenBase : public UFortActivatablePanel
{
	public:
	    __int64/*MapProperty*/ FeaturesTabsMap; // 0x340 Size: 0x50
	    class UFortTabListWidgetBase* TopTabList; // 0x390 Size: 0x8
	    char UnknownData0[0x398]; // 0x398
	    void ShowReplayBrowser(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetOnlineFriendsCount(int NewOnlineFriendsCount); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetActiveInvitesCount(int NewActiveInvitesCount); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleFeatureStateChanged(EFortUIFeature ChangedFeature, EFortUIFeatureState NewState, EFortUIFeatureStateReason Reason); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleFeatureNavigateRequest(EFortUIFeature Feature); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool CanShowSeasonShopTab(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool CanShowPrototypeTab(FName TabNameID); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7c39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAthenaTabsScreenBase");
			return (class UClass*)ptr;
		};

};

class UFortUserWidget : public UUserWidget
{
	public:
	    char UnknownData0[0x8];
	    bool bConsumePointerInput; // 0x230 Size: 0x1
	    char UnknownData1[0x231]; // 0x231
	    void AddStoreCheatMenu(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void AddGrantCheatMenu(struct FString TemplateId, struct FString InstanceId); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7da9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUserWidget");
			return (class UClass*)ptr;
		};

};

class UFortAttributeList : public UFortUserWidget
{
	public:
	    class UFortAttributeListItem* AttributeItemClass; // 0x238 Size: 0x8
	    bool bHoverEnabledOnElements; // 0x240 Size: 0x1
	    char UnknownData0[0x7]; // 0x241
	    class UVerticalBox* AttributeContainer; // 0x248 Size: 0x8
	    char UnknownData1[0x250]; // 0x250
	    void SetPreviewData(TArray<struct FFortDisplayAttribute> Data); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    TArray<struct FFortDisplayAttribute> SetData(TArray<struct FFortDisplayAttribute> Data); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void ClearPreviewData(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void Clear(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7d91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAttributeList");
			return (class UClass*)ptr;
		};

};

class UFortAttributeList_NUI : public UCommonUserWidget
{
	public:
	    class UFortAttributeListItem_NUI* AttributeItemClass; // 0x230 Size: 0x8
	    bool bHoverEnabledOnElements; // 0x238 Size: 0x1
	    char UnknownData0[0x7]; // 0x239
	    TArray<class UFortAttributeListItem_NUI*> ShownAttributeWidgets; // 0x240 Size: 0x10
	    char UnknownData1[0x250]; // 0x250
	    void SetPreviewData(TArray<struct FFortDisplayAttribute> Data); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetData(TArray<struct FFortDisplayAttribute> Data); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnRemoveShownAttributeListItem(class UFortAttributeListItem_NUI* AttributeListItemWidget, int AtIndex); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnClearShownAttributes(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnAddShownAttributeListItem(class UFortAttributeListItem_NUI* AttributeListItemWidget); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ClearPreviewData(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7d81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAttributeList_NUI");
			return (class UClass*)ptr;
		};

};

class UFortAttributeListItem : public UUserWidget
{
	public:
	    bool bHoverEnabled; // 0x228 Size: 0x1
	    char UnknownData0[0x229]; // 0x229
	    void ValueChanged(float Delta); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetPreviewAttribute(struct FFortDisplayAttribute InPreviewAttribute); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool SetDisplayAttribute(struct FFortDisplayAttribute InDisplayAttribute, struct FFortDisplayAttribute DeltaAttribute); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void PreviewStarted(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void PreviewEnded(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void GetDisplayPreviewCopy(struct FFortDisplayAttribute OutPreviewAttribute); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void GetDisplayAttributeCopy(struct FFortDisplayAttribute OutDisplayAttribute); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void GetCurrentAttributeCopy(struct FFortDisplayAttribute OutDisplayAttribute); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void DisplayAttributeChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void ClearPreview(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7cd1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAttributeListItem");
			return (class UClass*)ptr;
		};

};

class UFortAttributeListItem_NUI : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x8];
	    bool bHoverEnabled; // 0x238 Size: 0x1
	    char UnknownData1[0x3]; // 0x239
	    struct FGameplayTag StatTag; // 0x23c Size: 0x8
	    char UnknownData2[0x244]; // 0x244
	    void ValueChanged(float Delta); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetPreviewAttribute(struct FFortDisplayAttribute InPreviewAttribute); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetDisplayAttribute(struct FFortDisplayAttribute InDisplayAttribute); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void PreviewStarted(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void PreviewEnded(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool HasPreviewAttribute(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void GetDisplayPreviewCopy(struct FFortDisplayAttribute OutPreviewAttribute); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void GetDisplayAttributeCopy(struct FFortDisplayAttribute OutDisplayAttribute); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void GetCurrentAttributeCopy(struct FFortDisplayAttribute OutDisplayAttribute); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void DisplayAttributeChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void ClearPreview(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x-7cb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAttributeListItem_NUI");
			return (class UClass*)ptr;
		};

};

class UFortAutorunLockZone : public UBacchusHUDElement
{
	public:
	    bool bIsInZone; // 0x380 Size: 0x1
	    bool bIsAutorunLockEnabled; // 0x381 Size: 0x1
	    char UnknownData0[0x382]; // 0x382
	    void OnInZoneChanged(bool bNewIsInZone); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7c59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortAutorunLockZone");
			return (class UClass*)ptr;
		};

};

class UFortBangWrapperOld : public UContentWidget
{
	public:
	    char UnknownData0[0x8];
	    EFortBangSize Size; // 0x120 Size: 0x1
	    char UnknownData1[0x3]; // 0x121
	    struct FVector2D Offset; // 0x124 Size: 0x8
	    EFortBangType BangType; // 0x12c Size: 0x1
	    char UnknownData2[0x3]; // 0x12d
	    FName TutorialNameID; // 0x130 Size: 0x8
	    EFortTutorialGlowType TutorialGlowType; // 0x138 Size: 0x1
	    char UnknownData3[0x139]; // 0x139
	    void SetBangVisibility(bool InVisible); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7e89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortBangWrapperOld");
			return (class UClass*)ptr;
		};

};

class UFortBangWrapper_NUI : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x8];
	    EFortBangType BangType; // 0x238 Size: 0x1
	    char UnknownData1[0x3]; // 0x239
	    FName TutorialNameID; // 0x23c Size: 0x8
	    char UnknownData2[0x4]; // 0x244
	    class UNamedSlot* ContentSlot; // 0x248 Size: 0x8
	    char UnknownData3[0x250]; // 0x250
	    void UnregisterTutorialNameID(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetTutorialNameID(FName InTutorialNameID); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetBangType(EFortBangType NewBangType); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetBangStateBP(bool bEnabled, int Count); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnTutorialCalloutFinished(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnStopCallout(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnStartCallout(FName TutorialObjectiveName, ETutorialType TutorialType); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnBangStateChanged(bool bEnabled, int Count); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x-7d91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortBangWrapper_NUI");
			return (class UClass*)ptr;
		};

};

class UFortBangWrapperContentButton : public UCommonButton
{
	public:
	    void FinishTutorialCallout(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-74a1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortBangWrapperContentButton");
			return (class UClass*)ptr;
		};

};

class UFortBangWrapperContentInterface : public UInterface
{
	public:
	    void OnStopCallout(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void OnStartCallout(FName TutorialObjectiveName, ETutorialType TutorialType); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnBangStateChanged(bool bEnabled, int Count); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortBangWrapperContentInterface");
			return (class UClass*)ptr;
		};

};

class UFortBangWrapperContentWidget : public UCommonUserWidget
{
	public:
	    void FinishTutorialCallout(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7d99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortBangWrapperContentWidget");
			return (class UClass*)ptr;
		};

};

class UFortBannerSelectorBase : public UCommonActivatablePanel
{
	public:
	    class UEditableText* BannerName; // 0x318 Size: 0x8
	    int BannerNameMaxLength; // 0x320 Size: 0x4
	    char UnknownData0[0x4]; // 0x324
	    class UBorder* ErrorBorder; // 0x328 Size: 0x8
	    class UCommonTextBlock* ErrorText; // 0x330 Size: 0x8
	    bool bFilterHomeBaseNameWithOSS; // 0x338 Size: 0x1
	    char UnknownData1[0x339]; // 0x339
	    void UpdateErrorText(struct FText ErrorMessageText); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnHomebaseNameCommitSucceeded(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnHomebaseNameCommitFailed(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void IsPlayerNameValid(struct FText PlayerName, bool OutIsValid, struct FText OutErrorText); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool HasIllegalChars(struct FString NewBannerName); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void HandleBannerNameChanged(struct FText Text); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void CompleteHomebaseName(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void CompleteHomebaseBannerSelection(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7c59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortBannerSelectorBase");
			return (class UClass*)ptr;
		};

};

class UFortButtonStyle : public UObject
{
	public:
	    struct FFortStateStyle NormalBase; // 0x28 Size: 0x350
	    struct FFortStateStyle NormalHovered; // 0x378 Size: 0x350
	    struct FFortStateStyle NormalPressed; // 0x6c8 Size: 0x350
	    struct FFortStateStyle SelectedBase; // 0xa18 Size: 0x350
	    struct FFortStateStyle SelectedHovered; // 0xd68 Size: 0x350
	    struct FFortStateStyle SelectedPressed; // 0x10b8 Size: 0x350
	    struct FFortStateStyle Disabled; // 0x1408 Size: 0x350
	    struct FFortMultiSizeMargin ButtonPadding; // 0x1758 Size: 0x60
	    struct FFortMultiSizeFont Font; // 0x17b8 Size: 0x1e0
	    struct FFortMultiSizeMargin CustomPadding; // 0x1998 Size: 0x60
	    struct FSlateSound PressedSlateSound; // 0x19f8 Size: 0x18
	    struct FSlateSound HoveredSlateSound; // 0x1a10 Size: 0x18
	    char UnknownData0[0x1a28]; // 0x1a28
	    static struct FMargin GetMarginBySizeFromMultiSizeMargin(struct FFortMultiSizeMargin MultiSizeMargin, char Size); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static struct FSlateFontInfo GetFontBySizeFromMultiSizeFont(struct FFortMultiSizeFont MultiSizeFont, char Size); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    struct FSlateFontInfo GetFontBySize(char Size); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    struct FMargin GetCustomPaddingBySize(char Size); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    struct FMargin GetButtonPaddingBySize(char Size); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static struct FSlateBrush GetBrushBySizeFromMultiSizeBrush(struct FFortMultiSizeBrush MultiSizeBrush, char Size); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-65b9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortButtonStyle");
			return (class UClass*)ptr;
		};

};

class UFortBaseButton : public UFortUserWidget
{
	public:
	    char UnknownData0[0x8];
	    MulticastDelegateProperty EnabledChanged; // 0x240 Size: 0x10
	    MulticastDelegateProperty SelectedChanged; // 0x250 Size: 0x10
	    MulticastDelegateProperty ButtonClicked; // 0x260 Size: 0x10
	    EFortBangSize BangSize; // 0x270 Size: 0x1
	    char UnknownData1[0x3]; // 0x271
	    struct FVector2D BangOffset; // 0x274 Size: 0x8
	    EFortBangType BangType; // 0x27c Size: 0x1
	    char UnknownData2[0x3]; // 0x27d
	    FName TutorialNameID; // 0x280 Size: 0x8
	    EFortTutorialGlowType TutorialGlowType; // 0x288 Size: 0x1
	    char UnknownData3[0x7]; // 0x289
	    class UFortButtonStyle* Style; // 0x290 Size: 0x8
	    char BrushSize; // 0x298 Size: 0x1
	    char UnknownData4[0x7]; // 0x299
	    struct FSlateSound PressedSlateSoundOverride; // 0x2a0 Size: 0x18
	    struct FSlateSound HoveredSlateSoundOverride; // 0x2b8 Size: 0x18
	    bool bSelectable; // 0x2d0 Size: 0x1
	    char UnknownData5[0x3]; // 0x2d1
	    FName SelectionGroup; // 0x2d4 Size: 0x8
	    bool bToggleable; // 0x2dc Size: 0x1
	    bool bClickable; // 0x2dd Size: 0x1
	    char ClickMethod; // 0x2de Size: 0x1
	    char UnknownData6[0x2df]; // 0x2df
	    void SetStyle(class UFortButtonStyle* InStyle); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetSelectionGroup(FName InSelectionGroup); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetSelected(bool InSelected); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetHovered(bool InHovered); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetClickMethod(char InClickMethod); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetClickable(bool InClickable); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetBrushSize(char InSize); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void SetBangVisibility(bool bVisible); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void OnButtonClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    class UFortButtonStyle* GetStyle(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    int GetSelectionGroupIndex(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    bool GetSelected(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    struct FFortStateStyle GetCurrentStateStyle(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    struct FSlateFontInfo GetCurrentFont(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    struct FMargin GetCurrentCustomPadding(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    struct FMargin GetCurrentButtonPadding(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void ForceClick(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x-77e9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortBaseButton");
			return (class UClass*)ptr;
		};

};

class UFortBluGloCounter : public UFortUserWidget
{
	public:
	    void OnBluGloQuantityChanged(int Quantity); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7da1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortBluGloCounter");
			return (class UClass*)ptr;
		};

};

class UFortBorderStyleList : public UCommonUserWidget
{
	public:
	    FName BordersPath; // 0x230 Size: 0x8
	    char UnknownData0[0x238]; // 0x238
	    TArray<__int64/*SoftClassProperty*/> GetBorderStyles(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7da9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortBorderStyleList");
			return (class UClass*)ptr;
		};

};

class UFortBuildingInfoIndicatorWidget : public UFortActorIndicatorWidget
{
	public:
	    void SetKeyBindWidgetBoundAction(class UFortKeybindWidget* FortKeybindWidget, FName ActionName, EFortBuildingInteraction InteractionType); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7d51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortBuildingInfoIndicatorWidget");
			return (class UClass*)ptr;
		};

};

class UFortButtonInternalWidget : public UButton
{
	public:
	    bool IsClickable; // 0x420 Size: 0x1
	    char UnknownData0[0x17];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortButtonInternalWidget");
			return (class UClass*)ptr;
		};

};

class UFortCampaignMap : public UCommonUserWidget
{
	public:
	    struct FFortSwipeDetector SwipeDetector; // 0x230 Size: 0x70
	    char UnknownData0[0x2a0]; // 0x2a0
	    void OnSwipeRight(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnSwipeLeft(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnShowPreviousPage(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnShowNextPage(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7d41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCampaignMap");
			return (class UClass*)ptr;
		};

};

class UFortCampaignTeamMemberStatEntry : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x18];
	    class UCommonTextBlock* Text_StatValue; // 0x248 Size: 0x8
	    class UCommonTextBlock* Text_BaseStatValue; // 0x250 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCampaignTeamMemberStatEntry");
			return (class UClass*)ptr;
		};

};

class UFortCampaignTeamMemberEntry : public UFortBasicTeamMemberEntry
{
	public:
	    class UDynamicEntryBox* EntryBox_MemberStats; // 0x268 Size: 0x8
	    char UnknownData0[0x270]; // 0x270
	    void OnPlayerAttributesChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7d71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCampaignTeamMemberEntry");
			return (class UClass*)ptr;
		};

};

class UFortCapturePointWidget : public UFortUserWidget
{
	public:
	    void OnCapturePointDataChanged(bool bActivated, bool bLocked, float CapturePercentage, char CaptureState, char ControllingTeam); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7d99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCapturePointWidget");
			return (class UClass*)ptr;
		};

};

class UFortChatContainer : public USocialChatContainer
{
	public:
	    char UnknownData0[0x18];
	    TWeakObjectPtr<USocialChatChannel*> CacheChannelForPlatformMessage; // 0x298 Size: 0x8
	    char UnknownData1[0x8]; // 0x2a0
	    class USocialChatChannel* CombinedChannel; // 0x2a8 Size: 0x8
	    class UFortSocialInteractionMenu* ActionMenuClass; // 0x2b0 Size: 0x8
	    class UFortSocialInteractionMenu* ActionMenu; // 0x2b8 Size: 0x8
	    class UMenuAnchor* MenuAnchor_MessageActions; // 0x2c0 Size: 0x8
	    char UnknownData2[0x2c8]; // 0x2c8
	    void OnSendButtonDisplayChanged(bool bShowSendButton); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    class UWidget* HandleGetMenuContentForAnchor(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7d19];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortChatContainer");
			return (class UClass*)ptr;
		};

};

class UFortChatMessageEntry : public USocialChatMessageEntry
{
	public:
	    void OnFocusedChanged(bool bIsFocused); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7c51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortChatMessageEntry");
			return (class UClass*)ptr;
		};

};

class UFortChatPanel : public UFortActivatablePanel
{
	public:
	    char UnknownData0[0x8];
	    class UFortChatContainer* ChatContainer; // 0x348 Size: 0x8
	    char UnknownData1[0x350]; // 0x350
	    void OnWidgetIsOnFocusedPathChanged(bool bOnFocusPath); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7c91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortChatPanel");
			return (class UClass*)ptr;
		};

};

class UFortChatWidget : public UNativeWidgetHost
{
	public:
	    bool MinimizeEnabled; // 0x110 Size: 0x1
	    bool AutoReleaseFocus; // 0x111 Size: 0x1
	    bool AllowEmotes; // 0x112 Size: 0x1
	    char UnknownData0[0x1]; // 0x113
	    float ListFadeTime; // 0x114 Size: 0x4
	    int MinimizedChatMessageNum; // 0x118 Size: 0x4
	    bool ThrottleChat; // 0x11c Size: 0x1
	    char UnknownData1[0x3]; // 0x11d
	    float ThrottleTicketTime; // 0x120 Size: 0x4
	    int ThrottleTicketCount; // 0x124 Size: 0x4
	    MulticastDelegateProperty OnChatEnteredEvent; // 0x128 Size: 0x10
	    MulticastDelegateProperty OnUserListChanged; // 0x138 Size: 0x10
	    char UnknownData2[0x148]; // 0x148
	    void SetControllerActionBrush(struct FSlateBrush SlateBrush); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void MinimizeChatWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void FocusChatEntry(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7e89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortChatWidget");
			return (class UClass*)ptr;
		};

};

class UFortCheatMenuFactory : public UObject
{
	public:
	    static void AddStoreCheatMenu(class UCommonUserWidget* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void AddGrantCheatMenu(class UCommonUserWidget* Widget, struct FString TemplateId, struct FString InstanceId); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCheatMenuFactory");
			return (class UClass*)ptr;
		};

};

class UFortCMSInfoCarousel : public UFortActivatablePanel
{
	public:
	    __int64/*MapProperty*/ MessageWidgetLayoutMap; // 0x340 Size: 0x50
	    class UCommonWidgetCarousel* Carousel; // 0x390 Size: 0x8
	    class UCommonWidgetCarouselNavBar* CarouselNavBar; // 0x398 Size: 0x8
	    struct FString CMSInfoId; // 0x3a0 Size: 0x10
	    float AutoScrollInterval; // 0x3b0 Size: 0x4
	    char UnknownData0[0x3b4]; // 0x3b4
	    void NavigatePageRight(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void NavigatePageLeft(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7c19];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCMSInfoCarousel");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookGenericRewardWidget : public UCommonUserWidget
{
	public:
	    bool bUpdateVisibilityBasedOnRewardExistence; // 0x230 Size: 0x1
	    char UnknownData0[0x3]; // 0x231
	    ESlateVisibility VisibilityWhenNoRewardSpecified; // 0x234 Size: 0x1
	    ESlateVisibility VisibilityWhenRewardSpecified; // 0x235 Size: 0x1
	    char UnknownData1[0x2]; // 0x236
	    class UFortCollectionBookRewardCardWidget* RewardCardWidget; // 0x238 Size: 0x8
	    ECollectionBookRewardStatus RewardStatus; // 0x240 Size: 0x1
	    char UnknownData2[0x241]; // 0x241
	    void SetRewardStatus(ECollectionBookRewardStatus Status); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetRewards(struct FFortRewardInfo Rewards); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetCurrentItemToDisplay(class UFortItem* ItemToDisplay); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnRewardStatusChanged(ECollectionBookRewardStatus NewStatus); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool HasRewards(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    ECollectionBookRewardStatus GetRewardStatus(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void ClearRewards(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7d99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookGenericRewardWidget");
			return (class UClass*)ptr;
		};

};

class UFortPopupMenu : public UCommonPopupMenu
{
	public:
	    char UnknownData0[0x338];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPopupMenu");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookItemPopupMenu : public UFortPopupMenu
{
	public:
	    void HandleItemUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void HandleItemChanged(bool bItemChanged, bool bAmmoChanged, bool bIngredientsChanged); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    class UFortCollectionBookSlotButton* GetHostButton(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool CanItemBeUnslotted(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool CanItemBePurchased(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7ca1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookItemPopupMenu");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookOverviewWidget : public UCommonUserWidget
{
	public:
	    MulticastDelegateProperty OnCollectionBookPageSelected; // 0x230 Size: 0x10
	    MulticastDelegateProperty OnCollectionBookPageClicked; // 0x240 Size: 0x10
	    class UFortCollectionBookPage* LastSelectedPage; // 0x250 Size: 0x8
	    class UFortCollectionBookCategory* LastSelectedCategory; // 0x258 Size: 0x8
	    TArray<class UFortCollectionBookCategory*> CategoryObjectPool; // 0x260 Size: 0x10
	    class UCommonTreeView* PageTreeViewWidget; // 0x270 Size: 0x8
	    char UnknownData0[0x278]; // 0x278
	    void OnDeactivated(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnActivated(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookOverviewWidget");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookPageCompletionRewardWidget : public UFortCollectionBookGenericRewardWidget
{
	public:
	    char UnknownData0[0x248];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookPageCompletionRewardWidget");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookPageDetailsWidget : public UCommonUserWidget
{
	public:
	    class UCommonTextBlock* PageCompletionText; // 0x230 Size: 0x8
	    class UFortMaterialProgressBar* ProgressBar; // 0x238 Size: 0x8
	    class UFortCollectionBookPageCompletionRewardWidget* PageRewardWidget; // 0x240 Size: 0x8
	    class UCommonButton* RewardDetailsButton; // 0x248 Size: 0x8
	    class UFortCollectionBookPage* DetailsPage; // 0x250 Size: 0x8
	    __int64/*SoftClassProperty*/ RewardDetailsModalWidgetClass; // 0x258 Size: 0x28
	    struct FText ModalTitle; // 0x280 Size: 0x18
	    class UFortCollectionBookRewardModalWidget* RewardDetailsModalWidget; // 0x298 Size: 0x8
	    char UnknownData0[0x2a0]; // 0x2a0
	    void OnSlotItemComplete(class UFortAccountItem* SlottedItem, FName SlotId); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnPageProgressionUpdated(int TotalFilledSlots, int TotalSlots, EFortCollectionBookState State); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnDetailsPageChanged(class UFortCollectionBookPage* InNewDetailsPage); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleRewardDetailsModalWidgetDeactivated(class UCommonActivatablePanel* DeactivatedPanel); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7d41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookPageDetailsWidget");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookPageListWidget : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    class UCommonTextBlock* PageNameWidget; // 0xb30 Size: 0x8
	    class UCommonNumericTextBlock* AvailableSlotsWidget; // 0xb38 Size: 0x8
	    class UCommonTextBlock* PageCompletionWidget; // 0xb40 Size: 0x8
	    TWeakObjectPtr<UObject*> AssociatedPageOrCategory; // 0xb48 Size: 0x8
	    bool bIsExpanded; // 0xb50 Size: 0x1
	    char UnknownData1[0xb51]; // 0xb51
	    void SetupAsPage(class UFortCollectionBookPage* Page); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetupAsCategory(class UFortCollectionBookCategory* Category); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnSlotItemComplete(class UFortAccountItem* SlottedItem, FName SlotId); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnPageDetailsUpdated(int AvailableSlots, int FilledSlots, int TotalSlots, EFortCollectionBookState State); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnCategoryDetailsUpdated(int AvailableSlots, int FilledSlots, int TotalSlots); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7489];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookPageListWidget");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookPicker : public UFortItemPickerBase
{
	public:
	    MulticastDelegateProperty OnSlotItemConfirmationCompleteEvent; // 0x2e8 Size: 0x10
	    char UnknownData0[0x8]; // 0x2f8
	    class UFortAccountItem* CurrentSlottedItem; // 0x300 Size: 0x8
	    char UnknownData1[0x308]; // 0x308
	    void SlotItemConfirmationComplete(class UFortItem* CommittedItem, struct FFortDialogExternalLatentActionHandle LatentActionHandle); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnSlotItemConfirmed__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    class UFortAccountItem* GetCurrentSlottedItem(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7cd9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookPicker");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookPrimaryPanel : public UCommonActivatablePanel
{
	public:
	    MulticastDelegateProperty OnCollectionBookPageSelectedDelegate; // 0x318 Size: 0x10
	    MulticastDelegateProperty OnCollectionBookPageClickedDelegate; // 0x328 Size: 0x10
	    MulticastDelegateProperty OnCollectionBookSectionClickedDelegate; // 0x338 Size: 0x10
	    struct FDataTableRowHandle BackActionRowHandle; // 0x348 Size: 0x10
	    struct FDataTableRowHandle SummonInfoPanelActionRowHandle; // 0x358 Size: 0x10
	    class UFortCollectionBookOverviewWidget* OverviewWidget; // 0x368 Size: 0x8
	    class UCommonTileView* SectionTileViewWidget; // 0x370 Size: 0x8
	    ECollectionBookPrimaryNavTarget CurrentNavTarget; // 0x378 Size: 0x1
	    char UnknownData0[0x7]; // 0x379
	    class UFortCollectionBookSection* LastClickedSection; // 0x380 Size: 0x8
	    char UnknownData1[0x388]; // 0x388
	    void OnSummonInfoPanelExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnInputMethodChanged(ECommonInputType CurrentInputType); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnCollectionBookSectionClicked(class UFortCollectionBookSection* ClickedSection); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnCollectionBookPageSelected(class UFortCollectionBookPage* SelectedPage); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnCollectionBookPageClicked(class UFortCollectionBookPage* ClickedPage); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnBackActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7c09];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookPrimaryPanel");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookProgressionRewardDetailInspectWidget : public UCommonUserWidget
{
	public:
	    class UCommonNumericTextBlock* LevelTextWidget; // 0x230 Size: 0x8
	    class UFortRewardInfoWidget* RewardWidget; // 0x238 Size: 0x8
	    char UnknownData0[0x240]; // 0x240
	    void SetAssociatedLevel(int Level); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnXPRequiredChanged(int NewXPRequired); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    int GetXPRequired(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookProgressionRewardDetailInspectWidget");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookProgressionRewardsModalWidget : public UFortActivatablePanel
{
	public:
	    __int64/*SoftClassProperty*/ RewardWidgetClass; // 0x340 Size: 0x28
	    struct FMargin RewardWidgetPadding; // 0x368 Size: 0x10
	    int NumRewardsToShow; // 0x378 Size: 0x4
	    char UnknownData0[0x4]; // 0x37c
	    class UVerticalBox* RewardBoxWidget; // 0x380 Size: 0x8
	    class UVerticalBox* MajorRewardBoxWidget; // 0x388 Size: 0x8
	    class UCommonTextBlock* XPTextWidget; // 0x390 Size: 0x8
	    class UCommonNumericTextBlock* LevelTextWidget; // 0x398 Size: 0x8
	    class UCommonButtonGroup* ButtonGroup; // 0x3a0 Size: 0x8
	    char UnknownData1[0x3a8]; // 0x3a8
	    void OnSelectedButtonChanged(class UCommonButton* SelectedButton, int ButtonIndex); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnLevelProgressionSet(int CurrentLevel, float NextLvlPct); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnInputMethodChanged(bool bUsingGamepad); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void InspectItemBP(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7c39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookProgressionRewardsModalWidget");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookProgressionRewardsPreviewWidget : public UCommonUserWidget
{
	public:
	    class UFortCollectionBookProgressionRewardWidget* NextRewardWidget; // 0x230 Size: 0x8
	    class UFortCollectionBookProgressionRewardWidget* NextMajorRewardWidget; // 0x238 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookProgressionRewardsPreviewWidget");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookProgressionRewardWidget : public UFortCollectionBookGenericRewardWidget
{
	public:
	    class UCommonNumericTextBlock* LevelTextWidget; // 0x248 Size: 0x8
	    class UCommonTextBlock* DisplayNameWidget; // 0x250 Size: 0x8
	    char UnknownData0[0x258]; // 0x258
	    void SetAssociatedLevel(int Level); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7d89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookProgressionRewardWidget");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookProgressWidget : public UCommonUserWidget
{
	public:
	    int CachedXPLevel; // 0x230 Size: 0x4
	    float CachedXPCompletionPct; // 0x234 Size: 0x4
	    __int64/*SoftClassProperty*/ RewardDetailsModalWidgetClass; // 0x238 Size: 0x28
	    class UFortCollectionBookProgressionRewardsPreviewWidget* ProgressionRewardsPreviewWidget; // 0x260 Size: 0x8
	    class UCommonTextBlock* XPTextWidget; // 0x268 Size: 0x8
	    class UCommonNumericTextBlock* LevelTextWidget; // 0x270 Size: 0x8
	    class UCommonButton* DetailsButtonWidget; // 0x278 Size: 0x8
	    class UFortCollectionBookPageDetailsWidget* PageDetailsWidget; // 0x280 Size: 0x8
	    class UFortCollectionBookProgressionRewardsModalWidget* DetailsModalWidget; // 0x288 Size: 0x8
	    char UnknownData0[0x290]; // 0x290
	    void OnSlottedItemOperationComplete(class UFortAccountItem* ItemSlotted, FName SlotId); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnCollectionBookPreviewXPChange(float PreviewCompletionPct); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnCollectionBookPageSelected(class UFortCollectionBookPage* SelectedPage); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnCollectionBookLevelProgressionChanged(float NewCompletionPct); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnCollectionBookLevelChanged(int NewLevel); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleDetailsModalWidgetDeactivated(class UCommonActivatablePanel* DeactivatedPanel); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7d51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookProgressWidget");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookRecycleSlotResultsWidget : public UCommonUserWidget
{
	public:
	    class UPanelWidget* RecycleResultsWidget; // 0x230 Size: 0x8
	    EFortItemCardSize ItemCardSize; // 0x238 Size: 0x1
	    char UnknownData0[0x7]; // 0x239
	    class UFortAccountItem* ItemToRecycle; // 0x240 Size: 0x8
	    char UnknownData1[0x248]; // 0x248
	    void SetCurrentItemToRecycle(class UFortAccountItem* InItemToRecycle); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookRecycleSlotResultsWidget");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookRewardCardWidget : public UCommonUserWidget
{
	public:
	    MulticastDelegateProperty OnDisplayedItemChangedEvent; // 0x230 Size: 0x10
	    class UFortMultiSizeItemCard* ItemCardWidget; // 0x240 Size: 0x8
	    class UWidget* MultiItemRewardOverlay; // 0x248 Size: 0x8
	    class UWidget* ChoiceRewardOverlay; // 0x250 Size: 0x8
	    float UpdateCardInterval; // 0x258 Size: 0x4
	    EFortItemCardSize ItemCardSize; // 0x25c Size: 0x1
	    bool bDisplayAsRewardCard; // 0x25d Size: 0x1
	    char UnknownData0[0x2]; // 0x25e
	    struct FFortRewardInfo RepresentedRewards; // 0x260 Size: 0x30
	    TArray<class UFortItem*> DummyItems; // 0x290 Size: 0x10
	    struct FTimerHandle UpdateCardTimer; // 0x2a0 Size: 0x8
	    char UnknownData1[0x2a8]; // 0x2a8
	    void SetRewards(struct FFortRewardInfo Rewards); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnDisplayedItemChangedEvent__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool HasRewards(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void ClearRewards(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7d31];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookRewardCardWidget");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookRewardModalWidget : public UCommonActivatablePanel
{
	public:
	    class UCommonTextBlock* TitleWidget; // 0x318 Size: 0x8
	    class UFortRewardInfoWidget* RewardWidget; // 0x320 Size: 0x8
	    class UFortMaterialProgressBar* ProgressBar; // 0x328 Size: 0x8
	    class UCommonTextBlock* ProgressTextWidget; // 0x330 Size: 0x8
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookRewardModalWidget");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookSectionCompletionRewardWidget : public UFortCollectionBookGenericRewardWidget
{
	public:
	    class UCommonButton* RewardDetailsButton; // 0x248 Size: 0x8
	    __int64/*SoftClassProperty*/ RewardDetailsModalWidgetClass; // 0x250 Size: 0x28
	    struct FText ModalTitle; // 0x278 Size: 0x18
	    class UFortCollectionBookRewardModalWidget* RewardDetailsModalWidget; // 0x290 Size: 0x8
	    class UFortCollectionBookSection* Section; // 0x298 Size: 0x8
	    char UnknownData0[0x2a0]; // 0x2a0
	    void HandleRewardDetailsModalWidgetDeactivated(class UCommonActivatablePanel* DeactivatedPanel); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7d41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookSectionCompletionRewardWidget");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookSectionPanel : public UCommonActivatablePanel
{
	public:
	    MulticastDelegateProperty OnSectionCloseRequest; // 0x318 Size: 0x10
	    MulticastDelegateProperty OnPreviewXPChangeEvent; // 0x328 Size: 0x10
	    class UCommonTextBlock* SectionNameTextWidget; // 0x338 Size: 0x8
	    class UFortCollectionBookSlotView* SlotViewWidget; // 0x340 Size: 0x8
	    class UFortCollectionBookPicker* SlotItemPicker; // 0x348 Size: 0x8
	    class UWidget* ContextOverlayWidget; // 0x350 Size: 0x8
	    class UTextBlock* ContextTextWidget; // 0x358 Size: 0x8
	    class UFortCollectionBookSectionCompletionRewardWidget* SectionRewardWidget; // 0x360 Size: 0x8
	    class UWidget* ItemAcquisitionSourceContainerWidget; // 0x368 Size: 0x8
	    class UCommonTextBlock* ItemAcquisitionSourceDescWidget; // 0x370 Size: 0x8
	    class UCommonTextBlock* ItemAcquisitionSourceDesc2Widget; // 0x378 Size: 0x8
	    class UWidget* ResearchRecruitUnslotContainerWidget; // 0x380 Size: 0x8
	    class UCommonTextBlock* PersonRecruitUnavailableMessageWidget; // 0x388 Size: 0x8
	    class UCommonTextBlock* ItemResearchUnavailableMessageWidget; // 0x390 Size: 0x8
	    class UCommonTextBlock* UnslotUnavailableMessageWidget; // 0x398 Size: 0x8
	    struct FDataTableRowHandle BackActionRowHandle; // 0x3a0 Size: 0x10
	    struct FDataTableRowHandle CloseActionRowHandle; // 0x3b0 Size: 0x10
	    struct FDataTableRowHandle SlotItemActionRowHandle; // 0x3c0 Size: 0x10
	    struct FDataTableRowHandle InspectItemActionRowHandle; // 0x3d0 Size: 0x10
	    struct FDataTableRowHandle InspectCollectionBookItemActionRowHandle; // 0x3e0 Size: 0x10
	    struct FDataTableRowHandle InspectPreviewItemActionRowHandle; // 0x3f0 Size: 0x10
	    struct FDataTableRowHandle OpenPickerActionRowHandle; // 0x400 Size: 0x10
	    struct FDataTableRowHandle LogAllowedItemsActionRowHandle; // 0x410 Size: 0x10
	    struct FDataTableRowHandle ResearchItemActionRowHandle; // 0x420 Size: 0x10
	    struct FDataTableRowHandle RecruitActionRowHandle; // 0x430 Size: 0x10
	    struct FDataTableRowHandle UnslotItemActionRowHandle; // 0x440 Size: 0x10
	    ECollectionBookSectionNavTarget CurrentNavTarget; // 0x450 Size: 0x1
	    char UnknownData0[0x7]; // 0x451
	    class UFortCollectionBookSection* AssociatedSection; // 0x458 Size: 0x8
	    bool bHasSummonedPanel; // 0x460 Size: 0x1
	    char UnknownData1[0x3]; // 0x461
	    struct FFortDialogExternalLatentActionHandle SlotConfirmationDialogLatentHandle; // 0x464 Size: 0x4
	    MulticastDelegateProperty OnShowItemDetailEvent; // 0x468 Size: 0x10
	    MulticastDelegateProperty OnSlotItemConfirmEvent; // 0x478 Size: 0x10
	    MulticastDelegateProperty OnResearchItemConfirmEvent; // 0x488 Size: 0x10
	    MulticastDelegateProperty OnUnslotItemConfirmEvent; // 0x498 Size: 0x10
	    MulticastDelegateProperty OnInspectItemEvent; // 0x4a8 Size: 0x10
	    char UnknownData2[0x4b8]; // 0x4b8
	    void OnUnslotItemOperationComplete(class UFortAccountItem* UnslottedItem, class UFortAccountItem* OldSlottedItem, FName SlotId); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnUnslotItemComplete(class UFortItem* UnslottedItem, FName SlotId); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnUnslotItemActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnSlottedItemOperationComplete(class UFortAccountItem* SlottedItem, FName SlotId); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnSlotPickerItemSelected(class UFortItem* SelectedItem); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnSlotPickerItemHovered(class UFortItem* HoveredItem); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnSlotItemConfirmationCompleted(class UFortItem* SelectedItem, FName SlotId, struct FFortDialogExternalLatentActionHandle LatentActionHandle); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnSlotItemComplete(class UFortAccountItem* SlottedItem, FName SlotId); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnSlotItemActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void OnSlotButtonSelected(class UFortCollectionBookSlotButton* SlotButton); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void OnSlotButtonHovered(int ButtonIx); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void OnSlotButtonContextAction(EFortCollectionBookPopupButtonType ContextAction); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void OnSectionChanged(class UFortCollectionBookSection* Section); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void OnResearchItemOperationComplete(class UFortAccountItem* NewItem, struct FString TemplateId); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnResearchItemAction__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void OnPurchaseItemActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void OnOpenPickerActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void OnLogAllowedItemsActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnItemInspectAction__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnItemAction__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void OnInspectActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void OnInputMethodChanged(ECommonInputType CurrentInputType); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void OnBackActionExecuted(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x-7b09];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookSectionPanel");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookSectionTileWidget : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    __int64/*SoftClassProperty*/ SlotWidgetClass; // 0xb30 Size: 0x28
	    struct FMargin SlotWidgetPadding; // 0xb58 Size: 0x10
	    char SlotWidgetHorizontalAlignment; // 0xb68 Size: 0x1
	    char SlotWidgetVerticalAlignment; // 0xb69 Size: 0x1
	    char UnknownData1[0x2]; // 0xb6a
	    int MaxNumSlotsSupported; // 0xb6c Size: 0x4
	    class UHorizontalBox* SlotBoxWidget; // 0xb70 Size: 0x8
	    class UCommonTextBlock* SectionNameWidget; // 0xb78 Size: 0x8
	    class UFortCollectionBookGenericRewardWidget* SectionRewardWidget; // 0xb80 Size: 0x8
	    class UFortCollectionBookSection* AssociatedSection; // 0xb88 Size: 0x8
	    TArray<class UFortCollectionBookSlotWidget*> SlotWidgets; // 0xb90 Size: 0x10
	    char UnknownData2[0xba0]; // 0xba0
	    void OnSectionSlotUpdate(int NumFilledSlots, int NumSlots, EFortCollectionBookState SectionState); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnItemUnslotted(class UFortAccountItem* ItemUnslotted, class UFortAccountItem* OldSlottedItem, FName SlotId); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnItemSlotted(class UFortAccountItem* ItemSlotted, FName SlotId); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7441];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookSectionTileWidget");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookSlotButton : public UCommonButton
{
	public:
	    class UFortCollectionBookSlotWidget* CollectionBookSlotWidget; // 0xb28 Size: 0x8
	    class UMenuAnchor* PopupMenuAnchor; // 0xb30 Size: 0x8
	    char UnknownData0[0xb38]; // 0xb38
	    void PopupMenuClosedWithAction(EFortCollectionBookPopupButtonType Selection); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnSlottedItemUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    class UWidget* GetPopupMenu(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7481];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookSlotButton");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookSlotDetailsWidget : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x230];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookSlotDetailsWidget");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookSlotView : public UCommonUserWidget
{
	public:
	    __int64/*SoftClassProperty*/ CollectionBookButtonClass; // 0x230 Size: 0x28
	    class UHorizontalBox* CollectionBookButtonBox; // 0x258 Size: 0x8
	    class UCommonButtonGroup* CollectionBookSlotButtonGroup; // 0x260 Size: 0x8
	    TArray<class UFortCollectionBookSlotButton*> CollectionBookSlotButtons; // 0x268 Size: 0x10
	    class UFortCollectionBookSection* AssociatedSection; // 0x278 Size: 0x8
	    char UnknownData0[0x48]; // 0x280
	    int PreviousSelectedButtonIdx; // 0x2c8 Size: 0x4
	    int CurrentSelectedButtonIdx; // 0x2cc Size: 0x4
	    char UnknownData1[0x2d0]; // 0x2d0
	    void OnSlotButtonHovered(class UCommonButton* HoveredButton, int ButtonIdx); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnSlotButtonClicked(class UCommonButton* ClickedButton, int ButtonIdx); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnSelectedSlotButtonChanged(class UCommonButton* SelectedButton, int ButtonIdx); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7d09];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookSlotView");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookSlotWidget : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x10];
	    EFortItemCardSize ItemCardSize; // 0x240 Size: 0x1
	    bool bIsRewardCard; // 0x241 Size: 0x1
	    char UnknownData1[0x6]; // 0x242
	    class UFortMultiSizeItemCard* ItemCardWidget; // 0x248 Size: 0x8
	    class UWidget* UnslottedOverlayWidget; // 0x250 Size: 0x8
	    class UWidget* ReadyToSlotOverlayWidget; // 0x258 Size: 0x8
	    class UWidget* UnslottedButReadyOverlayWidget; // 0x260 Size: 0x8
	    FName SlotRowName; // 0x268 Size: 0x8
	    struct FText ItemAvailableToSlotText; // 0x270 Size: 0x18
	    struct FText NoItemsAvailableToSlotText; // 0x288 Size: 0x18
	    struct FText HigherQualityItemsAvailableToSlotAndUpgradeAvailableText; // 0x2a0 Size: 0x18
	    struct FText HigherQualityItemsAvailableToSlotAndEvolveAvailableText; // 0x2b8 Size: 0x18
	    struct FText HigherQualityItemsAvailableToSlotText; // 0x2d0 Size: 0x18
	    struct FText ItemInSlotFullyUpgradedText; // 0x2e8 Size: 0x18
	    struct FText ItemInSlotCanBeUpgradedText; // 0x300 Size: 0x18
	    struct FText ItemInSlotCanBeEvolvedText; // 0x318 Size: 0x18
	    class UFortItem* SlottedItemRepresentation; // 0x330 Size: 0x8
	    char UnknownData2[0x338]; // 0x338
	    void OnSlottedItemOperationComplete(class UFortAccountItem* ItemSlotted, FName SlotId); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnItemDestroyed(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnItemCardUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool IsItemSlotted(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool HasItemsToSlot(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    class UFortItem* GetSlottedItemRepresentation(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    FName GetSlotRowName(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    int GetNumItemsToSlot(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ FortCollectionBookSlottedItemUpdatedDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData11[0x-7c89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookSlotWidget");
			return (class UClass*)ptr;
		};

};

class UFortCollectionBookWidget : public UFortActivatablePanel
{
	public:
	    class UFortCollectionBookProgressWidget* ProgressWidget; // 0x340 Size: 0x8
	    class UCommonWidgetSwitcher* MainWidgetSwitcher; // 0x348 Size: 0x8
	    class UFortCollectionBookPrimaryPanel* PrimaryPanelWidget; // 0x350 Size: 0x8
	    class UFortCollectionBookSectionPanel* SectionPanelWidget; // 0x358 Size: 0x8
	    int PrimaryPanelIdx; // 0x360 Size: 0x4
	    int SectionPanelIdx; // 0x364 Size: 0x4
	    char UnknownData0[0x368]; // 0x368
	    void RequestToClose(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnPreviewXPChangeRequest(int XPChange); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnCollectionBookSectionCloseRequest(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnCollectionBookSectionClicked(class UFortCollectionBookSection* ClickedSection); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnCollectionBookPageSelected(class UFortCollectionBookPage* SelectedPage); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnCollectionBookPageClicked(class UFortCollectionBookPage* ClickedPage); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7c71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCollectionBookWidget");
			return (class UClass*)ptr;
		};

};

class AFortItemPlacementActor : public AActor
{
	public:
	    class UWidgetComponent* WidgetComponent_LoadingIndicator; // 0x330 Size: 0x8
	    bool bIsActorHovered; // 0x338 Size: 0x1
	    char UnknownData0[0x7]; // 0x339
	    class AFortPlayerPawn* CurrentPawn; // 0x340 Size: 0x8
	    char UnknownData1[0x348]; // 0x348
	    void OnUnhovered(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnRemovePreviewActor(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnPreviewActorSpawned(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnItemClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnHovered(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnHeroPawnSetupCompleted(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void HandlePawnTouchReleased(char FingerIndex, class AActor* TouchedActor); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void HandlePawnFinishedApplyingCharacterParts(class AFortPlayerPawn* Pawn); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void HandlePawnEndCursorOver(class AActor* TouchedActor); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void HandlePawnClicked(class AActor* TouchedActor, struct FKey ButtonPressed); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void HandlePawnBeginCursorOver(class AActor* TouchedActor); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7c69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemPlacementActor");
			return (class UClass*)ptr;
		};

};

class AFortItemPreviewPedestal : public AFortItemPlacementActor
{
	public:
	    TWeakObjectPtr<APlayerController*> ContextualPlayerController; // 0x378 Size: 0x8
	    class UFortHero* TemporaryHeroInstance; // 0x380 Size: 0x8
	    TArray<class UCustomCharacterPart*> AdditionalCharacterParts; // 0x388 Size: 0x10
	    char UnknownData0[0x28]; // 0x398
	    class USceneComponent* WeaponPlacementComponent; // 0x3c0 Size: 0x8
	    class UChildActorComponent* PreviewActorComponent; // 0x3c8 Size: 0x8
	    class UStaticMeshComponent* PreviewStaticMeshComponent; // 0x3d0 Size: 0x8
	    class USkeletalMeshComponent* PreviewSkelMeshComponent; // 0x3d8 Size: 0x8
	    char UnknownData1[0x3e0]; // 0x3e0
	    void PreviewItemBP(class UFortItem* Item, bool bIncludeCurrentLoadout); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void ClearDisplay(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7c01];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemPreviewPedestal");
			return (class UClass*)ptr;
		};

};

class AFortCommandRoomPedestal : public AFortItemPreviewPedestal
{
	public:
	    void HandleDifferentHeroSet(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7be9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCommandRoomPedestal");
			return (class UClass*)ptr;
		};

};

class UFortCommittableButtonGroup : public UCommonButtonGroup
{
	public:
	    MulticastDelegateProperty OnButtonCommitted; // 0x98 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCommittableButtonGroup");
			return (class UClass*)ptr;
		};

};

class UFortMultiSizeImage : public UWidget
{
	public:
	    struct FFortMultiSizeBrush MultiSizeBrush; // 0x100 Size: 0x330
	    char BrushSize; // 0x430 Size: 0x1
	    char UnknownData0[0x3]; // 0x431
	    struct FLinearColor ColorAndOpacity; // 0x434 Size: 0x10
	    char UnknownData1[0x444]; // 0x444
	    void SetMultiSizeBrush(struct FFortMultiSizeBrush MultiSizeBrush); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetColorAndOpacity(struct FLinearColor Color); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetBrushSize(char BrushSize); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7b89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMultiSizeImage");
			return (class UClass*)ptr;
		};

};

class UFortComparisonResultIndicator : public UFortMultiSizeImage
{
	public:
	    bool bShouldCollapseWhenNotShown; // 0x458 Size: 0x1
	    EFortBuffState ComparisonResult; // 0x459 Size: 0x1
	    char UnknownData0[0x45a]; // 0x45a
	    void SetComparisonResult(EFortBuffState ComparisonResult); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7b81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortComparisonResultIndicator");
			return (class UClass*)ptr;
		};

};

class UFortCraftingBarWidget : public UFortHUDElementWidget
{
	public:
	    class UCommonTextBlock* CraftingText; // 0x258 Size: 0x8
	    class UProgressBar* CraftingProgressBar; // 0x260 Size: 0x8
	    float CompletedRemainVisibleTime; // 0x268 Size: 0x4
	    char UnknownData0[0x26c]; // 0x26c
	    void SetHideCraftingBar(bool bInHideCraftBar); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnCompletedSetHidden(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HandlePlayerStoppedCrafting(bool bSuccess, EFortCraftFailCause CraftFailureCause); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandlePlayerStartedCrafting(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7d61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCraftingBarWidget");
			return (class UClass*)ptr;
		};

};

class UFortCreativeAdsView : public UUserWidget
{
	public:
	    TArray<struct FCreativeAdData> CreativeAdList; // 0x228 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCreativeAdsView");
			return (class UClass*)ptr;
		};

};

class UFortCreativeAdTile : public UCommonUserWidget
{
	public:
	    class UEpicCMSImage* Image_CreativeAd; // 0x230 Size: 0x8
	    struct FCreativeAdData CMSAdEntry; // 0x238 Size: 0x68
	    char UnknownData0[0x2a0]; // 0x2a0
	    void PopulateAdTile(struct FCreativeAdData Entry); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnCMSDataUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCreativeAdTile");
			return (class UClass*)ptr;
		};

};

class UFortCreativeInfoIndicatorWidget : public UFortActorIndicatorWidget
{
	public:
	    void SetKeyBindWidgetBoundAction(class UFortKeybindWidget* FortKeybindWidget, FName ActionName, EFortBuildingInteraction InteractionType); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7d51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCreativeInfoIndicatorWidget");
			return (class UClass*)ptr;
		};

};

class UFortCreativeIslandLink : public UObject
{
	public:
	    struct FString Mnemonic; // 0x28 Size: 0x10
	    struct FString CreatorUsername; // 0x38 Size: 0x10
	    struct FString Title; // 0x48 Size: 0x10
	    struct FString Tagline; // 0x58 Size: 0x10
	    EFortCreativeIslandLinkCategory Category; // 0x68 Size: 0x1
	    bool bDummyLink; // 0x69 Size: 0x1
	    char UnknownData0[0x6]; // 0x6a
	    struct FDateTime SortDate; // 0x70 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCreativeIslandLink");
			return (class UClass*)ptr;
		};

};

class UFortCreativeIslandLinkEntry : public UCommonButton
{
	public:
	    char UnknownData0[0xb30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCreativeIslandLinkEntry");
			return (class UClass*)ptr;
		};

};

class UFortCreativeIslandLinkScreen : public UFortActivatablePanel
{
	public:
	    int NumDebugIslandLinks; // 0x340 Size: 0x4
	    char UnknownData0[0x4]; // 0x344
	    MulticastDelegateProperty OnCreativeIslandCodeConfirmed; // 0x348 Size: 0x10
	    class UEditableText* EditableText_IslandLink; // 0x358 Size: 0x8
	    class UListView* ListView_IslandLinks; // 0x360 Size: 0x8
	    class UCommonButton* Button_Select; // 0x368 Size: 0x8
	    class UCommonButton* Button_Cancel; // 0x370 Size: 0x8
	    class UCommonButton* Button_Refresh; // 0x378 Size: 0x8
	    TArray<class UFortCreativeIslandLink*> FavoriteIslandLinks; // 0x380 Size: 0x10
	    TArray<class UFortCreativeIslandLink*> RecentIslandLinks; // 0x390 Size: 0x10
	    class AFortAthenaCreativePortal* TargetPortal; // 0x3a0 Size: 0x8
	    struct FDateTime LastRefreshTime; // 0x3a8 Size: 0x8
	    struct FString LastTestedMnemonic; // 0x3b0 Size: 0x10
	    bool bCodeLookupRequestInFlight; // 0x3c0 Size: 0x1
	    bool bFriendsGetRequestInFlight; // 0x3c1 Size: 0x1
	    char UnknownData1[0x3c2]; // 0x3c2
	    void SetTargetPortal(class AFortAthenaCreativePortal* Portal); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnCreativeIslandLinkValidated(EFortCreativeIslandLinkValidationResult ValidateResult); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnCreativeIslandLinksPopulated(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleIslandSelectionChanged(class UObject* Item); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleIslandLinkCommitted(struct FText InText, char CommitInfo); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void HandleIslandLinkChanged(struct FText Text); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7c09];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCreativeIslandLinkScreen");
			return (class UClass*)ptr;
		};

};

class UFortCreativeItemListMenu : public UFortActivatablePanel
{
	public:
	    class UFortCreativeItemListPanelData* PanelDataClass; // 0x340 Size: 0x8
	    class UDataTable* ItemListSource; // 0x348 Size: 0x8
	    class UDataTable* ItemListCategorySource; // 0x350 Size: 0x8
	    class UFortCreativeItemListPanelData* ItemListPanelData; // 0x358 Size: 0x8
	    MulticastDelegateProperty OnItemSelected; // 0x360 Size: 0x10
	    char UnknownData0[0x370]; // 0x370
	    void OnItemsLoaded(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void LoadItems(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    FName GetTabNameFromLabel(struct FText TabLabel); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool GetCollapseBorderPadFlagForCategory(FName ItemListCategoryName); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    EFortItemCardSize GetCardSizeForCategory(FName ItemListCategoryName); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool CanPlayerCreateInVolume(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void BroadcastOnItemSelected(struct FFortItemEntry ItemToSpawn); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7c71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCreativeItemListMenu");
			return (class UClass*)ptr;
		};

};

class UFortCreativeItemListPanelData : public UObject
{
	public:
	    TArray<class UFortItemDefinition*> AllItems; // 0x28 Size: 0x10
	    TArray<struct FItemListCategoryArray> CategoryList; // 0x38 Size: 0x10
	    MulticastDelegateProperty OnLoadItemsComplete; // 0x48 Size: 0x10
	    class UDataTable* ItemListTable; // 0x58 Size: 0x8
	    class UDataTable* ItemListCategoryTable; // 0x60 Size: 0x8
	    char UnknownData0[0x68]; // 0x68
	    void LoadItems(class UObject* Target); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    struct FFortItemEntry GetItemToSpawn(class UFortItemDefinition* InItemDefinition); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    struct FText GetInteractionText(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static class UFortCreativeItemListPanelData* GetCreativeItemListPanelData(class UObject* Target, class UFortCreativeItemListPanelData* PanelDataClass, class UDataTable* InItemListSource, class UDataTable* InItemListCategorySource); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7f79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCreativeItemListPanelData");
			return (class UClass*)ptr;
		};

};

class UFortCreativeOptions : public UObject
{
	public:
	    int CurrentReleaseVersion; // 0x28 Size: 0x4
	    char UnknownData0[0x4]; // 0x2c
	    TArray<struct FOptionsReleaseInfo> ReleaseInfo; // 0x30 Size: 0x10
	    char UnknownData1[0x40]; // 0x40
	    static bool IsVisibleOption(ESettingType SettingType); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static bool GetVisibleOptionsForTab(ESettingTab TabType, TArray<ESettingType> VisibleOptions); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7fa1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCreativeOptions");
			return (class UClass*)ptr;
		};

};

class UFortCreativeOptionsDisplay : public UFortActivatablePanel
{
	public:
	    char UnknownData0[0x340];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCreativeOptionsDisplay");
			return (class UClass*)ptr;
		};

};

class UFortCreativeSpawnDisplay : public UFortActivatablePanel
{
	public:
	    TArray<struct FRarityArray> ItemArray; // 0x340 Size: 0x10
	    TArray<class UFortItemDefinition*> AllItems; // 0x350 Size: 0x10
	    char UnknownData0[0x360]; // 0x360
	    void OnLoadedItems(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void LoadItems(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7c81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCreativeSpawnDisplay");
			return (class UClass*)ptr;
		};

};

class UFortMatchmakingKnobsModal : public UFortActivatablePanel
{
	public:
	    class AFortMinigameSettingsBuilding* Machine; // 0x340 Size: 0x8
	    class UPlaylistUserOptions* OptionsAsset; // 0x348 Size: 0x8
	    struct FPlaylistFrontEndData FrontEndData; // 0x350 Size: 0x10
	    __int64/*MapProperty*/ LoadedOptionValues; // 0x360 Size: 0x50
	    class UFortPlaylistAthena* CurrentPlaylist; // 0x3b0 Size: 0x8
	    char UnknownData0[0x18]; // 0x3b8
	    class UListView* OptionsList; // 0x3d0 Size: 0x8
	    class UCommonButton* AcceptButton; // 0x3d8 Size: 0x8
	    class UCommonButton* CancelButton; // 0x3e0 Size: 0x8
	    class UCommonButton* RestoreDefaultsButton; // 0x3e8 Size: 0x8
	    class UCommonTextBlock* TextBlock_HeaderText; // 0x3f0 Size: 0x8
	    class UCommonTextBlock* TextBlock_TitleText; // 0x3f8 Size: 0x8
	    class UCommonTextBlock* TextBlock_DescriptionText; // 0x400 Size: 0x8
	    class UImage* Image_DisplayImage; // 0x408 Size: 0x8
	    char UnknownData1[0x410]; // 0x410
	    void SetListDataSource(char ListType); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetInScrimmage(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetInGameMode(bool bIsInGame); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnSelectionUpdated(class UFortMatchmakingKnobsSpinnerButton* CurrentSelection); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnCurrentItemSelectionChanged(class UObject* Item); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnAcceptAnimationComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void InitForOptionsComponent(class UFortActorOptionsComponent* OptionsComponent); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void HandleCancelClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void ApplyChanges(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7bd1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMatchmakingKnobsModal");
			return (class UClass*)ptr;
		};

};

class UFortCreativePermissionOptions : public UFortMatchmakingKnobsModal
{
	public:
	    EFortCreativePlotPermission CurrentPermissionsEnum; // 0x410 Size: 0x1
	    char UnknownData0[0x411]; // 0x411
	    void UpdatePermissions(EFortCreativePlotPermission Permissions, TArray<struct FString> WhiteList); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7bc9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCreativePermissionOptions");
			return (class UClass*)ptr;
		};

};

class UFortCreativePlayOptions : public UFortActivatablePanel
{
	public:
	    class UFortCreativeServersView* CreativeOptionsServers; // 0x340 Size: 0x8
	    class UCommonButton* PlayButton; // 0x348 Size: 0x8
	    class UCommonButton* CancelButton; // 0x350 Size: 0x8
	    char UnknownData0[0x358]; // 0x358
	    bool ShouldShowImportPlatformFriendsOption(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetMatchmakingWidget(class UFortAthenaMatchmakingWidget* InWidget); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void ImportPlatformFriends(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7c81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCreativePlayOptions");
			return (class UClass*)ptr;
		};

};

class UFortCreativePublishModal : public UFortActivatablePanel
{
	public:
	    int DescriptionEntryCharLimit; // 0x340 Size: 0x4
	    int NameEntryCharLimit; // 0x344 Size: 0x4
	    bool bFakePublishingFlow; // 0x348 Size: 0x1
	    bool DescriptionTextOkForSubmit; // 0x349 Size: 0x1
	    bool NameTextOkForSubmit; // 0x34a Size: 0x1
	    char UnknownData0[0x5]; // 0x34b
	    class UCommonWidgetSwitcher* Switcher_Content; // 0x350 Size: 0x8
	    class UCommonTextBlock* Text_IslandCode; // 0x358 Size: 0x8
	    class UCommonTextBlock* Text_ErrorInNameField; // 0x360 Size: 0x8
	    class UCommonTextBlock* Text_ErrorInDescriptionField; // 0x368 Size: 0x8
	    class UCommonTextBlock* Text_ErrorOnPublish; // 0x370 Size: 0x8
	    class UCommonTextBlock* Text_CharCountTitle; // 0x378 Size: 0x8
	    class UCommonTextBlock* Text_CharCountDesc; // 0x380 Size: 0x8
	    class UCommonButton* Button_Submit; // 0x388 Size: 0x8
	    class UCommonButton* Button_CopyCode; // 0x390 Size: 0x8
	    class UEditableTextBox* EditText_Name; // 0x398 Size: 0x8
	    class UMultiLineEditableTextBox* MultiLineEditText_Description; // 0x3a0 Size: 0x8
	    char UnknownData1[0x3a8]; // 0x3a8
	    void PublishMyCurrentCreativePlot(struct FCreativePublishOptions MyPublishOptions); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnValidCheckComplete(bool bSuccess); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnPublishError(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnPublishedLinksChanged(struct FString ErrorCode, struct FString Mnemonic); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnPublishBegin(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnNameTextCommitted(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnDescriptionTextCommitted(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnCodeCopied(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnCodeConfirmation(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void HandleSubmitClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void HandleNameTextCommitted(struct FText Text, char CommittMethod); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void HandleNameTextChanged(struct FText Text); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void HandleDescriptionTextCommitted(struct FText Text, char CommittMethod); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void HandleDescriptionTextChanged(struct FText Text); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void HandleCopyCode(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void HandleCodeConfirmation(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x-7c29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCreativePublishModal");
			return (class UClass*)ptr;
		};

};

class UFortCreativePublishOptions : public UFortActivatablePanel
{
	public:
	    EFortCreativePlotPermission CurrentPermissionsEnum; // 0x340 Size: 0x1
	    char UnknownData0[0x7]; // 0x341
	    class UHorizontalBox* IslandPublishBox; // 0x348 Size: 0x8
	    class UHorizontalBox* IslandRestoreBox; // 0x350 Size: 0x8
	    class UVerticalBox* CheckpointBox; // 0x358 Size: 0x8
	    char UnknownData1[0x58]; // 0x360
	    class UFortLevelSaveComponent* SaveComponent; // 0x3b8 Size: 0x8
	    class UCommonTextBlock* Text_RestoreTime; // 0x3c0 Size: 0x8
	    class UCommonTextBlock* Text_OnCooldown; // 0x3c8 Size: 0x8
	    class UCommonButton* Button_Restore; // 0x3d0 Size: 0x8
	    char UnknownData2[0x3d8]; // 0x3d8
	    void UpdateTimeSinceLastBackup(struct FDateTime LastBackup); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void UpdatePermissions(EFortCreativePlotPermission Permissions); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void RestoreMyIslandFromBackup(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ResetMyCurrentCreativePlot(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void PublishMyCurrentCreativePlot(struct FCreativePublishOptions MyPublishOptions); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnSaveStateChanged(bool bSuccess); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnRestoreStateChanged(bool bReady); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnRestoreMyIslandFromBackup(bool bSuccess); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnBackupMyIsland(bool bSuccess); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void CheckpointSaveStateChanged(EBackupSaveState SaveState); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void CheckpointRestoreStateChanged(EBackupSaveState SaveState); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void BackupMyIsland(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x-7c09];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCreativePublishOptions");
			return (class UClass*)ptr;
		};

};

class UFortCreativeServerOptionTile : public UCommonButton
{
	public:
	    class UCommonTextBlock* Text_JoinServerPlayerCount; // 0xb28 Size: 0x8
	    class UFortCreativeServerInfo* Server; // 0xb30 Size: 0x8
	    char UnknownData0[0xb38]; // 0xb38
	    void SetBPData(class UFortCreativeServerInfo* ServerInfo); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-74a9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCreativeServerOptionTile");
			return (class UClass*)ptr;
		};

};

class UFortCreativeServerInfo : public UObject
{
	public:
	    int CurrentPlayerCount; // 0x28 Size: 0x4
	    int MaxPlayerCount; // 0x2c Size: 0x4
	    TArray<struct FString> MatchFriendsList; // 0x30 Size: 0x10
	    struct FString OwnerName; // 0x40 Size: 0x10
	    class UFortSocialUser* FriendInMatch; // 0x50 Size: 0x8
	    EFortCreativeServerPrivacySetting PrivacySetting; // 0x58 Size: 0x1
	    bool IsNewServer; // 0x59 Size: 0x1
	    char UnknownData0[0x6];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCreativeServerInfo");
			return (class UClass*)ptr;
		};

};

class UFortCreativeServersView : public UCommonUserWidget
{
	public:
	    int MaxSuggestedServers; // 0x230 Size: 0x4
	    bool bShowDebugServers; // 0x234 Size: 0x1
	    char UnknownData0[0x3]; // 0x235
	    class UFortCreativeServerOptionTile* TileItemClass; // 0x238 Size: 0x8
	    class UCommonButtonGroup* ServerButtonGroup; // 0x240 Size: 0x8
	    class UScrollBox* ScrollBox_ServerList; // 0x248 Size: 0x8
	    TArray<class UFortCreativeServerInfo*> ServerList; // 0x250 Size: 0x10
	    char UnknownData1[0x260]; // 0x260
	    void RefreshServerList(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnCreativeServerListRefreshed(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void NavigateServerRight(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void NavigateServerLeft(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7d71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCreativeServersView");
			return (class UClass*)ptr;
		};

};

class UFortCreativeSettingsFlow : public UFortActivatablePanel
{
	public:
	    class UCommonButtonGroup* TabButtonGroup; // 0x340 Size: 0x8
	    char UnknownData0[0x348]; // 0x348
	    void OnClose(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void HasActiveModalWidget(bool OutWidgetActive); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7c99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortCreativeSettingsFlow");
			return (class UClass*)ptr;
		};

};

class UFortDailyRewards : public UFortActivatablePanel
{
	public:
	    bool TryGetDailyRewardsData(struct FFortDailyRewardsData OutDailyRewardsData, int ItemCardsPerSchedule, int MinEpicRewards); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void SetupDailyRewards(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7c99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortDailyRewards");
			return (class UClass*)ptr;
		};

};

class UFortDailyRewardsItem : public UCommonUserWidget
{
	public:
	    struct FFortDailyRewardsItemData ItemData; // 0x230 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortDailyRewardsItem");
			return (class UClass*)ptr;
		};

};

class UFortDailyRewardsSchedule : public UCommonUserWidget
{
	public:
	    struct FFortDailyRewardsScheduleData ScheduleData; // 0x230 Size: 0x98

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortDailyRewardsSchedule");
			return (class UClass*)ptr;
		};

};

class UFortDefenderConfigPanel : public UCommonActivatablePanel
{
	public:
	    TWeakObjectPtr<UFortItem*> SelectedDefenderItem; // 0x318 Size: 0x8
	    TWeakObjectPtr<UFortItem*> SelectedWeaponItem; // 0x320 Size: 0x8
	    TWeakObjectPtr<UFortItem*> SelectedAmmoItem; // 0x328 Size: 0x8
	    int SelectedAmmoQuantity; // 0x330 Size: 0x4
	    TWeakObjectPtr<ABuildingTrapDefender*> DefenderTrap; // 0x334 Size: 0x8
	    char UnknownData0[0x33c]; // 0x33c
	    bool UnsummonDefender(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool SpawnDefender(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool IsWeaponSelectionValid(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool HasWeaponForSelectedDefender(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool HasAnyDefenders(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    class UFortSchematicItemDefinition* GetSourceSchematic(class UFortWorldItemDefinition* ItemDefUsedForCrafting); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    class UFortWorldItem* GetDefenderPawnWeaponItem(class AFortAIPawn* DefenderPawn); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    class UFortWorldItemDefinition* GetCompatibleAmmoDef(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    class UFortWorldItem* GetCompatibleAmmo(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    int GetAmmoCountFromPlayer(class UFortWorldItemDefinition* AmmoItemDef); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    int GetAmmoCountFromDefender(class UFortWorldItemDefinition* AmmoItemDef); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x-7ca1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortDefenderConfigPanel");
			return (class UClass*)ptr;
		};

};

class UFortDefenderItemTileButton : public UFortItemPickerButton
{
	public:
	    void HandleEquipSlotChanged(int EquipSlot); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7489];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortDefenderItemTileButton");
			return (class UClass*)ptr;
		};

};

class UFortItemTileView : public UCommonTileView
{
	public:
	    struct FFortItemFilterDefinition Filter; // 0x350 Size: 0x50
	    struct FFortItemSorterDefinition Sorter; // 0x3a0 Size: 0x40
	    bool bShouldShowNullItemTile; // 0x3e0 Size: 0x1
	    bool bAutomaticallyLoadItemDetails; // 0x3e1 Size: 0x1
	    EItemTileViewDisplayType DisplayType; // 0x3e2 Size: 0x1
	    char UnknownData0[0x5]; // 0x3e3
	    MulticastDelegateProperty OnInventoryUpdatedEvent; // 0x3e8 Size: 0x10
	    char UnknownData1[0x20]; // 0x3f8
	    TArray<TWeakObjectPtr<UFortItem*>> CustomItemList; // 0x418 Size: 0x10
	    TArray<TWeakObjectPtr<UFortItem*>> ItemsForTileView; // 0x428 Size: 0x10
	    __int64/*InterfaceProperty*/ ItemViewContext; // 0x438 Size: 0x10
	    char UnknownData2[0x448]; // 0x448
	    void ShowNullItemTile(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetSorter(struct FFortItemSorterDefinition Sorter); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetItemViewContext(__int64/*InterfaceProperty*/ ItemViewContext); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetFilterAndSorter(struct FFortItemFilterDefinition Filter, struct FFortItemSorterDefinition Sorter); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetFilter(struct FFortItemFilterDefinition Filter); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetCustomItemList(TArray<class UFortItem*> ItemList); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void RefreshSort(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void RefreshFilterAndSort(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnInventoryUpdated__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void HideNullItemTile(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    bool ContainsItem(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void ClearCustomItemList(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void CenterSelectedItemTileWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x-7b81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemTileView");
			return (class UClass*)ptr;
		};

};

class UFortDefenderItemTileView : public UFortItemTileView
{
	public:
	    TWeakObjectPtr<UFortDefenderConfigPanel*> DefenderConfigPanel; // 0x460 Size: 0x8
	    char UnknownData0[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortDefenderItemTileView");
			return (class UClass*)ptr;
		};

};

class UFortDefenderSlotButton : public UCommonButton
{
	public:
	    char UnknownData0[0xb28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortDefenderSlotButton");
			return (class UClass*)ptr;
		};

};

class UFortDefenderSlotItemPicker : public UFortItemPickerBase
{
	public:
	    EFortDefenderSlotType DefenderSlotType; // 0x2e8 Size: 0x1
	    char UnknownData0[0x7]; // 0x2e9
	    TArray<EInventoryContentSortType> SortTypesList; // 0x2f0 Size: 0x10
	    EInventoryContentSortType CurrentSortType; // 0x300 Size: 0x1
	    char UnknownData1[0x301]; // 0x301
	    void SetSortType(EInventoryContentSortType SortType); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void PopulateDefenderSlotItems(class UFortDefenderItem* DefenderItem); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnCurrentSortTypeChanged(EInventoryContentSortType SortType); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void NextSortType(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7cd9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortDefenderSlotItemPicker");
			return (class UClass*)ptr;
		};

};

class UFortDefenderSlotView : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x230];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortDefenderSlotView");
			return (class UClass*)ptr;
		};

};

class UFortDefenderSlotWidget : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x230];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortDefenderSlotWidget");
			return (class UClass*)ptr;
		};

};

class UFortSquadSelectorButton : public UCommonButton
{
	public:
	    char UnknownData0[0x10];
	    class UFortSquadManagementScreenBase* SquadManagementScreenType; // 0xb38 Size: 0x8
	    char UnknownData1[0xb40]; // 0xb40
	    bool TryGetStaticSquadDataBP(struct FHomebaseSquad OutSquadData); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetIdOfSquadToManageBP(FName SquadId); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleSquadChangedBP(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleDifferentSquadSetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    FName GetIdOfSquadToManageBP(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7499];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSquadSelectorButton");
			return (class UClass*)ptr;
		};

};

class UFortDefenderSquadSelectorButton : public UFortSquadSelectorButton
{
	public:
	    bool TryGetTheaterUniqueId(struct FString OutTheaterUniqueId, bool OutIsUnlocked); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    bool TryGetPowerLevel(int OutPowerLevel); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7499];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortDefenderSquadSelectorButton");
			return (class UClass*)ptr;
		};

};

class UFortDirectAcquisitionOfferDetailsWidgetBase : public UFortActivatablePanelWithItemPreview
{
	public:
	    char UnknownData0[0x10];
	    struct FDataTableRowHandle EnterViewModeInputActionRowHandle; // 0x448 Size: 0x10
	    bool IsInItemViewMode; // 0x458 Size: 0x1
	    bool ShouldAllowItemViewModeAction; // 0x459 Size: 0x1
	    char UnknownData1[0x6]; // 0x45a
	    TArray<class UFortStoreFrontOfferInfo*> PagedItems; // 0x460 Size: 0x10
	    class UFortStoreFrontOfferInfo* OfferData; // 0x470 Size: 0x8
	    class UFortVariantPicker* Picker_VariantSelector; // 0x478 Size: 0x8
	    char UnknownData2[0x480]; // 0x480
	    void UpdateItemViewModeBP(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool ShouldHavePurchaseConfirmation(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetupOffer(class UFortStoreFrontOfferInfo* InOfferData); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetShouldAllowItemViewModeAction(bool Value); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetPagedItems(TArray<class UFortStoreFrontOfferInfo*> InPagedItems); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetIsInItemViewMode(bool Value); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SendShopInteractionAnalytic(struct FString Interaction); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void PurchaseAmountRight(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void PurchaseAmountLeft(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void OnUpdateStatus(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void OnOfferSet(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void OnEnterViewModeActionCommitted(bool PassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void HandleCurrentlyViewedAccountInfoChanged(struct FFortPublicAccountInfo NewInfo); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    class UFortStoreFrontOfferInfo* GetOfferInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    bool CanAutoEquip(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void AutoEquip(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x-7b61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortDirectAcquisitionOfferDetailsWidgetBase");
			return (class UClass*)ptr;
		};

};

class UFortMtxStoreRootBase : public UFortActivatablePanel
{
	public:
	    char UnknownData0[0x8];
	    class UFortMtxStoreSelectionPopup* MtxStoreSelectionWidget; // 0x348 Size: 0x8
	    class UFortMtxStoreSelectionPopup* MtxStoreSelectionClass; // 0x350 Size: 0x8
	    TArray<struct FString> StorefrontNames; // 0x358 Size: 0x10
	    char UnknownData1[0x10]; // 0x368
	    TArray<class UFortStoreFrontOfferInfo*> AcquisitionOfferData; // 0x378 Size: 0x10
	    char UnknownData2[0x388]; // 0x388
	    void SetStorefrontNames(TArray<struct FString> InStorefrontNames); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void PushStoreSelection(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnUpdateOtherPlatformMTXMessage(bool HasOtherPlatformCurrency, struct FText CurrencyMessageLocText); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnStartReadingOffers(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnPurchasingDisabled(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnOffersGenerated(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void NoOffersAvailable(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    struct FMtxBreakdown GetMtxBreakdown(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void GenerateOfferWidget(class UFortStoreFrontOfferInfo* OfferData); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void ClearOfferWidgets(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    bool AreOffersLoaded(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x-7c51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMtxStoreRootBase");
			return (class UClass*)ptr;
		};

};

class UFortDirectAcquisitionWidgetBase : public UFortMtxStoreRootBase
{
	public:
	    char UnknownData0[0x8];
	    bool bShowIneligible; // 0x398 Size: 0x1
	    char UnknownData1[0x399]; // 0x399
	    void OnAffiliateUpdated(struct FString AffiliateName); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    struct FDateTime GetWeeklyStoreEndDate(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    TArray<class UFortAccountItemDefinition*> GetStoreCurrencies(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    struct FDateTime GetSeasonStoreEndDate(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    struct FDateTime GetDailyStoreEndDate(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7c29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortDirectAcquisitionWidgetBase");
			return (class UClass*)ptr;
		};

};

class UFortDisplayNameWidget : public UCommonActivatablePanel
{
	public:
	    char UnknownData0[0x10];
	    struct FText ButtonDisableReason; // 0x328 Size: 0x18
	    struct FText NameTakenText; // 0x340 Size: 0x18
	    struct FText NameInvalidFormatText; // 0x358 Size: 0x18
	    struct FText NameTooShortText; // 0x370 Size: 0x18
	    class UCommonButton* Button_Enter; // 0x388 Size: 0x8
	    class UCommonTextBlock* Text_Error; // 0x390 Size: 0x8
	    class UEditableText* EditText_DisplayName; // 0x398 Size: 0x8
	    char UnknownData1[0x3a0]; // 0x3a0
	    void HandleTextChanged(struct FText Text); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7c41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortDisplayNameWidget");
			return (class UClass*)ptr;
		};

};

class UFortDropdownMenu : public UCommonPopupMenu
{
	public:
	    MulticastDelegateProperty OnOptionSelected; // 0x330 Size: 0x10
	    class UCommonButtonGroup* ButtonGroup; // 0x340 Size: 0x8
	    bool bCloseOnSelection; // 0x348 Size: 0x1
	    char UnknownData0[0x349]; // 0x349
	    void RegisterButton(class UCommonButton* Button); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void InternalOnSelectionChanged(class UCommonButton* AssociatedButton, int ButtonIndex); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void InternalOnButtonClicked(class UCommonButton* AssociatedButton, int ButtonIndex); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    int GetSelectedButtonIndex(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    class UCommonButton* GetSelectedButton(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void DeselectAll(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ClearRegisteredButtons(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7c91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortDropdownMenu");
			return (class UClass*)ptr;
		};

};

class UFortDropdownDelegateRegistrar : public UObject
{
	public:
	    class UObject* ContextProvider; // 0x28 Size: 0x8
	    class UCommonButton* Button; // 0x30 Size: 0x8
	    class UMenuAnchor* MenuAnchor; // 0x38 Size: 0x8
	    char UnknownData0[0x10]; // 0x40
	    class UFortDropdownMenu* CachedDropdownMenu; // 0x50 Size: 0x8
	    char UnknownData1[0x58]; // 0x58
	    void OnOpenStatusChanged(bool Open); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    class UWidget* GetOrCreateDropdownMenu(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7f89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortDropdownDelegateRegistrar");
			return (class UClass*)ptr;
		};

};

class UFortDynamicEntryBox : public UDynamicEntryBox
{
	public:
	    int MaximumEntries; // 0x1d0 Size: 0x4
	    EDynamicEntryPatternDirection PatternDirection; // 0x1d4 Size: 0x1
	    char UnknownData0[0x3]; // 0x1d5
	    TArray<float> RenderOpacityPattern; // 0x1d8 Size: 0x10
	    TArray<struct FWidgetTransform> RenderTransformPattern; // 0x1e8 Size: 0x10
	    TArray<struct FVector2D> RenderTransformPivotPattern; // 0x1f8 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortDynamicEntryBox");
			return (class UClass*)ptr;
		};

};

class UFortErrorWindow : public UFortActivatablePanel
{
	public:
	    class UCommonUserWidget* ErrorEntryClass; // 0x340 Size: 0x8
	    TArray<class UCommonUserWidget*> ErrorEntriesPool; // 0x348 Size: 0x10
	    char UnknownData0[0x358]; // 0x358
	    void PutErrorEntries(TArray<class UCommonUserWidget*> ErrorEntries); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    class UCommonUserWidget* GetErrorEntry(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void DismissErrors(TArray<struct FFortErrorInfo> ErrorInfos); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7c89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortErrorWindow");
			return (class UClass*)ptr;
		};

};

class UFortEulaWidget : public UCommonActivatablePanel
{
	public:
	    char UnknownData0[0x18];
	    class UFortRichTextBlock* Text_Description; // 0x330 Size: 0x8
	    class UScrollBox* ScrollBox_License; // 0x338 Size: 0x8
	    class UCommonButton* Button_Confirm; // 0x340 Size: 0x8
	    class UCommonButton* Button_Decline; // 0x348 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortEulaWidget");
			return (class UClass*)ptr;
		};

};

class UFortEventLeaderboardEntryData : public UObject
{
	public:
	    int Rank; // 0x28 Size: 0x4
	    int Score; // 0x2c Size: 0x4
	    TArray<struct FString> TeammateNames; // 0x30 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortEventLeaderboardEntryData");
			return (class UClass*)ptr;
		};

};

class UFortEventLeaderboardEntry : public UCommonButton
{
	public:
	    char UnknownData0[0xb30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortEventLeaderboardEntry");
			return (class UClass*)ptr;
		};

};

class UFortEventLeaderboardScreen : public UFortActivatablePanel
{
	public:
	    class UListView* ListView_LeaderboardEntries; // 0x340 Size: 0x8
	    char UnknownData0[0x348]; // 0x348
	    void HandleLeaderboardEntrySelectionChanged(class UObject* Item); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7c99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortEventLeaderboardScreen");
			return (class UClass*)ptr;
		};

};

class UFortSimpleItemConditionIconIndicator : public UFortMultiSizeImage
{
	public:
	    bool bShouldCollapseWhenConditionIsFalse; // 0x458 Size: 0x1
	    char UnknownData0[0x459]; // 0x459
	    void ShouldCollapseWhenConditionIsFalse(bool Value); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetItemToRepresent(class UFortItem* ItemToRepresent); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    class UFortItem* GetItemToRepresent(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7b81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSimpleItemConditionIconIndicator");
			return (class UClass*)ptr;
		};

};

class UFortEvolveIndicator : public UFortSimpleItemConditionIconIndicator
{
	public:
	    char UnknownData0[0x460];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortEvolveIndicator");
			return (class UClass*)ptr;
		};

};

class UFortExpeditionBuildSquadWidget : public UCommonActivatablePanel
{
	public:
	    TWeakObjectPtr<UFortExpeditionItem*> Item; // 0x318 Size: 0x8
	    FName CurrentSquadId; // 0x320 Size: 0x8
	    class UFortSquadSlotsView* ExpeditionSquadSlotsView; // 0x328 Size: 0x8
	    class UFortSquadSlotDetailsPanel* ExpeditionSquadSlotDetails; // 0x330 Size: 0x8
	    class UFortSquadSlotItemPicker* ExpeditionSquadSlotPicker; // 0x338 Size: 0x8
	    class UFortItemViewContext_ExpeditionSquadSlotsView* ItemViewContext_ExpeditionSlotsView; // 0x340 Size: 0x8
	    class UFortItemViewContext_ExpeditionSquadSlotItemPicker* ItemViewContext_ExpeditionSlotItemPicker; // 0x348 Size: 0x8
	    char UnknownData0[0x350]; // 0x350
	    bool StartExpedition(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetData(class UFortExpeditionItem* InItem); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetCurrentSquadId(FName SquadId); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnStartExpeditionCompleted(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnRequestClosePicker(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnRefreshBuildSquadWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool IsSquadSlotLocked(int SlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool IsExpeditionValidToStart(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void HandleStartExpeditionCompleted(class UFortExpeditionItem* Expedition, bool bSucceeded); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void HandleDifferentSquadSlotSelected(int SquadSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void ClearTemporaryExpeditionSquadState(bool bPreviewOnly); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x-7c69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortExpeditionBuildSquadWidget");
			return (class UClass*)ptr;
		};

};

class UFortExpeditionDetailsWidget : public UCommonUserWidget
{
	public:
	    TWeakObjectPtr<UFortExpeditionItem*> Item; // 0x230 Size: 0x8
	    class UFortSquadSlotsView* ExpeditionSquadSlotsView; // 0x238 Size: 0x8
	    FName CurrentSquadId; // 0x240 Size: 0x8
	    class UFortItemViewContext_ExpeditionSquadSlotsView* ItemViewContext_ExpeditionSlotsView; // 0x248 Size: 0x8
	    char UnknownData0[0x250]; // 0x250
	    void SetData(class UFortExpeditionItem* InItem); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetCurrentSquadId(FName SquadId); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnAbandonExpeditionCompleted(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleAbandonExpeditionCompleted(class UFortExpeditionItem* Expedition, bool bSuccess); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void AbandonExpedition(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7d71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortExpeditionDetailsWidget");
			return (class UClass*)ptr;
		};

};

class UFortExpeditionExpiresWidget : public UCommonUserWidget
{
	public:
	    TWeakObjectPtr<UFortExpeditionItem*> Item; // 0x230 Size: 0x8
	    char UnknownData0[0x238]; // 0x238
	    void SetData(class UFortExpeditionItem* InItem); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnExpeditionExpirationUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7da1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortExpeditionExpiresWidget");
			return (class UClass*)ptr;
		};

};

class UFortExpeditionListItemWidget : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    TWeakObjectPtr<UFortExpeditionItem*> Item; // 0xb30 Size: 0x8
	    char UnknownData1[0xb38]; // 0xb38
	    void OnItemChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-74a1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortExpeditionListItemWidget");
			return (class UClass*)ptr;
		};

};

class UFortExpeditionListViewWidget : public UCommonUserWidget
{
	public:
	    MulticastDelegateProperty OnExpeditionSelected; // 0x230 Size: 0x10
	    MulticastDelegateProperty OnExpeditionListViewRefreshed; // 0x240 Size: 0x10
	    class UCommonListView* ExpeditionListView; // 0x250 Size: 0x8
	    FName CurrentTabNameId; // 0x258 Size: 0x8
	    EFortExpeditionListSort SortType; // 0x260 Size: 0x1
	    char UnknownData0[0x261]; // 0x261
	    void SetExpeditionListSortType(EFortExpeditionListSort InSortType); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    struct FText GetExpeditionListSortName(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortExpeditionListViewWidget");
			return (class UClass*)ptr;
		};

};

class UFortExpeditionMasterWidget : public UCommonActivatablePanel
{
	public:
	    char UnknownData0[0x338];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortExpeditionMasterWidget");
			return (class UClass*)ptr;
		};

};

class UFortExpeditionOverviewWidget : public UCommonUserWidget
{
	public:
	    class UCommonButton* TabButtonType; // 0x230 Size: 0x8
	    TArray<struct FExpeditionTabInfo> TabListRegistrationInfo; // 0x238 Size: 0x10
	    class UFortTabListWidgetBase* ExpeditionTabList; // 0x248 Size: 0x8
	    class UFortExpeditionListViewWidget* ExpeditionListView; // 0x250 Size: 0x8
	    char UnknownData0[0x258]; // 0x258
	    void UpdateExpeditionTabs(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnExpeditionTabSelected(FName TabNameID); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnExpeditionOverviewRefresh(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleExpeditionTabSelected(FName TabNameID); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleExpeditionTabButtonCreated(FName TabNameID, class UCommonButton* TabButton); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7d89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortExpeditionOverviewWidget");
			return (class UClass*)ptr;
		};

};

class UFortExpeditionPickVehicleWidget : public UCommonActivatablePanel
{
	public:
	    TWeakObjectPtr<UFortExpeditionItem*> Item; // 0x318 Size: 0x8
	    char UnknownData0[0x320]; // 0x320
	    void SetData(class UFortExpeditionItem* InItem); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7cc1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortExpeditionPickVehicleWidget");
			return (class UClass*)ptr;
		};

};

class UFortExpeditionReturnsWidget : public UCommonUserWidget
{
	public:
	    TWeakObjectPtr<UFortExpeditionItem*> Item; // 0x230 Size: 0x8
	    char UnknownData0[0x238]; // 0x238
	    void SetData(class UFortExpeditionItem* InItem); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnExpeditionInProgressUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7da1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortExpeditionReturnsWidget");
			return (class UClass*)ptr;
		};

};

class UFortExpeditionRewardsWidget : public UCommonUserWidget
{
	public:
	    MulticastDelegateProperty OnAllExpeditionsCollected; // 0x230 Size: 0x10
	    class UCommonTileView* RewardsTileView; // 0x240 Size: 0x8
	    bool bPendingCollection; // 0x248 Size: 0x1
	    char UnknownData0[0x249]; // 0x249
	    void RefreshRewardsUI(class UFortExpeditionItem* Expedition, bool bExpeditionSucceeded, TArray<struct FFortItemInstanceQuantityPair> Rewards); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void ProcessNextReward(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HandleCollectionExpeditionCompleted(bool bMcpSuccess, class UFortExpeditionItem* Expedition, bool bExpeditionSuccess, TArray<struct FFortItemInstanceQuantityPair> Rewards); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortExpeditionRewardsWidget");
			return (class UClass*)ptr;
		};

};

class UFortExpeditionSummaryWidget : public UCommonUserWidget
{
	public:
	    int AvailableExpeditions; // 0x230 Size: 0x4
	    int CompletedExpeditions; // 0x234 Size: 0x4
	    int LandVehiclesTotal; // 0x238 Size: 0x4
	    int LandVehiclesAvailable; // 0x23c Size: 0x4
	    int AirVehiclesTotal; // 0x240 Size: 0x4
	    int AirVehiclesAvailable; // 0x244 Size: 0x4
	    int SeaVehiclesTotal; // 0x248 Size: 0x4
	    int SeaVehiclesAvailable; // 0x24c Size: 0x4
	    int LandExpeditionsTotal; // 0x250 Size: 0x4
	    int LandExpeditionsAvailable; // 0x254 Size: 0x4
	    int AirExpeditionsTotal; // 0x258 Size: 0x4
	    int AirExpeditionsAvailable; // 0x25c Size: 0x4
	    int SeaExpeditionsTotal; // 0x260 Size: 0x4
	    int SeaExpeditionsAvailable; // 0x264 Size: 0x4
	    TArray<class UFortExpeditionItem*> InProgressExpeditions; // 0x268 Size: 0x10
	    char UnknownData0[0x278]; // 0x278
	    void UnbindInventoryDelegates(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnRefreshSummaryWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void BindInventoryDelegates(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortExpeditionSummaryWidget");
			return (class UClass*)ptr;
		};

};

class UFortExpeditionUtilities : public UBlueprintFunctionLibrary
{
	public:
	    static int TotalUnseenExpeditionsForTab(class UWidget* Widget, FName TabNameID); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static bool IsSquadOnExpedition(class UWidget* Widget, FName SquadId); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static struct FGameplayTag GetVehicleTagRequiredForExpedition(class UFortExpeditionItem* Expedition); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static bool GetVehicleTagFromSquadId(FName SquadId, struct FGameplayTag OutFoundVehicleTag); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static void GetTotalExpeditionVehiclesAvailable(class UWidget* Widget, class AFortPlayerController* FortPC, int OutLandVehicles, int OutLandVehiclesAvailable, int OutSeaVehicles, int OutSeaVehiclesAvailable, int OutAirVehicles, int OutAirVehiclesAvailable); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static void GetMatchedCriteriaTags(class UFortExpeditionItem* Expedition, TArray<class UFortItem*> SlottedItems, TArray<struct FGameplayTag> OutMatchedCriteria); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static bool GetExpeditionSquadsThatMatchRequirements(struct FGameplayTagContainer RequirementTags, class AFortPlayerController* FortPC, TArray<FName> OutExpeditionSquadIds); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static float GetExpeditionSquadPower(class AFortPlayerController* FortPC, FName SquadId); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static void GetAllExpeditionSquadIds(TArray<FName> OutExpeditionSquadIds); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static float CalculateTotalPower(class AFortPlayerController* FortPC, class UFortExpeditionItem* Expedition, FName SquadId, TArray<class UFortItem*> SlottedItems); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static void CalculateGlobalAndItemRatingModValuesBP(class UFortExpeditionItem* Expedition, TArray<class UFortItem*> SlottedItems, float GlobalPowerMod, TArray<float> SlottedItemMods); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static float CalculateExpeditionPercentageChanceForSuccess(class UFortExpeditionItem* Expedition, float TotalPower); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    static bool AreExpeditionsUnlocked(class UObject* WorldContextObject, struct FUniqueNetIdRepl UniqueId); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    static bool AreAnyExpeditionsComplete(class UWidget* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortExpeditionUtilities");
			return (class UClass*)ptr;
		};

};

class UFortExpeditionVehicleTileItemWidget : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    TWeakObjectPtr<UObject*> SquadId; // 0xb30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortExpeditionVehicleTileItemWidget");
			return (class UClass*)ptr;
		};

};

class UFortFavoriteIndicator : public UFortSimpleItemConditionIconIndicator
{
	public:
	    char UnknownData0[0x460];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortFavoriteIndicator");
			return (class UClass*)ptr;
		};

};

class UFortFeatureUnlockWidget : public UFortActivatablePanel
{
	public:
	    class UCommonWidgetSwitcher* MediaSwitcher; // 0x340 Size: 0x8
	    class UWidget* VideoContent; // 0x348 Size: 0x8
	    class UWidget* ImageContent; // 0x350 Size: 0x8
	    class UFortVideoPlayerWidget* VideoWidget; // 0x358 Size: 0x8
	    class UCommonLazyImage* ImageWidget; // 0x360 Size: 0x8
	    char UnknownData0[0x368]; // 0x368
	    void UpdateAsset(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetData(struct FString HomebaseNodeTemplateId); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void RefreshDataBP(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    class UMediaSource* GetVideo(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    struct FText GetTitle(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    struct TSoftObjectPtr<struct UTexture2D*> GetSmallIcon(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    struct TSoftObjectPtr<struct UTexture2D*> GetLargeIcon(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    struct FText GetDescription(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7c71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortFeatureUnlockWidget");
			return (class UClass*)ptr;
		};

};

class UFortMobileShareButton : public UCommonButton
{
	public:
	    void SetShareParams(struct FString URL, struct FText Description); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void OnOSImageEnumSet(EFortFortMobileShareButtonOS OSType); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7489];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMobileShareButton");
			return (class UClass*)ptr;
		};

};

class UFortFriendCodeEntryBase : public UFortMobileShareButton
{
	public:
	    struct FFriendCode FriendCode; // 0xb58 Size: 0x20
	    class UCommonTextBlock* LinkDataTextBox; // 0xb78 Size: 0x8
	    struct FString DebugName; // 0xb80 Size: 0x10
	    int LengthOfCode; // 0xb90 Size: 0x4
	    char UnknownData0[0x4]; // 0xb94
	    struct FText SharedMessage; // 0xb98 Size: 0x18
	    struct FText SharedMessageNoInvite; // 0xbb0 Size: 0x18

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortFriendCodeEntryBase");
			return (class UClass*)ptr;
		};

};

class UFortFriendCodeListBase : public UFortActivatablePanel
{
	public:
	    TArray<struct FFriendCode> BacchusFriendCodes; // 0x340 Size: 0x10
	    class UFortFriendCodeEntryBase* FriendCodeEntryClass; // 0x350 Size: 0x8
	    class UDynamicEntryBox* EntryBox_FriendCodes; // 0x358 Size: 0x8
	    class URichTextBlock* WarningText; // 0x360 Size: 0x8
	    char UnknownData0[0x368]; // 0x368
	    void JustDesc(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void DescAndURL(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void CloseAndPopDialog(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7c79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortFriendCodeListBase");
			return (class UClass*)ptr;
		};

};

class UFortFriendLinkPanel : public UFortActivatablePanel
{
	public:
	    class UCommonButton* Button_ShareButton; // 0x340 Size: 0x8
	    char UnknownData0[0x348]; // 0x348
	    void OnShareButtonTypeSet(EShareButtonType Type); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnCopiedToClipboard(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7c99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortFriendLinkPanel");
			return (class UClass*)ptr;
		};

};

class UFortFrontEndContext : public UFortLocalPlayerSubsystem
{
	public:
	    char UnknownData0[0x8];
	    MulticastDelegateProperty OnFrontEndCameraChanged; // 0x30 Size: 0x10
	    MulticastDelegateProperty OnLobbyBackgroundChanged; // 0x40 Size: 0x10
	    MulticastDelegateProperty OnLobbyEmptyPlayerClicked; // 0x50 Size: 0x10
	    MulticastDelegateProperty OnLobbyPlayerGadgetsClicked; // 0x60 Size: 0x10
	    MulticastDelegateProperty OnLobbyPlayerPadHovered; // 0x70 Size: 0x10
	    MulticastDelegateProperty OnLobbyPlayerPadUnhovered; // 0x80 Size: 0x10
	    MulticastDelegateProperty OnLobbyPlayerHovered; // 0x90 Size: 0x10
	    MulticastDelegateProperty OnLobbyPlayerUnhovered; // 0xa0 Size: 0x10
	    MulticastDelegateProperty OnLobbyPlayerSelected; // 0xb0 Size: 0x10
	    MulticastDelegateProperty OnLobbyPlayerUnselected; // 0xc0 Size: 0x10
	    MulticastDelegateProperty OnPartySuggestionAccepted; // 0xd0 Size: 0x10
	    MulticastDelegateProperty OnLobbyPlayerTalkingChanged; // 0xe0 Size: 0x10
	    MulticastDelegateProperty OnLobbyPlayerMutingChanged; // 0xf0 Size: 0x10
	    MulticastDelegateProperty OnLobbyPlayersStoppedTalking; // 0x100 Size: 0x10
	    MulticastDelegateProperty OnRadialPickerStatusChanged; // 0x110 Size: 0x10
	    MulticastDelegateProperty OnTheaterPinClicked; // 0x120 Size: 0x10
	    MulticastDelegateProperty OnSetPreviewedSceneTheater; // 0x130 Size: 0x10
	    MulticastDelegateProperty OnTheaterSelected; // 0x140 Size: 0x10
	    MulticastDelegateProperty OnTheaterDataChanged; // 0x150 Size: 0x10
	    MulticastDelegateProperty OnTheaterTileClicked; // 0x160 Size: 0x10
	    MulticastDelegateProperty OnTheaterTileUnselected; // 0x170 Size: 0x10
	    MulticastDelegateProperty OnTheaterTileDoubleClicked; // 0x180 Size: 0x10
	    MulticastDelegateProperty OnTheaterTileFocused; // 0x190 Size: 0x10
	    MulticastDelegateProperty OnTheaterTileUnfocused; // 0x1a0 Size: 0x10
	    MulticastDelegateProperty OnVaultItemViewed; // 0x1b0 Size: 0x10
	    MulticastDelegateProperty OnVaultItemsViewed; // 0x1c0 Size: 0x10
	    MulticastDelegateProperty OnSeasonTabVariantPreviewInfoChanged; // 0x1d0 Size: 0x10
	    MulticastDelegateProperty OnPlayerLoggedIn; // 0x1e0 Size: 0x10
	    MulticastDelegateProperty OnPlayerLoggedOut; // 0x1f0 Size: 0x10
	    MulticastDelegateProperty OnMainTabSelected; // 0x200 Size: 0x10
	    MulticastDelegateProperty OnSocialImportClosed; // 0x210 Size: 0x10
	    char UnknownData1[0x8]; // 0x220
	    struct FFortFrontEndFeatureStruct* Features; // 0x228 Size: 0x18
	    char UnknownData2[0xc0]; // 0x240
	    struct FFortSavedModeLoadout CachedModeLoadout; // 0x300 Size: 0x20
	    char UnknownData3[0x8]; // 0x320
	    struct FUnlockableVariantPreviewInfo SeasonTabVariantPreviewInfo; // 0x328 Size: 0x28
	    char UnknownData4[0x350]; // 0x350
	    void ViewVaultItemsFromOffer(struct FCatalogOffer CatalogOffer, bool bIgnoreCurrentlyEquppedFavorites); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ViewVaultItems(TArray<class UFortItem*> ItemsToView, bool bIgnoreCurrentlyEquppedFavorites); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ViewVaultItemFromDefinition(class UFortItemDefinition* ItemToViewDefinition, bool bIgnoreCurrentlyEquppedFavorites); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void ViewVaultItem(class UFortItem* ItemToView, bool bIgnoreCurrentlyEquppedFavorites); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void UpdateNewAccountItemBangCounts(class UFortInventoryContext* InventoryContext); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool TryGetAttributeInfo(struct FGameplayAttribute GameplayAttribute, struct FFortAttributeInfo OutAttribute); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SkipInitialBenchmark(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    class UFortSocialImportPanel* ShowSocialImport(class UFortSocialImportPanel* PanelClass); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void ShowAthenaStoreNewItemBang(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    bool ShouldShowSocialImport(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    bool ShouldShowLoginMessage(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    bool ShouldRunInitialBenchmark(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void SetSelectedTheater(struct FString TheaterId); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void SetSeenLoginMessage(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void SetSeasonTabVariantPreviewInfo(struct FUnlockableVariantPreviewInfo Info); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void SetPersonalHeroChoice(class UFortHero* Hero, struct FDisplayManagerVariantData VariantData); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void SetLocalVariantPreview(class UAthenaCosmeticItemDefinition* CosmeticItem, struct FGameplayTag VariantChannelTag, struct FGameplayTag VariantTag); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void SetHeroChoice(int PartyMemberIndex, class UFortHero* Hero, struct FDisplayManagerVariantData VariantData); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void SetFrontEndVisibility(bool bHideHeader, bool bHideFooter, bool bHideChatWidget); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void SetFrontEndCamera(EFrontEndCamera NewState); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void SetDefaultLocalVariantPreview(class UAthenaCosmeticItemDefinition* CosmeticItem); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void SetCurrentLockerSubslotIndex(int NewIndex); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void SendPlayQuestAnalytic(class UFortQuestItem* QuestItem); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void SendFrontendEnteredEvent(); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    bool SelectTileForQuest(class UFortQuestItem* QuestItem, float OutCriticalMissionDifficultyOverrideMin, float OutCriticalMissionDifficultyOverrideMax); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    void SelectGadgetForSlot(int Slot, class UFortItemDefinition* GadgetDefinition); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    void SelectDefaultTheaterTile(); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    void SelectDefaultTheater(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    void RunBenchmarkAndApplyBestSettings(); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    void PushContentWidget_Adv(class UWidget* Widget, bool bHideHeader, bool bHideFooter, bool bHideChatWidget); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    void PreviewCatalogOfferItems(struct FCatalogOffer CatalogOffer); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    void PlayLevelUpEffect(); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    void PlayEvolutionEffect(); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    void OnPlayerProfileInitialized(); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    bool IsActiveTileMissionValid(); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    bool Is4PlayerTile(class AFortTheaterMapTile* Tile); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    void HideAthenaStoreNewItemBang(); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    void HandleDynamicSocialImportClosed(); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    struct FDisplayManagerVariantData GetVariantDataForMemberIndex(int MemberIndex); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    TArray<class UFortGadgetItemDefinition*> GetUnlockedGadgetDefinitions(); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    class UObject* GetUITestingClass(); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    bool GetTileMissionDetails(class AFortTheaterMapTile* Tile, struct FFortMissionDetails MissionDetails); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    EFortTheaterType GetTheaterType(struct FString TheaterId); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    int GetTheaterRegionCount(struct FString TheaterId); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    struct FText GetTheaterName(struct FString TheaterId); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    bool GetTheaterData(struct FString TheaterId, struct FFortTheaterMapData OutTheaterData); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    struct FString GetSelectedTheaterId(); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    bool GetSelectedTheaterData(struct FFortTheaterMapData OutTheaterData); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    void GetSelectableGadgets(TArray<class UFortWorldItem*> SelectableGadgets, TArray<class UFortWorldItem*> LastSelectedGadgets); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    struct FUnlockableVariantPreviewInfo GetSeasonTabVariantPreviewInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    EFortReturnToFrontendBehavior GetReturnToFrontendBehavior(); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    struct FText GetRequirementText(struct FFortRequirementsInfo InRequirements); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    class AActor* GetPrefabActorForCurrentDisplayedItem(); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    void GetPostMaxAccountLevelUpRewards(TArray<struct FFortItemQuantityPair> Rewards, int RewardOffset); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    void GetOutpostStructureUpgradeCost(int TheaterSlot, int UpgradeLevel, class UFortOutpostItemDefinition* OutpostStructure, TArray<struct FFortItemQuantityPair> OutWorldItems, TArray<struct FFortItemQuantityPair> OutAccountItems); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    int GetOutpostStructureMaxLevel(int TheaterSlot, class UFortOutpostItemDefinition* OutpostStructure); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    bool GetOutpostCoreLevelByTheaterId(struct FString TheaterId, int OutCoreLevel); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    bool GetOutpostCoreLevelByItemDefinition(class UFortOutpostItemDefinition* OutpostCoreItemDef, int OutCoreLevel); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x7fe1]; // 0x7fe1
	    class UMeshComponent* GetMeshForCurrentDisplayedItem(); // 0x0 Size: 0x7fe1
	    char UnknownData63[0x7fe1]; // 0x7fe1
	    struct FText GetMCPRegionText(); // 0x0 Size: 0x7fe1
	    char UnknownData64[0x7fe1]; // 0x7fe1
	    struct FText GetMCPRegion(); // 0x0 Size: 0x7fe1
	    char UnknownData65[0x7fe1]; // 0x7fe1
	    struct FGameDifficultyInfo GetMaxAvailableDifficulty(bool bIncludeMissionAlertTiles); // 0x0 Size: 0x7fe1
	    char UnknownData66[0x7fe1]; // 0x7fe1
	    FName GetLobbyBackgroundLevelName(); // 0x0 Size: 0x7fe1
	    char UnknownData67[0x7fe1]; // 0x7fe1
	    class UFortItemDefinition* GetItemFromItemQuantityPair(struct FFortItemQuantityPair InPair); // 0x0 Size: 0x7fe1
	    char UnknownData68[0x7fe1]; // 0x7fe1
	    class AFortPlayerPawn* GetHeroPlayerPawnForCurrentDisplayedItem(); // 0x0 Size: 0x7fe1
	    char UnknownData69[0x7fe1]; // 0x7fe1
	    class AFortPlayerPawn* GetHeroPlayerPawnByIndex(int PartyMemberIndex); // 0x0 Size: 0x7fe1
	    char UnknownData70[0x7fe1]; // 0x7fe1
	    class UFortWorldItemDefinition* GetHarvestingToolForLevel(int TheaterSlot, int InHarvestingOptimizerLevel); // 0x0 Size: 0x7fe1
	    char UnknownData71[0x7fe1]; // 0x7fe1
	    EFrontEndCamera GetFrontEndCamera(); // 0x0 Size: 0x7fe1
	    char UnknownData72[0x7fe1]; // 0x7fe1
	    class AFortTheaterMapTile* GetFocusedTile(); // 0x0 Size: 0x7fe1
	    char UnknownData73[0x7fe1]; // 0x7fe1
	    bool GetFocusedOrActiveTileMissionDetails(struct FFortMissionDetails MissionDetails); // 0x0 Size: 0x7fe1
	    char UnknownData74[0x7fe1]; // 0x7fe1
	    class AFortTheaterMapTile* GetFocusedOrActiveTile(); // 0x0 Size: 0x7fe1
	    char UnknownData75[0x7fe1]; // 0x7fe1
	    struct FText GetFeatureStateReasonText(EFortFrontEndFeatureStateReason Reason); // 0x0 Size: 0x7fe1
	    char UnknownData76[0x7fe1]; // 0x7fe1
	    void GetFeatureState(EFortFrontEndFeature Feature, EFortFrontEndFeatureState OutFeatureState, EFortFrontEndFeatureStateReason OutReason); // 0x0 Size: 0x7fe1
	    char UnknownData77[0x7fe1]; // 0x7fe1
	    int GetFabricatorStoredGooAmount(int TheaterSlot); // 0x0 Size: 0x7fe1
	    char UnknownData78[0x7fe1]; // 0x7fe1
	    int GetFabricatorIncomingGooAmount(int TheaterSlot); // 0x0 Size: 0x7fe1
	    char UnknownData79[0x7fe1]; // 0x7fe1
	    int GetFabricatorDisintegrationSecondsRemaining(int TheaterSlot); // 0x0 Size: 0x7fe1
	    char UnknownData80[0x7fe1]; // 0x7fe1
	    EFrontEndCamera GetDesiredPlayButtonCamera(); // 0x0 Size: 0x7fe1
	    char UnknownData81[0x7fe1]; // 0x7fe1
	    FName GetDefenderSquadIDByTheaterID(struct FString TheaterId); // 0x0 Size: 0x7fe1
	    char UnknownData82[0x7fe1]; // 0x7fe1
	    struct FText GetCurrentTheaterName(); // 0x0 Size: 0x7fe1
	    char UnknownData83[0x7fe1]; // 0x7fe1
	    int GetCurrentLockerSubslotIndex(); // 0x0 Size: 0x7fe1
	    char UnknownData84[0x7fe1]; // 0x7fe1
	    TArray<struct FGameDifficultyInfo> GetAvailableDifficulties(bool bIncludeMissionAlertTiles); // 0x0 Size: 0x7fe1
	    char UnknownData85[0x7fe1]; // 0x7fe1
	    struct FFortMultiSizeBrush GetAttributeIcon(struct FFortAttributeInfo InAttribute, struct FGameplayTagContainer InRequiredTags); // 0x0 Size: 0x7fe1
	    char UnknownData86[0x7fe1]; // 0x7fe1
	    struct FText GetAttributeDisplayName(struct FFortAttributeInfo InAttribute, struct FGameplayTagContainer InRequiredTags); // 0x0 Size: 0x7fe1
	    char UnknownData87[0x7fe1]; // 0x7fe1
	    struct FText GetAttributeDescription(struct FFortAttributeInfo InAttribute, struct FGameplayTagContainer InRequiredTags); // 0x0 Size: 0x7fe1
	    char UnknownData88[0x7fe1]; // 0x7fe1
	    bool GetAllTheaterData(TArray<struct FFortTheaterMapData> OutAllTheaterData); // 0x0 Size: 0x7fe1
	    char UnknownData89[0x7fe1]; // 0x7fe1
	    bool GetActiveTileMissionDetails(struct FFortMissionDetails MissionDetails); // 0x0 Size: 0x7fe1
	    char UnknownData90[0x7fe1]; // 0x7fe1
	    class AFortTheaterMapTile* GetActiveTile(); // 0x0 Size: 0x7fe1
	    char UnknownData91[0x7fe1]; // 0x7fe1
	    void GetAccountLevelUpRewards(TArray<struct FFortItemQuantityPair> Rewards, int AccountLevel); // 0x0 Size: 0x7fe1
	    char UnknownData92[0x7fe1]; // 0x7fe1
	    void ForceSetFeatureState(EFortFrontEndFeature Feature, EFortFrontEndFeatureState State, EFortFrontEndFeatureStateReason Reason); // 0x0 Size: 0x7fe1
	    char UnknownData93[0x7fe1]; // 0x7fe1
	    void DisplayAthenaCosmetic(class UAthenaCosmeticItemDefinition* CosmeticItemDef, int VariantPreviewIdx); // 0x0 Size: 0x7fe1
	    char UnknownData94[0x7fe1]; // 0x7fe1
	    void ClearSelectedTheater(); // 0x0 Size: 0x7fe1
	    char UnknownData95[0x7fe1]; // 0x7fe1
	    void ClearLocalPreview(bool StopUsingLocalPreview); // 0x0 Size: 0x7fe1
	    char UnknownData96[0x7fe1]; // 0x7fe1
	    bool CanShowLockerSlotType(EAthenaCustomizationCategory SlotType); // 0x0 Size: 0x7fe1
	    char UnknownData97[0x7fe1]; // 0x7fe1
	    bool CanFindTileForQuest(class UFortQuestItem* QuestItem); // 0x0 Size: 0x7fe1
	    char UnknownData98[0x7fe1]; // 0x7fe1
	    bool CanCompleteQuestInFocusedOrActiveTileMission(class UFortQuestItem* QuestItem); // 0x0 Size: 0x7fe1
	    char UnknownData99[0x7fe1]; // 0x7fe1
	    bool CanCompleteQuestInActiveTileMission(class UFortQuestItem* QuestItem); // 0x0 Size: 0x7fe1
	    char UnknownData100[0x7fe1]; // 0x7fe1
	    void BroadcastMainTabSelected(FName TabName); // 0x0 Size: 0x7fe1
	    char UnknownData101[0x7fe1]; // 0x7fe1
	    void BindToFeatureStateAndInitialize(EFortFrontEndFeature Feature, __int64/*DelegateProperty*/ Delegate); // 0x0 Size: 0x7fe1
	    char UnknownData102[0x7fe1]; // 0x7fe1
	    bool AreProfilesAvailableToWIFE(); // 0x0 Size: 0x7fe1
	    char UnknownData103[0x-7c01];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortFrontEndContext");
			return (class UClass*)ptr;
		};

};

class AFortFrontendLevelScriptActor : public AFortLevelScriptActor
{
	public:
	    struct TSoftObjectPtr<struct AFortItemPreviewPedestal*> CommanderPreviewPedestalActor; // 0x348 Size: 0x28
	    struct TSoftObjectPtr<struct AFortItemPreviewPedestal*> HeroLoadoutPreviewPedestalActor; // 0x370 Size: 0x28
	    char UnknownData0[0x398]; // 0x398
	    struct TSoftObjectPtr<struct AFortItemPreviewPedestal*> GetHeroLoadoutPreviewPedestalActor(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static class AFortFrontendLevelScriptActor* GetFrontendLevelScript(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    struct TSoftObjectPtr<struct AFortItemPreviewPedestal*> GetCommanderPreviewPedestalActor(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7c49];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortFrontendLevelScriptActor");
			return (class UClass*)ptr;
		};

};

class UFortGameFeedbackBase : public UFortActivatablePanel
{
	public:
	    class UEditableText* SubjectEditable; // 0x340 Size: 0x8
	    class UTextBlock* PlayerNameText; // 0x348 Size: 0x8
	    class UMultiLineEditableText* BodyEditable; // 0x350 Size: 0x8
	    class UCommonButton* PlayerReportingCategoryButton; // 0x358 Size: 0x8
	    class UMenuAnchor* PlayerReportingCategoryMenuAnchor; // 0x360 Size: 0x8
	    class UCommonButton* PlayerNameButton; // 0x368 Size: 0x8
	    class UMenuAnchor* PlayerNameMenuAnchor; // 0x370 Size: 0x8
	    class UEditableText* BodyEditable_SingleLine; // 0x378 Size: 0x8
	    char UnknownData0[0x50]; // 0x380
	    class UCommonButtonGroup* ButtonGroup; // 0x3d0 Size: 0x8
	    char UnknownData1[0x80]; // 0x3d8
	    class UFortDropdownDelegateRegistrar* PlayerReportingCategoryDropdownRegistrar; // 0x458 Size: 0x8
	    class UFortDropdownDelegateRegistrar* PlayerNameDropdownRegistrar; // 0x460 Size: 0x8
	    struct FPlayerNameInfoContainer PlayerNameInfoContainer; // 0x468 Size: 0x18
	    char UnknownData2[0x480]; // 0x480
	    void SubmitFeedback(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SelectSpectateTarget(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SelectKiller(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnReportingCategoryChanged(int CategoryIndex); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnPlayerReportingCategorySelected(class UCommonButton* SelectedButton, int ButtonIndex); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnPlayerNameSelectedEvent(struct FText Name); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnPlayerNameSelected(class UCommonButton* SelectedButton, int ButtonIndex); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnInitiateDebugInfoForFeedbackComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnFeedbackTypeSelected(class UCommonButton* SelectedButton, int ButtonIndex); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void OnFeedbackTypeChanged(EFortUIGameFeedbackType FeedBackType); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void InitiateDebugInfoForFeedback(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    bool HasSpectateTarget(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    bool HasSelectedPlayer(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    bool HasSelectedCategory(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    bool HasKiller(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    static TArray<struct FText> GetPlayerReportingCategoryLabels(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    struct FPlayerNameInfoContainer GetPlayerNameInfoContainer(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    static struct FText GetDisplayTextForPlayerReportingCategoryBP(int CategoryIndex); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    ESlateVisibility GetButtonVisibilityByUIFeedbackType(EFortUIGameFeedbackType UIFeedbackType); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void CancelFeedback(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void AddButtonWithFeedbackType(class UCommonButton* Button, EFortUIGameFeedbackType UIFeedbackType); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x-7b61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortGameFeedbackBase");
			return (class UClass*)ptr;
		};

};

class UFortGameOptions : public UFortOptionsTab
{
	public:
	    TArray<class UFortHUDVisibilityData*> HUDData; // 0x280 Size: 0x10
	    char UnknownData0[0x290]; // 0x290
	    void UpdatePossibleLanguages(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void UpdateHUDSettings(struct FGameplayTag HUDMapping, bool NewVisibility); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetControllerPlatform(struct FString InControllerPlatform); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleGamePadToggleMode(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool GetHUDSettings(struct FGameplayTag HUDMapping); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    struct FString GetControllerPlatform(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ConstructHUDTagList(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7d51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortGameOptions");
			return (class UClass*)ptr;
		};

};

class UFortGamepadCustomListItem : public UCommonButton
{
	public:
	    char UnknownData0[0xb30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortGamepadCustomListItem");
			return (class UClass*)ptr;
		};

};

class UFortInputOptions : public UFortOptionsTab
{
	public:
	    TArray<class UFortOptionsMenuInputData*> InputData; // 0x280 Size: 0x10
	    class UCommonListView* InputCommonListView; // 0x290 Size: 0x8
	    class UCommonTextBlock* TooltipDisplay; // 0x298 Size: 0x8
	    char UnknownData0[0x2a0]; // 0x2a0
	    void HandleUsingGamepadChanged(ECommonInputType NewInputType); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    class UWidget* GetListWidget(class UObject* Item); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    int GetInputDataIndexForActionName(FName ActionName); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    struct FText GetBindedKeyNameBP(int KeyBind, bool IsPrimary); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    TArray<class UFortOptionsMenuInputData*> GetActionItemsInGroup(EFortInputActionGroup InputActionGroup); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    struct FFortActionBeingUnbound GetActionBeingUnbound(bool bIsPrimarySlot, int Input, struct FKey NewKey); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ConstructKeyBindList(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void ChangeBinding(bool bIsPrimarySlot, int Input, struct FKey NewKey); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7d39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortInputOptions");
			return (class UClass*)ptr;
		};

};

class UFortGamepadInputOptions : public UFortInputOptions
{
	public:
	    void SetControllerPlatform(struct FString InControllerPlatform); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void ResetCustomGamepadToDefault(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool IsCustomGamepadConfig(struct FString ConfigName); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool HasCustomGamepadBindingChanges(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleGamePadToggleMode(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    struct FString GetControllerPlatform(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void EnableAnalogCursor(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void DisableAnalogCursor(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool AreAllImportantActionsBound(TArray<struct FText> OutUnboundScreenLabels, bool bRichText); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7d39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortGamepadInputOptions");
			return (class UClass*)ptr;
		};

};

class UFortGiftBoxButton : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    class UFortGiftBoxItemDefinition* GiftBoxDefinition; // 0xb30 Size: 0x8
	    class UCommonLazyImage* Image_Gift; // 0xb38 Size: 0x8
	    char UnknownData1[0xb40]; // 0xb40
	    void PlayGiftSelectedAnimation(bool bIsSelected); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-74a1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortGiftBoxButton");
			return (class UClass*)ptr;
		};

};

class UFortGiftingScreen : public UFortActivatablePanelWithItemPreview
{
	public:
	    class UCommonButtonGroup* TabButtonGroup; // 0x438 Size: 0x8
	    TArray<struct TSoftObjectPtr<struct UFortGiftBoxItemDefinition*>> GiftBoxes; // 0x440 Size: 0x10
	    TArray<class UFortGiftBoxItemDefinition*> GiftBoxItemDefs; // 0x450 Size: 0x10
	    class UFortGiftBoxButton* SelectedGiftBoxButton; // 0x460 Size: 0x8
	    class UFortStoreFrontOfferInfo* OfferInfo; // 0x468 Size: 0x8
	    TArray<class UFortUserDetails*> UserDetailArray; // 0x470 Size: 0x10
	    class UFortUserDetails* LocalPlayerDetails; // 0x480 Size: 0x8
	    struct FText DefaultGiftMessage; // 0x488 Size: 0x18
	    TArray<struct FGiftingErrorText> GiftingErrorMessages; // 0x4a0 Size: 0x10
	    struct FGiftingErrorText GiftingErrorMessageDefault; // 0x4b0 Size: 0x38
	    int PersonalizedMessageLength; // 0x4e8 Size: 0x4
	    char UnknownData0[0x3c]; // 0x4ec
	    class UCommonTextBlock* Text_ItemName; // 0x528 Size: 0x8
	    class UImage* Image_RecipientCurrency; // 0x530 Size: 0x8
	    class UCommonTextBlock* Text_Price; // 0x538 Size: 0x8
	    class UCommonTextBlock* Text_GiftCount; // 0x540 Size: 0x8
	    class UCommonTextBlock* Text_FriendCount; // 0x548 Size: 0x8
	    class UCommonTextBlock* Text_CharCount; // 0x550 Size: 0x8
	    class UCommonListView* ListView_Friends; // 0x558 Size: 0x8
	    class UCommonButton* Button_Continue; // 0x560 Size: 0x8
	    class UCommonButton* Button_Send; // 0x568 Size: 0x8
	    class UCommonTileView* TileView_GiftBoxes; // 0x570 Size: 0x8
	    class UCommonListView* ListView_ChosenRecipients; // 0x578 Size: 0x8
	    class UMultiLineEditableText* Text_EditableMessage; // 0x580 Size: 0x8
	    char UnknownData1[0x588]; // 0x588
	    void SetOffer(class UFortStoreFrontOfferInfo* NewOfferInfo); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnOfferSet(class UFortStoreFrontOfferInfo* NewOfferInfo); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnMoveToGiftWrapStep(bool bGiftingToSelf); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnMoveToFriendSelectStep(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnGiftingTimerEnded(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnEndGiftingSubmission(bool bSuccess); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnBeginGiftingSubmission(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void HandleMessageChanged(struct FText InText); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void FocusFriendsList(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void FocusEditableTextMessage(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void DynamicHandleGiftSent(bool bSuccess, TArray<struct FString> IneligibleAccounts, TArray<struct FString> ErrorCodes); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void AllowGiftWrapSelection(bool bIsAllowed); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x-7a59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortGiftingScreen");
			return (class UClass*)ptr;
		};

};

class UFortUserDetails : public UObject
{
	public:
	    char UnknownData0[0x68];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUserDetails");
			return (class UClass*)ptr;
		};

};

class UFortGiftingUserItem : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    class UFortUserDetails* ItemData; // 0xb30 Size: 0x8
	    class UCommonTextBlock* Text_DisplayName; // 0xb38 Size: 0x8
	    char UnknownData1[0xb40]; // 0xb40
	    void UpdateMessageText(struct FText NewMessage); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetSelectionState(ESelectionState NewState, bool bAnimateOnSelect); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-74a1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortGiftingUserItem");
			return (class UClass*)ptr;
		};

};

class UFortGlobalActionDetailsDataSource : public UInterface
{
	public:
	    void RemoveOnChangeDelegate(__int64/*DelegateProperty*/ InDelegate); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    struct FFortGlobalActionDetails GetValue(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void AddOnChangeDelegate(__int64/*DelegateProperty*/ InDelegate); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortGlobalActionDetailsDataSource");
			return (class UClass*)ptr;
		};

};

class UFortGlobalUIContext : public UFortLocalPlayerSubsystem
{
	public:
	    char UnknownData0[0x8];
	    MulticastDelegateProperty SubGameChanged; // 0x30 Size: 0x10
	    MulticastDelegateProperty PlayerControllerChanged; // 0x40 Size: 0x10
	    char UnknownData1[0x18]; // 0x50
	    MulticastDelegateProperty OnKeybindsChanged; // 0x68 Size: 0x10
	    MulticastDelegateProperty OnInputActionHoldStarted; // 0x78 Size: 0x10
	    MulticastDelegateProperty OnInputActionHoldStopped; // 0x88 Size: 0x10
	    MulticastDelegateProperty OnEnterVehicleDriver; // 0x98 Size: 0x10
	    MulticastDelegateProperty OnEnterVehiclePassenger; // 0xa8 Size: 0x10
	    MulticastDelegateProperty OnExitVehicle; // 0xb8 Size: 0x10
	    MulticastDelegateProperty OnTeamPowerChanged; // 0xc8 Size: 0x10
	    MulticastDelegateProperty DragAndDropStartedDelegate; // 0xd8 Size: 0x10
	    MulticastDelegateProperty DragAndDropEndedDelegate; // 0xe8 Size: 0x10
	    MulticastDelegateProperty OnScoreReportChanged; // 0xf8 Size: 0x10
	    MulticastDelegateProperty OnContextHelpChanged; // 0x108 Size: 0x10
	    MulticastDelegateProperty OnItemReceivedNotificationShown; // 0x118 Size: 0x10
	    MulticastDelegateProperty OnQueryFortBackendVersionComplete; // 0x128 Size: 0x10
	    MulticastDelegateProperty OnLoadingScreenVisibilityChanged; // 0x138 Size: 0x10
	    MulticastDelegateProperty OnLocalPlayerControllerConnectionChanged; // 0x148 Size: 0x10
	    char UnknownData2[0x18]; // 0x158
	    __int64/*MapProperty*/ MessageManagersByName; // 0x170 Size: 0x50
	    __int64/*MapProperty*/ Features; // 0x1c0 Size: 0x50
	    char UnknownData3[0x140]; // 0x210
	    class UAthenaMatchReadyDesktopPopup* AthenaMatchReadyNotificationWidget; // 0x350 Size: 0x8
	    char UnknownData4[0x10]; // 0x358
	    class UFortHelpItem* ActiveContextSpecificHelpItem; // 0x368 Size: 0x8
	    bool bIsUIVisible; // 0x370 Size: 0x1
	    bool bShowRateWidget; // 0x371 Size: 0x1
	    bool bIsAllContentInstalledCache; // 0x372 Size: 0x1
	    char UnknownData5[0x5]; // 0x373
	    struct FText FeedbackTitle; // 0x378 Size: 0x18
	    struct FDateTime FirstLoginTime; // 0x390 Size: 0x8
	    struct FTimerHandle AddictionMsgTimer; // 0x398 Size: 0x8
	    struct FUniqueNetIdRepl CurrentLocalPlayerUniqueNetId; // 0x3a0 Size: 0x28
	    char UnknownData6[0x3c8]; // 0x3c8
	    void UnregisterScriptedActions(TArray<class AFortScriptedAction*> ScriptedActions); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void UnregisterScriptedAction(class AFortScriptedAction* ScriptedAction); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void UnregisterInputAction(class UUserWidget* UserWidget, struct FDataTableRowHandle InputActionRow); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void UnbindToFeatureState(EFortUIFeature Feature, __int64/*DelegateProperty*/ Delegate); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void TriggerUIFeedbackEvent(FName EventName); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    bool ShowWebURL(struct FString URL, EFortUrlType URLType); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    bool ShowVehicleHealthBarOnPlayerHUD(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void ShowConsoleAccountPicker(int ControllerIndex, __int64/*DelegateProperty*/ CompletionDelegate); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void ShowBang(EFortBangType Type); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void ShowAthenaMatchReadyExternalNotificationWindow(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    bool ShouldShowRateWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    bool ShouldCloseMenuOnEscape(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void SetSubGame(ESubGame SubGame); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void SetRatingWidgetFeedbackTitle(struct FText Title); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void SetInputMode(EFortInputMode InMode); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void SetHideStwItemRefundHelp(bool bInHideHelp); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void SetHidePerkRecombobulatorHelp(bool bInHideHelp); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void SetCurrentInputPresetName(struct FString InputPresetName); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void SetCurrentCustomInputTemplatePresetName(struct FString InputPresetName); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void SetCreativeMode(bool IsCreativeMode); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void SetContextHelpItem(class UFortHelpItem* ContextSpecificHelpItem); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void SetBangFromCount(EFortBangType Type, int Count); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void SendUINavigationAnalytic(struct FString Destination, bool bUserInitiated); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    void SendLeaveZoneAnalytic(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    void SendExperienceRatingAnalytic(struct FString RatingType, struct FString FeedbackSentBy, struct FText RatingQuestion, int StarCount, struct FString GameSessionId, struct FString Comment); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    void RunLauncherWithOptions(struct FString Options); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    void ReturnToSubGameSelect(); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    void RegisterScriptedActions(TArray<class AFortScriptedAction*> ScriptedActions); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    void RegisterScriptedAction(class AFortScriptedAction* ScriptedAction); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    void RegisterInputAction(class UUserWidget* UserWidget, struct FDataTableRowHandle InputActionRow, __int64/*DelegateProperty*/ CommitedEvent, int InFilterPriority); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    void QuitGame(); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    void QueryGameBackendVersion(); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    void ProcessConfirmationResult(EFortDialogResult InResult, FName InResultName, struct FFortDialogDescription_NUI ConfirmationDescription, bool bWaitingForLatentAction, struct FFortDialogExternalLatentActionHandle WaitingDialogHandle); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnQueryFortBackendVersionDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnLocalPlayerControllerConnectionChangedDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnLoadingScreenVisibilityChangedDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    void Logout(); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    bool IsUsingGamepad(); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    bool IsUIVisible(); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    bool IsPendingLogout(); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    bool IsMobileApp(); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    bool IsInZone(); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    bool IsInOutpostZone(); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    bool IsHUDVisible(); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    bool IsGamepadAttached(); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    bool IsDesktopPlatform(); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    bool IsCustomGamepadConfig(int ConfigIndex); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    bool IsCurrentlyShowingLoadingScreen(); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    bool IsCreativeModeAccessLimited(); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    bool IsBluGloEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    bool IsBattleRoyaleMatchmakingEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    bool IsAllContentInstalled(); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    void InputActionHoldStopped(FName InputActionName, bool bCompletedSuccessfully); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    void InputActionHoldStarted(FName InputActionName, float HoldDuration); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    void HideBang(EFortBangType Type); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    bool HasCompletedOnboardingObjective(struct FDataTableRowHandle Objective); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x7fe1]; // 0x7fe1
	    bool HasAccesstoMultipleSubGames(); // 0x0 Size: 0x7fe1
	    char UnknownData63[0x7fe1]; // 0x7fe1
	    struct FString GetWatermark(); // 0x0 Size: 0x7fe1
	    char UnknownData64[0x7fe1]; // 0x7fe1
	    FName GetVehicleJumpActionName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData65[0x7fe1]; // 0x7fe1
	    FName GetVehicleExitActionName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData66[0x7fe1]; // 0x7fe1
	    FName GetVehicleChangeSeatActionName(); // 0x0 Size: 0x7fe1
	    char UnknownData67[0x7fe1]; // 0x7fe1
	    FName GetUseActionName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData68[0x7fe1]; // 0x7fe1
	    FName GetTrapPickerActionName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData69[0x7fe1]; // 0x7fe1
	    FName GetTrapHotbarActionName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData70[0x7fe1]; // 0x7fe1
	    FName GetTrapConfirmActionName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData71[0x7fe1]; // 0x7fe1
	    void GetTopLevelHelpItems(TArray<class UFortHelpItem*> ActiveHelpEntries); // 0x0 Size: 0x7fe1
	    char UnknownData72[0x7fe1]; // 0x7fe1
	    FName GetToggleInventoryActionName(); // 0x0 Size: 0x7fe1
	    char UnknownData73[0x7fe1]; // 0x7fe1
	    FName GetToggleFullscreenMapActionName(); // 0x0 Size: 0x7fe1
	    char UnknownData74[0x7fe1]; // 0x7fe1
	    FName GetSwitchQuickBarActionName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData75[0x7fe1]; // 0x7fe1
	    ESubGame GetSubGame(); // 0x0 Size: 0x7fe1
	    char UnknownData76[0x7fe1]; // 0x7fe1
	    FName GetShoppingCartCoastActionName(); // 0x0 Size: 0x7fe1
	    char UnknownData77[0x7fe1]; // 0x7fe1
	    struct FString GetSessionId(); // 0x0 Size: 0x7fe1
	    char UnknownData78[0x7fe1]; // 0x7fe1
	    struct FString GetSessionConnectString(); // 0x0 Size: 0x7fe1
	    char UnknownData79[0x7fe1]; // 0x7fe1
	    class UFortSeasonalEventManager* GetSeasonalEventManager(); // 0x0 Size: 0x7fe1
	    char UnknownData80[0x7fe1]; // 0x7fe1
	    class UFortUIScoreReport* GetScoreReport(); // 0x0 Size: 0x7fe1
	    char UnknownData81[0x7fe1]; // 0x7fe1
	    FName GetRotatePrimitiveClockwiseActionName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData82[0x7fe1]; // 0x7fe1
	    class UFortQuestManager* GetQuestManager(ESubGame SubGame); // 0x0 Size: 0x7fe1
	    char UnknownData83[0x7fe1]; // 0x7fe1
	    FName GetQuadCrasherBoostActionName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData84[0x7fe1]; // 0x7fe1
	    struct FText GetPlatformDisplayName(); // 0x0 Size: 0x7fe1
	    char UnknownData85[0x7fe1]; // 0x7fe1
	    FName GetPickerConfirmActionName(EFortPickerMode PickerMode); // 0x0 Size: 0x7fe1
	    char UnknownData86[0x7fe1]; // 0x7fe1
	    FName GetPickerCancelActionName(EFortPickerMode PickerMode); // 0x0 Size: 0x7fe1
	    char UnknownData87[0x7fe1]; // 0x7fe1
	    FName GetPerformBuildingImprovementInteractionActionName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData88[0x7fe1]; // 0x7fe1
	    FName GetPerformBuildingEditInteractionActionName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData89[0x7fe1]; // 0x7fe1
	    class UFortUIMessageManager* GetMessageManager(FName ManagerName, bool bCreatedNew); // 0x0 Size: 0x7fe1
	    char UnknownData90[0x7fe1]; // 0x7fe1
	    class UFortUIRewardReport* GetLastMissionRewardReport(); // 0x0 Size: 0x7fe1
	    char UnknownData91[0x7fe1]; // 0x7fe1
	    void GetLastMissionInfo(struct FFortLastMissionInfo LastMissionInfo); // 0x0 Size: 0x7fe1
	    char UnknownData92[0x7fe1]; // 0x7fe1
	    struct FGameSummaryInfo GetLastGameSummaryInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData93[0x7fe1]; // 0x7fe1
	    struct FText GetKeyTextForAxis(FName Axis, float AxisScale, bool bIsUsingGamepad, bool bUseAbbreviatedText); // 0x0 Size: 0x7fe1
	    char UnknownData94[0x7fe1]; // 0x7fe1
	    struct FText GetKeyTextForAction(FName Action, struct FText ButtonActionType, bool bUseAbbreviatedText); // 0x0 Size: 0x7fe1
	    char UnknownData95[0x7fe1]; // 0x7fe1
	    struct FKey GetKeyForAxis(FName Axis, float Scale, bool bIsUsingGamepad); // 0x0 Size: 0x7fe1
	    char UnknownData96[0x7fe1]; // 0x7fe1
	    struct FKey GetKeyForAction(FName Action, bool bForceGamepadKey, FName PresetNameOverride); // 0x0 Size: 0x7fe1
	    char UnknownData97[0x7fe1]; // 0x7fe1
	    void GetKBMPlayerInputPresetNamesForSubGame(ESubGame SubGame, TArray<struct FString> InputPresetNames, TArray<struct FText> InputPresetFriendlyNames); // 0x0 Size: 0x7fe1
	    char UnknownData98[0x7fe1]; // 0x7fe1
	    void GetKBMPlayerInputPresetDescriptionForSubGame(ESubGame SubGame, int CurrentPreset, struct FText InputPresetDescription, struct FText InputPresetSubDescription); // 0x0 Size: 0x7fe1
	    char UnknownData99[0x7fe1]; // 0x7fe1
	    FName GetJumpActionName(); // 0x0 Size: 0x7fe1
	    char UnknownData100[0x7fe1]; // 0x7fe1
	    FName GetJackalBoostActionName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData101[0x7fe1]; // 0x7fe1
	    int GetInputPriority(EInputPriority Priority); // 0x0 Size: 0x7fe1
	    char UnknownData102[0x7fe1]; // 0x7fe1
	    bool GetInputDetailsForAction(FName Action, struct FFortInputActionDetails InputActionDetails); // 0x0 Size: 0x7fe1
	    char UnknownData103[0x7fe1]; // 0x7fe1
	    bool GetHideStwItemRefundHelp(); // 0x0 Size: 0x7fe1
	    char UnknownData104[0x7fe1]; // 0x7fe1
	    bool GetHidePerkRecombobulatorHelp(); // 0x0 Size: 0x7fe1
	    char UnknownData105[0x7fe1]; // 0x7fe1
	    FName GetGolfCartReverseActionName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData106[0x7fe1]; // 0x7fe1
	    FName GetGolfCartForwardActionName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData107[0x7fe1]; // 0x7fe1
	    FName GetGolfCartEBrakeActionName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData108[0x7fe1]; // 0x7fe1
	    FName GetGadget2ActionName(); // 0x0 Size: 0x7fe1
	    char UnknownData109[0x7fe1]; // 0x7fe1
	    FName GetGadget1ActionName(); // 0x0 Size: 0x7fe1
	    char UnknownData110[0x7fe1]; // 0x7fe1
	    FName GetFireActionName(); // 0x0 Size: 0x7fe1
	    char UnknownData111[0x7fe1]; // 0x7fe1
	    struct FText GetFeedbackTitle(); // 0x0 Size: 0x7fe1
	    char UnknownData112[0x7fe1]; // 0x7fe1
	    struct FText GetFeatureStateReasonText(EFortUIFeatureStateReason Reason); // 0x0 Size: 0x7fe1
	    char UnknownData113[0x7fe1]; // 0x7fe1
	    void GetFeatureState(EFortUIFeature Feature, EFortUIFeatureState OutFeatureState, EFortUIFeatureStateReason OutReason); // 0x0 Size: 0x7fe1
	    char UnknownData114[0x7fe1]; // 0x7fe1
	    struct FString GetCustomGamepadInputPresetName(); // 0x0 Size: 0x7fe1
	    char UnknownData115[0x7fe1]; // 0x7fe1
	    struct FString GetCurrentInputPresetName(); // 0x0 Size: 0x7fe1
	    char UnknownData116[0x7fe1]; // 0x7fe1
	    struct FString GetCurrentCustomInputTemplatePresetName(); // 0x0 Size: 0x7fe1
	    char UnknownData117[0x7fe1]; // 0x7fe1
	    FName GetCrouchActionName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData118[0x7fe1]; // 0x7fe1
	    FName GetCreativeMoveToolEquippedGrabOrLetGoName(); // 0x0 Size: 0x7fe1
	    char UnknownData119[0x7fe1]; // 0x7fe1
	    FName GetCreativeMoveToolEquippedDeleteName(); // 0x0 Size: 0x7fe1
	    char UnknownData120[0x7fe1]; // 0x7fe1
	    FName GetCreativeMoveToolEquippedCopyGrabOrDuplicateName(); // 0x0 Size: 0x7fe1
	    char UnknownData121[0x7fe1]; // 0x7fe1
	    FName GetCreativeMoveObjectsFreelySwitchAxisName(); // 0x0 Size: 0x7fe1
	    char UnknownData122[0x7fe1]; // 0x7fe1
	    FName GetCreativeMoveObjectsFreelyRotateCounterclockwiseName(); // 0x0 Size: 0x7fe1
	    char UnknownData123[0x7fe1]; // 0x7fe1
	    FName GetCreativeMoveObjectsFreelyRotateClockwiseName(); // 0x0 Size: 0x7fe1
	    char UnknownData124[0x7fe1]; // 0x7fe1
	    FName GetCreativeMoveObjectsFreelyPushName(); // 0x0 Size: 0x7fe1
	    char UnknownData125[0x7fe1]; // 0x7fe1
	    FName GetCreativeMoveObjectsFreelyPullName(); // 0x0 Size: 0x7fe1
	    char UnknownData126[0x7fe1]; // 0x7fe1
	    FName GetCreativeMoveObjectsFreelyLetGoName(); // 0x0 Size: 0x7fe1
	    char UnknownData127[0x7fe1]; // 0x7fe1
	    FName GetCreativeMoveObjectsFreelyExitName(); // 0x0 Size: 0x7fe1
	    char UnknownData128[0x7fe1]; // 0x7fe1
	    FName GetCreativeMoveObjectsFreelyDuplicateName(); // 0x0 Size: 0x7fe1
	    char UnknownData129[0x7fe1]; // 0x7fe1
	    FName GetCreativeMoveObjectsFreelyDropToFloorName(); // 0x0 Size: 0x7fe1
	    char UnknownData130[0x7fe1]; // 0x7fe1
	    FName GetCreativeMoveObjectsFreelyChangePrecisionLevelName(); // 0x0 Size: 0x7fe1
	    char UnknownData131[0x7fe1]; // 0x7fe1
	    FName GetCreativeMoveBuildingsOnGridRotateCounterclockwiseName(); // 0x0 Size: 0x7fe1
	    char UnknownData132[0x7fe1]; // 0x7fe1
	    FName GetCreativeMoveBuildingsOnGridRotateClockwiseName(); // 0x0 Size: 0x7fe1
	    char UnknownData133[0x7fe1]; // 0x7fe1
	    FName GetCreativeMoveBuildingsOnGridMirrorName(); // 0x0 Size: 0x7fe1
	    char UnknownData134[0x7fe1]; // 0x7fe1
	    FName GetCreativeMoveBuildingsOnGridLetGoName(); // 0x0 Size: 0x7fe1
	    char UnknownData135[0x7fe1]; // 0x7fe1
	    FName GetCreativeMoveBuildingsOnGridExitName(); // 0x0 Size: 0x7fe1
	    char UnknownData136[0x7fe1]; // 0x7fe1
	    FName GetCreativeMoveBuildingsOnGridDuplicateName(); // 0x0 Size: 0x7fe1
	    char UnknownData137[0x7fe1]; // 0x7fe1
	    FName GetCreativeMoveBuildingsOnGridChangePrecisionLevelName(); // 0x0 Size: 0x7fe1
	    char UnknownData138[0x7fe1]; // 0x7fe1
	    struct FDateTime GetCreativeModeLimitedAccessEndTime(); // 0x0 Size: 0x7fe1
	    char UnknownData139[0x7fe1]; // 0x7fe1
	    bool GetCreativeMode(); // 0x0 Size: 0x7fe1
	    char UnknownData140[0x7fe1]; // 0x7fe1
	    FName GetCreativeFlyUpActionName(); // 0x0 Size: 0x7fe1
	    char UnknownData141[0x7fe1]; // 0x7fe1
	    FName GetCreativeFlyDownActionName(); // 0x0 Size: 0x7fe1
	    char UnknownData142[0x7fe1]; // 0x7fe1
	    struct FText GetConningXpModifierMessage(int TotalSkillPoints, int ContentDifficulty); // 0x0 Size: 0x7fe1
	    char UnknownData143[0x7fe1]; // 0x7fe1
	    float GetConningDifficultyXpModifier(int TotalSkillPoints, int ContentDifficulty); // 0x0 Size: 0x7fe1
	    char UnknownData144[0x7fe1]; // 0x7fe1
	    class UFortCollectionBookManager* GetCollectionBookManager(); // 0x0 Size: 0x7fe1
	    char UnknownData145[0x7fe1]; // 0x7fe1
	    FName GetChangeMaterialActionName(); // 0x0 Size: 0x7fe1
	    char UnknownData146[0x7fe1]; // 0x7fe1
	    FName GetBuildConfirmActionName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData147[0x7fe1]; // 0x7fe1
	    bool GetBrushForKeyWithCustomInput(struct FKey Key, struct FSlateBrush Brush, ECommonInputType InputType, ECommonGamepadType GamepadType); // 0x0 Size: 0x7fe1
	    char UnknownData148[0x7fe1]; // 0x7fe1
	    bool GetBrushForKey(struct FKey Key, struct FSlateBrush Brush); // 0x0 Size: 0x7fe1
	    char UnknownData149[0x7fe1]; // 0x7fe1
	    FName GetBiplaneTaxiBackwardsName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData150[0x7fe1]; // 0x7fe1
	    FName GetBiplaneStopEngineName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData151[0x7fe1]; // 0x7fe1
	    FName GetBiplaneStartEngineName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData152[0x7fe1]; // 0x7fe1
	    FName GetBiplaneShootName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData153[0x7fe1]; // 0x7fe1
	    FName GetBiplaneRollRightName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData154[0x7fe1]; // 0x7fe1
	    FName GetBiplaneRollLeftName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData155[0x7fe1]; // 0x7fe1
	    FName GetBiplaneRollInvertName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData156[0x7fe1]; // 0x7fe1
	    FName GetBiplaneFreelookName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData157[0x7fe1]; // 0x7fe1
	    FName GetBiplaneBoostName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData158[0x7fe1]; // 0x7fe1
	    struct FString GetBackendName(); // 0x0 Size: 0x7fe1
	    char UnknownData159[0x7fe1]; // 0x7fe1
	    void GetAllPlayerInputPresetNamesForSubGame(ESubGame SubGame, TArray<struct FString> InputPresetNames, TArray<struct FText> InputPresetFriendlyNames); // 0x0 Size: 0x7fe1
	    char UnknownData160[0x7fe1]; // 0x7fe1
	    void GetAllPlayerInputPresetNames(TArray<struct FString> InputPresetNames, TArray<struct FText> InputPresetFriendlyNames); // 0x0 Size: 0x7fe1
	    char UnknownData161[0x7fe1]; // 0x7fe1
	    FName GetActionForKey(FName PresetName, struct FKey Key, EFortInputActionGroup InputActionGroup, bool bIsUsingGamepad); // 0x0 Size: 0x7fe1
	    char UnknownData162[0x7fe1]; // 0x7fe1
	    struct FFortGlobalActionDetails GetActionDetails(EFortGlobalAction Action, struct FFortGlobalActionDetailsFunctionContext Context); // 0x0 Size: 0x7fe1
	    char UnknownData163[0x7fe1]; // 0x7fe1
	    struct FText GetAccountGameplayRestrictionText(); // 0x0 Size: 0x7fe1
	    char UnknownData164[0x7fe1]; // 0x7fe1
	    ESubGameAccessReason GetAccessReason(ESubGame SubGame); // 0x0 Size: 0x7fe1
	    char UnknownData165[0x7fe1]; // 0x7fe1
	    FName GetAbility3ActionName(); // 0x0 Size: 0x7fe1
	    char UnknownData166[0x7fe1]; // 0x7fe1
	    FName GetAbility2ActionName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData167[0x7fe1]; // 0x7fe1
	    FName GetAbility1ActionName(ECommonInputType OverrideInputType); // 0x0 Size: 0x7fe1
	    char UnknownData168[0x7fe1]; // 0x7fe1
	    void ForceSetFeatureState(EFortUIFeature Feature, EFortUIFeatureState ForcedState, EFortUIFeatureStateReason Reason); // 0x0 Size: 0x7fe1
	    char UnknownData169[0x7fe1]; // 0x7fe1
	    void ExitVehicle(); // 0x0 Size: 0x7fe1
	    char UnknownData170[0x7fe1]; // 0x7fe1
	    void EnterVehiclePassenger(); // 0x0 Size: 0x7fe1
	    char UnknownData171[0x7fe1]; // 0x7fe1
	    void EnterVehicleDriver(); // 0x0 Size: 0x7fe1
	    char UnknownData172[0x7fe1]; // 0x7fe1
	    static void DrawAttention(class UWidget* BaseWidget); // 0x0 Size: 0x7fe1
	    char UnknownData173[0x7fe1]; // 0x7fe1
	    void DisplayStateContent(bool bDisplay); // 0x0 Size: 0x7fe1
	    char UnknownData174[0x7fe1]; // 0x7fe1
	    void CopyToClipboard(struct FString ClipboardText); // 0x0 Size: 0x7fe1
	    char UnknownData175[0x7fe1]; // 0x7fe1
	    float ContentInstallationProgress(); // 0x0 Size: 0x7fe1
	    char UnknownData176[0x7fe1]; // 0x7fe1
	    void CloseExternalNotificationWindowIfOpen(); // 0x0 Size: 0x7fe1
	    char UnknownData177[0x7fe1]; // 0x7fe1
	    void ClearSelectionGroup(FName SelectionGroup); // 0x0 Size: 0x7fe1
	    char UnknownData178[0x7fe1]; // 0x7fe1
	    void ClearRatingWidgetInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData179[0x7fe1]; // 0x7fe1
	    void ClearLastMissionReports(); // 0x0 Size: 0x7fe1
	    char UnknownData180[0x7fe1]; // 0x7fe1
	    void ClearLastGameSummaryInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData181[0x7fe1]; // 0x7fe1
	    void ClearForceSetFeatureState(EFortUIFeature Feature); // 0x0 Size: 0x7fe1
	    char UnknownData182[0x7fe1]; // 0x7fe1
	    static void CheckFlag(struct FString FlagName, EFlagStatus OutStatus); // 0x0 Size: 0x7fe1
	    char UnknownData183[0x7fe1]; // 0x7fe1
	    bool CanPlay(ESubGame SubGame, struct FText DenialReason); // 0x0 Size: 0x7fe1
	    char UnknownData184[0x7fe1]; // 0x7fe1
	    bool CanMatchmake(ESubGame SubGame, struct FText DenialReason); // 0x0 Size: 0x7fe1
	    char UnknownData185[0x7fe1]; // 0x7fe1
	    static void CancelDrawAttention(class UWidget* BaseWidget); // 0x0 Size: 0x7fe1
	    char UnknownData186[0x7fe1]; // 0x7fe1
	    void BroadcastItemReceivedNotificationShown(bool IsActive); // 0x0 Size: 0x7fe1
	    char UnknownData187[0x7fe1]; // 0x7fe1
	    void BindToFeatureStateAndInitialize(EFortUIFeature Feature, __int64/*DelegateProperty*/ Delegate); // 0x0 Size: 0x7fe1
	    char UnknownData188[0x7fe1]; // 0x7fe1
	    bool AutoSelectSubGame(); // 0x0 Size: 0x7fe1
	    char UnknownData189[0x7fe1]; // 0x7fe1
	    bool AllowQuit(); // 0x0 Size: 0x7fe1
	    char UnknownData190[0x7fe1]; // 0x7fe1
	    bool AllowLogout(); // 0x0 Size: 0x7fe1
	    char UnknownData191[0x-7c01];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortGlobalUIContext");
			return (class UClass*)ptr;
		};

};

class UFortGridWidgetBase : public UContentWidget
{
	public:
	    class UFortGridPickerTile* ClearWidgetType; // 0x118 Size: 0x8
	    float TileWidth; // 0x120 Size: 0x4
	    float TileHeight; // 0x124 Size: 0x4
	    int TilesAcross; // 0x128 Size: 0x4
	    int TilesDown; // 0x12c Size: 0x4
	    bool bShrinkToFit; // 0x130 Size: 0x1
	    char UnknownData0[0x3]; // 0x131
	    float PeekOverflowTilePercentage; // 0x134 Size: 0x4
	    struct FMargin TilePadding; // 0x138 Size: 0x10
	    struct FSlateBrush GridBackground; // 0x148 Size: 0x88
	    struct FMargin GridBackgroundPadding; // 0x1d0 Size: 0x10
	    TArray<class UObject*> DataProvider; // 0x1e0 Size: 0x10
	    MulticastDelegateProperty OnTileGenerated; // 0x1f0 Size: 0x10
	    MulticastDelegateProperty OnTileClicked; // 0x200 Size: 0x10
	    MulticastDelegateProperty OnMouseEnterTile; // 0x210 Size: 0x10
	    MulticastDelegateProperty OnMouseLeaveTile; // 0x220 Size: 0x10
	    class UFortGridPickerTile* TileWidgetType; // 0x230 Size: 0x8
	    EGridSortKind SortKind; // 0x238 Size: 0x1
	    bool bReversed; // 0x239 Size: 0x1
	    char UnknownData1[0x2]; // 0x23a
	    __int64/*DelegateProperty*/ GetSortKeyFor; // 0x23c Size: 0x10
	    char UnknownData2[0x24c]; // 0x24c
	    void SetTileWidth(float Width); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetTilesDown(int Down); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetTilesAcross(int Across); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetTilePadding(struct FMargin Padding); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetTileHeight(float Height); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetPeekOverflowTilePercentage(float Percent); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetDataProvider(TArray<class UObject*> Data); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetClearWidgetType(class UFortGridPickerTile* InClearWidgetType); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    TArray<class UFortGridPickerTile*> GetTiles(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    class UFortGridPickerTile* GetTileForObject(class UObject* Object); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7d81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortGridWidgetBase");
			return (class UClass*)ptr;
		};

};

class UFortGridPickerButton : public UFortGridWidgetBase
{
	public:
	    char GridPlacement; // 0x260 Size: 0x1
	    char UnknownData0[0x7]; // 0x261
	    class UFortGridPickerGrid* GridWidget; // 0x268 Size: 0x8
	    bool bCloseOnTileClicked; // 0x270 Size: 0x1
	    char UnknownData1[0x3]; // 0x271
	    __int64/*DelegateProperty*/ GridWidgetDelegate; // 0x274 Size: 0x10
	    char UnknownData2[0x4]; // 0x284
	    MulticastDelegateProperty OnGridPickerOpenChanged; // 0x288 Size: 0x10
	    char UnknownData3[0x298]; // 0x298
	    void SetIsOpen(bool ShouldBeOpen); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnIsGridPickerOpenChanged__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnButtonClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ CreateGridWidget__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7d39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortGridPickerButton");
			return (class UClass*)ptr;
		};

};

class UFortGridPickerGrid : public UFortUserWidget
{
	public:
	    char UnknownData0[0x238];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortGridPickerGrid");
			return (class UClass*)ptr;
		};

};

class UFortGridPickerTile : public UFortUserWidget
{
	public:
	    class UObject* Data; // 0x238 Size: 0x8
	    class UFortGridWidgetBase* Owner; // 0x240 Size: 0x8
	    char UnknownData0[0x248]; // 0x248
	    void SetData(class UObject* InData); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void ForwardClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortGridPickerTile");
			return (class UClass*)ptr;
		};

};

class UFortGridWidget : public UFortGridWidgetBase
{
	public:
	    char UnknownData0[0x270];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortGridWidget");
			return (class UClass*)ptr;
		};

};

class UFortHaveInviteSelect : public UCommonActivatablePanel
{
	public:
	    char UnknownData0[0x10];
	    class UCommonButton* Button_Yes; // 0x328 Size: 0x8
	    class UCommonButton* Button_No; // 0x330 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHaveInviteSelect");
			return (class UClass*)ptr;
		};

};

class UFortHealthWarningBase : public UCommonActivatablePanel
{
	public:
	    char UnknownData0[0x18];
	    float ShowTimeLength; // 0x330 Size: 0x4
	    char UnknownData1[0x4]; // 0x334
	    class UCommonTextBlock* Text_HealthWarning; // 0x338 Size: 0x8
	    class UHorizontalBox* HBox_RatingsIcons; // 0x340 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHealthWarningBase");
			return (class UClass*)ptr;
		};

};

class UFortHelpTreeItemBase : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    class UFortHelpItem* HelpItem; // 0xb30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHelpTreeItemBase");
			return (class UClass*)ptr;
		};

};

class UFortHeroLoadoutGadgetPicker : public UFortItemPickerBase
{
	public:
	    TWeakObjectPtr<UFortCampaignHeroLoadoutItem*> TargetLoadoutItem; // 0x2e8 Size: 0x8
	    int TargetSlotIndex; // 0x2f0 Size: 0x4
	    char UnknownData0[0x4]; // 0x2f4
	    TArray<class UFortItem*> TemporaryGadgetItemInstances; // 0x2f8 Size: 0x10
	    char UnknownData1[0x308]; // 0x308
	    void SetTargetLoadoutSlot(class UFortCampaignHeroLoadoutItem* LoadoutItem, int SlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7cd9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHeroLoadoutGadgetPicker");
			return (class UClass*)ptr;
		};

};

class UFortHeroLoadoutHeroPicker : public UFortItemPickerBase
{
	public:
	    class UFortTabListWidgetBase* FilterTabList; // 0x2e8 Size: 0x8
	    TWeakObjectPtr<UFortCampaignHeroLoadoutItem*> TargetLoadoutItem; // 0x2f0 Size: 0x8
	    FName TargetSlotName; // 0x2f8 Size: 0x8
	    class UCommonButton* FilterTabButtonType; // 0x300 Size: 0x8
	    __int64/*MapProperty*/ TabButtonLabelInfoMap; // 0x308 Size: 0x50
	    char UnknownData0[0x358]; // 0x358
	    void SetTargetLoadoutSlot(class UFortCampaignHeroLoadoutItem* LoadoutItem, FName SlotName); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void HandleFilterTabSelected(FName TabId); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7c39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHeroLoadoutHeroPicker");
			return (class UClass*)ptr;
		};

};

class UFortHeroLoadoutHeroPickerFunctionLibrary : public UBlueprintFunctionLibrary
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHeroLoadoutHeroPickerFunctionLibrary");
			return (class UClass*)ptr;
		};

};

class AFortHeroLoadoutPedestal : public AFortItemPreviewPedestal
{
	public:
	    FName SlotName; // 0x3e0 Size: 0x8
	    TWeakObjectPtr<UFortCampaignHeroLoadoutItem*> HeroLoadout; // 0x3e8 Size: 0x8
	    bool bIsSlotFocusedInUI; // 0x3f0 Size: 0x1
	    char UnknownData0[0x3f1]; // 0x3f1
	    void HandleSlotFocusInUIChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void HandleDifferentLoadoutViewed(class UFortCampaignHeroLoadoutItem* PreviousLoadout, class UFortCampaignHeroLoadoutItem* CurrentLoadout); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HandleDifferentHeroLoadoutSlotFocused(FName FocusedSlotName); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7bc9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHeroLoadoutPedestal");
			return (class UClass*)ptr;
		};

};

class UFortHeroLoadoutScreenBase : public UFortActivatablePanelWithItemPreview
{
	public:
	    void SetHeroLoadout(class UFortCampaignHeroLoadoutItem* HeroLoadout); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7ba9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHeroLoadoutScreenBase");
			return (class UClass*)ptr;
		};

};

class UFortHeroLoadoutSlotButton : public UCommonButton
{
	public:
	    FName SlotName; // 0xb28 Size: 0x8
	    MulticastDelegateProperty OnRequestChangeHero; // 0xb30 Size: 0x10
	    MulticastDelegateProperty OnContextMenuOpenChanged; // 0xb40 Size: 0x10
	    class UMenuAnchor* ContextMenuAnchor; // 0xb50 Size: 0x8
	    char UnknownData0[0xb58]; // 0xb58
	    __int64/*DelegateFunction*/ OnRequestChangeHero__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnMenuOpenChangedEvent__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool IsContextMenuOpen(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleMenuOpenChanged(bool bIsMenuOpen); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7489];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHeroLoadoutSlotButton");
			return (class UClass*)ptr;
		};

};

class UFortHeroManagementContext : public UBlueprintContextBase
{
	public:
	    MulticastDelegateProperty OnPlayerDataUpdated; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnMcpHeroDeleteResponse; // 0x38 Size: 0x10
	    MulticastDelegateProperty OnMcpHeroCreateResponse; // 0x48 Size: 0x10
	    MulticastDelegateProperty OnCurrentHeroChanged; // 0x58 Size: 0x10
	    MulticastDelegateProperty OnMcpAbilityChangeRequestResponse; // 0x68 Size: 0x10
	    MulticastDelegateProperty OnMcpAbilityChangeRequestSent; // 0x78 Size: 0x10
	    MulticastDelegateProperty OnAbilitySelectionRolledBack; // 0x88 Size: 0x10
	    MulticastDelegateProperty OnAvailableAbilityPointsChanged; // 0x98 Size: 0x10
	    MulticastDelegateProperty OnHeroStatsChanged; // 0xa8 Size: 0x10
	    class UFortHero* CurrentHero; // 0xb8 Size: 0x8
	    char UnknownData0[0x8]; // 0xc0
	    class UFortHero* HeroBeingDeleted; // 0xc8 Size: 0x8
	    char UnknownData1[0xd0]; // 0xd0
	    bool SetHeroName(struct FString NewName); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool SetCurrentHero(struct FString HeroId); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool RequestSetTraitDepthFromID(struct FString HeroId, int TraitIdx, int Depth); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool RequestSetTraitDepth(int TraitIdx, int Depth); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool RequestCreateHero(class UFortHeroType* HeroType, struct FString Name, char Gender); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool RedeemPrevAbilityFromID(struct FString HeroId, int TraitIdx); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool RedeemPrevAbility(int TraitIdx); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void RedeemAllAbilitiesFromID(struct FString HeroId); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool RedeemAllAbilities(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    bool PurchaseNextAbilityFromID(struct FString HeroId, int TraitIdx); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    bool PurchaseNextAbility(int TraitIdx); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void MarkHeroAsSeen(struct FString HeroId); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    bool IsSkillTreeUnlocked(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    bool IsShowingStatsScreen(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    bool IsCreateHeroEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    int GetTraitDepthFromID(struct FString HeroId, int TraitIdx); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    bool GetTraitDepth(int TraitIdx, int Depth); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    int GetNumUnspentAbilityPointsFromID(struct FString HeroId); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    bool GetNumUnspentAbilityPoints(int NumAbilityPoints); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    int GetNumHeroTraits(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    int GetNextAbilityCostFromID(struct FString HeroId, int TraitIdx); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    int GetNextAbilityCost(int TraitIdx); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    int GetMaxNameLength(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    struct FHeroUIData GetHeroDataFromID(struct FString HeroId); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    bool GetHeroData(struct FHeroUIData HeroData); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void GetDisplayStats(TArray<struct FFortGameplayEffectModifierDescription> Stats); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    bool GetCurrentHeroID(struct FString HeroId); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    TArray<class UFortAbilityKit*> GetCoreAbilities(); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    bool GetAttributeValuesArrayFromID(struct FString HeroId, TArray<struct FGameplayAttribute> Attributes, TArray<float> Values, bool bUseProxy); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    bool GetAttributeValuesArray(TArray<struct FGameplayAttribute> Attributes, TArray<float> Values, bool bUseProxy); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    float GetAttributeValueFromID(struct FString HeroId, struct FGameplayAttribute Attribute, bool bUseProxy); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    float GetAttributeValue(struct FGameplayAttribute Attribute, bool bUseProxy); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    TArray<struct FString> GetAllHeroIDs(); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    class UFortAbilitySystemComponent* GetAbilitySystemComponent(); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    int GetAbilityCostFromID(struct FString HeroId, int TraitIdx, int TraitDepth); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    int GetAbilityCost(int TraitIdx, int TraitDepth); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    void GenerateRandomHeroName(class UDataTable* NameTable, struct FString Name); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    void FocusOnHero(struct FString HeroId); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    ENameStatus CheckHeroNameValidity(struct FString Name); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    bool CanRedeemAllAbilities(); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    bool CanModifyTraitDepthFromID(struct FString HeroId, int TraitIdx); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    bool CanModifyTraitDepth(int TraitIdx); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    bool CanAffordNextAbilityFromID(struct FString HeroId, int TraitIdx); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    bool CanAffordNextAbility(int TraitIdx); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    bool CanAffordAbilityFromID(struct FString HeroId, int TraitIdx, int TraitDepth); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    bool CanAffordAbility(int TraitIdx, int TraitDepth); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x-7f09];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHeroManagementContext");
			return (class UClass*)ptr;
		};

};

class UFortSquadStatDetailsWidget : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x260];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSquadStatDetailsWidget");
			return (class UClass*)ptr;
		};

};

class UFortHeroSquadBonusPerksWidgetBase : public UFortSquadStatDetailsWidget
{
	public:
	    class UFortPerkWidget_NUI* SupportBonusPerkWidget; // 0x260 Size: 0x8
	    class UFortPerkWidget_NUI* TacticalBonusPerkWidget; // 0x268 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHeroSquadBonusPerksWidgetBase");
			return (class UClass*)ptr;
		};

};

class UFortSquadManagementScreenBase : public UFortActivatablePanel
{
	public:
	    char UnknownData0[0x10];
	    class UFortSquadStatsWidgetBase* SquadStatsWidget; // 0x350 Size: 0x8
	    class UFortSquadSlotsView* SquadSlotsView; // 0x358 Size: 0x8
	    class UFortSquadSlotDetailsPanel* SelectedSlotDetailsPanel; // 0x360 Size: 0x8
	    class UFortSquadSlotItemPicker* SelectedSlotItemPicker; // 0x368 Size: 0x8
	    struct FDataTableRowHandle InspectInputActionRowHandle; // 0x370 Size: 0x10
	    struct FDataTableRowHandle ManageInputActionRowHandle; // 0x380 Size: 0x10
	    struct FDataTableRowHandle BackInputActionRowHandle; // 0x390 Size: 0x10
	    struct FDataTableRowHandle InventoryInputActionRowHandle; // 0x3a0 Size: 0x10
	    struct FDataTableRowHandle InventoryCloseInputActionRowHandle; // 0x3b0 Size: 0x10
	    struct FDataTableRowHandle ClosePickerInputActionRowHandle; // 0x3c0 Size: 0x10
	    struct FDataTableRowHandle SelectPickerSlotActionRowHandle; // 0x3d0 Size: 0x10
	    struct FDataTableRowHandle CyclePickerSortActionRowHandle; // 0x3e0 Size: 0x10
	    struct FDataTableRowHandle PreviousSquadActionRowHandle; // 0x3f0 Size: 0x10
	    struct FDataTableRowHandle NextSquadActionRowHandle; // 0x400 Size: 0x10
	    struct FDataTableRowHandle ClearAllActionRowHandle; // 0x410 Size: 0x10
	    struct FDataTableRowHandle HelpScreenActionRowHandle; // 0x420 Size: 0x10
	    class UFortDisableAutoSlottingPromptAction* DisableAutoSlottingToClearSquadPromptAction; // 0x430 Size: 0x8
	    char UnknownData1[0x10]; // 0x438
	    class UFortItemViewContext_SquadSlotsView* ItemViewContext_SquadSlotsView; // 0x448 Size: 0x8
	    class UFortItemViewContext_SquadSlotItemPicker* ItemViewContext_SquadSlotItemPicker; // 0x450 Size: 0x8
	    char UnknownData2[0x458]; // 0x458
	    bool TryGetStaticSquadDataBP(struct FHomebaseSquad OutSquadData); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool TryGetSquadTeamAttribute(struct FGameplayAttribute OutGameplayAttribute); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool TryGetSquadMainAttribute(struct FGameplayAttribute OutGameplayAttribute); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool TryGetAttributeValueFromSquad(float OutValue, struct FGameplayAttribute Attribute); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetIdOfSquadToManageBP(FName SquadId); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SelectSquadWithOffset(int Offset); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SelectPreviousSquad(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SelectNextSquad(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void NavigateToSquadSlot(int SquadSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void HandleViewInAll(int SquadSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void HandleSquadStateChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void HandleSquadSlotPickerShown(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void HandleSquadSlotPickerHidden(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void HandleShouldAutoSlotSurvivorSquadsChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void HandleSelectPickerSlotInputAction(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void HandlePreviousSquadInputAction(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void HandlePickerSelectionCommitted(class UFortItem* CommittedItem); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void HandlePickerSelectionChanged(class UFortItem* SelectedItem); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void HandleOpenSquadSlot(int SquadSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void HandleNextSquadInputAction(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void HandleManageInputAction(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void HandleInventoryInputAction(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void HandleInspectInputAction(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void HandleDifferentSquadSlotSelected(int SquadSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void HandleDifferentSquadSetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void HandleCyclePickerSortInputAction(); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void HandleClosePickerInputAction(); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    void HandleBackInputAction(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    int GetNumUnlockedSquads(); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    FName GetIdOfSquadToManageBP(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    void ClearSquad(); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x-7b89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSquadManagementScreenBase");
			return (class UClass*)ptr;
		};

};

class UFortHeroSquadManagementScreen : public UFortSquadManagementScreenBase
{
	public:
	    struct FDataTableRowHandle ManageDefendersInputActionRowHandle; // 0x458 Size: 0x10
	    class UFortHeroSquadBonusPerksWidgetBase* BonusPerksWidget; // 0x468 Size: 0x8
	    char UnknownData0[0x470]; // 0x470
	    void PlayFeedbackForSlottingPerson(class UFortCharacter* Character, int SlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7b69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHeroSquadManagementScreen");
			return (class UClass*)ptr;
		};

};

class UFortIconWithLabel : public UWidget
{
	public:
	    bool ShouldShowIcon; // 0x100 Size: 0x1
	    bool ShouldCollapseIconWhenNotShown; // 0x101 Size: 0x1
	    char IconBrushSize; // 0x102 Size: 0x1
	    bool ShouldShowLabel; // 0x103 Size: 0x1
	    char UnknownData0[0x4]; // 0x104
	    class UCommonTextStyle* LabelTextStyle; // 0x108 Size: 0x8
	    char UnknownData1[0x10];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortIconWithLabel");
			return (class UClass*)ptr;
		};

};

class UFortHeroSupportPerkIndicator : public UFortIconWithLabel
{
	public:
	    TWeakObjectPtr<UFortItem*> ItemToRepresent; // 0x120 Size: 0x8
	    EFortSupportBonusType SupportTypeToRepresent; // 0x128 Size: 0x1
	    char UnknownData0[0x129]; // 0x129
	    void SetSupportTypeToRepresent(EFortSupportBonusType SupportTypeToRepresent); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetItemToRepresent(class UFortItem* ItemToRepresent); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7eb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHeroSupportPerkIndicator");
			return (class UClass*)ptr;
		};

};

class UFortHeroSupportPerkWidget : public UUserWidget
{
	public:
	    TWeakObjectPtr<UFortHero*> HeroToRepresent; // 0x228 Size: 0x8
	    EFortSupportBonusType SupportTypeToRepresent; // 0x230 Size: 0x1
	    EFortSupportPerkWidgetState SupportPerkWidgetState; // 0x231 Size: 0x1
	    char UnknownData0[0x6]; // 0x232
	    class UFortMultiSizeImage* PerkImage; // 0x238 Size: 0x8
	    class UCommonTextBlock* NameText; // 0x240 Size: 0x8
	    class UCommonTextBlock* DescriptionText; // 0x248 Size: 0x8
	    char UnknownData1[0x250]; // 0x250
	    void SetSupportTypeToRepresent(EFortSupportBonusType InSupportTypeToRepresent); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetState(EFortSupportPerkWidgetState InState); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetHeroToRepresent(class UFortHero* InHeroToRepresent); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnSupportTypeUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnStateChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnHeroUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool IsPerkUnlocked(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool IsPerkInCorrectSlot(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool IsPerkHighlighted(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    bool IsPerkEmpty(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    bool IsPerkActive(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    bool IsHeroInSupportSlot(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x-7a61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHeroSupportPerkWidget");
			return (class UClass*)ptr;
		};

};

class UFortHomebaseNodeItemTooltip : public UFortItemTooltip
{
	public:
	    char UnknownData0[0xb0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHomebaseNodeItemTooltip");
			return (class UClass*)ptr;
		};

};

class UFortHomebaseNodeItemUtilities : public UBlueprintFunctionLibrary
{
	public:
	    static bool IsSquadSlotUnseen(class AFortPlayerController* FortPC, FName SquadId, int SquadSlot); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static bool IsHomebaseNodeItemUnseenForTagContainer(class AFortPlayerController* FortPC, struct FGameplayTagContainer Tags); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static struct FString GetHomebaseNodeItemNameForTagContainer(class AFortPlayerController* FortPC, struct FGameplayTagContainer Tags); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static class UFortHomebaseNodeItem* GetHomebaseNodeItemForTagContainer(class AFortPlayerController* FortPC, struct FGameplayTagContainer Tags); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static class UFortHomebaseNodeItem* GetHomebaseNodeItemForSquadSlot(class AFortPlayerController* FortPC, FName SquadId, int SquadSlot); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static bool AreAnyHomebaseNodeItemsUnseenForSquadType(class AFortPlayerController* FortPC, EFortHomebaseSquadType SquadType); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static bool AreAnyHomebaseNodeItemsUnseenForSquadId(class AFortPlayerController* FortPC, FName SquadId); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHomebaseNodeItemUtilities");
			return (class UClass*)ptr;
		};

};

class UFortDisableAutoSlottingPromptAction : public UObject
{
	public:
	    TWeakObjectPtr<APlayerController*> OwningPlayerController; // 0x28 Size: 0x8
	    char UnknownData0[0x10]; // 0x30
	    TWeakObjectPtr<UGameInstance*> RegisteredWithGameInstance; // 0x40 Size: 0x8
	    char UnknownData1[0x48]; // 0x48
	    void Execute(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void CompleteExecution(EFortDialogResult Result, FName ResultName); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7f99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortDisableAutoSlottingPromptAction");
			return (class UClass*)ptr;
		};

};

class UFortHomebaseUIContext : public UBlueprintContextBase
{
	public:
	    MulticastDelegateProperty OnShouldAutoSlotSurvivorSquadsChanged; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnSquadSlotChanged; // 0x38 Size: 0x10
	    MulticastDelegateProperty OnSurvivorSquadsAutoSlotted; // 0x48 Size: 0x10
	    MulticastDelegateProperty OnNodePurchased; // 0x58 Size: 0x10
	    MulticastDelegateProperty OnSlottedPrimaryHeroChanged; // 0x68 Size: 0x10
	    MulticastDelegateProperty OnDifferentHeroLoadoutViewed; // 0x78 Size: 0x10
	    MulticastDelegateProperty OnDifferentHeroLoadoutSlotFocused; // 0x88 Size: 0x10
	    struct TSoftObjectPtr<struct UDataTable*> SquadIconDataTableAsset; // 0x98 Size: 0x28
	    char UnknownData0[0x38]; // 0xc0
	    __int64/*MapProperty*/ GadgetDefinitionToInstanceMap; // 0xf8 Size: 0x50
	    char UnknownData1[0x148]; // 0x148
	    void SetShowHeroHeadAccessoriesForLocalPlayer(bool bShow); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetShowHeroBackpackForLocalPlayer(bool bShow); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetShouldAutoSlotSurvivorSquads(bool Value); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetCurrentlyViewedHeroLoadout(class UFortCampaignHeroLoadoutItem* Loadout); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetCurrentlyFocusedHeroLoadoutSlotName(FName SlotName); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnSurvivorSquadsAutoSlotted__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnSquadSlotChanged__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnSlottedPrimaryHeroChanged__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnShouldAutoSlotSurvivorSquadsChanged__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnNodesPurchased__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnDifferentHeroLoadoutViewed__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnDifferentHeroLoadoutSlotFocused__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    bool IsHeroLoadoutSlotUnlocked(FName SlotName, class UFortCampaignHeroLoadoutItem* Loadout); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    bool IsAnySquadSlotUnlocked(FName SquadId); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void HandleDifferentHeroLoadoutActivated(class UFortMcpProfileCampaign* Profile); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void GetWorkerSetBonusEffectModifiers(struct FGameplayTag SetBonusTag, TArray<struct FFortAttributeModifierDisplayData> OutModifiers); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    class UFortQuestItemDefinition* GetUnlockingQuestDefinitionForSquadSlot(FName SquadName, int SlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    class UFortQuestItemDefinition* GetUnlockingQuestDefinitionForHeroLoadoutSlot(FName SlotName, class UFortCampaignHeroLoadoutItem* Loadout); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    struct FFortMultiSizeBrush GetSquadIcon(FName SquadId); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    class UFortHero* GetSlottedPrimaryHero(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    bool GetShowHeroHeadAccessoriesForLocalPlayer(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    bool GetShowHeroBackpackForLocalPlayer(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    bool GetShouldAutoSlotSurvivorSquads(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    bool GetLocalPlayerHasHeroHeadAccessories(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    bool GetLocalPlayerHasHeroBackpack(); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    TArray<class UFortItem*> GetItemsInSquad(FName SquadId, bool bRemoveEmptySquadSlots); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    class UFortItem* GetItemInSquadSlot(FName SquadName, int SlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    class UFortWorldItem* GetGadgetItemInstanceForUI(class UFortGadgetItemDefinition* GadgetDefinition); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    class UFortCampaignHeroLoadoutItem* GetCurrentlyViewedHeroLoadout(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    FName GetCurrentlyFocusedHeroLoadoutSlotName(); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    void AutoSlotAllSurvivorSquads(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x-7e99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHomebaseUIContext");
			return (class UClass*)ptr;
		};

};

class UFortHomeCMSScreenBase : public UEpicCMSScreenBase
{
	public:
	    class UWidgetSwitcher* LayoutSwitcher; // 0x3a8 Size: 0x8
	    char UnknownData0[0x3b0]; // 0x3b0
	    void OnTilesLoaded(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool AreTilesLoaded(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7c31];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHomeCMSScreenBase");
			return (class UClass*)ptr;
		};

};

class UFortHUDCenterPopupMessageWidget : public UCommonUserWidget
{
	public:
	    __int64/*SoftClassProperty*/ CenterPopupModalWidgetClass; // 0x230 Size: 0x28
	    char UnknownData0[0x8]; // 0x258
	    class UCommonActivatablePanel* CenterPopupModalWidget; // 0x260 Size: 0x8
	    char UnknownData1[0x268]; // 0x268
	    void UpdateState(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnModalDisplayed(ECenterPopupMessageStateEnum NewState, class UCommonActivatablePanel* ModalPopup); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    ECenterPopupMessageStateEnum GetCenterPopupMessageState(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7d79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHUDCenterPopupMessageWidget");
			return (class UClass*)ptr;
		};

};

class UFortHUDContext : public UBlueprintContextBase
{
	public:
	    char UnknownData0[0x8];
	    MulticastDelegateProperty OnCursorModeChanging; // 0x30 Size: 0x10
	    MulticastDelegateProperty OnCursorModeChanged; // 0x40 Size: 0x10
	    MulticastDelegateProperty OnGameViewportActivationChanged; // 0x50 Size: 0x10
	    MulticastDelegateProperty OnMgmtMenuTabChangeRequested; // 0x60 Size: 0x10
	    MulticastDelegateProperty OnIndicatorModeChanged; // 0x70 Size: 0x10
	    MulticastDelegateProperty OnContextualReticleChanged; // 0x80 Size: 0x10
	    MulticastDelegateProperty OnVehicleFocused; // 0x90 Size: 0x10
	    MulticastDelegateProperty OnBuildingFocused; // 0xa0 Size: 0x10
	    MulticastDelegateProperty OnActorFocusedForCreative; // 0xb0 Size: 0x10
	    MulticastDelegateProperty OnFocusedBuildingStateChanged; // 0xc0 Size: 0x10
	    MulticastDelegateProperty OnFocusedBuildingHealthChanged; // 0xd0 Size: 0x10
	    MulticastDelegateProperty OnFocusedBuildingBigHealthChanged; // 0xe0 Size: 0x10
	    MulticastDelegateProperty OnFocusedBuildingRepairCostChanged; // 0xf0 Size: 0x10
	    MulticastDelegateProperty OnFocusedBuildingAttachedTrapDurabilityChanged; // 0x100 Size: 0x10
	    MulticastDelegateProperty OnFocusedBuildingAttachedTrapChanged; // 0x110 Size: 0x10
	    MulticastDelegateProperty OnDamagedResourceBuilding; // 0x120 Size: 0x10
	    MulticastDelegateProperty OnPlayerCanInteract; // 0x130 Size: 0x10
	    MulticastDelegateProperty OnInteractUpdated; // 0x140 Size: 0x10
	    MulticastDelegateProperty OnPlayerTargetingChanged; // 0x150 Size: 0x10
	    MulticastDelegateProperty OnScoreChanged; // 0x160 Size: 0x10
	    MulticastDelegateProperty OnScoreStatChanged; // 0x170 Size: 0x10
	    MulticastDelegateProperty OnZoneCompleted; // 0x180 Size: 0x10
	    MulticastDelegateProperty OnPawnSet; // 0x190 Size: 0x10
	    MulticastDelegateProperty OnDamageReceived; // 0x1a0 Size: 0x10
	    MulticastDelegateProperty OnUnableToPerformAction; // 0x1b0 Size: 0x10
	    MulticastDelegateProperty OnLocalPlayerMaxHealthChanged; // 0x1c0 Size: 0x10
	    MulticastDelegateProperty OnLocalPlayerHealthChanged; // 0x1d0 Size: 0x10
	    MulticastDelegateProperty OnLocalPlayerDied; // 0x1e0 Size: 0x10
	    MulticastDelegateProperty OnLocalPlayerSpawned; // 0x1f0 Size: 0x10
	    MulticastDelegateProperty OnLocalPlayerRevived; // 0x200 Size: 0x10
	    MulticastDelegateProperty OnLocalPlayerKillsChanged; // 0x210 Size: 0x10
	    MulticastDelegateProperty OnLocalPlayerPlaceChanged; // 0x220 Size: 0x10
	    MulticastDelegateProperty OnLocalPlayerViewTargetChanged; // 0x230 Size: 0x10
	    MulticastDelegateProperty OnLocalPlayerMaxShieldChanged; // 0x240 Size: 0x10
	    MulticastDelegateProperty OnLocalPlayerShieldChanged; // 0x250 Size: 0x10
	    MulticastDelegateProperty OnLocalPlayerMaxStaminaChanged; // 0x260 Size: 0x10
	    MulticastDelegateProperty OnLocalPlayerStaminaChanged; // 0x270 Size: 0x10
	    MulticastDelegateProperty OnToggleScoreboard; // 0x280 Size: 0x10
	    MulticastDelegateProperty OnEndOfDayRecap; // 0x290 Size: 0x10
	    MulticastDelegateProperty OnWaveCombatStart; // 0x2a0 Size: 0x10
	    MulticastDelegateProperty OnWaveBasedModifiersApplied; // 0x2b0 Size: 0x10
	    MulticastDelegateProperty OnActiveGameplayModifiersChanged; // 0x2c0 Size: 0x10
	    MulticastDelegateProperty OnHordeTierInitialized; // 0x2d0 Size: 0x10
	    MulticastDelegateProperty OnHordeTierComplete; // 0x2e0 Size: 0x10
	    MulticastDelegateProperty OnHordeWaveComplete; // 0x2f0 Size: 0x10
	    MulticastDelegateProperty OnBuildingMaterialCycled; // 0x300 Size: 0x10
	    MulticastDelegateProperty OnHighlightsCountChanged; // 0x310 Size: 0x10
	    MulticastDelegateProperty OnUIResetRequired; // 0x320 Size: 0x10
	    MulticastDelegateProperty OnHUDStateRefreshed; // 0x330 Size: 0x10
	    MulticastDelegateProperty OnShouldTriggerCooldownUpdate; // 0x340 Size: 0x10
	    MulticastDelegateProperty OnWeaponEquippedDelegate; // 0x350 Size: 0x10
	    MulticastDelegateProperty OnAbilityDecisionWindowStackUpdated; // 0x360 Size: 0x10
	    MulticastDelegateProperty OnItemCollectorChanged; // 0x370 Size: 0x10
	    MulticastDelegateProperty OnTotalQuantumChanged; // 0x380 Size: 0x10
	    MulticastDelegateProperty OnAllFOBCoresAdded; // 0x390 Size: 0x10
	    MulticastDelegateProperty OnWorldDaysElapsedChanged; // 0x3a0 Size: 0x10
	    MulticastDelegateProperty OnNumSurvivorsRescuedChanged; // 0x3b0 Size: 0x10
	    MulticastDelegateProperty OnEarnedBadgesChanged; // 0x3c0 Size: 0x10
	    MulticastDelegateProperty OnPotentialBadgesChanged; // 0x3d0 Size: 0x10
	    MulticastDelegateProperty OnMissionManagerCreated; // 0x3e0 Size: 0x10
	    MulticastDelegateProperty OnMissionsUpdated; // 0x3f0 Size: 0x10
	    MulticastDelegateProperty OnFocusedMissionChanged; // 0x400 Size: 0x10
	    MulticastDelegateProperty OnTheaterUniqueIDChanged; // 0x410 Size: 0x10
	    MulticastDelegateProperty OnZoneDifficultyInfoRowChanged; // 0x420 Size: 0x10
	    MulticastDelegateProperty OnDifficultyIncreaseRewardTierChanged; // 0x430 Size: 0x10
	    MulticastDelegateProperty OnDifficultyIncreaseRewardsChanged; // 0x440 Size: 0x10
	    MulticastDelegateProperty OnMissionGeneratorChanged; // 0x450 Size: 0x10
	    MulticastDelegateProperty OnMissionRewardsChanged; // 0x460 Size: 0x10
	    MulticastDelegateProperty OnPointOfInterestAdded; // 0x470 Size: 0x10
	    MulticastDelegateProperty OnPointOfInterestRemoved; // 0x480 Size: 0x10
	    char UnknownData1[0x18]; // 0x490
	    MulticastDelegateProperty OnHUDElementVisibilityChanged; // 0x4a8 Size: 0x10
	    char UnknownData2[0x10]; // 0x4b8
	    MulticastDelegateProperty OnDebugHUDObjectiveHeightChangedDelegate; // 0x4c8 Size: 0x10
	    MulticastDelegateProperty OnBuildModeChanged; // 0x4d8 Size: 0x10
	    MulticastDelegateProperty OnPersonalVehicleModeChanged; // 0x4e8 Size: 0x10
	    MulticastDelegateProperty OnPlayerVehicleStateChanged; // 0x4f8 Size: 0x10
	    MulticastDelegateProperty OnClientSettingsShowViewersChanged; // 0x508 Size: 0x10
	    bool bDebugHudObjectiveHeight; // 0x518 Size: 0x1
	    bool bPendingAttachToHUD; // 0x519 Size: 0x1
	    char UnknownData3[0x6]; // 0x51a
	    class AFortPlayerState* OwningPlayerState; // 0x520 Size: 0x8
	    class ABuildingActor* CurFocusedBuilding; // 0x528 Size: 0x8
	    class ABuildingTrap* CurFocusedTrap; // 0x530 Size: 0x8
	    char UnknownData4[0x8]; // 0x538
	    class ABuildingActor* BuildingFocusCandidates; // 0x540 Size: 0x8
	    char UnknownData5[0x10]; // 0x548
	    class AFortPlayerPawn* BoundPlayerPawn; // 0x558 Size: 0x8
	    char UnknownData6[0x560]; // 0x560
	    void UpdateTrapAttachedToBuilding(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void TriggerCooldownUpdate(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void ToggleFullScreenMap(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool ShouldOnlyShowNextPrevBuildingSlotKeybinds(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetPreparingMgmtMenu(bool bPreparing); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetIndicatorsState(EFortIndicatorState NewState); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetIndicatorsAllowed(bool bIndicatorsAllowed); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void SetHUDElementVisibility(struct FGameplayTagContainer HUDElementTags, bool bHideElements); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void SetCursorModeLocked(bool bLocked); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void RequestMgmtMenuTab(FName TabName); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void RemovePointOfInterest(class AActor* PointOfInterest); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void OnClientSettingUpdatedShowViewers(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    bool IsShowViewerCountEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    bool IsPreparingMgmtMenu(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    bool IsInEditMode(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    bool IsInCursorMode(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void HandleVehicleStateChanged(class AFortPlayerPawn* PlayerPawn, class AFortAthenaVehicle* NewVehicle, class AFortAthenaVehicle* OldVehicle); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void HandleSpectatorViewTargetChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void HandlePersonalVehicleModeChanged(bool bEnteredVehicle); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void HandleLocalPlayerViewTargetChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void HandleLocalPlayerPlaceChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void HandleLocalPlayerKillsChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void HandleLocalPawnSpawned(); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    void HandleLocalPawnRevived(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    void HandleLocalPawnDied(struct FFortPlayerDeathReport DeathReport); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    void HandleFocusedBuildingHealthChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    void HandleBuildingModeChanged(bool bEntering); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    void HandleActorFocusedForCreative(class AActor* NewActor); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    float GetTimeToDelayEndOfDayZoneWidgetDisplay(); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    class AFortPvPBaseCornerstone* GetTeamCornerstone(char Team); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    float GetScoreDisplayFactor(); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    TArray<struct FFortBadgeCount> GetPotentialBadges(); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    class AFortPlayerStateZone* GetPlayerStateZone(); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    int GetNumAllowedDifficultyIncreases(); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    void GetMissionRewards(TArray<class UFortItem*> MissionRewards, TArray<class UFortItem*> MissionAlertRewards); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    TArray<struct FZoneLoadingScreenHeadingConfig> GetMissionOverviewObjectives(); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    class AFortMissionManager* GetMissionManager(); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    struct FFortKillerVisualInfo GetKillerVisualInfoFromDeathReport(struct FFortPlayerDeathReport DeathReport); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    EFortIndicatorState GetIndicatorsState(); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    class AFortGameStateZone* GetGameStateZone(); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    class AFortMission* GetFocusedMission(); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    bool GetFocusedBuildingInfo(struct FFortFocusedBuildingInfo OutBuildingInfo); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    TArray<struct FEarnedBadgeEntry> GetEarnedBadges(); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    int GetDifficultyIncreaseRewardsTier(); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    void GetDifficultyIncreaseRewardsDifference(int BaseDifficultyIncreaseTier, int ComparedDifficultyIncreaseTier, TArray<struct FFortItemDelta> RewardDeltaInfo); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    void GetDifficultyIncreaseRewards(int DifficultyIncreaseTier, TArray<struct FFortItemDelta> DifficultyIncreaseRewards); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    struct FGameplayTagContainer GetCurrentPrimaryMissionTags(); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    struct FFortHUDState GetCurrentHUDState(); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    class UFortHero* GetCurrentHero(); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    class ABuildingActor* GetCurrentFocusedBuilding(); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    bool GetCurrentBasicMissionInfo(struct FFortBasicMissionInfo BasicMissionInfo); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    class AFortBluGloManager* GetBluGloManager(); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    void GetAccountLevelUpRewards(TArray<struct FFortItemQuantityPair> Rewards, int AccountLevel); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    void ForwardOnWeaponEquipped(class AFortWeapon* NewWeapon, class AFortWeapon* PrevWeapon); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    void ForwardOnNumSurvivorsRescuedChanged(int NumSurvivorsRescued); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    void ForwardOnMissionsUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x7fe1]; // 0x7fe1
	    void ForwardOnAbilityDecisionWindowStackUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData63[0x7fe1]; // 0x7fe1
	    void EnterCursorMode(FName ActionName, class UUserWidget* CursorModeWidget); // 0x0 Size: 0x7fe1
	    char UnknownData64[0x7fe1]; // 0x7fe1
	    void EnterCameraMode(); // 0x0 Size: 0x7fe1
	    char UnknownData65[0x7fe1]; // 0x7fe1
	    bool AreIndicatorsEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData66[0x7fe1]; // 0x7fe1
	    bool AreHUDElementsVisible(struct FGameplayTagContainer HUDElementTags); // 0x0 Size: 0x7fe1
	    char UnknownData67[0x7fe1]; // 0x7fe1
	    void AddPointOfInterest(class AActor* PointOfInterest, struct FText DisplayText, class UTexture2D* DisplayImage); // 0x0 Size: 0x7fe1
	    char UnknownData68[0x-79c1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHUDContext");
			return (class UClass*)ptr;
		};

};

class UFortHUDEquipProgressBase : public UFortHUDElementWidget
{
	public:
	    char UnknownData0[0x258];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHUDEquipProgressBase");
			return (class UClass*)ptr;
		};

};

class UFortHUDObjectiveSizeInterface : public UInterface
{
	public:
	    float GetHeightEstimate(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHUDObjectiveSizeInterface");
			return (class UClass*)ptr;
		};

};

class UFortHUDTargetUnderReticleWidget : public UCommonUserWidget
{
	public:
	    __int64/*InterfaceProperty*/ Target; // 0x230 Size: 0x10
	    bool bKeepTargetUntilNewValidTarget; // 0x240 Size: 0x1
	    char UnknownData0[0x7]; // 0x241
	    struct FGameplayTagContainer TargetRequiredTags; // 0x248 Size: 0x20
	    char UnknownData1[0x268]; // 0x268
	    void Setup(bool bInKeepTargetUntilNewValidTarget, struct FGameplayTagContainer InTargetRequiredTags); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnTargetHealthChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnTargetDied(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnTargetDestroyed(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnTargetChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnTargetActorDestroyed(class AActor* DestroyedActor); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void HandleOnHUDTargetUnderReticle(__int64/*InterfaceProperty*/ NewTarget); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void ClearTarget(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7d69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHUDTargetUnderReticleWidget");
			return (class UClass*)ptr;
		};

};

class UFortHUDVisibilityData : public UDataAsset
{
	public:
	    struct FGameplayTag HUDVisibilityGameplayTag; // 0x30 Size: 0x8
	    struct FText DisplayText; // 0x38 Size: 0x18
	    struct FText ToolTipText; // 0x50 Size: 0x18
	    bool Visible; // 0x68 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortHUDVisibilityData");
			return (class UClass*)ptr;
		};

};

class UFortInfoWindow : public UFortActivatablePanel
{
	public:
	    class UCommonListView* InfoEntries; // 0x340 Size: 0x8
	    char UnknownData0[0x348]; // 0x348
	    class UWidget* GetListWidget(class UObject* Item); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7c99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortInfoWindow");
			return (class UClass*)ptr;
		};

};

class UFortInputReflector : public UCommonInputReflector
{
	public:
	    char UnknownData0[0x260];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortInputReflector");
			return (class UClass*)ptr;
		};

};

class UFortInventoryContext : public UBlueprintContextBase
{
	public:
	    MulticastDelegateProperty OnMcpWorldItemsChanged; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnMcpOutpostItemsChanged; // 0x38 Size: 0x10
	    MulticastDelegateProperty OnWorldItemListChanged; // 0x48 Size: 0x10
	    MulticastDelegateProperty OnOutpostItemListChanged; // 0x58 Size: 0x10
	    MulticastDelegateProperty OnItemPickedUp; // 0x68 Size: 0x10
	    MulticastDelegateProperty OnQuickbarContentsChanged; // 0x78 Size: 0x10
	    MulticastDelegateProperty OnQuickbarSlotFocusChanged; // 0x88 Size: 0x10
	    MulticastDelegateProperty OnQuickbarSecondarySlotFocusChanged; // 0x98 Size: 0x10
	    MulticastDelegateProperty OnQuickbarForceFullUpdate; // 0xa8 Size: 0x10
	    MulticastDelegateProperty OnWorldItemsChanged; // 0xb8 Size: 0x10
	    MulticastDelegateProperty OnPinnedSchematicsChanged; // 0xc8 Size: 0x10
	    MulticastDelegateProperty OnSchematicsLockedChanged; // 0xd8 Size: 0x10
	    MulticastDelegateProperty OnSchematicUnlocked; // 0xe8 Size: 0x10
	    MulticastDelegateProperty OnCraftItemStarted; // 0xf8 Size: 0x10
	    MulticastDelegateProperty OnCraftItemFailed; // 0x108 Size: 0x10
	    MulticastDelegateProperty OnVaultItemLimitStateChangedEvent; // 0x118 Size: 0x10
	    MulticastDelegateProperty OnInventoryFiltersWithUnseenItemsChanged; // 0x128 Size: 0x10
	    char UnknownData0[0x18]; // 0x138
	    MulticastDelegateProperty OnItemTypesWithUnseenItemsChanged; // 0x150 Size: 0x10
	    char UnknownData1[0x30]; // 0x160
	    __int64/*MapProperty*/ SchematicLockedStates; // 0x190 Size: 0x50
	    char UnknownData2[0x1e0]; // 0x1e0
	    bool WouldExceedMaxStackSize(class UFortItemDefinition* ItemDefinition, int QuantityToTest); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void UpdateLastSeenResearchPointCollectionNodes(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void UpdateLastSeenHomebasePoints(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void UnlockSchematic(class UFortSchematicItemDefinition* SchematicDefinition); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void UnlockAllSchematics(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SortAccountItemArrayForTransmog(TArray<class UFortAccountItem*> VaultItems, TArray<class UFortAccountItem*> SortedItems); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool SetSchematicPinned(class UFortSchematicItem* Schematic, bool bEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool RemoveItemFromQuickBar(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnItemTypesWithUnseenItemsChanged__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnInventoryFiltersWithUnseenItemsChanged__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    static struct FFortItemQuantityPair MakeItemQuantityPair(class UFortItemDefinition* ItemDefinition, int ItemQuantity); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void LockAllSchematics(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    bool IsTrapAvailableForBuilding(class ABuildingSMActor* Actor); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    bool IsSlotHidden(EFortQuickBars InQuickBar, int Slot); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    bool IsSchematicPinned(class UFortSchematicItem* Schematic); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    bool IsPickAxeEquipped(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    bool HasUnseenResearchPointCollectionNodes(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    bool HasUnseenHomebasePoints(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    bool HasUnavailableItemsInStorage(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    bool HasTrapReadyForBuilding(class ABuildingSMActor* BuildingToAttachTo); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    bool HasRecyclingWarnings(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    bool HasGameplayTagContainerExact(struct FGameplayTagContainer GameplayTagContainer); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    bool HasGameplayTagContainer(struct FGameplayTagContainer GameplayTagContainer); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    bool HasEvolutions(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void HandleMcpProfilesInitialized(); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void GetWorldItemListForDeployableBaseThePlayerIsIn(TArray<class UFortWorldItem*> Items, struct FFortItemListFilter FilterSettings); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void GetWorldItemList(TArray<class UFortWorldItem*> Items, struct FFortItemListFilter FilterSettings); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    class UFortPersistentResourceItemDefinition* GetVoucherResourceItemDefinition(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    EVaultItemLimitStatus GetVaultItemLimitStatus(); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    int GetVaultItemLimit(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    static TArray<struct FText> GetUserFriendlyTags(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    struct FRecipe GetUpgradeItemRarityRecipeFromItemDefintion(class UFortItemDefinition* ItemDefinition); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    void GetUnseenTransformKeys(EConversionControlKeyRequest RequestType, EInventoryContentSortType SortType, TArray<class UFortAccountItem*> TransformKeys); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    struct FText GetTrapAttachTypeName(class ABuildingSMActor* Actor); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    bool GetTransmogSacrificeDataFromItemDefintion(class UFortItemDefinition* ItemDefinition, struct FTransmogSacrifice OutTransmogData); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    void GetTransformKeys(EConversionControlKeyRequest RequestType, EInventoryContentSortType SortType, TArray<class UFortAccountItem*> TransformKeys); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    int GetTotalItemQuantityByDefinition(class UFortItemDefinition* ItemDefinition); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    static struct FText GetTierText(char Tier); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    bool GetSupportBonusPerks(class UFortHero* Hero, TArray<struct FFortUIPerk> SupportBonusPerks); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    int GetStorageOverflowFromAddingItem(class UFortWorldItem* Item, int Count); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    int GetStorageNumItems(); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    int GetStorageCapacity(); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    static struct FText GetShorthandItemStackCount(int Quantity, int MiniumFractionalDigits, int MaximumFractionalDigits); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    class UFortPersistentResourceItemDefinition* GetSchematicResourceItemDefinition(); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    int GetResourceItemMaxStackSize(char ResourceType); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    class UFortResourceItemDefinition* GetResourceItemDefinition(char ResourceType); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    class UTexture2D* GetResourceIcon(char ResourceType); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    int GetResourceCount(char ResourceType); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    static struct FText GetRecyclingWarningText(EItemRecyclingWarning Warning, bool WereAnyItemsAnimate); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    static struct FText GetRecyclingCatalystDisplayName(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    static struct FText GetRecycleRestrictionReasonText(EItemRecyclingRestrictionReason Reason); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    class UFortItem* GetQuickBarSlottedItem(EFortQuickBars InQuickBar, int Slot); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    void GetQuickbarFocus(EFortQuickBars OutQuickBar, int OutSlot, int OutSecondarySlot, int OutPreviousFocusedSlot); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    void GetProfileItemsByType(class UFortMcpProfile* Profile, EFortItemType ItemType, TArray<class UFortAccountItem*> Items); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    void GetProfileItemsByFilterType(class UFortMcpProfile* Profile, struct FString SearchText, EInventoryContentSortType SortType, EFortInventoryFilter SubType, TArray<class UFortAccountItem*> OutItemList); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    void GetPinnedSchematicList(TArray<class UFortSchematicItem*> PinnedItems); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    class UFortPersistentResourceItemDefinition* GetPersonnelResourceItemDefinition(); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    int GetNumItemsToMulch(); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    int GetNumInInventory(class UFortItemDefinition* ItemDefinition, bool bIncludeReserved); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    int GetNumGiftingStamps(); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x7fe1]; // 0x7fe1
	    static char GetItemTierRecyclingWarningThreshold(); // 0x0 Size: 0x7fe1
	    char UnknownData63[0x7fe1]; // 0x7fe1
	    TArray<class UFortItem*> GetItemsToMulchBP(); // 0x0 Size: 0x7fe1
	    char UnknownData64[0x7fe1]; // 0x7fe1
	    static EFortRarity GetItemRarityRecyclingWarningThreshold(); // 0x0 Size: 0x7fe1
	    char UnknownData65[0x7fe1]; // 0x7fe1
	    static int GetItemLevelRecyclingWarningThreshold(); // 0x0 Size: 0x7fe1
	    char UnknownData66[0x7fe1]; // 0x7fe1
	    void GetItemInstancesByDefinition(class UFortItemDefinition* ItemDefinition, TArray<class UFortItem*> Items); // 0x0 Size: 0x7fe1
	    char UnknownData67[0x7fe1]; // 0x7fe1
	    void GetHomebaseUnlockedTransmogKeys(TArray<class UFortAccountItem*> TransmogKeys); // 0x0 Size: 0x7fe1
	    char UnknownData68[0x7fe1]; // 0x7fe1
	    class UFortPersistentResourceItemDefinition* GetHeroResourceItemDefinition(); // 0x0 Size: 0x7fe1
	    char UnknownData69[0x7fe1]; // 0x7fe1
	    bool GetHeroAbilityPerks(class UFortHero* Hero, TArray<struct FFortUIPerk> HeroAbilityPerks); // 0x0 Size: 0x7fe1
	    char UnknownData70[0x7fe1]; // 0x7fe1
	    bool GetGameplayTagByIndex(struct FGameplayTagContainer GameplayTagContainer, int Index, struct FGameplayTag Result); // 0x0 Size: 0x7fe1
	    char UnknownData71[0x7fe1]; // 0x7fe1
	    static struct FText GetEvolveRestrictionReasonText(EItemEvolutionRestrictionReason Reason); // 0x0 Size: 0x7fe1
	    char UnknownData72[0x7fe1]; // 0x7fe1
	    class AFortWeapon* GetEquippedWeapon(); // 0x0 Size: 0x7fe1
	    char UnknownData73[0x7fe1]; // 0x7fe1
	    static struct FText GetDisassembleRestrictionReasonText(EItemDisassembleRestrictionReason Reason); // 0x0 Size: 0x7fe1
	    char UnknownData74[0x7fe1]; // 0x7fe1
	    int GetDeployableBaseOverflowFromAddingItem(class UFortWorldItem* Item, int Count); // 0x0 Size: 0x7fe1
	    char UnknownData75[0x7fe1]; // 0x7fe1
	    void GetDeployableBaseItemCounts(int ItemsCount, int MaxItemsCount, int OverflowItemsCount); // 0x0 Size: 0x7fe1
	    char UnknownData76[0x7fe1]; // 0x7fe1
	    class UFortResourceItemDefinition* GetCurrentResourceItemDefinition(); // 0x0 Size: 0x7fe1
	    char UnknownData77[0x7fe1]; // 0x7fe1
	    int GetCurrentResourceCount(); // 0x0 Size: 0x7fe1
	    char UnknownData78[0x7fe1]; // 0x7fe1
	    class UFortWorldItemDefinition* GetCurrentAmmoItemDefinition(); // 0x0 Size: 0x7fe1
	    char UnknownData79[0x7fe1]; // 0x7fe1
	    int GetCountOfVaultLimitedItems(); // 0x0 Size: 0x7fe1
	    char UnknownData80[0x7fe1]; // 0x7fe1
	    int GetCountOfHeroItems(); // 0x0 Size: 0x7fe1
	    char UnknownData81[0x7fe1]; // 0x7fe1
	    void GetCoreItemsByType(EFortItemType ItemType, TArray<class UFortAccountItem*> Items); // 0x0 Size: 0x7fe1
	    char UnknownData82[0x7fe1]; // 0x7fe1
	    void GetCoreItemsByFilterType(struct FString SearchText, EInventoryContentSortType SortType, EFortInventoryFilter SubType, TArray<class UFortAccountItem*> OutItemList); // 0x0 Size: 0x7fe1
	    char UnknownData83[0x7fe1]; // 0x7fe1
	    TArray<struct FRecipe> GetConversionRecipesFromItemDefintion(class UFortItemDefinition* ItemDefinition); // 0x0 Size: 0x7fe1
	    char UnknownData84[0x7fe1]; // 0x7fe1
	    int GetBackpackOverflowFromAddingItem(class UFortWorldItem* Item, int Count); // 0x0 Size: 0x7fe1
	    char UnknownData85[0x7fe1]; // 0x7fe1
	    void GetBackpackItemCounts(int ItemsCount, int MaxItemsCount, int OverflowItemsCount); // 0x0 Size: 0x7fe1
	    char UnknownData86[0x7fe1]; // 0x7fe1
	    void GetAccountItemsByType(EFortItemType ItemType, TArray<class UFortAccountItem*> Items); // 0x0 Size: 0x7fe1
	    char UnknownData87[0x7fe1]; // 0x7fe1
	    void GetAccountItemsByFilterType(struct FString SearchText, EInventoryContentSortType SortType, EFortInventoryFilter SubType, TArray<class UFortAccountItem*> OutItemList); // 0x0 Size: 0x7fe1
	    char UnknownData88[0x7fe1]; // 0x7fe1
	    void EquipItem(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData89[0x7fe1]; // 0x7fe1
	    void EnumerateRecyclingWarningsForItems(TArray<class UFortItem*> Items, TArray<EItemRecyclingWarning> OutWarnings); // 0x0 Size: 0x7fe1
	    char UnknownData90[0x7fe1]; // 0x7fe1
	    bool DropItemOnQuickBar(class UFortItem* Item, EFortQuickBars TargetQuickbar, int TargetSlot); // 0x0 Size: 0x7fe1
	    char UnknownData91[0x7fe1]; // 0x7fe1
	    void DropItem(class UFortWorldItem* ItemBeingDropped, int Quantity); // 0x0 Size: 0x7fe1
	    char UnknownData92[0x7fe1]; // 0x7fe1
	    bool DoesItemMatchFilter(class UFortItem* Item, struct FFortItemListFilter FilterSettings); // 0x0 Size: 0x7fe1
	    char UnknownData93[0x7fe1]; // 0x7fe1
	    void DestroyWorldItem(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData94[0x7fe1]; // 0x7fe1
	    bool CraftSchematic(class UFortSchematicItem* SchematicItem, EFortCraftFailCause FailCause, char RequestedTier); // 0x0 Size: 0x7fe1
	    char UnknownData95[0x7fe1]; // 0x7fe1
	    bool CraftAndSlotSchematic(class UFortSchematicItem* SchematicItem, int PostCraftSlot, EFortCraftFailCause FailCause, char RequestedTier); // 0x0 Size: 0x7fe1
	    char UnknownData96[0x7fe1]; // 0x7fe1
	    bool CanUpgradeItemRarity(class UFortItem* Item, TArray<EItemEvolutionRestrictionReason> OutRestrictionReasons); // 0x0 Size: 0x7fe1
	    char UnknownData97[0x7fe1]; // 0x7fe1
	    bool CanSwapItem(class UFortItem* Item, EFortQuickBars TargetQuickbar, int TargetSlot); // 0x0 Size: 0x7fe1
	    char UnknownData98[0x7fe1]; // 0x7fe1
	    bool CanRecycle(class UFortItem* Item, TArray<EItemRecyclingRestrictionReason> OutRestrictionReasons); // 0x0 Size: 0x7fe1
	    char UnknownData99[0x7fe1]; // 0x7fe1
	    bool CanPinSchematic(class UFortSchematicItem* Schematic); // 0x0 Size: 0x7fe1
	    char UnknownData100[0x7fe1]; // 0x7fe1
	    bool CanItemBeMulched(class UFortItem* Item, struct FText OutRestrictionReasons); // 0x0 Size: 0x7fe1
	    char UnknownData101[0x7fe1]; // 0x7fe1
	    bool CanEvolve(class UFortItem* Item, TArray<EItemEvolutionRestrictionReason> OutRestrictionReasons); // 0x0 Size: 0x7fe1
	    char UnknownData102[0x7fe1]; // 0x7fe1
	    bool CanDisassembleItem(class UFortWorldItem* Item, TArray<EItemDisassembleRestrictionReason> OutRestrictionReasons); // 0x0 Size: 0x7fe1
	    char UnknownData103[0x7fe1]; // 0x7fe1
	    bool CanCraftSchematic(class UFortSchematicItem* SchematicItem, EFortCraftFailCause FailCause, char RequestedTier); // 0x0 Size: 0x7fe1
	    char UnknownData104[0x7fe1]; // 0x7fe1
	    bool AreRecipeRequirementsMet(TArray<struct FFortItemQuantityPair> RecipeCosts); // 0x0 Size: 0x7fe1
	    char UnknownData105[0x7fe1]; // 0x7fe1
	    bool AreAnyItemsUnseenForItemType(EFortItemType ItemType); // 0x0 Size: 0x7fe1
	    char UnknownData106[0x7fe1]; // 0x7fe1
	    bool AreAnyItemsUnseenForInventoryFilter(EFortFrontendInventoryFilter InventoryFilter); // 0x0 Size: 0x7fe1
	    char UnknownData107[0x7fe1]; // 0x7fe1
	    static bool AreAnyItemsAnimate(TArray<class UFortItem*> Items); // 0x0 Size: 0x7fe1
	    char UnknownData108[0x7fe1]; // 0x7fe1
	    bool ActivateItem(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData109[0x-7cd9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortInventoryContext");
			return (class UClass*)ptr;
		};

};

class UFortInventoryOverflowIndicator : public UFortSimpleItemConditionIconIndicator
{
	public:
	    char UnknownData0[0x460];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortInventoryOverflowIndicator");
			return (class UClass*)ptr;
		};

};

class UFortInviteRequest : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x10];
	    class UCommonButton* Button_RequestInvite; // 0x240 Size: 0x8
	    class UCommonButton* Button_Logout; // 0x248 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortInviteRequest");
			return (class UClass*)ptr;
		};

};

class UFortItemBaseWidget : public UCommonUserWidget
{
	public:
	    struct FFortItemQuantityPair ItemQuantityPair; // 0x230 Size: 0x40
	    class UFortItemDefinition* ItemDefinition; // 0x270 Size: 0x8
	    char UnknownData0[0x278]; // 0x278
	    bool SetItemQuantityPairToRepresent(struct FFortItemQuantityPair InItemQuantityPair); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetItemDefinitionToRepresent(class UFortItemDefinition* InItemDefinition); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnItemDefinitionChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnItemCountChanged(int NewCount); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleItemCountChanged(class UFortItemDefinition* Definition, int Delta); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    int GetQuantity(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    class UFortItemDefinition* GetItemDefinition(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7d69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemBaseWidget");
			return (class UClass*)ptr;
		};

};

class UFortItemWidget_NUI : public UWidget
{
	public:
	    TWeakObjectPtr<UFortItem*> ItemToRepresent; // 0x100 Size: 0x8
	    __int64/*InterfaceProperty*/ ItemViewContext; // 0x108 Size: 0x10
	    char UnknownData0[0x118]; // 0x118
	    void SetItemViewContext(__int64/*InterfaceProperty*/ ItemViewContext); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetItemToRepresent(class UFortItem* ItemToRepresent); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7eb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemWidget_NUI");
			return (class UClass*)ptr;
		};

};

class UFortItemCardBase : public UFortItemWidget_NUI
{
	public:
	    static EFortItemCardSize PortBrushSize(char BrushSize); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7eb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemCardBase");
			return (class UClass*)ptr;
		};

};

class UFortItemCardMaterialPooler : public UObject
{
	public:
	    char UnknownData0[0x120];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemCardMaterialPooler");
			return (class UClass*)ptr;
		};

};

class UFortItemCardUtilities : public UBlueprintFunctionLibrary
{
	public:
	    static struct FVector2D GetCardDimensions(EFortItemType ItemType, EFortItemCardSize CardSize, bool IsReward, bool UseNewItemCardSizes); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemCardUtilities");
			return (class UClass*)ptr;
		};

};

class UFortItemCategoryIndicator : public UFortIconWithLabel
{
	public:
	    TWeakObjectPtr<UFortItem*> ItemToRepresent; // 0x120 Size: 0x8
	    EFortItemCategoryOrdinal OrdinalOfCategoryToRepresent; // 0x128 Size: 0x1
	    char UnknownData0[0x129]; // 0x129
	    void SetOrdinalOfCategoryToRepresent(EFortItemCategoryOrdinal ItemCategoryOrdinal); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetLabelColorOverride(struct FLinearColor InLabelColorOverride); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetItemToRepresent(class UFortItem* ItemToRepresent); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void ClearLabelColorOverride(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7eb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemCategoryIndicator");
			return (class UClass*)ptr;
		};

};

class UFortItemCollectorWidget : public UFortUserWidget
{
	public:
	    class ABuildingItemCollectorActor* ItemCollector; // 0x238 Size: 0x8
	    char UnknownData0[0x240]; // 0x240
	    void OnItemCollectorValuesChanged(class UFortWorldItemDefinition* InputItem, int Goal, int deposit, int Captures); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnItemCollectorStateChanged(EFortItemCollectorState ItemCollectorState); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnItemCollectorChanged(class ABuildingItemCollectorActor* OutItemCollector); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemCollectorWidget");
			return (class UClass*)ptr;
		};

};

class UFortItemCooldownWidget : public UCommonUserWidget
{
	public:
	    MulticastDelegateProperty OnCooldownStarted_Delegate; // 0x230 Size: 0x10
	    MulticastDelegateProperty OnCooldownStopped_Delegate; // 0x240 Size: 0x10
	    class UCommonTextBlock* CooldownText; // 0x250 Size: 0x8
	    class UImage* CooldownImage; // 0x258 Size: 0x8
	    FName CooldownMaterialParameterName; // 0x260 Size: 0x8
	    TArray<EFortItemCooldownType> CooldownTypesSupported; // 0x268 Size: 0x10
	    class UMaterialInstanceDynamic* CooldownPercentageMID; // 0x278 Size: 0x8
	    char UnknownData0[0x280]; // 0x280
	    void TryStartUpdateCooldown_BP(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetItem(class UFortWorldItem* InWorldItem); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnWorldItemDestroyed(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnCooldownStopped(EFortItemCooldownType CooldownType); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnCooldownStarted(EFortItemCooldownType CooldownType); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7d19];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemCooldownWidget");
			return (class UClass*)ptr;
		};

};

class UFortItemCountTextBlock : public UCommonNumericTextBlock
{
	public:
	    class UFortItemDefinition* ItemDefinition; // 0x2e0 Size: 0x8
	    EFortItemCountStyle CountStyle; // 0x2e8 Size: 0x1
	    char UnknownData0[0x3]; // 0x2e9
	    float ItemCountMaxInterpolateDuration; // 0x2ec Size: 0x4
	    float ItemCountMinInterpolateRate; // 0x2f0 Size: 0x4
	    char UnknownData1[0x2f4]; // 0x2f4
	    void SetOverrideValue(int InOverrideValue); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetItemDefinition(class UFortItemDefinition* InItemDefinition); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetCountStyle(EFortItemCountStyle InCountStyle); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void InterpolateOverrideToValue(int TargetValue, float MaximumInterpolationDuration, float MinimumChangeRate, float OutroOffset); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleItemCountChanged(class UFortItemDefinition* Definition, int Delta); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7ce9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemCountTextBlock");
			return (class UClass*)ptr;
		};

};

class UFortItemCraftingOptionsActivatablePanel : public UFortActivatablePanel
{
	public:
	    class UFortSchematicItem* BaseItem; // 0x340 Size: 0x8
	    class UFortSchematicItem* TargetItem; // 0x348 Size: 0x8
	    int MaxCraftingTierIndex; // 0x350 Size: 0x4
	    int TargetCraftingTierIndex; // 0x354 Size: 0x4
	    bool CanCraftTargetItem; // 0x358 Size: 0x1
	    char UnknownData0[0x359]; // 0x359
	    void SetItemManagementScreen(class UFortItemManagementScreen* InItemManagementScreen); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetBaseSchematicItem(class UFortSchematicItem* InBaseItem); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SelectPreviousTier(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SelectNextTier(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnTargetItemChanged(class UFortSchematicItem* NewTargetItem); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnBaseItemChanged(class UFortSchematicItem* NewBaseItem); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void CraftTargetItem(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void CraftAndSlotTargetItem(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7c79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemCraftingOptionsActivatablePanel");
			return (class UClass*)ptr;
		};

};

class UFortItemDetailsActivatablePanel : public UCommonActivatablePanel
{
	public:
	    TWeakObjectPtr<UFortItem*> ItemToDetail; // 0x318 Size: 0x8
	    TWeakObjectPtr<UFortItem*> ItemToCompareWith; // 0x320 Size: 0x8
	    TWeakObjectPtr<UFortItemManagementScreen*> HostItemManagementScreen; // 0x328 Size: 0x8
	    char UnknownData0[0x330]; // 0x330
	    void HandleDifferentItemToDetailSetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void HandleDifferentItemToCompareSetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HandleConsumeItemProgressChangedBP(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7c91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemDetailsActivatablePanel");
			return (class UClass*)ptr;
		};

};

class UFortItemDetailsModeActivatablePanel : public UFortItemDetailsActivatablePanel
{
	public:
	    class UCommonWidgetSwitcher* DetailPanelWidgetSwitcher; // 0x350 Size: 0x8
	    char UnknownData0[0x358]; // 0x358
	    void HandleOnActiveWidgetChanged(class UWidget* ActiveWidget, int ActiveWidgetIndex); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7c89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemDetailsModeActivatablePanel");
			return (class UClass*)ptr;
		};

};

class UFortItemCompareModeActivatablePanel : public UFortItemDetailsActivatablePanel
{
	public:
	    class UFortItemManagementItemDetailsPanel* ComparisonModeLeftItemDetailsPanel; // 0x350 Size: 0x8
	    class UFortItemManagementItemDetailsPanel* ComparisonModeRightItemDetailsPanel; // 0x358 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemCompareModeActivatablePanel");
			return (class UClass*)ptr;
		};

};

class UFortItemMulchModeActivatablePanel : public UFortItemDetailsActivatablePanel
{
	public:
	    class UFortItemManagementItemDetailsPanel* MulchModeItemDetailsPanel; // 0x350 Size: 0x8
	    class UFortItemManagementMulchDetailsPanel* MulchDetailsPanel; // 0x358 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemMulchModeActivatablePanel");
			return (class UClass*)ptr;
		};

};

class UFortItemDetailElementWidget : public UCommonUserWidget
{
	public:
	    TWeakObjectPtr<UFortItem*> ItemToDetail; // 0x230 Size: 0x8
	    TWeakObjectPtr<UFortItem*> ItemToCompareWith; // 0x238 Size: 0x8
	    bool bShouldPreviewUpgradingItem; // 0x240 Size: 0x1
	    char UnknownData0[0x7]; // 0x241
	    __int64/*InterfaceProperty*/ ItemViewContext; // 0x248 Size: 0x10
	    EFortItemInspectionMode CurrentInspectMode; // 0x258 Size: 0x1
	    char UnknownData1[0x259]; // 0x259
	    void HandleShouldPreviewUpgradingItemChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HandlePreDifferentItemToDetailSet(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandlePreDifferentItemToCompareWithSet(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandlePostDifferentItemToDetailSet(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandlePostDifferentItemToCompareWithSet(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void HandleItemToDetailChangedBP(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void HandleInspectModeChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7d69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemDetailElementWidget");
			return (class UClass*)ptr;
		};

};

class UFortItemDetailsHostPanel : public UCommonUserWidget
{
	public:
	    TWeakObjectPtr<UFortItem*> ItemToDetail; // 0x230 Size: 0x8
	    TWeakObjectPtr<UFortItem*> ItemToCompareWith; // 0x238 Size: 0x8
	    bool bShouldPreviewUpgradingItem; // 0x240 Size: 0x1
	    char UnknownData0[0x7]; // 0x241
	    class UScrollBox* ScrollBox; // 0x248 Size: 0x8
	    class UNamedSlot* DetailsContainerSlotWidget; // 0x250 Size: 0x8
	    class UCommonBorder* HighRarityBorder; // 0x258 Size: 0x8
	    __int64/*InterfaceProperty*/ ItemViewContext; // 0x260 Size: 0x10
	    EFortItemInspectionMode CurrentInspectMode; // 0x270 Size: 0x1
	    char UnknownData1[0x271]; // 0x271
	    void ShouldPreviewUpgradingItem(bool Value); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetScrollWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetItemViewContext(__int64/*InterfaceProperty*/ ItemViewContext); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetItemToDetail(class UFortItem* ItemToDetail); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetItemToCompareWith(class UFortItem* ItemToCompareWith); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetInspectMode(EFortItemInspectionMode InspectMode); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void HandleShouldPreviewUpgradingItemChangedBP(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void HandleInspectModeChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void HandleDifferentItemToDetailSet(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void HandleDifferentItemToCompareSet(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x-7d49];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemDetailsHostPanel");
			return (class UClass*)ptr;
		};

};

class UFortItemDetailsPanel : public UCommonUserWidget
{
	public:
	    TWeakObjectPtr<UFortItem*> ItemToDetail; // 0x230 Size: 0x8
	    TWeakObjectPtr<UFortItem*> ItemToCompareWith; // 0x238 Size: 0x8
	    char UnknownData0[0x240]; // 0x240
	    void SetItemToDetail(class UFortItem* ItemToDetail); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetItemToCompareWith(class UFortItem* ItemToCompareWith); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HandleItemToDetailChanged(bool bItemChanged, bool bAmmoChanged, bool bIngredientsChanged); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleItemToCompareWithChanged(bool bItemChanged, bool bAmmoChanged, bool bIngredientsChanged); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleDifferentItemToDetailSet(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleDifferentItemToCompareSet(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void HandleCursorModeChanged(bool bCursorModeEnabled, FName ActionName, class UUserWidget* CustomWidget); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7d89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemDetailsPanel");
			return (class UClass*)ptr;
		};

};

class UFortItemDisplayNameText : public UCommonTextBlock
{
	public:
	    TWeakObjectPtr<UFortItem*> ItemToRepresent; // 0x260 Size: 0x8
	    char UnknownData0[0x268]; // 0x268
	    void SetItemToRepresent(class UFortItem* ItemToRepresent); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7d51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemDisplayNameText");
			return (class UClass*)ptr;
		};

};

class UFortItemEntryObjectWrapper : public UObject
{
	public:
	    struct FFortItemEntry ItemEntry; // 0x28 Size: 0xd0

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemEntryObjectWrapper");
			return (class UClass*)ptr;
		};

};

class UFortItemEntryWidget : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    class UFortItemListTileView* ParentView; // 0xb30 Size: 0x8
	    class UFortItemDefinition* ItemDefinition; // 0xb38 Size: 0x8
	    struct FFortItemEntry ItemEntry; // 0xb40 Size: 0xd0
	    char UnknownData1[0xc10]; // 0xc10
	    void OnLoadedItem(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnEntryClick(class UFortItemEntryWidget* Entry); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static class UFortItemEntryObjectWrapper* MakeFortItemEntryObjectWrapper(class UObject* Target, struct FFortItemEntry InItemEntry); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    int GetItemTypeCount(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool CompareToItemEntry(struct FFortItemEntry InItemEntry); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-73d1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemEntryWidget");
			return (class UClass*)ptr;
		};

};

class UFortItemIcon : public UWidget
{
	public:
	    class UFortItemDefinition* ItemDefinition; // 0x100 Size: 0x8
	    char BrushSize; // 0x108 Size: 0x1
	    char UnknownData0[0x3]; // 0x109
	    struct FLinearColor ColorAndOpacity; // 0x10c Size: 0x10
	    bool bShadow; // 0x11c Size: 0x1
	    char UnknownData1[0x3]; // 0x11d
	    struct FLinearColor ShadowColorAndOpacity; // 0x120 Size: 0x10
	    struct FSlateBrush SmallPreviewImageBrush; // 0x130 Size: 0x88
	    char UnknownData2[0x1b8]; // 0x1b8
	    void SetShadowColorAndOpacity(struct FLinearColor InColorAndOpacity); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetOpacity(float InOpacity); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetItemDefinition(class UFortItemDefinition* InItemDefinition); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetColorAndOpacity(struct FLinearColor InColorAndOpacity); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetBrushSize(char InBrushSize); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool IsLoading(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7db9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemIcon");
			return (class UClass*)ptr;
		};

};

class UFortItemInfoWidget : public UCommonUserWidget
{
	public:
	    void PopulateUsingItemDefinition(class UFortItemDefinition* NewItem); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void PopulateUsingItem(class UFortItem* NewItem); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7db1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemInfoWidget");
			return (class UClass*)ptr;
		};

};

class UFortItemInspectionScreen : public UFortActivatablePanelWithItemPreview
{
	public:
	    EFortItemInspectionMode CurrentInspectMode; // 0x438 Size: 0x1
	    char UnknownData0[0x3]; // 0x439
	    TWeakObjectPtr<UFortItem*> InspectedItem; // 0x43c Size: 0x8
	    bool UpgradeAllowed; // 0x444 Size: 0x1
	    bool EvolveAllowed; // 0x445 Size: 0x1
	    bool FavoriteAllowed; // 0x446 Size: 0x1
	    bool RarityUpgradingAllowed; // 0x447 Size: 0x1
	    bool IsPreviewing; // 0x448 Size: 0x1
	    bool bHasSeenRefundHelpPrompt; // 0x449 Size: 0x1
	    char UnknownData1[0x6]; // 0x44a
	    class UFortItemInspectCycleWidget* CycleWidget; // 0x450 Size: 0x8
	    struct FGameplayTagQuery InspectAnimationTag; // 0x458 Size: 0x48
	    class UFortAlterationModOptinScreenBase* AlterationModOptinScreenClass; // 0x4a0 Size: 0x8
	    class UFortAlterationModScreenBase* AlterationModScreenClass; // 0x4a8 Size: 0x8
	    struct TSoftObjectPtr<struct UDataTable*> RefundDescriptionsDataTable; // 0x4b0 Size: 0x28
	    char UnknownData2[0x4d8]; // 0x4d8
	    void SetItemToRepresent(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetInspectionMode(EFortItemInspectionMode NewInspectMode); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetAttemptingConversion(bool bIsAttemptingConversion); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OpenItemInspect(class UFortItem* ItemToInspect, EFortItemInspectionMode Mode, bool ShouldAllowUpgrading, bool ShouldAllowEvolution, bool ShouldAllowFavorite, bool IsTemporaryItem, bool bAllowRarityUpgrading); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool IsItemSlottedInCollectionBook(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void HandleItemToInspectDestroyedBP(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void HandleItemToInspectDestroyed(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void HandleItemToInspectChangedBP(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void HandleItemToInspectChanged(bool bItemChanged, bool bAmmoChanged, bool bIngredientsChanged); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void HandleIsPreviewingChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void HandleDifferentItemToInspectSetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void HandleDifferentInspectionModeSetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    class UFortAccountItem* GetRefundResultItem(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    struct FText GetRefundDescriptionText(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    class UFortItemInspectCycleWidget* GetCycleWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    bool DoesItemHaveLegacyAlterations(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void DoAlterationModification(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x-7ad9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemInspectionScreen");
			return (class UClass*)ptr;
		};

};

class UFortItemInspectCycleWidget : public UCommonUserWidget
{
	public:
	    MulticastDelegateProperty OnItemToRepresentChanged; // 0x230 Size: 0x10
	    TWeakObjectPtr<UFortItemTileView*> ItemTileView; // 0x240 Size: 0x8
	    TWeakObjectPtr<UFortItem*> ItemToRepresent; // 0x248 Size: 0x8
	    struct FDataTableRowHandle PreviousItemActionRowHandle; // 0x250 Size: 0x10
	    struct FDataTableRowHandle NextItemActionRowHandle; // 0x260 Size: 0x10
	    char UnknownData0[0x270]; // 0x270
	    void SetupActionHandlers(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetOwningItemInspectScreen(class UFortItemInspectionScreen* ItemInspect); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetItemToRepresent(class UFortItem* NewItemToRepresent); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SelectPreviousItem(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SelectNextItem(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SelectItemWithOffset(int Offset); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnItemCycled(class UFortItem* OldItem, class UFortItem* NewItem, int OffsetFromPreviousItem); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    class UFortItem* GetItemWithOffset_BP(int IndexOffset); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7d61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemInspectCycleWidget");
			return (class UClass*)ptr;
		};

};

class UFortItemListTileView : public UCommonTileView
{
	public:
	    class UFortOptionsTab* ParentTab; // 0x350 Size: 0x8
	    class UFortItem* CurrentlyFocusedItem; // 0x358 Size: 0x8
	    char UnknownData0[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemListTileView");
			return (class UClass*)ptr;
		};

};

class UFortItemManagementCustomFilterModalWidget : public UFortActivatablePanel
{
	public:
	    TWeakObjectPtr<UFortItemManagementScreen*> HostItemManagementScreen; // 0x340 Size: 0x8
	    TArray<EFortInventoryCustomFilter> AvailableFilters; // 0x348 Size: 0x10
	    __int64/*SetProperty*/ LocalCustomFilterSet; // 0x358 Size: 0x50
	    char UnknownData0[0x3a8]; // 0x3a8
	    void ToggleFilter(EFortInventoryCustomFilter Filter); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnEndCommitCustomFilter(bool bWasSuccessful); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnCustomFilterSetUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnBeginCommitCustomFilter(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool IsCustomFilterEnabled(EFortInventoryCustomFilter Filter); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void EnableAllFilters(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void DisableAllFilters(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void CommitCustomFilters(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7c39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemManagementCustomFilterModalWidget");
			return (class UClass*)ptr;
		};

};

class UFortItemManagementEquipSlot : public UFortUserWidget
{
	public:
	    int SlotIndex; // 0x238 Size: 0x4
	    char UnknownData0[0x23c]; // 0x23c
	    void UpdateInventoryChangedDelegate(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7d99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemManagementEquipSlot");
			return (class UClass*)ptr;
		};

};

class UFortItemManagementInventoryPanel : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x50];
	    FName CurrentFilterName; // 0x280 Size: 0x8
	    EInventoryContentSortType CurrentSortType; // 0x288 Size: 0x1
	    char UnknownData1[0x7]; // 0x289
	    class UCommonButton* FilterTabButtonType; // 0x290 Size: 0x8
	    class UCommonButtonStyle* FilterTabButtonStyle; // 0x298 Size: 0x8
	    TArray<struct FFortItemManagementInventoryFilterTabLabelInfo> FilterTabLabelInfoArray; // 0x2a0 Size: 0x10
	    class UFortTabListWidgetBase* FilterTabList; // 0x2b0 Size: 0x8
	    class UCommonLoadGuard* TileViewLoadGuard; // 0x2b8 Size: 0x8
	    class UFortItemTileView* TileView; // 0x2c0 Size: 0x8
	    class UPanelWidget* CraftingPanel; // 0x2c8 Size: 0x8
	    class UCommonLoadGuard* CraftingTileViewLoadGuard; // 0x2d0 Size: 0x8
	    class UFortItemTileView* CraftingTileView; // 0x2d8 Size: 0x8
	    class UPanelWidget* StoragePanel; // 0x2e0 Size: 0x8
	    class UCommonLoadGuard* StorageTileViewLoadGuard; // 0x2e8 Size: 0x8
	    class UFortItemTileView* StorageTileView; // 0x2f0 Size: 0x8
	    class UCommonTextBlock* MulchRestrictionReasonText; // 0x2f8 Size: 0x8
	    EFortItemCardSize SmallTileSize; // 0x300 Size: 0x1
	    EFortItemCardSize LargeTileSize; // 0x301 Size: 0x1
	    char UnknownData2[0x2]; // 0x302
	    TWeakObjectPtr<UFortItemManagementScreen*> HostItemManagementScreen; // 0x304 Size: 0x8
	    char UnknownData3[0x8c]; // 0x30c
	    class UFortInventoryContext* InventoryContext; // 0x398 Size: 0x8
	    char UnknownData4[0x3a0]; // 0x3a0
	    void UpdateSchematicTiles(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ToggleTileSize(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void TogglePrioritizeFavorites(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SwitchPanelFocus(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetSortType(EInventoryContentSortType SortType); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetFilter(FName FilterName); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void RequestFocusEquipSlots(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void RefreshCraftingSort(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void MarkAllItemsAsSeen(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    bool IsSwitchPanelAvailable(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void HandleSetOfItemsToMulchChangedBP(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void HandleQuickBarChangedBP(EFortQuickBars QuickBarType); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void HandleInventoryUpdatedEvent(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void HandleFocusEquipSlotsBP(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void HandleFilterTabSelected(FName TabNameID); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void HandleFilterTabButtonCreated(FName TabNameID, class UCommonButton* TabButton); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void HandleDifferentSortTypeSetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void HandleDifferentItemManagementModeSetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void HandleDifferentFrontendInventoryFilterSetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void HandleDifferentFilterSetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void HandleCustomInventoryFilterChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void HandleCursorModeChangedBP(bool bCursorModeEnabled, FName ActionName, class UUserWidget* CursorModeContentWidget); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void HandleCursorModeChanged(bool bCursorModeEnabled, FName ActionName, class UUserWidget* CursorModeContentWidget); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void HandleCraftItemStarted(); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    TArray<class UFortItemDefinition*> GetUpgradeItemDefinitionsForCurrentInventory(); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    TArray<EInventoryContentSortType> GetSupportedSortTypesForCurrentInventory(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    bool GetShouldPrioritizeFavorites(); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    struct FText GetQualifiedFilterDisplayName(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    void CycleSortType(); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    void AdvanceSelection(); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    void AddItemStackToMulch(class UFortItem* Item, int Count); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x-7c41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemManagementInventoryPanel");
			return (class UClass*)ptr;
		};

};

class UFortItemManagementItemPopupMenu : public UFortPopupMenu
{
	public:
	    void MulchItem(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void HandleItemChanged(bool bItemChanged, bool bAmmoChanged, bool bIngredientsChanged); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void HandleCompareAction(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    class UFortItemManagementItemTileButton* GetHostButton(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7ca1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemManagementItemPopupMenu");
			return (class UClass*)ptr;
		};

};

class UFortItemManagementItemTileButton : public UFortItemTileButton
{
	public:
	    TWeakObjectPtr<UFortItemManagementScreen*> HostItemManagementScreen; // 0xb58 Size: 0x8
	    bool HasTheItemToDetail; // 0xb60 Size: 0x1
	    bool HasTheItemToCompareDetailsWith; // 0xb61 Size: 0x1
	    bool HasAnItemMarkedForMulching; // 0xb62 Size: 0x1
	    char UnknownData0[0x1]; // 0xb63
	    int MulchCount; // 0xb64 Size: 0x4
	    class UOverlay* NotCraftableOverlay; // 0xb68 Size: 0x8
	    class UMenuAnchor* PopupMenuAnchor; // 0xb70 Size: 0x8
	    bool ShowCollectionBookIndicator; // 0xb78 Size: 0x1
	    bool ShowRefundIndicator; // 0xb79 Size: 0x1
	    char UnknownData1[0x46]; // 0xb7a
	    class UFortInventoryContext* InventoryContext; // 0xbc0 Size: 0x8
	    char UnknownData2[0xbc8]; // 0xbc8
	    void OnSlotItemComplete(class UFortAccountItem* SlottedItem, FName SlotId); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleShowRefundIndicatorChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleShowCollectionBookIndicatorChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleItemMulchStateChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void HandleItemChangedBP(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void HandleHasItemToDetailChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void HandleHasItemToCompareDetailsWithChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void HandleEquipSlotChanged(int EquipSlot); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void HandleDifferentItemManagementModeSetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    class UWidget* GetPopupMenu(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    EFortItemManagementMode GetItemManagementMode(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x-7419];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemManagementItemTileButton");
			return (class UClass*)ptr;
		};

};

class UFortItemManagementItemDetailsPanel : public UFortItemDetailsHostPanel
{
	public:
	    bool HasItemMarkedForMulching; // 0x298 Size: 0x1
	    char UnknownData0[0x3]; // 0x299
	    TWeakObjectPtr<UFortItemManagementScreen*> HostItemManagementScreen; // 0x29c Size: 0x8
	    char UnknownData1[0xc]; // 0x2a4
	    class UFortInventoryContext* InventoryContext; // 0x2b0 Size: 0x8
	    char UnknownData2[0x2b8]; // 0x2b8
	    void HandleHostSet(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleHasItemMarkedForMulchingChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7d29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemManagementItemDetailsPanel");
			return (class UClass*)ptr;
		};

};

class UFortItemManagementMulchDetailsPanel : public UCommonUserWidget
{
	public:
	    class UFortItemQuantityListBase* ResourceList; // 0x230 Size: 0x8
	    __int64/*InterfaceProperty*/ HostItemManagementMulchPanel; // 0x238 Size: 0x10
	    char UnknownData0[0x8]; // 0x248
	    class UFortInventoryContext* InventoryContext; // 0x250 Size: 0x8
	    char UnknownData1[0x258]; // 0x258
	    bool IsSpaceAvailableForMulch(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HandleSetOfItemsToMulchChangedBP(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleHostSet(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    TArray<class UFortItem*> GetItemsToMulch(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    TArray<int> GetItemCountsToMulch(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void CommitMulch(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7d89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemManagementMulchDetailsPanel");
			return (class UClass*)ptr;
		};

};

class UFortItemManagementModeDetailsPanel : public UCommonUserWidget
{
	public:
	    class UCommonWidgetSwitcher* ModeWidgetSwitcher; // 0x230 Size: 0x8
	    class UFortItemDetailsActivatablePanel* DetailsModeItemDetailsPanel; // 0x238 Size: 0x8
	    class UFortItemDetailsActivatablePanel* ComparisonModeItemDetailsPanel; // 0x240 Size: 0x8
	    class UFortItemDetailsActivatablePanel* MulchModeItemDetailsPanel; // 0x248 Size: 0x8
	    TWeakObjectPtr<UFortItemManagementScreen*> HostItemManagementScreen; // 0x250 Size: 0x8
	    char UnknownData0[0x258]; // 0x258
	    void HandleHostSet(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void HandleDifferentItemManagementModeSetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    EFortItemManagementMode GetItemManagementMode(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemManagementModeDetailsPanel");
			return (class UClass*)ptr;
		};

};

class UFortItemManagementMulchPanel : public UInterface
{
	public:
	    void ShowMulchConfirmationModal(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void NotifyPanelDeactivated(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void NotifyPanelActivated(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HideMulchConfirmationModal(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemManagementMulchPanel");
			return (class UClass*)ptr;
		};

};

class UFortFrontendInventoryFilterFunctionLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static struct FText ToText(EFortFrontendInventoryFilter FrontendInventoryFilter); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortFrontendInventoryFilterFunctionLibrary");
			return (class UClass*)ptr;
		};

};

class UFortItemManagementScreen : public UFortActivatablePanel
{
	public:
	    char UnknownData0[0x8];
	    MulticastDelegateProperty OnItemViewRefreshed; // 0x348 Size: 0x10
	    char UnknownData1[0xc0]; // 0x358
	    EFortItemManagementMode Mode; // 0x418 Size: 0x1
	    EFortFrontendInventoryFilter FrontendInventoryFilter; // 0x419 Size: 0x1
	    bool bReadOnlyModeWIFE; // 0x41a Size: 0x1
	    bool ConsumeItemRequestInProgress; // 0x41b Size: 0x1
	    char UnknownData2[0x4]; // 0x41c
	    class UFortItemManagementInventoryPanel* InventoryPanel; // 0x420 Size: 0x8
	    class UFortItemManagementModeDetailsPanel* ModeDetailsPanel; // 0x428 Size: 0x8
	    TWeakObjectPtr<UFortItem*> ItemToDetail; // 0x430 Size: 0x8
	    char UnknownData3[0x8]; // 0x438
	    class UFortMulchConfirmationModalWidget* MulchConfirmationModalClass; // 0x440 Size: 0x8
	    class UFortItemManagementCustomFilterModalWidget* CustomFilterModalClass; // 0x448 Size: 0x8
	    char UnknownData4[0x18]; // 0x450
	    class UFortMulchConfirmationModalWidget* MulchConfirmationModal; // 0x468 Size: 0x8
	    class UFortItemManagementCustomFilterModalWidget* CustomFilterModal; // 0x470 Size: 0x8
	    char UnknownData5[0x8]; // 0x478
	    class UFortInventoryContext* InventoryContext; // 0x480 Size: 0x8
	    char UnknownData6[0x488]; // 0x488
	    void TransferItem(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void ToggleShowRefundIndicator(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void ToggleShowCollectionBookIndicator(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void ShowMulchConfirmationModal(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void ShowCustomFilterModal(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetFrontendInventoryFilter(EFortFrontendInventoryFilter FrontendInventoryFilter); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetConsumeItemRequestInProgress(bool InProgress); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void RequestPopupMenuForSelectedItem(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void OpenCraftingOptions(class UFortSchematicItem* SchematicItem); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void NotifyPanelDeactivated(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void NotifyPanelActivated(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void MarkAllItemsAsSeen(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    bool IsScreenWIFE(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void InspectItem(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void HideMulchConfirmationModal(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void HideCustomFilterModal(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    bool HasItemBeenSeen(class UFortAccountItem* AccountItem); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void HandleTransferItemBP(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void HandleOpenCraftingOptionsBP(class UFortSchematicItem* SchematicItem); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void HandleMulchQuantitySelection(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void HandleItemToDetailChanged(bool bItemChanged, bool bAmmoChanged, bool bIngredientsChanged); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void HandleItemToCompareWithChanged(bool bItemChanged, bool bAmmoChanged, bool bIngredientsChanged); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void HandleInspectItemBP(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    void HandleEquipItemBP(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    void HandleDropItemBP(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    void HandleDifferentItemManagementModeSetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    void HandleCraftItemBP(class UFortSchematicItem* SchematicItem, char RequestedTier); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    void HandleCraftAndSlotItemBP(class UFortSchematicItem* SchematicItem, char RequestedTier); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    void HandleConsumeItemBP(class UFortConsumableAccountItem* ConsumableItem); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    bool GetShouldShowRefundIndicator(); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    bool GetShouldShowCollectionBookIndicator(); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    class UFortItem* GetItemToDetail(); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    class UFortItem* GetItemToCompareDetailsWith(); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    void EquipItem(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    void EnterMulchMode(class UFortItem* ItemToMulch); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    void EnterDetailsMode(class UFortItem* ItemToDetail); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    void EnterComparisonMode(class UFortItem* ItemToCompareDetailsWith); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    void DropItem(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    void CycleSortType(); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    void CraftItem(class UFortSchematicItem* SchematicItem, char RequestedTier); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    void CraftAndSlotItem(class UFortSchematicItem* SchematicItem, char RequestedTier); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    void ConsumeItem(class UFortConsumableAccountItem* ConsumableItem); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    bool CanRequestPopupMenuForSelectedItem(); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    void CancelInventoryPanelTileViewRefresh(); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x-7b59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemManagementScreen");
			return (class UClass*)ptr;
		};

};

class UFortItemQuantityListEntryBase : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x8];
	    int Quantity; // 0x238 Size: 0x4
	    char UnknownData1[0x23c]; // 0x23c
	    void SetPreviewData(struct FFortItemEntryPreviewData PreviewData); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetItemInstanceAndQuantity(struct FFortItemInstanceQuantityPair ItemQuantityPair, bool ShouldTreatAsReset); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetItemDefinitionAndQuantity(struct FFortItemQuantityPair ItemQuantityPair, bool ShouldTreatAsReset); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void PreviewStarted(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void PreviewEnded(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool IsBeingPreviewed(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void HandleDifferentItemOrQuantitySetBP(bool IsBeingReset); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void GetPreviewData(struct FFortItemEntryPreviewData OutPreviewData); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    class UFortItem* GetItemInstance(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    class UFortItemDefinition* GetItemDefinition(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void ClearPreviewData(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7d89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemQuantityListEntryBase");
			return (class UClass*)ptr;
		};

};

class UFortItemQuantityListBase : public UCommonUserWidget
{
	public:
	    EFortItemInspectionMode CurrentInspectMode; // 0x230 Size: 0x1
	    char UnknownData0[0x7]; // 0x231
	    class UFortItemQuantityListEntryBase* ListEntryWidgetType; // 0x238 Size: 0x8
	    __int64/*MapProperty*/ ItemObjectToWidgetMap; // 0x240 Size: 0x50
	    char UnknownData1[0x290]; // 0x290
	    void SetItemToCompareDefinitionsAndQuantities(TArray<struct FFortItemQuantityPair> ItemToCompareQuantityPairs); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetItemInstancesAndQuantities(TArray<struct FFortItemInstanceQuantityPair> ItemQuantityPairs, bool ShouldResetWidgets); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetItemInspectMode(EFortItemInspectionMode InspectMode); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetItemDefinitionsAndQuantities(TArray<struct FFortItemQuantityPair> ItemQuantityPairs, bool ShouldResetWidgets); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnItemInspectModeChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool IsEmptyList(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    TArray<class UFortItemDefinition*> GetItemDefinitions(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void AddListEntry(class UFortItemQuantityListEntryBase* ListEntry); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7d31];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemQuantityListBase");
			return (class UClass*)ptr;
		};

};

class UFortItemRatingIndicator : public UCommonUserWidget
{
	public:
	    TWeakObjectPtr<UFortItem*> ItemToRepresent; // 0x230 Size: 0x8
	    TWeakObjectPtr<UFortItem*> ItemToCompareWith; // 0x238 Size: 0x8
	    struct FFortMultiSizeBrush RatingTypeIcon; // 0x240 Size: 0x330
	    int RatingValue; // 0x570 Size: 0x4
	    EFortBuffState ComparisonResult; // 0x574 Size: 0x1
	    bool ShouldAppearEnchanted; // 0x575 Size: 0x1
	    char UnknownData0[0x576]; // 0x576
	    void SetItemViewContext(__int64/*InterfaceProperty*/ ItemViewContext); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetItemToRepresent(class UFortItem* ItemToRepresent); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetItemToCompareWith(class UFortItem* ItemToCompareWith); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleViewModelChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7a49];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemRatingIndicator");
			return (class UClass*)ptr;
		};

};

class UFortItemReceivedWidgetBase : public UFortActivatablePanelWithItemPreview
{
	public:
	    char UnknownData0[0x18];
	    TArray<struct FFortReceivedItemLootInfo> ItemDefs; // 0x450 Size: 0x10
	    class UFortGiftBoxItem* GiftBoxItem; // 0x460 Size: 0x8
	    struct FString FromUsername; // 0x468 Size: 0x10
	    class UHorizontalBox* HeaderContainer; // 0x478 Size: 0x8
	    class UScrollBox* GiftScrollBox; // 0x480 Size: 0x8
	    class UItemCardWidgetBase* ItemCardClass; // 0x488 Size: 0x8
	    char UnknownData1[0x490]; // 0x490
	    void ShowGiftBox(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetGiftBoxItem(class UFortGiftBoxItem* GiftBoxItem); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetAlignmentOnSlots(class UScrollBox* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetAlignmentOnSlot(class UScrollBox* Widget, int Index); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnGiftBoxItemSetInternal(bool bFromSelf); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnGiftBoxItemSet(bool bFromSelf); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    class UFortItem* GetTemporaryInstance(struct FFortReceivedItemLootInfo ItemReference); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7b51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemReceivedWidgetBase");
			return (class UClass*)ptr;
		};

};

class UFortItemReceivedScreen : public UFortItemReceivedWidgetBase
{
	public:
	    MulticastDelegateProperty OnFinalGiftingComplete; // 0x490 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemReceivedScreen");
			return (class UClass*)ptr;
		};

};

class UFortMessageReceivedScreen : public UFortActivatablePanel
{
	public:
	    MulticastDelegateProperty OnMessageClosed; // 0x340 Size: 0x10
	    class UFortGiftBoxItem* GiftBoxItem; // 0x350 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMessageReceivedScreen");
			return (class UClass*)ptr;
		};

};

class UFortItemReceivedPrePrompt : public UFortItemReceivedWidgetBase
{
	public:
	    MulticastDelegateProperty OnPrePromptClosed; // 0x490 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemReceivedPrePrompt");
			return (class UClass*)ptr;
		};

};

class UItemReceivedHeaderBase : public UUserWidget
{
	public:
	    class UFortGiftBoxItem* GiftBoxItem; // 0x228 Size: 0x8
	    struct FString FromUsername; // 0x230 Size: 0x10
	    char UnknownData0[0x240]; // 0x240
	    void InitFromGiftBoxItem(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7da1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.ItemReceivedHeaderBase");
			return (class UClass*)ptr;
		};

};

class UFortGiftInfo : public UObject
{
	public:
	    struct FGiftBoxInfo GiftBoxInfo; // 0x28 Size: 0x48

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortGiftInfo");
			return (class UClass*)ptr;
		};

};

class UItemCardWidgetBase : public UButton
{
	public:
	    class UFortGiftInfo* LootInfo; // 0x420 Size: 0x8
	    class UFortMultiSizeItemCard* FortMultiSizeItemCard_Widget; // 0x428 Size: 0x8
	    char UnknownData0[0x430]; // 0x430
	    void SetLootInfo(class UFortGiftInfo* LootInfo); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnLootInfoSet(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7bb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.ItemCardWidgetBase");
			return (class UClass*)ptr;
		};

};

class UFortNullItem : public UFortItem
{
	public:
	    char UnknownData0[0x88];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortNullItem");
			return (class UClass*)ptr;
		};

};

class UFortItemTransform : public UCommonActivatablePanel
{
	public:
	    void ProcessPendingSeenTransformKeys(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void OnRequestCloseItemPicker(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void LogSelectedKey(class UFortItem* SelectedKey); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7cc9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemTransform");
			return (class UClass*)ptr;
		};

};

class UFortItemView : public UObject
{
	public:
	    char UnknownData0[0x8];
	    struct FDataTableRowHandle UnifiedSupportsCameraControlInputAction; // 0x30 Size: 0x10
	    struct FDataTableRowHandle UnifiedZoomInputAction; // 0x40 Size: 0x10
	    struct FDataTableRowHandle ZoomOutInputAction; // 0x50 Size: 0x10
	    struct FDataTableRowHandle ZoomInInputAction; // 0x60 Size: 0x10
	    struct FDataTableRowHandle RotateInputAction; // 0x70 Size: 0x10
	    MulticastDelegateProperty OnItemRotaionChanged; // 0x80 Size: 0x10
	    MulticastDelegateProperty OnItemZoomLevelChanged; // 0x90 Size: 0x10
	    char UnknownData1[0x120]; // 0xa0
	    TArray<struct FDataTableRowHandle> RegisteredInputActions; // 0x1c0 Size: 0x10
	    char UnknownData2[0x1d0]; // 0x1d0
	    void UnregisterInputActions(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetSettings(struct FFortItemViewSettings Settings); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetSceneComponentToAffect(class USceneComponent* Component); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetOwningPanel(class UCommonActivatablePanel* Panel); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void RestoreInitialTransform(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void RegisterInputActions(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnUserInputChangedView__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    struct FFortItemViewSettings GetSettings(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7e11];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemView");
			return (class UClass*)ptr;
		};

};

class UFortItemViewContextInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemViewContextInterface");
			return (class UClass*)ptr;
		};

};

class UFortItemWidget : public UFortBaseButton
{
	public:
	    __int64/*DelegateProperty*/ OnGetItemToCompareDelegate; // 0x7f8 Size: 0x10
	    FName CooldownMaterialParameterName; // 0x808 Size: 0x8
	    class UMaterialInstanceDynamic* CooldownMaterial; // 0x810 Size: 0x8
	    int LastCooldownTimeInSeconds; // 0x818 Size: 0x4
	    float LastCooldownPct; // 0x81c Size: 0x4
	    bool LastIsActivatable; // 0x820 Size: 0x1
	    char UnknownData0[0xb]; // 0x821
	    int QuantityOverride; // 0x82c Size: 0x4
	    char UnknownData1[0x830]; // 0x830
	    void SetOnGetItemToCompareDelegate(__int64/*DelegateProperty*/ InDelegate); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetItem(class UFortItem* InItem, int QuantityOverride); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetCooldownMaterial(class UMaterialInstanceDynamic* NewCooldownMaterial); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnGetItemToCompare__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnFortItemUpdated(bool bItemChanged, bool bAmmoChanged, bool bIngredientsChanged); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnFortItemDestroyed(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool IsSlotted(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool IsSchematic(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool IsItemValid(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    bool IsInventoryOverflowItem(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    bool IsEquipped(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    bool HasTertiaryCategory(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    bool HasSecondaryCategory(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    bool HasLevel(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    bool HasDurability(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    float GetType(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    int GetStackCount(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    EFortRarity GetRarity(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    int GetLevel(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    class UFortItem* GetItemToCompare(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    class UFortItem* GetItem(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    class UTexture* GetIconTexture(char InBrushSize); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    float GetDurability(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    struct FText GetDisplayName(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    struct FText GetDescription(); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void BPOnItemSet(class UFortItem* NewItem); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void BPOnItemChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void BPOnCooldownSecondsChanged(int NewCooldownSeconds); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    void BPOnActivatableChanged(bool bNewActivatable); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x-77b1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemWidget");
			return (class UClass*)ptr;
		};

};

class UFortJournalQuestDetails : public UCommonUserWidget
{
	public:
	    class UFortQuestItem* CurrentQuest; // 0x230 Size: 0x8
	    char UnknownData0[0x238]; // 0x238
	    void SetCurrentQuest(class UFortQuestItem* InCurrentQuest); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void HandleCurrentQuestChangedBP(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void GetVisibleObjectives(TArray<class UFortQuestObjectiveInfo*> VisibleObjectives); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void GetRewards(TArray<struct FFortItemInstanceQuantityPair> OutRewards, TArray<struct FFortItemInstanceQuantityPair> OutSelectableRewards); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void GetFutureObjectives(TArray<class UFortQuestObjectiveInfo*> FutureObjectives); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    EFortTheaterMapTileType GetActiveMissionTileType(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool CanPlayQuest(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool CanPartyLeaderPlayQuest(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool CanGotoQuest(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7da9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortJournalQuestDetails");
			return (class UClass*)ptr;
		};

};

class UFortJournalQuestProgressBar : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x8];
	    TWeakObjectPtr<UFortQuestObjectiveInfo*> QuestObjectiveInfo; // 0x238 Size: 0x8
	    char UnknownData1[0x240]; // 0x240
	    void GetProgressDetails(struct FText OutNumerator, struct FText OutDenominator, float OutFraction); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7da1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortJournalQuestProgressBar");
			return (class UClass*)ptr;
		};

};

class UFortKeybindWidget : public UCommonUserWidget
{
	public:
	    FName BoundAction; // 0x230 Size: 0x8
	    float AxisScale; // 0x238 Size: 0x4
	    char UnknownData0[0x4]; // 0x23c
	    struct FKey BoundKeyFallback; // 0x240 Size: 0x18
	    ECommonInputType InputTypeOverride; // 0x258 Size: 0x1
	    ECommonGamepadType GamepadTypeOverride; // 0x259 Size: 0x1
	    char UnknownData1[0x2]; // 0x25a
	    FName PresetNameOverride; // 0x25c Size: 0x8
	    bool bForcedHoldKeybind; // 0x264 Size: 0x1
	    EFortKeybindForcedHoldStatus ForcedHoldKeybindStatus; // 0x265 Size: 0x1
	    bool bIsHoldKeybind; // 0x266 Size: 0x1
	    bool bShowKeybindBorder; // 0x267 Size: 0x1
	    struct FVector2D FrameSize; // 0x268 Size: 0x8
	    bool bShowTimeCountDown; // 0x270 Size: 0x1
	    char UnknownData2[0x7]; // 0x271
	    struct FKey BoundKey; // 0x278 Size: 0x18
	    struct FSlateBrush HoldProgressBrush; // 0x290 Size: 0x88
	    struct FSlateBrush KeyBindTextBorder; // 0x318 Size: 0x88
	    struct FSlateFontInfo KeyBindTextFont; // 0x3a0 Size: 0x50
	    struct FSlateFontInfo CountdownTextFont; // 0x3f0 Size: 0x50
	    struct FMeasuredText CountdownText; // 0x440 Size: 0x28
	    struct FMeasuredText KeybindText; // 0x468 Size: 0x28
	    struct FMargin KeybindTextPadding; // 0x490 Size: 0x10
	    struct FVector2D KeybindFrameMinimumSize; // 0x4a0 Size: 0x8
	    FName PercentageMaterialParameterName; // 0x4a8 Size: 0x8
	    class UMaterialInstanceDynamic* ProgressPercentageMID; // 0x4b0 Size: 0x8
	    char BrushSize; // 0x4b8 Size: 0x1
	    char UnknownData3[0x7]; // 0x4b9
	    struct FFortMultiSizeBrush FrameMultiBrush; // 0x4c0 Size: 0x330
	    char UnknownData4[0x10]; // 0x7f0
	    struct FSlateBrush CachedKeyBrush; // 0x800 Size: 0x88
	    char UnknownData5[0x888]; // 0x888
	    void UpdateKeybindWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void StopHoldProgress(FName HoldActionName, bool bCompletedSuccessfully); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void StartHoldProgress(FName HoldActionName, float HoldDuration); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetShowProgressCountDown(bool bShow); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetPresetNameOverride(FName NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetForcedHoldKeybindStatus(EFortKeybindForcedHoldStatus InForcedHoldKeybindStatus); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetForcedHoldKeybind(bool InForcedHoldKeybind); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetBrushSize(char InBrushSize); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void SetBoundKey(struct FKey NewBoundAction); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void SetBoundAction(FName NewBoundAction); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void SetAxisScale(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    bool IsHoldKeybind(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    bool IsBoundKeyValid(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    char GetBrushSize(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    bool GetBrushForKey(char InBrushSize, struct FSlateBrush Brush); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x-7759];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortKeybindWidget");
			return (class UClass*)ptr;
		};

};

class UFortLayoutQuestNode : public UCommonUserWidget
{
	public:
	    class UFortQuestMapQuestTile* QuestTile; // 0x230 Size: 0x8
	    int QuestNodeIndex; // 0x238 Size: 0x4
	    char UnknownData0[0x14];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortLayoutQuestNode");
			return (class UClass*)ptr;
		};

};

class UFortLeaderboardContext : public UBlueprintContextBase
{
	public:
	    bool CanShowStats(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    bool CanShowLeaderboards(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool CanShowGlobalLeaderboards(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortLeaderboardContext");
			return (class UClass*)ptr;
		};

};

class UFortLeaderboardEntryWidget : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    class UObject* LeaderboardEntryObject; // 0xb30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortLeaderboardEntryWidget");
			return (class UClass*)ptr;
		};

};

class UFortLegacySlateBridgeWidget : public UNativeWidgetHost
{
	public:
	    EFortLegacySlateWidget ContainedWidgetType; // 0x110 Size: 0x1
	    char UnknownData0[0x3]; // 0x111
	    float DPIScaleFactor; // 0x114 Size: 0x4
	    __int64/*DelegateProperty*/ OnClose; // 0x118 Size: 0x10
	    char UnknownData1[0x128]; // 0x128
	    void UpdateSlateWidget(EFortLegacySlateWidget SlateWidgetType); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetOnCloseHandler(__int64/*DelegateProperty*/ OnCloseHandler); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7eb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortLegacySlateBridgeWidget");
			return (class UClass*)ptr;
		};

};

class UFortLevelIndicator : public UWidget
{
	public:
	    TWeakObjectPtr<UFortItem*> ItemToRepresent; // 0x100 Size: 0x8
	    TWeakObjectPtr<UFortItem*> ItemForComparison; // 0x108 Size: 0x8
	    bool ShouldShowLabel; // 0x110 Size: 0x1
	    char UnknownData0[0x7]; // 0x111
	    class UCommonTextStyle* TextStyle; // 0x118 Size: 0x8
	    bool ShouldShowMaximumLevel; // 0x120 Size: 0x1
	    char UnknownData1[0x3]; // 0x121
	    int CurrentLevel; // 0x124 Size: 0x4
	    int MaximumLevel; // 0x128 Size: 0x4
	    bool IsComparingLevels; // 0x12c Size: 0x1
	    char ComparisonResultIndicatorSize; // 0x12d Size: 0x1
	    char UnknownData2[0x2]; // 0x12e
	    int CurrentLevelForComparison; // 0x130 Size: 0x4
	    int MaximumLevelForComparison; // 0x134 Size: 0x4
	    class UCommonTextBlock* LabelTextBlock; // 0x138 Size: 0x8
	    class UCommonNumericTextBlock* CurrentLevelNumericTextBlock; // 0x140 Size: 0x8
	    char UnknownData3[0x10]; // 0x148
	    class UCommonTextBlock* DivisionOperatorTextBlock; // 0x158 Size: 0x8
	    class UCommonNumericTextBlock* MaximumLevelNumericTextBlock; // 0x160 Size: 0x8
	    char UnknownData4[0x168]; // 0x168
	    void SetShouldShowMaximumLevel(bool InShouldShowMaximumLevel); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetItemToRepresent(class UFortItem* ItemToRepresent); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetItemForComparison(class UFortItem* ItemForComparison); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void HandleItemToRepresentChanged(bool bItemChanged, bool bAmmoChanged, bool bIngredientsChanged); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void HandleItemForComparisonChanged(bool bItemChanged, bool bAmmoChanged, bool bIngredientsChanged); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7e59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortLevelIndicator");
			return (class UClass*)ptr;
		};

};

class UFortLiveStreamGrantWindowExpires : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x230];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortLiveStreamGrantWindowExpires");
			return (class UClass*)ptr;
		};

};

class UFortLlamaStoreData : public UPrimaryDataAsset
{
	public:
	    TArray<struct FText> RandomLoadingTexts; // 0x30 Size: 0x10
	    class UFortProgressModal* ProgressModalClass; // 0x40 Size: 0x8
	    FName NotEnoughCurrencyDialogCloseAction; // 0x48 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortLlamaStoreData");
			return (class UClass*)ptr;
		};

};

class UFortLlamaStoreBase : public UFortDirectAcquisitionWidgetBase
{
	public:
	    bool ShouldUpdateOverallLlamaFlow; // 0x3b8 Size: 0x1
	    char UnknownData0[0x7]; // 0x3b9
	    TArray<struct FOfferGroup> OfferCategoriesToDisplay; // 0x3c0 Size: 0x10
	    float ShowOfferDelay; // 0x3d0 Size: 0x4
	    char UnknownData1[0x4]; // 0x3d4
	    class UDynamicEntryBox* OfferEntryBox; // 0x3d8 Size: 0x8
	    class UCommonButtonGroup* OfferButtonGroup; // 0x3e0 Size: 0x8
	    class UFortLlamaStoreDetailsBase* OfferDetails; // 0x3e8 Size: 0x8
	    class UFortLlamaStoreData* StoreData; // 0x3f0 Size: 0x8
	    class UFortProgressModal* ProgressModal; // 0x3f8 Size: 0x8
	    class UFortLlamaStoreOfferInfo* PendingPurchaseOffer; // 0x400 Size: 0x8
	    char UnknownData2[0x408]; // 0x408
	    void SwapToCardEnterState(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetupFocus(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnStoreStateChanged(EFortStoreState NewStoreState); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnStorePurchaseCompleted(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void FinishViewingCardPackOpening(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void CreateTencentPuchaseOpenModal(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void CreateCardPackOpeningWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7bb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortLlamaStoreBase");
			return (class UClass*)ptr;
		};

};

class UFortLlamaStoreDetailsBase : public UCommonUserWidget
{
	public:
	    class UFortStoreFrontOfferInfo* OfferInfo; // 0x230 Size: 0x8
	    class UCommonTileView* ItemTileView; // 0x238 Size: 0x8
	    char UnknownData0[0x240]; // 0x240
	    void SetScrollWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnOfferInfoChanged(struct FDateTime DateTime); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7da1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortLlamaStoreDetailsBase");
			return (class UClass*)ptr;
		};

};

class UFortStoreFrontOfferInfo : public UObject
{
	public:
	    char UnknownData0[0x18];
	    class UFortMtxOfferData* OfferDisplayAsset; // 0x40 Size: 0x8
	    char UnknownData1[0x48]; // 0x48
	    bool WasPrerollItemSeen(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool OfferHasDenyRequirements(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void MarkPrerollAsSeen(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool IsValidOffer(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool IsUnique(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool IsRefundable(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool IsPriceInRealMoney(int PriceIndex); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool IsPriceInMTX(int PriceIndex); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool IsPrerollOffer(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    bool IsLockedByRequirement(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    bool isItemGrantUnique(struct FString TemplateId); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    bool IsItemDefOwned(class UFortItemDefinition* ItemDef); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    bool IsGiftOnly(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    bool IsGiftable(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    bool IsExclusive(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    bool IsCurrencyVoucher(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    bool IsCardpack(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    bool HasRequirement(struct FText RequirementText); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    bool HasMaxLevel(int MaxLevel); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    bool HasDisplayAsset(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    bool HasCatalogOfferName(struct FText CatalogOfferName); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    int GetTotalQuantity(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    struct FSlateBrush GetTileImage(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    FName GetStorefrontName(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    int GetSortPriority(); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    struct FText GetShortName(); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    struct FText GetShortDescription(); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    char GetSaleType(int PriceIndex); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    struct FText GetSaleText(int PriceIndex, int ItemQuantity); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    bool GetSalePrice(int PriceIndex, struct FText SalePrice, int ItemQuantity); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    ECatalogRequirementType GetRequirementTypeAtIndex(int RequirementIndex); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    int GetRequirementMinQuantityAtIndex(int RequirementIndex); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    struct FString GetRequirementIdAtIndex(int RequirementIndex); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    int GetQuantityRemaining(); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    class UFortAccountItemDefinition* GetPriceItem(int PriceIndex, int RequiredItemCount); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    int GetPrerollRarity(); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    bool GetPrerollOfferItem(struct FFortItemQuantityPair ItemQuantityPair); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    ECatalogOfferType GetOfferType(); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    struct FString GetOfferId(); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    class UFortMtxOfferData* GetOfferDisplayAsset(); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    struct FCatalogOffer GetOffer(); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    int GetNumRequirements(); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    int GetNumGrantedItems(); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    struct FText GetNormalPrice(int PriceIndex, int ItemQuantity); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    struct FText GetName(); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    bool GetMetaAsBool(struct FString MetaTag); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    int GetMaxConcurrentPurchases(); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    struct FText GetItemTypeText(); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    int GetItemQuantity(struct FString TemplateId); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    int GetItemOfferCount(struct FString TemplateId); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    void GetGrantedItemQuantityPairs(bool bPrioritizeUnowned, TArray<struct FFortItemQuantityPair> ItemQuantityPairs); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    bool GetGrantedItemQuantityPair(int GrantedItemIndex, struct FFortItemQuantityPair ItemQuantity); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    int GetGrantedItemQuantity(int GrantedItemIndex); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    void GetGrantedItemDefinitions(TArray<class UFortAccountItemDefinition*> GrantedItems); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    class UFortAccountItemDefinition* GetGrantedItemDefinition(int GrantedItemIndex); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    struct FFortMtxGradient GetGradient(); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    EFortMtxStoreOfferType GetFortStoreOfferType(); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    struct FString GetFortStoreOfferCategory(); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    struct FString GetForcedGiftBoxTemplateId(); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    int GetFirstGrantQuantity(); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    class UFortAccountItemDefinition* GetFirstGrantItemDefinition(); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x7fe1]; // 0x7fe1
	    void GetDynamicBundleItems(TArray<struct FBundledItemInfo> Items); // 0x0 Size: 0x7fe1
	    char UnknownData63[0x7fe1]; // 0x7fe1
	    struct FString GetDisplayAssetPath(); // 0x0 Size: 0x7fe1
	    char UnknownData64[0x7fe1]; // 0x7fe1
	    struct FSlateBrush GetDetailsImage(); // 0x0 Size: 0x7fe1
	    char UnknownData65[0x7fe1]; // 0x7fe1
	    TArray<struct FFortMtxDetailsAttribute> GetDetailsAttributes(); // 0x0 Size: 0x7fe1
	    char UnknownData66[0x7fe1]; // 0x7fe1
	    struct FText GetDescription(); // 0x0 Size: 0x7fe1
	    char UnknownData67[0x7fe1]; // 0x7fe1
	    class UFortAccountItemDefinition* GetCurrencyItemDefinition(); // 0x0 Size: 0x7fe1
	    char UnknownData68[0x7fe1]; // 0x7fe1
	    struct FText GetCategoryText(); // 0x0 Size: 0x7fe1
	    char UnknownData69[0x7fe1]; // 0x7fe1
	    int GetBonusQuantity(); // 0x0 Size: 0x7fe1
	    char UnknownData70[0x7fe1]; // 0x7fe1
	    int GetBaseQuantity(); // 0x0 Size: 0x7fe1
	    char UnknownData71[0x7fe1]; // 0x7fe1
	    struct FString GetBannerOverrideTag(); // 0x0 Size: 0x7fe1
	    char UnknownData72[0x7fe1]; // 0x7fe1
	    struct FLinearColor GetBackground(); // 0x0 Size: 0x7fe1
	    char UnknownData73[0x7fe1]; // 0x7fe1
	    class UFortAccountItem* CreatePreviewItem(); // 0x0 Size: 0x7fe1
	    char UnknownData74[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortStoreFrontOfferInfo");
			return (class UClass*)ptr;
		};

};

class UFortLlamaStoreOfferInfo : public UFortStoreFrontOfferInfo
{
	public:
	    class UFortPackPersonality* GetMetaAssetPersonality(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    struct TSoftObjectPtr<struct UTexture2D*> GetMetaAssetImage(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    class UTexture* GetMetaAssetIcon(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortLlamaStoreOfferInfo");
			return (class UClass*)ptr;
		};

};

class UFortStoreFrontOfferWidgetBase : public UCommonButton
{
	public:
	    TArray<class UFortStoreFrontOfferInfo*> GroupedOffers; // 0xb28 Size: 0x10
	    class UFortStoreFrontOfferInfo* OfferData; // 0xb38 Size: 0x8
	    char UnknownData0[0xb40]; // 0xb40
	    void SetupOffer(class UFortStoreFrontOfferInfo* InOfferData); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void RemoveAllOffers(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnUpdateStatus(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnOfferSet(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnOfferAdded(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleCurrentlyViewedAccountInfoChanged(struct FFortPublicAccountInfo NewInfo); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    class UFortStoreFrontOfferInfo* GetOfferInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void AddOffer(class UFortStoreFrontOfferInfo* InOfferData); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-74a1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortStoreFrontOfferWidgetBase");
			return (class UClass*)ptr;
		};

};

class UFortLlamaStoreOfferWidgetBase : public UFortStoreFrontOfferWidgetBase
{
	public:
	    void RequestPurchase(int Quantity); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void OnOfferShown(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7491];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortLlamaStoreOfferWidgetBase");
			return (class UClass*)ptr;
		};

};

class UFortLobby : public UCommonActivatablePanel
{
	public:
	    char UnknownData0[0x10];
	    class UOverlay* OverlayMain; // 0x328 Size: 0x8
	    char UnknownData1[0x330]; // 0x330
	    void OnPlayerClicked(int PlayerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnNavigationRight(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnNavigationLeft(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnEndCursorOverPlayer(int PlayerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnBeginCursorOverPlayer(int PlayerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void DynamicHandleLoadingScreenVisibilityChanged(bool IsVisible); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7cb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortLobby");
			return (class UClass*)ptr;
		};

};

class UFortLobbyAddPlayer : public UFortTeamMemberEntryBase
{
	public:
	    char UnknownData0[0x10];
	    class UFortSocialPanel* SocialPanelClass; // 0x250 Size: 0x8
	    char UnknownData1[0x8]; // 0x258
	    class UCommonButton* Button_EmptySlot; // 0x260 Size: 0x8
	    class UFortPartySuggestionButton* PartySuggestion; // 0x268 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortLobbyAddPlayer");
			return (class UClass*)ptr;
		};

};

class UFortLocalUserEntry : public UCommonButton
{
	public:
	    class UFortOnlineStatusPanel* OnlineStatusPanelClass; // 0xb28 Size: 0x8
	    class UFortOnlineStatusPanel* OnlineStatusPanel; // 0xb30 Size: 0x8
	    class UFortPlayerBanner* PlayerBanner; // 0xb38 Size: 0x8
	    class UTextBlock* Text_UserName; // 0xb40 Size: 0x8
	    class UTextBlock* Text_RichPresence; // 0xb48 Size: 0x8
	    class UMenuAnchor* MenuAnchor_OnlineStatusPanel; // 0xb50 Size: 0x8
	    char UnknownData0[0xb58]; // 0xb58
	    void OnOnlineStatusChanged(ELocalUserOnlineStatus OnlineStatus); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    class UWidget* HandleGetMenuContent(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7489];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortLocalUserEntry");
			return (class UClass*)ptr;
		};

};

class UFortLoginCredentialSelect : public UCommonActivatablePanel
{
	public:
	    char UnknownData0[0x38];
	    class UCommonButton* Button_Epic; // 0x350 Size: 0x8
	    class UCommonButton* Button_Facebook; // 0x358 Size: 0x8
	    class UCommonButton* Button_Google; // 0x360 Size: 0x8
	    class UCommonButton* Button_PS; // 0x368 Size: 0x8
	    class UCommonButton* Button_XB; // 0x370 Size: 0x8
	    class UCommonButton* Button_Erebus; // 0x378 Size: 0x8
	    class UCommonButton* Button_CreateAccount; // 0x380 Size: 0x8
	    class UCommonButton* Button_NoXB; // 0x388 Size: 0x8
	    class UCommonButton* Button_NoSony; // 0x390 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortLoginCredentialSelect");
			return (class UClass*)ptr;
		};

};

class UFortLoginResultWidget : public UCommonActivatablePanel
{
	public:
	    char UnknownData0[0x10];
	    class UCommonTextStyle* ErrorStyle; // 0x328 Size: 0x8
	    class UCommonTextStyle* NoErrorStyle; // 0x330 Size: 0x8
	    char UnknownData1[0x8]; // 0x338
	    class UCommonTextBlock* Text_Title; // 0x340 Size: 0x8
	    class UCommonTextBlock* Text_Description; // 0x348 Size: 0x8
	    class UCommonButton* Button_Continue; // 0x350 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortLoginResultWidget");
			return (class UClass*)ptr;
		};

};

class UFortLoginStatus : public UCommonActivatablePanel
{
	public:
	    char UnknownData0[0x10];
	    class UCommonTextBlock* Text_Title; // 0x328 Size: 0x8
	    class UCommonTextBlock* Text_Status; // 0x330 Size: 0x8
	    class UCommonButton* Button_Status; // 0x338 Size: 0x8
	    char UnknownData1[0x340]; // 0x340
	    void SetTitleText(struct FText TitleText); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetLoginStatus(struct FText InLoginStatus); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7ca1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortLoginStatus");
			return (class UClass*)ptr;
		};

};

class UFortLoginUnavailable : public UCommonUserWidget
{
	public:
	    struct FText DisableMessage; // 0x230 Size: 0x18
	    struct FText DisableButtonMsg; // 0x248 Size: 0x18
	    struct FText InviteClosedMessage; // 0x260 Size: 0x18
	    struct FText InviteButtonMsg; // 0x278 Size: 0x18
	    char UnknownData0[0x8]; // 0x290
	    class UCommonTextBlock* Text_Title; // 0x298 Size: 0x8
	    class UCommonTextBlock* Text_DisplayMsg; // 0x2a0 Size: 0x8
	    char UnknownData1[0x2a8]; // 0x2a8
	    void OnMessageSet(bool bDisableMessage); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void LaunchSpecificURL(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortLoginUnavailable");
			return (class UClass*)ptr;
		};

};

class UFortMainMenu : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x230];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMainMenu");
			return (class UClass*)ptr;
		};

};

class UFortMainTabsScreenBase : public UCommonActivatablePanel
{
	public:
	    __int64/*MapProperty*/ FeaturesTabsMap; // 0x318 Size: 0x50
	    class UHorizontalBox* TopTabContainer; // 0x368 Size: 0x8
	    class UFortTabListWidgetBase* TopTabList; // 0x370 Size: 0x8
	    char UnknownData0[0x378]; // 0x378
	    void HandleMainTabSelected(FName TabNameID); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void HandleMainTabCreated(FName TabNameID, class UCommonButton* TabButton); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HandleFeatureStateChanged(EFortUIFeature ChangedFeature, EFortUIFeatureState NewState, EFortUIFeatureStateReason Reason); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleFeatureNavigateRequest(EFortUIFeature Feature); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void ConstructTabs(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7c61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMainTabsScreenBase");
			return (class UClass*)ptr;
		};

};

class UFortMatchmakingKnobsSpinnerButton : public UCommonRotator
{
	public:
	    char UnknownData0[0x10];
	    class UCommonTextBlock* OptionDisplayName; // 0xb78 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMatchmakingKnobsSpinnerButton");
			return (class UClass*)ptr;
		};

};

class UFortMaterialProgressBarStyle : public UObject
{
	public:
	    FName BackgroundColorParamName; // 0x28 Size: 0x8
	    struct FLinearColor BackgroundColor; // 0x30 Size: 0x10
	    struct FFortMaterialProgressBarSectionStyle* BarSectionStyles; // 0x40 Size: 0x3c
	    char UnknownData0[0xb4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMaterialProgressBarStyle");
			return (class UClass*)ptr;
		};

};

class UFortMaterialProgressBar : public UCommonUserWidget
{
	public:
	    class UFortMaterialProgressBarStyle* Style; // 0x230 Size: 0x8
	    FName BackgroundColorParamName; // 0x238 Size: 0x8
	    struct FLinearColor BackgroundColor; // 0x240 Size: 0x10
	    EFortMaterialProgressBarSectionOverflowBehavior OverflowBehavior; // 0x250 Size: 0x1
	    char UnknownData0[0x3]; // 0x251
	    struct FFortMaterialProgressBarSectionInfo* BarSectionInfo; // 0x254 Size: 0x40
	    char UnknownData1[0xc4]; // 0x294
	    class UCommonBorder* ProgressBar; // 0x358 Size: 0x8
	    class UMaterialInstanceDynamic* ProgressBarMID; // 0x360 Size: 0x8
	    char UnknownData2[0x368]; // 0x368
	    void SetStyle(class UFortMaterialProgressBarStyle* BarStyle); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetProgressBarSectionPercent(char BarSection, float Percent); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetProgressBarSectionColor(char BarSection, struct FLinearColor Color, EFortMaterialProgressBarSectionColorNumber ColorNumber); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetBackgroundColor(struct FLinearColor Color); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7c79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMaterialProgressBar");
			return (class UClass*)ptr;
		};

};

class UFortMicIndicatorWidget : public UCommonUserWidget
{
	public:
	    void SetPlayerUniqueId(struct FUniqueNetIdRepl InPlayerUniqueId); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void OnPlayerTalkingChanged(bool bIsTalking); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnPlayerMuted(bool bIsMuted); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnPlayerMicAvailable(bool bIsTalking); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMicIndicatorWidget");
			return (class UClass*)ptr;
		};

};

class UFortMissionActivationInfo : public UObject
{
	public:
	    bool bIsMultiplayer; // 0x28 Size: 0x1
	    char UnknownData0[0x77]; // 0x29
	    class AFortPlayerController* FortPC; // 0xa0 Size: 0x8
	    class AFortGameStateZone* GameStateZone; // 0xa8 Size: 0x8
	    class UCurveFloat* DifficultyIncreaseBluGloCurve; // 0xb0 Size: 0x8
	    char UnknownData1[0xb8]; // 0xb8
	    struct FText TimeSecondsToText(float InSeconds); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SubmitVote(EFortVoteType VoteType, bool bApprove); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void RequestVote(EFortVoteType VoteType, float VoteDuration, float FailedVoteLockOutDuration, EFortVoteArbitratorType ArbitratorType); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool IsVoteLocked(EFortVoteType VoteType); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool IsVoteActive(EFortVoteType VoteType); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool IsPlayerVoteInstigator(EFortVoteType VoteType); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool IsAnyVoteActive(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool HasPlayerVoted(EFortVoteType VoteType); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void HandleTeamMemberRemoved(int RemovedIndex); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void HandleTeamMemberAdded(struct FFortTeamMemberInfo NewInfo); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void HandleGameplayVoteUpdated(EFortVoteType VoteType, EFortVoteStatus VoteStatus, int VoteResult, TArray<struct FVoter> Voters); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    float GetVoteTimeRemaining(EFortVoteType VoteType); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    TArray<struct FVoter> GetVoters(EFortVoteType VoteType); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void GetVoteCounts(EFortVoteType VoteType, int OutYesVoteCount, int OutNoVoteCount); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    int GetStartObjectiveBluGloRequirement(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    class UFortMissionInfo* GetPrimaryMissionInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    class AFortMission* GetPrimaryMission(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    EFortVoteType GetMissionVoteType(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    float GetMissionObjectiveTimeRemaining(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    struct FText GetLockoutTimeRemaining(EFortVoteType VoteType); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    struct FUniqueNetIdRepl GetInstigatorId(EFortVoteType VoteType); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    int GetIncreaseDifficultyBluGloRequirement(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void GetDeltaRewards(int BaseDifficultyIncreaseTier, int ComparedDifficultyIncreaseTier, TArray<struct FFortItemDelta> DeltaRewards); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    int GetAvailableBluGloCount(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    EFortVoteArbitratorType GetArbitratorType(EFortVoteType VoteType); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    bool DoesPrimaryMissionContainTags(struct FGameplayTagContainer Tags); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    bool CanRequestVote(EFortVoteType VoteType); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x-7e69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMissionActivationInfo");
			return (class UClass*)ptr;
		};

};

class UFortMissionActivationWidgetPanel : public UCommonUserWidget
{
	public:
	    class UFortMissionActivationInfo* InfoObject; // 0x230 Size: 0x8
	    char UnknownData0[0x238]; // 0x238
	    void SetInfoObject(class UFortMissionActivationInfo* NewInfoObject); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnVoteUpdatedBP(EFortVoteType VoteType); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnVoteLockoutChangedBP(EFortVoteType VoteType, bool bIsLocked); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnMultiplayerChangedBP(bool bIsMultiplayer); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnActiveVoteChangedBP(EFortVoteType VoteType, bool bIsVoteActive, int VoteResult); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void InfoObjectUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7d89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMissionActivationWidgetPanel");
			return (class UClass*)ptr;
		};

};

class UFortMissionActivationWidget : public UFortActivatablePanel
{
	public:
	    class UFortMissionActivationInfo* InfoObject; // 0x340 Size: 0x8
	    struct FGameplayTagContainer ReadyUpObjectiveHandle; // 0x348 Size: 0x20
	    class UCurveFloat* DifficultyIncreaseBluGloCurve; // 0x368 Size: 0x8
	    char UnknownData0[0x370]; // 0x370
	    void RequestStartObjectiveState(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void RequestDifficultyIncreaseState(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void RequestDefaultState(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnVoteLockoutChangedBP(EFortVoteType VoteType, bool bIsLocked); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnStateUpdated(EFortMissionActivationWidgetState ActiveState, EFortMissionActivationWidgetState PreviousState); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnMultiplayerChangedBP(bool bIsMultiplayer); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnActiveVoteChangedBP(EFortVoteType VoteType, bool bIsVoteActive, int VoteResult); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    EFortMissionActivationWidgetState GetCurrentState(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7c51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMissionActivationWidget");
			return (class UClass*)ptr;
		};

};

class UFortMissionSelect : public UCommonActivatablePanel
{
	public:
	    char UnknownData0[0x10];
	    MulticastDelegateProperty OnNavigation; // 0x328 Size: 0x10
	    char UnknownData1[0x338]; // 0x338
	    bool NavigateMissionTiles(EUINavigation Direction); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool CanCaptureAcceptInput(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7ca9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMissionSelect");
			return (class UClass*)ptr;
		};

};

class UFortMissionTracker : public UFortHUDElementWidget
{
	public:
	    class UFortMissionTrackerList* MissionTrackerList; // 0x258 Size: 0x8
	    class UFortQuestTrackerList* MainQuestList; // 0x260 Size: 0x8
	    class UFortQuestTrackerList* PinnedQuestsList; // 0x268 Size: 0x8
	    class UWidget* AdditionalEntriesIndicator; // 0x270 Size: 0x8
	    class UCommonNumericTextBlock* DebugHeightEstimate; // 0x278 Size: 0x8
	    float AllowedSize; // 0x280 Size: 0x4
	    bool bEnforceHeightLimit; // 0x284 Size: 0x1
	    bool bSizeEstimateNeedsRefresh; // 0x285 Size: 0x1
	    char UnknownData0[0x286]; // 0x286
	    void RefreshSizeEstimate(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void HandleSizeEstimateChanged(class UObject* ChangedElement); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HandleDebugHUDObjectiveHeightChanged(bool bIsDebugging); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMissionTracker");
			return (class UClass*)ptr;
		};

};

class UFortMissionTrackerEntry : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x8];
	    MulticastDelegateProperty OnMissionEntryVisibilityChanged; // 0x238 Size: 0x10
	    class UFortMissionTrackerSubEntry* SubEntryClass; // 0x248 Size: 0x8
	    bool bConfigureAsHUD; // 0x250 Size: 0x1
	    bool bHiddenByHeightConstraint; // 0x251 Size: 0x1
	    char UnknownData1[0x6]; // 0x252
	    class UCommonTextBlock* MissionNameText; // 0x258 Size: 0x8
	    class UVerticalBox* ObjectivesListBox; // 0x260 Size: 0x8
	    class UImage* UpperSeparator; // 0x268 Size: 0x8
	    class AFortMission* TrackedMission; // 0x270 Size: 0x8
	    MulticastDelegateProperty OnSizeEstimateChangedDelegate; // 0x278 Size: 0x10
	    char UnknownData2[0x288]; // 0x288
	    void UpdateVisibility(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnMissionSet(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleObjectivesChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleMissionInfoSet(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7d09];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMissionTrackerEntry");
			return (class UClass*)ptr;
		};

};

class UFortMissionTrackerList : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x8];
	    class UFortMissionTrackerEntry* MissionEntryClass; // 0x238 Size: 0x8
	    bool bConfigureAsHUD; // 0x240 Size: 0x1
	    char UnknownData1[0x7]; // 0x241
	    class UVerticalBox* MissionsListBox; // 0x248 Size: 0x8
	    MulticastDelegateProperty OnMissionTrackerListVisibilityChanged; // 0x250 Size: 0x10
	    MulticastDelegateProperty OnSizeEstimateChangedDelegate; // 0x260 Size: 0x10
	    char UnknownData2[0x270]; // 0x270
	    void UpdateVisibility(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleSizeEstimateChanged(class UObject* ChangedElement); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleMissionsUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7d21];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMissionTrackerList");
			return (class UClass*)ptr;
		};

};

class UFortMissionTrackerSubEntry : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x8];
	    MulticastDelegateProperty OnMissionSubEntryVisibilityChanged; // 0x238 Size: 0x10
	    bool bConfigureAsHUD; // 0x248 Size: 0x1
	    bool bHiddenByHeightConstraint; // 0x249 Size: 0x1
	    char UnknownData1[0x6]; // 0x24a
	    class AFortObjectiveBase* TrackedObjective; // 0x250 Size: 0x8
	    MulticastDelegateProperty OnSizeEstimateChangedDelegate; // 0x258 Size: 0x10
	    char UnknownData2[0x268]; // 0x268
	    void OnObjectiveSet(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnHiddenByHeightConstraintChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void NotifyVisibilityChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7d79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMissionTrackerSubEntry");
			return (class UClass*)ptr;
		};

};

class UFortMissionVoteHUDElementWidget : public UFortHUDElementWidget
{
	public:
	    void RegisterFailsafeForVoteType(EFortVoteType VoteType); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void OnVoteUpdated(EFortVoteType VoteType, int YesVoteCount, int NoVoteCount); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnVoteStarted(EFortVoteType VoteType, EFortVoteArbitratorType ArbitratorType, int YesVoteCount, int NoVoteCount); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnVoteEnded(EFortVoteType VoteType, EFortVoteArbitratorType ArbitratorType, bool VoteSucceeded); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool IsMultiplayerVote(EFortVoteType VoteType); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool HasLocalPlayerVoted(EFortVoteType VoteType); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleMissionActivationVoteUpdate(EFortVoteType VoteType, EFortVoteStatus VoteStatus, int VoteResult, TArray<struct FVoter> Voters); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void HandleDifficultyIncreaseVoteUpdate(EFortVoteType VoteType, EFortVoteStatus VoteStatus, int VoteResult, TArray<struct FVoter> Voters); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    int GetVoteTimeRemaining(EFortVoteType VoteType); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7d59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMissionVoteHUDElementWidget");
			return (class UClass*)ptr;
		};

};

class UFortModalContainerData : public UDataAsset
{
	public:
	    TArray<struct FFortModalContainerSizeEntry> Entries; // 0x30 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortModalContainerData");
			return (class UClass*)ptr;
		};

};

class UFortModalContainerWidget : public UWidget
{
	public:
	    char UnknownData0[0x8];
	    EModalContainerSize SizeConstraint; // 0x108 Size: 0x1
	    char UnknownData1[0x7]; // 0x109
	    TArray<struct FFortModalContainerSizeEntry> DefaultSizeEntries; // 0x110 Size: 0x10
	    class UFortModalContainerData* OverrideSizeEntries; // 0x120 Size: 0x8
	    class UWidget* TopContent; // 0x128 Size: 0x8
	    class UWidget* MiddleContent; // 0x130 Size: 0x8
	    class UWidget* BottomContent; // 0x138 Size: 0x8
	    class UWidget* BackgroudContent; // 0x140 Size: 0x8
	    char UnknownData2[0x10];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortModalContainerWidget");
			return (class UClass*)ptr;
		};

};

class UFortMOTDWidget : public UCommonActivatablePanel
{
	public:
	    char UnknownData0[0x10];
	    class UCommonTextBlock* Text_Header; // 0x328 Size: 0x8
	    class UCommonTextBlock* Text_Body; // 0x330 Size: 0x8
	    class UCommonButton* Button_Close; // 0x338 Size: 0x8
	    class UScrollBox* ScrollBox; // 0x340 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMOTDWidget");
			return (class UClass*)ptr;
		};

};

class UFortMovieWidget : public UFortUserWidget
{
	public:
	    MulticastDelegateProperty OnMediaOpened; // 0x238 Size: 0x10
	    class UMediaPlayer* MediaPlayer; // 0x248 Size: 0x8
	    class UMediaTexture* MediaTexture; // 0x250 Size: 0x8
	    class UMediaSoundComponent* SoundComponent; // 0x258 Size: 0x8
	    char UnknownData0[0x260]; // 0x260
	    bool SetMediaSource(class UMediaSource* InMediaSource, struct FMediaPlayerOptions PlayerOptions, bool bPlayOnOpen, bool bLooping); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void RequestStopMovie(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void RequestPlayMovie(bool bShouldRewind); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void MediaDimensionsUpdated(float NewWidth, float NewHeight); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool HasPlayerForSource(class UMediaSource* InMediaSource); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    class UMediaTexture* GetMediaTexture(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    class UMediaSoundComponent* GetMediaSoundComponent(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    class UMediaPlayer* GetMediaPlayer(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7d81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMovieWidget");
			return (class UClass*)ptr;
		};

};

class UFortMtxOfferData : public UPrimaryDataAsset
{
	public:
	    struct FText DisplayName; // 0x30 Size: 0x18
	    struct FText ShortDisplayName; // 0x48 Size: 0x18
	    struct FText ShortDescription; // 0x60 Size: 0x18
	    TArray<struct FFortItemQuantityPair> GrantOverride; // 0x78 Size: 0x10
	    struct FSlateBrush TileImage; // 0x88 Size: 0x88
	    struct FSlateBrush BadgeImage; // 0x110 Size: 0x88
	    struct FSlateBrush DetailsImage; // 0x198 Size: 0x88
	    TArray<struct FFortMtxDetailsAttribute> DetailsAttributes; // 0x220 Size: 0x10
	    struct FFortMtxGradient Gradient; // 0x230 Size: 0x20
	    struct FLinearColor Background; // 0x250 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMtxOfferData");
			return (class UClass*)ptr;
		};

};

class UFortMtxStoreSelectionPopup : public UCommonActivatablePanel
{
	public:
	    char UnknownData0[0x18];
	    class UCommonButton* Button_Epic; // 0x330 Size: 0x8
	    class UCommonButton* Button_Samsung; // 0x338 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMtxStoreSelectionPopup");
			return (class UClass*)ptr;
		};

};

class UFortMulchItemTileButton : public UFortItemTileButton
{
	public:
	    void HandleItemChanged_BP(class UFortItem* NewItem); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7489];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMulchItemTileButton");
			return (class UClass*)ptr;
		};

};

class UFortMulchConfirmationModalWidget : public UFortActivatablePanel
{
	public:
	    __int64/*InterfaceProperty*/ HostItemManagementMulchPanel; // 0x340 Size: 0x10
	    class UCommonTileView* RecycleItemTileView; // 0x350 Size: 0x8
	    class UFortItemManagementMulchDetailsPanel* RecycleDetailsPanel; // 0x358 Size: 0x8
	    char UnknownData0[0x8]; // 0x360
	    class UFortInventoryContext* InventoryContext; // 0x368 Size: 0x8
	    char UnknownData1[0x370]; // 0x370
	    void UpdateConfirmationModal_BP(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void UpdateConfirmationModal(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    __int64/*MapProperty*/ GetMulchWarnings(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void CommitMulch(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7c71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMulchConfirmationModalWidget");
			return (class UClass*)ptr;
		};

};

class UFortMultiFactorAuthWidget : public UCommonActivatablePanel
{
	public:
	    struct FText PromptText; // 0x318 Size: 0x18
	    class UCommonButton* Button_Continue; // 0x330 Size: 0x8
	    class UCommonButton* Button_Cancel; // 0x338 Size: 0x8
	    class UCommonTextBlock* Text_Error; // 0x340 Size: 0x8
	    class UEditableText* EditText_MultiFactorCode; // 0x348 Size: 0x8
	    char UnknownData0[0x350]; // 0x350
	    void HandleTextCommitted(struct FText Text, char CommitMethod); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7c71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMultiFactorAuthWidget");
			return (class UClass*)ptr;
		};

};

class UFortMultiSizeItemCard : public UFortItemWidget_NUI
{
	public:
	    EFortItemCardSize BPItemCardSize; // 0x128 Size: 0x1
	    bool ShouldDisplayItemAsReward; // 0x129 Size: 0x1
	    char UnknownData0[0x2]; // 0x12a
	    int QuantityOverride; // 0x12c Size: 0x4
	    EFortItemType EmptyItemType; // 0x130 Size: 0x1
	    bool ShouldSuppressItemTypeIcon; // 0x131 Size: 0x1
	    bool ShouldSuppressTierMeter; // 0x132 Size: 0x1
	    bool ShouldCollapseBorderPadding; // 0x133 Size: 0x1
	    bool ShouldCollapseItem; // 0x134 Size: 0x1
	    char UnknownData1[0x135]; // 0x135
	    static bool ShouldUseNewItemCards(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetShouldDisplayItemAsReward(bool Value); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetShouldCollapseItem(bool Value); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetShouldCollapseBorderPadding(bool Value); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetQuantityOverride(int QuantityOverride); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetEmptyItemType(EFortItemType NewEmptyItemType); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetCardSize(EFortItemCardSize CardSize); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    EFortItemCardSize GetCardSize(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7e81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortMultiSizeItemCard");
			return (class UClass*)ptr;
		};

};

class UFortNewAccountWarning : public UCommonActivatablePanel
{
	public:
	    char UnknownData0[0x20];
	    class UCommonButton* Button_NewAccount; // 0x338 Size: 0x8
	    class UCommonButton* Button_Back; // 0x340 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortNewAccountWarning");
			return (class UClass*)ptr;
		};

};

class UFortniteUserInterfaceSettings : public UDeveloperSettings
{
	public:
	    struct FRuntimeFloatCurve WidthScaleCurve; // 0x38 Size: 0x88
	    struct FRuntimeFloatCurve HeightScaleCurve; // 0xc0 Size: 0x88
	    struct FRuntimeFloatCurve WidthScaleCurve_iOS_InGame; // 0x148 Size: 0x88
	    struct FRuntimeFloatCurve HeightScaleCurve_iOS_InGame; // 0x1d0 Size: 0x88
	    struct FRuntimeFloatCurve WidthScaleCurve_iOS_FrontEnd; // 0x258 Size: 0x88
	    struct FRuntimeFloatCurve HeightScaleCurve_iOS_FrontEnd; // 0x2e0 Size: 0x88
	    struct FRuntimeFloatCurve WidthScaleCurve_Android_InGame; // 0x368 Size: 0x88
	    struct FRuntimeFloatCurve HeightScaleCurve_Android_InGame; // 0x3f0 Size: 0x88
	    struct FRuntimeFloatCurve WidthScaleCurve_Android_FrontEnd; // 0x478 Size: 0x88
	    struct FRuntimeFloatCurve HeightScaleCurve_Android_FrontEnd; // 0x500 Size: 0x88

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortniteUserInterfaceSettings");
			return (class UClass*)ptr;
		};

};

class UFortNodeCanvasEntityInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortNodeCanvasEntityInterface");
			return (class UClass*)ptr;
		};

};

class UFortNodeCanvasInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortNodeCanvasInterface");
			return (class UClass*)ptr;
		};

};

class UFortNumericTextBlock : public UTextBlock
{
	public:
	    MulticastDelegateProperty CountFinished; // 0x210 Size: 0x10
	    int StartingValue; // 0x220 Size: 0x4
	    int DestValue; // 0x224 Size: 0x4
	    bool bUseGrouping; // 0x228 Size: 0x1
	    bool bAsCurrency; // 0x229 Size: 0x1
	    char UnknownData0[0x2]; // 0x22a
	    float EaseOutExp; // 0x22c Size: 0x4
	    float UpdateInterval; // 0x230 Size: 0x4
	    float ShrinkTime; // 0x234 Size: 0x4
	    char UnknownData1[0x238]; // 0x238
	    bool IsInterpolatingNumber(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void InterpolateSet(int InValue, float InUpdateLength, float InReportEndEarly); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    int GetCurrentValue(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void DirectlySet(int InValue); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7d81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortNumericTextBlock");
			return (class UClass*)ptr;
		};

};

class UFortOnlineStatusPanel : public UUserWidget
{
	public:
	    class UMenuAnchor* OwningMenuAnchor; // 0x228 Size: 0x8
	    class UCommonButton* Button_Online; // 0x230 Size: 0x8
	    class UCommonButton* Button_Away; // 0x238 Size: 0x8
	    char UnknownData0[0x240]; // 0x240
	    void OnFocused(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7da1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortOnlineStatusPanel");
			return (class UClass*)ptr;
		};

};

class UFortOpenCardPackModal : public UFortActivatablePanel
{
	public:
	    class UCommonListView* CardPackList; // 0x340 Size: 0x8
	    class UCommonButton* OpenAllButton; // 0x348 Size: 0x8
	    class UCommonButton* CancelButton; // 0x350 Size: 0x8
	    MulticastDelegateProperty OnRequestOpenCardPack; // 0x358 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortOpenCardPackModal");
			return (class UClass*)ptr;
		};

};

class UFortOptionsMenu : public UFortActivatablePanel
{
	public:
	    bool ShowVideoOptions(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    bool ShowInputOptions(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool ShowControllerOptions(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool ShowBrightnessOptions(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool ShowAccountOptions(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool ShowAccessibilityOptions(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ResetGameOptionsSettings(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ResetClientHUDSettings(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnVideoCancel(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnVideoAccept(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnResetToDefaults(int PresetToSet); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnReset(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void OnApply(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    bool NeedsVideoChangeConfirmation(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    bool NeedsLanguageChangeConfirmation(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void HandleSettingsSaveComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void HandleSettingsErrorMessageClosed(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void HandleBenchmarkComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void ClearCachedEula(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x-7ca1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortOptionsMenu");
			return (class UClass*)ptr;
		};

};

class UFortOptionsMenuData : public UDataAsset
{
	public:
	    __int64/*MapProperty*/ TabDatas; // 0x30 Size: 0x50

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortOptionsMenuData");
			return (class UClass*)ptr;
		};

};

class UFortOptionsMenuDefaults : public UDataAsset
{
	public:
	    __int64/*MapProperty*/ SettingRotatorDefaults; // 0x30 Size: 0x50
	    __int64/*MapProperty*/ SettingSliderDefaults; // 0x80 Size: 0x50

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortOptionsMenuDefaults");
			return (class UClass*)ptr;
		};

};

class UFortOptionsMenuInputData : public UDataAsset
{
	public:
	    FName ActionName; // 0x30 Size: 0x8
	    struct FText DisplayText; // 0x38 Size: 0x18
	    struct FText PrimaryText; // 0x50 Size: 0x18
	    struct FText SecondaryText; // 0x68 Size: 0x18
	    int ElementNumber; // 0x80 Size: 0x4
	    char UnknownData0[0x4]; // 0x84
	    class UCommonTextBlock* TabText; // 0x88 Size: 0x8
	    struct FFortActionKeyMapping ActionKeyMapping; // 0x90 Size: 0x60
	    char UnknownData1[0xf0]; // 0xf0
	    float GetInputScale(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    EFortInputActionGroup GetInputActionGroup(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7ef1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortOptionsMenuInputData");
			return (class UClass*)ptr;
		};

};

class UFortOptionsMenuSetting : public UCommonUserWidget
{
	public:
	    MulticastDelegateProperty SettingValueChanged; // 0x230 Size: 0x10
	    ESettingType SettingType; // 0x240 Size: 0x1
	    char UnknownData0[0x7]; // 0x241
	    struct FText NameText; // 0x248 Size: 0x18
	    char UnknownData1[0x260]; // 0x260
	    void UpdateSetting(class UCommonTextBlock* TooltipTextBlock); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void CenterOnWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortOptionsMenuSetting");
			return (class UClass*)ptr;
		};

};

class UFortSettingInfo : public UObject
{
	public:
	    ESettingType SettingType; // 0x28 Size: 0x1
	    char UnknownData0[0x7]; // 0x29
	    class UFortOptionsMenuSetting* SettingWidgetType; // 0x30 Size: 0x8
	    struct FText OptionDisplayText; // 0x38 Size: 0x18
	    struct FText OptionHoverText; // 0x50 Size: 0x18
	    int MinIntegralDigits; // 0x68 Size: 0x4
	    int MaxIntegralDigits; // 0x6c Size: 0x4
	    int MinFractionalDigits; // 0x70 Size: 0x4
	    int MaxFractionalDigits; // 0x74 Size: 0x4
	    float StepSize; // 0x78 Size: 0x4
	    float MinSensitivityValue; // 0x7c Size: 0x4
	    float MaxSensitivityValue; // 0x80 Size: 0x4
	    char RoundingMode; // 0x84 Size: 0x1
	    char UnknownData1[0x3];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSettingInfo");
			return (class UClass*)ptr;
		};

};

class UFortOutpostStorageItemPicker : public UFortItemPickerBase
{
	public:
	    void UseFilters(TArray<EFortItemType> ItemTypes); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void UseFilter(EFortItemType ItemType); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7ca1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortOutpostStorageItemPicker");
			return (class UClass*)ptr;
		};

};

class UFortPartySlot : public UUserWidget
{
	public:
	    struct FLinearColor EmptySlotColor; // 0x228 Size: 0x10
	    class UImage* Image_PartySlot; // 0x238 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPartySlot");
			return (class UClass*)ptr;
		};

};

class UFortPartySuggestionButton : public UCommonButton
{
	public:
	    char UnknownData0[0x18];
	    class UImage* Image_Platform; // 0xb40 Size: 0x8
	    class UImage* Image_PartySize; // 0xb48 Size: 0x8
	    class UCommonTextBlock* Text_DisplayName; // 0xb50 Size: 0x8
	    class UCommonTextBlock* Text_Description; // 0xb58 Size: 0x8
	    class UCommonTextBlock* Text_ActionText; // 0xb60 Size: 0x8
	    char UnknownData1[0xb68]; // 0xb68
	    void UpdateDisplayInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnSuggestionAccepted(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnNewSuggestionAdded(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnDisplayInfoUpdated(struct FDateTime LFGTime, bool bIsInvited, bool bIsPlaying); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnDismissSuggestion(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void HandleSuggestionAccepted(int PlayerID); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void HandleLobbyStarted(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7479];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPartySuggestionButton");
			return (class UClass*)ptr;
		};

};

class UFortPCBInfoPannel : public UUserWidget
{
	public:
	    bool bDisplayPCBData; // 0x228 Size: 0x1
	    char UnknownData0[0x7]; // 0x229
	    struct FText PCB_Header; // 0x230 Size: 0x18
	    struct FText PCB_Description; // 0x248 Size: 0x18
	    char UnknownData1[0x260]; // 0x260
	    bool ShouldDisplayPCBData(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    struct FText GetPCBHeader(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    struct FText GetPCBDescription(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void CmsDataRead(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7d81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPCBInfoPannel");
			return (class UClass*)ptr;
		};

};

class UFortPerksWidget_NUI : public UCommonUserWidget
{
	public:
	    class UFortHero* Hero; // 0x230 Size: 0x8
	    EFortPerksWidgetState State; // 0x238 Size: 0x1
	    char UnknownData0[0x7]; // 0x239
	    class UFortHero* EvolutionOption; // 0x240 Size: 0x8
	    class UFortPerkTierWidget_NUI* PerkTierWidgetType; // 0x248 Size: 0x8
	    class UFortPerkWidget_NUI* PerkWidgetType; // 0x250 Size: 0x8
	    class UFortTooltipContext* TooltipContext; // 0x258 Size: 0x8
	    class UCommonLoadGuard* PerksListLoadGuard; // 0x260 Size: 0x8
	    char UnknownData1[0x268]; // 0x268
	    void SetState(EFortPerksWidgetState InState, class UFortHero* InEvolutionOption); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetHero(class UFortHero* InHero); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void ProcessPerkTiers(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void ProcessPerks(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ProcessActiveAbilityPerksAsync(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnStateChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnHeroChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnGeneratePerkTier(struct FFortUIPerkTier FortPerkTier, class UFortPerkTierWidget_NUI* PerkTierWidget); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnGeneratePerk(struct FFortUIPerk FortPerk, class UFortPerkWidget_NUI* PerkWidget); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7d19];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPerksWidget_NUI");
			return (class UClass*)ptr;
		};

};

class UFortPerkTierWidget_NUI : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x8];
	    struct FFortUIPerkTier FortPerkTier; // 0x238 Size: 0x20
	    char UnknownData1[0x258]; // 0x258
	    void ProcessPerks(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnGeneratePerk(struct FFortUIPerk Perk, class UFortPerkWidget_NUI* PerkWidget); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPerkTierWidget_NUI");
			return (class UClass*)ptr;
		};

};

class UFortPerkWidget_NUI : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x8];
	    struct FFortUIPerk Perk; // 0x238 Size: 0x98
	    char UnknownData1[0x8]; // 0x2d0
	    class UFortTooltipContext* CachedTooltipContext; // 0x2d8 Size: 0x8
	    char UnknownData2[0x2e0]; // 0x2e0
	    void SetTooltipContext(class UFortTooltipContext* InTooltipContext); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void RequestTooltipDescription(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void RequestCombinedTooltipDescription(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnTooltipDescriptionReady(TArray<struct FText> DescriptionList); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnPerkUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnCombinedTooltipDescriptionReady(struct FText Description); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool IsTierPerk(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool IsPerkUnlocked(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    bool IsPerkHighlighted(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    bool IsPerkEmpty(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    bool HasAbility(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    struct FText GetTooltipTitle(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    class UFortTooltipContext* GetTooltipContext(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    EFortSupportBonusType GetSupportBonusType(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    int GetRequiredLevel(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    char GetPerkTier(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    bool GetIcon(struct FSlateBrush Brush); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x-7ce9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPerkWidget_NUI");
			return (class UClass*)ptr;
		};

};

class UFortPickerContext : public UBlueprintContextBase
{
	public:
	    MulticastDelegateProperty OnShowPicker; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnPickerConfirm; // 0x38 Size: 0x10
	    MulticastDelegateProperty OnPickerCancel; // 0x48 Size: 0x10
	    MulticastDelegateProperty OnPickerOptionMoved; // 0x58 Size: 0x10
	    MulticastDelegateProperty OnPickerOptionChosen; // 0x68 Size: 0x10
	    MulticastDelegateProperty OnPickerRefreshItems; // 0x78 Size: 0x10
	    char UnknownData0[0x18]; // 0x88
	    TArray<struct FItemDefOptionData> CustomPickerMenuItems; // 0xa0 Size: 0x10
	    TArray<struct FSquadQuickChatOptionData> SquadChatMenuItems; // 0xb0 Size: 0x10
	    __int64/*MapProperty*/ TrackedTrapsMap; // 0xc0 Size: 0x50
	    char UnknownData1[0x8]; // 0x110
	    class UFortPickerData* PickerData; // 0x118 Size: 0x8
	    TArray<class UFortSchematicItem*> AccountTrapSchematics; // 0x120 Size: 0x10
	    TArray<struct FFortPickerTemporaryWheel> AvailableWheels; // 0x130 Size: 0x10
	    int CurrentWheelIndex; // 0x140 Size: 0x4
	    char UnknownData2[0xc]; // 0x144
	    __int64/*MapProperty*/ ConsumableStackCount; // 0x150 Size: 0x50
	    char UnknownData3[0x1a0]; // 0x1a0
	    bool UseLeftThumbstick(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SwitchToAdjacentWheel(int SelectionDirection); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ShowRadialPickerMenu(EFortPickerToDisplay PickerType, int WheelIndex, class UObject* ContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetFortPickerData(class UFortPickerData* Data); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void RestoreInputAxes(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void PickerOptionAccepted(int Option); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void PickerCanceled(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void GetRadialPickerOptionItem(int Index, class UFortItem* Item, bool bOptionEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void GetRadialPickerOptionImageAndLabel(int Index, struct FText Label, struct FSlateBrush Brush, struct TSoftObjectPtr<struct UTexture2D*> Icon, bool bOptionEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void GetPickerWheelAdjacency(bool bCanPageLeft, bool bCanPageRight); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    int GetNumPickerOptions(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    class UFortItem* GetListPickerOption(int Index); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    int GetCurrentWheelIndex(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    struct FText GetCurrentPickerDisplayName(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void GetAdjacentPickerWheelInformation(int Direction, struct FText AdjacentTitle, bool bCanPageThisDirection); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    bool DoesRadialCloseOnRelease(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x-7e39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPickerContext");
			return (class UClass*)ptr;
		};

};

class UFortPickerData : public UDataAsset
{
	public:
	    TArray<struct FBuildingCategoryOptionData> BuildingCategories; // 0x30 Size: 0x10
	    TArray<struct FBuildingOptionData> WallOptions; // 0x40 Size: 0x10
	    TArray<struct FBuildingOptionData> FloorOptions; // 0x50 Size: 0x10
	    TArray<struct FBuildingOptionData> StairOptions; // 0x60 Size: 0x10
	    TArray<struct FBuildingOptionData> RoofOptions; // 0x70 Size: 0x10
	    TArray<struct FItemCategoryOptionData> TrapCategories; // 0x80 Size: 0x10
	    TArray<struct FItemCategoryOptionData> WeaponCategories; // 0x90 Size: 0x10
	    TArray<struct FRadialOptionData> SocialCategories; // 0xa0 Size: 0x10
	    TArray<struct FChatOptionData> ChatOptions; // 0xb0 Size: 0x10
	    TArray<class UAthenaQuickChatBank*> SquadChatOptionBanks; // 0xc0 Size: 0x10
	    TArray<struct FMapNoteOptionData> MapNoteOptions; // 0xd0 Size: 0x10
	    TArray<struct FEmoteOptionData> EmoteOptions; // 0xe0 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPickerData");
			return (class UClass*)ptr;
		};

};

class UFortPlayedBeforeSelect : public UCommonActivatablePanel
{
	public:
	    char UnknownData0[0x18];
	    class UCommonButton* Button_Yes; // 0x330 Size: 0x8
	    class UCommonButton* Button_No; // 0x338 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPlayedBeforeSelect");
			return (class UClass*)ptr;
		};

};

class UFortPlayerBanned : public UFortActivatablePanel
{
	public:
	    char UnknownData0[0x340];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPlayerBanned");
			return (class UClass*)ptr;
		};

};

class UFortPlayerBanner : public UWidget
{
	public:
	    char UnknownData0[0x8];
	    struct FVector2D DesiredSize; // 0x108 Size: 0x8
	    bool bShowBorder; // 0x110 Size: 0x1
	    bool bUseLargeTexture; // 0x111 Size: 0x1
	    char UnknownData1[0x16]; // 0x112
	    class UMaterialInterface* DefaultBorderlessBannerMaterial; // 0x128 Size: 0x8
	    struct FSlateBrush BannerBrush; // 0x130 Size: 0x88
	    char UnknownData2[0x20];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPlayerBanner");
			return (class UClass*)ptr;
		};

};

class UFortPlayerNameDropdown : public UFortDropdownMenu
{
	public:
	    char UnknownData0[0x350];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPlayerNameDropdown");
			return (class UClass*)ptr;
		};

};

class UFortPlayerProfileBannerEditor : public UCommonUserWidget
{
	public:
	    ESaveProfileForBanners ProfileToSave; // 0x230 Size: 0x4
	    char UnknownData0[0x4]; // 0x234
	    struct FFortSwipeDetector SwipeDetector; // 0x238 Size: 0x70
	    TArray<FName> IconCategories; // 0x2a8 Size: 0x10
	    TArray<FName> ColorCategories; // 0x2b8 Size: 0x10
	    FName ChosenIcon; // 0x2c8 Size: 0x8
	    FName ChosenIconCategory; // 0x2d0 Size: 0x8
	    FName ChosenColor; // 0x2d8 Size: 0x8
	    FName ChosenColorCategory; // 0x2e0 Size: 0x8
	    char UnknownData1[0x2e8]; // 0x2e8
	    void SetBannerIcon(FName Icon); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetBannerColor(FName Color); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void RefreshBannerEditor(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnShowPreviousCategory(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnShowNextCategory(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void HandleEditorDeactivated(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void HandleEditorActivated(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void CommitChosenIconAndColor(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7cf9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPlayerProfileBannerEditor");
			return (class UClass*)ptr;
		};

};

class UFortPlayerProfileBannerEditorTile : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    TWeakObjectPtr<UFortItem*> Item; // 0xb30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPlayerProfileBannerEditorTile");
			return (class UClass*)ptr;
		};

};

class UFortPlayerProfileModalWidget : public UFortActivatablePanel
{
	public:
	    char UnknownData0[0x340];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPlayerProfileModalWidget");
			return (class UClass*)ptr;
		};

};

class UFortPlayerTrackerBase : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x8];
	    struct FUniqueNetIdRepl UniqueId; // 0x238 Size: 0x28
	    TWeakObjectPtr<UFortRegisteredPlayerInfo*> PlayerInfo; // 0x260 Size: 0x8
	    int PartyIndex; // 0x268 Size: 0x4
	    bool IsLocalPlayer; // 0x26c Size: 0x1
	    bool ShouldDeferAttributesChangedEvents; // 0x26d Size: 0x1
	    char UnknownData1[0x26e]; // 0x26e
	    void UpdateBasedOnId(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetUniqueIdInternal(struct FUniqueNetIdRepl InUniqueId); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetUniqueId(struct FUniqueNetIdRepl InUniqueId); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetTeamMember(int InPlayerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ResetPartyEvents(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ReRegisterAttributeChangedDelegates(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void RegisterAttributeChangedDelegates(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnPlayerInfoChanged(struct FFortTeamMemberInfo NewInfo); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnPlayerAttributesChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    bool HasModifiedStats(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void HandleTooltipAttributeChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void HandleTeamMemberStateChangedId(struct FFortTeamMemberInfo NewInfo); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void HandleTeamMemberStateChanged(struct FFortTeamMemberInfo NewInfo); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void HandleTeamMemberRemoved(int RemovedIndex); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void HandleTeamMemberAdded(struct FFortTeamMemberInfo NewInfo); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void HandlePartyLeft(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void HandleOnPlayerIdUpdated(struct FUniqueNetIdRepl NewInfo); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void HandleOnLocalPlayerInfoUpdated(struct FFortTeamMemberInfo NewInfo); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void HandleDelayedOnPlayerAttributesChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    int GetTeamTech(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    int GetTeamResistance(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    int GetTeamOffense(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    int GetTeamFortitude(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    bool GetModifiedHomebaseRating(int Rating, float ProgressFraction); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    bool GetHomebaseRating(int Rating, float ProgressFraction); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    int GetBuffedTech(); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    int GetBuffedResistance(); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    int GetBuffedOffense(); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    int GetBuffedFortitude(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    int GetBaseTech(); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    int GetBaseResistance(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    int GetBaseOffense(); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    int GetBaseFortitude(); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x-7d71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPlayerTrackerBase");
			return (class UClass*)ptr;
		};

};

class UFortPlaysetInventoryPanelData : public UFortCreativeItemListPanelData
{
	public:
	    char UnknownData0[0x68];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPlaysetInventoryPanelData");
			return (class UClass*)ptr;
		};

};

class UFortPrivacyBase : public UFortActivatablePanel
{
	public:
	    class UCommonButton* AllowFriendsOfFriendsButton; // 0x340 Size: 0x8
	    class UPanelWidget* AllowFriendsOfFriendsContainer; // 0x348 Size: 0x8
	    class UCommonButtonGroup* ButtonGroup; // 0x350 Size: 0x8
	    __int64/*MapProperty*/ PrivacyButtonMap; // 0x358 Size: 0x50
	    char UnknownData0[0x3a8]; // 0x3a8
	    void HandlePrivacyButtonSelected(class UCommonButton* SelectedPrivacyButton, int ButtonIndex); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void ApplyPrivacySetting(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void AddPrivacyButton(class UCommonButton* PrivacyButton, EPartyType PartyType); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7c31];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPrivacyBase");
			return (class UClass*)ptr;
		};

};

class UFortProgressModal : public UFortActivatablePanel
{
	public:
	    struct FText Title; // 0x340 Size: 0x18
	    struct FText Description; // 0x358 Size: 0x18
	    struct FSlateBrush Icon; // 0x370 Size: 0x88
	    bool bIntroOutroEnabled; // 0x3f8 Size: 0x1
	    bool bAutoInitialize; // 0x3f9 Size: 0x1
	    bool bFocusSelf; // 0x3fa Size: 0x1
	    bool bConsumeAnalogInput; // 0x3fb Size: 0x1
	    char UnknownData0[0x3fc]; // 0x3fc
	    void SetTitle(struct FText InTitle); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetIcon(struct FSlateBrush InIcon); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetDescription(struct FText InDescription); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7be1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortProgressModal");
			return (class UClass*)ptr;
		};

};

class UFortPurchaseHistoryEntry : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    class UCommonTextBlock* Text_Name; // 0xb30 Size: 0x8
	    char UnknownData1[0xb38]; // 0xb38
	    void UpdateItemList(TArray<class UFortMultiSizeItemCard*> ItemCards); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetRefundState(struct FText PurchaseText, EItemRefundability Refundability); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetPurchaseText(struct FText PurchaseText, bool bHasBeenRefunded); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-74a9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPurchaseHistoryEntry");
			return (class UClass*)ptr;
		};

};

class UFortPurchaseHistoryListView : public UListViewBase
{
	public:
	    char UnknownData0[0x2d0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPurchaseHistoryListView");
			return (class UClass*)ptr;
		};

};

class UReturnReasonDataWrapper : public UObject
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.ReturnReasonDataWrapper");
			return (class UClass*)ptr;
		};

};

class UFortPurchaseHistoryScreen : public UCommonActivatablePanel
{
	public:
	    struct FDataTableRowHandle PreviousStepRowHandle; // 0x318 Size: 0x10
	    class UFortRefundConfirmation* RefundConfirmationClass; // 0x328 Size: 0x8
	    class UFortRefundConfirmation* RefundConfirmationWidget; // 0x330 Size: 0x8
	    TArray<struct FText> ReturnReasons; // 0x338 Size: 0x10
	    TArray<class UReturnReasonDataWrapper*> WrapperArray; // 0x348 Size: 0x10
	    char UnknownData0[0x10]; // 0x358
	    TArray<class UFortItemDefinition*> SelectedItemDefs; // 0x368 Size: 0x10
	    char UnknownData1[0x18]; // 0x378
	    class UCommonButtonGroup* TabButtonGroup; // 0x390 Size: 0x8
	    bool bRefundConfirmationProcessing; // 0x398 Size: 0x1
	    char UnknownData2[0x7]; // 0x399
	    class UFortPurchaseHistoryListView* ListView_Purchases; // 0x3a0 Size: 0x8
	    class UCommonListView* ListView_Reasons; // 0x3a8 Size: 0x8
	    class UCommonTextBlock* Text_Desc; // 0x3b0 Size: 0x8
	    class UCommonTextBlock* Text_RefundCount; // 0x3b8 Size: 0x8
	    class UCommonButton* Button_RequestRefund; // 0x3c0 Size: 0x8
	    class UFortRichTextBlock* RichText_WarningMsg; // 0x3c8 Size: 0x8
	    class UCommonTextBlock* Text_RefundValue; // 0x3d0 Size: 0x8
	    class UCommonTextBlock* Text_RefundReason; // 0x3d8 Size: 0x8
	    char UnknownData3[0x3e0]; // 0x3e0
	    void UpdateItemList(TArray<class UCommonTextBlock*> ItemsToReturn); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnPopulateView(EPurchaseReturnStep CurrentStep); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnNoPurchasesAvailable(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnItemRefresh(struct FMtxPurchaseHistory PurchaseHistory); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnEndRefundSubmission(bool bSuccess, int MtxRefunded, class UFortItemDefinition* ReturnedItem, int TicketIndex); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnBeginRefundSubmission(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void InitializeTickets(int NumTicketsAvailableToUse); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void HandleTabButtonClicked(EPurchaseReturnStep ClickedStep); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void HandlePreviousStepAction(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    EPurchaseReturnStep GetCurrentStep(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void ConsumeComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x-7c01];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPurchaseHistoryScreen");
			return (class UClass*)ptr;
		};

};

class UFortPvPMinimapWidget : public UFortUserWidget
{
	public:
	    char UnknownData0[0x258];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortPvPMinimapWidget");
			return (class UClass*)ptr;
		};

};

class UFortQuestExpiresWidget : public UCommonUserWidget
{
	public:
	    TWeakObjectPtr<UFortQuestItem*> Item; // 0x230 Size: 0x8
	    char UnknownData0[0x238]; // 0x238
	    void SetData(class UFortQuestItem* InItem); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnQuestExpirationUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7da1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortQuestExpiresWidget");
			return (class UClass*)ptr;
		};

};

class UFortQuestMapCosmeticListWidget : public UCommonUserWidget
{
	public:
	    void UpdateCosmeticListDisplay(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    TArray<class UFortItemDefinition*> GetDisplayItemDefs(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7da1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortQuestMapCosmeticListWidget");
			return (class UClass*)ptr;
		};

};

class UFortQuestMapDetailsPanel : public UCommonUserWidget
{
	public:
	    struct FDataTableRowHandle PlayButtonTriggeringAction; // 0x230 Size: 0x10
	    char UnknownData0[0x240]; // 0x240
	    void DisplayInactiveQuest(class UFortQuestItemDefinition* QuestDef); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void DisplayActiveQuest(class UFortQuestItem* QuestItem); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7da1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortQuestMapDetailsPanel");
			return (class UClass*)ptr;
		};

};

class UFortQuestMapNodeLayout : public UUserWidget
{
	public:
	    class UCommonButton* ButtonPrevious; // 0x228 Size: 0x8
	    class UCommonButton* ButtonNext; // 0x230 Size: 0x8
	    class USizeBox* StartArrow; // 0x238 Size: 0x8
	    class USizeBox* EndArrow; // 0x240 Size: 0x8
	    class UPanelWidget* LayoutPanel; // 0x248 Size: 0x8
	    class UCommonButtonGroup* QuestButtonGroup; // 0x250 Size: 0x8
	    char UnknownData0[0x30]; // 0x258
	    class UFortQuestMapScreen* ParentScreen; // 0x288 Size: 0x8
	    char UnknownData1[0x290]; // 0x290
	    void SetParentScreen(class UFortQuestMapScreen* Parent); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetLayoutPanel(class UPanelWidget* Value); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleQuestIndexSelectionModelIndexChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleQuestButtonSelected(class UCommonButton* SelectedQuestButton, int ButtonIndex); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    struct FFortQuestMapPage GetQuestPageData(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void DisposeLayout(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7d51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortQuestMapNodeLayout");
			return (class UClass*)ptr;
		};

};

class UFortQuestMapQuestTile : public UCommonUserWidget
{
	public:
	    class UCommonButton* QuestButton; // 0x230 Size: 0x8
	    char UnknownData0[0x238]; // 0x238
	    void HandleSelectedChange(bool Selected); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void HandleQuestDataChangedBP(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    struct FFortQuestMapNode GetQuestNodeData(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortQuestMapQuestTile");
			return (class UClass*)ptr;
		};

};

class UFortQuestMapScreen : public UCommonActivatablePanel
{
	public:
	    class UFortQuestMapDetailsPanel* CampaignDetailsPanel; // 0x318 Size: 0x8
	    class UFortQuestMapDetailsPanel* EventDetailsPanel; // 0x320 Size: 0x8
	    class UFortQuestMapViewer* QuestMapViewer; // 0x328 Size: 0x8
	    EQuestMapScreenMode CurrentMode; // 0x330 Size: 0x1
	    bool bUseSpecialEventsCamera; // 0x331 Size: 0x1
	    char UnknownData0[0x6]; // 0x332
	    struct FString ActiveEventFlag; // 0x338 Size: 0x10
	    struct FFortQuestMapDataEntry CampaignQuestMapDataTable; // 0x348 Size: 0x10
	    struct FFortEventQuestMapDataEntry EventQuestMapDataTable; // 0x358 Size: 0x40
	    class UFortQuestItemDefinition* CutoffQuest; // 0x398 Size: 0x8
	    struct FFortQuestMapDataEntry CurrentQuestMapDataTable; // 0x3a0 Size: 0x10
	    char UnknownData1[0x3b0]; // 0x3b0
	    void UpdateQuestMapMode(EQuestMapScreenMode QuestMapMode); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void ToggleQuestMapState(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetQuestMapViewer(class UFortQuestMapViewer* Value); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetIgnorePageNavigation(bool bIgnoreNavigation); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetFindCurrentActionVisibility(EInputActionState ActionVisibility); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetBeyondCutoffQuest(bool bBeyondCutoff); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool IsEventFlagActive(struct FString EventFlag); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool IsBeyondCutoffQuest(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void InitializeQuestData(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void HandleRequestCurrentQuestNavigation(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void HandleQuestIndexSelectionModelChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void HandleQuestDetailsUpdated(class UFortQuestItem* QuestDefinition); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void HandleMapViewerNavigationRequest(EViewerNavigationDirection Direction); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void HandleEventQuestMapActivate(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    bool GetBeyondCutoffQuest(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x-7c11];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortQuestMapScreen");
			return (class UClass*)ptr;
		};

};

class UFortQuestMapViewer : public UFortCampaignMap
{
	public:
	    class UCanvasPanel* CosmeticCanvasPanel; // 0x2a0 Size: 0x8
	    class USizeBox* FullQuestMap; // 0x2a8 Size: 0x8
	    class UFortQuestMapScreen* ParentScreen; // 0x2b0 Size: 0x8
	    char UnknownData0[0x38]; // 0x2b8
	    class UFortQuestMapNodeLayout* NodeLayout; // 0x2f0 Size: 0x8
	    char UnknownData1[0x2f8]; // 0x2f8
	    void SetQuestMapNodeLayout(class UFortQuestMapNodeLayout* Value); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void PlayLayoutOutroAnimation(EViewerNavigationDirection TravelDirection); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void PlayLayoutFadeInAnimation(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void NavigateToPage(EViewerNavigationDirection Direction); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void NavigateToCurrentQuest(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void HandleQuestMapDataChangedBP(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void HandleQuestIndexSelectionModelIndexChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void HandleLayoutOutroAnimationFinished(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    struct FFortQuestMapPage GetQuestMapData(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    struct FFortQuestMapPageCosmetics GetQuestMapCosmeticData(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void DisposeQuestMap(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7cc9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortQuestMapViewer");
			return (class UClass*)ptr;
		};

};

class UFortQuestNotificationHandler : public UFortDialogNotificationHandler
{
	public:
	    class UFortQuestItem* Quest; // 0x1a0 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortQuestNotificationHandler");
			return (class UClass*)ptr;
		};

};

class UFortQuestObjectiveEntry : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x8];
	    MulticastDelegateProperty OnFinishedDisplaying; // 0x238 Size: 0x10
	    class UFortQuestObjectiveInfo* MyObjectiveInfo; // 0x248 Size: 0x8
	    char UnknownData1[0x250]; // 0x250
	    void StartDisplayingObjective(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void ObjectiveInfoSet(class UFortQuestObjectiveInfo* ObjectiveInfo, bool IsAnnouncement); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortQuestObjectiveEntry");
			return (class UClass*)ptr;
		};

};

class UFortQuestPlayButton : public UCommonUserWidget
{
	public:
	    class UFortQuestItem* QuestItem; // 0x230 Size: 0x8
	    char UnknownData0[0x238]; // 0x238
	    void OnContentMissing(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void HandlePlayerStateChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HandleMatchmakingStarted(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleMatchmakingComplete(EMatchmakingCompleteResult Result); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleLobbyDisconnected(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool CanPlayQuest(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool CanNavigateToQuestObjective(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void AttemptToPlayQuest(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7da9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortQuestPlayButton");
			return (class UClass*)ptr;
		};

};

class UFortQuestTrackerEntry : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x10];
	    class UCommonTextBlock* QuestNameText; // 0x240 Size: 0x8
	    class UCommonListView* ObjectivesList; // 0x248 Size: 0x8
	    class UFortQuestItem* TrackedQuest; // 0x250 Size: 0x8
	    MulticastDelegateProperty OnHUDQuestFinalObjectiveHiddenDelegate; // 0x258 Size: 0x10
	    TArray<class UFortQuestObjectiveInfo*> HUDCachedObjectiveInfos; // 0x268 Size: 0x10
	    bool bConfigureAsHUD; // 0x278 Size: 0x1
	    char UnknownData1[0x7]; // 0x279
	    MulticastDelegateProperty OnSizeEstimateChangedDelegate; // 0x280 Size: 0x10
	    char UnknownData2[0x290]; // 0x290
	    void OnSetup(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleHUDObjectiveCompletion(class UFortQuestObjectiveInfo* QuestObjective); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7d51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortQuestTrackerEntry");
			return (class UClass*)ptr;
		};

};

class UFortQuestTrackerList : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x8];
	    bool bConfigureAsHUD; // 0x238 Size: 0x1
	    char UnknownData1[0x7]; // 0x239
	    class UCommonListView* QuestList; // 0x240 Size: 0x8
	    TArray<class UFortQuestItem*> HUDCachedQuests; // 0x248 Size: 0x10
	    MulticastDelegateProperty OnSizeEstimateChangedDelegate; // 0x258 Size: 0x10
	    char UnknownData2[0x268]; // 0x268
	    void HandleSizeEstimateChanged(class UObject* ChangedElement); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleQuestsUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandlePinnedQuestsChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleHUDFinalObjectiveHidden(class UFortQuestItem* QuestItem); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    TArray<class UFortQuestItem*> GetQuestsToDisplay(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7d79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortQuestTrackerList");
			return (class UClass*)ptr;
		};

};

class UFortQuestTrackerSubEntry : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x10];
	    class UFortQuestObjectiveInfo* TrackedObjective; // 0x240 Size: 0x8
	    MulticastDelegateProperty OnSizeEstimateChangedDelegate; // 0x248 Size: 0x10
	    MulticastDelegateProperty OnHUDQuestObjectiveCompletedDelegate; // 0x258 Size: 0x10
	    bool bConfigureAsHUD; // 0x268 Size: 0x1
	    char UnknownData1[0x269]; // 0x269
	    void OnSetup(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnQuestsUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnPlayObjectiveCompletedAnimation(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void NotifyCompletionAnimationFinished(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleQuestsUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7d71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortQuestTrackerSubEntry");
			return (class UClass*)ptr;
		};

};

class UFortQuestTreeItemWidget : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    TWeakObjectPtr<UObject*> QuestOrCategory; // 0xb30 Size: 0x8
	    char UnknownData1[0xb38]; // 0xb38
	    void SetupAsQuest(class UFortQuestItem* Category); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetupAsCategory(class UFortQuestCategory* Category); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnQuestsUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleQuestsUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-74a9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortQuestTreeItemWidget");
			return (class UClass*)ptr;
		};

};

class UFortQuestUpdateEntry : public UCommonUserWidget
{
	public:
	    class UFortQuestObjectiveEntry* SubEntryClass; // 0x230 Size: 0x8
	    MulticastDelegateProperty FinishedDisplayingQuests; // 0x238 Size: 0x10
	    class UVerticalBox* ObjectivesBox; // 0x248 Size: 0x8
	    char UnknownData0[0x250]; // 0x250
	    void StartQuestOutro(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void StartQuestIntro(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetupAsAnnouncement(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetQuestItem(class UFortQuestObjectiveInfo* ObjectiveInfo, bool IsAnnouncement); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void QuestItemSet(class UFortQuestItem* QuestItemToCheck); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    int GetNumDisplayedObjectives(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void FinishQuestOutro(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void FinishQuestIntro(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void CurrentlyDisplayedObjectiveFinished(class UFortQuestObjectiveEntry* QuestObjective); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool CanAddObjective(class UFortQuestItem* QuestItemToCheck); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7d81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortQuestUpdateEntry");
			return (class UClass*)ptr;
		};

};

class UFortQuestUpdatesLog : public UFortHUDElementWidget
{
	public:
	    class UFortQuestUpdateEntry* QuestEntryClass; // 0x258 Size: 0x8
	    int MaxDisplayedQuestUpdates; // 0x260 Size: 0x4
	    int MaxDisplayedQuestObjectives; // 0x264 Size: 0x4
	    class UVerticalBox* QuestUpdatesBox; // 0x268 Size: 0x8
	    char UnknownData0[0x10]; // 0x270
	    TArray<class UFortQuestUpdateEntry*> QuestUpdateWidgets; // 0x280 Size: 0x10
	    char UnknownData1[0x290]; // 0x290
	    void HandleQuestUpdateFinished(class UFortQuestUpdateEntry* QuestEntryFinished); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HandleDisplayDynamicQuestUpdate(class UFortQuestObjectiveInfo* QuestObjective, bool DisplayStatusUpdate, bool DisplayAnnouncementUpdate); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void CreateAnnouncementUpdate(class UFortQuestObjectiveInfo* QuestItemToCheck); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7d49];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortQuestUpdatesLog");
			return (class UClass*)ptr;
		};

};

class UFortQuickBarSlotBase : public UCommonUserWidget
{
	public:
	    class UCommonWidgetSwitcher* SwitcherTopComboSwitcher; // 0x230 Size: 0x8
	    class UCommonWidgetSwitcher* SwitcherBottomComboSwitcher; // 0x238 Size: 0x8
	    class UFortKeybindWidget* KeybindTop; // 0x240 Size: 0x8
	    class UFortKeybindWidget* KeybindBottom; // 0x248 Size: 0x8
	    class UFortKeybindWidget* KeybindBottomCombo1; // 0x250 Size: 0x8
	    class UFortKeybindWidget* KeybindBottomCombo2; // 0x258 Size: 0x8
	    class UFortKeybindWidget* KeybindTopComboArrow1; // 0x260 Size: 0x8
	    class UFortKeybindWidget* KeybindTopComboArrow2; // 0x268 Size: 0x8
	    class UFortKeybindWidget* KeybindBottomComboArrow1; // 0x270 Size: 0x8
	    class UFortKeybindWidget* KeybindBottomComboArrow2; // 0x278 Size: 0x8
	    class UCommonTextBlock* BottomHoldText; // 0x280 Size: 0x8
	    class UImage* TopLeftArrowImage; // 0x288 Size: 0x8
	    class UImage* TopLeftArrowImage2; // 0x290 Size: 0x8
	    class UImage* TopRightArrowImage; // 0x298 Size: 0x8
	    class UImage* TopRightArrowImage2; // 0x2a0 Size: 0x8
	    class UImage* BottomLeftArrowImage; // 0x2a8 Size: 0x8
	    class UImage* BottomLeftArrowImage2; // 0x2b0 Size: 0x8
	    class UImage* BottomRightArrowImage; // 0x2b8 Size: 0x8
	    class UImage* BottomRightArrowImage2; // 0x2c0 Size: 0x8
	    class UImage* EmptyImage; // 0x2c8 Size: 0x8
	    class UFortMultiSizeItemCard* ItemCardMaximized; // 0x2d0 Size: 0x8
	    class UFortMultiSizeItemCard* ItemCardMinimized; // 0x2d8 Size: 0x8
	    class UFortItemCooldownWidget* QuickbarSlotCooldown; // 0x2e0 Size: 0x8
	    class UImage* SlotInteraction; // 0x2e8 Size: 0x8
	    class UAthenaQuickBarNativeCell* NativeCell; // 0x2f0 Size: 0x8
	    int SlotIndex; // 0x2f8 Size: 0x4
	    EFortQuickBars QuickBarType; // 0x2fc Size: 0x1
	    bool bShowBottomArrows; // 0x2fd Size: 0x1
	    bool bShowTopArrows; // 0x2fd Size: 0x1
	    bool bHideKeybindsWhenAbilityUnavailable; // 0x2fd Size: 0x1
	    bool bShouldCollapseItemWidgetBorder; // 0x2fd Size: 0x1
	    bool DoNotPlaySelectionAnimation; // 0x2fe Size: 0x1
	    bool bIsAthenaQuickBar; // 0x2fe Size: 0x1
	    bool bKeybindsHidden; // 0x2fe Size: 0x1
	    char UnknownData0[0x5]; // 0x304
	    EFortItemCardSize ItemCardSize; // 0x2ff Size: 0x1
	    class UFortItem* Item; // 0x300 Size: 0x8
	    class UFortInputData* InputData; // 0x308 Size: 0x8
	    char UnknownData1[0x310]; // 0x310
	    void UpdateKeyBindingVisibility(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void UpdateKeyBindingText(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void UpdateItemCardsVisibility(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetTopComboSwitcherVisibility(ESlateVisibility InVisibility); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetSlotSelected(bool bSelected); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetQuickbarTypeRuntime(EFortQuickBars NewQuickBarType, bool bRefresh); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetQuickbarIndexRuntime(int Index, bool bRefresh); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetBottomComboSwitcherVisibility(ESlateVisibility InVisibility); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void Resize(EFortItemCardSize CardSize); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void RefreshItem(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void OnRefreshItem(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void MinimizeSlot(bool bShouldSkipAnimation); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void MaximizeSlot(bool bShouldSkipAnimation); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    FName GetKeyBindingActionKeyboard(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    FName GetKeyBindingActionGamepad(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    FName GetKeyBindingAction(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x-7cd1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortQuickBarSlotBase");
			return (class UClass*)ptr;
		};

};

class UFortRedeemCodeBase : public UFortActivatablePanel
{
	public:
	    void RedeemFriendCode(struct FString FriendCode); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void OnRedeemFriendCodeComplete(bool bSuccess, ERedeemCodeFailureReason FailureReason); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7ca1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRedeemCodeBase");
			return (class UClass*)ptr;
		};

};

class UFortRedirectToEpicAccountWidget : public UCommonActivatablePanel
{
	public:
	    TArray<struct FPlatformSupportDesc> SupportedPlatforms; // 0x318 Size: 0x10
	    struct FPlatformSupportDesc DefaultValues; // 0x328 Size: 0x20
	    class UCommonTextBlock* Text_Title; // 0x348 Size: 0x8
	    class UCommonTextBlock* Text_Desc; // 0x350 Size: 0x8
	    class UCommonButton* Button_CreateAccount; // 0x358 Size: 0x8
	    char UnknownData0[0x360]; // 0x360
	    void SetLoginType(EFortLoginAccountType LoginType); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7c81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRedirectToEpicAccountWidget");
			return (class UClass*)ptr;
		};

};

class UFortRefundConfirmation : public UCommonActivatablePanel
{
	public:
	    char UnknownData0[0x10];
	    class UCommonTextBlock* Text_AreYouSure; // 0x328 Size: 0x8
	    class UCommonTextBlock* Text_RefundsRemaining; // 0x330 Size: 0x8
	    class UCommonButton* Button_Yes; // 0x338 Size: 0x8
	    class UCommonButton* Button_No; // 0x340 Size: 0x8
	    char UnknownData1[0x348]; // 0x348
	    void SetRefundsRemainingText(int RefundsRemaining, int TotalRefunds); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7c99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRefundConfirmation");
			return (class UClass*)ptr;
		};

};

class UFortRejoinWindowBase : public UCommonActivatablePanel
{
	public:
	    class UCommonTextBlock* RejoinTime; // 0x318 Size: 0x8
	    char UnknownData0[0x320]; // 0x320
	    void StopTimeout(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void StartTimeout(float TimeoutTime); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnTimeoutTimeReached(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7cb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRejoinWindowBase");
			return (class UClass*)ptr;
		};

};

class UFortRelativeAnchorCanvasSlot : public UPanelSlot
{
	public:
	    TWeakObjectPtr<UWidget*> AnchorWidget; // 0x38 Size: 0x8
	    char UnknownData0[0x40]; // 0x40
	    void SetAnchorWidget(class UWidget* NewAnchorWidget); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRelativeAnchorCanvasSlot");
			return (class UClass*)ptr;
		};

};

class UFortRelativeAnchorCanvas : public UPanelWidget
{
	public:
	    int ZLayerOffset; // 0x118 Size: 0x4
	    char UnknownData0[0x11c]; // 0x11c
	    void SetZLayerOffset(int Value); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    class UFortRelativeAnchorCanvasSlot* AddSlot(class UWidget* ContentWidget, class UWidget* AnchorWidget); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7eb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRelativeAnchorCanvas");
			return (class UClass*)ptr;
		};

};

class UFortReplayBase : public UFortHUDElementWidget
{
	public:
	    class UFortReplayContext* ReplayContext; // 0x258 Size: 0x8
	    char UnknownData0[0x260]; // 0x260
	    void SetReplayContext(class UFortReplayContext* InReplayContext); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnTimelineRangeChanged(float StartTime, float EndTime); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnReplayPausedChanged(bool bIsPaused); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnPlaybackTimeChanged(float NowTime); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7d81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortReplayBase");
			return (class UClass*)ptr;
		};

};

class UFortReplayViewSettingsTabBase : public UFortActivatablePanel
{
	public:
	    class AFortPlayerControllerSpectating* SpectatingPC; // 0x340 Size: 0x8
	    char UnknownData0[0x348]; // 0x348
	    void SetWidgetValues(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void ResetToDefault(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnFXStateChanged(struct FFortReplayFXState NewFXState); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnCameraTypeChanged(class AFortPlayerControllerSpectating* FortPlayerControllerSpectating, ESpectatorCameraType CameraType); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void InitializeWidgets(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void CenterOnTab(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7c99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortReplayViewSettingsTabBase");
			return (class UClass*)ptr;
		};

};

class UFortReportActioned : public UFortActivatablePanel
{
	public:
	    char UnknownData0[0x340];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortReportActioned");
			return (class UClass*)ptr;
		};

};

class UFortResearchMenuBase : public UFortActivatablePanel
{
	public:
	    class UFortItemDefinition* ResearchRespecToken; // 0x340 Size: 0x8
	    char UnknownData0[0x348]; // 0x348
	    void UseResearchRespecToken(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void RequestPurchaseResearchLevel(struct FString StatId); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnUseResearchRespecTokenComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnPurchaseResearchLevelStarted(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnPurchaseResearchLevelCompleted(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    int GetResearchRespecTokenCount(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    int GetClaimableResearchPointEstimate(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool AreResearchRespecTokensAvailable(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7c99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortResearchMenuBase");
			return (class UClass*)ptr;
		};

};

class UFortResearchStatTileWidget : public UUserWidget
{
	public:
	    class UFortStatItemDefinition* PersonalStatItemDefinition; // 0x228 Size: 0x8
	    class UFortStatItemDefinition* TeamStatItemDefinition; // 0x230 Size: 0x8
	    FName StatCostCurveName; // 0x238 Size: 0x8
	    FName StatPersonalDeltaCurveName; // 0x240 Size: 0x8
	    FName StatPersonalCumulativeCurveName; // 0x248 Size: 0x8
	    FName StatTeamDeltaCurveName; // 0x250 Size: 0x8
	    FName StatTeamCumulativeCurveName; // 0x258 Size: 0x8
	    char UnknownData0[0x260]; // 0x260
	    void OnStatChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool IsAtMaxResearchLevel(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    struct FString GetStatIdName(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    EFortStatType GetPersonalStatType(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    int GetNextTeamStatValueDelta(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    int GetNextPersonalStatValueDelta(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    int GetNextCombinedStatValueDelta(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    int GetCurrentTeamStatValue(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    int GetCurrentResearchLevel(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    int GetCurrentPersonalStatValue(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    int GetCurrentCombinedStatValue(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    int GetCostToIncreaseStat(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7d69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortResearchStatTileWidget");
			return (class UClass*)ptr;
		};

};

class UFortResultsSummaryScreenWidget : public UCommonUserWidget
{
	public:
	    void GetTotalScoreSortedScoreIndices(class UFortUIScoreReport* ScoreReport, TArray<int> OutSortedScoreIndices); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7db1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortResultsSummaryScreenWidget");
			return (class UClass*)ptr;
		};

};

class UFortResultsTeleportScreenWidget : public UCommonUserWidget
{
	public:
	    float ExitTime; // 0x230 Size: 0x4
	    char UnknownData0[0x234]; // 0x234
	    void StartExitTimer(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnExitTimerFinished(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnExitTimeRemainingUpdated(int TimeRemainingSeconds); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnExitTimePercentagePassedUpdated(float Percent); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7d89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortResultsTeleportScreenWidget");
			return (class UClass*)ptr;
		};

};

class UFortResultsWidget : public UCommonActivatablePanel
{
	public:
	    char UnknownData0[0x78];
	    int AdditionalGrantedMissionPoints; // 0x390 Size: 0x4
	    char UnknownData1[0x4]; // 0x394
	    TArray<class UFortItem*> RewardedBadges; // 0x398 Size: 0x10
	    TArray<class UFortItem*> MissedBadges; // 0x3a8 Size: 0x10
	    TArray<class UFortItem*> RewardedItems; // 0x3b8 Size: 0x10
	    TArray<class UFortItem*> RewardedAccountItems; // 0x3c8 Size: 0x10
	    char UnknownData2[0x3d8]; // 0x3d8
	    void TriggerSetupTeleportCameraEvent(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SendEndOfRoundUpVoteAnalytic(struct FUniqueNetIdRepl TargetId, struct FString TargetPlayerName); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SendEndOfRoundScreenAnalytic(struct FString ScreenName, bool Skipped, float TimeSpent); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SendEndOfRoundFriendInviteAnalytic(struct FUniqueNetIdRepl TargetId, struct FString TargetPlayerName); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void RequestExitZone(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void LogXPData(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool IsDataFinalized(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    struct FText GetZoneCompletionResultText(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    EFortCompletionResult GetZoneCompletionResult(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    int GetTotalMissionPointsEarned(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void GetRewardsByType(EFortRewardItemType Type, TArray<class UFortItem*> OutRewards); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x-7c09];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortResultsWidget");
			return (class UClass*)ptr;
		};

};

class UFortReticle : public UFortHUDElementWidget
{
	public:
	    char UnknownData0[0x30];
	    class UMaterialInterface* ReticleWeaponCooldownMI; // 0x288 Size: 0x8
	    char UnknownData1[0x290]; // 0x290
	    void OnWeaponEquipped(class AFortWeapon* NewWeapon, class AFortWeapon* PrevWeapon); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnReticleColorChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnPawnSet(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnContextualReticleChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7d51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortReticle");
			return (class UClass*)ptr;
		};

};

class UFortReturnReasonEntry : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    class UObject* InternalData; // 0xb30 Size: 0x8
	    class UCommonTextBlock* Text_Name; // 0xb38 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortReturnReasonEntry");
			return (class UClass*)ptr;
		};

};

class UFortRewardNotificationData : public UObject
{
	public:
	    EFrontEndRewardType RewardType; // 0x28 Size: 0x1
	    char UnknownData0[0x29]; // 0x29
	    bool GetIconBrush(struct FSlateBrush IconBrush, char BrushSize); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7fb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRewardNotificationData");
			return (class UClass*)ptr;
		};

};

class UFortRewardCollectionBookData : public UFortRewardNotificationData
{
	public:
	    struct FFortCollectionBookRewards CollectionBookRewards; // 0x30 Size: 0x68

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRewardCollectionBookData");
			return (class UClass*)ptr;
		};

};

class UFortRewardNotificationSubWidget : public UCommonUserWidget
{
	public:
	    MulticastDelegateProperty OnTransitionInComplete; // 0x230 Size: 0x10
	    MulticastDelegateProperty OnTransitionOutComplete; // 0x240 Size: 0x10
	    char UnknownData0[0x250]; // 0x250
	    void TransitionOutBegin(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void TransitionOut(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void TransitionInBegin(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void TransitionIn(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetPrimaryActionText(struct FText Text); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetPrimaryActionHidden(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetPrimaryActionEnabled(bool bEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetInputActionHandlerState(class UDataTable* DataTable, FName RowName, EInputActionState State); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void RemoveInputActionHandler(struct FDataTableRowHandle InputActionRow); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void RemoveAllInputActionHandlers(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnPrimaryAction(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void OnNavigationUp(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void OnNavigationRight(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void OnNavigationLeft(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void OnNavigationDown(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void OnDeactivated(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void OnActivated(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void IsPrimaryActionHidden(bool bHidden); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void IsPrimaryActionEnabled(bool bEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void InspectItem(class UFortItem* ItemToInspect); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void Init(class UFortRewardNotificationWidget* MainWidget); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void AddInputActionHandler(class UDataTable* DataTable, FName RowName, __int64/*DelegateProperty*/ CommittedEvent); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x-7d89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRewardNotificationSubWidget");
			return (class UClass*)ptr;
		};

};

class UFortRewardConversationWidget : public UFortRewardNotificationSubWidget
{
	public:
	    bool IsValidConversation(class UFortConversation* Conversation); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void GetDataFromSentence(struct FFortConversationSentence Sentence, struct FText Text, class UTexture2D* TalkingHeadTexture); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7d89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRewardConversationWidget");
			return (class UClass*)ptr;
		};

};

class UFortRewardDifficultyIncrease : public UFortRewardNotificationData
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRewardDifficultyIncrease");
			return (class UClass*)ptr;
		};

};

class UFortRewardEpicQuestData : public UFortRewardNotificationData
{
	public:
	    class UFortQuestItem* Quest; // 0x30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRewardEpicQuestData");
			return (class UClass*)ptr;
		};

};

class UFortRewardExpeditionData : public UFortRewardNotificationData
{
	public:
	    class UFortExpeditionItem* Expedition; // 0x30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRewardExpeditionData");
			return (class UClass*)ptr;
		};

};

class UFortRewardExpeditionWidget : public UFortRewardNotificationSubWidget
{
	public:
	    MulticastDelegateProperty OnMcpError; // 0x258 Size: 0x10
	    char UnknownData0[0x268]; // 0x268
	    void OnCollectExpeditionCompleted(class UFortExpeditionItem* Expedition, bool bSucceeded, TArray<struct FFortItemInstanceQuantityPair> Rewards); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void CollectExpedition(class UFortExpeditionItem* Expedition); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d21];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRewardExpeditionWidget");
			return (class UClass*)ptr;
		};

};

class UFortRewardGiftBoxData : public UFortRewardNotificationData
{
	public:
	    class UFortGiftBoxItem* GiftBox; // 0x30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRewardGiftBoxData");
			return (class UClass*)ptr;
		};

};

class UFortRewardInfoButton : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    class UPanelWidget* ItemCardPanel; // 0xb30 Size: 0x8
	    EFortItemCardSize ItemCardSize; // 0xb38 Size: 0x1
	    bool bDisplayAsRewardCard; // 0xb39 Size: 0x1
	    char UnknownData1[0x6]; // 0xb3a
	    class UFortItem* ItemInstance; // 0xb40 Size: 0x8
	    char UnknownData2[0xb48]; // 0xb48
	    void SetShowDescriptionBP(bool bInShowDescription); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetShowDescription(bool bInShowDescription); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetItemInstanceQuantityPair(struct FFortItemInstanceQuantityPair ItemQuantityPair); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleDifferentItemOrQuantitySetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    int GetQuantity(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    class UFortItem* GetItemInstance(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7499];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRewardInfoButton");
			return (class UClass*)ptr;
		};

};

class UFortRewardInfoWidget : public UCommonUserWidget
{
	public:
	    class UPanelWidget* RewardListWidget; // 0x230 Size: 0x8
	    struct FMargin RewardWidgetPadding; // 0x238 Size: 0x10
	    char HorizontalAlignment; // 0x248 Size: 0x1
	    char VerticalAlignment; // 0x249 Size: 0x1
	    bool bShowDescription; // 0x24a Size: 0x1
	    bool bAllowItemInteraction; // 0x24b Size: 0x1
	    int MaxNumRewardsShown; // 0x24c Size: 0x4
	    class UFortRewardInfoButton* OrWidgetType; // 0x250 Size: 0x8
	    class UFortRewardInfoButton* RewardInfoButtonType; // 0x258 Size: 0x8
	    char UnknownData0[0x20]; // 0x260
	    class UCommonButtonGroup* ButtonGroup; // 0x280 Size: 0x8
	    char UnknownData1[0x288]; // 0x288
	    void SetRewards(struct FFortRewardInfo RewardsIn); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetReward(struct FFortItemQuantityPair RewardIn); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetButtonGroup(class UCommonButtonGroup* InButtonGroup); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool ContainsReward(struct FString TemplateIdToCheck); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7d29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRewardInfoWidget");
			return (class UClass*)ptr;
		};

};

class UFortRewardItemCacheData : public UFortRewardNotificationData
{
	public:
	    class UFortItem* ItemCache; // 0x30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRewardItemCacheData");
			return (class UClass*)ptr;
		};

};

class UFortRewardMissionAlertData : public UFortRewardNotificationData
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRewardMissionAlertData");
			return (class UClass*)ptr;
		};

};

class UFortRewardMissionData : public UFortRewardNotificationData
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRewardMissionData");
			return (class UClass*)ptr;
		};

};

class UFortRewardNewQuestWidget : public UFortRewardNotificationSubWidget
{
	public:
	    bool IsValidConversation(class UFortConversation* Conversation); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void GetDataFromSentence(struct FFortConversationSentence Sentence, struct FText Text, class UTexture2D* TalkingHeadTexture); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7d89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRewardNewQuestWidget");
			return (class UClass*)ptr;
		};

};

class UFortRewardNotificationWidget : public UCommonActivatablePanel
{
	public:
	    TArray<class UFortRewardNotificationData*> NotificationDataList; // 0x318 Size: 0x10
	    char UnknownData0[0x10]; // 0x328
	    class UOverlay* OverlayMain; // 0x338 Size: 0x8
	    struct FFortSwipeDetector SwipeDetector; // 0x340 Size: 0x70
	    char UnknownData1[0x3b0]; // 0x3b0
	    void SetPrimaryActionText(struct FText Text); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetPrimaryActionHidden(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetPrimaryActionEnabled(bool bEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void ResetAllRewardData(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnPrimaryActionTextChanged(struct FText Text); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnPrimaryActionHidden(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnPrimaryActionEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnPrimaryActionDisabled(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnNavigationUp(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnNavigationRight(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void OnNavigationLeft(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void OnNavigationDown(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void IsPrimaryActionHidden(bool bHidden); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void IsPrimaryActionEnabled(bool bEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void InspectItem(class UFortItem* ItemToInspect); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void AddQuestData(class UFortQuestItem* Quest); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void AddMissionData(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void AddMissionAlertData(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void AddItemCacheRewardData(class UFortItem* ItemCache); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void AddGiftBoxData(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void AddExpeditionData(class UFortExpeditionItem* ExpeditionItem); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void AddEpicQuestData(class UFortQuestItem* Quest); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void AddDifficultyIncreaseRewardData(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void AddCollectionBookData(struct FFortCollectionBookRewards CollectionBookRewards); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x-7c11];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRewardNotificationWidget");
			return (class UClass*)ptr;
		};

};

class UFortRewardQuestData : public UFortRewardNotificationData
{
	public:
	    class UFortQuestItem* Quest; // 0x30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRewardQuestData");
			return (class UClass*)ptr;
		};

};

class UFortRichTextBlock : public UWidget
{
	public:
	    struct FText Text; // 0x100 Size: 0x18
	    class UDataTable* StyleSet; // 0x118 Size: 0x8
	    struct FMargin TextMargin; // 0x120 Size: 0x10
	    float WrapTextAt; // 0x130 Size: 0x4
	    bool AutoWrapText; // 0x134 Size: 0x1
	    char Justification; // 0x135 Size: 0x1
	    char UnknownData0[0x2]; // 0x136
	    struct FButtonStyle HyperlinkButtonStyle; // 0x138 Size: 0x278
	    struct FScrollBarStyle ScrollBarStyle; // 0x3b0 Size: 0x4d0
	    bool DisableTouchInput; // 0x880 Size: 0x1
	    bool AllowContextMenu; // 0x881 Size: 0x1
	    char UnknownData1[0x6]; // 0x882
	    class UFortKeybindWidget* KeybindWidgetClass; // 0x888 Size: 0x8
	    char UnknownData2[0x890]; // 0x890
	    void SetText(struct FText InText); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static struct FString EscapeStringForRichText(struct FString inString); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7551];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortRichTextBlock");
			return (class UClass*)ptr;
		};

};

class UFortSelectableAttributeListItem_NUI : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    class UFortAttributeListItem_NUI* AttributeListItem; // 0xb30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSelectableAttributeListItem_NUI");
			return (class UClass*)ptr;
		};

};

class UFortSettingsContext : public UBlueprintContextBase
{
	public:
	    MulticastDelegateProperty WindowModeHasChanged; // 0x28 Size: 0x10
	    char UnknownData0[0x50]; // 0x38
	    class UFortOptionsMenuData* OptionsMenuData; // 0x88 Size: 0x8
	    class UFortOptionsMenuData* CreativeOptionsMenuData; // 0x90 Size: 0x8
	    char UnknownData1[0xc]; // 0x98
	    float MinGammaValue; // 0xa4 Size: 0x4
	    float MaxGammaValue; // 0xa8 Size: 0x4
	    char UnknownData2[0xac]; // 0xac
	    void YawInversionReset(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void YawInversionChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void YawForMotionInversionReset(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void YawForMotionInversionChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void WindowModeChanged(int NewMode); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void ViewDistanceQualityChanged(int ButtonId); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void UseVsyncChanged(bool IsChecked); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void UpdateGammaSettings(float GammaValue); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void TouchVerticalSensitivityValueChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void TouchTargetingMultiplierValueChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void TouchLookSensitivityChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void TouchDragScopedSensitivityValueChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void ThreeDResolutionChanged(float Resolution); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void TextureQualityChanged(int ButtonId); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void TargetingToggleChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void TargetingMultiplierValueChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void TapInteractChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void StreamerModeChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void SprintToggleChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void SprintCancelsReloadChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void SprintByDefaultChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void SoundFXVolumeChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void SliderSettingReset(ESettingType InSettingType, struct FText NameText, float PreviousValue, float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void SliderSettingChanged(ESettingType InSettingType, struct FText NameText, float PreviousValue, float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void ShowViewerCountChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void ShowGrassChanged(bool IsChecked); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void ShowFPSChanged(bool IsChecked); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    void ShadowQualityChanged(int ButtonId); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    void SetVoiceChatPTTEnabled(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    void SetVoiceChatOutputDevice(int NewDevice); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    void SetVoiceChatInputDevice(int NewDevice); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    void SetVoiceChatEnabled(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    void SetVoiceChat3DEnabled(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    void SetVisualizeAudioSources(bool bEnable); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    void SetSubtitlesEnabled(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    void SetQuality(int NewQuality); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    void SetIgnoreGamepadInput(bool bIgnore); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    void SetColorBlindStrength(float InColorBlindStrength); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    void SetColorBlindMode(int InMode); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    void SetAllowGameVolumeWhenMinimized(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    void SendSettingChanges(); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    void ScopedMultiplierValueChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    void SafeZoneChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    void RotatorSettingReset(ESettingType InSettingType, struct FText NameText, int PreviousValue, int NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    void RotatorSettingChanged(ESettingType InSettingType, struct FText NameText, int PreviousValue, int NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    void ResolutionChanged(int NewResolution); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    void RegionReset(); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    void RegionChanged(int NewRegion); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    void PowerSaverModeChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    void PostProcessQualityChanged(int ButtonId); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    void PitchInversionReset(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    void PitchInversionChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    void PitchForMotionInversionReset(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    void PitchForMotionInversionChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    void PitchForAircraftSecondaryInversionReset(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    void PitchForAircraftSecondaryInversionChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    void PitchForAircraftPrimaryInversionReset(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    void PitchForAircraftPrimaryInversionChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    void PeripheralLightingChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    void OnUseTapToShootChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x7fe1]; // 0x7fe1
	    void OnTurboBuildReset(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData63[0x7fe1]; // 0x7fe1
	    void OnTurboBuildChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData64[0x7fe1]; // 0x7fe1
	    void OnShowGlobalChatEnabledChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData65[0x7fe1]; // 0x7fe1
	    void OnShadowPlayHighlightsChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData66[0x7fe1]; // 0x7fe1
	    void OnReplayRecordingPreferenceChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData67[0x7fe1]; // 0x7fe1
	    void OnQualitySelectorReset(); // 0x0 Size: 0x7fe1
	    char UnknownData68[0x7fe1]; // 0x7fe1
	    void OnQualitySelectorChanged(int ValueRef); // 0x0 Size: 0x7fe1
	    char UnknownData69[0x7fe1]; // 0x7fe1
	    void OnLargeTeamsReplayRecordingPreferenceChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData70[0x7fe1]; // 0x7fe1
	    void OnHUDScaleChanged(float bInHUDScale); // 0x0 Size: 0x7fe1
	    char UnknownData71[0x7fe1]; // 0x7fe1
	    void OnGamepadAutoRunChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData72[0x7fe1]; // 0x7fe1
	    void OnForceFeedbackChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData73[0x7fe1]; // 0x7fe1
	    void OnFocusOnFirstBuildingPieceWhenQuickbarSwappedChangedAthena(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData74[0x7fe1]; // 0x7fe1
	    void OnFocusOnFirstBuildingPieceWhenQuickbarSwappedChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData75[0x7fe1]; // 0x7fe1
	    void OnEnableTryBuildOnFocusChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData76[0x7fe1]; // 0x7fe1
	    void OnEditModeAimAssistChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData77[0x7fe1]; // 0x7fe1
	    void OnEditButtonHoldTimeChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData78[0x7fe1]; // 0x7fe1
	    void OnCrossplayPreferenceChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData79[0x7fe1]; // 0x7fe1
	    void OnCreativeTurboDeleteReset(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData80[0x7fe1]; // 0x7fe1
	    void OnCreativeTurboDeleteChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData81[0x7fe1]; // 0x7fe1
	    void OnCreativeModeReplayRecordingPreferenceChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData82[0x7fe1]; // 0x7fe1
	    void OnAutoSortConsumablesToRightChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData83[0x7fe1]; // 0x7fe1
	    void OnAutoPickupWeaponsConsolePCChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData84[0x7fe1]; // 0x7fe1
	    void OnAutoPickupWeaponsChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData85[0x7fe1]; // 0x7fe1
	    void OnAutoOpenDoorsChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData86[0x7fe1]; // 0x7fe1
	    void OnAutoChangeMaterialReset(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData87[0x7fe1]; // 0x7fe1
	    void OnAutoChangeMaterialChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData88[0x7fe1]; // 0x7fe1
	    void OnAimAssistReset(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData89[0x7fe1]; // 0x7fe1
	    void OnAimAssistChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData90[0x7fe1]; // 0x7fe1
	    void MusicVolumeChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData91[0x7fe1]; // 0x7fe1
	    void MouseSensitivityYChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData92[0x7fe1]; // 0x7fe1
	    void MouseSensitivityXChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData93[0x7fe1]; // 0x7fe1
	    void MouseSensitivityMultiplierForAircraftChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData94[0x7fe1]; // 0x7fe1
	    void MotionTargetingMultiplierValueChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData95[0x7fe1]; // 0x7fe1
	    void MotionScopedMultiplierValueChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData96[0x7fe1]; // 0x7fe1
	    void MotionHarvestingToolMultiplierValueChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData97[0x7fe1]; // 0x7fe1
	    void MotionControlEnabledValueChanged(bool NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData98[0x7fe1]; // 0x7fe1
	    void MotionBlurChanged(bool IsChecked); // 0x0 Size: 0x7fe1
	    char UnknownData99[0x7fe1]; // 0x7fe1
	    void MotionAxisValueChanged(int NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData100[0x7fe1]; // 0x7fe1
	    void MobileFPSModeChanged(int FPSMode); // 0x0 Size: 0x7fe1
	    char UnknownData101[0x7fe1]; // 0x7fe1
	    void LanguageReset(); // 0x0 Size: 0x7fe1
	    char UnknownData102[0x7fe1]; // 0x7fe1
	    void LanguageChanged(int NewMode); // 0x0 Size: 0x7fe1
	    char UnknownData103[0x7fe1]; // 0x7fe1
	    void HiddenMatchmakingDelayMaxReset(); // 0x0 Size: 0x7fe1
	    char UnknownData104[0x7fe1]; // 0x7fe1
	    void HiddenMatchmakingDelayMaxChanged(int InValue); // 0x0 Size: 0x7fe1
	    char UnknownData105[0x7fe1]; // 0x7fe1
	    void GyroSensitivityValueChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData106[0x7fe1]; // 0x7fe1
	    bool GetYawInversionState(); // 0x0 Size: 0x7fe1
	    char UnknownData107[0x7fe1]; // 0x7fe1
	    bool GetYawForMotionInversionState(); // 0x0 Size: 0x7fe1
	    char UnknownData108[0x7fe1]; // 0x7fe1
	    TArray<struct FText> GetWindowModeNames(); // 0x0 Size: 0x7fe1
	    char UnknownData109[0x7fe1]; // 0x7fe1
	    bool GetVoiceChatPTTEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData110[0x7fe1]; // 0x7fe1
	    int GetVoiceChatOutputDevice(); // 0x0 Size: 0x7fe1
	    char UnknownData111[0x7fe1]; // 0x7fe1
	    int GetVoiceChatInputDevice(); // 0x0 Size: 0x7fe1
	    char UnknownData112[0x7fe1]; // 0x7fe1
	    bool GetVoiceChatEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData113[0x7fe1]; // 0x7fe1
	    bool GetVoiceChat3DEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData114[0x7fe1]; // 0x7fe1
	    bool GetVisualizeAudioSources(); // 0x0 Size: 0x7fe1
	    char UnknownData115[0x7fe1]; // 0x7fe1
	    int GetViewDistanceQuality(); // 0x0 Size: 0x7fe1
	    char UnknownData116[0x7fe1]; // 0x7fe1
	    TArray<struct FText> GetViewDistanceNames(); // 0x0 Size: 0x7fe1
	    char UnknownData117[0x7fe1]; // 0x7fe1
	    bool GetUseVsync(); // 0x0 Size: 0x7fe1
	    char UnknownData118[0x7fe1]; // 0x7fe1
	    bool GetUseTapToShoot(); // 0x0 Size: 0x7fe1
	    char UnknownData119[0x7fe1]; // 0x7fe1
	    bool GetTurboBuild(); // 0x0 Size: 0x7fe1
	    char UnknownData120[0x7fe1]; // 0x7fe1
	    float GetTouchVerticalSensitivityValue(); // 0x0 Size: 0x7fe1
	    char UnknownData121[0x7fe1]; // 0x7fe1
	    float GetTouchTargetingMultiplierValue(); // 0x0 Size: 0x7fe1
	    char UnknownData122[0x7fe1]; // 0x7fe1
	    float GetTouchLookSensitivityValue(); // 0x0 Size: 0x7fe1
	    char UnknownData123[0x7fe1]; // 0x7fe1
	    float GetTouchDragScopedSensitivityValue(); // 0x0 Size: 0x7fe1
	    char UnknownData124[0x7fe1]; // 0x7fe1
	    float GetThreeDResolution(); // 0x0 Size: 0x7fe1
	    char UnknownData125[0x7fe1]; // 0x7fe1
	    int GetTextureQuality(); // 0x0 Size: 0x7fe1
	    char UnknownData126[0x7fe1]; // 0x7fe1
	    bool GetTargetingToggleState(); // 0x0 Size: 0x7fe1
	    char UnknownData127[0x7fe1]; // 0x7fe1
	    float GetTargetingMultiplierValue(); // 0x0 Size: 0x7fe1
	    char UnknownData128[0x7fe1]; // 0x7fe1
	    bool GetTapInteractState(); // 0x0 Size: 0x7fe1
	    char UnknownData129[0x7fe1]; // 0x7fe1
	    bool GetSubtitlesEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData130[0x7fe1]; // 0x7fe1
	    bool GetStreamerModeEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData131[0x7fe1]; // 0x7fe1
	    bool GetSprintToggleState(); // 0x0 Size: 0x7fe1
	    char UnknownData132[0x7fe1]; // 0x7fe1
	    bool GetSprintCancelsReloadState(); // 0x0 Size: 0x7fe1
	    char UnknownData133[0x7fe1]; // 0x7fe1
	    bool GetSprintByDefaultState(); // 0x0 Size: 0x7fe1
	    char UnknownData134[0x7fe1]; // 0x7fe1
	    float GetSoundFXVolumeValue(); // 0x0 Size: 0x7fe1
	    char UnknownData135[0x7fe1]; // 0x7fe1
	    float GetSliderSettingValue(ESettingType InSettingType); // 0x0 Size: 0x7fe1
	    char UnknownData136[0x7fe1]; // 0x7fe1
	    bool GetShowViewerCountEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData137[0x7fe1]; // 0x7fe1
	    bool GetShowHeroHeadAccessories(); // 0x0 Size: 0x7fe1
	    char UnknownData138[0x7fe1]; // 0x7fe1
	    bool GetShowHeroBackpack(); // 0x0 Size: 0x7fe1
	    char UnknownData139[0x7fe1]; // 0x7fe1
	    bool GetShowGrass(); // 0x0 Size: 0x7fe1
	    char UnknownData140[0x7fe1]; // 0x7fe1
	    bool GetShowGlobalChatEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData141[0x7fe1]; // 0x7fe1
	    bool GetShowFPS(); // 0x0 Size: 0x7fe1
	    char UnknownData142[0x7fe1]; // 0x7fe1
	    int GetShadowQuality(); // 0x0 Size: 0x7fe1
	    char UnknownData143[0x7fe1]; // 0x7fe1
	    bool GetShadowPlayHighlightsEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData144[0x7fe1]; // 0x7fe1
	    float GetSettingValueInRange(float Value, ESettingType InSettingType, ESettingTab InSettingTab); // 0x0 Size: 0x7fe1
	    char UnknownData145[0x7fe1]; // 0x7fe1
	    TArray<struct FText> GetSettingDisplayNames(ESettingType InSettingType); // 0x0 Size: 0x7fe1
	    char UnknownData146[0x7fe1]; // 0x7fe1
	    float GetScopedMultiplierValue(); // 0x0 Size: 0x7fe1
	    char UnknownData147[0x7fe1]; // 0x7fe1
	    float GetSafeZoneValue(); // 0x0 Size: 0x7fe1
	    char UnknownData148[0x7fe1]; // 0x7fe1
	    int GetRotatorSettingValue(ESettingType InSettingType); // 0x0 Size: 0x7fe1
	    char UnknownData149[0x7fe1]; // 0x7fe1
	    int GetResolution(); // 0x0 Size: 0x7fe1
	    char UnknownData150[0x7fe1]; // 0x7fe1
	    bool GetReplayRecordingEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData151[0x7fe1]; // 0x7fe1
	    TArray<struct FText> GetRegionDisplayNames(); // 0x0 Size: 0x7fe1
	    char UnknownData152[0x7fe1]; // 0x7fe1
	    TArray<struct FText> GetQualityOffNames(); // 0x0 Size: 0x7fe1
	    char UnknownData153[0x7fe1]; // 0x7fe1
	    TArray<struct FText> GetQualityNames(); // 0x0 Size: 0x7fe1
	    char UnknownData154[0x7fe1]; // 0x7fe1
	    TArray<struct FText> GetQualityLowNames(); // 0x0 Size: 0x7fe1
	    char UnknownData155[0x7fe1]; // 0x7fe1
	    int GetQuality(); // 0x0 Size: 0x7fe1
	    char UnknownData156[0x7fe1]; // 0x7fe1
	    bool GetPowerSaverMode(); // 0x0 Size: 0x7fe1
	    char UnknownData157[0x7fe1]; // 0x7fe1
	    int GetPostProcessQuality(); // 0x0 Size: 0x7fe1
	    char UnknownData158[0x7fe1]; // 0x7fe1
	    TArray<struct FText> GetPossibleLanguages(); // 0x0 Size: 0x7fe1
	    char UnknownData159[0x7fe1]; // 0x7fe1
	    bool GetPitchInversionState(); // 0x0 Size: 0x7fe1
	    char UnknownData160[0x7fe1]; // 0x7fe1
	    bool GetPitchForMotionInversionState(); // 0x0 Size: 0x7fe1
	    char UnknownData161[0x7fe1]; // 0x7fe1
	    bool GetPitchForAircraftSecondaryInversionState(); // 0x0 Size: 0x7fe1
	    char UnknownData162[0x7fe1]; // 0x7fe1
	    bool GetPitchForAircraftPrimaryInversionState(); // 0x0 Size: 0x7fe1
	    char UnknownData163[0x7fe1]; // 0x7fe1
	    bool GetPeripheralLightingEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData164[0x7fe1]; // 0x7fe1
	    int GetOverallQualityLevel(); // 0x0 Size: 0x7fe1
	    char UnknownData165[0x7fe1]; // 0x7fe1
	    float GetMusicVolumeValue(); // 0x0 Size: 0x7fe1
	    char UnknownData166[0x7fe1]; // 0x7fe1
	    struct FVector2D GetMouseSensitivityValue(); // 0x0 Size: 0x7fe1
	    char UnknownData167[0x7fe1]; // 0x7fe1
	    float GetMouseSensitivityMultiplierForAircraft(); // 0x0 Size: 0x7fe1
	    char UnknownData168[0x7fe1]; // 0x7fe1
	    float GetMotionTargetingMultiplierValue(); // 0x0 Size: 0x7fe1
	    char UnknownData169[0x7fe1]; // 0x7fe1
	    float GetMotionScopedMultiplierValue(); // 0x0 Size: 0x7fe1
	    char UnknownData170[0x7fe1]; // 0x7fe1
	    float GetMotionHarvestingToolMultiplierValue(); // 0x0 Size: 0x7fe1
	    char UnknownData171[0x7fe1]; // 0x7fe1
	    bool GetMotionControlsEnabledValue(); // 0x0 Size: 0x7fe1
	    char UnknownData172[0x7fe1]; // 0x7fe1
	    bool GetMotionBlur(); // 0x0 Size: 0x7fe1
	    char UnknownData173[0x7fe1]; // 0x7fe1
	    int GetMotionAxisValue(); // 0x0 Size: 0x7fe1
	    char UnknownData174[0x7fe1]; // 0x7fe1
	    TArray<struct FText> GetMotionAxisNames(); // 0x0 Size: 0x7fe1
	    char UnknownData175[0x7fe1]; // 0x7fe1
	    TArray<struct FText> GetMobileFPSTypeNames(); // 0x0 Size: 0x7fe1
	    char UnknownData176[0x7fe1]; // 0x7fe1
	    int GetMobileFPSMode(); // 0x0 Size: 0x7fe1
	    char UnknownData177[0x7fe1]; // 0x7fe1
	    int GetMaxQualityLevel(); // 0x0 Size: 0x7fe1
	    char UnknownData178[0x7fe1]; // 0x7fe1
	    bool GetLargeTeamsReplayRecordingEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData179[0x7fe1]; // 0x7fe1
	    bool GetIgnoreGamepadInput(); // 0x0 Size: 0x7fe1
	    char UnknownData180[0x7fe1]; // 0x7fe1
	    float GetHUDScale(); // 0x0 Size: 0x7fe1
	    char UnknownData181[0x7fe1]; // 0x7fe1
	    int GetHiddenMatchmakingDelayMax(); // 0x0 Size: 0x7fe1
	    char UnknownData182[0x7fe1]; // 0x7fe1
	    float GetGyroSensitivityValue(); // 0x0 Size: 0x7fe1
	    char UnknownData183[0x7fe1]; // 0x7fe1
	    float GetGammaSettings(); // 0x0 Size: 0x7fe1
	    char UnknownData184[0x7fe1]; // 0x7fe1
	    float GetGamepadTargetingMultiplierValue(); // 0x0 Size: 0x7fe1
	    char UnknownData185[0x7fe1]; // 0x7fe1
	    float GetGamepadScopedMultiplierValue(); // 0x0 Size: 0x7fe1
	    char UnknownData186[0x7fe1]; // 0x7fe1
	    struct FVector2D GetGamepadLookSensitivityValue(); // 0x0 Size: 0x7fe1
	    char UnknownData187[0x7fe1]; // 0x7fe1
	    float GetGamepadBuildingMultiplierValue(); // 0x0 Size: 0x7fe1
	    char UnknownData188[0x7fe1]; // 0x7fe1
	    bool GetGamepadAutoRunState(); // 0x0 Size: 0x7fe1
	    char UnknownData189[0x7fe1]; // 0x7fe1
	    TArray<struct FText> GetFPSNames(); // 0x0 Size: 0x7fe1
	    char UnknownData190[0x7fe1]; // 0x7fe1
	    bool GetForceFeedbackState(); // 0x0 Size: 0x7fe1
	    char UnknownData191[0x7fe1]; // 0x7fe1
	    bool GetFocusOnFirstBuildingPieceWhenQuickbarSwappedStateAthena(); // 0x0 Size: 0x7fe1
	    char UnknownData192[0x7fe1]; // 0x7fe1
	    bool GetFocusOnFirstBuildingPieceWhenQuickbarSwappedState(); // 0x0 Size: 0x7fe1
	    char UnknownData193[0x7fe1]; // 0x7fe1
	    bool GetFirstPersonCameraState(); // 0x0 Size: 0x7fe1
	    char UnknownData194[0x7fe1]; // 0x7fe1
	    bool GetEnableTryBuildOnFocus(); // 0x0 Size: 0x7fe1
	    char UnknownData195[0x7fe1]; // 0x7fe1
	    int GetEffectsQuality(); // 0x0 Size: 0x7fe1
	    char UnknownData196[0x7fe1]; // 0x7fe1
	    bool GetEditModeAimAssistState(); // 0x0 Size: 0x7fe1
	    char UnknownData197[0x7fe1]; // 0x7fe1
	    float GetEditButtonHoldTimeValue(); // 0x0 Size: 0x7fe1
	    char UnknownData198[0x7fe1]; // 0x7fe1
	    TArray<struct FText> GetDisplayResolutionNames(); // 0x0 Size: 0x7fe1
	    char UnknownData199[0x7fe1]; // 0x7fe1
	    float GetDialogVolumeValue(); // 0x0 Size: 0x7fe1
	    char UnknownData200[0x7fe1]; // 0x7fe1
	    int GetCurrentRegion(); // 0x0 Size: 0x7fe1
	    char UnknownData201[0x7fe1]; // 0x7fe1
	    int GetCurrentLanguage(); // 0x0 Size: 0x7fe1
	    char UnknownData202[0x7fe1]; // 0x7fe1
	    int GetCurrentFPS(); // 0x0 Size: 0x7fe1
	    char UnknownData203[0x7fe1]; // 0x7fe1
	    int GetCurrentDisplayResolution(); // 0x0 Size: 0x7fe1
	    char UnknownData204[0x7fe1]; // 0x7fe1
	    bool GetCrossplayPreference(); // 0x0 Size: 0x7fe1
	    char UnknownData205[0x7fe1]; // 0x7fe1
	    bool GetCreativeTurboDelete(); // 0x0 Size: 0x7fe1
	    char UnknownData206[0x7fe1]; // 0x7fe1
	    bool GetCreativeModeReplayRecordingEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData207[0x7fe1]; // 0x7fe1
	    bool GetConsoleUnlockedFPSState(); // 0x0 Size: 0x7fe1
	    char UnknownData208[0x7fe1]; // 0x7fe1
	    float GetColorBlindStrength(); // 0x0 Size: 0x7fe1
	    char UnknownData209[0x7fe1]; // 0x7fe1
	    TArray<struct FText> GetColorBlindModeNames(); // 0x0 Size: 0x7fe1
	    char UnknownData210[0x7fe1]; // 0x7fe1
	    int GetColorBlindMode(); // 0x0 Size: 0x7fe1
	    char UnknownData211[0x7fe1]; // 0x7fe1
	    float GetCinematicsVolume(); // 0x0 Size: 0x7fe1
	    char UnknownData212[0x7fe1]; // 0x7fe1
	    float GetChatVolumeValue(); // 0x0 Size: 0x7fe1
	    char UnknownData213[0x7fe1]; // 0x7fe1
	    void GetAvailableVoiceChatOutputDevices(); // 0x0 Size: 0x7fe1
	    char UnknownData214[0x7fe1]; // 0x7fe1
	    void GetAvailableVoiceChatInputDevices(); // 0x0 Size: 0x7fe1
	    char UnknownData215[0x7fe1]; // 0x7fe1
	    bool GetAutoSortConsumablesToRight(); // 0x0 Size: 0x7fe1
	    char UnknownData216[0x7fe1]; // 0x7fe1
	    bool GetAutoPickupWeaponsConsolePC(); // 0x0 Size: 0x7fe1
	    char UnknownData217[0x7fe1]; // 0x7fe1
	    bool GetAutoPickupWeapons(); // 0x0 Size: 0x7fe1
	    char UnknownData218[0x7fe1]; // 0x7fe1
	    bool GetAutoOpenDoors(); // 0x0 Size: 0x7fe1
	    char UnknownData219[0x7fe1]; // 0x7fe1
	    bool GetAutoEquipState(); // 0x0 Size: 0x7fe1
	    char UnknownData220[0x7fe1]; // 0x7fe1
	    bool GetAutoChangeMaterial(); // 0x0 Size: 0x7fe1
	    char UnknownData221[0x7fe1]; // 0x7fe1
	    int GetAntiAliasingQuality(); // 0x0 Size: 0x7fe1
	    char UnknownData222[0x7fe1]; // 0x7fe1
	    bool GetAllowVideoPlayback(); // 0x0 Size: 0x7fe1
	    char UnknownData223[0x7fe1]; // 0x7fe1
	    bool GetAllowLowPower(); // 0x0 Size: 0x7fe1
	    char UnknownData224[0x7fe1]; // 0x7fe1
	    bool GetAllowGameVolumeWhenMinimized(); // 0x0 Size: 0x7fe1
	    char UnknownData225[0x7fe1]; // 0x7fe1
	    bool GetAllowDynamicResolution(); // 0x0 Size: 0x7fe1
	    char UnknownData226[0x7fe1]; // 0x7fe1
	    bool GetAimAssistState(); // 0x0 Size: 0x7fe1
	    char UnknownData227[0x7fe1]; // 0x7fe1
	    void GamepadTargetingMultiplierValueChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData228[0x7fe1]; // 0x7fe1
	    void GamepadScopedMultiplierValueChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData229[0x7fe1]; // 0x7fe1
	    void GamepadLookSensitivityYChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData230[0x7fe1]; // 0x7fe1
	    void GamepadLookSensitivityXChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData231[0x7fe1]; // 0x7fe1
	    void GamepadBuildingMultiplierValueChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData232[0x7fe1]; // 0x7fe1
	    void FrameRateLimitChanged(int FrameRateLimit); // 0x0 Size: 0x7fe1
	    char UnknownData233[0x7fe1]; // 0x7fe1
	    void FirstPersonCameraChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData234[0x7fe1]; // 0x7fe1
	    void EffectsQualityChanged(int ButtonId); // 0x0 Size: 0x7fe1
	    char UnknownData235[0x7fe1]; // 0x7fe1
	    void DialogVolumeChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData236[0x7fe1]; // 0x7fe1
	    void ConsoleUnlockedFPSChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData237[0x7fe1]; // 0x7fe1
	    void CinematicsVolumeChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData238[0x7fe1]; // 0x7fe1
	    void ChatVolumeChanged(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData239[0x7fe1]; // 0x7fe1
	    void AutoEquipChanged(bool bInChecked); // 0x0 Size: 0x7fe1
	    char UnknownData240[0x7fe1]; // 0x7fe1
	    void AntiAliasingQualityChanged(int ButtonId); // 0x0 Size: 0x7fe1
	    char UnknownData241[0x7fe1]; // 0x7fe1
	    void AllowVideoPlaybackChanged(bool IsChecked); // 0x0 Size: 0x7fe1
	    char UnknownData242[0x7fe1]; // 0x7fe1
	    void AllowLowPowerChanged(bool IsChecked); // 0x0 Size: 0x7fe1
	    char UnknownData243[0x7fe1]; // 0x7fe1
	    void AllowDynamicResolutionChanged(bool IsChecked); // 0x0 Size: 0x7fe1
	    char UnknownData244[0x-7ee1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSettingsContext");
			return (class UClass*)ptr;
		};

};

class UFortShowdownDetailView : public UCommonUserWidget
{
	public:
	    struct FFortTournamentDisplayInfo TournamentDisplayInfo; // 0x230 Size: 0x170
	    struct FShowdownTournamentEntry CMSTournamentData; // 0x3a0 Size: 0x178
	    class UCommonTextBlock* Text_TimeRemaining; // 0x518 Size: 0x8
	    class UEpicCMSImage* Image_PosterFront; // 0x520 Size: 0x8
	    class UEpicCMSImage* Image_PosterBack; // 0x528 Size: 0x8
	    class UEpicCMSImage* Image_LoadingScreen; // 0x530 Size: 0x8
	    class UEpicCMSImage* Image_PlaylistTile; // 0x538 Size: 0x8
	    struct FText TimeRemainingFormat; // 0x540 Size: 0x18
	    bool bTimeRemainingShowSeconds; // 0x558 Size: 0x1
	    bool bTimeRemainingUppercase; // 0x559 Size: 0x1
	    ETimespanAsTextFormat TimeRemainingFormatType; // 0x55a Size: 0x1
	    char UnknownData0[0x55b]; // 0x55b
	    bool ShouldShowCrossplayError(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetTournament(struct FString TournamentId, struct FString EventId); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void RefreshDataBP(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool IsEventLeaderboardAvailable(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    struct FTimespan GetTournamentTimeLeft(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    EFortShowdownEventState GetTournamentState(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    TArray<struct FFortShowdownScoringRuleInfo> GetTournamentScoringRules(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    int GetTournamentPinUnlockScore(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    struct FString GetTournamentNextEvent(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    EFortShowdownMatchType GetTournamentMatchType(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    int GetTournamentMatchCap(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    struct FString GetTournamentId(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    TArray<struct FString> GetTournamentEvents(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    struct FDateTime GetTournamentEndTime(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    int GetTournamentBestScore(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    EFortShowdownPinState GetTournamentBestPinState(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    struct FDateTime GetTournamentBeginTime(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    struct FTimespan GetEventTimeLeft(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    struct FText GetEventTimeAsText(struct FDateTime DateTime, EFortDateTimeStyle Style); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    EFortShowdownEventState GetEventState(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    struct FFortShowdownEventBestResultsSummary GetEventResultsSummary(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    EFortShowdownPinState GetEventPinState(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    struct FString GetEventId(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    struct FDateTime GetEventEndTime(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    struct FText GetEventDateAsText(struct FDateTime DateTime, EFortDateTimeStyle Style); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    struct FDateTime GetEventBeginTime(); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    int GetCurrentEventTeamNumMatchesPlayed(); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    int GetCurrentEventScore(); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    int GetBestEventScore(); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    struct FLinearColor ConvertCMSStringToColor(struct FString ColorString); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x-7a49];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortShowdownDetailView");
			return (class UClass*)ptr;
		};

};

class UFortShowdownCurrentEventView : public UFortShowdownDetailView
{
	public:
	    char UnknownData0[0x598];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortShowdownCurrentEventView");
			return (class UClass*)ptr;
		};

};

class UFortShowdownLoadingScreen : public UFortShowdownDetailView
{
	public:
	    char UnknownData0[0x598];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortShowdownLoadingScreen");
			return (class UClass*)ptr;
		};

};

class UFortShowdownScoringHUDAlert : public UFortHUDElementWidget
{
	public:
	    void ScorePointAlert(FName RuleLookup, int TotalScore, int PointDelta); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void OnTeamPlacementChanged(int NewTeamPlacement); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnGamePhaseChanged(EAthenaGamePhase GamePhase); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortShowdownScoringHUDAlert");
			return (class UClass*)ptr;
		};

};

class UFortShowdownScreen : public UFortActivatablePanel
{
	public:
	    class UFortShowdownTournamentTile* TileItemClass; // 0x340 Size: 0x8
	    class UCommonButtonGroup* TournamentTileGroup; // 0x348 Size: 0x8
	    class UScrollBox* ScrollBox_TournamentList; // 0x350 Size: 0x8
	    class UCommonButton* Button_Details; // 0x358 Size: 0x8
	    class UCommonTextBlock* CommonTextBlock_RegionText; // 0x360 Size: 0x8
	    char UnknownData0[0x368]; // 0x368
	    void ShowTournamentDetails(struct FString SelectedTournament); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SelectedTournamentChanged(struct FString SelectedTournament); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void NavigateTournamentRight(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void NavigateTournamentLeft(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleTournamentsChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleDetailsClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7c59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortShowdownScreen");
			return (class UClass*)ptr;
		};

};

class UFortShowdownTournamentTile : public UCommonButton
{
	public:
	    class UFortShowdownDetailView* ShowdownDetailView_Violator; // 0xb28 Size: 0x8
	    class UFortShowdownDetailView* ShowdownDetailView_Poster; // 0xb30 Size: 0x8
	    struct FString TournamentId; // 0xb38 Size: 0x10
	    char UnknownData0[0xb48]; // 0xb48
	    struct FString GetTileTournament(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7499];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortShowdownTournamentTile");
			return (class UClass*)ptr;
		};

};

class UFortSignInConsole : public UCommonActivatablePanel
{
	public:
	    char UnknownData0[0x10];
	    class UEditableText* Email; // 0x328 Size: 0x8
	    class UCommonButton* Button_SendCode; // 0x330 Size: 0x8
	    class UEditableText* Passcode; // 0x338 Size: 0x8
	    class UCommonTextBlock* Text_Error; // 0x340 Size: 0x8
	    class UCommonButton* Button_SubmitCode; // 0x348 Size: 0x8
	    class UWidgetSwitcher* Switcher_Main; // 0x350 Size: 0x8
	    char UnknownData1[0x358]; // 0x358
	    void UpdatePasscodeStatus(struct FText Text); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void UpdateEmailStatus(struct FText Text); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleTextCommitted(struct FText Text, char CommitMethod); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7c89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSignInConsole");
			return (class UClass*)ptr;
		};

};

class UFortSignInWidget : public UCommonActivatablePanel
{
	public:
	    char UnknownData0[0x10];
	    class UCommonBorderStyle* NormalBorderStyle; // 0x328 Size: 0x8
	    class UCommonBorderStyle* HighlightBorderStyle; // 0x330 Size: 0x8
	    struct FString ForgotPasswordURL; // 0x338 Size: 0x10
	    char UnknownData1[0x10]; // 0x348
	    class UEditableText* Email; // 0x358 Size: 0x8
	    class UEditableText* Password; // 0x360 Size: 0x8
	    class UCommonBorder* EmailBorder; // 0x368 Size: 0x8
	    class UCommonBorder* PasswordBorder; // 0x370 Size: 0x8
	    class UCommonButton* SignInButton; // 0x378 Size: 0x8
	    class UCommonButton* Button_ForgotPassword; // 0x380 Size: 0x8
	    char UnknownData2[0x388]; // 0x388
	    void UpdateSignInButton(struct FText Text); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void StartSignIn(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleTextCommitted(struct FText Text, char CommitMethod); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7c59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSignInWidget");
			return (class UClass*)ptr;
		};

};

class UFortSocialDisplayData : public UDataAsset
{
	public:
	    __int64/*MapProperty*/ PlatformPrefixIconMap; // 0x30 Size: 0x50
	    __int64/*MapProperty*/ SubsystemDisplayIconMap; // 0x80 Size: 0x50
	    __int64/*MapProperty*/ PartySizeIconMap; // 0xd0 Size: 0x50

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSocialDisplayData");
			return (class UClass*)ptr;
		};

};

class UFortSocialDisplayLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void SetPlatformPrefixIcon(class UImage* Image, struct FString OtherPlayerPlatform); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void SetPartySizeIcon(class UImage* Image, int InPartySize); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSocialDisplayLibrary");
			return (class UClass*)ptr;
		};

};

class UFortSocialImportButton : public UCommonButton
{
	public:
	    char UnknownData0[0x18];
	    class UFortSocialImportPanel* ActivePanel; // 0xb40 Size: 0x8
	    ESocialImportPanelType DesiredPanelType; // 0xb48 Size: 0x1
	    char UnknownData1[0x7]; // 0xb49
	    class UFortSocialImportPanel* SocialImportPanelClass; // 0xb50 Size: 0x8
	    char UnknownData2[0xb58]; // 0xb58
	    void OnCaptionGenerated(struct FText Caption); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleDynamicSocialImportDialogClosed(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7489];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSocialImportButton");
			return (class UClass*)ptr;
		};

};

class UFortSocialImportPanel : public UFortActivatablePanel
{
	public:
	    MulticastDelegateProperty OnSocialImportPanelClosed; // 0x340 Size: 0x10
	    char UnknownData0[0x28]; // 0x350
	    class UWidgetSwitcher* Switcher_AddFriends; // 0x378 Size: 0x8
	    class UCommonButton* Button_Import; // 0x380 Size: 0x8
	    class UCommonButton* Button_Cancel; // 0x388 Size: 0x8
	    class UCommonButton* Button_Add; // 0x390 Size: 0x8
	    class UCommonButton* Button_NotNow; // 0x398 Size: 0x8
	    class UCommonButton* Button_OptOut; // 0x3a0 Size: 0x8
	    class UBorder* Border_OuterBorder; // 0x3a8 Size: 0x8
	    char UnknownData1[0x3b0]; // 0x3b0
	    void ShowPanel(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnWaitingViewRequested(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnPanelTypeSet(ESocialImportPanelType NewType); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnLauncherImportOpened(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnIncentivizedSet(bool bIncentivized); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnImportViewRequested(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnClaimViewRequested(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool GetSocialPlatform(ESocialImportPanelPlatform OutPlatform); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7c31];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSocialImportPanel");
			return (class UClass*)ptr;
		};

};

class UFortSubsystemNameDisplay : public UUserWidget
{
	public:
	    class UCommonTextBlock* Text_PlatformDisplayName; // 0x228 Size: 0x8
	    class UImage* Image_PlatformIcon; // 0x230 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSubsystemNameDisplay");
			return (class UClass*)ptr;
		};

};

class UFortSocialInteractionMenu : public USocialInteractionMenu
{
	public:
	    class UImage* Image_Platform; // 0x2a8 Size: 0x8
	    class UFortPlayerBanner* PlayerBanner; // 0x2b0 Size: 0x8
	    class UCommonTextBlock* Text_DisplayName; // 0x2b8 Size: 0x8
	    class UDynamicEntryBox* EntryBox_PlatformNames; // 0x2c0 Size: 0x8
	    class UCommonTextBlock* Text_Presence; // 0x2c8 Size: 0x8
	    class UDynamicEntryBox* EntryBox_PartySlots; // 0x2d0 Size: 0x8
	    char UnknownData0[0x2d8]; // 0x2d8
	    void OnUserPresenceChanged(EOnlineStatus OnlineStatus); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnEnableBackButtonDisplay(bool bEnableBackButtonDisplay); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d09];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSocialInteractionMenu");
			return (class UClass*)ptr;
		};

};

class UFortSocialMenuSlateWrapperWidget : public UWidget
{
	public:
	    char UnknownData0[0x120];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSocialMenuSlateWrapperWidget");
			return (class UClass*)ptr;
		};

};

class UFortSocialPanel : public UFortActivatablePanel
{
	public:
	    class UFortSocialPanelView_UserLists* PanelView_UserLists; // 0x340 Size: 0x8
	    char UnknownData0[0x348]; // 0x348
	    bool IsAnySlideOutMenuOpen(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void ClosePanel(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7c99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSocialPanel");
			return (class UClass*)ptr;
		};

};

class UFortSocialPanelView_FriendLinkButton : public UCommonButton
{
	public:
	    class UCommonBorder* Border_ScreenTarget; // 0xb28 Size: 0x8
	    char UnknownData0[0xb30]; // 0xb30
	    void OnShareButtonTypeSet(EFriendLinkShareButtonType Type); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnCopiedToClipboard(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-74b1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSocialPanelView_FriendLinkButton");
			return (class UClass*)ptr;
		};

};

class UFortSocialTabButton : public UCommonButton
{
	public:
	    class UTexture2D* Texture_TabIcon; // 0xb28 Size: 0x8
	    struct FText TabName; // 0xb30 Size: 0x18
	    struct FSlateColor InviteTintColor; // 0xb48 Size: 0x28
	    class UImage* Image_TabIcon; // 0xb70 Size: 0x8
	    class UCommonTextBlock* Text_TabName; // 0xb78 Size: 0x8
	    class UCommonTextBlock* Text_Number; // 0xb80 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSocialTabButton");
			return (class UClass*)ptr;
		};

};

class UFortFriendSearchButton : public UCommonButton
{
	public:
	    class UEditableText* EditableText_AddFriend; // 0xb28 Size: 0x8
	    char UnknownData0[0xb30]; // 0xb30
	    void SetKeyboardFocusOnAddFriendText(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void HandleAddFriendTextCommitted(struct FText Text, char CommitMethod); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-74b1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortFriendSearchButton");
			return (class UClass*)ptr;
		};

};

class UFortSocialPanelView_UserLists : public UUserWidget
{
	public:
	    char UnknownData0[0x68];
	    class UFortLocalUserEntry* LocalUserEntry; // 0x290 Size: 0x8
	    class UCommonWidgetSwitcher* WidgetSwitcher_UserLists; // 0x298 Size: 0x8
	    class UFortSocialTabButton* Button_AddFriendsList; // 0x2a0 Size: 0x8
	    class UFortSocialTabButton* Button_FriendsList; // 0x2a8 Size: 0x8
	    class USocialUserTreeView* TreeView_FriendsLists; // 0x2b0 Size: 0x8
	    class USocialUserTreeView* TreeView_AddFriends; // 0x2b8 Size: 0x8
	    class UFortFriendSearchButton* Button_FriendSearch; // 0x2c0 Size: 0x8
	    char UnknownData1[0x2c8]; // 0x2c8
	    void ToggleSocialPanel(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    TArray<class UUserWidget*> ReturnDisplayedEntryWidgets(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void PlayIntroAnim(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnSocialPanelTabChanged(int PanelIndex); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7d19];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSocialPanelView_UserLists");
			return (class UClass*)ptr;
		};

};

class UFortSocialSettings : public UUserWidget
{
	public:
	    char UnknownData0[0x10];
	    class UDynamicEntryBox* EntryBox_Settings; // 0x238 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSocialSettings");
			return (class UClass*)ptr;
		};

};

class UFortSocialSettingToggle : public UUserWidget
{
	public:
	    char UnknownData0[0x8];
	    class UCommonRotator* Rotator_Text; // 0x230 Size: 0x8
	    class UCommonTextBlock* Text_ParamName; // 0x238 Size: 0x8
	    class UCommonButton* Button_Left; // 0x240 Size: 0x8
	    class UCommonButton* Button_Right; // 0x248 Size: 0x8
	    char UnknownData1[0x250]; // 0x250
	    void HandleRotated(int SelectedIndex); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSocialSettingToggle");
			return (class UClass*)ptr;
		};

};

class UFortSocialStyle : public UDataAsset
{
	public:
	    struct FSocialStyle Style; // 0x30 Size: 0x66d0
	    class USocialStyleDataAsset* OverrideStyle; // 0x6700 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSocialStyle");
			return (class UClass*)ptr;
		};

};

class UFortSocialUserListEntry : public USocialUserListEntry
{
	public:
	    class UImage* Image_PlatformIcon; // 0xb50 Size: 0x8
	    class UFortPlayerBanner* PlayerBanner; // 0xb58 Size: 0x8
	    class UDynamicEntryBox* EntryBox_PartySlots; // 0xb60 Size: 0x8
	    char UnknownData0[0xb68]; // 0xb68
	    bool IsPlatformOnlyFriend(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7479];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSocialUserListEntry");
			return (class UClass*)ptr;
		};

};

class UFortSpectatedPlayerSwitcher : public UUserWidget
{
	public:
	    int MaxPlayersToShow; // 0x228 Size: 0x4
	    char UnknownData0[0x4]; // 0x22c
	    TArray<struct FPotentialSpectatorTarget> DisplayedTargets; // 0x230 Size: 0x10
	    TArray<struct FPotentialSpectatorTarget> AvailableTargets; // 0x240 Size: 0x10
	    char UnknownData1[0x250]; // 0x250
	    bool ShouldBeVisible(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnDisplayedTargetsUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSpectatedPlayerSwitcher");
			return (class UClass*)ptr;
		};

};

class UFortSplashScreenWidget : public UCommonActivatablePanel
{
	public:
	    char UnknownData0[0x328];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSplashScreenWidget");
			return (class UClass*)ptr;
		};

};

class UFortSquadIcon : public UCommonUserWidget
{
	public:
	    FName Name; // 0x230 Size: 0x8
	    char ImageSize; // 0x238 Size: 0x1
	    char UnknownData0[0x7]; // 0x239
	    class UImage* Icon; // 0x240 Size: 0x8
	    char UnknownData1[0x248]; // 0x248
	    void SetSquad(FName InName); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HandleDifferentSquadSetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSquadIcon");
			return (class UClass*)ptr;
		};

};

class UFortSquadLandingPageDefenderSquadDetails : public UCommonUserWidget
{
	public:
	    class UCommonTextBlock* OutpostName; // 0x230 Size: 0x8
	    class UCommonNumericTextBlock* PowerRating; // 0x238 Size: 0x8
	    char UnknownData0[0x240]; // 0x240
	    void SetDefenderSquadInfo(struct FFortLandingPageDefenderSummaryInfo DefenderSummaryInfo); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void HandleDefenderSquadInfoSetBP(struct FFortLandingPageDefenderSummaryInfo DefenderSummaryInfo); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HandleAddDefenderSquadMemberBP(FName SquadId, int Index); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7da1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSquadLandingPageDefenderSquadDetails");
			return (class UClass*)ptr;
		};

};

class UFortSquadLandingPageDefenderSquadDetailsLocked : public UCommonUserWidget
{
	public:
	    class UCommonTextBlock* OutpostName; // 0x230 Size: 0x8
	    char UnknownData0[0x238]; // 0x238
	    void SetDefenderSquadInfo(struct FFortLandingPageDefenderSummaryInfo DefenderSummaryInfo); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7da9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSquadLandingPageDefenderSquadDetailsLocked");
			return (class UClass*)ptr;
		};

};

class UFortSquadLandingPageDefenderSummary : public UCommonUserWidget
{
	public:
	    void HandleClearDefenderSquadDetailsBP(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void HandleAddLockedDefenderSquadDetailsBP(struct FFortLandingPageDefenderSummaryInfo DefenderSummaryInfo); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void HandleAddDefenderSquadDetailsBP(struct FFortLandingPageDefenderSummaryInfo DefenderSummaryInfo); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7da9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSquadLandingPageDefenderSummary");
			return (class UClass*)ptr;
		};

};

class UFortSquadLandingPageSurvivorSummary : public UCommonUserWidget
{
	public:
	    class UFortSquadStatValueWithIcon* FortitudeStatValue; // 0x230 Size: 0x8
	    class UFortSquadStatValueWithIcon* OffenseStatValue; // 0x238 Size: 0x8
	    class UFortSquadStatValueWithIcon* ResistanceStatValue; // 0x240 Size: 0x8
	    class UFortSquadStatValueWithIcon* TechStatValue; // 0x248 Size: 0x8
	    char UnknownData0[0x250]; // 0x250
	    void HandleClearSetBonusSummaryLineItemsBP(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void HandleAddSetBonusSummaryLineItemBP(struct FFortAttributeModifierAccumulation AttributeModifierAccumulation); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSquadLandingPageSurvivorSummary");
			return (class UClass*)ptr;
		};

};

class UFortSquadManagementItemViewContextBase : public UObject
{
	public:
	    char UnknownData0[0xf8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSquadManagementItemViewContextBase");
			return (class UClass*)ptr;
		};

};

class UFortItemViewContext_SquadSlotsView : public UFortSquadManagementItemViewContextBase
{
	public:
	    char UnknownData0[0x100];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemViewContext_SquadSlotsView");
			return (class UClass*)ptr;
		};

};

class UFortItemViewContext_SquadSlotItemPicker : public UFortSquadManagementItemViewContextBase
{
	public:
	    char UnknownData0[0x108];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemViewContext_SquadSlotItemPicker");
			return (class UClass*)ptr;
		};

};

class UFortItemViewContext_ExpeditionSquadSlotsView : public UFortItemViewContext_SquadSlotsView
{
	public:
	    char UnknownData0[0x108];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemViewContext_ExpeditionSquadSlotsView");
			return (class UClass*)ptr;
		};

};

class UFortItemViewContext_ExpeditionSquadSlotItemPicker : public UFortItemViewContext_SquadSlotItemPicker
{
	public:
	    char UnknownData0[0x110];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortItemViewContext_ExpeditionSquadSlotItemPicker");
			return (class UClass*)ptr;
		};

};

class UFortSquadSlotDetailsPanel : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x28];
	    class UFortSquadSlotItemDetailsHostPanel* ItemDetailsPanel; // 0x258 Size: 0x8
	    __int64/*InterfaceProperty*/ ItemViewContext; // 0x260 Size: 0x10
	    char UnknownData1[0x270]; // 0x270
	    bool TryGetItemToPreviewInSlot(class UFortItem* OutItemToPreviewInSlot); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetScrollWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetIdOfSquadSlotToManageBP(FName SquadId, int SquadSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool IsSquadSlotLockedBP(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleSquadSlotStateChangedBP(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void HandleSquadSlotRestrictionFactorsChangedBP(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void HandleDifferentSquadSlotSetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    TArray<EFortSquadSlottingRestrictionReason> GetSlottingRestrictionReasons(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    class UFortItem* GetItemInSquadSlotBP(class ULocalPlayer* LocalPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void GetIdOfSquadSlotToManageBP(FName OutSquadId, int OutSquadSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x-7d51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSquadSlotDetailsPanel");
			return (class UClass*)ptr;
		};

};

class UFortSquadSlotItemDetailElementWidget : public UFortItemDetailElementWidget
{
	public:
	    void SetIdOfSquadSlotToManageBP(FName SquadId, int SquadSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    bool IsSquadSlotLockedBP(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void HandlePostDifferentSquadSlotSetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    class UFortItem* GetItemInSquadSlotBP(class ULocalPlayer* LocalPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void GetIdOfSquadSlotToManageBP(FName OutSquadId, int OutSquadSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7d41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSquadSlotItemDetailElementWidget");
			return (class UClass*)ptr;
		};

};

class UFortSquadSlotItemDetailsHostPanel : public UFortItemDetailsHostPanel
{
	public:
	    void SetIdOfSquadSlotToManageBP(FName SquadId, int SquadSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    bool IsSquadSlotLockedBP(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    class UFortItem* GetItemInSquadSlotBP(class ULocalPlayer* LocalPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void GetIdOfSquadSlotToManageBP(FName OutSquadId, int OutSquadSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d21];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSquadSlotItemDetailsHostPanel");
			return (class UClass*)ptr;
		};

};

class UFortSquadSlotItemPicker : public UFortItemPickerBase
{
	public:
	    char UnknownData0[0x40];
	    MulticastDelegateProperty OnSortChanged; // 0x328 Size: 0x10
	    char UnknownData1[0x338]; // 0x338
	    void SetSortTypes(struct FSquadSlotSortTypes SquadSlotSortTypes); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetIdOfSquadSlotToManageBP(FName SquadId, int SquadSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void GetIdOfSquadSlotToManageBP(FName OutSquadId, int OutSquadSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ FortSquadSlotSortChanged__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void CycleSortType(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7c29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSquadSlotItemPicker");
			return (class UClass*)ptr;
		};

};

class UFortSquadSlotItemPickerTileButton : public UFortItemPickerButton
{
	public:
	    void HandleSlottingRestrictionReasonsChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void HandleItemSlottedToDifferentSquad(struct FHomebaseSquadSlotId SquadSlotId); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    TArray<EFortSquadSlottingRestrictionReason> GetSlottingRestrictionReasons(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7471];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSquadSlotItemPickerTileButton");
			return (class UClass*)ptr;
		};

};

class UFortSquadSlotSelectorPopupMenu : public UFortPopupMenu
{
	public:
	    class UFortSquadSlotSelectorButton* GetHostButton(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7ca9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSquadSlotSelectorPopupMenu");
			return (class UClass*)ptr;
		};

};

class UFortSquadSlotSurvivorTraitMatchesDetailWidget : public UFortSquadSlotItemDetailElementWidget
{
	public:
	    bool IsSquadLeaderSlot; // 0x2a0 Size: 0x1
	    bool LeaderMatchesSquadType; // 0x2a1 Size: 0x1
	    char UnknownData0[0x2]; // 0x2a2
	    int SubordinatePersonalityMatchCount; // 0x2a4 Size: 0x4
	    bool MatchesLeaderPersonality; // 0x2a8 Size: 0x1
	    char UnknownData1[0x3]; // 0x2a9
	    int MatchingSetBonusCount; // 0x2ac Size: 0x4
	    int SetBonusSize; // 0x2b0 Size: 0x4
	    char UnknownData2[0x2b4]; // 0x2b4
	    void HandleTraitValuesUpdatedBP(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d19];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSquadSlotSurvivorTraitMatchesDetailWidget");
			return (class UClass*)ptr;
		};

};

class UFortSquadSlotSelectorButton : public UCommonButton
{
	public:
	    char UnknownData0[0x28];
	    MulticastDelegateProperty OnRequestOpenSquadSlotEvent; // 0xb50 Size: 0x10
	    MulticastDelegateProperty OnRequestViewInAllEvent; // 0xb60 Size: 0x10
	    class UFortSquadSlotWidget* SquadSlotWidget; // 0xb70 Size: 0x8
	    class UMenuAnchor* PopupMenuAnchor; // 0xb78 Size: 0x8
	    __int64/*InterfaceProperty*/ ItemViewContext; // 0xb80 Size: 0x10
	    char UnknownData1[0xb90]; // 0xb90
	    void ViewInAll(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SquadSlotWidgetUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetIdOfSquadSlotToManageBP(FName SquadId, int SquadSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OpenSquadSlot(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool IsSquadSlotLockedBP(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void HandlePreDifferentSquadSlotSetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void HandlePostDifferentSquadSlotSetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    class UWidget* GetPopupMenu(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool GetInPreviewMode(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void GetIdOfSquadSlotToManageBP(FName OutSquadId, int OutSquadSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x-7439];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSquadSlotSelectorButton");
			return (class UClass*)ptr;
		};

};

class UFortSquadSlotsView : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x10];
	    MulticastDelegateProperty OnDifferentSquadSlotSelectedEvent; // 0x240 Size: 0x10
	    MulticastDelegateProperty OnRequestOpenSquadSlotEvent; // 0x250 Size: 0x10
	    MulticastDelegateProperty OnRequestViewInAllEvent; // 0x260 Size: 0x10
	    int IndexOfSelectedSquadSlot; // 0x270 Size: 0x4
	    bool bSlotButtonsRequireSelection; // 0x274 Size: 0x1
	    bool bInPreviewMode; // 0x275 Size: 0x1
	    char UnknownData1[0x2]; // 0x276
	    __int64/*MapProperty*/ SquadSlotSortTypesMap; // 0x278 Size: 0x50
	    class UFortDisableAutoSlottingPromptAction* DisableAutoSlottingToOpenSquadSlotPromptAction; // 0x2c8 Size: 0x8
	    class UFortCommittableButtonGroup* SquadSlotButtonGroup; // 0x2d0 Size: 0x8
	    char UnknownData2[0x30]; // 0x2d8
	    __int64/*InterfaceProperty*/ ItemViewContext; // 0x308 Size: 0x10
	    char UnknownData3[0x318]; // 0x318
	    bool TryGetStaticSquadDataBP(struct FHomebaseSquad OutSquadData); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool TryGetSelectedSquadSlotSortTypes(struct FSquadSlotSortTypes OutSlotSortTypes); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetIsSelectionLocked(bool ShouldSelectionBeLocked); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetInPreviewMode(bool bPreview); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetIdOfSquadToManageBP(FName SquadId); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SelectSlot(int SquadSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnDifferentSquadSlotSelected__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void HandleSelectedButtonChanged(class UCommonButton* SelectedButton, int ButtonIndex); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void HandleRequestViewInAll(int SquadSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void HandleRequestOpenSquadSlot(int SquadSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void HandleHoveredButtonChanged(class UCommonButton* HoveredButton, int ButtonIndex); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void HandleButtonDoubleClicked(class UCommonButton* CommittedButton, int ButtonIndex); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void HandleButtonClicked(class UCommonButton* CommittedButton, int ButtonIndex); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    int GetIndexOfSelectedSquadSlot(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    FName GetIdOfSquadToManageBP(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    class UFortSquadSlotSelectorButton* CreateAndAddSquadSlotButton(int SquadSlotIndex, struct FHomebaseSquadSlot SquadSlotDefinition, class UWidget* OutSquadSlotButtonHost); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x-7cc1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSquadSlotsView");
			return (class UClass*)ptr;
		};

};

class UFortSquadSlotWidget : public UWidget
{
	public:
	    char UnknownData0[0x28];
	    EFortItemCardSize ItemCardSize; // 0x128 Size: 0x1
	    char UnknownData1[0x3f]; // 0x129
	    class UFortMultiSizeItemCard* SlottedItemCard; // 0x168 Size: 0x8
	    char UnknownData2[0x8]; // 0x170
	    __int64/*InterfaceProperty*/ ItemViewContext; // 0x178 Size: 0x10
	    char UnknownData3[0x188]; // 0x188
	    void SetIdOfSquadSlotToManageBP(FName SquadId, int SquadSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetCardSize(EFortItemCardSize CardSize); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool IsSquadSlotLockedBP(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    class UFortItem* GetItemInSquadSlotBP(class ULocalPlayer* LocalPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void GetIdOfSquadSlotToManageBP(FName OutSquadId, int OutSquadSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7e49];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSquadSlotWidget");
			return (class UClass*)ptr;
		};

};

class UFortSquadStatsWidgetBase : public UCommonUserWidget
{
	public:
	    TArray<class UFortAttributeListItem_NUI*> OverviewStats; // 0x230 Size: 0x10
	    class UFortAttributeList_NUI* DetailedStats; // 0x240 Size: 0x8
	    char UnknownData0[0x248]; // 0x248
	    void RequestStatsUpdate(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void RequestShowPreviewStats(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HandleSquadSlottingPreviewStateChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    struct FUniqueNetIdRepl GetLocalPlayerId(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7d79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSquadStatsWidgetBase");
			return (class UClass*)ptr;
		};

};

class UFortSquadStatValueWithIcon : public UCommonUserWidget
{
	public:
	    struct FGameplayAttribute Attribute; // 0x230 Size: 0x20
	    struct FGameplayAttribute TeamAttribute; // 0x250 Size: 0x20
	    char ImageSize; // 0x270 Size: 0x1
	    char UnknownData0[0x7]; // 0x271
	    class UCommonNumericTextBlock* Value; // 0x278 Size: 0x8
	    class UImage* Icon; // 0x280 Size: 0x8
	    char UnknownData1[0x288]; // 0x288
	    void HandleDifferentAttributeSetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSquadStatValueWithIcon");
			return (class UClass*)ptr;
		};

};

class UFortSquadTypeLandingPageBase : public UFortActivatablePanel
{
	public:
	    EFortHomebaseSquadType SquadType; // 0x340 Size: 0x1
	    char UnknownData0[0x7]; // 0x341
	    struct FDataTableRowHandle BackInputActionRowHandle; // 0x348 Size: 0x10
	    EFortFrontendInventoryFilter ItemManagementScreenFilter; // 0x358 Size: 0x1
	    char UnknownData1[0x7]; // 0x359
	    TArray<TWeakObjectPtr<UFortSquadSelectorButton*>> SquadSelectorButtons; // 0x360 Size: 0x10
	    char UnknownData2[0x370]; // 0x370
	    void HandlePendingNavigationOp(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleBackInputAction(bool bPassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    class UFortSquadSelectorButton* CreateAndAddSquadButton(FName SquadId); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7c71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSquadTypeLandingPageBase");
			return (class UClass*)ptr;
		};

};

class UFortStandardGlobalActionDetailsDataSource : public UObject
{
	public:
	    char UnknownData0[0x8];
	    class UFortGlobalUIContext* GlobalUIContext; // 0x30 Size: 0x8
	    class UCommonInputSubsystem* CommonInputSubsystem; // 0x38 Size: 0x8
	    class AFortPlayerController* FortPlayerController; // 0x40 Size: 0x8
	    char UnknownData1[0x12]; // 0x48
	    struct FFortGlobalActionDetailsFunctionContext ActionDetailsContext; // 0x5a Size: 0x1
	    char UnknownData2[0x5b]; // 0x5b
	    void SetGlobalUIContext(class UFortGlobalUIContext* Value); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetGlobalAction(EFortGlobalAction Value); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetCommonInputSubsystem(class UCommonInputSubsystem* Value); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetActionDetailsContext(struct FFortGlobalActionDetailsFunctionContext Value); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void HandlePlayerControllerChanged(class UObject* Source); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ FortNameDataSourceOnChangeInternalDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static class UFortStandardGlobalActionDetailsDataSource* ConstructWithDefaultContexts(class UObject* Outer, class UWidget* ContextWidget, EFortGlobalAction GlobalAction, struct FFortGlobalActionDetailsFunctionContext ActionDetailsContext); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static class UFortStandardGlobalActionDetailsDataSource* Construct(class UObject* Outer, class UFortGlobalUIContext* GlobalUIContext, class UCommonInputSubsystem* CommonInputSubsystem, EFortGlobalAction GlobalAction, struct FFortGlobalActionDetailsFunctionContext ActionDetailsContext); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7f71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortStandardGlobalActionDetailsDataSource");
			return (class UClass*)ptr;
		};

};

class UFortStatIcon : public UCommonUserWidget
{
	public:
	    struct FGameplayAttribute Attribute; // 0x230 Size: 0x20
	    char ImageSize; // 0x250 Size: 0x1
	    char UnknownData0[0x7]; // 0x251
	    class UImage* Icon; // 0x258 Size: 0x8
	    char UnknownData1[0x260]; // 0x260
	    void SetAttribute(struct FGameplayAttribute InAttribute); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HandleDifferentAttributeSetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortStatIcon");
			return (class UClass*)ptr;
		};

};

class UFortStatsOverviewDetailsBase : public UCommonUserWidget
{
	public:
	    TArray<class UFortAttributeListItem_NUI*> OverviewStats; // 0x230 Size: 0x10
	    class UFortAttributeList_NUI* DetailedStats; // 0x240 Size: 0x8
	    char UnknownData0[0x248]; // 0x248
	    void RequestStatsUpdate(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void ListenForChanges(bool bListen); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    struct FUniqueNetIdRepl GetLocalPlayerId(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortStatsOverviewDetailsBase");
			return (class UClass*)ptr;
		};

};

class UFortStoreContext : public UBlueprintContextBase
{
	public:
	    char UnknownData0[0x8];
	    MulticastDelegateProperty OnCardPackOffersChanged; // 0x30 Size: 0x10
	    MulticastDelegateProperty OnStorePurchaseCompleted; // 0x40 Size: 0x10
	    MulticastDelegateProperty OnStoreStateChange; // 0x50 Size: 0x10
	    TArray<struct FCardPackOffer> Offers; // 0x60 Size: 0x10
	    struct FDateTime NextStoreRefresh; // 0x70 Size: 0x8
	    TArray<struct FCard> CardList; // 0x78 Size: 0x10
	    int CardIndex; // 0x88 Size: 0x4
	    char UnknownData1[0x4]; // 0x8c
	    struct FOpenedCardPack OpenedCardPack; // 0x90 Size: 0x10
	    EFortRarity LastCardRarity; // 0xa0 Size: 0x1
	    char UnknownData2[0x7]; // 0xa1
	    TArray<struct FCard> PurchasedItemList; // 0xa8 Size: 0x10
	    TArray<class UFortCardPackItem*> PurchasedCardPacks; // 0xb8 Size: 0x10
	    char UnknownData3[0x38]; // 0xc8
	    TArray<struct FSoftObjectPath> MissingAssetsAttemptedAsyncLoad; // 0x100 Size: 0x10
	    char UnknownData4[0x110]; // 0x110
	    void UserViewedAthenaItemShop(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool StoreHasStarsForSale(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void RealMoneyPurchaseStart(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void RealMoneyPurchaseFinished(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool PurchaseOpeningComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool OpenWebPayment(struct FString AttemptedMTXOfferId); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    ECardPackPurchaseError MakePurchase(struct FCardPackOffer Offer, int Quantity); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    bool MakeChoice(int ChoiceIdx); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    bool IsWaitingForMcp(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    bool IsOpeningOnePack(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    bool IsOpeningDirectPack(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    struct FTimespan GetTimeUntilMarketplaceRefresh(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    struct FTimespan GetTimeUntilDailyLimitReset(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    EFortStoreState GetStoreState(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    struct FLinearColor GetRarityColor(EFortRarity Rarity); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    EFortStoreState GetPreviousState(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    int GetOwnedItemCount(class UFortItemDefinition* ItemDefinition); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    int GetNumUnopenedCardPacksRemaining(class UFortCardPackItemDefinition* PackType, bool bCountChoicePacks); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    bool GetCard(int CardIdx, struct FCard ResultOut); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void GetAccountItems(TArray<class UFortAccountItemDefinition*> AccountItemDefinitions, TArray<class UFortAccountItem*> AccountItems); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void FreshenCache(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void FireInteractionAnalyticsEvent(struct FString Interaction, struct FString Details); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    bool ExitWebPayment(); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    bool ExitSummary(); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void ExitRealMoneyStore(); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    bool ExitCurrencyStore(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    bool ExitCardPackStore(); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    bool ErrorOccurred(struct FString ErrorAnalytics); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    void EnterRealMoneyStore(); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    bool EnterCurrencyStore(struct FString AttemptedPurchaseCardPackId); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    bool EnterCardPackStore(); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    void DismissError(); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    bool ChoiceResultComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    bool CardPackOpeningComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    bool CardPackDestroyComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    bool CardFrontRevealComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    bool CardFlipComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    bool CardExitComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    bool CardEntryComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    bool CardBackRevealComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    bool CardAddedToSummaryComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    void AttemptOpenSinglePack(); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    void AttemptOpenPackByIndex(int CardPackIndex); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    void AttemptOpenAllPacks(); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x-7ed1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortStoreContext");
			return (class UClass*)ptr;
		};

};

class UFortStorefront : public UFortUserWidget
{
	public:
	    char UnknownData0[0x238];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortStorefront");
			return (class UClass*)ptr;
		};

};

class UFortStoreFrontOfferDetailsWidgetBase : public UFortActivatablePanelWithItemPreview
{
	public:
	    char UnknownData0[0x10];
	    struct FDataTableRowHandle EnterViewModeInputActionRowHandle; // 0x448 Size: 0x10
	    bool IsInItemViewMode; // 0x458 Size: 0x1
	    bool ShouldAllowItemViewModeAction; // 0x459 Size: 0x1
	    char UnknownData1[0x6]; // 0x45a
	    TArray<class UFortStoreFrontOfferInfo*> PagedItems; // 0x460 Size: 0x10
	    class UFortStoreFrontOfferInfo* OfferData; // 0x470 Size: 0x8
	    class UFortVariantPicker* Picker_VariantSelector; // 0x478 Size: 0x8
	    char UnknownData2[0x480]; // 0x480
	    void UpdateItemViewModeBP(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool ShouldHavePurchaseConfirmation(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetupOffer(class UFortStoreFrontOfferInfo* InOfferData); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetShouldAllowItemViewModeAction(bool Value); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetPagedItems(TArray<class UFortStoreFrontOfferInfo*> InPagedItems); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetIsInItemViewMode(bool Value); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SendShopInteractionAnalytic(struct FString Interaction); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void RequestExternalPurchase(int Quantity); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void PurchaseAmountRight(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void PurchaseAmountLeft(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void OnUpdateStatus(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void OnOfferSet(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void OnEnterViewModeActionCommitted(bool PassThrough); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void HandleCurrentlyViewedAccountInfoChanged(struct FFortPublicAccountInfo NewInfo); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    class UFortStoreFrontOfferInfo* GetOfferInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    bool CanAutoEquip(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void AutoEquip(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x-7b51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortStoreFrontOfferDetailsWidgetBase");
			return (class UClass*)ptr;
		};

};

class UFortStoreRootBase : public UCommonActivatablePanel
{
	public:
	    void PopulatePrerollOffers(__int64/*DelegateProperty*/ Callback); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void OnUpdateOtherPlatformMTXMessage(bool HasOtherPlatformCurrency, struct FText CurrencyMessageLocText); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnAffiliateUpdated(struct FString AffiliateName); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7cc1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortStoreRootBase");
			return (class UClass*)ptr;
		};

};

class UStoreCardObject : public UObject
{
	public:
	    struct FCard Card; // 0x28 Size: 0x18

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.StoreCardObject");
			return (class UClass*)ptr;
		};

};

class UFortStoreSummary : public UCommonActivatablePanel
{
	public:
	    char UnknownData0[0x8];
	    TArray<class UStoreCardObject*> StoreCardObjects; // 0x320 Size: 0x10
	    class UCommonTileView* TileView; // 0x330 Size: 0x8
	    class UFortMulchConfirmationModalWidget* MulchConfirmationModalClass; // 0x338 Size: 0x8
	    char UnknownData1[0x18]; // 0x340
	    class UFortMulchConfirmationModalWidget* MulchConfirmationModal; // 0x358 Size: 0x8
	    char UnknownData2[0x360]; // 0x360
	    void ShowMulchConfirmationModal(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetCards(TArray<struct FCard> Cards); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void NotifyPanelDeactivated(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void NotifyPanelActivated(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void HideMulchConfirmationModal(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void HandleContextMenuOpenChangedBP(bool bIsOpen); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void HandleContextMenuOpenChanged(bool bIsOpen); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void FinalizeFavoriteStatus(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void CloseSummaryScreen(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x-7c81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortStoreSummary");
			return (class UClass*)ptr;
		};

};

class UFortStoreSummaryItemButton : public UCommonButton
{
	public:
	    bool HasAnItemMarkedForMulching; // 0xb28 Size: 0x1
	    char UnknownData0[0x2f]; // 0xb29
	    class UMenuAnchor* PopupMenuAnchor; // 0xb58 Size: 0x8
	    class UStoreCardObject* StoreCardObject; // 0xb60 Size: 0x8
	    class UFortInventoryContext* InventoryContext; // 0xb68 Size: 0x8
	    char UnknownData1[0xb70]; // 0xb70
	    void UpdateMulchListWithItem(bool bAddingItem); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetStoreCardObject(class UStoreCardObject* CardObject); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleMenuOpenChanged(bool bIsOpen); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleItemMulchStateChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    class UStoreCardObject* GetStoreCardObject(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    class UWidget* GetPopupMenu(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7469];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortStoreSummaryItemButton");
			return (class UClass*)ptr;
		};

};

class UFortStoreSummaryItemPopupMenu : public UFortPopupMenu
{
	public:
	    void MulchItem(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void HandleItemChanged(bool bItemChanged, bool bAmmoChanged, bool bIngredientsChanged); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    class UFortStoreSummaryItemButton* GetHostButton(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7ca1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortStoreSummaryItemPopupMenu");
			return (class UClass*)ptr;
		};

};

class UFortSubGameSelectBase : public UCommonActivatablePanel
{
	public:
	    void ShowRedeemCodeScreen(ESubGame SubGame, __int64/*DelegateProperty*/ CompletionDelegate); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void OnSubGameImageLoadedFromCMS(EFortSubgameSelectOption SubGameOption, class UTexture2D* Image); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool IsSubGameOptionVisible(EFortSubgameSelectOption SubGameOption); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void GetUpsellStorefrontNames(ESubGame SubGame, TArray<struct FString> OutStorefrontNames); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    ESubGame GetSubGameBySubGameSelectOption(EFortSubgameSelectOption SubGameOption); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool GetShortDescription(EFortSubgameSelectOption SubGameOption, struct FText ShortDescription); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool GetIsOnSale(EFortSubgameSelectOption SubGameOption); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool GetFullDescription(EFortSubgameSelectOption SubGameOption, struct FText FullDescription); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool CheckRewardRate(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7cc9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSubGameSelectBase");
			return (class UClass*)ptr;
		};

};

class UFortSupportCenter : public UCommonActivatablePanel
{
	public:
	    class UCommonButton* Button_OnlineSupport; // 0x318 Size: 0x8
	    class UCommonButton* Button_Forums; // 0x320 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSupportCenter");
			return (class UClass*)ptr;
		};

};

class UFortSurvivorSquadManagementScreen : public UFortSquadManagementScreenBase
{
	public:
	    class UFortSurvivorSquadStatMatchesBase* StatMatchesWidget; // 0x458 Size: 0x8
	    char UnknownData0[0x460]; // 0x460
	    void UpdateCycleButtons(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void ShowHelpDialog(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void PlayFeedbackForSlottingPerson(class UFortWorker* Worker, int SlotIndex, struct FFortSurvivorSquadSlottingFeedbackData FeedbackData); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7aa9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSurvivorSquadManagementScreen");
			return (class UClass*)ptr;
		};

};

class UFortSurvivorSquadSelectorButton : public UFortSquadSelectorButton
{
	public:
	    TArray<struct FGameplayAttribute> FortStatAttributes; // 0xb48 Size: 0x10
	    TArray<struct FGameplayAttribute> FortTeamStatAttributes; // 0xb58 Size: 0x10
	    char UnknownData0[0xb68]; // 0xb68
	    bool TryGetSummaryStats(struct FFortSurvivorSquadSelectorButtonSummaryStats OutSummaryStats); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool TryGetSquadMembers(TArray<class UFortWorker*> OutSquadMembers); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool TryGetPersonalityMatches(struct FFortSurvivorSquadSelectorButtonPersonalityMatches OutPersonalityMatches); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7479];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSurvivorSquadSelectorButton");
			return (class UClass*)ptr;
		};

};

class UFortSurvivorSquadStatMatchBase : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x8];
	    struct FFortUISurvivorSquadStatMatch StatMatch; // 0x238 Size: 0x370
	    char UnknownData1[0x5a8]; // 0x5a8
	    void OnStatMatchUpdated(struct FFortUISurvivorSquadStatMatch UpdatedMatch); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7a39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSurvivorSquadStatMatchBase");
			return (class UClass*)ptr;
		};

};

class UFortSurvivorSquadStatMatchesBase : public UFortSquadStatDetailsWidget
{
	public:
	    class UFortSurvivorSquadStatMatchBase* StatMatchClass; // 0x260 Size: 0x8
	    bool bSummaryView; // 0x268 Size: 0x1
	    char UnknownData0[0x7]; // 0x269
	    TArray<class UFortSurvivorSquadStatMatchBase*> StatMatches; // 0x270 Size: 0x10
	    char UnknownData1[0x280]; // 0x280
	    bool TryGetStaticSquadDataBP(struct FHomebaseSquad OutSquadData); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetSummaryView(bool bInSummaryView); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetIdOfSquadToManageBP(FName SquadId); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleDifferentSquadSetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    FName GetIdOfSquadToManageBP(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void AddStatMatch(class UFortSurvivorSquadStatMatchBase* SetBonus); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7d51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSurvivorSquadStatMatchesBase");
			return (class UClass*)ptr;
		};

};

class UFortSurvivorSquadSummaryStatItem : public UCommonUserWidget
{
	public:
	    char ImageSize; // 0x230 Size: 0x1
	    char UnknownData0[0x7]; // 0x231
	    class UImage* Icon; // 0x238 Size: 0x8
	    class UCommonTextBlock* Value; // 0x240 Size: 0x8
	    class UCommonTextBlock* Name; // 0x248 Size: 0x8
	    char UnknownData1[0x250]; // 0x250
	    void SetAttributeModifierAccumulation(struct FFortAttributeModifierAccumulation Accumulation); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSurvivorSquadSummaryStatItem");
			return (class UClass*)ptr;
		};

};

class UFortSwipePanel : public UContentWidget
{
	public:
	    struct FFortSwipeDetector SwipeDetector; // 0x118 Size: 0x70
	    bool bBeginSwipeOnPointerEnter; // 0x188 Size: 0x1
	    bool bConsumePointerInput; // 0x189 Size: 0x1
	    char UnknownData0[0x6]; // 0x18a
	    MulticastDelegateProperty OnSwipeLeft; // 0x190 Size: 0x10
	    MulticastDelegateProperty OnSwipeRight; // 0x1a0 Size: 0x10
	    MulticastDelegateProperty OnSwipeUp; // 0x1b0 Size: 0x10
	    MulticastDelegateProperty OnSwipeDown; // 0x1c0 Size: 0x10
	    char UnknownData1[0x1d0]; // 0x1d0
	    void SwipeUp(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SwipeRight(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SwipeLeft(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SwipeDown(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void GetSwipeInfo(int OutIndex, struct FVector2D OutSwipePercentage); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7df9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSwipePanel");
			return (class UClass*)ptr;
		};

};

class UFortSwipePanelSlot : public UPanelSlot
{
	public:
	    char UnknownData0[0x48];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSwipePanelSlot");
			return (class UClass*)ptr;
		};

};

class UFortSZAwareImage : public UImage
{
	public:
	    bool AnchorLeft; // 0x200 Size: 0x1
	    bool AnchorRight; // 0x201 Size: 0x1
	    bool AnchorTop; // 0x202 Size: 0x1
	    bool AnchorBottom; // 0x203 Size: 0x1
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSZAwareImage");
			return (class UClass*)ptr;
		};

};

class UFortTabButtonInterface : public UInterface
{
	public:
	    void SetTabLabelInfo(struct FFortTabButtonLabelInfo TabLabelInfo); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTabButtonInterface");
			return (class UClass*)ptr;
		};

};

class UFortTabListWidgetBase : public UCommonTabListWidget
{
	public:
	    MulticastDelegateProperty OnTabContentCreated; // 0x2f8 Size: 0x10
	    TArray<struct FFortTabListRegistrationInfo> PreregisteredTabInfoArray; // 0x308 Size: 0x10
	    __int64/*MapProperty*/ PendingTabLabelInfoMap; // 0x318 Size: 0x50
	    char UnknownData0[0x368]; // 0x368
	    void SetTabHiddenState(FName TabNameID, bool bHidden); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetPreviousTabInputActionData(struct FDataTableRowHandle PreviousData); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetNextTabInputActionData(struct FDataTableRowHandle NextData); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool RegisterFortTab(FName TabNameID, class UCommonButton* TabButtonType, struct FFortTabButtonLabelInfo LabelInfo, class UWidget* ContentWidget); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void RegisterAllPreregisteredTabInfos(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnTabContentCreated__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool IsLastTabActive(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool IsFirstTabActive(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    int GetVisibleTabCount(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool GetPreregisteredTabInfo(FName TabNameID, struct FFortTabListRegistrationInfo OutTabInfo); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7c79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTabListWidgetBase");
			return (class UClass*)ptr;
		};

};

class UFortTeamMemberXPBoostInfo : public UFortTeamMemberEntryBase
{
	public:
	    class UPanelWidget* Panel_BattlePassOwnerInfo; // 0x240 Size: 0x8
	    class UTextBlock* Text_BattlePassSelfXPBoost; // 0x248 Size: 0x8
	    class UTextBlock* Text_EventXPBoost; // 0x250 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTeamMemberXPBoostInfo");
			return (class UClass*)ptr;
		};

};

class AFortTeamMemberPedestal : public AFortItemPlacementActor
{
	public:
	    char UnknownData0[0x30];
	    TArray<struct FCachedComponentMaterials> CachedComponentMaterials; // 0x3a8 Size: 0x10
	    int AssignedMemberIndex; // 0x3b8 Size: 0x4
	    char UnknownData1[0x4]; // 0x3bc
	    class UWidgetComponent* WidgetComponent_MemberInfo; // 0x3c0 Size: 0x8
	    class UWidgetComponent* WidgetComponent_FillOpenSlot; // 0x3c8 Size: 0x8
	    class UWidgetComponent* WidgetComponent_EquippedGadgets; // 0x3d0 Size: 0x8
	    class UWidgetComponent* WidgetComponent_BattlePassInfo; // 0x3d8 Size: 0x8
	    char UnknownData2[0x10]; // 0x3e0
	    class UFortHero* MemberHeroItem; // 0x3f0 Size: 0x8
	    char UnknownData3[0x3f8]; // 0x3f8
	    void RefreshBattlePassOwnerVisuals(bool bOwnsBattlePass); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnPedestalIsPopulatedChanged(bool bIsPopulated); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnIsCurrentlyInMatchChanged(bool bIsInMatch); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnConnectedToCampaignLobby(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool IsInFrontend(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void HandleContextSaysLobbyPlayerUnhovered(int HoveredMemberIdx); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void HandleContextSaysLobbyPlayerHovered(int HoveredMemberIdx); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void ClearOverrideMaterial(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void ApplyUniformOverrideMaterial(class UMaterialInterface* OverrideMaterial); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7be1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTeamMemberPedestal");
			return (class UClass*)ptr;
		};

};

class UFortTeamMemberPedestalNameplate : public UFortBasicTeamMemberEntry
{
	public:
	    char UnknownData0[0x20];
	    class UCommonTextBlock* Text_ReadyStatus; // 0x288 Size: 0x8
	    class UMatchmakingInputIndicatorBase* InputIndicator_ActiveInputType; // 0x290 Size: 0x8
	    class UFortPlayerTrackerBase* PlayerTracker_CampaignPower; // 0x298 Size: 0x8
	    char UnknownData1[0x2a0]; // 0x2a0
	    void OnReadyStatusChanged(bool bIsReadyForMatchmaking); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnPedestalSelectedChanged(bool bIsSelected); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTeamMemberPedestalNameplate");
			return (class UClass*)ptr;
		};

};

class UFortTextStyleList : public UCommonUserWidget
{
	public:
	    FName TextStylesPath; // 0x230 Size: 0x8
	    char UnknownData0[0x238]; // 0x238
	    TArray<__int64/*SoftClassProperty*/> GetTextStyles(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7da9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTextStyleList");
			return (class UClass*)ptr;
		};

};

class UFortTheaterSelect : public UCommonActivatablePanel
{
	public:
	    char UnknownData0[0x10];
	    class UOverlay* OverlayMain; // 0x328 Size: 0x8
	    char UnknownData1[0x330]; // 0x330
	    void OnNavigationRight(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnNavigationLeft(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool GetTheaterRecommendedRatingRange(struct FString UniqueId, int Minimum, int Maximum); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool GetSurvivalCMSText(struct FText Title, struct FText Body); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7cb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTheaterSelect");
			return (class UClass*)ptr;
		};

};

class UFortTierIndicator : public UWidget
{
	public:
	    TWeakObjectPtr<UFortItem*> ItemToRepresent; // 0x100 Size: 0x8
	    char BrushSize; // 0x108 Size: 0x1
	    char UnknownData0[0x3]; // 0x109
	    float InterPipPadding; // 0x10c Size: 0x4
	    char UnknownData1[0x110]; // 0x110
	    void SetPreviewState(int TierIncrease); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetItemToRepresent(class UFortItem* ItemToRepresent); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetInterPipPadding(float InterPipPadding); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetBrushSize(char BrushSize); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ClearPreviewState(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7ec1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTierIndicator");
			return (class UClass*)ptr;
		};

};

class UFortTimelineBase : public UFortActivatablePanel
{
	public:
	    class UFortReplayContext* ReplayContext; // 0x340 Size: 0x8
	    char UnknownData0[0x348]; // 0x348
	    class UWidget* GetProgressBarWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void ClearTimelineMarkers(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void AddReplayEventToTimeline(EFortReplayEventType EventType, float RelativeTime); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7c99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTimelineBase");
			return (class UClass*)ptr;
		};

};

class UFortTimerTimespanDataSource : public UObject
{
	public:
	    __int64/*DelegateFunction*/ TimespanSourceDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void TickManually(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void StopTimer(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void StartTimer(float Delay, bool bTickImmediately); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetTimespanSource(__int64/*DelegateProperty*/ Value); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ FortTimespanDataSourceOnChangeInternalDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTimerTimespanDataSource");
			return (class UClass*)ptr;
		};

};

class UFortTimespanDataSource : public UInterface
{
	public:
	    void RemoveOnChangeDelegate(__int64/*DelegateProperty*/ InDelegate); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    struct FTimespan GetValue(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void AddOnChangeDelegate(__int64/*DelegateProperty*/ InDelegate); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTimespanDataSource");
			return (class UClass*)ptr;
		};

};

class UFortTooltipUIContext : public UBlueprintContextBase
{
	public:
	    bool HasTooltipStats(class UObject* Object); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    TArray<struct FFortDisplayAttribute> GetUpgradeStats(class UObject* Object, class UFortTooltipContext* TooltipContext); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool GetUIDataForTag(struct FGameplayTag Tag, struct FFortTagUIData OutData); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    TArray<struct FFortDisplayAttribute> GetTooltipStats(class UObject* Object, class UFortTooltipContext* TooltipContext); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool GetTooltipStat(class UObject* Object, class UFortTooltipContext* TooltipContext, struct FGameplayTag Token, struct FFortDisplayAttribute OutDisplayAttribute); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    TArray<struct FGameplayAttribute> GetTooltipAttributes(class UObject* Object); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool GetDisplayNameAndMultiBrushForTag(struct FGameplayTag Tag, struct FText OutDisplayName, struct FFortMultiSizeBrush OutBrush); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool GetDescription(class UObject* Object, class UFortTooltipContext* TooltipContext, TArray<struct FText> OutDescription); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    TArray<struct FFortDisplayAttribute> GetComparisonStats(class UObject* Object, class UObject* ComparisonObject, class UFortTooltipContext* TooltipContext); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool GetCombinedDescription(class UObject* Object, class UFortTooltipContext* TooltipContext, struct FText OutDescription); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTooltipUIContext");
			return (class UClass*)ptr;
		};

};

class UFortTopBarPanel : public UFortActivatablePanel
{
	public:
	    void SetOnlineFriendsCount(int NewOnlineFriendsCount); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void SetActiveInvitesCount(int NewActiveInvitesCount); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void AddIconToScreen(class UCommonLazyImage* Image); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7c91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTopBarPanel");
			return (class UClass*)ptr;
		};

};

class UFortTouchControlRegion : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x80];
	    class UFortAutorunLockZone* AutoRunLockTarget; // 0x2b0 Size: 0x8
	    struct FTimerHandle AutorunLockDelayHandle; // 0x2b8 Size: 0x8
	    class UFortTouchMoveStick* TouchMoveStick; // 0x2c0 Size: 0x8
	    class UFortTouchLookStick* TouchLookStick; // 0x2c8 Size: 0x8
	    class UWidget* AutoRunTapZone; // 0x2d0 Size: 0x8
	    struct FVector2D LastMovePlayerRegionTouchOrigin; // 0x2d8 Size: 0x8
	    struct FVector2D MovePlayerRegionTouchEndPos; // 0x2e0 Size: 0x8
	    struct FVector MoveVector; // 0x2e8 Size: 0xc
	    struct FVector2D MoveStickPos; // 0x2f4 Size: 0x8
	    float MoveStickLockMagnitudeThreshold; // 0x2fc Size: 0x4
	    float MoveStickLockAngleBegin; // 0x300 Size: 0x4
	    float MoveStickLockAngleEnd; // 0x304 Size: 0x4
	    float MoveStickLockAccumulator; // 0x308 Size: 0x4
	    bool bLastLookTouchWasTap; // 0x30c Size: 0x1
	    bool bMoveStickIsTouched; // 0x30c Size: 0x1
	    bool bMoveStickIsLocked; // 0x30c Size: 0x1
	    bool bLookStickIsTouched; // 0x30c Size: 0x1
	    bool bIsLockedOn; // 0x30c Size: 0x1
	    char UnknownData1[0x1]; // 0x311
	    float MoveStickLockTimeToHold; // 0x310 Size: 0x4
	    float MoveStickLastTouchTime; // 0x314 Size: 0x4
	    class UMaterialInstanceDynamic* LockBar_MID; // 0x318 Size: 0x8
	    float MovePlayerRegionLastTouchTime; // 0x320 Size: 0x4
	    struct FVector2D MovePlayerRegionLastTouchPos; // 0x324 Size: 0x8
	    struct FVector2D RotateCameraRegionTouchStartPos; // 0x32c Size: 0x8
	    struct FVector2D RotateCameraRegionLastTouchPos; // 0x334 Size: 0x8
	    struct FVector2D RotateCameraPlayerRegionLastTouchDiff; // 0x33c Size: 0x8
	    float RotateCameraLastTouchTime; // 0x344 Size: 0x4
	    char UnknownData2[0x8]; // 0x348
	    class UCurveFloat* RotateInertiaCurve; // 0x350 Size: 0x8
	    struct FVector2D RotateStickPosition; // 0x358 Size: 0x8
	    struct FVector2D LockOnStickOrigin; // 0x360 Size: 0x8
	    struct FVector2D LockOnStickCurrentPos; // 0x368 Size: 0x8
	    struct FVector2D LockOnBarOffset; // 0x370 Size: 0x8
	    bool bIsForceFiring; // 0x378 Size: 0x1
	    char UnknownData3[0x379]; // 0x379
	    void UpdateMoveStickLock(float DeltaTime); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void UpdateLockOnStickPosition(struct FVector2D LocalPos); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void UpdateLockOnStickOrigin(struct FVector2D LocalPos, bool IsTouchStartEvent); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetMoveStickPos(struct FVector2D NewMoveStickPos); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetLockOnStickPosition(struct FVector2D LocalPos); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetFeedbackPosition(struct FGeometry InGeometry, struct FPointerEvent InGestureEvent); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void RotatePlayerRegionTick(struct FGeometry InGeometry, float DeltaTime); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void ResetTouchState(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void OnRotatePlayerRegionTouchStarted(struct FGeometry InGeometry, struct FPointerEvent InGestureEvent); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void OnRotatePlayerRegionTouchMoved(struct FGeometry InGeometry, struct FPointerEvent InGestureEvent, struct FVector2D MoveDelta); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void OnRotatePlayerRegionTouchLost(int PointerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void OnRotatePlayerRegionTouchEnded(struct FGeometry InGeometry, struct FPointerEvent InGestureEvent); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void OnRegionTouchStarted(EFortTouchControlRegion Region, struct FGeometry InGeometry, struct FPointerEvent InGestureEvent); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void OnRegionTouchMoved(EFortTouchControlRegion Region, struct FGeometry InGeometry, struct FPointerEvent InGestureEvent, struct FVector2D MoveDelta); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void OnRegionTouchEnded(EFortTouchControlRegion Region, struct FGeometry InGeometry, struct FPointerEvent InGestureEvent); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void OnMovePlayerRegionTouchStarted(struct FGeometry InGeometry, struct FPointerEvent InGestureEvent); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void OnMovePlayerRegionTouchMoved(struct FGeometry InGeometry, struct FPointerEvent InGestureEvent); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void OnMovePlayerRegionTouchLost(int PointerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void OnMovePlayerRegionTouchEnded(struct FGeometry InGeometry, struct FPointerEvent InGestureEvent); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void OnCursorModeChanged(bool bCursorModeEnabled, FName ActionName, class UUserWidget* CustomWidget); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void OnBuildModeChanged(bool bBuildModeEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void OnAdditionalTouchStarted(struct FGeometry InGeometry, struct FPointerEvent InGestureEvent); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void OnAdditionalTouchLost(int PointerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void OnAdditionalTouchEnded(struct FGeometry InGeometry, struct FPointerEvent InGestureEvent); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    bool MoveStickIsInSprintThreshold(); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    bool MoveStickIsInLockPosition(); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    void MovePlayerRegionTick(struct FGeometry InGeometry, float DeltaTime); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    bool IsRotatePlayerRegionTouched(); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    bool IsMovePlayerRegionTouched(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    bool IsFiring(); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    float GetTouchStickRange(); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    bool CanLockMoveStick(); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x-7c51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTouchControlRegion");
			return (class UClass*)ptr;
		};

};

class UFortTouchLookStick : public UBacchusHUDElement
{
	public:
	    class USizeBox* MainSizeBox; // 0x380 Size: 0x8
	    struct TSoftObjectPtr<struct UImage*> FireImageRef; // 0x388 Size: 0x28
	    struct FVector2D FireImageAbsoluteOffset; // 0x3b0 Size: 0x8
	    struct FText SizePropertyName; // 0x3b8 Size: 0x18
	    struct FText ShowAllTimeTimePropertyName; // 0x3d0 Size: 0x18
	    char UnknownData0[0x3e8]; // 0x3e8
	    void SetTouchStickPositionLocal(struct FVector2D TouchPosition); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetTouchStickPositionAbsolute(struct FVector2D TouchPosition); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetSize(float NewSize); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetFiringState(bool IsFiring); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool IsFireButtonUnderTouch(struct FVector2D TouchPosition); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    float GetSize(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool GetShowAllTimeTime(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7bf1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTouchLookStick");
			return (class UClass*)ptr;
		};

};

class UFortTouchMoveStick : public UBacchusHUDElement
{
	public:
	    bool bIsTouched; // 0x380 Size: 0x1
	    char UnknownData0[0x7]; // 0x381
	    struct FText AlwaysShowPropertyName; // 0x388 Size: 0x18
	    bool bAlwaysShowWhenTouched; // 0x3a0 Size: 0x1
	    char UnknownData1[0x3a1]; // 0x3a1
	    void SetStickPosition(struct FVector2D NewPosition); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetMovementLockStatus(bool MovementIsLocked); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool IsTouched(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleTouchStarted(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void HandleTouchEnded(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    float GetHalfHeight(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7c39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTouchMoveStick");
			return (class UClass*)ptr;
		};

};

class UFortTrackedIndicator : public UFortSimpleItemConditionIconIndicator
{
	public:
	    char UnknownData0[0x460];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTrackedIndicator");
			return (class UClass*)ptr;
		};

};

class UFortTransformKeyPicker : public UFortItemPickerBase
{
	public:
	    void RebuildTransformKeys(TArray<class UObject*> InDataProvider); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7ca1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTransformKeyPicker");
			return (class UClass*)ptr;
		};

};

class UFortTransformKeyPickerTileButton : public UFortItemPickerButton
{
	public:
	    char UnknownData0[0xb58];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTransformKeyPickerTileButton");
			return (class UClass*)ptr;
		};

};

class UFortTransformSlotItemPicker : public UFortItemPickerBase
{
	public:
	    void RebuildSlottableItems(TArray<EFortInventoryFilter> ItemFilters, EFortItemType ItemType, TArray<class UFortItem*> ItemsToIgnore); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7cf1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTransformSlotItemPicker");
			return (class UClass*)ptr;
		};

};

class UFortTransformSlotItemPickerTileButton : public UFortItemPickerButton
{
	public:
	    char UnknownData0[0xb58];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTransformSlotItemPickerTileButton");
			return (class UClass*)ptr;
		};

};

class UFortTrapDefenderItemPicker : public UFortItemPickerBase
{
	public:
	    class UFortItemDetailsHostPanel* DetailsPanel; // 0x2e8 Size: 0x8
	    TWeakObjectPtr<ABuildingTrapDefender*> DefenderTrap; // 0x2f0 Size: 0x8
	    char UnknownData0[0x2f8]; // 0x2f8
	    void HandleSelectionCommittedBP(class UFortItem* CommittedItem); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7c91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTrapDefenderItemPicker");
			return (class UClass*)ptr;
		};

};

class UFortTravelLogMap : public UUserWidget
{
	public:
	    float MapSize; // 0x228 Size: 0x4
	    float CurrentTimeFraction; // 0x22c Size: 0x4
	    int DistanceToCoalescePositions; // 0x230 Size: 0x4
	    char UnknownData0[0x234]; // 0x234
	    void InitializeFromTravelRecord(struct FAthenaTravelRecord Record); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7d89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTravelLogMap");
			return (class UClass*)ptr;
		};

};

class UFortTutorialContext : public UBlueprintContextBase
{
	public:
	    MulticastDelegateProperty OnUpdateTutorialAnnouncement; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnNewAnnouncementStartedOnClientDelegate; // 0x38 Size: 0x10
	    char UnknownData0[0x48]; // 0x48
	    void UpdateTutorialAnnouncement(struct FFortClientAnnouncementData_Tutorial AnnouncementData, bool bShow); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void UnhideTutorialCallout(FName WidgetName, FName TutorialQuestObjectiveName, ETutorialType TutorialType); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void UnhideAllTutorialCallouts(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SkipTutorial(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool ShouldPromptToSkipTutorial(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnNewAnnouncementStartedOnClient(class AFortClientAnnouncement* NewAnnouncement); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool IsTutorialCalloutVisible(FName WidgetName); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void HideTutorialCallout(FName WidgetName, FName TutorialQuestObjectiveName, ETutorialType TutorialType); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool GetTutorialData(FName TutorialObjectiveName, struct FFortUITutorialData OutTutorialData); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void GetTutorialCallouts(TArray<FName> WidgetNames); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void GetHiddenTutorialCallouts(TArray<FName> WidgetNames); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void EnableTutorialCallout(FName WidgetName, FName TutorialQuestObjectiveName, ETutorialType TutorialType); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void DisableTutorialCallout(FName WidgetName, FName TutorialQuestObjectiveName, ETutorialType TutorialType); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void ContinueTutorial(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void ClearTutorialCallouts(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x-7ef9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTutorialContext");
			return (class UClass*)ptr;
		};

};

class UFortTutorialQuestVisibilityWrapper : public UFortBangWrapper_NUI
{
	public:
	    class UFortQuestItemDefinition* QuestItemDefinition; // 0x250 Size: 0x8
	    struct FDataTableRowHandle QuestObjectiveStat; // 0x258 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTutorialQuestVisibilityWrapper");
			return (class UClass*)ptr;
		};

};

class UFortTwitchLogin : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x20];
	    __int64/*SoftClassProperty*/ TwitchLoginModalWidgetClass; // 0x250 Size: 0x28
	    class UFortTwitchLoginModalWidget* ActiveLoginModal; // 0x278 Size: 0x8
	    char UnknownData1[0x280]; // 0x280
	    void OnShowLoginError(struct FText ErrorTitle, struct FText ErrorMessage); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnLoginStatusChanged(bool bLoggedIn, struct FString AccountName); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnLoginFlowModalDismissed(class UFortTwitchLoginModalWidget* Modal); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnLoginFlowModalCreated(class UFortTwitchLoginModalWidget* Modal); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnLinkedTwitchAccountChanged(struct FString AccountName); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void Logout(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void Login(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool IsLoggedIn(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    struct FString GetLinkedTwitchAccountName(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    struct FString GetAccountName(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void CancelLoginFlow(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7d61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTwitchLogin");
			return (class UClass*)ptr;
		};

};

class UFortTwitchLoginModalWidget : public UFortActivatablePanel
{
	public:
	    class UNativeWidgetHost* NativeHost; // 0x340 Size: 0x8
	    char UnknownData0[0x348]; // 0x348
	    void OnNativeHostContentChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7c99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortTwitchLoginModalWidget");
			return (class UClass*)ptr;
		};

};

class UFortUIBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static struct FText GetTimespanAsSimpleString(struct FTimespan Timespan); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static struct FVector2D GetStandardBrushSize(char BrushSize); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static class UTexture2D* GetOrLoadSynchronously(struct TSoftObjectPtr<struct UTexture2D*> SoftTexture2D); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static struct FString GetMetaStringOnOffer(struct FCardPackOffer Offer, struct FString Key); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static int GetMetaIntOnOffer(struct FCardPackOffer Offer, struct FString Key, int DefaultValue); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static bool GetMetaBoolOnOffer(struct FCardPackOffer Offer, struct FString Key, bool bDefaultValue); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static struct FFortMultiSizeBrush GetItemSmallPreviewImageMultiSizeBrush(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static struct FSlateBrush GetItemSmallPreviewImageBrush(class UFortItem* Item, char BrushSize); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static struct FFortMultiSizeBrush GetItemDefinitionSmallPreviewImageMultiSizeBrush(class UFortItemDefinition* ItemDefinition); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static struct FSlateBrush GetItemDefinitionSmallPreviewImageBrush(class UFortItemDefinition* ItemDefinition, char BrushSize); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static class UObject* GetAssetFromTemplateId(struct FString TemplateId); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUIBlueprintFunctionLibrary");
			return (class UClass*)ptr;
		};

};

class UFortUIDataConfiguration : public UPrimaryDataAsset
{
	public:
	    struct FString DefaultUIDataConfigurationPath; // 0x30 Size: 0x10
	    struct FString BROnlyUIDataConfigurationPath; // 0x40 Size: 0x10
	    struct FString ErebusUIDataConfigurationPath; // 0x50 Size: 0x10
	    __int64/*SoftClassProperty*/ StateWidgetClasses; // 0x60 Size: 0x28
	    char UnknownData0[0x1e0]; // 0x88
	    __int64/*SoftClassProperty*/ MenuStateWidgetClasses; // 0x268 Size: 0x28
	    char UnknownData1[0x1e0]; // 0x290
	    __int64/*SoftClassProperty*/ ZoneStateWidgetClasses; // 0x470 Size: 0x28
	    char UnknownData2[0x1e0]; // 0x498
	    TArray<__int64/*SoftClassProperty*/> CachedWidgetClasses; // 0x678 Size: 0x10
	    class UFortVideoDisplayData* VideoDisplayData; // 0x688 Size: 0x8
	    class UFortSocialDisplayData* SocialDisplayData; // 0x690 Size: 0x8
	    __int64/*MapProperty*/ StandardImageBrushSizes; // 0x698 Size: 0x50
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> PowerRatingIconMultiSizeBrush; // 0x6e8 Size: 0x28
	    struct FLinearColor PowerRatingEnchantedPositiveColorOverride; // 0x710 Size: 0x10
	    struct FLinearColor PowerRatingEnchantedNegativeColorOverride; // 0x720 Size: 0x10
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> FilledTierPipMultiSizeBrush; // 0x730 Size: 0x28
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> UnfilledTierPipMultiSizeBrush; // 0x758 Size: 0x28
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> PreviewingTierPipMultiSizeBrush; // 0x780 Size: 0x28
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> UpgradeArrowMultiSizeBrush; // 0x7a8 Size: 0x28
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> ComparisonUpArrowMultiSizeBrush; // 0x7d0 Size: 0x28
	    struct FLinearColor BetterComparisonResultColor; // 0x7f8 Size: 0x10
	    struct FLinearColor WorseComparisonResultColor; // 0x808 Size: 0x10
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> InventoryOverflowIndicatorMultiSizeBrush; // 0x818 Size: 0x28
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> TrackedSchematicIndicatorMultiSizeBrush; // 0x840 Size: 0x28
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> FavoritedItemIndicatorMultiSizeBrush; // 0x868 Size: 0x28
	    __int64/*MapProperty*/ VariantToWidgetMaping; // 0x890 Size: 0x50
	    bool bEnableSocialFeatures; // 0x8e0 Size: 0x1
	    bool bEnableChat; // 0x8e1 Size: 0x1
	    bool bEnablePartyFeatures; // 0x8e2 Size: 0x1
	    char UnknownData3[0x5]; // 0x8e3
	    __int64/*MapProperty*/ ChatChannelStyles; // 0x8e8 Size: 0x50
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> UnlockedSquadSlotBorderMultiSizeBrush; // 0x938 Size: 0x28
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> LockedSquadSlotBorderMultiSizeBrush; // 0x960 Size: 0x28
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> ReadOnlySquadSlotBorderMultiSizeBrush; // 0x988 Size: 0x28
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> DefenderIconMultiSizeBrush; // 0x9b0 Size: 0x28
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> AssaultDefenderIconMultiSizeBrush; // 0x9d8 Size: 0x28
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> PistolDefenderIconMultiSizeBrush; // 0xa00 Size: 0x28
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> MeleeDefenderIconMultiSizeBrush; // 0xa28 Size: 0x28
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> SniperDefenderIconMultiSizeBrush; // 0xa50 Size: 0x28
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> ShotgunDefenderIconMultiSizeBrush; // 0xa78 Size: 0x28
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> LeadSurvivorIconMultiSizeBrush; // 0xaa0 Size: 0x28
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> SurvivorIconMultiSizeBrush; // 0xac8 Size: 0x28
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> TrapIconMultiSizeBrush; // 0xaf0 Size: 0x28
	    __int64/*SoftClassProperty*/ KeybindWidgetClass; // 0xb18 Size: 0x28
	    __int64/*SoftClassProperty*/ HiddenCursorWidget; // 0xb40 Size: 0x28
	    __int64/*SoftClassProperty*/ VirtualCursorWidget; // 0xb68 Size: 0x28
	    struct FRuntimeFloatCurve UIScaleCurve; // 0xb90 Size: 0x88
	    struct FRuntimeFloatCurve FrontEndUIScaleCurve; // 0xc18 Size: 0x88
	    EFortReturnToFrontendBehavior ReturnToFrontendBehavior; // 0xca0 Size: 0x1
	    char UnknownData4[0x7]; // 0xca1
	    struct TSoftObjectPtr<struct UDataTable*> UpgradesDisplayDataTable; // 0xca8 Size: 0x28
	    __int64/*MapProperty*/ ItemCardPowerRatingTextStylesByBrushSize; // 0xcd0 Size: 0x50
	    __int64/*MapProperty*/ ItemCardStackCountTextStylesByBrushSize; // 0xd20 Size: 0x50
	    struct TSoftObjectPtr<struct UMaterialInterface*> ItemCardLevelMeterMaterial; // 0xd70 Size: 0x28
	    struct TSoftObjectPtr<struct UMaterialInterface*> ItemCardDurabilityMeterMaterial; // 0xd98 Size: 0x28
	    struct FSlateBrush ItemCardBackgroundPlateBrush; // 0xdc0 Size: 0x88
	    struct FSlateBrush ItemCardRarityGradientBrush; // 0xe48 Size: 0x88
	    struct FSlateBrush ItemCardDefenderPortraitBackgroundBrush; // 0xed0 Size: 0x88
	    struct FSlateBrush ItemCardHeroPortraitBackgroundBrush; // 0xf58 Size: 0x88
	    struct FSlateBrush ItemCardLeadSurvivorPortraitBackgroundBrush; // 0xfe0 Size: 0x88
	    struct FSlateBrush ItemCardSchematicBackgroundBrush; // 0x1068 Size: 0x88
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> ItemCardRewardTraitsBackgroundMultiSizeBrush; // 0x10f0 Size: 0x28
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> ItemCardSchematicTraitsBackgroundMultiSizeBrush; // 0x1118 Size: 0x28
	    __int64/*SoftClassProperty*/ FrontendItemManagementScreenType; // 0x1140 Size: 0x28
	    __int64/*SoftClassProperty*/ FrontendItemInspectionScreenType; // 0x1168 Size: 0x28
	    __int64/*SoftClassProperty*/ HeroSquadManagementScreenType; // 0x1190 Size: 0x28
	    __int64/*SoftClassProperty*/ HeroLoadoutScreenType; // 0x11b8 Size: 0x28
	    __int64/*SoftClassProperty*/ SurvivorSquadManagementScreenType; // 0x11e0 Size: 0x28
	    __int64/*SoftClassProperty*/ DefenderSquadManagementScreenType; // 0x1208 Size: 0x28
	    __int64/*SoftClassProperty*/ MatchReadyDesktopPopupWidgetType; // 0x1230 Size: 0x28
	    __int64/*SoftClassProperty*/ MainTabSet; // 0x1258 Size: 0x28
	    bool bLimitedToES2Features; // 0x1280 Size: 0x1
	    char UnknownData5[0x7]; // 0x1281
	    struct FWeightedBlendables FrontEndFFPostProcessMaterials; // 0x1288 Size: 0x10
	    bool bUseSpecificPinataWeapon; // 0x1298 Size: 0x1
	    bool bQuestVOEnabled; // 0x1299 Size: 0x1
	    char UnknownData6[0x6]; // 0x129a
	    __int64/*MapProperty*/ PersonnelAndSchematicCardSizes; // 0x12a0 Size: 0x50
	    __int64/*MapProperty*/ OtherItemCardSizes; // 0x12f0 Size: 0x50
	    __int64/*MapProperty*/ PersonnelAndSchematicItemCardMaterial; // 0x1340 Size: 0x50
	    __int64/*MapProperty*/ CardPackItemCardMaterial; // 0x1390 Size: 0x50
	    __int64/*MapProperty*/ InstanceItemCardMaterial; // 0x13e0 Size: 0x50
	    __int64/*MapProperty*/ TransformKeyItemCardMaterial; // 0x1430 Size: 0x50
	    __int64/*MapProperty*/ CosmeticItemCardMaterial; // 0x1480 Size: 0x50
	    TArray<EFortItemType> ItemTypesWhoseImagesReplaceCardBackgrounds; // 0x14d0 Size: 0x10
	    __int64/*SetProperty*/ ItemTypesToHideCountWhenCountEqualsOne; // 0x14e0 Size: 0x50
	    __int64/*MapProperty*/ ItemCardDetailAreaMaterial; // 0x1530 Size: 0x50
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> FavoriteBookmarkMultiSizeBrush; // 0x1580 Size: 0x28
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> PermanentTransformKeykMultiSizeBrush; // 0x15a8 Size: 0x28
	    struct TSoftObjectPtr<struct UFortMultiSizeBrushAsset*> ConsumableTransformKeykMultiSizeBrush; // 0x15d0 Size: 0x28
	    __int64/*MapProperty*/ DefenderSubtypeWeaponTextures; // 0x15f8 Size: 0x50
	    __int64/*MapProperty*/ EnchantedCustomRatingBlockBackgroundMaterial; // 0x1648 Size: 0x50
	    __int64/*MapProperty*/ NormalCustomRatingBlockBackgroundMaterial; // 0x1698 Size: 0x50
	    struct FMargin CustomRatingBlockBackgroundBrushMargin; // 0x16e8 Size: 0x10
	    struct TSoftObjectPtr<struct UMaterialInterface*> UniversalItemCardDurabilityMeterMaterial; // 0x16f8 Size: 0x28
	    struct TSoftObjectPtr<struct UMaterialInterface*> UniversalItemCardLevelMeterMaterial; // 0x1720 Size: 0x28
	    struct TSoftObjectPtr<struct UMaterialInterface*> UniversalItemCardTraitIconMaterial; // 0x1748 Size: 0x28
	    struct TSoftObjectPtr<struct UMaterialInterface*> UniversalItemCardUnearnedTierIconMaterial; // 0x1770 Size: 0x28
	    struct TSoftObjectPtr<struct UMaterialInterface*> UniversalItemCardAvailableTierIconMaterial; // 0x1798 Size: 0x28
	    struct TSoftObjectPtr<struct UMaterialInterface*> UniversalItemCardEarnedTierIconMaterial; // 0x17c0 Size: 0x28
	    struct TSoftObjectPtr<struct UFortItemDefinition*> MysteryItemDefinition; // 0x17e8 Size: 0x28
	    struct TSoftObjectPtr<struct UTexture2D*> LoadingCardTexture; // 0x1810 Size: 0x28
	    struct FFortItemCard_XL_PersonnelAndSchematics_Configuration ItemCardConfig_XXL_PersonnelAndSchematics; // 0x1838 Size: 0x350
	    struct FFortItemCard_XL_ItemInstance_Configuration ItemCardConfig_XXL_ItemInstance; // 0x1b88 Size: 0x1b0
	    struct FFortItemCard_XL_TransformKey_Configuration ItemCardConfig_XXL_TransformKey; // 0x1d38 Size: 0x48
	    struct FFortItemCard_XL_PersonnelAndSchematics_Configuration ItemCardConfig_XL_PersonnelAndSchematics; // 0x1d80 Size: 0x350
	    struct FFortItemCard_XL_ItemInstance_Configuration ItemCardConfig_XL_ItemInstance; // 0x20d0 Size: 0x1b0
	    struct FFortItemCard_XL_TransformKey_Configuration ItemCardConfig_XL_TransformKey; // 0x2280 Size: 0x48
	    struct FFortItemCard_L_PersonnelAndSchematics_Configuration ItemCardConfig_L_PersonnelAndSchematics; // 0x22c8 Size: 0x2c8
	    struct FFortItemCard_L_ItemInstance_Configuration ItemCardConfig_L_ItemInstance; // 0x2590 Size: 0x1b0
	    struct FFortItemCard_L_TransformKey_Configuration ItemCardConfig_L_TransformKey; // 0x2740 Size: 0x48
	    struct FFortItemCard_M_PersonnelAndSchematics_Configuration ItemCardConfig_M_PersonnelAndSchematics; // 0x2788 Size: 0x2c8
	    struct FFortItemCard_M_ItemInstance_Configuration ItemCardConfig_M_ItemInstance; // 0x2a50 Size: 0x1b0
	    struct FFortItemCard_M_TransformKey_Configuration ItemCardConfig_M_TransformKey; // 0x2c00 Size: 0x48
	    struct FFortItemCard_S_PersonnelAndSchematics_Configuration ItemCardConfig_S_PersonnelAndSchematics; // 0x2c48 Size: 0x2c8
	    struct FFortItemCard_S_ItemInstance_Configuration ItemCardConfig_S_ItemInstance; // 0x2f10 Size: 0x1a0
	    struct FFortItemCard_S_TransformKey_Configuration ItemCardConfig_S_TransformKey; // 0x30b0 Size: 0x48
	    struct FFortItemCard_XS_PersonnelAndSchematics_Configuration ItemCardConfig_XS_PersonnelAndSchematics; // 0x30f8 Size: 0x34
	    char UnknownData7[0x4]; // 0x312c
	    struct FFortItemCard_XS_ItemInstance_Configuration ItemCardConfig_XS_ItemInstance; // 0x3130 Size: 0x188
	    struct FFortItemCard_XS_TransformKey_Configuration ItemCardConfig_XS_TransformKey; // 0x32b8 Size: 0x48
	    struct FFortItemCard_XS_PersonnelAndSchematics_Configuration ItemCardConfig_XXS_PersonnelAndSchematics; // 0x3300 Size: 0x34
	    char UnknownData8[0x4]; // 0x3334
	    struct FFortItemCard_XXS_ItemInstance_Configuration ItemCardConfig_XXS_ItemInstance; // 0x3338 Size: 0x30
	    struct FFortItemCard_XS_TransformKey_Configuration ItemCardConfig_XXS_TransformKey; // 0x3368 Size: 0x48
	    struct TSoftObjectPtr<struct UDataTable*> HealthyGamingDataTable; // 0x33b0 Size: 0x28
	    struct TSoftObjectPtr<struct UDataTable*> TrapPickerGameplayTagSettings; // 0x33d8 Size: 0x28
	    struct FFortUIPickerTrapSortScores TrapPickerSortScores; // 0x3400 Size: 0x18
	    class UFortTooltipDisplayStatsLookupTable* ObjClassToTooltipStatsMap; // 0x3418 Size: 0x8
	    __int64/*SoftClassProperty*/ LoadingScreenBacchusTutorialWidget; // 0x3420 Size: 0x28
	    struct TSoftObjectPtr<struct USlateBrushAsset*> ActorCanvasArrowBrush; // 0x3448 Size: 0x28
	    class UFortOptionsMenuData* GameOptionsMenuData; // 0x3470 Size: 0x8
	    class UFortOptionsMenuData* GameCreativeMenuData; // 0x3478 Size: 0x8
	    class UFortOptionsMenuDefaults* GameOptionsMenuDefaults; // 0x3480 Size: 0x8
	    struct TSoftObjectPtr<struct UDataTable*> UITutorialData; // 0x3488 Size: 0x28
	    TArray<class UFortUIDataProfileStats*> ProfileStatStyleSets; // 0x34b0 Size: 0x10
	    __int64/*MapProperty*/ LegacyNativeUIBrushMap; // 0x34c0 Size: 0x50
	    __int64/*MapProperty*/ LegacyNativeUIAssetMap; // 0x3510 Size: 0x50
	    float AnalogRotateSpeed; // 0x3560 Size: 0x4
	    float DragRotateSpeed; // 0x3564 Size: 0x4
	    float TouchSwipeRotateRate; // 0x3568 Size: 0x4
	    float MouseWheelZoomSpeed; // 0x356c Size: 0x4
	    float DragZoomSpeed; // 0x3570 Size: 0x4
	    float TriggerZoomSpeed; // 0x3574 Size: 0x4
	    float TouchZoomPinchRate; // 0x3578 Size: 0x4
	    float ItemViewCompetingAxisInputThreshold; // 0x357c Size: 0x4
	    TArray<EFortItemType> ItemTypesToUseVaultCamera; // 0x3580 Size: 0x10
	    class UFortFrontendItemViewSettingsManager* FrontendItemViewSettingsManager; // 0x3590 Size: 0x8
	    char UnknownData9[0x3598]; // 0x3598
	    static class UFortMultiSizeBrushAsset* GetDefenderSubtypeIconMultiSizeBrushByTag(struct FGameplayTag DefenderSubtypeTag); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-4a49];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUIDataConfiguration");
			return (class UClass*)ptr;
		};

};

class UFortUIDataConfigurationContext : public UBlueprintContextBase
{
	public:
	    bool UseSpecificPinataWeapon(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    bool IsQuestVOEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool IsLimitedToES2Features(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool IsChatEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    TArray<EFortItemType> GetItemTypesToUseVaultCamera(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    struct FPostProcessSettings GetFrontEndFFSettings(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool AreSocialFeaturesEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool ArePartyFeaturesEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUIDataConfigurationContext");
			return (class UClass*)ptr;
		};

};

class UFortUIDataProfileStats : public UDataAsset
{
	public:
	    __int64/*MapProperty*/ ProfileStatStyles; // 0x30 Size: 0x50

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUIDataProfileStats");
			return (class UClass*)ptr;
		};

};

class UFortUIManagerWidget_NUI : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x8];
	    MulticastDelegateProperty OnPreShowConfirmation_NUI; // 0x238 Size: 0x10
	    MulticastDelegateProperty OnBeginSpokenDialog; // 0x248 Size: 0x10
	    MulticastDelegateProperty OnEndSpokenDialog; // 0x258 Size: 0x10
	    MulticastDelegateProperty OnShouldOpenTalkingHead; // 0x268 Size: 0x10
	    MulticastDelegateProperty OnShouldCloseTalkingHead; // 0x278 Size: 0x10
	    MulticastDelegateProperty OnShouldBlockSubtitlePortraitChanged; // 0x288 Size: 0x10
	    EFortUIState CurrentState; // 0x298 Size: 0x1
	    EFortUIState PendingState; // 0x299 Size: 0x1
	    char UnknownData1[0x6]; // 0x29a
	    class UFortUIStateWidget_NUI* CurrentStateWidget; // 0x2a0 Size: 0x8
	    char UnknownData2[0x10]; // 0x2a8
	    TArray<class UFortUIStateTrigger*> StateTriggers; // 0x2b8 Size: 0x10
	    bool bIsStateContentDisplayed; // 0x2d0 Size: 0x1
	    char UnknownData3[0xf]; // 0x2c9
	    class UFortUINavigationManager* NavigationManager; // 0x2d8 Size: 0x8
	    class UFortUINotificationManager* NotificationManager; // 0x2e0 Size: 0x8
	    __int64/*MapProperty*/ TypedWidgetCache; // 0x2e8 Size: 0x50
	    bool bSupressErrors; // 0x3a0 Size: 0x1
	    char UnknownData4[0x7f]; // 0x339
	    class UFortPlayerBanned* PlayerBannedScreen; // 0x3b8 Size: 0x8
	    int BlockSubtitlePortraitRefcount; // 0x3c0 Size: 0x4
	    char UnknownData5[0x3c4]; // 0x3c4
	    void UpdateStateWidgetContent(class UFortUIStateWidget_NUI* StateWidget); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void UnregisterStateTrigger(class UFortUIStateTrigger* TriggerToRemove); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static void ShowErrorDialog(class UObject* WorldContextObject, struct FText OperationDesc, struct FText DisplayMessage, struct FString ErrorNote, EFortErrorSeverity ErrorSeverity); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool ShouldBlockSubtitlePortrait(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetStateContentDisplayed(bool bDisplay); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetFrontEndVisibility(bool bHideHeader, bool bHideFooter, bool bHideChatWidget); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void ReleaseNotification(class UFortUINotification* Notification); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void RegisterStateTrigger(class UFortUIStateTrigger* StateTrigger); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void QueueNotification(EFortNotificationQueueType QueueType, class UFortUINotification* Notification); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void QueueActivatablePanelIntoModalLayer(class UCommonActivatablePanel* Panel); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void PushContentWidgetAdvanced(class UWidget* Widget, bool bHideHeader, bool bHideFooter, bool bHideChatWidget); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void PushContentWidget(class UWidget* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void PopContentWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void PopAllContentWidgets(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void PopActivatablePanelInModalLayer(class UCommonActivatablePanel* Panel); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void OnStateStarted(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void OnStateEnded(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void OnShowConfirmation_NUI(struct FFortDialogDescription_NUI Description); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void OnShowConfirmation(struct FFortDialogDescription Description); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnShouldOpenTalkingHead__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnShouldCloseTalkingHead__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnShouldBlockSubtitlePortraitChanged__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnPreShowConfirmation_NUI__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnEndSpokenDialog__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    void OnEndLatentWaitForConfirmationDialog(struct FFortDialogExternalLatentActionHandle WaitingDialogHandle); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnBeginSpokenDialog__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    void NotifyPreShowConfirmation_NUI(struct FFortDialogDescription_NUI DialogDescription); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    static void KillConfirmationDialog(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    bool IsStateContentDisplayed(); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    bool IsShowingModalsConfirmationsErrors(); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    void IncrementShouldBlockSubtitlePortrait(); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    bool HasActiveModalWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    static class UFortUINotificationQueue* GetUINotificationQueue(class UObject* WorldContextObject, EFortNotificationQueueType QueueType); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    static class UFortUINavigationManager* GetUINavigationManager(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    static class UFortUIManagerWidget_NUI* GetUIManagerWidget(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    class UFortUINavigationManager* GetNavigationManager(); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    class UFortUIStateWidget_NUI* GetCurrentUIStateWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    class UUserWidget* GetCachedWidget(class UObject* InClass); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    void DisplayStateContent(bool bDisplay); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    void DisplayErrorDialog(struct FFortErrorInfo Info); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    void DecrementShouldBlockSubtitlePortrait(); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    static class UFortUIStateTrigger* CreateUIStateTrigger(class UFortUIStateTrigger* Class, class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    class UFortUINotification* CreateNotification(class UFortUINotification* UINotificationClass); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    void CloseErrorWindow(); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    void CloseConfirmationWindow(); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    bool CanNotificationBeQueued(EFortNotificationQueueType QueueType, EFortNotificationPriority NotificationPriority); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    EFortUIState _BPGetCurrentUIState(); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x-7c19];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUIManagerWidget_NUI");
			return (class UClass*)ptr;
		};

};

class UFortUIMessageItemWidget : public UCommonUserWidget
{
	public:
	    MulticastDelegateProperty OnMessageDisplayed; // 0x230 Size: 0x10
	    MulticastDelegateProperty OnMessageRemoved; // 0x240 Size: 0x10
	    FName MessageID; // 0x250 Size: 0x8
	    int StackSize; // 0x258 Size: 0x4
	    float DisplayDuration; // 0x25c Size: 0x4
	    float RemoveDuration; // 0x260 Size: 0x4
	    char UnknownData0[0x264]; // 0x264
	    void OnStackSizeChanged(int OldStackSize); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnReturnedToPool(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnBeginRemove(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUIMessageItemWidget");
			return (class UClass*)ptr;
		};

};

class UFortUIMessageManager : public UObject
{
	public:
	    MulticastDelegateProperty OnMessageAvailable; // 0x28 Size: 0x10
	    TArray<class UFortUIMessageItemWidget*> MessageQueue; // 0x38 Size: 0x10
	    TArray<TWeakObjectPtr<UFortUIMessageItemWidget*>> CurrentlyDisplayedMessages; // 0x48 Size: 0x10
	    char UnknownData0[0x58]; // 0x58
	    void HandleMessageRemoved(class UFortUIMessageItemWidget* MessageItem); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void HandleMessageDisplayed(class UFortUIMessageItemWidget* MessageItem); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    int GetNumDisplayedItems(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    class UFortUIMessageItemWidget* GetNextMessageInQueue(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    class UFortUIMessageItemWidget* AddMessageItem(class UFortUIMessageItemWidget* MessageItemClass, class APlayerController* OwningPlayer, FName MessageID, int StackCount); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7f39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUIMessageManager");
			return (class UClass*)ptr;
		};

};

class UFortUIMessagesPageBase : public UCommonActivatablePanel
{
	public:
	    int MaximumMessagesShown; // 0x318 Size: 0x4
	    char UnknownData0[0x4]; // 0x31c
	    class UCommonListView* MessagesList; // 0x320 Size: 0x8
	    char UnknownData1[0x8]; // 0x328
	    TArray<class UFortUINotification*> MessagesShown; // 0x330 Size: 0x10
	    char UnknownData2[0x340]; // 0x340
	    void OnNotificationCleared(class UFortUINotification* ClearedMessage); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnMessageAvailable(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void FillMessagesList(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7ca1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUIMessagesPageBase");
			return (class UClass*)ptr;
		};

};

class UUINavigationManager : public UObject
{
	public:
	    MulticastDelegateProperty OnNavigationEvent; // 0x28 Size: 0x10
	    TArray<struct FUINavigationEntry> NavigationStack; // 0x38 Size: 0x10
	    char UnknownData0[0x48]; // 0x48
	    void PushNavigation(struct FText DisplayName, class UObject* ObjectData, FName IdData, int IntData, __int64/*DelegateProperty*/ OnNavigateTo, __int64/*DelegateProperty*/ OnNavigateFrom); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void PopNavigation(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void NavigationToIndex(int Index); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    int GetStackSize(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    struct FText GetDisplayName(int Index); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ClearStack(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7f99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.UINavigationManager");
			return (class UClass*)ptr;
		};

};

class UFortUINavigationManager : public UUINavigationManager
{
	public:
	    MulticastDelegateProperty OnMainTabNavigateRequest; // 0x48 Size: 0x10
	    MulticastDelegateProperty OnFeatureNavigateOp; // 0x58 Size: 0x10
	    MulticastDelegateProperty OnNodePageNavigateRequest; // 0x68 Size: 0x10
	    MulticastDelegateProperty OnSquadSlotNavigateRequest; // 0x78 Size: 0x10
	    MulticastDelegateProperty OnVaultTabNavigateRequest; // 0x88 Size: 0x10
	    MulticastDelegateProperty OnVaultItemNavigateRequest; // 0x98 Size: 0x10
	    MulticastDelegateProperty OnItemEvolutionNavigateRequest; // 0xa8 Size: 0x10
	    MulticastDelegateProperty OnQuestItemNavigateRequest; // 0xb8 Size: 0x10
	    MulticastDelegateProperty OnPopContentStackOp; // 0xc8 Size: 0x10
	    MulticastDelegateProperty OnSquadNavigationOp; // 0xd8 Size: 0x10
	    MulticastDelegateProperty FortExpeditionsOp; // 0xe8 Size: 0x10
	    MulticastDelegateProperty FortCollectionBookOp; // 0xf8 Size: 0x10
	    MulticastDelegateProperty OnQuestItemOp; // 0x108 Size: 0x10
	    char UnknownData0[0x20]; // 0x118
	    TArray<struct FFortUINavigationRequest> NavigationRequests; // 0x138 Size: 0x10
	    class UUserWidget* HiddenCursorWidget; // 0x148 Size: 0x8
	    class UUserWidget* VirtualCursorWidget; // 0x150 Size: 0x8
	    char UnknownData1[0x158]; // 0x158
	    bool TryGetPendingNavigationOp(struct FFortUINavigationOperation NavigationOp); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetScrollWidget(class UWidget* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void PushSquadManagementScreen(FName SquadId, int SquadSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void PushItemManagementScreen(EFortFrontendInventoryFilter ItemManagementFilter, class UFortItem* ItemToSelect); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void PushItemInspectionScreen(class UFortItem* ItemToInspect, EFortItemInspectionMode Mode, class UFortItemTileView* CycleTileView, bool bReadOnly, bool bAllowFavoriting, bool bIsTemporaryItem, bool bAllowRarityUpgrading); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void PushHeroLoadoutScreen(class UFortCampaignHeroLoadoutItem* HeroLoadout); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void NavigateToSquadSlot(FName SquadId, int SquadSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void NavigateToQuestObjective(class UFortQuestItem* QuestItem); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void NavigateToItemManagementScreen(EFortFrontendInventoryFilter Filter); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void NavigateToItem(class UFortItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void NavigateToFeature(EFortUIFeature Feature); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void NavigateToExpeditions(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void NavigateToCollectionBook(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void NavigateForGift(class UFortGiftBoxItem* Item); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    bool HasPendingNavigationOp(EFortUINavigationOp NavigationOp); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void CompletePendingNavigationOp(EFortUINavigationOp NavigationOp); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void CenterWidget(class UWidget* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    bool CanNavigateToQuestObjective(class UFortQuestItem* QuestItem); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    bool CanAccessSquadManagementScreen(FName SquadId, int SquadSlotIndex); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    bool CanAccessItemManagementScreen(EFortFrontendInventoryFilter ItemManagementFilter); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    bool CanAccessHeroLoadoutScreen(class UFortCampaignHeroLoadoutItem* HeroLoadout); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    bool CanAccessCollectionBook(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    bool AttemptPlayQuest(class UFortQuestItem* Quest); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    bool AttemptMatchmakeForQuest(class UFortQuestItem* Quest, bool OutContentNotDownloaded); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x-7e89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUINavigationManager");
			return (class UClass*)ptr;
		};

};

class UFortUINotificationManager : public UObject
{
	public:
	    TArray<class UFortUINotificationQueue*> UINotificationQueues; // 0x28 Size: 0x10
	    char UnknownData0[0x50];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUINotificationManager");
			return (class UClass*)ptr;
		};

};

class UFortUINotificationQueue : public UObject
{
	public:
	    int MaxNotificationsInQueue; // 0x28 Size: 0x4
	    char UnknownData0[0x4]; // 0x2c
	    TArray<class UFortUINotification*> NotificationQueue; // 0x30 Size: 0x10
	    char UnknownData1[0x40]; // 0x40
	    void UnregisterToReceiveNotifications(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void RemoveNotification(class UFortUINotification* InNotificationDescription); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void RegisterToReceiveNotifications(__int64/*DelegateProperty*/ NotificationDelegate); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void QueueNotification(class UFortUINotification* Notification, bool bShowImmediately); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    class UFortUINotification* GetNextNotification(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool CanNotificationBeQueued(EFortNotificationPriority Priority); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7f91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUINotificationQueue");
			return (class UClass*)ptr;
		};

};

class UFortUIRewardReport : public UObject
{
	public:
	    class UFortLocalPlayer* LocalPlayer; // 0x28 Size: 0x8
	    int RewardDisplayLevel; // 0x30 Size: 0x4
	    char UnknownData0[0x34]; // 0x34
	    int GetRewardedChestIndex(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7fa9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUIRewardReport");
			return (class UClass*)ptr;
		};

};

class UFortUIScoreReport : public UObject
{
	public:
	    class UFortLocalPlayer* LocalPlayer; // 0x28 Size: 0x8
	    char UnknownData0[0x30]; // 0x30
	    bool IsLocalPlayer(int ScoreReportIndex); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    int GetXpToCompleteLevel(int Level); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool GetXpInfo(int ScoreReportIndex, struct FFortUIXpInfo OutXpInfo); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    int GetTeamScore(char ScoreType); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void GetScoreReportIndicesByPlayerID(TArray<int> SortedScoreReportIndices); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    int GetScoreReportIndex(struct FUniqueNetIdRepl PlayerID); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    int GetPlayerScore(int ScoreReportIndex, char ScoreType); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    struct FString GetPlayerPlatform(int ScoreReportIndex); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    struct FText GetPlayerName(int ScoreReportIndex); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void GetPlayerIDFromScoreReportIndex(int ScoreReportIndex, struct FUniqueNetIdRepl OutUniqueNetIdRepl); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    int GetPlayerCount(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    float GetLevelProgress(int Level, int DisplayXp); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    int GetDifficultBonusScore(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    float GetDifficultBonusMultiplier(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    class AFortPlayerState* GetCurrentPlayerState(int ScoreReportIndex); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    class AFortPlayerPawn* GetCurrentPlayerPawn(int ScoreReportIndex); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    int GetBadgeScore(class UFortItem* BadgeItem); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x-7fb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUIScoreReport");
			return (class UClass*)ptr;
		};

};

class UFortUIStateTrigger : public UObject
{
	public:
	    EFortUIState UIState; // 0x28 Size: 0x1
	    char UnknownData0[0x29]; // 0x29
	    bool IsLoggedIn(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool EvalBP(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7fb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUIStateTrigger");
			return (class UClass*)ptr;
		};

};

class UFortUIStateTrigger_Athena : public UFortUIStateTrigger
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUIStateTrigger_Athena");
			return (class UClass*)ptr;
		};

};

class UFortUIStateTrigger_AthenaReplay : public UFortUIStateTrigger
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUIStateTrigger_AthenaReplay");
			return (class UClass*)ptr;
		};

};

class UFortUIStateTrigger_AthenaSpectator : public UFortUIStateTrigger
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUIStateTrigger_AthenaSpectator");
			return (class UClass*)ptr;
		};

};

class UFortUIStateTrigger_InGame : public UFortUIStateTrigger
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUIStateTrigger_InGame");
			return (class UClass*)ptr;
		};

};

class UFortUIStateTrigger_Login : public UFortUIStateTrigger
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUIStateTrigger_Login");
			return (class UClass*)ptr;
		};

};

class UFortUIStateTrigger_Replay : public UFortUIStateTrigger
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUIStateTrigger_Replay");
			return (class UClass*)ptr;
		};

};

class UFortUIStateWidget_Frontend : public UFortUIStateWidget_NUI
{
	public:
	    bool bVideoActive; // 0x358 Size: 0x1
	    char UnknownData0[0x7]; // 0x359
	    class UFortGiftBoxItem* NextGiftBox; // 0x360 Size: 0x8
	    class UFortItemReceivedScreen* ItemReceivedScreenClass; // 0x368 Size: 0x8
	    char UnknownData1[0x370]; // 0x370
	    void TryMFAModal(class UEnableMultiFactorModal* BPClass); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnMatchmakingV2Changed(bool matchmakingActive); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool NeedSeeTrailerMovie(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void MarkTrailerMovieSeenByIndex(int IndexOfMovieToMarkSeen); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void MarkTrailerMovieSeen(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void HandleGiftingComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void HandleGiftBoxRemoved(bool bSuccess); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool GetTrailerMovieIndexThatNeedsToBeShownForQuest(int IndexOfMovieToShow); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool CheckForGifts(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void CheckBanStatus(bool bBanned); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    bool AttemptToOpenBattlePassTabForNewSeason(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7c59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUIStateWidget_Frontend");
			return (class UClass*)ptr;
		};

};

class UFortUIStateWidget_Login : public UFortUIStateWidget_NUI
{
	public:
	    class UFortLoginStatus* StatusScreenClass; // 0x358 Size: 0x8
	    class UFortLoginStatus* StatusScreenWidget; // 0x360 Size: 0x8
	    class UFortSplashScreenWidget* SplashScreenClass; // 0x368 Size: 0x8
	    class UFortSplashScreenWidget* SplashScreenWidget; // 0x370 Size: 0x8
	    class UFortHaveInviteSelect* HaveInviteClass; // 0x378 Size: 0x8
	    class UFortHaveInviteSelect* HaveInviteWidget; // 0x380 Size: 0x8
	    class UFortPlayedBeforeSelect* PlayedBeforeClass; // 0x388 Size: 0x8
	    class UFortPlayedBeforeSelect* PlayedBeforeWidget; // 0x390 Size: 0x8
	    class UFortLoginCredentialSelect* CredentialSelectClass; // 0x398 Size: 0x8
	    class UFortLoginCredentialSelect* CredentialSelectWidget; // 0x3a0 Size: 0x8
	    class UFortInviteRequest* InviteRequestClass; // 0x3a8 Size: 0x8
	    class UFortInviteRequest* InviteRequestWidget; // 0x3b0 Size: 0x8
	    class UFortSignInWidget* SignInScreenClass; // 0x3b8 Size: 0x8
	    class UFortSignInWidget* SignInScreenWidget; // 0x3c0 Size: 0x8
	    class UFortSignInWidget* SignInConsoleClass; // 0x3c8 Size: 0x8
	    class UFortSignInWidget* SignInConsoleWidget; // 0x3d0 Size: 0x8
	    class UFortRedirectToEpicAccountWidget* RedirectToEpicClass; // 0x3d8 Size: 0x8
	    class UFortRedirectToEpicAccountWidget* RedirectToEpicWidget; // 0x3e0 Size: 0x8
	    class UFortNewAccountWarning* NewAccountWarningClass; // 0x3e8 Size: 0x8
	    class UFortNewAccountWarning* NewAccountWarningWidget; // 0x3f0 Size: 0x8
	    class UFortLoginResultWidget* LoginResultClass; // 0x3f8 Size: 0x8
	    class UFortLoginResultWidget* LoginResultWIdget; // 0x400 Size: 0x8
	    class UFortAccountNotFound* AccountNotFoundClass; // 0x408 Size: 0x8
	    class UFortAccountNotFound* AccountNotFoundWidget; // 0x410 Size: 0x8
	    class UFortDisplayNameWidget* DisplayNameClass; // 0x418 Size: 0x8
	    class UFortDisplayNameWidget* DisplayNameWidget; // 0x420 Size: 0x8
	    class UFortMultiFactorAuthWidget* MultiFactorAuthWidgetClass; // 0x428 Size: 0x8
	    class UFortMultiFactorAuthWidget* MultiFactorAuthWidget; // 0x430 Size: 0x8
	    class UFortWebLoginWidget* WebLoginWidgetClass; // 0x438 Size: 0x8
	    class UFortHealthWarningBase* HealthWarningClass; // 0x440 Size: 0x8
	    class UFortHealthWarningBase* HealthWarningWidget; // 0x448 Size: 0x8
	    class UFortEulaWidget* EulaClass; // 0x450 Size: 0x8
	    class UFortEulaWidget* EulaWidget; // 0x458 Size: 0x8
	    struct FText BenchmarkDialogTitle; // 0x460 Size: 0x18
	    struct FText BenchmarkDialogMessage; // 0x478 Size: 0x18
	    class UFortAccountLinkingWindow* AccountLinkingWindowClass; // 0x490 Size: 0x8
	    class UFortAccountLinkingWindow* AccountLinkingWidget; // 0x498 Size: 0x8
	    struct FDataTableRowHandle BackButtonRowHandle; // 0x4a0 Size: 0x10
	    class UFortMOTDWidget* MOTDClass; // 0x4b0 Size: 0x8
	    class UFortMOTDWidget* MOTDWidget; // 0x4b8 Size: 0x8
	    char UnknownData0[0x8]; // 0x4c0
	    class UFortLoginUnavailable* LoginUnavailableClass; // 0x4c8 Size: 0x8
	    char UnknownData1[0x38]; // 0x4d0
	    class UCommonWidgetStack* LoginFlowStack; // 0x508 Size: 0x8
	    char UnknownData2[0x510]; // 0x510
	    void ShowBackBar(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetConsoleWidgetDisplayName(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SafePopFlowStackNoReturn(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    class UWidget* SafePopFlowStack(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void PushWidgetOntoFlowStack(class UWidget* Widget); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnDisplayWebLogin(class UWidget* WebWidget); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnDisplayWebAccountCreation(class UWidget* WebWidget); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void HideTopBarOptions(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    struct FText GetPlatformDisplayName(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x-7ad1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUIStateWidget_Login");
			return (class UClass*)ptr;
		};

};

class UFortUIStyleDefinitionAsset : public UDataAsset
{
	public:
	    struct FFortUIStyleDefinition StyleDefinition; // 0x30 Size: 0x9e0

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUIStyleDefinitionAsset");
			return (class UClass*)ptr;
		};

};

class UFortUpgradeDetailsBase : public UCommonUserWidget
{
	public:
	    class UMediaPlayer* VideoPlayer; // 0x230 Size: 0x8
	    class UFortUpgradeInfo* UpgradeInfo; // 0x238 Size: 0x8
	    char UnknownData0[0x240]; // 0x240
	    void RequestPurchaseNode(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnUpgradeToDetailChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnShowIcon(class UTexture2D* Icon); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnScreenActive(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnPurchaseComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7d81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUpgradeDetailsBase");
			return (class UClass*)ptr;
		};

};

class UFortUpgradeIndicator : public UFortSimpleItemConditionIconIndicator
{
	public:
	    char UnknownData0[0x460];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUpgradeIndicator");
			return (class UClass*)ptr;
		};

};

class UFortUpgradeInfo : public UObject
{
	public:
	    char UnknownData0[0x20];
	    class UFortHomebaseNodeItemDefinition* NodeItemDef; // 0x48 Size: 0x8
	    char UnknownData1[0x50]; // 0x50
	    bool IsUpgradeUnlocked(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool IsPreviewing(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    class UMediaSource* GetVideo(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    int GetUpgradeUnlockLevel(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    struct FText GetTitle(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    struct FText GetNextLevelTitle(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    struct FText GetNextLevelDescription(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    int GetNextLevel(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    int GetMaxLevel(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    struct FText GetItemName(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    struct TSoftObjectPtr<struct UTexture2D*> GetIcon(EUpgradeInfoImageSize ImageSize); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    bool GetDisplayAttributes(TArray<struct FFortDisplayAttribute> OutDisplayAttributes); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    struct FText GetDescription(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    int GetCurrentLevel(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    int GetCost(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void ForwardPreview(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    bool CanPreview(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    bool CanAffordUpgrade(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void BackwardPreview(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x-7f31];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUpgradeInfo");
			return (class UClass*)ptr;
		};

};

class UFortUpgradeScreenBase : public UCommonActivatablePanel
{
	public:
	    class UFortTabListWidgetBase* UpgradesTabSelector; // 0x318 Size: 0x8
	    class UCommonTileView* UpgradesTileView; // 0x320 Size: 0x8
	    class UCommonLoadGuard* UpgradeTileViewLoadGuard; // 0x328 Size: 0x8
	    class UFortUpgradeDetailsBase* Details; // 0x330 Size: 0x8
	    __int64/*MapProperty*/ TabToNodeTypeMap; // 0x338 Size: 0x50
	    class UFortItemDefinition* UpgradesRespecToken; // 0x388 Size: 0x8
	    char UnknownData0[0x390]; // 0x390
	    void UseUpgradesRespecToken(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void TogglePreview(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void RefreshFocus(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnUseUpgradesRespecTokenComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnUpgradeInfoChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnPurchaseNodeComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool IsPreviewing(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void HandleTabSelected(FName TabId); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    int GetUpgradesRespecTokenCount(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool CanPreview(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    bool AreUpgradesRespecTokensAvailable(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x-7c01];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUpgradeScreenBase");
			return (class UClass*)ptr;
		};

};

class UFortUpgradeTileBase : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    class UFortUpgradeInfo* UpgradeInfo; // 0xb30 Size: 0x8
	    char UnknownData1[0xb38]; // 0xb38
	    void OnDataRefresh(bool bUpgrade); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-74a9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUpgradeTileBase");
			return (class UClass*)ptr;
		};

};

class UFortUserChoiceWidget : public UFortUserWidget
{
	public:
	    void SetChoices(struct FChoiceData ChoiceItems); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7da9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortUserChoiceWidget");
			return (class UClass*)ptr;
		};

};

class UFortVariantEditorWidgetBase : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x298];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortVariantEditorWidgetBase");
			return (class UClass*)ptr;
		};

};

class UFortVariantEntryBox : public UDynamicEntryBox
{
	public:
	    class UAthenaCosmeticAccountItem* CurrentItem; // 0x1d0 Size: 0x8
	    class UAthenaCosmeticItemDefinition* CurrentItemDef; // 0x1d8 Size: 0x8
	    TArray<struct FMcpVariantChannelInfo> CurrentItemVariants; // 0x1e0 Size: 0x10
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortVariantEntryBox");
			return (class UClass*)ptr;
		};

};

class UFortVariantNumericalPicker : public UFortVariantEditorWidgetBase
{
	public:
	    int MinNum; // 0x298 Size: 0x4
	    int MaxNum; // 0x29c Size: 0x4
	    int NumericDelta; // 0x2a0 Size: 0x4
	    int CurrentNumber; // 0x2a4 Size: 0x4
	    class UFortCosmeticNumericalVariant* NumericalVariant; // 0x2a8 Size: 0x8
	    class UCommonButton* Button_ZeroDigitUp; // 0x2b0 Size: 0x8
	    class UCommonButton* Button_ZeroDigitDown; // 0x2b8 Size: 0x8
	    class UCommonButton* Button_TenDigitUp; // 0x2c0 Size: 0x8
	    class UCommonButton* Button_TenDigitDown; // 0x2c8 Size: 0x8
	    class UCommonTextBlock* Text_NumericalValue; // 0x2d0 Size: 0x8
	    class UCommonTextBlock* Text_VariantName; // 0x2d8 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortVariantNumericalPicker");
			return (class UClass*)ptr;
		};

};

class UFortVariantPicker : public UCommonUserWidget
{
	public:
	    MulticastDelegateProperty OnVariantChanged; // 0x230 Size: 0x10
	    class UScrollBox* ScrollBox_Variants; // 0x240 Size: 0x8
	    class UFortVariantEntryBox* EntryBox_VariantOptions; // 0x248 Size: 0x8
	    char UnknownData0[0x250]; // 0x250
	    void InitFromCosmeticItemDef(class UAthenaCosmeticItemDefinition* InCosmeticItemDef); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void InitFromCosmeticItem(class UAthenaCosmeticAccountItem* InCosmeticItem); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7d91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortVariantPicker");
			return (class UClass*)ptr;
		};

};

class UVariantObject : public UObject
{
	public:
	    struct FGameplayTag VariantChannel; // 0x28 Size: 0x8
	    struct FGameplayTag VariantTag; // 0x30 Size: 0x8
	    bool bOwned; // 0x38 Size: 0x1
	    char UnknownData0[0x7]; // 0x39
	    class UAthenaCosmeticItemDefinition* CosmeticDef; // 0x40 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.VariantObject");
			return (class UClass*)ptr;
		};

};

class UFortVariantTileButton : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    struct FLinearColor LockedTintColor; // 0xb30 Size: 0x10
	    FName IconParamName; // 0xb40 Size: 0x8
	    class UVariantObject* SourceObject; // 0xb48 Size: 0x8
	    class UImage* Image_VariantDisplay; // 0xb50 Size: 0x8
	    class UImage* Image_Locked; // 0xb58 Size: 0x8
	    class UImage* Image_Active; // 0xb60 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortVariantTileButton");
			return (class UClass*)ptr;
		};

};

class UFortVariantTileSelector : public UFortVariantEditorWidgetBase
{
	public:
	    char UnknownData0[0x8];
	    class UCommonTileView* Tile_VariantOptions; // 0x2a0 Size: 0x8
	    class UCommonTextBlock* Text_VariantName; // 0x2a8 Size: 0x8
	    class UVariantObject* CurrentSelectedVariant; // 0x2b0 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortVariantTileSelector");
			return (class UClass*)ptr;
		};

};

class UFortVehicleInfoIndicatorWidget : public UFortActorIndicatorWidget
{
	public:
	    TWeakObjectPtr<AFortAthenaVehicle*> CurrentVehicle; // 0x290 Size: 0x8
	    float TimeToHideWhenDamaged; // 0x298 Size: 0x4
	    char UnknownData0[0x29c]; // 0x29c
	    void SetVehicle(class AFortAthenaVehicle* NewVehicle); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnVehicleHealthChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnVehicleChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortVehicleInfoIndicatorWidget");
			return (class UClass*)ptr;
		};

};

class UFortVideoDisplayData : public UDataAsset
{
	public:
	    class UMediaPlayer* FortVideoPlayer; // 0x30 Size: 0x8
	    class UFortMediaSubtitlesPlayer* SubtitlePlayer; // 0x38 Size: 0x8
	    __int64/*MapProperty*/ LocaleAudioTrackIndexMap; // 0x40 Size: 0x50
	    TArray<struct FFortVideoInfo> Videos; // 0x90 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortVideoDisplayData");
			return (class UClass*)ptr;
		};

};

class UFortVideoOptions : public UFortOptionsTab
{
	public:
	    char UnknownData0[0x280];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortVideoOptions");
			return (class UClass*)ptr;
		};

};

class UFortVideoPlayerWidget : public UFortUserWidget
{
	public:
	    bool bAutoPlayOnOpen; // 0x238 Size: 0x1
	    bool bLoop; // 0x239 Size: 0x1
	    bool bShowSubtitles; // 0x23a Size: 0x1
	    bool bNoAudio; // 0x23b Size: 0x1
	    char UnknownData0[0x74]; // 0x23c
	    class UMediaPlayer* VideoPlayer; // 0x2b0 Size: 0x8
	    class UMediaSoundComponent* SoundComponent; // 0x2b8 Size: 0x8
	    class UFortMediaSubtitlesPlayer* SubtitlePlayer; // 0x2c0 Size: 0x8
	    class UImage* Image_VideoTexture; // 0x2c8 Size: 0x8
	    class USubtitleDisplay* Subtitles; // 0x2d0 Size: 0x8
	    char UnknownData1[0x2d8]; // 0x2d8
	    void DynamicHandleOnOpenMediaFailed(struct FString FailedUrl); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void DynamicHandleOnMediaOpened(struct FString OpenedUrl); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d09];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortVideoPlayerWidget");
			return (class UClass*)ptr;
		};

};

class UFortVisualAttachment : public USizeBox
{
	public:
	    char UnknownData0[0x148];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortVisualAttachment");
			return (class UClass*)ptr;
		};

};

class UFortVoiceChatStatusIcon : public UWidget
{
	public:
	    struct FVector2D DesiredSize; // 0x100 Size: 0x8
	    struct FSlateBrush StatusBrush; // 0x108 Size: 0x88
	    char UnknownData0[0x50];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortVoiceChatStatusIcon");
			return (class UClass*)ptr;
		};

};

class UFortWebLoginWidget : public UCommonActivatablePanel
{
	public:
	    void DisplayWidget(class UWidget* WebWidget); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void DismissWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7cc1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortWebLoginWidget");
			return (class UClass*)ptr;
		};

};

class UFortWorkerSetBonusIcon : public UCommonUserWidget
{
	public:
	    struct FGameplayTag GameplayTag; // 0x230 Size: 0x8
	    char ImageSize; // 0x238 Size: 0x1
	    char UnknownData0[0x7]; // 0x239
	    class UImage* Icon; // 0x240 Size: 0x8
	    char UnknownData1[0x248]; // 0x248
	    void SetGameplayTag(struct FGameplayTag InGameplayTag); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void HandleDifferentGameplayTagSetBP(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortWorkerSetBonusIcon");
			return (class UClass*)ptr;
		};

};

class UFriendCodeEntryBase : public UCommonButton
{
	public:
	    char UnknownData0[0xb28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FriendCodeEntryBase");
			return (class UClass*)ptr;
		};

};

class UFriendCodeListBase : public UCommonActivatablePanel
{
	public:
	    char UnknownData0[0x318];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FriendCodeListBase");
			return (class UClass*)ptr;
		};

};

class UFriendCodeShareButtonBase : public UCommonButton
{
	public:
	    TArray<struct FFriendCode> BacchusFriendCodes; // 0xb28 Size: 0x10
	    class UFortFriendCodeListBase* FriendCodeListClass; // 0xb38 Size: 0x8
	    class UCommonTextBlock* NumSharesRemainingText; // 0xb40 Size: 0x8
	    class UTextBlock* InviteCodeMessage; // 0xb48 Size: 0x8
	    char UnknownData0[0xb50]; // 0xb50
	    void OnQueryUnredeemedFriendCodesComplete(bool bSuccess, TArray<struct FFriendCode> FriendCodes); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnNumSharesUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnFriendCodeIssued(bool bSuccess, struct FFriendCode FriendCode); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7481];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FriendCodeShareButtonBase");
			return (class UClass*)ptr;
		};

};

class UHeistWidgetBase : public UFortHUDElementWidget
{
	public:
	    char UnknownData0[0x20];
	    EHeistExitCraftUIState CurrExitCraftUIState; // 0x278 Size: 0x1
	    bool bDisplayBlingRow; // 0x279 Size: 0x1
	    bool bCanDisplayVanUI; // 0x27a Size: 0x1
	    char UnknownData1[0x1]; // 0x27b
	    struct FGameplayTag SafeSupplyDropTag; // 0x27c Size: 0x8
	    struct FGameplayTag BlingItemTag; // 0x284 Size: 0x8
	    struct FGameplayTag CarryingBlingItemTag; // 0x28c Size: 0x8
	    int CurrBlingSupplyDropCount; // 0x294 Size: 0x4
	    int CurrBlingItemCount; // 0x298 Size: 0x4
	    int CurrBlingEnemyCount; // 0x29c Size: 0x4
	    int CurrBlingAllyCount; // 0x2a0 Size: 0x4
	    char UnknownData2[0x2a4]; // 0x2a4
	    void UpdateAllUI(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetExitCraftUIState(EHeistExitCraftUIState NewState); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnUpdateStateTimeText(struct FText TimeText, EHeistExitCraftUIState CurrState); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnUpdateStateText(struct FText StateText, EHeistExitCraftUIState CurrState); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnUpdateExitCraftIcon(struct FHeistExitCraftIconData ExitCraftIconData); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnUpdateBlingIcon(struct FHeistBlingIconData BlingIconData); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnSpecialActorRemoved(struct FSpecialActorRepData SpecialActorData); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnSpecialActorAdded(struct FSpecialActorRepData SpecialActorData); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnMutatorObjectUpdated(struct FGameplayMutatorObjectDataArray MutatorArray); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void OnHandleSpectatingChanged(class AFortPlayerStateZone* SpectatingTarget); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void OnExitCraftsUIChanged(EHeistExitCraftUIState NewState); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void OnDisplayExitCraftUI(bool bDisplay); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void OnDisplayBlingUI(bool bDisplay); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x-7d29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.HeistWidgetBase");
			return (class UClass*)ptr;
		};

};

class UHUDLayoutToolButtonLayer : public UCommonUserWidget
{
	public:
	    class UCanvasPanel* CanvasPanel_Combat; // 0x230 Size: 0x8
	    class UCanvasPanel* CanvasPanel_Build; // 0x238 Size: 0x8
	    class UCanvasPanel* CanvasPanel_Persistent; // 0x240 Size: 0x8
	    class USizeBox* InternalSizeBox; // 0x248 Size: 0x8
	    TArray<class UHUDLayoutToolPlacementWidget*> PlacementWidgets; // 0x250 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.HUDLayoutToolButtonLayer");
			return (class UClass*)ptr;
		};

};

class UHUDLayoutToolContext : public UBlueprintContextBase
{
	public:
	    char UnknownData0[0x8];
	    MulticastDelegateProperty OnPropertyMenuStateChangeDelegate; // 0x30 Size: 0x10
	    MulticastDelegateProperty OnCloseLayoutTool; // 0x40 Size: 0x10
	    MulticastDelegateProperty OnOpenLayoutToolDelegate; // 0x50 Size: 0x10
	    MulticastDelegateProperty OnRecenterPressedDelegate; // 0x60 Size: 0x10
	    MulticastDelegateProperty OnLayoutDirtyUpdated; // 0x70 Size: 0x10
	    MulticastDelegateProperty OnViewOffsetUpdatedDelegate; // 0x80 Size: 0x10
	    MulticastDelegateProperty OnNewViewOffsetLerpDelegate; // 0x90 Size: 0x10
	    MulticastDelegateProperty OnHUDLayoutModeChangeDelegate; // 0xa0 Size: 0x10
	    MulticastDelegateProperty OnWidgetSelectedDelegate; // 0xb0 Size: 0x10
	    MulticastDelegateProperty OnOpenCloseFireModePanelDelegate; // 0xc0 Size: 0x10
	    MulticastDelegateProperty OnFireModeChangeDelegate; // 0xd0 Size: 0x10
	    int HudLayoutSnappingDistance; // 0xe0 Size: 0x4
	    char UnknownData1[0xe4]; // 0xe4
	    void StartLerping(struct FVector2D NewViewOffset); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool ShouldShowSelectedWidgetProperties(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetSelectedWidget(class UHUDLayoutToolPlacementWidget* NewSelectedWidget); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetPropertyMenuState(bool bNewlyOpen); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetLayoutVisibility(bool bShowCombat, bool bShowBuild, bool bShowEdit, bool bShowCreative); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetFireModeOpenState(bool bNewlyOpened); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetFireMode(EFireModeType NewFireMode); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetCustomFireMode(bool bAutofireEnabled, bool bForceTouchEnabled, bool bTapToShootEnabled, bool bAlwaysShowDedicatedButton); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SaveLayout(ELayoutDataType LayoutType, struct FString Reason); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void ResetSelectedWidgetProperties(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void ResetDirtyWidgets(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void ResetAllWidgets(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void OnViewOffsetUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void OnToolOpened(struct FString Reason); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void OnRecenterPressed(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void OnPanZoomWidgetClick(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void LoadLayout(ELayoutDataType LayoutType, struct FString Reason); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    bool IsSelectedWidgetUnderPanel(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    bool IsLayoutDirty(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    bool IsFireModeAvailable(EFireModeType NewFireMode); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    bool IsCentered(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    bool HasSelectedWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    bool HasSavedLayout(ELayoutDataType LayoutType); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    bool GetPropertyMenuState(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    bool GetIsPanning(); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    bool GetIsLerping(); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    bool GetFireModeOpenState(); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void GetFireMode(EFireModeType FireMode, bool bAutofireEnabled, bool bForceTouchEnabled, bool bTapToShootEnabled, bool bAlwaysShowDedicatedButton); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    struct FVector2D GetCurrentOffset(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    void CloseLayoutTool(struct FString Reason); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    void ClearLayout(ELayoutDataType LayoutType, struct FString Reason); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x-7e19];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.HUDLayoutToolContext");
			return (class UClass*)ptr;
		};

};

class UHUDLayoutToolFireModePanel : public UFortActivatablePanel
{
	public:
	    bool bSkipFireModeOptionTutorial; // 0x340 Size: 0x1
	    char UnknownData0[0x7]; // 0x341
	    TArray<class UHUDLayoutToolFireModeButton*> FireModeButtons; // 0x348 Size: 0x10
	    char UnknownData1[0x358]; // 0x358
	    void SetOpenState(bool bNewOpenState); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7c89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.HUDLayoutToolFireModePanel");
			return (class UClass*)ptr;
		};

};

class UHUDLayoutToolFireModeButton : public UCommonUserWidget
{
	public:
	    EFireModeType FireModeType; // 0x230 Size: 0x1
	    char UnknownData0[0x7]; // 0x231
	    struct FText FireModeName; // 0x238 Size: 0x18
	    struct FText FireModeDescription; // 0x250 Size: 0x18
	    class UTexture2D* FireModeImage; // 0x268 Size: 0x8
	    class UCommonButton* SelectionButton; // 0x270 Size: 0x8
	    class UFortMovieWidget* MovieWidget; // 0x278 Size: 0x8
	    char UnknownData1[0x280]; // 0x280
	    void OnSelected(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnDeselected(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    EFireModeType GetFireModeType(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    struct FText GetFireModeDescription(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7d61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.HUDLayoutToolFireModeButton");
			return (class UClass*)ptr;
		};

};

class UHUDLayoutToolInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.HUDLayoutToolInterface");
			return (class UClass*)ptr;
		};

};

class UHUDLayoutToolPanZoomWidget : public UContentWidget
{
	public:
	    float LerpSpeed; // 0x118 Size: 0x4
	    float RecenterRadius; // 0x11c Size: 0x4
	    char UnknownData0[0x120]; // 0x120
	    void StopOffsetLerp(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void StartOffsetLerp(struct FVector2D NewTargetOffset); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void Recenter(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7e09];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.HUDLayoutToolPanZoomWidget");
			return (class UClass*)ptr;
		};

};

class UHUDLayoutToolPanZoomWidgetSlot : public UPanelSlot
{
	public:
	    char UnknownData0[0x48];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.HUDLayoutToolPanZoomWidgetSlot");
			return (class UClass*)ptr;
		};

};

class UHUDLayoutToolPlacementWidget : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x8];
	    bool bCanMoveWidget; // 0x238 Size: 0x1
	    char UnknownData1[0x7]; // 0x239
	    class UBacchusHUDElement* HUDElementClass; // 0x240 Size: 0x8
	    struct FGameplayTag HUDElementTagOverride; // 0x248 Size: 0x8
	    bool bIsBlockingWidget; // 0x250 Size: 0x1
	    char UnknownData2[0x7]; // 0x251
	    class UBorder* SelectionBorder; // 0x258 Size: 0x8
	    class UBorder* DisplayScaleBorder; // 0x260 Size: 0x8
	    class UOverlay* MainOverlay; // 0x268 Size: 0x8
	    bool bCanEditVisibilityOverride; // 0x270 Size: 0x1
	    char UnknownData3[0x3]; // 0x271
	    float Property_0; // 0x274 Size: 0x4
	    float Property_1; // 0x278 Size: 0x4
	    float Property_2; // 0x27c Size: 0x4
	    float Property_3; // 0x280 Size: 0x4
	    char UnknownData4[0x4]; // 0x284
	    struct FHUDLayoutDataEntry DefaultEntry; // 0x288 Size: 0xe0
	    class UBacchusHUDElement* BacchusHUDElement; // 0x368 Size: 0x8
	    char UnknownData5[0x370]; // 0x370
	    void OnWidgetSelected(class UHUDLayoutToolPlacementWidget* InSelectedWidget); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnLayoutVisibilityChanged(bool bShowCombat, bool bShowBuild, bool bShowEdit, bool bShowCreative); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnInsideGridStateChange(bool bInsideGrid); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool IsInsideGrid(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool GetIsOverlapping(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    bool CanEditVisibility(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    struct FGameplayTag BP_GetMobileVisualType(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7c11];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.HUDLayoutToolPlacementWidget");
			return (class UClass*)ptr;
		};

};

class UHUDLayoutToolPropertyPanel : public UCommonUserWidget
{
	public:
	    struct FText DefaultTitle; // 0x230 Size: 0x18
	    class UCommonTextBlock* PanelTitle; // 0x248 Size: 0x8
	    char UnknownData0[0x250]; // 0x250
	    void OnWidgetSelected(class UHUDLayoutToolPlacementWidget* NewlySelectedWidget); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnOpen(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnMenuStateChange(bool bNewlyOpen); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnClose(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool GetIsOpen(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7d81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.HUDLayoutToolPropertyPanel");
			return (class UClass*)ptr;
		};

};

class UHUDLayoutToolPropertyWidget : public UCommonUserWidget
{
	public:
	    class UAnalogSlider* MySlider; // 0x230 Size: 0x8
	    class UCommonTextBlock* Text_PropertyName; // 0x238 Size: 0x8
	    class UCommonTextBlock* Text_PropertyValue; // 0x240 Size: 0x8
	    int PropertyIndex; // 0x248 Size: 0x4
	    TWeakObjectPtr<UHUDLayoutToolPlacementWidget*> CurrentWidget; // 0x24c Size: 0x8
	    char UnknownData0[0x254]; // 0x254
	    void SetPropertyType(ELayoutPropertyType NewPropertyType); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetBoolValue(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void RefreshProperties(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnWidgetSelected(class UHUDLayoutToolPlacementWidget* NewlySelectedWidget); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnNewSliderValue(float NormalizedValue); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnNewRotatorValue(int NormalizedValue); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnNewBoolValue(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    TArray<struct FText> GetRotatorLabels(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    int GetCurrentValueAsInt(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool GetCurrentValueAsBool(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    float GetCurrentValue(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x-7d81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.HUDLayoutToolPropertyWidget");
			return (class UClass*)ptr;
		};

};

class UHUDLayoutToolProxy : public UBacchusHUDElement
{
	public:
	    void BP_SetPropertyValue(int PropertyIndex, float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    struct FText BP_GetWidgetName(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    float BP_GetPropertyValue(int PropertyIndex); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    ELayoutPropertyType BP_GetPropertyType(int PropertyIndex); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void BP_GetPropertyRange(int PropertyIndex, float OutMin, float OutMax); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    struct FText BP_GetPropertyName(int PropertyIndex); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    int BP_GetNumOfProperties(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    TArray<struct FText> BP_GetMultiOptionLabels(int PropertyIndex); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7c61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.HUDLayoutToolProxy");
			return (class UClass*)ptr;
		};

};

class UHUDLayoutToolVisibilityWidget : public UCommonUserWidget
{
	public:
	    class UCommonButton* CombatVisibilityButton; // 0x230 Size: 0x8
	    class UCommonButton* BuildVisibilityButton; // 0x238 Size: 0x8
	    class UCommonButton* EditVisibilityButton; // 0x240 Size: 0x8
	    class UCommonButton* CreativeVisibilityButton; // 0x248 Size: 0x8
	    TWeakObjectPtr<UHUDLayoutToolPlacementWidget*> CurrentWidget; // 0x250 Size: 0x8
	    char UnknownData0[0x258]; // 0x258
	    void Refresh(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnWidgetSelected(class UHUDLayoutToolPlacementWidget* NewlySelectedWidget); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnEditClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnCreativeClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnCombatClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnBuildClicked(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void GetVisibilities(EBacchusHUDStateType CombatVisibility, EBacchusHUDStateType BuildVisibility, EBacchusHUDStateType EditVisibility, EBacchusHUDStateType CreativeVisibility); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7d89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.HUDLayoutToolVisibilityWidget");
			return (class UClass*)ptr;
		};

};

class UIconTextButtonSpectatorBase : public UCommonButton
{
	public:
	    void SetText(struct FText Text); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-74b9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.IconTextButtonSpectatorBase");
			return (class UClass*)ptr;
		};

};

class UMassiveGadgetEquippedWidget : public UCommonUserWidget
{
	public:
	    void HandleMassiveTagChanged(struct FGameplayTag Tag, int Count); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7db1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.MassiveGadgetEquippedWidget");
			return (class UClass*)ptr;
		};

};

class UMatchmakingInputIndicatorBase : public UCommonUserWidget
{
	public:
	    EMatchmakingInputSource InputSource; // 0x230 Size: 0x1
	    bool bShowLocalInputOnlyWhenDifferentFromDefault; // 0x231 Size: 0x1
	    bool bShowRemoteInputOnlyWhenDifferentFromDefault; // 0x232 Size: 0x1
	    char UnknownData0[0x5]; // 0x233
	    struct FUniqueNetIdRepl RemotePlayerUniqueId; // 0x238 Size: 0x28
	    ECommonInputType LastInputType; // 0x260 Size: 0x1
	    char UnknownData1[0x261]; // 0x261
	    void SetRemotePlayer(struct FUniqueNetIdRepl UniqueId); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnInputSourceTypeChanged(ECommonInputType InputType); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.MatchmakingInputIndicatorBase");
			return (class UClass*)ptr;
		};

};

class UMatchmakingRegionAndPoolBase : public UUserWidget
{
	public:
	    char UnknownData0[0x228];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.MatchmakingRegionAndPoolBase");
			return (class UClass*)ptr;
		};

};

class UMinigameWidgetBase : public UFortHUDElementWidget
{
	public:
	    bool bDisplayCaptureObjectiveRow; // 0x258 Size: 0x1
	    char UnknownData0[0x7]; // 0x259
	    class AFortMinigame* CurrentMinigame; // 0x260 Size: 0x8
	    char UnknownData1[0x268]; // 0x268
	    void ResetDisplayValues(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnStopExitingVolume(class APlayerState* ClientState, class AFortVolume* ExitedVolume); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnPlayerStatUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnObjectiveUpdated(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnExitVolume(class APlayerState* ClientState, class AFortVolume* ExitedVolume); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnExitingVolume(class APlayerState* ClientState, class AFortVolume* ExitingVolume); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnEnteredVolume(class APlayerState* ClientState, class AFortVolume* EnteredVolume); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnDisplayMinigameStartUI(bool bDisplay); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnDisplayMinigameEndUI(bool bDisplay); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnDisplayMiniGameAbortUI(bool bDisplay); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void OnDisplayLeavingVolumeUI(bool bDisplay); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void OnDisplayCaptureObjectiveUI(bool bDisplay); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void OnCurrentStateChangedDelegate(EFortMinigameState MinigameState); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    static struct FAthenaGameMessageData MakeMessageData(EAthenaGameMsgType MsgType, struct FText MsgText, class USoundCue* MsgSound, float DisplayTime); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void HideAllMinigameWidgetUI(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x-7d69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.MinigameWidgetBase");
			return (class UClass*)ptr;
		};

};

class UMobileHUDVisual : public UCommonUserWidget
{
	public:
	    struct FGameplayTag VisualType; // 0x230 Size: 0x8
	    float Opacity; // 0x238 Size: 0x4
	    char UnknownData0[0x23c]; // 0x23c
	    struct FGameplayTag GetVisualType(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7da1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.MobileHUDVisual");
			return (class UClass*)ptr;
		};

};

class UMobileHUDButtonVisual : public UMobileHUDVisual
{
	public:
	    float ButtonSize; // 0x240 Size: 0x4
	    float ButtonDisplayScale; // 0x244 Size: 0x4
	    class UPaperSprite* DefaultIcon; // 0x248 Size: 0x8
	    class USizeBox* OuterSizeBox; // 0x250 Size: 0x8
	    class USizeBox* InnerSizeBox; // 0x258 Size: 0x8
	    class UImage* Image_Icon; // 0x260 Size: 0x8
	    char UnknownData0[0x268]; // 0x268
	    void SetButtonSprite(class UPaperSprite* NewSprite); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7d79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.MobileHUDButtonVisual");
			return (class UClass*)ptr;
		};

};

class UFortQuestScreen : public UFortActivatablePanel
{
	public:
	    void ProcessPendingSeenQuestItems(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7ca1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortQuestScreen");
			return (class UClass*)ptr;
		};

};

class URemoteControlledPawnExpirationWidget : public UFortHUDElementWidget
{
	public:
	    class UImage* ExpirationProgressImage; // 0x258 Size: 0x8
	    char UnknownData0[0x260]; // 0x260
	    void OnPawnChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7d79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.RemoteControlledPawnExpirationWidget");
			return (class UClass*)ptr;
		};

};

class UFortSeasonPassLevelInfo : public UObject
{
	public:
	    char UnknownData0[0x8];
	    class AFortPlayerController* FortPC; // 0x30 Size: 0x8
	    class UAthenaSeasonItemDefinition* SeasonData; // 0x38 Size: 0x8
	    char UnknownData1[0x40]; // 0x40
	    bool IsPaidUnlocked(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool IsPaidClaimed(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool IsFreeUnlocked(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool IsFreeClaimed(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    int GetSeasonPassMaxLevel(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    TArray<class UFortItem*> GetRewardItems(EAthenaSeasonRewardTrack Track); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    int GetNumRewardItems(EAthenaSeasonRewardTrack Track); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    float GetLevelProgress(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    int GetLevel(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    bool ContainsChaseReward(EAthenaSeasonRewardTrack Track); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x-7fa1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.FortSeasonPassLevelInfo");
			return (class UClass*)ptr;
		};

};

class USeasonPassLevelWidget : public UCommonUserWidget
{
	public:
	    char UnknownData0[0x10];
	    class UFortSeasonPassLevelInfo* LevelInfo; // 0x240 Size: 0x8
	    char UnknownData1[0x248]; // 0x248
	    void PlayIntro(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnSetup(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnNavigateTo(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnLockedStatusChanged(bool FreeUnlocked, bool PaidUnlocked); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnAttemptClaimFinished(bool FreeClaimed, bool PaidClaimed); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    class UFortSeasonPassLevelInfo* GetLevelInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void AttemptClaim(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7d99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.SeasonPassLevelWidget");
			return (class UClass*)ptr;
		};

};

class USeasonPassLevelPanel : public UCommonActivatablePanel
{
	public:
	    char UnknownData0[0x10];
	    class UFortSeasonPassLevelInfo* LevelInfo; // 0x328 Size: 0x8
	    char UnknownData1[0x330]; // 0x330
	    void Setup(class UFortSeasonPassLevelInfo* Info); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnSetup(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnLockedStatusChanged(bool FreeUnlocked, bool PaidUnlocked); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    class UFortSeasonPassLevelInfo* GetLevelInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7cb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.SeasonPassLevelPanel");
			return (class UClass*)ptr;
		};

};

class USeasonPassPageWidget : public UCommonUserWidget
{
	public:
	    bool ShouldPlayInto(int FirstLevel); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void ScreenShown(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool OwnsSeasonPass(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnBattlePassChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void NavigatePageRight(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void NavigatePageLeft(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    int GetCurrentSeasonNumber(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool ContainsLevel(int Level); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7d99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.SeasonPassPageWidget");
			return (class UClass*)ptr;
		};

};

class USeasonPassScreenBase : public UFortActivatablePanelWithItemPreview
{
	public:
	    char UnknownData0[0x8];
	    class UAthenaSeasonItemDefinition* SeasonData; // 0x440 Size: 0x8
	    TArray<class USeasonPassLevelWidget*> LevelWidgets; // 0x448 Size: 0x10
	    __int64/*MapProperty*/ LevelInfos; // 0x458 Size: 0x50
	    char UnknownData1[0x4a8]; // 0x4a8
	    void UpdateStoreHasStarsNotification(bool bShowNotification); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool ShouldOpenAboutScreen(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void ScrollPositive(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void ScrollNegative(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool PurchaseAvailible(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool OwnsSeasonPass(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnSetGiftability(bool bIsGiftable); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnSeasonPassChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnNoCurrentSeason(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnNavigateToLevel(int Level); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void OnLevelsGenerated(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void NavigateToLevel(int Level); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    int GetSeasonPassLevelMax(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    int GetSeasonPassLevel(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    struct FDateTime GetSeasonEndDate(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    class UFortSeasonPassLevelInfo* GetLevelInfo(int Level); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    __int64/*MapProperty*/ GetAllLevelInfos(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    TArray<class USeasonPassLevelWidget*> GenerateLevelWidgets(class UFortSeasonPassLevelInfo* LevelInfo); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x-7b39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.SeasonPassScreenBase");
			return (class UClass*)ptr;
		};

};

class USeasonRewardsGridWidget : public UWidget
{
	public:
	    class UUserWidget* ItemWidgetToCreate; // 0x100 Size: 0x8
	    MulticastDelegateProperty OnItemWidgetCreated; // 0x108 Size: 0x10
	    struct FMargin ItemPadding; // 0x118 Size: 0x10
	    struct FMargin ColumnPadding; // 0x128 Size: 0x10
	    float ScrollSpeed; // 0x138 Size: 0x4
	    char UnknownData0[0x13c]; // 0x13c
	    void Populate(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7e81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.SeasonRewardsGridWidget");
			return (class UClass*)ptr;
		};

};

class UStoreToastRequest : public UObject
{
	public:
	    char UnknownData0[0x10];
	    class UCatalogMessaging* CatalogMessaging; // 0x38 Size: 0x8
	    char UnknownData1[0x40]; // 0x40
	    void SkipRequest(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool ShouldBeginRequest(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool IsRequestReady(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    struct FStoreCallout GetToast(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void CompleteRequest(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void BeginRequest(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7ef9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.StoreToastRequest");
			return (class UClass*)ptr;
		};

};

class UTryHardCountdownWidget : public UFortHUDElementWidget
{
	public:
	    char UnknownData0[0x8];
	    int NumToStartShowingAt; // 0x260 Size: 0x4
	    char UnknownData1[0x264]; // 0x264
	    void UpdateNumber(int NumRemaining); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void ShowWidget(int NumRemaining); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnHandleSpectatingChanged(class AFortPlayerStateZone* SpectatingTarget); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnGamePhaseStepChanged(EAthenaGamePhaseStep GamePhaseStep); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool IsShowing(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void HideWidget(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7d71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.TryHardCountdownWidget");
			return (class UClass*)ptr;
		};

};

class UTwoTeamScoreWidgetBase : public UFortHUDElementWidget
{
	public:
	    char UnknownData0[0x28];
	    TArray<float> PlayScoreProgressSoundPercentagesMild; // 0x280 Size: 0x10
	    TArray<float> PlayScoreProgressSoundPercentagesMedium; // 0x290 Size: 0x10
	    TArray<float> PlayScoreProgressSoundPercentagesStrong; // 0x2a0 Size: 0x10
	    float PercentageScoreToPlayCountdown; // 0x2b0 Size: 0x4
	    float PercentageScoreToPlayFinalCountdown; // 0x2b4 Size: 0x4
	    float ScoreCountdownSoundFrequency; // 0x2b8 Size: 0x4
	    char LastViewedTeam; // 0x2bc Size: 0x1
	    char UnknownData1[0x2bd]; // 0x2bd
	    void UpdateAllUI(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnUpdateTotalScore(struct FText TotalScoreText); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnUpdateTeamScore(int TeamIndex, struct FTDMTeamScoreData ScoreData); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnPlayScoreProgressSound(ETDMScoreProgressTypes ScoreProgressType, bool bIsLocalTeam); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnHandleSpectatingChanged(class AFortPlayerStateZone* SpectatingTarget); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnGamePhaseChanged(EAthenaGamePhase GamePhase); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void OnCountdownTimerUpdate(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7d21];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.TwoTeamScoreWidgetBase");
			return (class UClass*)ptr;
		};

};

class UWeaponOverheatWidget : public UFortHUDElementWidget
{
	public:
	    class UImage* OverheatProgressImage; // 0x258 Size: 0x8
	    char UnknownData0[0x260]; // 0x260
	    void OnWeaponUnEquipped(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnWeaponEquipped(class AFortWeapon* CurrentWeapon, class AFortWeapon* PrevWeapon); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnPawnChanged(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/FortniteUI.WeaponOverheatWidget");
			return (class UClass*)ptr;
		};

};


}