#pragma once

#include "../SDK.hpp"

namespace SDK {


class UEpicCMSImage : public UCommonLazyImage
{
	public:
	    MulticastDelegateProperty OnImageLoadingComplete; // 0x2c8 Size: 0x10
	    struct FSlateBrush LoadingFailFallback; // 0x2d8 Size: 0x88
	    class UTexture2D* ExternalMedia; // 0x360 Size: 0x8
	    bool bDownloadingExternalMedia; // 0x368 Size: 0x1
	    char UnknownData0[0xf];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EpicCMSUIFramework.EpicCMSImage");
			return (class UClass*)ptr;
		};

};

class UEpicCMSLayoutBase : public UUserWidget
{
	public:
	    TArray<struct FSlotDescription> CarouselSlotDescriptions; // 0x228 Size: 0x10
	    class UEpicCMSTileCarousel* CarouselClass; // 0x238 Size: 0x8
	    char UnknownData0[0x50];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EpicCMSUIFramework.EpicCMSLayoutBase");
			return (class UClass*)ptr;
		};

};

class UEpicCMSManager : public UObject
{
	public:
	    char UnknownData0[0x18];
	    struct FString CmsEndpointOverride; // 0x40 Size: 0x10
	    bool bRefreshing; // 0x50 Size: 0x1
	    char UnknownData1[0x5f];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EpicCMSUIFramework.EpicCMSManager");
			return (class UClass*)ptr;
		};

};

class UEpicCMSScreenBase : public UCommonActivatablePanel
{
	public:
	    struct FString TileSetFieldName; // 0x318 Size: 0x10
	    struct TSoftObjectPtr<struct UDataTable*> TileTypeToTileClassDataTable; // 0x328 Size: 0x28
	    __int64/*SoftClassProperty*/ LayoutErrorClass; // 0x350 Size: 0x28
	    struct TSoftObjectPtr<struct UDataTable*> LayoutTypeToLayoutClassDataTable; // 0x378 Size: 0x28
	    char UnknownData0[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EpicCMSUIFramework.EpicCMSScreenBase");
			return (class UClass*)ptr;
		};

};

class UEpicCMSSimpleMessage : public UCommonUserWidget
{
	public:
	    class UCommonTextBlock* TitleText; // 0x230 Size: 0x8
	    class UCommonTextBlock* BodyText; // 0x238 Size: 0x8
	    class UEpicCMSImage* PrimaryImage; // 0x240 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EpicCMSUIFramework.EpicCMSSimpleMessage");
			return (class UClass*)ptr;
		};

};

class UEpicCMSTileBase : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    class UCommonTextStyle* DefaultTitleTextStyle; // 0xb30 Size: 0x8
	    class UCommonTextStyle* FeaturedTitleTextStyle; // 0xb38 Size: 0x8
	    struct FText Title; // 0xb40 Size: 0x18
	    struct FString Link; // 0xb58 Size: 0x10
	    bool bDownloadingExternalMedia; // 0xb68 Size: 0x1
	    bool bRefreshingMcpCatalog; // 0xb69 Size: 0x1
	    char UnknownData1[0x6]; // 0xb6a
	    class UTexture2D* ExternalMedia; // 0xb70 Size: 0x8
	    char UnknownData2[0xa0]; // 0xb78
	    class UCommonLazyImage* LazyImage_Icon; // 0xc18 Size: 0x8
	    class UCommonTextBlock* TitleTextBlock; // 0xc20 Size: 0x8
	    class UCommonTextBlock* SubtitleTextBlock; // 0xc28 Size: 0x8
	    class UCommonTextBlock* EyebrowTextBlock; // 0xc30 Size: 0x8
	    char UnknownData3[0xc38]; // 0xc38
	    void Launch(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-73a9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EpicCMSUIFramework.EpicCMSTileBase");
			return (class UClass*)ptr;
		};

};

class UEpicCMSTileCarousel : public UUserWidget
{
	public:
	    struct FSlateSound PreviousButtonSound; // 0x228 Size: 0x18
	    struct FSlateSound NextButtonSound; // 0x240 Size: 0x18
	    class UCommonWidgetCarousel* Carousel; // 0x258 Size: 0x8
	    class UWidget* NextPageButton; // 0x260 Size: 0x8
	    class UWidget* PreviousPageButton; // 0x268 Size: 0x8
	    bool bShouldShowNavigationOnlyOnHover; // 0x270 Size: 0x1
	    bool bIsShowingNavigation; // 0x271 Size: 0x1
	    char UnknownData0[0x272]; // 0x272
	    void SetCurrentPageByIndex(int PageIndex); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void PreviousPage(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void NextPage(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void NavigationVisibilityChanged(bool bShowNavigation); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleTilePageAdded(class UWidget* TileWidget); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    int GetCurrentPageIndex(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7d69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/EpicCMSUIFramework.EpicCMSTileCarousel");
			return (class UClass*)ptr;
		};

};


}