#pragma once

#include "../SDK.hpp"

namespace SDK {


class ANavigationData : public AActor
{
	public:
	    char UnknownData0[0x8];
	    class UPrimitiveComponent* RenderingComp; // 0x338 Size: 0x8
	    struct FNavDataConfig NavDataConfig; // 0x340 Size: 0x68
	    bool bEnableDrawing; // 0x3a8 Size: 0x1
	    bool bForceRebuildOnLoad; // 0x3a8 Size: 0x1
	    bool bCanBeMainNavData; // 0x3a8 Size: 0x1
	    bool bCanSpawnOnRebuild; // 0x3a8 Size: 0x1
	    bool bRebuildAtRuntime; // 0x3a8 Size: 0x1
	    char UnknownData1[0x1]; // 0x3ad
	    ERuntimeGenerationType RuntimeGeneration; // 0x3ac Size: 0x1
	    char UnknownData2[0x3]; // 0x3ad
	    float ObservedPathsTickInterval; // 0x3b0 Size: 0x4
	    uint32_t DataVersion; // 0x3b4 Size: 0x4
	    char UnknownData3[0xd0]; // 0x3b8
	    TArray<struct FSupportedAreaData> SupportedAreas; // 0x488 Size: 0x10
	    char UnknownData4[0x58];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavigationData");
			return (class UClass*)ptr;
		};

};

class ARecastNavMesh : public ANavigationData
{
	public:
	    bool bDrawTriangleEdges; // 0x4f0 Size: 0x1
	    bool bDrawPolyEdges; // 0x4f0 Size: 0x1
	    bool bDrawFilledPolys; // 0x4f0 Size: 0x1
	    bool bDrawNavMeshEdges; // 0x4f0 Size: 0x1
	    bool bDrawTileBounds; // 0x4f0 Size: 0x1
	    bool bDrawPathCollidingGeometry; // 0x4f0 Size: 0x1
	    bool bDrawTileLabels; // 0x4f0 Size: 0x1
	    bool bDrawPolygonLabels; // 0x4f0 Size: 0x1
	    bool bDrawDefaultPolygonCost; // 0x4f1 Size: 0x1
	    bool bDrawLabelsOnPathNodes; // 0x4f1 Size: 0x1
	    bool bDrawNavLinks; // 0x4f1 Size: 0x1
	    bool bDrawFailedNavLinks; // 0x4f1 Size: 0x1
	    bool bDrawClusters; // 0x4f1 Size: 0x1
	    bool bDrawOctree; // 0x4f1 Size: 0x1
	    bool bDrawOctreeDetails; // 0x4f1 Size: 0x1
	    bool bDistinctlyDrawTilesBeingBuilt; // 0x4f1 Size: 0x1
	    bool bDrawNavMesh; // 0x4f2 Size: 0x1
	    char UnknownData0[0xd]; // 0x501
	    float DrawOffset; // 0x4f4 Size: 0x4
	    bool bFixedTilePoolSize; // 0x4f8 Size: 0x1
	    char UnknownData1[0x3]; // 0x4f9
	    int TilePoolSize; // 0x4fc Size: 0x4
	    float TileSizeUU; // 0x500 Size: 0x4
	    float CellSize; // 0x504 Size: 0x4
	    float CellHeight; // 0x508 Size: 0x4
	    float AgentRadius; // 0x50c Size: 0x4
	    float AgentHeight; // 0x510 Size: 0x4
	    float AgentMaxHeight; // 0x514 Size: 0x4
	    float AgentMaxSlope; // 0x518 Size: 0x4
	    float AgentMaxStepHeight; // 0x51c Size: 0x4
	    float MinRegionArea; // 0x520 Size: 0x4
	    float MergeRegionSize; // 0x524 Size: 0x4
	    float MaxSimplificationError; // 0x528 Size: 0x4
	    int MaxSimultaneousTileGenerationJobsCount; // 0x52c Size: 0x4
	    int TileNumberHardLimit; // 0x530 Size: 0x4
	    int PolyRefTileBits; // 0x534 Size: 0x4
	    int PolyRefNavPolyBits; // 0x538 Size: 0x4
	    int PolyRefSaltBits; // 0x53c Size: 0x4
	    struct FVector NavMeshOriginOffset; // 0x540 Size: 0xc
	    float DefaultDrawDistance; // 0x54c Size: 0x4
	    float DefaultMaxSearchNodes; // 0x550 Size: 0x4
	    float DefaultMaxHierarchicalSearchNodes; // 0x554 Size: 0x4
	    char RegionPartitioning; // 0x558 Size: 0x1
	    char LayerPartitioning; // 0x559 Size: 0x1
	    char UnknownData2[0x2]; // 0x55a
	    int RegionChunkSplits; // 0x55c Size: 0x4
	    int LayerChunkSplits; // 0x560 Size: 0x4
	    bool bSortNavigationAreasByCost; // 0x564 Size: 0x1
	    bool bPerformVoxelFiltering; // 0x564 Size: 0x1
	    bool bMarkLowHeightAreas; // 0x564 Size: 0x1
	    bool bFilterLowSpanSequences; // 0x564 Size: 0x1
	    bool bFilterLowSpanFromTileCache; // 0x564 Size: 0x1
	    bool bDoFullyAsyncNavDataGathering; // 0x564 Size: 0x1
	    bool bUseBetterOffsetsFromCorners; // 0x564 Size: 0x1
	    bool bStoreEmptyTileLayers; // 0x564 Size: 0x1
	    bool bUseVirtualFilters; // 0x565 Size: 0x1
	    bool bAllowNavLinkAsPathEnd; // 0x565 Size: 0x1
	    bool bUseVoxelCache; // 0x565 Size: 0x1
	    char UnknownData3[0x7]; // 0x56f
	    float TileSetUpdateInterval; // 0x568 Size: 0x4
	    float HeuristicScale; // 0x56c Size: 0x4
	    float VerticalDeviationFromGroundCompensation; // 0x570 Size: 0x4
	    char UnknownData4[0x34];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.RecastNavMesh");
			return (class UClass*)ptr;
		};

};

class UNavigationSystemV1 : public UNavigationSystemBase
{
	public:
	    class ANavigationData* MainNavData; // 0x28 Size: 0x8
	    class ANavigationData* AbstractNavData; // 0x30 Size: 0x8
	    class UCrowdManagerBase* CrowdManagerClass; // 0x38 Size: 0x8
	    bool bAutoCreateNavigationData; // 0x40 Size: 0x1
	    bool bSpawnNavDataInNavBoundsLevel; // 0x40 Size: 0x1
	    bool bAllowClientSideNavigation; // 0x40 Size: 0x1
	    bool bShouldDiscardSubLevelNavData; // 0x40 Size: 0x1
	    bool bTickWhilePaused; // 0x40 Size: 0x1
	    bool bSupportRebuilding; // 0x40 Size: 0x1
	    bool bInitialBuildingLocked; // 0x40 Size: 0x1
	    bool bSkipAgentHeightCheckWhenPickingNavData; // 0x41 Size: 0x1
	    char UnknownData0[0x4]; // 0x48
	    ENavDataGatheringModeConfig DataGatheringMode; // 0x44 Size: 0x1
	    bool bGenerateNavigationOnlyAroundNavigationInvokers; // 0x48 Size: 0x1
	    char UnknownData1[0x6]; // 0x46
	    float ActiveTilesUpdateInterval; // 0x4c Size: 0x4
	    TArray<struct FNavDataConfig> SupportedAgents; // 0x50 Size: 0x10
	    float DirtyAreasUpdateFreq; // 0x60 Size: 0x4
	    char UnknownData2[0x4]; // 0x64
	    TArray<class ANavigationData*> NavDataSet; // 0x68 Size: 0x10
	    TArray<class ANavigationData*> NavDataRegistrationQueue; // 0x78 Size: 0x10
	    char UnknownData3[0x60]; // 0x88
	    MulticastDelegateProperty OnNavDataRegisteredEvent; // 0xe8 Size: 0x10
	    MulticastDelegateProperty OnNavigationGenerationFinishedDelegate; // 0xf8 Size: 0x10
	    char UnknownData4[0xcc]; // 0x108
	    FNavigationSystemRunMode OperationMode; // 0x1d4 Size: 0x1
	    char UnknownData5[0x1d5]; // 0x1d5
	    void UnregisterNavigationInvoker(class AActor* Invoker); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static void SimpleMoveToLocation(class AController* Controller, struct FVector Goal); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static void SimpleMoveToActor(class AController* Controller, class AActor* Goal); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetMaxSimultaneousTileGenerationJobsCount(int MaxNumberOfJobs); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetGeometryGatheringMode(ENavDataGatheringModeConfig NewMode); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void ResetMaxSimultaneousTileGenerationJobsCount(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void RegisterNavigationInvoker(class AActor* Invoker, float TileGenerationRadius, float TileRemovalRadius); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    static struct FVector ProjectPointToNavigation(class UObject* WorldContextObject, struct FVector Point, class ANavigationData* NavData, class UNavigationQueryFilter* FilterClass, struct FVector QueryExtent); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void OnNavigationBoundsUpdated(class ANavMeshBoundsVolume* NavVolume); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    static bool NavigationRaycast(class UObject* WorldContextObject, struct FVector RayStart, struct FVector RayEnd, struct FVector HitLocation, class UNavigationQueryFilter* FilterClass, class AController* Querier); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    static bool K2_ProjectPointToNavigation(class UObject* WorldContextObject, struct FVector Point, struct FVector ProjectedLocation, class ANavigationData* NavData, class UNavigationQueryFilter* FilterClass, struct FVector QueryExtent); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    static bool K2_GetRandomReachablePointInRadius(class UObject* WorldContextObject, struct FVector Origin, struct FVector RandomLocation, float Radius, class ANavigationData* NavData, class UNavigationQueryFilter* FilterClass); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    static bool K2_GetRandomPointInNavigableRadius(class UObject* WorldContextObject, struct FVector Origin, struct FVector RandomLocation, float Radius, class ANavigationData* NavData, class UNavigationQueryFilter* FilterClass); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    static bool IsNavigationBeingBuiltOrLocked(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    static bool IsNavigationBeingBuilt(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    static struct FVector GetRandomReachablePointInRadius(class UObject* WorldContextObject, struct FVector Origin, float Radius, class ANavigationData* NavData, class UNavigationQueryFilter* FilterClass); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    static struct FVector GetRandomPointInNavigableRadius(class UObject* WorldContextObject, struct FVector Origin, float Radius, class ANavigationData* NavData, class UNavigationQueryFilter* FilterClass); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    static char GetPathLength(class UObject* WorldContextObject, struct FVector PathStart, struct FVector PathEnd, float PathLength, class ANavigationData* NavData, class UNavigationQueryFilter* FilterClass); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    static char GetPathCost(class UObject* WorldContextObject, struct FVector PathStart, struct FVector PathEnd, float PathCost, class ANavigationData* NavData, class UNavigationQueryFilter* FilterClass); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    static class UNavigationSystemV1* GetNavigationSystem(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    static class UNavigationPath* FindPathToLocationSynchronously(class UObject* WorldContextObject, struct FVector PathStart, struct FVector PathEnd, class AActor* PathfindingContext, class UNavigationQueryFilter* FilterClass); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    static class UNavigationPath* FindPathToActorSynchronously(class UObject* WorldContextObject, struct FVector PathStart, class AActor* GoalActor, float TetherDistance, class AActor* PathfindingContext, class UNavigationQueryFilter* FilterClass); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x-7bd1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavigationSystemV1");
			return (class UClass*)ptr;
		};

};

class UNavigationSystemModuleConfig : public UNavigationSystemConfig
{
	public:
	    bool bStrictlyStatic; // 0x48 Size: 0x1
	    bool bCreateOnClient; // 0x48 Size: 0x1
	    bool bAutoSpawnMissingNavData; // 0x48 Size: 0x1
	    bool bSpawnNavDataInNavBoundsLevel; // 0x48 Size: 0x1
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavigationSystemModuleConfig");
			return (class UClass*)ptr;
		};

};

class ANavSystemConfigOverride : public AActor
{
	public:
	    class UNavigationSystemConfig* NavigationSystemConfig; // 0x330 Size: 0x8
	    bool bLoadOnClient; // 0x338 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavSystemConfigOverride");
			return (class UClass*)ptr;
		};

};

class UNavLinkRenderingComponent : public UPrimitiveComponent
{
	public:
	    char UnknownData0[0x570];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavLinkRenderingComponent");
			return (class UClass*)ptr;
		};

};

class UCrowdManagerBase : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.CrowdManagerBase");
			return (class UClass*)ptr;
		};

};

class UNavRelevantComponent : public UActorComponent
{
	public:
	    char UnknownData0[0x24];
	    bool bAttachToOwnersRoot; // 0x11c Size: 0x1
	    char UnknownData1[0x3]; // 0x11d
	    class UObject* CachedNavParent; // 0x120 Size: 0x8
	    char UnknownData2[0x128]; // 0x128
	    void SetNavigationRelevancy(bool bRelevant); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7eb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavRelevantComponent");
			return (class UClass*)ptr;
		};

};

class UNavLinkCustomComponent : public UNavRelevantComponent
{
	public:
	    char UnknownData0[0x8];
	    uint32_t NavLinkUserId; // 0x130 Size: 0x4
	    char UnknownData1[0x4]; // 0x134
	    class UNavArea* EnabledAreaClass; // 0x138 Size: 0x8
	    class UNavArea* DisabledAreaClass; // 0x140 Size: 0x8
	    struct FVector LinkRelativeStart; // 0x148 Size: 0xc
	    struct FVector LinkRelativeEnd; // 0x154 Size: 0xc
	    char LinkDirection; // 0x160 Size: 0x1
	    bool bLinkEnabled; // 0x164 Size: 0x1
	    bool bNotifyWhenEnabled; // 0x164 Size: 0x1
	    bool bNotifyWhenDisabled; // 0x164 Size: 0x1
	    bool bCreateBoxObstacle; // 0x164 Size: 0x1
	    char UnknownData2[0x3]; // 0x165
	    struct FVector ObstacleOffset; // 0x168 Size: 0xc
	    struct FVector ObstacleExtent; // 0x174 Size: 0xc
	    class UNavArea* ObstacleAreaClass; // 0x180 Size: 0x8
	    float BroadcastRadius; // 0x188 Size: 0x4
	    float BroadcastInterval; // 0x18c Size: 0x4
	    char BroadcastChannel; // 0x190 Size: 0x1
	    char UnknownData3[0x3f];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavLinkCustomComponent");
			return (class UClass*)ptr;
		};

};

class UNavArea : public UNavAreaBase
{
	public:
	    float DefaultCost; // 0x30 Size: 0x4
	    float FixedAreaEnteringCost; // 0x34 Size: 0x4
	    struct FColor DrawColor; // 0x38 Size: 0x4
	    struct FNavAgentSelector SupportedAgents; // 0x3c Size: 0x4
	    bool bSupportsAgent0; // 0x40 Size: 0x1
	    bool bSupportsAgent1; // 0x40 Size: 0x1
	    bool bSupportsAgent2; // 0x40 Size: 0x1
	    bool bSupportsAgent3; // 0x40 Size: 0x1
	    bool bSupportsAgent4; // 0x40 Size: 0x1
	    bool bSupportsAgent5; // 0x40 Size: 0x1
	    bool bSupportsAgent6; // 0x40 Size: 0x1
	    bool bSupportsAgent7; // 0x40 Size: 0x1
	    bool bSupportsAgent8; // 0x41 Size: 0x1
	    bool bSupportsAgent9; // 0x41 Size: 0x1
	    bool bSupportsAgent10; // 0x41 Size: 0x1
	    bool bSupportsAgent11; // 0x41 Size: 0x1
	    bool bSupportsAgent12; // 0x41 Size: 0x1
	    bool bSupportsAgent13; // 0x41 Size: 0x1
	    bool bSupportsAgent14; // 0x41 Size: 0x1
	    bool bSupportsAgent15; // 0x41 Size: 0x1
	    char UnknownData0[0x-8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavArea");
			return (class UClass*)ptr;
		};

};

class UNavAreaMeta : public UNavArea
{
	public:
	    char UnknownData0[0x48];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavAreaMeta");
			return (class UClass*)ptr;
		};

};

class UNavigationQueryFilter : public UObject
{
	public:
	    TArray<struct FNavigationFilterArea> Areas; // 0x28 Size: 0x10
	    struct FNavigationFilterFlags IncludeFlags; // 0x38 Size: 0x4
	    struct FNavigationFilterFlags ExcludeFlags; // 0x3c Size: 0x4
	    char UnknownData0[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavigationQueryFilter");
			return (class UClass*)ptr;
		};

};

class AAbstractNavData : public ANavigationData
{
	public:
	    char UnknownData0[0x4f0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.AbstractNavData");
			return (class UClass*)ptr;
		};

};

class UNavArea_Default : public UNavArea
{
	public:
	    char UnknownData0[0x48];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavArea_Default");
			return (class UClass*)ptr;
		};

};

class UNavArea_LowHeight : public UNavArea
{
	public:
	    char UnknownData0[0x48];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavArea_LowHeight");
			return (class UClass*)ptr;
		};

};

class UNavArea_Null : public UNavArea
{
	public:
	    char UnknownData0[0x48];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavArea_Null");
			return (class UClass*)ptr;
		};

};

class UNavArea_Obstacle : public UNavArea
{
	public:
	    char UnknownData0[0x48];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavArea_Obstacle");
			return (class UClass*)ptr;
		};

};

class UNavAreaMeta_SwitchByAgent : public UNavAreaMeta
{
	public:
	    class UNavArea* Agent0Area; // 0x48 Size: 0x8
	    class UNavArea* Agent1Area; // 0x50 Size: 0x8
	    class UNavArea* Agent2Area; // 0x58 Size: 0x8
	    class UNavArea* Agent3Area; // 0x60 Size: 0x8
	    class UNavArea* Agent4Area; // 0x68 Size: 0x8
	    class UNavArea* Agent5Area; // 0x70 Size: 0x8
	    class UNavArea* Agent6Area; // 0x78 Size: 0x8
	    class UNavArea* Agent7Area; // 0x80 Size: 0x8
	    class UNavArea* Agent8Area; // 0x88 Size: 0x8
	    class UNavArea* Agent9Area; // 0x90 Size: 0x8
	    class UNavArea* Agent10Area; // 0x98 Size: 0x8
	    class UNavArea* Agent11Area; // 0xa0 Size: 0x8
	    class UNavArea* Agent12Area; // 0xa8 Size: 0x8
	    class UNavArea* Agent13Area; // 0xb0 Size: 0x8
	    class UNavArea* Agent14Area; // 0xb8 Size: 0x8
	    class UNavArea* Agent15Area; // 0xc0 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavAreaMeta_SwitchByAgent");
			return (class UClass*)ptr;
		};

};

class UNavCollision : public UNavCollisionBase
{
	public:
	    char UnknownData0[0x10];
	    TArray<struct FNavCollisionCylinder> CylinderCollision; // 0x80 Size: 0x10
	    TArray<struct FNavCollisionBox> BoxCollision; // 0x90 Size: 0x10
	    class UNavArea* AreaClass; // 0xa0 Size: 0x8
	    bool bGatherConvexGeometry; // 0xa8 Size: 0x1
	    bool bCreateOnClient; // 0xa8 Size: 0x1
	    char UnknownData1[0x2e];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavCollision");
			return (class UClass*)ptr;
		};

};

class ANavigationGraph : public ANavigationData
{
	public:
	    char UnknownData0[0x4f0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavigationGraph");
			return (class UClass*)ptr;
		};

};

class ANavigationGraphNode : public AActor
{
	public:
	    char UnknownData0[0x330];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavigationGraphNode");
			return (class UClass*)ptr;
		};

};

class UNavigationGraphNodeComponent : public USceneComponent
{
	public:
	    struct FNavGraphNode Node; // 0x248 Size: 0x18
	    class UNavigationGraphNodeComponent* NextNodeComponent; // 0x260 Size: 0x8
	    class UNavigationGraphNodeComponent* PrevNodeComponent; // 0x268 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavigationGraphNodeComponent");
			return (class UClass*)ptr;
		};

};

class UNavigationInvokerComponent : public UActorComponent
{
	public:
	    float TileGenerationRadius; // 0xf8 Size: 0x4
	    float TileRemovalRadius; // 0xfc Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavigationInvokerComponent");
			return (class UClass*)ptr;
		};

};

class UNavigationPath : public UObject
{
	public:
	    MulticastDelegateProperty PathUpdatedNotifier; // 0x28 Size: 0x10
	    TArray<struct FVector> PathPoints; // 0x38 Size: 0x10
	    char RecalculateOnInvalidation; // 0x48 Size: 0x1
	    char UnknownData0[0x49]; // 0x49
	    bool IsValid(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool IsStringPulled(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool IsPartial(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    float GetPathLength(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    float GetPathCost(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    struct FString GetDebugString(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void EnableRecalculationOnInvalidation(char DoRecalculation); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void EnableDebugDrawing(bool bShouldDrawDebugData, struct FLinearColor PathColor); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7f59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavigationPath");
			return (class UClass*)ptr;
		};

};

class UNavigationPathGenerator : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavigationPathGenerator");
			return (class UClass*)ptr;
		};

};

class ANavigationTestingActor : public AActor
{
	public:
	    char UnknownData0[0x10];
	    class UCapsuleComponent* CapsuleComponent; // 0x340 Size: 0x8
	    class UNavigationInvokerComponent* InvokerComponent; // 0x348 Size: 0x8
	    bool bActAsNavigationInvoker; // 0x350 Size: 0x1
	    char UnknownData1[0x7]; // 0x351
	    struct FNavAgentProperties NavAgentProps; // 0x358 Size: 0x30
	    struct FVector QueryingExtent; // 0x388 Size: 0xc
	    char UnknownData2[0x4]; // 0x394
	    class ANavigationData* MyNavData; // 0x398 Size: 0x8
	    struct FVector ProjectedLocation; // 0x3a0 Size: 0xc
	    bool bProjectedLocationValid; // 0x3ac Size: 0x1
	    bool bSearchStart; // 0x3ac Size: 0x1
	    bool bBacktracking; // 0x3ac Size: 0x1
	    bool bUseHierarchicalPathfinding; // 0x3ac Size: 0x1
	    bool bGatherDetailedInfo; // 0x3ac Size: 0x1
	    bool bDrawDistanceToWall; // 0x3ac Size: 0x1
	    bool bShowNodePool; // 0x3ac Size: 0x1
	    bool bShowBestPath; // 0x3ac Size: 0x1
	    bool bShowDiffWithPreviousStep; // 0x3ad Size: 0x1
	    bool bShouldBeVisibleInGame; // 0x3ad Size: 0x1
	    char UnknownData3[0x6]; // 0x3b6
	    char CostDisplayMode; // 0x3b0 Size: 0x1
	    char UnknownData4[0x3]; // 0x3b1
	    struct FVector2D TextCanvasOffset; // 0x3b4 Size: 0x8
	    bool bPathExist; // 0x3bc Size: 0x1
	    bool bPathIsPartial; // 0x3bc Size: 0x1
	    bool bPathSearchOutOfNodes; // 0x3bc Size: 0x1
	    char UnknownData5[0x1]; // 0x3bf
	    float PathfindingTime; // 0x3c0 Size: 0x4
	    float PathCost; // 0x3c4 Size: 0x4
	    int PathfindingSteps; // 0x3c8 Size: 0x4
	    char UnknownData6[0x4]; // 0x3cc
	    class ANavigationTestingActor* OtherActor; // 0x3d0 Size: 0x8
	    class UNavigationQueryFilter* FilterClass; // 0x3d8 Size: 0x8
	    int ShowStepIndex; // 0x3e0 Size: 0x4
	    float OffsetFromCornersDistance; // 0x3e4 Size: 0x4
	    char UnknownData7[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavigationTestingActor");
			return (class UClass*)ptr;
		};

};

class UNavLinkComponent : public UPrimitiveComponent
{
	public:
	    char UnknownData0[0x8];
	    TArray<struct FNavigationLink> Links; // 0x578 Size: 0x10
	    char UnknownData1[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavLinkComponent");
			return (class UClass*)ptr;
		};

};

class UNavLinkCustomInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavLinkCustomInterface");
			return (class UClass*)ptr;
		};

};

class UNavLinkHostInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavLinkHostInterface");
			return (class UClass*)ptr;
		};

};

class UNavLinkTrivial : public UNavLinkDefinition
{
	public:
	    char UnknownData0[0x50];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavLinkTrivial");
			return (class UClass*)ptr;
		};

};

class ANavMeshBoundsVolume : public AVolume
{
	public:
	    struct FNavAgentSelector SupportedAgents; // 0x368 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavMeshBoundsVolume");
			return (class UClass*)ptr;
		};

};

class UNavMeshRenderingComponent : public UPrimitiveComponent
{
	public:
	    char UnknownData0[0x580];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavMeshRenderingComponent");
			return (class UClass*)ptr;
		};

};

class UNavModifierComponent : public UNavRelevantComponent
{
	public:
	    class UNavArea* AreaClass; // 0x128 Size: 0x8
	    struct FVector FailsafeExtent; // 0x130 Size: 0xc
	    bool bIncludeAgentHeight; // 0x13c Size: 0x1
	    char UnknownData0[0x13d]; // 0x13d
	    void SetAreaClass(class UNavArea* NewAreaClass); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7e91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavModifierComponent");
			return (class UClass*)ptr;
		};

};

class ANavModifierVolume : public AVolume
{
	public:
	    char UnknownData0[0x8];
	    class UNavArea* AreaClass; // 0x370 Size: 0x8
	    char UnknownData1[0x378]; // 0x378
	    void SetAreaClass(class UNavArea* NewAreaClass); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7c69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavModifierVolume");
			return (class UClass*)ptr;
		};

};

class UNavNodeInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavNodeInterface");
			return (class UClass*)ptr;
		};

};

class UNavTestRenderingComponent : public UPrimitiveComponent
{
	public:
	    char UnknownData0[0x570];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.NavTestRenderingComponent");
			return (class UClass*)ptr;
		};

};

class URecastFilter_UseDefaultArea : public UNavigationQueryFilter
{
	public:
	    char UnknownData0[0x48];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.RecastFilter_UseDefaultArea");
			return (class UClass*)ptr;
		};

};

class URecastNavMeshDataChunk : public UNavigationDataChunk
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NavigationSystem.RecastNavMeshDataChunk");
			return (class UClass*)ptr;
		};

};


}