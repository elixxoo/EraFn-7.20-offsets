#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class EPathFollowingResult : uint8_t
{
    Success = 0,
    Blocked = 1,
    OffPath = 2,
    Aborted = 3,
    Skipped_DEPRECATED = 4,
    Invalid = 5,
    EPathFollowingResult_MAX = 6
};struct FAIRequestID
{
	public:
	    uint32_t RequestId; // 0x0 Size: 0x4

};

struct FAIMoveCompletedSignature__DelegateSignature
{
	public:
	    struct FAIRequestID RequestId; // 0x0 Size: 0x4
	    char Result; // 0x4 Size: 0x1
	    char UnknownData0[0x3];

};

struct FOAISimpleDelegate__DelegateSignature
{
	public:
	    char MovementResult; // 0x0 Size: 0x1

};



enum class EEnvQueryStatus : uint8_t
{
    Processing = 0,
    Success = 1,
    Failed = 2,
    Aborted = 3,
    OwnerLost = 4,
    MissingParam = 5,
    EEnvQueryStatus_MAX = 6
};struct FSmartLinkReachedSignature__DelegateSignature
{
	public:
	    class AActor* MovingActor; // 0x0 Size: 0x8
	    struct FVector DestinationPoint; // 0x8 Size: 0xc
	    char UnknownData0[0x4];

};

struct FAIStimulus
{
	public:
	    float Age; // 0x0 Size: 0x4
	    float ExpirationAge; // 0x4 Size: 0x4
	    float Strength; // 0x8 Size: 0x4
	    struct FVector StimulusLocation; // 0xc Size: 0xc
	    struct FVector ReceiverLocation; // 0x18 Size: 0xc
	    FName Tag; // 0x24 Size: 0x8
	    bool bSuccessfullySensed; // 0x38 Size: 0x1
	    char UnknownData0[0xf];

};

struct FActorPerceptionUpdatedDelegate__DelegateSignature
{
	public:
	    class AActor* Actor; // 0x0 Size: 0x8
	    struct FAIStimulus Stimulus; // 0x8 Size: 0x3c
	    char UnknownData0[0x4];

};

struct FMoveTaskCompletedSignature__DelegateSignature
{
	public:
	    char Result; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class AAIController* AIController; // 0x8 Size: 0x8

};



enum class EAISenseNotifyType : uint8_t
{
    OnEveryPerception = 0,
    OnPerceptionChange = 1,
    EAISenseNotifyType_MAX = 2
};

enum class EAITaskPriority : uint8_t
{
    Lowest = 0,
    Low = 64,
    AutonomousAI = 127,
    High = 192,
    Ultimate = 254,
    EAITaskPriority_MAX = 255
};

enum class EGenericAICheck : uint8_t
{
    Less = 0,
    LessOrEqual = 1,
    Equal = 2,
    NotEqual = 3,
    GreaterOrEqual = 4,
    Greater = 5,
    IsTrue = 6,
    MAX = 7
};

enum class EAILockSource : uint8_t
{
    Animation = 0,
    Logic = 1,
    Script = 2,
    Gameplay = 3,
    MAX = 4
};

enum class EAIRequestPriority : uint8_t
{
    SoftScript = 0,
    Logic = 1,
    HardScript = 2,
    Reaction = 3,
    Ultimate = 4,
    MAX = 5
};

enum class EPawnActionEventType : uint8_t
{
    Invalid = 0,
    FailedToStart = 1,
    InstantAbort = 2,
    FinishedAborting = 3,
    FinishedExecution = 4,
    Push = 5,
    EPawnActionEventType_MAX = 6
};

enum class EPawnActionResult : uint8_t
{
    NotStarted = 0,
    InProgress = 1,
    Success = 2,
    Failed = 3,
    Aborted = 4,
    EPawnActionResult_MAX = 5
};

enum class EPawnActionAbortState : uint8_t
{
    NeverStarted = 0,
    NotBeingAborted = 1,
    MarkPendingAbort = 2,
    LatentAbortInProgress = 3,
    AbortDone = 4,
    MAX = 5
};

enum class FAIDistanceType : uint8_t
{
    Distance3D = 0,
    Distance2D = 1,
    DistanceZ = 2,
    MAX = 3
};

enum class EAIOptionFlag : uint8_t
{
    Default = 0,
    Enable = 1,
    Disable = 2,
    MAX = 3
};

enum class EBTFlowAbortMode : uint8_t
{
    None = 0,
    LowerPriority = 1,
    Self = 2,
    Both = 3,
    EBTFlowAbortMode_MAX = 4
};

enum class EBTNodeResult : uint8_t
{
    Succeeded = 0,
    Failed = 1,
    Aborted = 2,
    InProgress = 3,
    EBTNodeResult_MAX = 4
};

enum class ETextKeyOperation : uint8_t
{
    Equal = 0,
    NotEqual = 1,
    Contain = 2,
    NotContain = 3,
    ETextKeyOperation_MAX = 4
};

enum class EArithmeticKeyOperation : uint8_t
{
    Equal = 0,
    NotEqual = 1,
    Less = 2,
    LessOrEqual = 3,
    Greater = 4,
    GreaterOrEqual = 5,
    EArithmeticKeyOperation_MAX = 6
};

enum class EBasicKeyOperation : uint8_t
{
    Set = 0,
    NotSet = 1,
    EBasicKeyOperation_MAX = 2
};

enum class EBTParallelMode : uint8_t
{
    AbortBackground = 0,
    WaitForBackground = 1,
    EBTParallelMode_MAX = 2
};

enum class EBTDecoratorLogic : uint8_t
{
    Invalid = 0,
    Test = 1,
    And = 2,
    Or = 3,
    Not = 4,
    EBTDecoratorLogic_MAX = 5
};

enum class EBTChildIndex : uint8_t
{
    FirstNode = 0,
    TaskNode = 1,
    EBTChildIndex_MAX = 2
};

enum class EBTBlackboardRestart : uint8_t
{
    ValueChange = 0,
    ResultChange = 1,
    EBTBlackboardRestart_MAX = 2
};

enum class EBlackBoardEntryComparison : uint8_t
{
    Equal = 0,
    NotEqual = 1,
    EBlackBoardEntryComparison_MAX = 2
};

enum class EPathExistanceQueryType : uint8_t
{
    NavmeshRaycast2D = 0,
    HierarchicalQuery = 1,
    RegularPathFinding = 2,
    EPathExistanceQueryType_MAX = 3
};

enum class EPointOnCircleSpacingMethod : uint8_t
{
    BySpaceBetween = 0,
    ByNumberOfPoints = 1,
    EPointOnCircleSpacingMethod_MAX = 2
};

enum class EEQSNormalizationType : uint8_t
{
    Absolute = 0,
    RelativeToScores = 1,
    EEQSNormalizationType_MAX = 2
};

enum class EEnvTestDistance : uint8_t
{
    Distance3D = 0,
    Distance2D = 1,
    DistanceZ = 2,
    DistanceAbsoluteZ = 3,
    EEnvTestDistance_MAX = 4
};

enum class EEnvTestDot : uint8_t
{
    Dot3D = 0,
    Dot2D = 1,
    EEnvTestDot_MAX = 2
};

enum class EEnvTestPathfinding : uint8_t
{
    PathExist = 0,
    PathCost = 1,
    PathLength = 2,
    EEnvTestPathfinding_MAX = 3
};

enum class EEnvQueryTestClamping : uint8_t
{
    None = 0,
    SpecifiedValue = 1,
    FilterThreshold = 2,
    EEnvQueryTestClamping_MAX = 3
};

enum class EEnvDirection : uint8_t
{
    TwoPoints = 0,
    Rotation = 1,
    EEnvDirection_MAX = 2
};

enum class EEnvOverlapShape : uint8_t
{
    Box = 0,
    Sphere = 1,
    Capsule = 2,
    EEnvOverlapShape_MAX = 3
};

enum class EEnvTraceShape : uint8_t
{
    Line = 0,
    Box = 1,
    Sphere = 2,
    Capsule = 3,
    EEnvTraceShape_MAX = 4
};

enum class EEnvQueryTrace : uint8_t
{
    None = 0,
    Navigation = 1,
    Geometry = 2,
    NavigationOverLedges = 3,
    EEnvQueryTrace_MAX = 4
};

enum class EAIParamType : uint8_t
{
    Float = 0,
    Int = 1,
    Bool = 2,
    MAX = 3
};

enum class EEnvQueryParam : uint8_t
{
    Float = 0,
    Int = 1,
    Bool = 2,
    EEnvQueryParam_MAX = 3
};

enum class EEnvQueryRunMode : uint8_t
{
    SingleResult = 0,
    RandomBest5Pct = 1,
    RandomBest25Pct = 2,
    AllMatching = 3,
    EEnvQueryRunMode_MAX = 4
};

enum class EEnvTestScoreOperator : uint8_t
{
    AverageScore = 0,
    MinScore = 1,
    MaxScore = 2,
    EEnvTestScoreOperator_MAX = 3
};

enum class EEnvTestFilterOperator : uint8_t
{
    AllPass = 0,
    AnyPass = 1,
    EEnvTestFilterOperator_MAX = 2
};

enum class EEnvTestCost : uint8_t
{
    Low = 0,
    Medium = 1,
    High = 2,
    EEnvTestCost_MAX = 3
};

enum class EEnvTestWeight : uint8_t
{
    None = 0,
    Square = 1,
    Inverse = 2,
    Unused = 3,
    Constant = 4,
    Skip = 5,
    EEnvTestWeight_MAX = 6
};

enum class EEnvTestScoreEquation : uint8_t
{
    Linear = 0,
    Square = 1,
    InverseLinear = 2,
    SquareRoot = 3,
    Constant = 4,
    EEnvTestScoreEquation_MAX = 5
};

enum class EEnvTestFilterType : uint8_t
{
    Minimum = 0,
    Maximum = 1,
    Range = 2,
    Match = 3,
    EEnvTestFilterType_MAX = 4
};

enum class EEnvTestPurpose : uint8_t
{
    Filter = 0,
    Score = 1,
    FilterAndScore = 2,
    EEnvTestPurpose_MAX = 3
};

enum class EEnvQueryHightlightMode : uint8_t
{
    All = 0,
    Best5Pct = 1,
    Best25Pct = 2,
    EEnvQueryHightlightMode_MAX = 3
};

enum class ETeamAttitude : uint8_t
{
    Friendly = 0,
    Neutral = 1,
    Hostile = 2,
    ETeamAttitude_MAX = 3
};

enum class EPathFollowingRequestResult : uint8_t
{
    Failed = 0,
    AlreadyAtGoal = 1,
    RequestSuccessful = 2,
    EPathFollowingRequestResult_MAX = 3
};

enum class EPathFollowingAction : uint8_t
{
    Error = 0,
    NoMove = 1,
    DirectMove = 2,
    PartialPath = 3,
    PathToGoal = 4,
    EPathFollowingAction_MAX = 5
};

enum class EPathFollowingStatus : uint8_t
{
    Idle = 0,
    Waiting = 1,
    Paused = 2,
    Moving = 3,
    EPathFollowingStatus_MAX = 4
};

enum class EPawnActionFailHandling : uint8_t
{
    RequireSuccess = 0,
    IgnoreFailure = 1,
    EPawnActionFailHandling_MAX = 2
};

enum class EPawnSubActionTriggeringPolicy : uint8_t
{
    CopyBeforeTriggering = 0,
    ReuseInstances = 1,
    EPawnSubActionTriggeringPolicy_MAX = 2
};

enum class EPawnActionMoveMode : uint8_t
{
    UsePathfinding = 0,
    StraightLine = 1,
    EPawnActionMoveMode_MAX = 2
};struct FEnvNamedValue
{
	public:
	    FName ParamName; // 0x0 Size: 0x8
	    EAIParamType ParamType; // 0x8 Size: 0x1
	    char UnknownData0[0x3]; // 0x9
	    float Value; // 0xc Size: 0x4

};

struct FAIDataProviderValue
{
	public:
	    class UProperty* CachedProperty; // 0x8 Size: 0x8
	    class UAIDataProvider* DataBinding; // 0x10 Size: 0x8
	    FName DataField; // 0x18 Size: 0x8

};

struct FAIDataProviderTypedValue : public FAIDataProviderValue
{
	public:
	    class UProperty* PropertyType; // 0x20 Size: 0x8

};

struct FAIDataProviderFloatValue : public FAIDataProviderTypedValue
{
	public:
	    float DefaultValue; // 0x28 Size: 0x4
	    char UnknownData0[0x4];

};

struct FAIDataProviderBoolValue : public FAIDataProviderTypedValue
{
	public:
	    bool DefaultValue; // 0x28 Size: 0x1
	    char UnknownData0[0x7];

};

struct FAIDataProviderIntValue : public FAIDataProviderTypedValue
{
	public:
	    int DefaultValue; // 0x28 Size: 0x4
	    char UnknownData0[0x4];

};

struct FAIDataProviderStructValue : public FAIDataProviderValue
{
	public:
	    char UnknownData0[0x30];

};

struct FAISenseAffiliationFilter
{
	public:
	    bool bDetectEnemies; // 0x0 Size: 0x1
	    bool bDetectNeutrals; // 0x0 Size: 0x1
	    bool bDetectFriendlies; // 0x0 Size: 0x1
	    char UnknownData0[0x1];

};

struct FAIDamageEvent
{
	public:
	    float Amount; // 0x0 Size: 0x4
	    struct FVector Location; // 0x4 Size: 0xc
	    struct FVector HitLocation; // 0x10 Size: 0xc
	    char UnknownData0[0x4]; // 0x1c
	    class AActor* DamagedActor; // 0x20 Size: 0x8
	    class AActor* Instigator; // 0x28 Size: 0x8

};

struct FAINoiseEvent
{
	public:
	    struct FVector NoiseLocation; // 0x4 Size: 0xc
	    float Loudness; // 0x10 Size: 0x4
	    float MaxRange; // 0x14 Size: 0x4
	    class AActor* Instigator; // 0x18 Size: 0x8
	    FName Tag; // 0x20 Size: 0x8
	    char UnknownData0[0x8];

};

struct FAIPredictionEvent
{
	public:
	    class AActor* Requestor; // 0x0 Size: 0x8
	    class AActor* PredictedActor; // 0x8 Size: 0x8
	    char UnknownData0[0x8];

};

struct FAISightEvent
{
	public:
	    class AActor* SeenActor; // 0x8 Size: 0x8
	    class AActor* Observer; // 0x10 Size: 0x8

};

struct FAITeamStimulusEvent
{
	public:
	    class AActor* Broadcaster; // 0x28 Size: 0x8
	    class AActor* Enemy; // 0x30 Size: 0x8

};

struct FAITouchEvent
{
	public:
	    class AActor* TouchReceiver; // 0x10 Size: 0x8
	    class AActor* OtherActor; // 0x18 Size: 0x8

};

struct FAIMoveRequest
{
	public:
	    class AActor* GoalActor; // 0x0 Size: 0x8
	    char UnknownData0[0x38];

};

struct FBehaviorTreeTemplateInfo
{
	public:
	    class UBehaviorTree* Asset; // 0x0 Size: 0x8
	    class UBTCompositeNode* Template; // 0x8 Size: 0x8
	    char UnknownData0[0x8];

};

struct FBlackboardEntry
{
	public:
	    FName EntryName; // 0x0 Size: 0x8
	    class UBlackboardKeyType* KeyType; // 0x8 Size: 0x8
	    bool bInstanceSynced; // 0x10 Size: 0x1
	    char UnknownData0[0x7];

};

struct FBTDecoratorLogic
{
	public:
	    char Operation; // 0x0 Size: 0x1
	    char UnknownData0[0x1]; // 0x1
	    __int64/*UInt16Property*/ Number; // 0x2 Size: 0x2

};

struct FCrowdAvoidanceConfig
{
	public:
	    float VelocityBias; // 0x0 Size: 0x4
	    float DesiredVelocityWeight; // 0x4 Size: 0x4
	    float CurrentVelocityWeight; // 0x8 Size: 0x4
	    float SideBiasWeight; // 0xc Size: 0x4
	    float ImpactTimeWeight; // 0x10 Size: 0x4
	    float ImpactTimeRange; // 0x14 Size: 0x4
	    char CustomPatternIdx; // 0x18 Size: 0x1
	    char AdaptiveDivisions; // 0x19 Size: 0x1
	    char AdaptiveRings; // 0x1a Size: 0x1
	    char AdaptiveDepth; // 0x1b Size: 0x1

};

struct FEnvQueryInstanceCache
{
	public:
	    class UEnvQuery* Template; // 0x0 Size: 0x8
	    char UnknownData0[0x170];

};

struct FEnvQueryRequest
{
	public:
	    class UEnvQuery* QueryTemplate; // 0x0 Size: 0x8
	    class UObject* Owner; // 0x8 Size: 0x8
	    class UWorld* World; // 0x10 Size: 0x8
	    char UnknownData0[0x50];

};

struct FEnvQueryResult
{
	public:
	    class UEnvQueryItemType* ItemType; // 0x10 Size: 0x8
	    char UnknownData0[0x14]; // 0x18
	    int OptionIndex; // 0x2c Size: 0x4
	    int QueryID; // 0x30 Size: 0x4
	    char UnknownData1[0xc];

};

struct FEnvOverlapData
{
	public:
	    float ExtentX; // 0x0 Size: 0x4
	    float ExtentY; // 0x4 Size: 0x4
	    float ExtentZ; // 0x8 Size: 0x4
	    struct FVector ShapeOffset; // 0xc Size: 0xc
	    char OverlapChannel; // 0x18 Size: 0x1
	    char OverlapShape; // 0x19 Size: 0x1
	    bool bOnlyBlockingHits; // 0x1c Size: 0x1
	    bool bOverlapComplex; // 0x1c Size: 0x1
	    char UnknownData0[0x4];

};

struct FEnvTraceData
{
	public:
	    int VersionNum; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    class UNavigationQueryFilter* NavigationFilter; // 0x8 Size: 0x8
	    float ProjectDown; // 0x10 Size: 0x4
	    float ProjectUp; // 0x14 Size: 0x4
	    float ExtentX; // 0x18 Size: 0x4
	    float ExtentY; // 0x1c Size: 0x4
	    float ExtentZ; // 0x20 Size: 0x4
	    float PostProjectionVerticalOffset; // 0x24 Size: 0x4
	    char TraceChannel; // 0x28 Size: 0x1
	    char SerializedChannel; // 0x29 Size: 0x1
	    char TraceShape; // 0x2a Size: 0x1
	    char TraceMode; // 0x2b Size: 0x1
	    bool bTraceComplex; // 0x2c Size: 0x1
	    bool bOnlyBlockingHits; // 0x2c Size: 0x1
	    bool bCanTraceOnNavMesh; // 0x2c Size: 0x1
	    bool bCanTraceOnGeometry; // 0x2c Size: 0x1
	    bool bCanDisableTrace; // 0x2c Size: 0x1
	    bool bCanProjectDown; // 0x2c Size: 0x1
	    char UnknownData1[0x-2];

};

struct FEnvDirection
{
	public:
	    class UEnvQueryContext* LineFrom; // 0x0 Size: 0x8
	    class UEnvQueryContext* LineTo; // 0x8 Size: 0x8
	    class UEnvQueryContext* Rotation; // 0x10 Size: 0x8
	    char DirMode; // 0x18 Size: 0x1
	    char UnknownData0[0x7];

};

struct FGenericTeamId
{
	public:
	    char TeamId; // 0x0 Size: 0x1

};

struct FPawnActionStack
{
	public:
	    class UPawnAction* TopAction; // 0x0 Size: 0x8

};

struct FPawnActionEvent
{
	public:
	    class UPawnAction* Action; // 0x0 Size: 0x8
	    char UnknownData0[0x10];

};

struct FDefault__AISenseBlueprintListener
{
	public:

};


}