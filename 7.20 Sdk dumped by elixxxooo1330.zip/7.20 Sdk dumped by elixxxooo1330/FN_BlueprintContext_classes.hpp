#pragma once

#include "../SDK.hpp"

namespace SDK {


class UBlueprintContextBase : public USubsystem
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/BlueprintContext.BlueprintContextBase");
			return (class UClass*)ptr;
		};

};

class UBlueprintContextLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static class USubsystem* GetContext(class UObject* ContextObject, class USubsystem* Class); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/BlueprintContext.BlueprintContextLibrary");
			return (class UClass*)ptr;
		};

};


}