#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FGameplayTag
{
	public:
	    FName TagName; // 0x0 Size: 0x8

};



enum class EGameplayTagQueryExprType : uint8_t
{
    Undefined = 0,
    AnyTagsMatch = 1,
    AllTagsMatch = 2,
    NoTagsMatch = 3,
    AnyExprMatch = 4,
    AllExprMatch = 5,
    NoExprMatch = 6,
    EGameplayTagQueryExprType_MAX = 7
};

enum class EGameplayContainerMatchType : uint8_t
{
    Any = 0,
    All = 1,
    EGameplayContainerMatchType_MAX = 2
};

enum class EGameplayTagMatchType : uint8_t
{
    Explicit = 0,
    IncludeParentTags = 1,
    EGameplayTagMatchType_MAX = 2
};

enum class EGameplayTagSelectionType : uint8_t
{
    None = 0,
    NonRestrictedOnly = 1,
    RestrictedOnly = 2,
    All = 3,
    EGameplayTagSelectionType_MAX = 4
};

enum class EGameplayTagSourceType : uint8_t
{
    Native = 0,
    DefaultTagList = 1,
    TagList = 2,
    RestrictedTagList = 3,
    DataTable = 4,
    Invalid = 5,
    EGameplayTagSourceType_MAX = 6
};struct FGameplayTagReferenceHelper
{
	public:
	    char UnknownData0[0x10];

};

struct FGameplayTagCreationWidgetHelper
{
	public:
	    char UnknownData0[0x1];

};

struct FGameplayTagNode
{
	public:
	    char UnknownData0[0x50];

};

struct FGameplayTagSource
{
	public:
	    FName SourceName; // 0x0 Size: 0x8
	    EGameplayTagSourceType SourceType; // 0x8 Size: 0x1
	    char UnknownData0[0x7]; // 0x9
	    class UGameplayTagsList* SourceTagList; // 0x10 Size: 0x8
	    class URestrictedGameplayTagsList* SourceRestrictedTagList; // 0x18 Size: 0x8

};

struct FGameplayTagTableRow : public FTableRowBase
{
	public:
	    FName Tag; // 0x8 Size: 0x8
	    struct FString DevComment; // 0x10 Size: 0x10

};

struct FRestrictedGameplayTagTableRow : public FGameplayTagTableRow
{
	public:
	    bool bAllowNonRestrictedChildren; // 0x20 Size: 0x1
	    char UnknownData0[0x7];

};

struct FGameplayTagRedirect
{
	public:
	    FName OldTagName; // 0x0 Size: 0x8
	    FName NewTagName; // 0x8 Size: 0x8

};


}