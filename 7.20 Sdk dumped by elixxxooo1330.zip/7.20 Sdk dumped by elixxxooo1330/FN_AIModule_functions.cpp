#include "../SDK.hpp"

bool AAIController::UseBlackboard(class UBlackboardData* BlackboardAsset, class UBlackboardComponent* BlackboardComponent)
{
	struct {
            class UBlackboardData* BlackboardAsset;
            class UBlackboardComponent* BlackboardComponent;
            bool ReturnValue;
	} params{ BlackboardAsset, BlackboardComponent };

    static auto fn = UObject::FindObject("/Script/AIModule.AIController:UseBlackboard");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void AAIController::UnclaimTaskResource(class UGameplayTaskResource* ResourceClass)
{
	struct {
            class UGameplayTaskResource* ResourceClass;
	} params{ ResourceClass };

    static auto fn = UObject::FindObject("/Script/AIModule.AIController:UnclaimTaskResource");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void AAIController::SetPathFollowingComponent(class UPathFollowingComponent* NewPFComponent)
{
	struct {
            class UPathFollowingComponent* NewPFComponent;
	} params{ NewPFComponent };

    static auto fn = UObject::FindObject("/Script/AIModule.AIController:SetPathFollowingComponent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void AAIController::SetMoveBlockDetection(bool bEnable)
{
	struct {
            bool bEnable;
	} params{ bEnable };

    static auto fn = UObject::FindObject("/Script/AIModule.AIController:SetMoveBlockDetection");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool AAIController::RunBehaviorTree(class UBehaviorTree* BTAsset)
{
	struct {
            class UBehaviorTree* BTAsset;
            bool ReturnValue;
	} params{ BTAsset };

    static auto fn = UObject::FindObject("/Script/AIModule.AIController:RunBehaviorTree");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void AAIController::OnUsingBlackBoard(class UBlackboardComponent* BlackboardComp, class UBlackboardData* BlackboardAsset)
{
	struct {
            class UBlackboardComponent* BlackboardComp;
            class UBlackboardData* BlackboardAsset;
	} params{ BlackboardComp, BlackboardAsset };

    static auto fn = UObject::FindObject("/Script/AIModule.AIController:OnUsingBlackBoard");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void AAIController::OnUnpossess(class APawn* UnpossessedPawn)
{
	struct {
            class APawn* UnpossessedPawn;
	} params{ UnpossessedPawn };

    static auto fn = UObject::FindObject("/Script/AIModule.AIController:OnUnpossess");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void AAIController::OnPossess(class APawn* PossessedPawn)
{
	struct {
            class APawn* PossessedPawn;
	} params{ PossessedPawn };

    static auto fn = UObject::FindObject("/Script/AIModule.AIController:OnPossess");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void AAIController::OnGameplayTaskResourcesClaimed(struct FGameplayResourceSet NewlyClaimed, struct FGameplayResourceSet FreshlyReleased)
{
	struct {
            struct FGameplayResourceSet NewlyClaimed;
            struct FGameplayResourceSet FreshlyReleased;
	} params{ NewlyClaimed, FreshlyReleased };

    static auto fn = UObject::FindObject("/Script/AIModule.AIController:OnGameplayTaskResourcesClaimed");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


char AAIController::MoveToLocation(struct FVector Dest, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bProjectDestinationToNavigation, bool bCanStrafe, class UNavigationQueryFilter* FilterClass, bool bAllowPartialPath)
{
	struct {
            struct FVector Dest;
            float AcceptanceRadius;
            bool bStopOnOverlap;
            bool bUsePathfinding;
            bool bProjectDestinationToNavigation;
            bool bCanStrafe;
            class UNavigationQueryFilter* FilterClass;
            bool bAllowPartialPath;
            char ReturnValue;
	} params{ Dest, AcceptanceRadius, bStopOnOverlap, bUsePathfinding, bProjectDestinationToNavigation, bCanStrafe, FilterClass, bAllowPartialPath };

    static auto fn = UObject::FindObject("/Script/AIModule.AIController:MoveToLocation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


char AAIController::MoveToActor(class AActor* Goal, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bCanStrafe, class UNavigationQueryFilter* FilterClass, bool bAllowPartialPath)
{
	struct {
            class AActor* Goal;
            float AcceptanceRadius;
            bool bStopOnOverlap;
            bool bUsePathfinding;
            bool bCanStrafe;
            class UNavigationQueryFilter* FilterClass;
            bool bAllowPartialPath;
            char ReturnValue;
	} params{ Goal, AcceptanceRadius, bStopOnOverlap, bUsePathfinding, bCanStrafe, FilterClass, bAllowPartialPath };

    static auto fn = UObject::FindObject("/Script/AIModule.AIController:MoveToActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void AAIController::K2_SetFocus(class AActor* NewFocus)
{
	struct {
            class AActor* NewFocus;
	} params{ NewFocus };

    static auto fn = UObject::FindObject("/Script/AIModule.AIController:K2_SetFocus");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void AAIController::K2_SetFocalPoint(struct FVector FP)
{
	struct {
            struct FVector FP;
	} params{ FP };

    static auto fn = UObject::FindObject("/Script/AIModule.AIController:K2_SetFocalPoint");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void AAIController::K2_ClearFocus()
{
    static auto fn = UObject::FindObject("/Script/AIModule.AIController:K2_ClearFocus");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


bool AAIController::HasPartialPath()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.AIController:HasPartialPath");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UPathFollowingComponent* AAIController::GetPathFollowingComponent()
{
	struct {
            class UPathFollowingComponent* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.AIController:GetPathFollowingComponent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


char AAIController::GetMoveStatus()
{
	struct {
            char ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.AIController:GetMoveStatus");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FVector AAIController::GetImmediateMoveDestination()
{
	struct {
            struct FVector ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.AIController:GetImmediateMoveDestination");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class AActor* AAIController::GetFocusActor()
{
	struct {
            class AActor* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.AIController:GetFocusActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FVector AAIController::GetFocalPointOnActor(class AActor* Actor)
{
	struct {
            class AActor* Actor;
            struct FVector ReturnValue;
	} params{ Actor };

    static auto fn = UObject::FindObject("/Script/AIModule.AIController:GetFocalPointOnActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FVector AAIController::GetFocalPoint()
{
	struct {
            struct FVector ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.AIController:GetFocalPoint");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UAIPerceptionComponent* AAIController::GetAIPerceptionComponent()
{
	struct {
            class UAIPerceptionComponent* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.AIController:GetAIPerceptionComponent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void AAIController::ClaimTaskResource(class UGameplayTaskResource* ResourceClass)
{
	struct {
            class UGameplayTaskResource* ResourceClass;
	} params{ ResourceClass };

    static auto fn = UObject::FindObject("/Script/AIModule.AIController:ClaimTaskResource");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UAIPerceptionComponent::SetSenseEnabled(class UAISense* SenseClass, bool bEnable)
{
	struct {
            class UAISense* SenseClass;
            bool bEnable;
	} params{ SenseClass, bEnable };

    static auto fn = UObject::FindObject("/Script/AIModule.AIPerceptionComponent:SetSenseEnabled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAIPerceptionComponent::RequestStimuliListenerUpdate()
{
    static auto fn = UObject::FindObject("/Script/AIModule.AIPerceptionComponent:RequestStimuliListenerUpdate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UAIPerceptionComponent::OnOwnerEndPlay(class AActor* Actor, char EndPlayReason)
{
	struct {
            class AActor* Actor;
            char EndPlayReason;
	} params{ Actor, EndPlayReason };

    static auto fn = UObject::FindObject("/Script/AIModule.AIPerceptionComponent:OnOwnerEndPlay");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAIPerceptionComponent::GetPerceivedHostileActors(TArray<class AActor*> OutActors)
{
	struct {
            TArray<class AActor*> OutActors;
	} params{ OutActors };

    static auto fn = UObject::FindObject("/Script/AIModule.AIPerceptionComponent:GetPerceivedHostileActors");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAIPerceptionComponent::GetPerceivedActors(class UAISense* SenseToUse, TArray<class AActor*> OutActors)
{
	struct {
            class UAISense* SenseToUse;
            TArray<class AActor*> OutActors;
	} params{ SenseToUse, OutActors };

    static auto fn = UObject::FindObject("/Script/AIModule.AIPerceptionComponent:GetPerceivedActors");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAIPerceptionComponent::GetKnownPerceivedActors(class UAISense* SenseToUse, TArray<class AActor*> OutActors)
{
	struct {
            class UAISense* SenseToUse;
            TArray<class AActor*> OutActors;
	} params{ SenseToUse, OutActors };

    static auto fn = UObject::FindObject("/Script/AIModule.AIPerceptionComponent:GetKnownPerceivedActors");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAIPerceptionComponent::GetCurrentlyPerceivedActors(class UAISense* SenseToUse, TArray<class AActor*> OutActors)
{
	struct {
            class UAISense* SenseToUse;
            TArray<class AActor*> OutActors;
	} params{ SenseToUse, OutActors };

    static auto fn = UObject::FindObject("/Script/AIModule.AIPerceptionComponent:GetCurrentlyPerceivedActors");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UAIPerceptionComponent::GetActorsPerception(class AActor* Actor, struct FActorPerceptionBlueprintInfo Info)
{
	struct {
            class AActor* Actor;
            struct FActorPerceptionBlueprintInfo Info;
            bool ReturnValue;
	} params{ Actor, Info };

    static auto fn = UObject::FindObject("/Script/AIModule.AIPerceptionComponent:GetActorsPerception");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UBrainComponent::StopLogic(struct FString Reason)
{
	struct {
            struct FString Reason;
	} params{ Reason };

    static auto fn = UObject::FindObject("/Script/AIModule.BrainComponent:StopLogic");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBrainComponent::RestartLogic()
{
    static auto fn = UObject::FindObject("/Script/AIModule.BrainComponent:RestartLogic");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


bool UBrainComponent::IsRunning()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.BrainComponent:IsRunning");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UBrainComponent::IsPaused()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.BrainComponent:IsPaused");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UBehaviorTreeComponent::SetDynamicSubtree(struct FGameplayTag InjectTag, class UBehaviorTree* BehaviorAsset)
{
	struct {
            struct FGameplayTag InjectTag;
            class UBehaviorTree* BehaviorAsset;
	} params{ InjectTag, BehaviorAsset };

    static auto fn = UObject::FindObject("/Script/AIModule.BehaviorTreeComponent:SetDynamicSubtree");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


float UBehaviorTreeComponent::GetTagCooldownEndTime(struct FGameplayTag CooldownTag)
{
	struct {
            struct FGameplayTag CooldownTag;
            float ReturnValue;
	} params{ CooldownTag };

    static auto fn = UObject::FindObject("/Script/AIModule.BehaviorTreeComponent:GetTagCooldownEndTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UBehaviorTreeComponent::AddCooldownTagDuration(struct FGameplayTag CooldownTag, float CooldownDuration, bool bAddToExistingDuration)
{
	struct {
            struct FGameplayTag CooldownTag;
            float CooldownDuration;
            bool bAddToExistingDuration;
	} params{ CooldownTag, CooldownDuration, bAddToExistingDuration };

    static auto fn = UObject::FindObject("/Script/AIModule.BehaviorTreeComponent:AddCooldownTagDuration");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

static void UAISense_Hearing::ReportNoiseEvent(class UObject* WorldContextObject, struct FVector NoiseLocation, float Loudness, class AActor* Instigator, float MaxRange, FName Tag)
{
	struct {
            class UObject* WorldContextObject;
            struct FVector NoiseLocation;
            float Loudness;
            class AActor* Instigator;
            float MaxRange;
            FName Tag;            void ReturnValue;
	} params{ WorldContextObject, NoiseLocation, Loudness, Instigator, MaxRange, Tag };

    static auto fn = UObject::FindObject("/Script/AIModule.AISense_Hearing:ReportNoiseEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UAISystem::AILoggingVerbose()
{
    static auto fn = UObject::FindObject("/Script/AIModule.AISystem:AILoggingVerbose");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UAISystem::AIIgnorePlayers()
{
    static auto fn = UObject::FindObject("/Script/AIModule.AISystem:AIIgnorePlayers");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

void UPathFollowingComponent::OnNavDataRegistered(class ANavigationData* NavData)
{
	struct {
            class ANavigationData* NavData;
	} params{ NavData };

    static auto fn = UObject::FindObject("/Script/AIModule.PathFollowingComponent:OnNavDataRegistered");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UPathFollowingComponent::OnActorBump(class AActor* SelfActor, class AActor* OtherActor, struct FVector NormalImpulse, struct FHitResult Hit)
{
	struct {
            class AActor* SelfActor;
            class AActor* OtherActor;
            struct FVector NormalImpulse;
            struct FHitResult Hit;
	} params{ SelfActor, OtherActor, NormalImpulse, Hit };

    static auto fn = UObject::FindObject("/Script/AIModule.PathFollowingComponent:OnActorBump");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


struct FVector UPathFollowingComponent::GetPathDestination()
{
	struct {
            struct FVector ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.PathFollowingComponent:GetPathDestination");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


char UPathFollowingComponent::GetPathActionType()
{
	struct {
            char ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.PathFollowingComponent:GetPathActionType");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UCrowdFollowingComponent::SuspendCrowdSteering(bool bSuspend)
{
	struct {
            bool bSuspend;
	} params{ bSuspend };

    static auto fn = UObject::FindObject("/Script/AIModule.CrowdFollowingComponent:SuspendCrowdSteering");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void ANavLinkProxy::SetSmartLinkEnabled(bool bEnabled)
{
	struct {
            bool bEnabled;
	} params{ bEnabled };

    static auto fn = UObject::FindObject("/Script/AIModule.NavLinkProxy:SetSmartLinkEnabled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ANavLinkProxy::ResumePathFollowing(class AActor* Agent)
{
	struct {
            class AActor* Agent;
	} params{ Agent };

    static auto fn = UObject::FindObject("/Script/AIModule.NavLinkProxy:ResumePathFollowing");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ANavLinkProxy::ReceiveSmartLinkReached(class AActor* Agent, struct FVector Destination)
{
	struct {
            class AActor* Agent;
            struct FVector Destination;
	} params{ Agent, Destination };

    static auto fn = UObject::FindObject("/Script/AIModule.NavLinkProxy:ReceiveSmartLinkReached");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool ANavLinkProxy::IsSmartLinkEnabled()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.NavLinkProxy:IsSmartLinkEnabled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool ANavLinkProxy::HasMovingAgents()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.NavLinkProxy:HasMovingAgents");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

static class UAITask_MoveTo* UAITask_MoveTo::AIMoveTo(class AAIController* Controller, struct FVector GoalLocation, class AActor* GoalActor, float AcceptanceRadius, char StopOnOverlap, char AcceptPartialPath, bool bUsePathfinding, bool bLockAILogic, bool bUseContinuosGoalTracking)
{
	struct {
            class AAIController* Controller;
            struct FVector GoalLocation;
            class AActor* GoalActor;
            float AcceptanceRadius;
            char StopOnOverlap;
            char AcceptPartialPath;
            bool bUsePathfinding;
            bool bLockAILogic;
            bool bUseContinuosGoalTracking;
            class UAITask_MoveTo* ReturnValue;
	} params{ Controller, GoalLocation, GoalActor, AcceptanceRadius, StopOnOverlap, AcceptPartialPath, bUsePathfinding, bLockAILogic, bUseContinuosGoalTracking };

    static auto fn = UObject::FindObject("/Script/AIModule.AITask_MoveTo:AIMoveTo");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static void UAIPerceptionSystem::ReportPerceptionEvent(class UObject* WorldContextObject, class UAISenseEvent* PerceptionEvent)
{
	struct {
            class UObject* WorldContextObject;
            class UAISenseEvent* PerceptionEvent;            void ReturnValue;
	} params{ WorldContextObject, PerceptionEvent };

    static auto fn = UObject::FindObject("/Script/AIModule.AIPerceptionSystem:ReportPerceptionEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UAIPerceptionSystem::ReportEvent(class UAISenseEvent* PerceptionEvent)
{
	struct {
            class UAISenseEvent* PerceptionEvent;
	} params{ PerceptionEvent };

    static auto fn = UObject::FindObject("/Script/AIModule.AIPerceptionSystem:ReportEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


static bool UAIPerceptionSystem::RegisterPerceptionStimuliSource(class UObject* WorldContextObject, class UAISense* Sense, class AActor* Target)
{
	struct {
            class UObject* WorldContextObject;
            class UAISense* Sense;
            class AActor* Target;
            bool ReturnValue;
	} params{ WorldContextObject, Sense, Target };

    static auto fn = UObject::FindObject("/Script/AIModule.AIPerceptionSystem:RegisterPerceptionStimuliSource");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UAIPerceptionSystem::OnPerceptionStimuliSourceEndPlay(class AActor* Actor, char EndPlayReason)
{
	struct {
            class AActor* Actor;
            char EndPlayReason;
	} params{ Actor, EndPlayReason };

    static auto fn = UObject::FindObject("/Script/AIModule.AIPerceptionSystem:OnPerceptionStimuliSourceEndPlay");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


static class UAISense* UAIPerceptionSystem::GetSenseClassForStimulus(class UObject* WorldContextObject, struct FAIStimulus Stimulus)
{
	struct {
            class UObject* WorldContextObject;
            struct FAIStimulus Stimulus;
            class UAISense* ReturnValue;
	} params{ WorldContextObject, Stimulus };

    static auto fn = UObject::FindObject("/Script/AIModule.AIPerceptionSystem:GetSenseClassForStimulus");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UAIAsyncTaskBlueprintProxy::OnMoveCompleted(struct FAIRequestID RequestId, char MovementResult)
{
	struct {
            struct FAIRequestID RequestId;
            char MovementResult;
	} params{ RequestId, MovementResult };

    static auto fn = UObject::FindObject("/Script/AIModule.AIAsyncTaskBlueprintProxy:OnMoveCompleted");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

static void UAIBlueprintHelperLibrary::UnlockAIResourcesWithAnimation(class UAnimInstance* AnimInstance, bool bUnlockMovement, bool UnlockAILogic)
{
	struct {
            class UAnimInstance* AnimInstance;
            bool bUnlockMovement;
            bool UnlockAILogic;            void ReturnValue;
	} params{ AnimInstance, bUnlockMovement, UnlockAILogic };

    static auto fn = UObject::FindObject("/Script/AIModule.AIBlueprintHelperLibrary:UnlockAIResourcesWithAnimation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class APawn* UAIBlueprintHelperLibrary::SpawnAIFromClass(class UObject* WorldContextObject, class APawn* PawnClass, class UBehaviorTree* BehaviorTree, struct FVector Location, struct FRotator Rotation, bool bNoCollisionFail)
{
	struct {
            class UObject* WorldContextObject;
            class APawn* PawnClass;
            class UBehaviorTree* BehaviorTree;
            struct FVector Location;
            struct FRotator Rotation;
            bool bNoCollisionFail;
            class APawn* ReturnValue;
	} params{ WorldContextObject, PawnClass, BehaviorTree, Location, Rotation, bNoCollisionFail };

    static auto fn = UObject::FindObject("/Script/AIModule.AIBlueprintHelperLibrary:SpawnAIFromClass");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAIBlueprintHelperLibrary::SimpleMoveToLocation(class AController* Controller, struct FVector Goal)
{
	struct {
            class AController* Controller;
            struct FVector Goal;            void ReturnValue;
	} params{ Controller, Goal };

    static auto fn = UObject::FindObject("/Script/AIModule.AIBlueprintHelperLibrary:SimpleMoveToLocation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAIBlueprintHelperLibrary::SimpleMoveToActor(class AController* Controller, class AActor* Goal)
{
	struct {
            class AController* Controller;
            class AActor* Goal;            void ReturnValue;
	} params{ Controller, Goal };

    static auto fn = UObject::FindObject("/Script/AIModule.AIBlueprintHelperLibrary:SimpleMoveToActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAIBlueprintHelperLibrary::SendAIMessage(class APawn* Target, FName MESSAGE, class UObject* MessageSource, bool bSuccess)
{
	struct {
            class APawn* Target;
            FName MESSAGE;
            class UObject* MessageSource;
            bool bSuccess;            void ReturnValue;
	} params{ Target, MESSAGE, MessageSource, bSuccess };

    static auto fn = UObject::FindObject("/Script/AIModule.AIBlueprintHelperLibrary:SendAIMessage");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAIBlueprintHelperLibrary::LockAIResourcesWithAnimation(class UAnimInstance* AnimInstance, bool bLockMovement, bool LockAILogic)
{
	struct {
            class UAnimInstance* AnimInstance;
            bool bLockMovement;
            bool LockAILogic;            void ReturnValue;
	} params{ AnimInstance, bLockMovement, LockAILogic };

    static auto fn = UObject::FindObject("/Script/AIModule.AIBlueprintHelperLibrary:LockAIResourcesWithAnimation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAIBlueprintHelperLibrary::IsValidAIRotation(struct FRotator Rotation)
{
	struct {
            struct FRotator Rotation;
            bool ReturnValue;
	} params{ Rotation };

    static auto fn = UObject::FindObject("/Script/AIModule.AIBlueprintHelperLibrary:IsValidAIRotation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAIBlueprintHelperLibrary::IsValidAILocation(struct FVector Location)
{
	struct {
            struct FVector Location;
            bool ReturnValue;
	} params{ Location };

    static auto fn = UObject::FindObject("/Script/AIModule.AIBlueprintHelperLibrary:IsValidAILocation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UAIBlueprintHelperLibrary::IsValidAIDirection(struct FVector DirectionVector)
{
	struct {
            struct FVector DirectionVector;
            bool ReturnValue;
	} params{ DirectionVector };

    static auto fn = UObject::FindObject("/Script/AIModule.AIBlueprintHelperLibrary:IsValidAIDirection");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UNavigationPath* UAIBlueprintHelperLibrary::GetCurrentPath(class AController* Controller)
{
	struct {
            class AController* Controller;
            class UNavigationPath* ReturnValue;
	} params{ Controller };

    static auto fn = UObject::FindObject("/Script/AIModule.AIBlueprintHelperLibrary:GetCurrentPath");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UBlackboardComponent* UAIBlueprintHelperLibrary::GetBlackboard(class AActor* Target)
{
	struct {
            class AActor* Target;
            class UBlackboardComponent* ReturnValue;
	} params{ Target };

    static auto fn = UObject::FindObject("/Script/AIModule.AIBlueprintHelperLibrary:GetBlackboard");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class AAIController* UAIBlueprintHelperLibrary::GetAIController(class AActor* ControlledActor)
{
	struct {
            class AActor* ControlledActor;
            class AAIController* ReturnValue;
	} params{ ControlledActor };

    static auto fn = UObject::FindObject("/Script/AIModule.AIBlueprintHelperLibrary:GetAIController");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UAIAsyncTaskBlueprintProxy* UAIBlueprintHelperLibrary::CreateMoveToProxyObject(class UObject* WorldContextObject, class APawn* Pawn, struct FVector Destination, class AActor* TargetActor, float AcceptanceRadius, bool bStopOnOverlap)
{
	struct {
            class UObject* WorldContextObject;
            class APawn* Pawn;
            struct FVector Destination;
            class AActor* TargetActor;
            float AcceptanceRadius;
            bool bStopOnOverlap;
            class UAIAsyncTaskBlueprintProxy* ReturnValue;
	} params{ WorldContextObject, Pawn, Destination, TargetActor, AcceptanceRadius, bStopOnOverlap };

    static auto fn = UObject::FindObject("/Script/AIModule.AIBlueprintHelperLibrary:CreateMoveToProxyObject");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UAIPerceptionStimuliSourceComponent::UnregisterFromSense(class UAISense* SenseClass)
{
	struct {
            class UAISense* SenseClass;
	} params{ SenseClass };

    static auto fn = UObject::FindObject("/Script/AIModule.AIPerceptionStimuliSourceComponent:UnregisterFromSense");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAIPerceptionStimuliSourceComponent::UnregisterFromPerceptionSystem()
{
    static auto fn = UObject::FindObject("/Script/AIModule.AIPerceptionStimuliSourceComponent:UnregisterFromPerceptionSystem");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UAIPerceptionStimuliSourceComponent::RegisterWithPerceptionSystem()
{
    static auto fn = UObject::FindObject("/Script/AIModule.AIPerceptionStimuliSourceComponent:RegisterWithPerceptionSystem");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UAIPerceptionStimuliSourceComponent::RegisterForSense(class UAISense* SenseClass)
{
	struct {
            class UAISense* SenseClass;
	} params{ SenseClass };

    static auto fn = UObject::FindObject("/Script/AIModule.AIPerceptionStimuliSourceComponent:RegisterForSense");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

float UAISense_Blueprint::OnUpdate(TArray<class UAISenseEvent*> EventsToProcess)
{
	struct {
            TArray<class UAISenseEvent*> EventsToProcess;
            float ReturnValue;
	} params{ EventsToProcess };

    static auto fn = UObject::FindObject("/Script/AIModule.AISense_Blueprint:OnUpdate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UAISense_Blueprint::OnListenerUpdated(class AActor* ActorListener, class UAIPerceptionComponent* PerceptionComponent)
{
	struct {
            class AActor* ActorListener;
            class UAIPerceptionComponent* PerceptionComponent;
	} params{ ActorListener, PerceptionComponent };

    static auto fn = UObject::FindObject("/Script/AIModule.AISense_Blueprint:OnListenerUpdated");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAISense_Blueprint::OnListenerUnregistered(class AActor* ActorListener, class UAIPerceptionComponent* PerceptionComponent)
{
	struct {
            class AActor* ActorListener;
            class UAIPerceptionComponent* PerceptionComponent;
	} params{ ActorListener, PerceptionComponent };

    static auto fn = UObject::FindObject("/Script/AIModule.AISense_Blueprint:OnListenerUnregistered");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAISense_Blueprint::OnListenerRegistered(class AActor* ActorListener, class UAIPerceptionComponent* PerceptionComponent)
{
	struct {
            class AActor* ActorListener;
            class UAIPerceptionComponent* PerceptionComponent;
	} params{ ActorListener, PerceptionComponent };

    static auto fn = UObject::FindObject("/Script/AIModule.AISense_Blueprint:OnListenerRegistered");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAISense_Blueprint::K2_OnNewPawn(class APawn* NewPawn)
{
	struct {
            class APawn* NewPawn;
	} params{ NewPawn };

    static auto fn = UObject::FindObject("/Script/AIModule.AISense_Blueprint:K2_OnNewPawn");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAISense_Blueprint::GetAllListenerComponents(TArray<class UAIPerceptionComponent*> ListenerComponents)
{
	struct {
            TArray<class UAIPerceptionComponent*> ListenerComponents;
	} params{ ListenerComponents };

    static auto fn = UObject::FindObject("/Script/AIModule.AISense_Blueprint:GetAllListenerComponents");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UAISense_Blueprint::GetAllListenerActors(TArray<class AActor*> ListenerActors)
{
	struct {
            TArray<class AActor*> ListenerActors;
	} params{ ListenerActors };

    static auto fn = UObject::FindObject("/Script/AIModule.AISense_Blueprint:GetAllListenerActors");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

static void UAISense_Damage::ReportDamageEvent(class UObject* WorldContextObject, class AActor* DamagedActor, class AActor* Instigator, float DamageAmount, struct FVector EventLocation, struct FVector HitLocation)
{
	struct {
            class UObject* WorldContextObject;
            class AActor* DamagedActor;
            class AActor* Instigator;
            float DamageAmount;
            struct FVector EventLocation;
            struct FVector HitLocation;            void ReturnValue;
	} params{ WorldContextObject, DamagedActor, Instigator, DamageAmount, EventLocation, HitLocation };

    static auto fn = UObject::FindObject("/Script/AIModule.AISense_Damage:ReportDamageEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static void UAISense_Prediction::RequestPawnPredictionEvent(class APawn* Requestor, class AActor* PredictedActor, float PredictionTime)
{
	struct {
            class APawn* Requestor;
            class AActor* PredictedActor;
            float PredictionTime;            void ReturnValue;
	} params{ Requestor, PredictedActor, PredictionTime };

    static auto fn = UObject::FindObject("/Script/AIModule.AISense_Prediction:RequestPawnPredictionEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UAISense_Prediction::RequestControllerPredictionEvent(class AAIController* Requestor, class AActor* PredictedActor, float PredictionTime)
{
	struct {
            class AAIController* Requestor;
            class AActor* PredictedActor;
            float PredictionTime;            void ReturnValue;
	} params{ Requestor, PredictedActor, PredictionTime };

    static auto fn = UObject::FindObject("/Script/AIModule.AISense_Prediction:RequestControllerPredictionEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static class UAITask_RunEQS* UAITask_RunEQS::RunEQS(class AAIController* Controller, class UEnvQuery* QueryTemplate)
{
	struct {
            class AAIController* Controller;
            class UEnvQuery* QueryTemplate;
            class UAITask_RunEQS* ReturnValue;
	} params{ Controller, QueryTemplate };

    static auto fn = UObject::FindObject("/Script/AIModule.AITask_RunEQS:RunEQS");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UBlackboardComponent::SetValueAsVector(FName KeyName, struct FVector VectorValue)
{
	struct {
            FName KeyName;
            struct FVector VectorValue;
	} params{ KeyName, VectorValue };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:SetValueAsVector");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBlackboardComponent::SetValueAsString(FName KeyName, struct FString StringValue)
{
	struct {
            FName KeyName;
            struct FString StringValue;
	} params{ KeyName, StringValue };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:SetValueAsString");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBlackboardComponent::SetValueAsRotator(FName KeyName, struct FRotator VectorValue)
{
	struct {
            FName KeyName;
            struct FRotator VectorValue;
	} params{ KeyName, VectorValue };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:SetValueAsRotator");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBlackboardComponent::SetValueAsObject(FName KeyName, class UObject* ObjectValue)
{
	struct {
            FName KeyName;
            class UObject* ObjectValue;
	} params{ KeyName, ObjectValue };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:SetValueAsObject");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBlackboardComponent::SetValueAsName(FName KeyName, FName NameValue)
{
	struct {
            FName KeyName;
            FName NameValue;
	} params{ KeyName, NameValue };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:SetValueAsName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBlackboardComponent::SetValueAsInt(FName KeyName, int IntValue)
{
	struct {
            FName KeyName;
            int IntValue;
	} params{ KeyName, IntValue };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:SetValueAsInt");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBlackboardComponent::SetValueAsFloat(FName KeyName, float FloatValue)
{
	struct {
            FName KeyName;
            float FloatValue;
	} params{ KeyName, FloatValue };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:SetValueAsFloat");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBlackboardComponent::SetValueAsEnum(FName KeyName, char EnumValue)
{
	struct {
            FName KeyName;
            char EnumValue;
	} params{ KeyName, EnumValue };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:SetValueAsEnum");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBlackboardComponent::SetValueAsClass(FName KeyName, class UObject* ClassValue)
{
	struct {
            FName KeyName;
            class UObject* ClassValue;
	} params{ KeyName, ClassValue };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:SetValueAsClass");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBlackboardComponent::SetValueAsBool(FName KeyName, bool BoolValue)
{
	struct {
            FName KeyName;
            bool BoolValue;
	} params{ KeyName, BoolValue };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:SetValueAsBool");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UBlackboardComponent::IsVectorValueSet(FName KeyName)
{
	struct {
            FName KeyName;
            bool ReturnValue;
	} params{ KeyName };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:IsVectorValueSet");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FVector UBlackboardComponent::GetValueAsVector(FName KeyName)
{
	struct {
            FName KeyName;
            struct FVector ReturnValue;
	} params{ KeyName };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:GetValueAsVector");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FString UBlackboardComponent::GetValueAsString(FName KeyName)
{
	struct {
            FName KeyName;
            struct FString ReturnValue;
	} params{ KeyName };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:GetValueAsString");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FRotator UBlackboardComponent::GetValueAsRotator(FName KeyName)
{
	struct {
            FName KeyName;
            struct FRotator ReturnValue;
	} params{ KeyName };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:GetValueAsRotator");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


class UObject* UBlackboardComponent::GetValueAsObject(FName KeyName)
{
	struct {
            FName KeyName;
            class UObject* ReturnValue;
	} params{ KeyName };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:GetValueAsObject");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


FName UBlackboardComponent::GetValueAsName(FName KeyName)
{
	struct {
            FName KeyName;
            FName ReturnValue;
	} params{ KeyName };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:GetValueAsName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


int UBlackboardComponent::GetValueAsInt(FName KeyName)
{
	struct {
            FName KeyName;
            int ReturnValue;
	} params{ KeyName };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:GetValueAsInt");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


float UBlackboardComponent::GetValueAsFloat(FName KeyName)
{
	struct {
            FName KeyName;
            float ReturnValue;
	} params{ KeyName };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:GetValueAsFloat");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


char UBlackboardComponent::GetValueAsEnum(FName KeyName)
{
	struct {
            FName KeyName;
            char ReturnValue;
	} params{ KeyName };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:GetValueAsEnum");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


class UObject* UBlackboardComponent::GetValueAsClass(FName KeyName)
{
	struct {
            FName KeyName;
            class UObject* ReturnValue;
	} params{ KeyName };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:GetValueAsClass");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UBlackboardComponent::GetValueAsBool(FName KeyName)
{
	struct {
            FName KeyName;
            bool ReturnValue;
	} params{ KeyName };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:GetValueAsBool");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UBlackboardComponent::GetRotationFromEntry(FName KeyName, struct FRotator ResultRotation)
{
	struct {
            FName KeyName;
            struct FRotator ResultRotation;
            bool ReturnValue;
	} params{ KeyName, ResultRotation };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:GetRotationFromEntry");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UBlackboardComponent::GetLocationFromEntry(FName KeyName, struct FVector ResultLocation)
{
	struct {
            FName KeyName;
            struct FVector ResultLocation;
            bool ReturnValue;
	} params{ KeyName, ResultLocation };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:GetLocationFromEntry");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UBlackboardComponent::ClearValue(FName KeyName)
{
	struct {
            FName KeyName;
	} params{ KeyName };

    static auto fn = UObject::FindObject("/Script/AIModule.BlackboardComponent:ClearValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UBTDecorator_BlueprintBase::ReceiveTickAI(class AAIController* OwnerController, class APawn* ControlledPawn, float DeltaSeconds)
{
	struct {
            class AAIController* OwnerController;
            class APawn* ControlledPawn;
            float DeltaSeconds;
	} params{ OwnerController, ControlledPawn, DeltaSeconds };

    static auto fn = UObject::FindObject("/Script/AIModule.BTDecorator_BlueprintBase:ReceiveTickAI");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTDecorator_BlueprintBase::ReceiveTick(class AActor* OwnerActor, float DeltaSeconds)
{
	struct {
            class AActor* OwnerActor;
            float DeltaSeconds;
	} params{ OwnerActor, DeltaSeconds };

    static auto fn = UObject::FindObject("/Script/AIModule.BTDecorator_BlueprintBase:ReceiveTick");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTDecorator_BlueprintBase::ReceiveObserverDeactivatedAI(class AAIController* OwnerController, class APawn* ControlledPawn)
{
	struct {
            class AAIController* OwnerController;
            class APawn* ControlledPawn;
	} params{ OwnerController, ControlledPawn };

    static auto fn = UObject::FindObject("/Script/AIModule.BTDecorator_BlueprintBase:ReceiveObserverDeactivatedAI");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTDecorator_BlueprintBase::ReceiveObserverDeactivated(class AActor* OwnerActor)
{
	struct {
            class AActor* OwnerActor;
	} params{ OwnerActor };

    static auto fn = UObject::FindObject("/Script/AIModule.BTDecorator_BlueprintBase:ReceiveObserverDeactivated");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTDecorator_BlueprintBase::ReceiveObserverActivatedAI(class AAIController* OwnerController, class APawn* ControlledPawn)
{
	struct {
            class AAIController* OwnerController;
            class APawn* ControlledPawn;
	} params{ OwnerController, ControlledPawn };

    static auto fn = UObject::FindObject("/Script/AIModule.BTDecorator_BlueprintBase:ReceiveObserverActivatedAI");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTDecorator_BlueprintBase::ReceiveObserverActivated(class AActor* OwnerActor)
{
	struct {
            class AActor* OwnerActor;
	} params{ OwnerActor };

    static auto fn = UObject::FindObject("/Script/AIModule.BTDecorator_BlueprintBase:ReceiveObserverActivated");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTDecorator_BlueprintBase::ReceiveExecutionStartAI(class AAIController* OwnerController, class APawn* ControlledPawn)
{
	struct {
            class AAIController* OwnerController;
            class APawn* ControlledPawn;
	} params{ OwnerController, ControlledPawn };

    static auto fn = UObject::FindObject("/Script/AIModule.BTDecorator_BlueprintBase:ReceiveExecutionStartAI");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTDecorator_BlueprintBase::ReceiveExecutionStart(class AActor* OwnerActor)
{
	struct {
            class AActor* OwnerActor;
	} params{ OwnerActor };

    static auto fn = UObject::FindObject("/Script/AIModule.BTDecorator_BlueprintBase:ReceiveExecutionStart");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTDecorator_BlueprintBase::ReceiveExecutionFinishAI(class AAIController* OwnerController, class APawn* ControlledPawn, char NodeResult)
{
	struct {
            class AAIController* OwnerController;
            class APawn* ControlledPawn;
            char NodeResult;
	} params{ OwnerController, ControlledPawn, NodeResult };

    static auto fn = UObject::FindObject("/Script/AIModule.BTDecorator_BlueprintBase:ReceiveExecutionFinishAI");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTDecorator_BlueprintBase::ReceiveExecutionFinish(class AActor* OwnerActor, char NodeResult)
{
	struct {
            class AActor* OwnerActor;
            char NodeResult;
	} params{ OwnerActor, NodeResult };

    static auto fn = UObject::FindObject("/Script/AIModule.BTDecorator_BlueprintBase:ReceiveExecutionFinish");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UBTDecorator_BlueprintBase::PerformConditionCheckAI(class AAIController* OwnerController, class APawn* ControlledPawn)
{
	struct {
            class AAIController* OwnerController;
            class APawn* ControlledPawn;
            bool ReturnValue;
	} params{ OwnerController, ControlledPawn };

    static auto fn = UObject::FindObject("/Script/AIModule.BTDecorator_BlueprintBase:PerformConditionCheckAI");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UBTDecorator_BlueprintBase::PerformConditionCheck(class AActor* OwnerActor)
{
	struct {
            class AActor* OwnerActor;
            bool ReturnValue;
	} params{ OwnerActor };

    static auto fn = UObject::FindObject("/Script/AIModule.BTDecorator_BlueprintBase:PerformConditionCheck");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UBTDecorator_BlueprintBase::IsDecoratorObserverActive()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.BTDecorator_BlueprintBase:IsDecoratorObserverActive");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UBTDecorator_BlueprintBase::IsDecoratorExecutionActive()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.BTDecorator_BlueprintBase:IsDecoratorExecutionActive");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

static void UBTFunctionLibrary::StopUsingExternalEvent(class UBTNode* NodeOwner)
{
	struct {
            class UBTNode* NodeOwner;            void ReturnValue;
	} params{ NodeOwner };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:StopUsingExternalEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UBTFunctionLibrary::StartUsingExternalEvent(class UBTNode* NodeOwner, class AActor* OwningActor)
{
	struct {
            class UBTNode* NodeOwner;
            class AActor* OwningActor;            void ReturnValue;
	} params{ NodeOwner, OwningActor };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:StartUsingExternalEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UBTFunctionLibrary::SetBlackboardValueAsVector(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key, struct FVector Value)
{
	struct {
            class UBTNode* NodeOwner;
            struct FBlackboardKeySelector Key;
            struct FVector Value;            void ReturnValue;
	} params{ NodeOwner, Key, Value };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:SetBlackboardValueAsVector");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UBTFunctionLibrary::SetBlackboardValueAsString(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key, struct FString Value)
{
	struct {
            class UBTNode* NodeOwner;
            struct FBlackboardKeySelector Key;
            struct FString Value;            void ReturnValue;
	} params{ NodeOwner, Key, Value };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:SetBlackboardValueAsString");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UBTFunctionLibrary::SetBlackboardValueAsRotator(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key, struct FRotator Value)
{
	struct {
            class UBTNode* NodeOwner;
            struct FBlackboardKeySelector Key;
            struct FRotator Value;            void ReturnValue;
	} params{ NodeOwner, Key, Value };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:SetBlackboardValueAsRotator");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UBTFunctionLibrary::SetBlackboardValueAsObject(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key, class UObject* Value)
{
	struct {
            class UBTNode* NodeOwner;
            struct FBlackboardKeySelector Key;
            class UObject* Value;            void ReturnValue;
	} params{ NodeOwner, Key, Value };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:SetBlackboardValueAsObject");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UBTFunctionLibrary::SetBlackboardValueAsName(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key, FName Value)
{
	struct {
            class UBTNode* NodeOwner;
            struct FBlackboardKeySelector Key;
            FName Value;            void ReturnValue;
	} params{ NodeOwner, Key, Value };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:SetBlackboardValueAsName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UBTFunctionLibrary::SetBlackboardValueAsInt(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key, int Value)
{
	struct {
            class UBTNode* NodeOwner;
            struct FBlackboardKeySelector Key;
            int Value;            void ReturnValue;
	} params{ NodeOwner, Key, Value };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:SetBlackboardValueAsInt");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UBTFunctionLibrary::SetBlackboardValueAsFloat(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key, float Value)
{
	struct {
            class UBTNode* NodeOwner;
            struct FBlackboardKeySelector Key;
            float Value;            void ReturnValue;
	} params{ NodeOwner, Key, Value };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:SetBlackboardValueAsFloat");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UBTFunctionLibrary::SetBlackboardValueAsEnum(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key, char Value)
{
	struct {
            class UBTNode* NodeOwner;
            struct FBlackboardKeySelector Key;
            char Value;            void ReturnValue;
	} params{ NodeOwner, Key, Value };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:SetBlackboardValueAsEnum");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UBTFunctionLibrary::SetBlackboardValueAsClass(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key, class UObject* Value)
{
	struct {
            class UBTNode* NodeOwner;
            struct FBlackboardKeySelector Key;
            class UObject* Value;            void ReturnValue;
	} params{ NodeOwner, Key, Value };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:SetBlackboardValueAsClass");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UBTFunctionLibrary::SetBlackboardValueAsBool(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key, bool Value)
{
	struct {
            class UBTNode* NodeOwner;
            struct FBlackboardKeySelector Key;
            bool Value;            void ReturnValue;
	} params{ NodeOwner, Key, Value };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:SetBlackboardValueAsBool");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UBlackboardComponent* UBTFunctionLibrary::GetOwnersBlackboard(class UBTNode* NodeOwner)
{
	struct {
            class UBTNode* NodeOwner;
            class UBlackboardComponent* ReturnValue;
	} params{ NodeOwner };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:GetOwnersBlackboard");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UBehaviorTreeComponent* UBTFunctionLibrary::GetOwnerComponent(class UBTNode* NodeOwner)
{
	struct {
            class UBTNode* NodeOwner;
            class UBehaviorTreeComponent* ReturnValue;
	} params{ NodeOwner };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:GetOwnerComponent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FVector UBTFunctionLibrary::GetBlackboardValueAsVector(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key)
{
	struct {
            class UBTNode* NodeOwner;
            struct FBlackboardKeySelector Key;
            struct FVector ReturnValue;
	} params{ NodeOwner, Key };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:GetBlackboardValueAsVector");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FString UBTFunctionLibrary::GetBlackboardValueAsString(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key)
{
	struct {
            class UBTNode* NodeOwner;
            struct FBlackboardKeySelector Key;
            struct FString ReturnValue;
	} params{ NodeOwner, Key };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:GetBlackboardValueAsString");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FRotator UBTFunctionLibrary::GetBlackboardValueAsRotator(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key)
{
	struct {
            class UBTNode* NodeOwner;
            struct FBlackboardKeySelector Key;
            struct FRotator ReturnValue;
	} params{ NodeOwner, Key };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:GetBlackboardValueAsRotator");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UObject* UBTFunctionLibrary::GetBlackboardValueAsObject(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key)
{
	struct {
            class UBTNode* NodeOwner;
            struct FBlackboardKeySelector Key;
            class UObject* ReturnValue;
	} params{ NodeOwner, Key };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:GetBlackboardValueAsObject");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static FName UBTFunctionLibrary::GetBlackboardValueAsName(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key)
{
	struct {
            class UBTNode* NodeOwner;
            struct FBlackboardKeySelector Key;
            FName ReturnValue;
	} params{ NodeOwner, Key };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:GetBlackboardValueAsName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static int UBTFunctionLibrary::GetBlackboardValueAsInt(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key)
{
	struct {
            class UBTNode* NodeOwner;
            struct FBlackboardKeySelector Key;
            int ReturnValue;
	} params{ NodeOwner, Key };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:GetBlackboardValueAsInt");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static float UBTFunctionLibrary::GetBlackboardValueAsFloat(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key)
{
	struct {
            class UBTNode* NodeOwner;
            struct FBlackboardKeySelector Key;
            float ReturnValue;
	} params{ NodeOwner, Key };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:GetBlackboardValueAsFloat");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static char UBTFunctionLibrary::GetBlackboardValueAsEnum(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key)
{
	struct {
            class UBTNode* NodeOwner;
            struct FBlackboardKeySelector Key;
            char ReturnValue;
	} params{ NodeOwner, Key };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:GetBlackboardValueAsEnum");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UObject* UBTFunctionLibrary::GetBlackboardValueAsClass(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key)
{
	struct {
            class UBTNode* NodeOwner;
            struct FBlackboardKeySelector Key;
            class UObject* ReturnValue;
	} params{ NodeOwner, Key };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:GetBlackboardValueAsClass");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UBTFunctionLibrary::GetBlackboardValueAsBool(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key)
{
	struct {
            class UBTNode* NodeOwner;
            struct FBlackboardKeySelector Key;
            bool ReturnValue;
	} params{ NodeOwner, Key };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:GetBlackboardValueAsBool");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class AActor* UBTFunctionLibrary::GetBlackboardValueAsActor(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key)
{
	struct {
            class UBTNode* NodeOwner;
            struct FBlackboardKeySelector Key;
            class AActor* ReturnValue;
	} params{ NodeOwner, Key };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:GetBlackboardValueAsActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UBTFunctionLibrary::ClearBlackboardValueAsVector(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key)
{
	struct {
            class UBTNode* NodeOwner;
            struct FBlackboardKeySelector Key;            void ReturnValue;
	} params{ NodeOwner, Key };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:ClearBlackboardValueAsVector");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UBTFunctionLibrary::ClearBlackboardValue(class UBTNode* NodeOwner, struct FBlackboardKeySelector Key)
{
	struct {
            class UBTNode* NodeOwner;
            struct FBlackboardKeySelector Key;            void ReturnValue;
	} params{ NodeOwner, Key };

    static auto fn = UObject::FindObject("/Script/AIModule.BTFunctionLibrary:ClearBlackboardValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UBTService_BlueprintBase::ReceiveTickAI(class AAIController* OwnerController, class APawn* ControlledPawn, float DeltaSeconds)
{
	struct {
            class AAIController* OwnerController;
            class APawn* ControlledPawn;
            float DeltaSeconds;
	} params{ OwnerController, ControlledPawn, DeltaSeconds };

    static auto fn = UObject::FindObject("/Script/AIModule.BTService_BlueprintBase:ReceiveTickAI");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTService_BlueprintBase::ReceiveTick(class AActor* OwnerActor, float DeltaSeconds)
{
	struct {
            class AActor* OwnerActor;
            float DeltaSeconds;
	} params{ OwnerActor, DeltaSeconds };

    static auto fn = UObject::FindObject("/Script/AIModule.BTService_BlueprintBase:ReceiveTick");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTService_BlueprintBase::ReceiveSearchStartAI(class AAIController* OwnerController, class APawn* ControlledPawn)
{
	struct {
            class AAIController* OwnerController;
            class APawn* ControlledPawn;
	} params{ OwnerController, ControlledPawn };

    static auto fn = UObject::FindObject("/Script/AIModule.BTService_BlueprintBase:ReceiveSearchStartAI");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTService_BlueprintBase::ReceiveSearchStart(class AActor* OwnerActor)
{
	struct {
            class AActor* OwnerActor;
	} params{ OwnerActor };

    static auto fn = UObject::FindObject("/Script/AIModule.BTService_BlueprintBase:ReceiveSearchStart");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTService_BlueprintBase::ReceiveDeactivationAI(class AAIController* OwnerController, class APawn* ControlledPawn)
{
	struct {
            class AAIController* OwnerController;
            class APawn* ControlledPawn;
	} params{ OwnerController, ControlledPawn };

    static auto fn = UObject::FindObject("/Script/AIModule.BTService_BlueprintBase:ReceiveDeactivationAI");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTService_BlueprintBase::ReceiveDeactivation(class AActor* OwnerActor)
{
	struct {
            class AActor* OwnerActor;
	} params{ OwnerActor };

    static auto fn = UObject::FindObject("/Script/AIModule.BTService_BlueprintBase:ReceiveDeactivation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTService_BlueprintBase::ReceiveActivationAI(class AAIController* OwnerController, class APawn* ControlledPawn)
{
	struct {
            class AAIController* OwnerController;
            class APawn* ControlledPawn;
	} params{ OwnerController, ControlledPawn };

    static auto fn = UObject::FindObject("/Script/AIModule.BTService_BlueprintBase:ReceiveActivationAI");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTService_BlueprintBase::ReceiveActivation(class AActor* OwnerActor)
{
	struct {
            class AActor* OwnerActor;
	} params{ OwnerActor };

    static auto fn = UObject::FindObject("/Script/AIModule.BTService_BlueprintBase:ReceiveActivation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UBTService_BlueprintBase::IsServiceActive()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.BTService_BlueprintBase:IsServiceActive");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UBTTask_BlueprintBase::SetFinishOnMessageWithId(FName MessageName, int RequestId)
{
	struct {
            FName MessageName;
            int RequestId;
	} params{ MessageName, RequestId };

    static auto fn = UObject::FindObject("/Script/AIModule.BTTask_BlueprintBase:SetFinishOnMessageWithId");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTTask_BlueprintBase::SetFinishOnMessage(FName MessageName)
{
	struct {
            FName MessageName;
	} params{ MessageName };

    static auto fn = UObject::FindObject("/Script/AIModule.BTTask_BlueprintBase:SetFinishOnMessage");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTTask_BlueprintBase::ReceiveTickAI(class AAIController* OwnerController, class APawn* ControlledPawn, float DeltaSeconds)
{
	struct {
            class AAIController* OwnerController;
            class APawn* ControlledPawn;
            float DeltaSeconds;
	} params{ OwnerController, ControlledPawn, DeltaSeconds };

    static auto fn = UObject::FindObject("/Script/AIModule.BTTask_BlueprintBase:ReceiveTickAI");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTTask_BlueprintBase::ReceiveTick(class AActor* OwnerActor, float DeltaSeconds)
{
	struct {
            class AActor* OwnerActor;
            float DeltaSeconds;
	} params{ OwnerActor, DeltaSeconds };

    static auto fn = UObject::FindObject("/Script/AIModule.BTTask_BlueprintBase:ReceiveTick");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTTask_BlueprintBase::ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn)
{
	struct {
            class AAIController* OwnerController;
            class APawn* ControlledPawn;
	} params{ OwnerController, ControlledPawn };

    static auto fn = UObject::FindObject("/Script/AIModule.BTTask_BlueprintBase:ReceiveExecuteAI");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTTask_BlueprintBase::ReceiveExecute(class AActor* OwnerActor)
{
	struct {
            class AActor* OwnerActor;
	} params{ OwnerActor };

    static auto fn = UObject::FindObject("/Script/AIModule.BTTask_BlueprintBase:ReceiveExecute");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTTask_BlueprintBase::ReceiveAbortAI(class AAIController* OwnerController, class APawn* ControlledPawn)
{
	struct {
            class AAIController* OwnerController;
            class APawn* ControlledPawn;
	} params{ OwnerController, ControlledPawn };

    static auto fn = UObject::FindObject("/Script/AIModule.BTTask_BlueprintBase:ReceiveAbortAI");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTTask_BlueprintBase::ReceiveAbort(class AActor* OwnerActor)
{
	struct {
            class AActor* OwnerActor;
	} params{ OwnerActor };

    static auto fn = UObject::FindObject("/Script/AIModule.BTTask_BlueprintBase:ReceiveAbort");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UBTTask_BlueprintBase::IsTaskExecuting()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.BTTask_BlueprintBase:IsTaskExecuting");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UBTTask_BlueprintBase::IsTaskAborting()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.BTTask_BlueprintBase:IsTaskAborting");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UBTTask_BlueprintBase::FinishExecute(bool bSuccess)
{
	struct {
            bool bSuccess;
	} params{ bSuccess };

    static auto fn = UObject::FindObject("/Script/AIModule.BTTask_BlueprintBase:FinishExecute");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBTTask_BlueprintBase::FinishAbort()
{
    static auto fn = UObject::FindObject("/Script/AIModule.BTTask_BlueprintBase:FinishAbort");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

void UEnvQueryContext_BlueprintBase::ProvideSingleLocation(class UObject* QuerierObject, class AActor* QuerierActor, struct FVector ResultingLocation)
{
	struct {
            class UObject* QuerierObject;
            class AActor* QuerierActor;
            struct FVector ResultingLocation;
	} params{ QuerierObject, QuerierActor, ResultingLocation };

    static auto fn = UObject::FindObject("/Script/AIModule.EnvQueryContext_BlueprintBase:ProvideSingleLocation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UEnvQueryContext_BlueprintBase::ProvideSingleActor(class UObject* QuerierObject, class AActor* QuerierActor, class AActor* ResultingActor)
{
	struct {
            class UObject* QuerierObject;
            class AActor* QuerierActor;
            class AActor* ResultingActor;
	} params{ QuerierObject, QuerierActor, ResultingActor };

    static auto fn = UObject::FindObject("/Script/AIModule.EnvQueryContext_BlueprintBase:ProvideSingleActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UEnvQueryContext_BlueprintBase::ProvideLocationsSet(class UObject* QuerierObject, class AActor* QuerierActor, TArray<struct FVector> ResultingLocationSet)
{
	struct {
            class UObject* QuerierObject;
            class AActor* QuerierActor;
            TArray<struct FVector> ResultingLocationSet;
	} params{ QuerierObject, QuerierActor, ResultingLocationSet };

    static auto fn = UObject::FindObject("/Script/AIModule.EnvQueryContext_BlueprintBase:ProvideLocationsSet");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UEnvQueryContext_BlueprintBase::ProvideActorsSet(class UObject* QuerierObject, class AActor* QuerierActor, TArray<class AActor*> ResultingActorsSet)
{
	struct {
            class UObject* QuerierObject;
            class AActor* QuerierActor;
            TArray<class AActor*> ResultingActorsSet;
	} params{ QuerierObject, QuerierActor, ResultingActorsSet };

    static auto fn = UObject::FindObject("/Script/AIModule.EnvQueryContext_BlueprintBase:ProvideActorsSet");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

class UObject* UEnvQueryGenerator_BlueprintBase::GetQuerier()
{
	struct {
            class UObject* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.EnvQueryGenerator_BlueprintBase:GetQuerier");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UEnvQueryGenerator_BlueprintBase::DoItemGeneration(TArray<struct FVector> ContextLocations)
{
	struct {
            TArray<struct FVector> ContextLocations;
	} params{ ContextLocations };

    static auto fn = UObject::FindObject("/Script/AIModule.EnvQueryGenerator_BlueprintBase:DoItemGeneration");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UEnvQueryGenerator_BlueprintBase::AddGeneratedVector(struct FVector GeneratedVector)
{
	struct {
            struct FVector GeneratedVector;
	} params{ GeneratedVector };

    static auto fn = UObject::FindObject("/Script/AIModule.EnvQueryGenerator_BlueprintBase:AddGeneratedVector");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UEnvQueryGenerator_BlueprintBase::AddGeneratedActor(class AActor* GeneratedActor)
{
	struct {
            class AActor* GeneratedActor;
	} params{ GeneratedActor };

    static auto fn = UObject::FindObject("/Script/AIModule.EnvQueryGenerator_BlueprintBase:AddGeneratedActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UEnvQueryInstanceBlueprintWrapper::SetNamedParam(FName ParamName, float Value)
{
	struct {
            FName ParamName;
            float Value;
	} params{ ParamName, Value };

    static auto fn = UObject::FindObject("/Script/AIModule.EnvQueryInstanceBlueprintWrapper:SetNamedParam");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


TArray<struct FVector> UEnvQueryInstanceBlueprintWrapper::GetResultsAsLocations()
{
	struct {
            TArray<struct FVector> ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.EnvQueryInstanceBlueprintWrapper:GetResultsAsLocations");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


TArray<class AActor*> UEnvQueryInstanceBlueprintWrapper::GetResultsAsActors()
{
	struct {
            TArray<class AActor*> ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.EnvQueryInstanceBlueprintWrapper:GetResultsAsActors");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UEnvQueryInstanceBlueprintWrapper::GetQueryResultsAsLocations(TArray<struct FVector> ResultLocations)
{
	struct {
            TArray<struct FVector> ResultLocations;
            bool ReturnValue;
	} params{ ResultLocations };

    static auto fn = UObject::FindObject("/Script/AIModule.EnvQueryInstanceBlueprintWrapper:GetQueryResultsAsLocations");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UEnvQueryInstanceBlueprintWrapper::GetQueryResultsAsActors(TArray<class AActor*> ResultActors)
{
	struct {
            TArray<class AActor*> ResultActors;
            bool ReturnValue;
	} params{ ResultActors };

    static auto fn = UObject::FindObject("/Script/AIModule.EnvQueryInstanceBlueprintWrapper:GetQueryResultsAsActors");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


float UEnvQueryInstanceBlueprintWrapper::GetItemScore(int ItemIndex)
{
	struct {
            int ItemIndex;
            float ReturnValue;
	} params{ ItemIndex };

    static auto fn = UObject::FindObject("/Script/AIModule.EnvQueryInstanceBlueprintWrapper:GetItemScore");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UEnvQueryInstanceBlueprintWrapper* UEnvQueryManager::RunEQSQuery(class UObject* WorldContextObject, class UEnvQuery* QueryTemplate, class UObject* Querier, char RunMode, class UEnvQueryInstanceBlueprintWrapper* WrapperClass)
{
	struct {
            class UObject* WorldContextObject;
            class UEnvQuery* QueryTemplate;
            class UObject* Querier;
            char RunMode;
            class UEnvQueryInstanceBlueprintWrapper* WrapperClass;
            class UEnvQueryInstanceBlueprintWrapper* ReturnValue;
	} params{ WorldContextObject, QueryTemplate, Querier, RunMode, WrapperClass };

    static auto fn = UObject::FindObject("/Script/AIModule.EnvQueryManager:RunEQSQuery");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

static bool UNavLocalGridManager::SetLocalNavigationGridDensity(class UObject* WorldContextObject, float CellSize)
{
	struct {
            class UObject* WorldContextObject;
            float CellSize;
            bool ReturnValue;
	} params{ WorldContextObject, CellSize };

    static auto fn = UObject::FindObject("/Script/AIModule.NavLocalGridManager:SetLocalNavigationGridDensity");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UNavLocalGridManager::RemoveLocalNavigationGrid(class UObject* WorldContextObject, int GridId, bool bRebuildGrids)
{
	struct {
            class UObject* WorldContextObject;
            int GridId;
            bool bRebuildGrids;            void ReturnValue;
	} params{ WorldContextObject, GridId, bRebuildGrids };

    static auto fn = UObject::FindObject("/Script/AIModule.NavLocalGridManager:RemoveLocalNavigationGrid");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UNavLocalGridManager::FindLocalNavigationGridPath(class UObject* WorldContextObject, struct FVector Start, struct FVector End, TArray<struct FVector> PathPoints)
{
	struct {
            class UObject* WorldContextObject;
            struct FVector Start;
            struct FVector End;
            TArray<struct FVector> PathPoints;
            bool ReturnValue;
	} params{ WorldContextObject, Start, End, PathPoints };

    static auto fn = UObject::FindObject("/Script/AIModule.NavLocalGridManager:FindLocalNavigationGridPath");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static int UNavLocalGridManager::AddLocalNavigationGridForPoints(class UObject* WorldContextObject, TArray<struct FVector> Locations, int Radius2D, float Height, bool bRebuildGrids)
{
	struct {
            class UObject* WorldContextObject;
            TArray<struct FVector> Locations;
            int Radius2D;
            float Height;
            bool bRebuildGrids;
            int ReturnValue;
	} params{ WorldContextObject, Locations, Radius2D, Height, bRebuildGrids };

    static auto fn = UObject::FindObject("/Script/AIModule.NavLocalGridManager:AddLocalNavigationGridForPoints");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static int UNavLocalGridManager::AddLocalNavigationGridForPoint(class UObject* WorldContextObject, struct FVector Location, int Radius2D, float Height, bool bRebuildGrids)
{
	struct {
            class UObject* WorldContextObject;
            struct FVector Location;
            int Radius2D;
            float Height;
            bool bRebuildGrids;
            int ReturnValue;
	} params{ WorldContextObject, Location, Radius2D, Height, bRebuildGrids };

    static auto fn = UObject::FindObject("/Script/AIModule.NavLocalGridManager:AddLocalNavigationGridForPoint");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static int UNavLocalGridManager::AddLocalNavigationGridForCapsule(class UObject* WorldContextObject, struct FVector Location, float CapsuleRadius, float CapsuleHalfHeight, int Radius2D, float Height, bool bRebuildGrids)
{
	struct {
            class UObject* WorldContextObject;
            struct FVector Location;
            float CapsuleRadius;
            float CapsuleHalfHeight;
            int Radius2D;
            float Height;
            bool bRebuildGrids;
            int ReturnValue;
	} params{ WorldContextObject, Location, CapsuleRadius, CapsuleHalfHeight, Radius2D, Height, bRebuildGrids };

    static auto fn = UObject::FindObject("/Script/AIModule.NavLocalGridManager:AddLocalNavigationGridForCapsule");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static int UNavLocalGridManager::AddLocalNavigationGridForBox(class UObject* WorldContextObject, struct FVector Location, struct FVector Extent, struct FRotator Rotation, int Radius2D, float Height, bool bRebuildGrids)
{
	struct {
            class UObject* WorldContextObject;
            struct FVector Location;
            struct FVector Extent;
            struct FRotator Rotation;
            int Radius2D;
            float Height;
            bool bRebuildGrids;
            int ReturnValue;
	} params{ WorldContextObject, Location, Extent, Rotation, Radius2D, Height, bRebuildGrids };

    static auto fn = UObject::FindObject("/Script/AIModule.NavLocalGridManager:AddLocalNavigationGridForBox");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

char UPawnAction::GetActionPriority()
{
	struct {
            char ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.PawnAction:GetActionPriority");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UPawnAction::Finish(char WithResult)
{
	struct {
            char WithResult;
	} params{ WithResult };

    static auto fn = UObject::FindObject("/Script/AIModule.PawnAction:Finish");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


static class UPawnAction* UPawnAction::CreateActionInstance(class UObject* WorldContextObject, class UPawnAction* ActionClass)
{
	struct {
            class UObject* WorldContextObject;
            class UPawnAction* ActionClass;
            class UPawnAction* ReturnValue;
	} params{ WorldContextObject, ActionClass };

    static auto fn = UObject::FindObject("/Script/AIModule.PawnAction:CreateActionInstance");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UPawnAction_BlueprintBase::ActionTick(class APawn* ControlledPawn, float DeltaSeconds)
{
	struct {
            class APawn* ControlledPawn;
            float DeltaSeconds;
	} params{ ControlledPawn, DeltaSeconds };

    static auto fn = UObject::FindObject("/Script/AIModule.PawnAction_BlueprintBase:ActionTick");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UPawnAction_BlueprintBase::ActionStart(class APawn* ControlledPawn)
{
	struct {
            class APawn* ControlledPawn;
	} params{ ControlledPawn };

    static auto fn = UObject::FindObject("/Script/AIModule.PawnAction_BlueprintBase:ActionStart");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UPawnAction_BlueprintBase::ActionResume(class APawn* ControlledPawn)
{
	struct {
            class APawn* ControlledPawn;
	} params{ ControlledPawn };

    static auto fn = UObject::FindObject("/Script/AIModule.PawnAction_BlueprintBase:ActionResume");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UPawnAction_BlueprintBase::ActionPause(class APawn* ControlledPawn)
{
	struct {
            class APawn* ControlledPawn;
	} params{ ControlledPawn };

    static auto fn = UObject::FindObject("/Script/AIModule.PawnAction_BlueprintBase:ActionPause");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UPawnAction_BlueprintBase::ActionFinished(class APawn* ControlledPawn, char WithResult)
{
	struct {
            class APawn* ControlledPawn;
            char WithResult;
	} params{ ControlledPawn, WithResult };

    static auto fn = UObject::FindObject("/Script/AIModule.PawnAction_BlueprintBase:ActionFinished");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

bool UPawnActionsComponent::K2_PushAction(class UPawnAction* NewAction, char Priority, class UObject* Instigator)
{
	struct {
            class UPawnAction* NewAction;
            char Priority;
            class UObject* Instigator;
            bool ReturnValue;
	} params{ NewAction, Priority, Instigator };

    static auto fn = UObject::FindObject("/Script/AIModule.PawnActionsComponent:K2_PushAction");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UPawnActionsComponent::K2_PerformAction(class APawn* Pawn, class UPawnAction* Action, char Priority)
{
	struct {
            class APawn* Pawn;
            class UPawnAction* Action;
            char Priority;
            bool ReturnValue;
	} params{ Pawn, Action, Priority };

    static auto fn = UObject::FindObject("/Script/AIModule.PawnActionsComponent:K2_PerformAction");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


char UPawnActionsComponent::K2_ForceAbortAction(class UPawnAction* ActionToAbort)
{
	struct {
            class UPawnAction* ActionToAbort;
            char ReturnValue;
	} params{ ActionToAbort };

    static auto fn = UObject::FindObject("/Script/AIModule.PawnActionsComponent:K2_ForceAbortAction");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


char UPawnActionsComponent::K2_AbortAction(class UPawnAction* ActionToAbort)
{
	struct {
            class UPawnAction* ActionToAbort;
            char ReturnValue;
	} params{ ActionToAbort };

    static auto fn = UObject::FindObject("/Script/AIModule.PawnActionsComponent:K2_AbortAction");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UPawnSensingComponent::SetSensingUpdatesEnabled(bool bEnabled)
{
	struct {
            bool bEnabled;
	} params{ bEnabled };

    static auto fn = UObject::FindObject("/Script/AIModule.PawnSensingComponent:SetSensingUpdatesEnabled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UPawnSensingComponent::SetSensingInterval(float NewSensingInterval)
{
	struct {
            float NewSensingInterval;
	} params{ NewSensingInterval };

    static auto fn = UObject::FindObject("/Script/AIModule.PawnSensingComponent:SetSensingInterval");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UPawnSensingComponent::SetPeripheralVisionAngle(float NewPeripheralVisionAngle)
{
	struct {
            float NewPeripheralVisionAngle;
	} params{ NewPeripheralVisionAngle };

    static auto fn = UObject::FindObject("/Script/AIModule.PawnSensingComponent:SetPeripheralVisionAngle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


float UPawnSensingComponent::GetPeripheralVisionCosine()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.PawnSensingComponent:GetPeripheralVisionCosine");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UPawnSensingComponent::GetPeripheralVisionAngle()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/AIModule.PawnSensingComponent:GetPeripheralVisionAngle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

