#pragma once

#include "../SDK.hpp"

namespace SDK {


class UInputCoreTypes : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/InputCore.InputCoreTypes");
			return (class UClass*)ptr;
		};

};


}