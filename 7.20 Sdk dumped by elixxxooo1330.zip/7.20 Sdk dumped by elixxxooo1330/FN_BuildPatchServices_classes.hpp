#pragma once

#include "../SDK.hpp"

namespace SDK {


class UBuildPatchManifest : public UObject
{
	public:
	    char ManifestFileVersion; // 0x28 Size: 0x1
	    bool bIsFileData; // 0x29 Size: 0x1
	    char UnknownData0[0x2]; // 0x2a
	    uint32_t AppID; // 0x2c Size: 0x4
	    struct FString AppName; // 0x30 Size: 0x10
	    struct FString BuildVersion; // 0x40 Size: 0x10
	    struct FString LaunchExe; // 0x50 Size: 0x10
	    struct FString LaunchCommand; // 0x60 Size: 0x10
	    __int64/*SetProperty*/ PrereqIds; // 0x70 Size: 0x50
	    struct FString PrereqName; // 0xc0 Size: 0x10
	    struct FString PrereqPath; // 0xd0 Size: 0x10
	    struct FString PrereqArgs; // 0xe0 Size: 0x10
	    TArray<struct FFileManifestData> FileManifestList; // 0xf0 Size: 0x10
	    TArray<struct FChunkInfoData> ChunkList; // 0x100 Size: 0x10
	    TArray<struct FCustomFieldData> CustomFields; // 0x110 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/BuildPatchServices.BuildPatchManifest");
			return (class UClass*)ptr;
		};

};


}