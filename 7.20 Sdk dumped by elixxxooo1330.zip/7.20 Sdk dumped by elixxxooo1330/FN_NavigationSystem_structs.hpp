#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FOnNavigationPathUpdated__DelegateSignature
{
	public:
	    class UNavigationPath* AffectedPath; // 0x0 Size: 0x8
	    char PathEvent; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FOnNavDataGenericEvent__DelegateSignature
{
	public:
	    class ANavigationData* NavData; // 0x0 Size: 0x8

};



enum class ERuntimeGenerationType : uint8_t
{
    Static = 0,
    DynamicModifiersOnly = 1,
    Dynamic = 2,
    LegacyGeneration = 3,
    ERuntimeGenerationType_MAX = 4
};

enum class ENavCostDisplay : uint8_t
{
    TotalCost = 0,
    HeuristicOnly = 1,
    RealCostOnly = 2,
    ENavCostDisplay_MAX = 3
};

enum class ERecastPartitioning : uint8_t
{
    Monotone = 0,
    Watershed = 1,
    ChunkyMonotone = 2,
    ERecastPartitioning_MAX = 3
};struct FNavCollisionBox
{
	public:
	    struct FVector Offset; // 0x0 Size: 0xc
	    struct FVector Extent; // 0xc Size: 0xc

};

struct FNavCollisionCylinder
{
	public:
	    struct FVector Offset; // 0x0 Size: 0xc
	    float Radius; // 0xc Size: 0x4
	    float Height; // 0x10 Size: 0x4

};

struct FSupportedAreaData
{
	public:
	    struct FString AreaClassName; // 0x0 Size: 0x10
	    int AreaID; // 0x10 Size: 0x4
	    char UnknownData0[0x4]; // 0x14
	    class UObject* AreaClass; // 0x18 Size: 0x8

};

struct FNavGraphNode
{
	public:
	    class UObject* Owner; // 0x0 Size: 0x8
	    char UnknownData0[0x10];

};

struct FNavGraphEdge
{
	public:
	    char UnknownData0[0x18];

};

struct FNavigationFilterFlags
{
	public:
	    bool bNavFlag0; // 0x0 Size: 0x1
	    bool bNavFlag1; // 0x0 Size: 0x1
	    bool bNavFlag2; // 0x0 Size: 0x1
	    bool bNavFlag3; // 0x0 Size: 0x1
	    bool bNavFlag4; // 0x0 Size: 0x1
	    bool bNavFlag5; // 0x0 Size: 0x1
	    bool bNavFlag6; // 0x0 Size: 0x1
	    bool bNavFlag7; // 0x0 Size: 0x1
	    bool bNavFlag8; // 0x1 Size: 0x1
	    bool bNavFlag9; // 0x1 Size: 0x1
	    bool bNavFlag10; // 0x1 Size: 0x1
	    bool bNavFlag11; // 0x1 Size: 0x1
	    bool bNavFlag12; // 0x1 Size: 0x1
	    bool bNavFlag13; // 0x1 Size: 0x1
	    bool bNavFlag14; // 0x1 Size: 0x1
	    bool bNavFlag15; // 0x1 Size: 0x1
	    char UnknownData0[0x-c];

};

struct FNavigationFilterArea
{
	public:
	    class UNavArea* AreaClass; // 0x0 Size: 0x8
	    float TravelCostOverride; // 0x8 Size: 0x4
	    float EnteringCostOverride; // 0xc Size: 0x4
	    bool bIsExcluded; // 0x10 Size: 0x1
	    bool bOverrideTravelCost; // 0x10 Size: 0x1
	    bool bOverrideEnteringCost; // 0x10 Size: 0x1
	    char UnknownData0[0x5];

};


}