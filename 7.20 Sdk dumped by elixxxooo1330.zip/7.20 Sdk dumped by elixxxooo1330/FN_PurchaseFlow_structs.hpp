#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FPurchaseFlowItem
{
	public:
	    struct FString ItemId; // 0x0 Size: 0x10
	    struct FString EntitlementId; // 0x10 Size: 0x10
	    struct FString ValidationInfo; // 0x20 Size: 0x10

};


}