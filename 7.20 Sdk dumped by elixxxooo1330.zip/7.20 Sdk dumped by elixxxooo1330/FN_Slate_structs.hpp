#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class ETextFlowDirection : uint8_t
{
    Auto = 0,
    LeftToRight = 1,
    RightToLeft = 2,
    ETextFlowDirection_MAX = 3
};

enum class ETextJustify : uint8_t
{
    Left = 0,
    Center = 1,
    Right = 2,
    ETextJustify_MAX = 3
};

enum class EVirtualKeyboardDismissAction : uint8_t
{
    TextChangeOnDismiss = 0,
    TextCommitOnAccept = 1,
    TextCommitOnDismiss = 2,
    EVirtualKeyboardDismissAction_MAX = 3
};struct FVirtualKeyboardOptions
{
	public:
	    bool bEnableAutocorrect; // 0x0 Size: 0x1

};

struct FInputChord
{
	public:
	    struct FKey Key; // 0x0 Size: 0x18
	    bool bShift; // 0x18 Size: 0x1
	    bool bCtrl; // 0x18 Size: 0x1
	    bool bAlt; // 0x18 Size: 0x1
	    bool bCmd; // 0x18 Size: 0x1
	    char UnknownData0[0x4];

};



enum class ETextWrappingPolicy : uint8_t
{
    DefaultWrapping = 0,
    AllowPerCharacterWrapping = 1,
    ETextWrappingPolicy_MAX = 2
};struct FAnchors
{
	public:
	    struct FVector2D Minimum; // 0x0 Size: 0x8
	    struct FVector2D Maximum; // 0x8 Size: 0x8

};



enum class ETableViewMode : uint8_t
{
    List = 0,
    Tile = 1,
    Tree = 2,
    ETableViewMode_MAX = 3
};

enum class ESelectionMode : uint8_t
{
    None = 0,
    Single = 1,
    SingleToggle = 2,
    Multi = 3,
    ESelectionMode_MAX = 4
};

enum class EProgressBarFillType : uint8_t
{
    LeftToRight = 0,
    RightToLeft = 1,
    FillFromCenter = 2,
    TopToBottom = 3,
    BottomToTop = 4,
    EProgressBarFillType_MAX = 5
};

enum class EStretch : uint8_t
{
    None = 0,
    Fill = 1,
    ScaleToFit = 2,
    ScaleToFitX = 3,
    ScaleToFitY = 4,
    ScaleToFill = 5,
    ScaleBySafeZone = 6,
    UserSpecified = 7,
    EStretch_MAX = 8
};

enum class EStretchDirection : uint8_t
{
    Both = 0,
    DownOnly = 1,
    UpOnly = 2,
    EStretchDirection_MAX = 3
};

enum class EDescendantScrollDestination : uint8_t
{
    IntoView = 0,
    TopOrLeft = 1,
    Center = 2,
    EDescendantScrollDestination_MAX = 3
};

enum class EListItemAlignment : uint8_t
{
    EvenlyDistributed = 0,
    EvenlySize = 1,
    EvenlyWide = 2,
    LeftAligned = 3,
    RightAligned = 4,
    CenterAligned = 5,
    Fill = 6,
    EListItemAlignment_MAX = 7
};

enum class EMultipleKeyBindingIndex : uint8_t
{
    Primary = 0,
    Secondary = 1,
    NumChords = 2,
    EMultipleKeyBindingIndex_MAX = 3
};
}