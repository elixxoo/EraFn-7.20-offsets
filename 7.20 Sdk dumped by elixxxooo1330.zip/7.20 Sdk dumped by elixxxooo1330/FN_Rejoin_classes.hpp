#pragma once

#include "../SDK.hpp"

namespace SDK {


class URejoinCheck : public UObject
{
	public:
	    ERejoinStatus LastKnownStatus; // 0x28 Size: 0x1
	    bool bRejoinAfterCheck; // 0x29 Size: 0x1
	    bool bAttemptingRejoin; // 0x2a Size: 0x1
	    char UnknownData0[0xf5];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Rejoin.RejoinCheck");
			return (class UClass*)ptr;
		};

};


}