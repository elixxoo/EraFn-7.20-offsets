#include "../SDK.hpp"

static void ULiveLinkBlueprintLibrary::TransformNames(struct FSubjectFrameHandle SubjectFrameHandle, TArray<FName> TransformNames)
{
	struct {
            struct FSubjectFrameHandle SubjectFrameHandle;
            TArray<FName> TransformNames;            void ReturnValue;
	} params{ SubjectFrameHandle, TransformNames };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkBlueprintLibrary:TransformNames");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void ULiveLinkBlueprintLibrary::TransformName(struct FLiveLinkTransform LiveLinkTransform, FName Name)
{
	struct {
            struct FLiveLinkTransform LiveLinkTransform;
            FName Name;            void ReturnValue;
	} params{ LiveLinkTransform, Name };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkBlueprintLibrary:TransformName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool ULiveLinkBlueprintLibrary::RequestShutdown(struct FLiveLinkSourceHandle SourceHandle)
{
	struct {
            struct FLiveLinkSourceHandle SourceHandle;
            bool ReturnValue;
	} params{ SourceHandle };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkBlueprintLibrary:RequestShutdown");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void ULiveLinkBlueprintLibrary::ParentBoneSpaceTransform(struct FLiveLinkTransform LiveLinkTransform, struct FTransform Transform)
{
	struct {
            struct FLiveLinkTransform LiveLinkTransform;
            struct FTransform Transform;            void ReturnValue;
	} params{ LiveLinkTransform, Transform };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkBlueprintLibrary:ParentBoneSpaceTransform");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static int ULiveLinkBlueprintLibrary::NumberOfTransforms(struct FSubjectFrameHandle SubjectFrameHandle)
{
	struct {
            struct FSubjectFrameHandle SubjectFrameHandle;
            int ReturnValue;
	} params{ SubjectFrameHandle };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkBlueprintLibrary:NumberOfTransforms");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool ULiveLinkBlueprintLibrary::IsSourceStillValid(struct FLiveLinkSourceHandle SourceHandle)
{
	struct {
            struct FLiveLinkSourceHandle SourceHandle;
            bool ReturnValue;
	} params{ SourceHandle };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkBlueprintLibrary:IsSourceStillValid");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool ULiveLinkBlueprintLibrary::HasParent(struct FLiveLinkTransform LiveLinkTransform)
{
	struct {
            struct FLiveLinkTransform LiveLinkTransform;
            bool ReturnValue;
	} params{ LiveLinkTransform };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkBlueprintLibrary:HasParent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void ULiveLinkBlueprintLibrary::GetTransformByName(struct FSubjectFrameHandle SubjectFrameHandle, FName TransformName, struct FLiveLinkTransform LiveLinkTransform)
{
	struct {
            struct FSubjectFrameHandle SubjectFrameHandle;
            FName TransformName;
            struct FLiveLinkTransform LiveLinkTransform;            void ReturnValue;
	} params{ SubjectFrameHandle, TransformName, LiveLinkTransform };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkBlueprintLibrary:GetTransformByName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void ULiveLinkBlueprintLibrary::GetTransformByIndex(struct FSubjectFrameHandle SubjectFrameHandle, int TransformIndex, struct FLiveLinkTransform LiveLinkTransform)
{
	struct {
            struct FSubjectFrameHandle SubjectFrameHandle;
            int TransformIndex;
            struct FLiveLinkTransform LiveLinkTransform;            void ReturnValue;
	} params{ SubjectFrameHandle, TransformIndex, LiveLinkTransform };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkBlueprintLibrary:GetTransformByIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FText ULiveLinkBlueprintLibrary::GetSourceType(struct FLiveLinkSourceHandle SourceHandle)
{
	struct {
            struct FLiveLinkSourceHandle SourceHandle;
            struct FText ReturnValue;
	} params{ SourceHandle };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkBlueprintLibrary:GetSourceType");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FText ULiveLinkBlueprintLibrary::GetSourceStatus(struct FLiveLinkSourceHandle SourceHandle)
{
	struct {
            struct FLiveLinkSourceHandle SourceHandle;
            struct FText ReturnValue;
	} params{ SourceHandle };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkBlueprintLibrary:GetSourceStatus");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FText ULiveLinkBlueprintLibrary::GetSourceMachineName(struct FLiveLinkSourceHandle SourceHandle)
{
	struct {
            struct FLiveLinkSourceHandle SourceHandle;
            struct FText ReturnValue;
	} params{ SourceHandle };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkBlueprintLibrary:GetSourceMachineName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void ULiveLinkBlueprintLibrary::GetRootTransform(struct FSubjectFrameHandle SubjectFrameHandle, struct FLiveLinkTransform LiveLinkTransform)
{
	struct {
            struct FSubjectFrameHandle SubjectFrameHandle;
            struct FLiveLinkTransform LiveLinkTransform;            void ReturnValue;
	} params{ SubjectFrameHandle, LiveLinkTransform };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkBlueprintLibrary:GetRootTransform");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void ULiveLinkBlueprintLibrary::GetParent(struct FLiveLinkTransform LiveLinkTransform, struct FLiveLinkTransform Parent)
{
	struct {
            struct FLiveLinkTransform LiveLinkTransform;
            struct FLiveLinkTransform Parent;            void ReturnValue;
	} params{ LiveLinkTransform, Parent };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkBlueprintLibrary:GetParent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void ULiveLinkBlueprintLibrary::GetMetadata(struct FSubjectFrameHandle SubjectFrameHandle, struct FSubjectMetadata MetaData)
{
	struct {
            struct FSubjectFrameHandle SubjectFrameHandle;
            struct FSubjectMetadata MetaData;            void ReturnValue;
	} params{ SubjectFrameHandle, MetaData };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkBlueprintLibrary:GetMetadata");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void ULiveLinkBlueprintLibrary::GetCurves(struct FSubjectFrameHandle SubjectFrameHandle, __int64/*MapProperty*/ Curves)
{
	struct {
            struct FSubjectFrameHandle SubjectFrameHandle;
            __int64/*MapProperty*/ Curves;            void ReturnValue;
	} params{ SubjectFrameHandle, Curves };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkBlueprintLibrary:GetCurves");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void ULiveLinkBlueprintLibrary::GetChildren(struct FLiveLinkTransform LiveLinkTransform, TArray<struct FLiveLinkTransform> Children)
{
	struct {
            struct FLiveLinkTransform LiveLinkTransform;
            TArray<struct FLiveLinkTransform> Children;            void ReturnValue;
	} params{ LiveLinkTransform, Children };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkBlueprintLibrary:GetChildren");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void ULiveLinkBlueprintLibrary::ComponentSpaceTransform(struct FLiveLinkTransform LiveLinkTransform, struct FTransform Transform)
{
	struct {
            struct FLiveLinkTransform LiveLinkTransform;
            struct FTransform Transform;            void ReturnValue;
	} params{ LiveLinkTransform, Transform };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkBlueprintLibrary:ComponentSpaceTransform");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static int ULiveLinkBlueprintLibrary::ChildCount(struct FLiveLinkTransform LiveLinkTransform)
{
	struct {
            struct FLiveLinkTransform LiveLinkTransform;
            int ReturnValue;
	} params{ LiveLinkTransform };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkBlueprintLibrary:ChildCount");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void ULiveLinkComponent::GetSubjectDataAtWorldTime(FName SubjectName, float WorldTime, bool bSuccess, struct FSubjectFrameHandle SubjectFrameHandle)
{
	struct {
            FName SubjectName;
            float WorldTime;
            bool bSuccess;
            struct FSubjectFrameHandle SubjectFrameHandle;
	} params{ SubjectName, WorldTime, bSuccess, SubjectFrameHandle };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkComponent:GetSubjectDataAtWorldTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ULiveLinkComponent::GetSubjectDataAtSceneTime(FName SubjectName, struct FTimecode SceneTime, bool bSuccess, struct FSubjectFrameHandle SubjectFrameHandle)
{
	struct {
            FName SubjectName;
            struct FTimecode SceneTime;
            bool bSuccess;
            struct FSubjectFrameHandle SubjectFrameHandle;
	} params{ SubjectName, SceneTime, bSuccess, SubjectFrameHandle };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkComponent:GetSubjectDataAtSceneTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ULiveLinkComponent::GetSubjectData(FName SubjectName, bool bSuccess, struct FSubjectFrameHandle SubjectFrameHandle)
{
	struct {
            FName SubjectName;
            bool bSuccess;
            struct FSubjectFrameHandle SubjectFrameHandle;
	} params{ SubjectName, bSuccess, SubjectFrameHandle };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkComponent:GetSubjectData");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ULiveLinkComponent::GetAvailableSubjectNames(TArray<FName> SubjectNames)
{
	struct {
            TArray<FName> SubjectNames;
	} params{ SubjectNames };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkComponent:GetAvailableSubjectNames");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void ULiveLinkMessageBusFinder::GetAvailableProviders(class UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, float Duration, TArray<struct FProviderPollResult> AvailableProviders)
{
	struct {
            class UObject* WorldContextObject;
            struct FLatentActionInfo LatentInfo;
            float Duration;
            TArray<struct FProviderPollResult> AvailableProviders;
	} params{ WorldContextObject, LatentInfo, Duration, AvailableProviders };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkMessageBusFinder:GetAvailableProviders");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


static class ULiveLinkMessageBusFinder* ULiveLinkMessageBusFinder::ConstructMessageBusFinder()
{
	struct {
            class ULiveLinkMessageBusFinder* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkMessageBusFinder:ConstructMessageBusFinder");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static void ULiveLinkMessageBusFinder::ConnectToProvider(struct FProviderPollResult Provider, struct FLiveLinkSourceHandle SourceHandle)
{
	struct {
            struct FProviderPollResult Provider;
            struct FLiveLinkSourceHandle SourceHandle;            void ReturnValue;
	} params{ Provider, SourceHandle };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkMessageBusFinder:ConnectToProvider");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void ULiveLinkRemapAsset::RemapCurveElements(__int64/*MapProperty*/ CurveItems)
{
	struct {
            __int64/*MapProperty*/ CurveItems;
	} params{ CurveItems };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkRemapAsset:RemapCurveElements");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


FName ULiveLinkRemapAsset::GetRemappedCurveName(FName CurveName)
{
	struct {
            FName CurveName;
            FName ReturnValue;
	} params{ CurveName };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkRemapAsset:GetRemappedCurveName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


FName ULiveLinkRemapAsset::GetRemappedBoneName(FName BoneName)
{
	struct {
            FName BoneName;
            FName ReturnValue;
	} params{ BoneName };

    static auto fn = UObject::FindObject("/Script/LiveLink.LiveLinkRemapAsset:GetRemappedBoneName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

