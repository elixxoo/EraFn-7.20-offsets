#include "../SDK.hpp"

void UCommonActionWidget::SetInputAction(struct FDataTableRowHandle InputActionRow)
{
	struct {
            struct FDataTableRowHandle InputActionRow;
	} params{ InputActionRow };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActionWidget:SetInputAction");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonActionWidget::SetIconRimBrush(struct FSlateBrush InIconRimBrush)
{
	struct {
            struct FSlateBrush InIconRimBrush;
	} params{ InIconRimBrush };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActionWidget:SetIconRimBrush");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UCommonActionWidget::IsHeldAction()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActionWidget:IsHeldAction");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FSlateBrush UCommonActionWidget::GetIcon()
{
	struct {
            struct FSlateBrush ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActionWidget:GetIcon");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FText UCommonActionWidget::GetDisplayText()
{
	struct {
            struct FText ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActionWidget:GetDisplayText");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UCommonUserWidget::SetConsumePointerInput(bool bInConsumePointerInput)
{
	struct {
            bool bInConsumePointerInput;
	} params{ bInConsumePointerInput };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonUserWidget:SetConsumePointerInput");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonUserWidget::OnTouchLeave(struct FPointerEvent TouchEvent)
{
	struct {
            struct FPointerEvent TouchEvent;
	} params{ TouchEvent };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonUserWidget:OnTouchLeave");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UCommonActivatablePanel::SetInputActionHandlerWithProgressPopupMenu(struct FDataTableRowHandle InputActionRow, __int64/*DelegateProperty*/ CommitedEvent, __int64/*DelegateProperty*/ ProgressEvent, class UCommonPopupMenu* PopupMenu)
{
	struct {
            struct FDataTableRowHandle InputActionRow;
            __int64/*DelegateProperty*/ CommitedEvent;
            __int64/*DelegateProperty*/ ProgressEvent;
            class UCommonPopupMenu* PopupMenu;
	} params{ InputActionRow, CommitedEvent, ProgressEvent, PopupMenu };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:SetInputActionHandlerWithProgressPopupMenu");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonActivatablePanel::SetInputActionHandlerWithProgress(struct FDataTableRowHandle InputActionRow, __int64/*DelegateProperty*/ CommitedEvent, __int64/*DelegateProperty*/ ProgressEvent)
{
	struct {
            struct FDataTableRowHandle InputActionRow;
            __int64/*DelegateProperty*/ CommitedEvent;
            __int64/*DelegateProperty*/ ProgressEvent;
	} params{ InputActionRow, CommitedEvent, ProgressEvent };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:SetInputActionHandlerWithProgress");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonActivatablePanel::SetInputActionHandlerWithPopupMenu(struct FDataTableRowHandle InputActionRow, __int64/*DelegateProperty*/ CommitedEvent, class UCommonPopupMenu* PopupMenu)
{
	struct {
            struct FDataTableRowHandle InputActionRow;
            __int64/*DelegateProperty*/ CommitedEvent;
            class UCommonPopupMenu* PopupMenu;
	} params{ InputActionRow, CommitedEvent, PopupMenu };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:SetInputActionHandlerWithPopupMenu");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonActivatablePanel::SetInputActionHandler(struct FDataTableRowHandle InputActionRow, __int64/*DelegateProperty*/ CommitedEvent)
{
	struct {
            struct FDataTableRowHandle InputActionRow;
            __int64/*DelegateProperty*/ CommitedEvent;
	} params{ InputActionRow, CommitedEvent };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:SetInputActionHandler");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonActivatablePanel::SetActionHandlerStateWithDisabledCommitEvent(class UDataTable* DataTable, FName RowName, EInputActionState State, __int64/*DelegateProperty*/ DisabledCommitEvent)
{
	struct {
            class UDataTable* DataTable;
            FName RowName;
            EInputActionState State;
            __int64/*DelegateProperty*/ DisabledCommitEvent;
	} params{ DataTable, RowName, State, DisabledCommitEvent };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:SetActionHandlerStateWithDisabledCommitEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonActivatablePanel::SetActionHandlerStateFromHandleWithDisabledCommitEvent(struct FDataTableRowHandle InputActionRow, EInputActionState State, __int64/*DelegateProperty*/ DisabledCommitEvent)
{
	struct {
            struct FDataTableRowHandle InputActionRow;
            EInputActionState State;
            __int64/*DelegateProperty*/ DisabledCommitEvent;
	} params{ InputActionRow, State, DisabledCommitEvent };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:SetActionHandlerStateFromHandleWithDisabledCommitEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonActivatablePanel::SetActionHandlerStateFromHandle(struct FDataTableRowHandle InputActionRow, EInputActionState State)
{
	struct {
            struct FDataTableRowHandle InputActionRow;
            EInputActionState State;
	} params{ InputActionRow, State };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:SetActionHandlerStateFromHandle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonActivatablePanel::SetActionHandlerState(class UDataTable* DataTable, FName RowName, EInputActionState State)
{
	struct {
            class UDataTable* DataTable;
            FName RowName;
            EInputActionState State;
	} params{ DataTable, RowName, State };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:SetActionHandlerState");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonActivatablePanel::RemoveInputActionHandler(struct FDataTableRowHandle InputActionRow)
{
	struct {
            struct FDataTableRowHandle InputActionRow;
	} params{ InputActionRow };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:RemoveInputActionHandler");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonActivatablePanel::RemoveAllInputActionHandlers()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:RemoveAllInputActionHandlers");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonActivatablePanel::PopPanel()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:PopPanel");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonActivatablePanel::OnRemovedFromActivationStack()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:OnRemovedFromActivationStack");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonActivatablePanel::OnInputModeChanged(bool bUsingGamepad)
{
	struct {
            bool bUsingGamepad;
	} params{ bUsingGamepad };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:OnInputModeChanged");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonActivatablePanel::OnDeactivated()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:OnDeactivated");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonActivatablePanel::OnBeginOutro()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:OnBeginOutro");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonActivatablePanel::OnBeginIntro()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:OnBeginIntro");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonActivatablePanel::OnAddedToActivationStack()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:OnAddedToActivationStack");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonActivatablePanel::OnActivated()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:OnActivated");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


bool UCommonActivatablePanel::IsIntroed()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:IsIntroed");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UCommonActivatablePanel::IsInActivationStack()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:IsInActivationStack");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UCommonActivatablePanel::IsActivated()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:IsActivated");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UCommonActivatablePanel::HasInputActionHandler(struct FDataTableRowHandle InputActionRow)
{
	struct {
            struct FDataTableRowHandle InputActionRow;
            bool ReturnValue;
	} params{ InputActionRow };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:HasInputActionHandler");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UCommonActivatablePanel::GetInputActions(TArray<struct FCommonInputActionHandlerData> InputActionDataRows)
{
	struct {
            TArray<struct FCommonInputActionHandlerData> InputActionDataRows;
            bool ReturnValue;
	} params{ InputActionDataRows };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:GetInputActions");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UCommonActivatablePanel::EndOutro()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:EndOutro");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonActivatablePanel::EndIntro()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:EndIntro");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonActivatablePanel::BeginOutro()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:BeginOutro");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonActivatablePanel::BeginIntro()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:BeginIntro");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonActivatablePanel::AddInputActionNoHandler(class UDataTable* DataTable, FName RowName)
{
	struct {
            class UDataTable* DataTable;
            FName RowName;
	} params{ DataTable, RowName };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:AddInputActionNoHandler");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonActivatablePanel::AddInputActionHandlerWithProgressPopup(class UDataTable* DataTable, FName RowName, __int64/*DelegateProperty*/ CommitedEvent, __int64/*DelegateProperty*/ ProgressEvent, class UCommonPopupMenu* PopupMenu)
{
	struct {
            class UDataTable* DataTable;
            FName RowName;
            __int64/*DelegateProperty*/ CommitedEvent;
            __int64/*DelegateProperty*/ ProgressEvent;
            class UCommonPopupMenu* PopupMenu;
	} params{ DataTable, RowName, CommitedEvent, ProgressEvent, PopupMenu };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:AddInputActionHandlerWithProgressPopup");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonActivatablePanel::AddInputActionHandlerWithProgress(class UDataTable* DataTable, FName RowName, __int64/*DelegateProperty*/ CommitedEvent, __int64/*DelegateProperty*/ ProgressEvent)
{
	struct {
            class UDataTable* DataTable;
            FName RowName;
            __int64/*DelegateProperty*/ CommitedEvent;
            __int64/*DelegateProperty*/ ProgressEvent;
	} params{ DataTable, RowName, CommitedEvent, ProgressEvent };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:AddInputActionHandlerWithProgress");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonActivatablePanel::AddInputActionHandlerWithPopup(class UDataTable* DataTable, FName RowName, __int64/*DelegateProperty*/ CommitedEvent, class UCommonPopupMenu* PopupMenu)
{
	struct {
            class UDataTable* DataTable;
            FName RowName;
            __int64/*DelegateProperty*/ CommitedEvent;
            class UCommonPopupMenu* PopupMenu;
	} params{ DataTable, RowName, CommitedEvent, PopupMenu };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:AddInputActionHandlerWithPopup");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonActivatablePanel::AddInputActionHandler(class UDataTable* DataTable, FName RowName, __int64/*DelegateProperty*/ CommitedEvent)
{
	struct {
            class UDataTable* DataTable;
            FName RowName;
            __int64/*DelegateProperty*/ CommitedEvent;
	} params{ DataTable, RowName, CommitedEvent };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonActivatablePanel:AddInputActionHandler");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UCommonBorderStyle::GetBackgroundBrush(struct FSlateBrush Brush)
{
	struct {
            struct FSlateBrush Brush;
	} params{ Brush };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonBorderStyle:GetBackgroundBrush");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UCommonBorder::SetStyle(class UCommonBorderStyle* InStyle)
{
	struct {
            class UCommonBorderStyle* InStyle;
	} params{ InStyle };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonBorder:SetStyle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

class UCommonTextStyle* UCommonButtonStyle::GetSelectedTextStyle()
{
	struct {
            class UCommonTextStyle* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonStyle:GetSelectedTextStyle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UCommonButtonStyle::GetSelectedPressedBrush(struct FSlateBrush Brush)
{
	struct {
            struct FSlateBrush Brush;
	} params{ Brush };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonStyle:GetSelectedPressedBrush");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


class UCommonTextStyle* UCommonButtonStyle::GetSelectedHoveredTextStyle()
{
	struct {
            class UCommonTextStyle* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonStyle:GetSelectedHoveredTextStyle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UCommonButtonStyle::GetSelectedHoveredBrush(struct FSlateBrush Brush)
{
	struct {
            struct FSlateBrush Brush;
	} params{ Brush };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonStyle:GetSelectedHoveredBrush");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButtonStyle::GetSelectedBaseBrush(struct FSlateBrush Brush)
{
	struct {
            struct FSlateBrush Brush;
	} params{ Brush };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonStyle:GetSelectedBaseBrush");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


class UCommonTextStyle* UCommonButtonStyle::GetNormalTextStyle()
{
	struct {
            class UCommonTextStyle* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonStyle:GetNormalTextStyle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UCommonButtonStyle::GetNormalPressedBrush(struct FSlateBrush Brush)
{
	struct {
            struct FSlateBrush Brush;
	} params{ Brush };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonStyle:GetNormalPressedBrush");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


class UCommonTextStyle* UCommonButtonStyle::GetNormalHoveredTextStyle()
{
	struct {
            class UCommonTextStyle* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonStyle:GetNormalHoveredTextStyle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UCommonButtonStyle::GetNormalHoveredBrush(struct FSlateBrush Brush)
{
	struct {
            struct FSlateBrush Brush;
	} params{ Brush };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonStyle:GetNormalHoveredBrush");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButtonStyle::GetNormalBaseBrush(struct FSlateBrush Brush)
{
	struct {
            struct FSlateBrush Brush;
	} params{ Brush };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonStyle:GetNormalBaseBrush");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButtonStyle::GetMaterialBrush(struct FSlateBrush Brush)
{
	struct {
            struct FSlateBrush Brush;
	} params{ Brush };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonStyle:GetMaterialBrush");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


class UCommonTextStyle* UCommonButtonStyle::GetDisabledTextStyle()
{
	struct {
            class UCommonTextStyle* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonStyle:GetDisabledTextStyle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UCommonButtonStyle::GetDisabledBrush(struct FSlateBrush Brush)
{
	struct {
            struct FSlateBrush Brush;
	} params{ Brush };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonStyle:GetDisabledBrush");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButtonStyle::GetCustomPadding(struct FMargin OutCustomPadding)
{
	struct {
            struct FMargin OutCustomPadding;
	} params{ OutCustomPadding };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonStyle:GetCustomPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButtonStyle::GetButtonPadding(struct FMargin OutButtonPadding)
{
	struct {
            struct FMargin OutButtonPadding;
	} params{ OutButtonPadding };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonStyle:GetButtonPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UCommonButton::StopDoubleClickPropagation()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:StopDoubleClickPropagation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonButton::SetTriggeringInputAction(struct FDataTableRowHandle InputActionRow)
{
	struct {
            struct FDataTableRowHandle InputActionRow;
	} params{ InputActionRow };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:SetTriggeringInputAction");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButton::SetTriggeredInputAction(struct FDataTableRowHandle InputActionRow, class UCommonActivatablePanel* OldPanel)
{
	struct {
            struct FDataTableRowHandle InputActionRow;
            class UCommonActivatablePanel* OldPanel;
	} params{ InputActionRow, OldPanel };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:SetTriggeredInputAction");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButton::SetTouchMethod(char InTouchMethod)
{
	struct {
            char InTouchMethod;
	} params{ InTouchMethod };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:SetTouchMethod");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButton::SetStyle(class UCommonButtonStyle* InStyle)
{
	struct {
            class UCommonButtonStyle* InStyle;
	} params{ InStyle };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:SetStyle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButton::SetShouldSelectUponReceivingFocus(bool bInShouldSelectUponReceivingFocus)
{
	struct {
            bool bInShouldSelectUponReceivingFocus;
	} params{ bInShouldSelectUponReceivingFocus };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:SetShouldSelectUponReceivingFocus");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButton::SetSelectedInternal(bool bInSelected, bool bAllowSound, bool bBroadcast)
{
	struct {
            bool bInSelected;
            bool bAllowSound;
            bool bBroadcast;
	} params{ bInSelected, bAllowSound, bBroadcast };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:SetSelectedInternal");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButton::SetPressMethod(char InPressMethod)
{
	struct {
            char InPressMethod;
	} params{ InPressMethod };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:SetPressMethod");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButton::SetMinDimensions(int InMinWidth, int InMinHeight)
{
	struct {
            int InMinWidth;
            int InMinHeight;
	} params{ InMinWidth, InMinHeight };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:SetMinDimensions");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButton::SetIsToggleable(bool bInIsToggleable)
{
	struct {
            bool bInIsToggleable;
	} params{ bInIsToggleable };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:SetIsToggleable");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButton::SetIsSelected(bool InSelected, bool bGiveClickFeedback)
{
	struct {
            bool InSelected;
            bool bGiveClickFeedback;
	} params{ InSelected, bGiveClickFeedback };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:SetIsSelected");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButton::SetIsSelectable(bool bInIsSelectable)
{
	struct {
            bool bInIsSelectable;
	} params{ bInIsSelectable };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:SetIsSelectable");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButton::SetIsInteractionEnabled(bool bInIsInteractionEnabled)
{
	struct {
            bool bInIsInteractionEnabled;
	} params{ bInIsInteractionEnabled };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:SetIsInteractionEnabled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButton::SetIsInteractableWhenSelected(bool bInInteractableWhenSelected)
{
	struct {
            bool bInInteractableWhenSelected;
	} params{ bInInteractableWhenSelected };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:SetIsInteractableWhenSelected");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButton::SetInputActionProgressMaterial(struct FSlateBrush InProgressMaterialBrush, FName InProgressMaterialParam)
{
	struct {
            struct FSlateBrush InProgressMaterialBrush;
            FName InProgressMaterialParam;
	} params{ InProgressMaterialBrush, InProgressMaterialParam };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:SetInputActionProgressMaterial");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButton::SetClickMethod(char InClickMethod)
{
	struct {
            char InClickMethod;
	} params{ InClickMethod };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:SetClickMethod");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButton::OnTriggeredInputActionChanged(struct FDataTableRowHandle NewTriggeredAction)
{
	struct {
            struct FDataTableRowHandle NewTriggeredAction;
	} params{ NewTriggeredAction };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:OnTriggeredInputActionChanged");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButton::OnInputMethodChanged(ECommonInputType CurrentInputType)
{
	struct {
            ECommonInputType CurrentInputType;
	} params{ CurrentInputType };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:OnInputMethodChanged");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButton::OnCurrentTextStyleChanged()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:OnCurrentTextStyleChanged");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonButton::OnActionProgress(float HeldPercent)
{
	struct {
            float HeldPercent;
	} params{ HeldPercent };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:OnActionProgress");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButton::OnActionComplete()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:OnActionComplete");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonButton::NativeOnActionProgress(float HeldPercent)
{
	struct {
            float HeldPercent;
	} params{ HeldPercent };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:NativeOnActionProgress");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButton::NativeOnActionComplete()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:NativeOnActionComplete");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


bool UCommonButton::IsPressed()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:IsPressed");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UCommonButton::IsInteractionEnabled()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:IsInteractionEnabled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UCommonButton::HandleTriggeringActionCommited(bool bPassThrough)
{
	struct {
            bool bPassThrough;
	} params{ bPassThrough };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:HandleTriggeringActionCommited");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButton::HandleFocusReceived()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:HandleFocusReceived");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonButton::HandleButtonReleased()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:HandleButtonReleased");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonButton::HandleButtonPressed()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:HandleButtonPressed");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonButton::HandleButtonClicked()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:HandleButtonClicked");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


class UCommonButtonStyle* UCommonButton::GetStyle()
{
	struct {
            class UCommonButtonStyle* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:GetStyle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UMaterialInstanceDynamic* UCommonButton::GetSingleMaterialStyleMID()
{
	struct {
            class UMaterialInstanceDynamic* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:GetSingleMaterialStyleMID");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UCommonButton::GetShouldSelectUponReceivingFocus()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:GetShouldSelectUponReceivingFocus");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UCommonButton::GetSelected()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:GetSelected");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UCommonButton::GetInputAction(struct FDataTableRowHandle InputActionRow)
{
	struct {
            struct FDataTableRowHandle InputActionRow;
            bool ReturnValue;
	} params{ InputActionRow };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:GetInputAction");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


class UCommonTextStyle* UCommonButton::GetCurrentTextStyleClass()
{
	struct {
            class UCommonTextStyle* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:GetCurrentTextStyleClass");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UCommonTextStyle* UCommonButton::GetCurrentTextStyle()
{
	struct {
            class UCommonTextStyle* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:GetCurrentTextStyle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UCommonButton::GetCurrentCustomPadding(struct FMargin OutCustomPadding)
{
	struct {
            struct FMargin OutCustomPadding;
	} params{ OutCustomPadding };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:GetCurrentCustomPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButton::GetCurrentButtonPadding(struct FMargin OutButtonPadding)
{
	struct {
            struct FMargin OutButtonPadding;
	} params{ OutButtonPadding };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:GetCurrentButtonPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButton::DisableButtonWithReason(struct FText DisabledReason)
{
	struct {
            struct FText DisabledReason;
	} params{ DisabledReason };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:DisableButtonWithReason");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButton::ClearSelection()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:ClearSelection");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonButton::BP_OnUnhovered()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:BP_OnUnhovered");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonButton::BP_OnSelected()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:BP_OnSelected");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonButton::BP_OnHovered()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:BP_OnHovered");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonButton::BP_OnEnabled()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:BP_OnEnabled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonButton::BP_OnDoubleClicked()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:BP_OnDoubleClicked");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonButton::BP_OnDisabled()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:BP_OnDisabled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonButton::BP_OnDeselected()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:BP_OnDeselected");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonButton::BP_OnClicked()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButton:BP_OnClicked");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

void UCommonWidgetGroupBase::RemoveWidget(class UWidget* InWidget)
{
	struct {
            class UWidget* InWidget;
	} params{ InWidget };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetGroupBase:RemoveWidget");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonWidgetGroupBase::RemoveAll()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetGroupBase:RemoveAll");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonWidgetGroupBase::AddWidget(class UWidget* InWidget)
{
	struct {
            class UWidget* InWidget;
	} params{ InWidget };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetGroupBase:AddWidget");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UCommonButtonGroup::SetSelectionRequired(bool bRequireSelection)
{
	struct {
            bool bRequireSelection;
	} params{ bRequireSelection };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonGroup:SetSelectionRequired");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButtonGroup::SelectPreviousButton(bool bAllowWrap)
{
	struct {
            bool bAllowWrap;
	} params{ bAllowWrap };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonGroup:SelectPreviousButton");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButtonGroup::SelectNextButton(bool bAllowWrap)
{
	struct {
            bool bAllowWrap;
	} params{ bAllowWrap };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonGroup:SelectNextButton");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButtonGroup::SelectButtonAtIndex(int ButtonIndex)
{
	struct {
            int ButtonIndex;
	} params{ ButtonIndex };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonGroup:SelectButtonAtIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButtonGroup::OnSelectionStateChanged(class UCommonButton* BaseButton, bool bIsSelected)
{
	struct {
            class UCommonButton* BaseButton;
            bool bIsSelected;
	} params{ BaseButton, bIsSelected };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonGroup:OnSelectionStateChanged");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButtonGroup::OnHandleButtonDoubleClicked(class UCommonButton* BaseButton)
{
	struct {
            class UCommonButton* BaseButton;
	} params{ BaseButton };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonGroup:OnHandleButtonDoubleClicked");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButtonGroup::OnHandleButtonClicked(class UCommonButton* BaseButton)
{
	struct {
            class UCommonButton* BaseButton;
	} params{ BaseButton };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonGroup:OnHandleButtonClicked");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButtonGroup::OnButtonUnhovered(class UCommonButton* BaseButton)
{
	struct {
            class UCommonButton* BaseButton;
	} params{ BaseButton };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonGroup:OnButtonUnhovered");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonButtonGroup::OnButtonHovered(class UCommonButton* BaseButton)
{
	struct {
            class UCommonButton* BaseButton;
	} params{ BaseButton };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonGroup:OnButtonHovered");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UCommonButtonGroup::HasAnyButtons()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonGroup:HasAnyButtons");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


int UCommonButtonGroup::GetSelectedButtonIndex()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonGroup:GetSelectedButtonIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


int UCommonButtonGroup::GetHoveredButtonIndex()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonGroup:GetHoveredButtonIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


int UCommonButtonGroup::GetButtonCount()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonGroup:GetButtonCount");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UCommonButton* UCommonButtonGroup::GetButtonAtIndex(int Index)
{
	struct {
            int Index;
            class UCommonButton* ReturnValue;
	} params{ Index };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonGroup:GetButtonAtIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


int UCommonButtonGroup::FindButtonIndex(class UCommonButton* ButtonToFind)
{
	struct {
            class UCommonButton* ButtonToFind;
            int ReturnValue;
	} params{ ButtonToFind };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonGroup:FindButtonIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UCommonButtonGroup::DeselectAll()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonButtonGroup:DeselectAll");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

void UCommonTextBlock::SetWrapTextWidth(int InWrapTextAt)
{
	struct {
            int InWrapTextAt;
	} params{ InWrapTextAt };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTextBlock:SetWrapTextWidth");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonTextBlock::SetStyle(class UCommonTextStyle* InStyle)
{
	struct {
            class UCommonTextStyle* InStyle;
	} params{ InStyle };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTextBlock:SetStyle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonTextBlock::SetScrollStyle(class UCommonTextScrollStyle* InScrollStyle)
{
	struct {
            class UCommonTextScrollStyle* InScrollStyle;
	} params{ InScrollStyle };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTextBlock:SetScrollStyle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonTextBlock::ResetScrollState()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTextBlock:ResetScrollState");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

void UCommonDateTimeTextBlock::SetTimespanValue(struct FTimespan InTimespan)
{
	struct {
            struct FTimespan InTimespan;
	} params{ InTimespan };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonDateTimeTextBlock:SetTimespanValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonDateTimeTextBlock::SetDateTimeValue(struct FDateTime InDateTime, bool bShowAsCountdown)
{
	struct {
            struct FDateTime InDateTime;
            bool bShowAsCountdown;
	} params{ InDateTime, bShowAsCountdown };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonDateTimeTextBlock:SetDateTimeValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonDateTimeTextBlock::SetCountDownCompletionText(struct FText InCompletionText)
{
	struct {
            struct FText InCompletionText;
	} params{ InCompletionText };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonDateTimeTextBlock:SetCountDownCompletionText");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


struct FDateTime UCommonDateTimeTextBlock::GetDateTime()
{
	struct {
            struct FDateTime ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonDateTimeTextBlock:GetDateTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UCommonInputManager::SuspendStartingOperationProcessing()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonInputManager:SuspendStartingOperationProcessing");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


bool UCommonInputManager::StopListeningForExistingHeldAction(struct FDataTableRowHandle InputActionDataRow, __int64/*DelegateProperty*/ CompleteEvent, __int64/*DelegateProperty*/ ProgressEvent)
{
	struct {
            struct FDataTableRowHandle InputActionDataRow;
            __int64/*DelegateProperty*/ CompleteEvent;
            __int64/*DelegateProperty*/ ProgressEvent;
            bool ReturnValue;
	} params{ InputActionDataRow, CompleteEvent, ProgressEvent };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonInputManager:StopListeningForExistingHeldAction");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UCommonInputManager::StartListeningForExistingHeldAction(struct FDataTableRowHandle InputActionDataRow, __int64/*DelegateProperty*/ CompleteEvent, __int64/*DelegateProperty*/ ProgressEvent)
{
	struct {
            struct FDataTableRowHandle InputActionDataRow;
            __int64/*DelegateProperty*/ CompleteEvent;
            __int64/*DelegateProperty*/ ProgressEvent;
            bool ReturnValue;
	} params{ InputActionDataRow, CompleteEvent, ProgressEvent };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonInputManager:StartListeningForExistingHeldAction");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UCommonInputManager::SetGlobalInputHandlerPriorityFilter(int InFilterPriority)
{
	struct {
            int InFilterPriority;
	} params{ InFilterPriority };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonInputManager:SetGlobalInputHandlerPriorityFilter");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonInputManager::ResumeStartingOperationProcessing()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonInputManager:ResumeStartingOperationProcessing");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonInputManager::PushActivatablePanel(class UCommonActivatablePanel* ActivatablePanel, bool bIntroPanel, bool bOutroPanelBelow)
{
	struct {
            class UCommonActivatablePanel* ActivatablePanel;
            bool bIntroPanel;
            bool bOutroPanelBelow;
	} params{ ActivatablePanel, bIntroPanel, bOutroPanelBelow };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonInputManager:PushActivatablePanel");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonInputManager::PopActivatablePanel(class UCommonActivatablePanel* ActivatablePanel)
{
	struct {
            class UCommonActivatablePanel* ActivatablePanel;
	} params{ ActivatablePanel };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonInputManager:PopActivatablePanel");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UCommonInputManager::IsPanelOnStack(class UCommonActivatablePanel* InPanel)
{
	struct {
            class UCommonActivatablePanel* InPanel;
            bool ReturnValue;
	} params{ InPanel };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonInputManager:IsPanelOnStack");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UCommonInputManager::IsInputSuspended()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonInputManager:IsInputSuspended");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UCommonActivatablePanel* UCommonInputManager::GetTopPanel()
{
	struct {
            class UCommonActivatablePanel* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonInputManager:GetTopPanel");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


int UCommonInputManager::GetGlobalInputHandlerPriorityFilter()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonInputManager:GetGlobalInputHandlerPriorityFilter");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UCommonInputManager::GetAvailableInputActions(TArray<struct FCommonInputActionHandlerData> AvailableInputActions)
{
	struct {
            TArray<struct FCommonInputActionHandlerData> AvailableInputActions;
            bool ReturnValue;
	} params{ AvailableInputActions };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonInputManager:GetAvailableInputActions");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UCommonInputReflector::OnButtonAdded(class UCommonButton* AddedButton, struct FCommonInputActionHandlerData Data)
{
	struct {
            class UCommonButton* AddedButton;
            struct FCommonInputActionHandlerData Data;
	} params{ AddedButton, Data };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonInputReflector:OnButtonAdded");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UCommonLazyImage::SetMaterialTextureParamName(FName TextureParamName)
{
	struct {
            FName TextureParamName;
	} params{ TextureParamName };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonLazyImage:SetMaterialTextureParamName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonLazyImage::SetBrushFromLazyTexture(struct TSoftObjectPtr<struct UTexture2D*> LazyTexture, bool bMatchSize)
{
	struct {
            struct TSoftObjectPtr<struct UTexture2D*> LazyTexture;
            bool bMatchSize;
	} params{ LazyTexture, bMatchSize };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonLazyImage:SetBrushFromLazyTexture");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonLazyImage::SetBrushFromLazyMaterial(struct TSoftObjectPtr<struct UMaterialInterface*> LazyMaterial)
{
	struct {
            struct TSoftObjectPtr<struct UMaterialInterface*> LazyMaterial;
	} params{ LazyMaterial };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonLazyImage:SetBrushFromLazyMaterial");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonLazyImage::SetBrushFromLazyDisplayAsset(struct TSoftObjectPtr<struct UObject*> LazyObject, bool bMatchTextureSize)
{
	struct {
            struct TSoftObjectPtr<struct UObject*> LazyObject;
            bool bMatchTextureSize;
	} params{ LazyObject, bMatchTextureSize };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonLazyImage:SetBrushFromLazyDisplayAsset");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UCommonLazyImage::IsLoading()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonLazyImage:IsLoading");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UCommonLazyWidget::SetLazyContent(__int64/*SoftClassProperty*/ SoftWidget)
{
	struct {
            __int64/*SoftClassProperty*/ SoftWidget;
	} params{ SoftWidget };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonLazyWidget:SetLazyContent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UCommonLazyWidget::IsLoading()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonLazyWidget:IsLoading");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void ULoadGuardSlot::SetVerticalAlignment(char InVerticalAlignment)
{
	struct {
            char InVerticalAlignment;
	} params{ InVerticalAlignment };

    static auto fn = UObject::FindObject("/Script/CommonUI.LoadGuardSlot:SetVerticalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ULoadGuardSlot::SetPadding(struct FMargin InPadding)
{
	struct {
            struct FMargin InPadding;
	} params{ InPadding };

    static auto fn = UObject::FindObject("/Script/CommonUI.LoadGuardSlot:SetPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ULoadGuardSlot::SetHorizontalAlignment(char InHorizontalAlignment)
{
	struct {
            char InHorizontalAlignment;
	} params{ InHorizontalAlignment };

    static auto fn = UObject::FindObject("/Script/CommonUI.LoadGuardSlot:SetHorizontalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UCommonLoadGuard::SetLoadingText(struct FText InLoadingText)
{
	struct {
            struct FText InLoadingText;
	} params{ InLoadingText };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonLoadGuard:SetLoadingText");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonLoadGuard::SetIsLoading(bool bInIsLoading)
{
	struct {
            bool bInIsLoading;
	} params{ bInIsLoading };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonLoadGuard:SetIsLoading");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UCommonLoadGuard::IsLoading()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonLoadGuard:IsLoading");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UCommonLoadGuard::BP_GuardAndLoadAsset(struct TSoftObjectPtr<struct UObject*> InLazyAsset, __int64/*DelegateProperty*/ OnAssetLoaded)
{
	struct {
            struct TSoftObjectPtr<struct UObject*> InLazyAsset;
            __int64/*DelegateProperty*/ OnAssetLoaded;
	} params{ InLazyAsset, OnAssetLoaded };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonLoadGuard:BP_GuardAndLoadAsset");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UCommonNumericTextBlock::SetNumericType(ECommonNumericType InNumericType)
{
	struct {
            ECommonNumericType InNumericType;
	} params{ InNumericType };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonNumericTextBlock:SetNumericType");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonNumericTextBlock::SetCurrentValue(float NewValue)
{
	struct {
            float NewValue;
	} params{ NewValue };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonNumericTextBlock:SetCurrentValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UCommonNumericTextBlock::IsInterpolatingNumericValue()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonNumericTextBlock:IsInterpolatingNumericValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UCommonNumericTextBlock::InterpolateToValue(float TargetValue, float MaximumInterpolationDuration, float MinimumChangeRate, float OutroOffset)
{
	struct {
            float TargetValue;
            float MaximumInterpolationDuration;
            float MinimumChangeRate;
            float OutroOffset;
	} params{ TargetValue, MaximumInterpolationDuration, MinimumChangeRate, OutroOffset };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonNumericTextBlock:InterpolateToValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


float UCommonNumericTextBlock::GetTargetValue()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonNumericTextBlock:GetTargetValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UCommonPoolableWidgetInterface::OnReleaseToPool()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonPoolableWidgetInterface:OnReleaseToPool");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonPoolableWidgetInterface::OnAcquireFromPool()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonPoolableWidgetInterface:OnAcquireFromPool");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

class UWidget* UCommonPopupButton::GetMenuAnchorWidget()
{
	struct {
            class UWidget* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonPopupButton:GetMenuAnchorWidget");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UCommonPopupMenu::SetOwningMenuAnchor(class UMenuAnchor* MenuAnchor)
{
	struct {
            class UMenuAnchor* MenuAnchor;
	} params{ MenuAnchor };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonPopupMenu:SetOwningMenuAnchor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonPopupMenu::SetContextProvider(class UObject* ContextProvidingObject)
{
	struct {
            class UObject* ContextProvidingObject;
	} params{ ContextProvidingObject };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonPopupMenu:SetContextProvider");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonPopupMenu::RequestClose()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonPopupMenu:RequestClose");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonPopupMenu::OnIsOpenChanged(bool IsOpen)
{
	struct {
            bool IsOpen;
	} params{ IsOpen };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonPopupMenu:OnIsOpenChanged");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonPopupMenu::HandlePreDifferentContextProviderSet()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonPopupMenu:HandlePreDifferentContextProviderSet");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonPopupMenu::HandlePostDifferentContextProviderSet()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonPopupMenu:HandlePostDifferentContextProviderSet");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

void UCommonRotator::ShiftTextRight()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonRotator:ShiftTextRight");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonRotator::ShiftTextLeft()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonRotator:ShiftTextLeft");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonRotator::SetSelectedItem(int InValue)
{
	struct {
            int InValue;
	} params{ InValue };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonRotator:SetSelectedItem");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonRotator::PopulateTextLabels(TArray<struct FText> Labels)
{
	struct {
            TArray<struct FText> Labels;
	} params{ Labels };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonRotator:PopulateTextLabels");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


struct FText UCommonRotator::GetSelectedText()
{
	struct {
            struct FText ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonRotator:GetSelectedText");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


int UCommonRotator::GetSelectedIndex()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonRotator:GetSelectedIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UCommonTabListWidget::SetTabVisibility(FName TabNameID, ESlateVisibility NewVisibility)
{
	struct {
            FName TabNameID;
            ESlateVisibility NewVisibility;
	} params{ TabNameID, NewVisibility };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTabListWidget:SetTabVisibility");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonTabListWidget::SetTabInteractionEnabled(FName TabNameID, bool bEnable)
{
	struct {
            FName TabNameID;
            bool bEnable;
	} params{ TabNameID, bEnable };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTabListWidget:SetTabInteractionEnabled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonTabListWidget::SetTabEnabled(FName TabNameID, bool bEnable)
{
	struct {
            FName TabNameID;
            bool bEnable;
	} params{ TabNameID, bEnable };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTabListWidget:SetTabEnabled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonTabListWidget::SetListeningForInput(bool bShouldListen)
{
	struct {
            bool bShouldListen;
	} params{ bShouldListen };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTabListWidget:SetListeningForInput");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonTabListWidget::SetLinkedSwitcher(class UCommonWidgetSwitcher* CommonSwitcher)
{
	struct {
            class UCommonWidgetSwitcher* CommonSwitcher;
	} params{ CommonSwitcher };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTabListWidget:SetLinkedSwitcher");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UCommonTabListWidget::SelectTabByID(FName TabNameID, bool bSuppressClickFeedback)
{
	struct {
            FName TabNameID;
            bool bSuppressClickFeedback;
            bool ReturnValue;
	} params{ TabNameID, bSuppressClickFeedback };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTabListWidget:SelectTabByID");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UCommonTabListWidget::RemoveTab(FName TabNameID)
{
	struct {
            FName TabNameID;
            bool ReturnValue;
	} params{ TabNameID };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTabListWidget:RemoveTab");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UCommonTabListWidget::RemoveAllTabs()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTabListWidget:RemoveAllTabs");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


bool UCommonTabListWidget::RegisterTab(FName TabNameID, class UCommonButton* ButtonWidgetType, class UWidget* ContentWidget)
{
	struct {
            FName TabNameID;
            class UCommonButton* ButtonWidgetType;
            class UWidget* ContentWidget;
            bool ReturnValue;
	} params{ TabNameID, ButtonWidgetType, ContentWidget };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTabListWidget:RegisterTab");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UCommonTabListWidget::HandleTabRemoved(FName TabNameID, class UCommonButton* TabButton)
{
	struct {
            FName TabNameID;
            class UCommonButton* TabButton;
	} params{ TabNameID, TabButton };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTabListWidget:HandleTabRemoved");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonTabListWidget::HandleTabCreated(FName TabNameID, class UCommonButton* TabButton)
{
	struct {
            FName TabNameID;
            class UCommonButton* TabButton;
	} params{ TabNameID, TabButton };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTabListWidget:HandleTabCreated");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonTabListWidget::HandleTabButtonSelected(class UCommonButton* SelectedTabButton, int ButtonIndex)
{
	struct {
            class UCommonButton* SelectedTabButton;
            int ButtonIndex;
	} params{ SelectedTabButton, ButtonIndex };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTabListWidget:HandleTabButtonSelected");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonTabListWidget::HandlePreviousTabInputAction(bool bPassThrough)
{
	struct {
            bool bPassThrough;
	} params{ bPassThrough };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTabListWidget:HandlePreviousTabInputAction");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonTabListWidget::HandlePreLinkedSwitcherChanged_BP()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTabListWidget:HandlePreLinkedSwitcherChanged_BP");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonTabListWidget::HandlePostLinkedSwitcherChanged_BP()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTabListWidget:HandlePostLinkedSwitcherChanged_BP");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonTabListWidget::HandleNextTabInputAction(bool bPassThrough)
{
	struct {
            bool bPassThrough;
	} params{ bPassThrough };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTabListWidget:HandleNextTabInputAction");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


FName UCommonTabListWidget::GetTabIdAtIndex(int Index)
{
	struct {
            int Index;
            FName ReturnValue;
	} params{ Index };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTabListWidget:GetTabIdAtIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


int UCommonTabListWidget::GetTabCount()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTabListWidget:GetTabCount");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UCommonButton* UCommonTabListWidget::GetTabButtonByID(FName TabNameID)
{
	struct {
            FName TabNameID;
            class UCommonButton* ReturnValue;
	} params{ TabNameID };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTabListWidget:GetTabButtonByID");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


FName UCommonTabListWidget::GetSelectedTabId()
{
	struct {
            FName ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTabListWidget:GetSelectedTabId");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UCommonWidgetSwitcher* UCommonTabListWidget::GetLinkedSwitcher()
{
	struct {
            class UCommonWidgetSwitcher* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTabListWidget:GetLinkedSwitcher");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


FName UCommonTabListWidget::GetActiveTab()
{
	struct {
            FName ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTabListWidget:GetActiveTab");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UCommonTabListWidget::DisableTabWithReason(FName TabNameID, struct FText Reason)
{
	struct {
            FName TabNameID;
            struct FText Reason;
	} params{ TabNameID, Reason };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTabListWidget:DisableTabWithReason");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UCommonTextStyle::GetShadowOffset(struct FVector2D OutShadowOffset)
{
	struct {
            struct FVector2D OutShadowOffset;
	} params{ OutShadowOffset };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTextStyle:GetShadowOffset");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonTextStyle::GetShadowColor(struct FLinearColor OutColor)
{
	struct {
            struct FLinearColor OutColor;
	} params{ OutColor };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTextStyle:GetShadowColor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonTextStyle::GetMargin(struct FMargin OutMargin)
{
	struct {
            struct FMargin OutMargin;
	} params{ OutMargin };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTextStyle:GetMargin");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


float UCommonTextStyle::GetLineHeightPercentage()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTextStyle:GetLineHeightPercentage");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UCommonTextStyle::GetFont(struct FSlateFontInfo OutFont)
{
	struct {
            struct FSlateFontInfo OutFont;
	} params{ OutFont };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTextStyle:GetFont");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonTextStyle::GetColor(struct FLinearColor OutColor)
{
	struct {
            struct FLinearColor OutColor;
	} params{ OutColor };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonTextStyle:GetColor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

static class UWidget* UCommonUILibrary::FindParentWidgetOfType(class UWidget* StartingWidget, class UWidget* Type)
{
	struct {
            class UWidget* StartingWidget;
            class UWidget* Type;
            class UWidget* ReturnValue;
	} params{ StartingWidget, Type };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonUILibrary:FindParentWidgetOfType");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

class UCommonInputManager* UCommonUISubsystem::GetInputManager()
{
	struct {
            class UCommonInputManager* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonUISubsystem:GetInputManager");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FSlateBrush UCommonUISubsystem::GetInputActionButtonIcon(struct FDataTableRowHandle InputActionRowHandle, ECommonInputType InputType, ECommonGamepadType GamepadType)
{
	struct {
            struct FDataTableRowHandle InputActionRowHandle;
            ECommonInputType InputType;
            ECommonGamepadType GamepadType;
            struct FSlateBrush ReturnValue;
	} params{ InputActionRowHandle, InputType, GamepadType };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonUISubsystem:GetInputActionButtonIcon");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UCommonWidgetCarousel::SetActiveWidgetIndex(int Index)
{
	struct {
            int Index;
	} params{ Index };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetCarousel:SetActiveWidgetIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonWidgetCarousel::SetActiveWidget(class UWidget* Widget)
{
	struct {
            class UWidget* Widget;
	} params{ Widget };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetCarousel:SetActiveWidget");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonWidgetCarousel::PreviousPage()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetCarousel:PreviousPage");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonWidgetCarousel::NextPage()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetCarousel:NextPage");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


class UWidget* UCommonWidgetCarousel::GetWidgetAtIndex(int Index)
{
	struct {
            int Index;
            class UWidget* ReturnValue;
	} params{ Index };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetCarousel:GetWidgetAtIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


int UCommonWidgetCarousel::GetActiveWidgetIndex()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetCarousel:GetActiveWidgetIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UCommonWidgetCarousel::EndAutoScrolling()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetCarousel:EndAutoScrolling");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonWidgetCarousel::BeginAutoScrolling(float ScrollInterval)
{
	struct {
            float ScrollInterval;
	} params{ ScrollInterval };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetCarousel:BeginAutoScrolling");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UCommonWidgetCarouselNavBar::SetLinkedCarousel(class UCommonWidgetCarousel* CommonCarousel)
{
	struct {
            class UCommonWidgetCarousel* CommonCarousel;
	} params{ CommonCarousel };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetCarouselNavBar:SetLinkedCarousel");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonWidgetCarouselNavBar::HandlePageChanged(class UCommonWidgetCarousel* CommonCarousel, int PageIndex)
{
	struct {
            class UCommonWidgetCarousel* CommonCarousel;
            int PageIndex;
	} params{ CommonCarousel, PageIndex };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetCarouselNavBar:HandlePageChanged");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonWidgetCarouselNavBar::HandleButtonClicked(class UCommonButton* AssociatedButton, int ButtonIndex)
{
	struct {
            class UCommonButton* AssociatedButton;
            int ButtonIndex;
	} params{ AssociatedButton, ButtonIndex };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetCarouselNavBar:HandleButtonClicked");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UCommonWidgetSwitcher::SetDisableTransitionAnimation(bool bDisableAnimation)
{
	struct {
            bool bDisableAnimation;
	} params{ bDisableAnimation };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetSwitcher:SetDisableTransitionAnimation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonWidgetSwitcher::SetActiveWidgetIndex_Advanced(int Index, bool AttemptActivationChange)
{
	struct {
            int Index;
            bool AttemptActivationChange;
	} params{ Index, AttemptActivationChange };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetSwitcher:SetActiveWidgetIndex_Advanced");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonWidgetSwitcher::SetActiveWidget_Advanced(class UWidget* Widget, bool AttemptActivationChange)
{
	struct {
            class UWidget* Widget;
            bool AttemptActivationChange;
	} params{ Widget, AttemptActivationChange };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetSwitcher:SetActiveWidget_Advanced");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UCommonWidgetSwitcher::HasWidgets()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetSwitcher:HasWidgets");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UCommonWidgetSwitcher::HandleActiveWidgetDeactivated(class UCommonActivatablePanel* DeactivatedPanel)
{
	struct {
            class UCommonActivatablePanel* DeactivatedPanel;
	} params{ DeactivatedPanel };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetSwitcher:HandleActiveWidgetDeactivated");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonWidgetSwitcher::DeactivateWidget()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetSwitcher:DeactivateWidget");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonWidgetSwitcher::ActivateWidget()
{
    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetSwitcher:ActivateWidget");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UCommonWidgetSwitcher::ActivatePreviousWidget(bool bCanWrap)
{
	struct {
            bool bCanWrap;
	} params{ bCanWrap };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetSwitcher:ActivatePreviousWidget");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCommonWidgetSwitcher::ActivateNextWidget(bool bCanWrap)
{
	struct {
            bool bCanWrap;
	} params{ bCanWrap };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetSwitcher:ActivateNextWidget");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UCommonWidgetStack::PushWidget(class UWidget* InWidget)
{
	struct {
            class UWidget* InWidget;
	} params{ InWidget };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetStack:PushWidget");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


class UWidget* UCommonWidgetStack::PopWidget()
{
	struct {
            class UWidget* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/CommonUI.CommonWidgetStack:PopWidget");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

