#include "../SDK.hpp"

void UWidget::SetVisibility(ESlateVisibility InVisibility)
{
	struct {
            ESlateVisibility InVisibility;
	} params{ InVisibility };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:SetVisibility");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidget::SetUserFocus(class APlayerController* PlayerController)
{
	struct {
            class APlayerController* PlayerController;
	} params{ PlayerController };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:SetUserFocus");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidget::SetToolTipText(struct FText InToolTipText)
{
	struct {
            struct FText InToolTipText;
	} params{ InToolTipText };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:SetToolTipText");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidget::SetToolTip(class UWidget* Widget)
{
	struct {
            class UWidget* Widget;
	} params{ Widget };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:SetToolTip");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidget::SetRenderTranslation(struct FVector2D Translation)
{
	struct {
            struct FVector2D Translation;
	} params{ Translation };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:SetRenderTranslation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidget::SetRenderTransformPivot(struct FVector2D Pivot)
{
	struct {
            struct FVector2D Pivot;
	} params{ Pivot };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:SetRenderTransformPivot");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidget::SetRenderTransform(struct FWidgetTransform InTransform)
{
	struct {
            struct FWidgetTransform InTransform;
	} params{ InTransform };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:SetRenderTransform");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidget::SetRenderShear(struct FVector2D Shear)
{
	struct {
            struct FVector2D Shear;
	} params{ Shear };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:SetRenderShear");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidget::SetRenderScale(struct FVector2D Scale)
{
	struct {
            struct FVector2D Scale;
	} params{ Scale };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:SetRenderScale");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidget::SetRenderOpacity(float InOpacity)
{
	struct {
            float InOpacity;
	} params{ InOpacity };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:SetRenderOpacity");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidget::SetRenderAngle(float Angle)
{
	struct {
            float Angle;
	} params{ Angle };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:SetRenderAngle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidget::SetNavigationRule(EUINavigation Direction, EUINavigationRule Rule, FName WidgetToFocus)
{
	struct {
            EUINavigation Direction;
            EUINavigationRule Rule;
            FName WidgetToFocus;
	} params{ Direction, Rule, WidgetToFocus };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:SetNavigationRule");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidget::SetKeyboardFocus()
{
    static auto fn = UObject::FindObject("/Script/UMG.Widget:SetKeyboardFocus");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UWidget::SetIsEnabled(bool bInIsEnabled)
{
	struct {
            bool bInIsEnabled;
	} params{ bInIsEnabled };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:SetIsEnabled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidget::SetCursor(char InCursor)
{
	struct {
            char InCursor;
	} params{ InCursor };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:SetCursor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidget::SetClipping(EWidgetClipping InClipping)
{
	struct {
            EWidgetClipping InClipping;
	} params{ InClipping };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:SetClipping");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidget::SetAllNavigationRules(EUINavigationRule Rule, FName WidgetToFocus)
{
	struct {
            EUINavigationRule Rule;
            FName WidgetToFocus;
	} params{ Rule, WidgetToFocus };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:SetAllNavigationRules");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidget::ResetCursor()
{
    static auto fn = UObject::FindObject("/Script/UMG.Widget:ResetCursor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UWidget::RemoveFromParent()
{
    static auto fn = UObject::FindObject("/Script/UMG.Widget:RemoveFromParent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


bool UWidget::IsVisible()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:IsVisible");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UWidget::IsHovered()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:IsHovered");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UWidget::InvalidateLayoutAndVolatility()
{
    static auto fn = UObject::FindObject("/Script/UMG.Widget:InvalidateLayoutAndVolatility");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


bool UWidget::HasUserFocusedDescendants(class APlayerController* PlayerController)
{
	struct {
            class APlayerController* PlayerController;
            bool ReturnValue;
	} params{ PlayerController };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:HasUserFocusedDescendants");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UWidget::HasUserFocus(class APlayerController* PlayerController)
{
	struct {
            class APlayerController* PlayerController;
            bool ReturnValue;
	} params{ PlayerController };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:HasUserFocus");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UWidget::HasMouseCaptureByUser(int UserIndex, int PointerIndex)
{
	struct {
            int UserIndex;
            int PointerIndex;
            bool ReturnValue;
	} params{ UserIndex, PointerIndex };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:HasMouseCaptureByUser");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UWidget::HasMouseCapture()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:HasMouseCapture");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UWidget::HasKeyboardFocus()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:HasKeyboardFocus");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UWidget::HasFocusedDescendants()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:HasFocusedDescendants");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UWidget::HasAnyUserFocus()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:HasAnyUserFocus");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


ESlateVisibility UWidget::GetVisibility()
{
	struct {
            ESlateVisibility ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:GetVisibility");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UWidget::GetRenderOpacity()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:GetRenderOpacity");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UPanelWidget* UWidget::GetParent()
{
	struct {
            class UPanelWidget* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:GetParent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class APlayerController* UWidget::GetOwningPlayer()
{
	struct {
            class APlayerController* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:GetOwningPlayer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class ULocalPlayer* UWidget::GetOwningLocalPlayer()
{
	struct {
            class ULocalPlayer* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:GetOwningLocalPlayer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UWidget::GetIsEnabled()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:GetIsEnabled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UGameInstance* UWidget::GetGameInstance()
{
	struct {
            class UGameInstance* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:GetGameInstance");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FVector2D UWidget::GetDesiredSize()
{
	struct {
            struct FVector2D ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:GetDesiredSize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


EWidgetClipping UWidget::GetClipping()
{
	struct {
            EWidgetClipping ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:GetClipping");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FGeometry UWidget::GetCachedGeometry()
{
	struct {
            struct FGeometry ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:GetCachedGeometry");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UWidget::ForceVolatile(bool bForce)
{
	struct {
            bool bForce;
	} params{ bForce };

    static auto fn = UObject::FindObject("/Script/UMG.Widget:ForceVolatile");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidget::ForceLayoutPrepass()
{
    static auto fn = UObject::FindObject("/Script/UMG.Widget:ForceLayoutPrepass");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

void USlider::SetValue(float InValue)
{
	struct {
            float InValue;
	} params{ InValue };

    static auto fn = UObject::FindObject("/Script/UMG.Slider:SetValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USlider::SetStepSize(float InValue)
{
	struct {
            float InValue;
	} params{ InValue };

    static auto fn = UObject::FindObject("/Script/UMG.Slider:SetStepSize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USlider::SetSliderHandleColor(struct FLinearColor InValue)
{
	struct {
            struct FLinearColor InValue;
	} params{ InValue };

    static auto fn = UObject::FindObject("/Script/UMG.Slider:SetSliderHandleColor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USlider::SetSliderBarColor(struct FLinearColor InValue)
{
	struct {
            struct FLinearColor InValue;
	} params{ InValue };

    static auto fn = UObject::FindObject("/Script/UMG.Slider:SetSliderBarColor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USlider::SetLocked(bool InValue)
{
	struct {
            bool InValue;
	} params{ InValue };

    static auto fn = UObject::FindObject("/Script/UMG.Slider:SetLocked");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USlider::SetIndentHandle(bool InValue)
{
	struct {
            bool InValue;
	} params{ InValue };

    static auto fn = UObject::FindObject("/Script/UMG.Slider:SetIndentHandle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


float USlider::GetValue()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Slider:GetValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UUserWidget::UnregisterInputComponent()
{
    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:UnregisterInputComponent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UUserWidget::UnbindFromAnimationStarted(class UWidgetAnimation* Animation, __int64/*DelegateProperty*/ Delegate)
{
	struct {
            class UWidgetAnimation* Animation;
            __int64/*DelegateProperty*/ Delegate;
	} params{ Animation, Delegate };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:UnbindFromAnimationStarted");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::UnbindFromAnimationFinished(class UWidgetAnimation* Animation, __int64/*DelegateProperty*/ Delegate)
{
	struct {
            class UWidgetAnimation* Animation;
            __int64/*DelegateProperty*/ Delegate;
	} params{ Animation, Delegate };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:UnbindFromAnimationFinished");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::UnbindAllFromAnimationStarted(class UWidgetAnimation* Animation)
{
	struct {
            class UWidgetAnimation* Animation;
	} params{ Animation };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:UnbindAllFromAnimationStarted");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::UnbindAllFromAnimationFinished(class UWidgetAnimation* Animation)
{
	struct {
            class UWidgetAnimation* Animation;
	} params{ Animation };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:UnbindAllFromAnimationFinished");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::Tick(struct FGeometry MyGeometry, float InDeltaTime)
{
	struct {
            struct FGeometry MyGeometry;
            float InDeltaTime;
	} params{ MyGeometry, InDeltaTime };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:Tick");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::StopListeningForInputAction(FName ActionName, char EventType)
{
	struct {
            FName ActionName;
            char EventType;
	} params{ ActionName, EventType };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:StopListeningForInputAction");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::StopListeningForAllInputActions()
{
    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:StopListeningForAllInputActions");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UUserWidget::StopAnimationsAndLatentActions()
{
    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:StopAnimationsAndLatentActions");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UUserWidget::StopAnimation(class UWidgetAnimation* InAnimation)
{
	struct {
            class UWidgetAnimation* InAnimation;
	} params{ InAnimation };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:StopAnimation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::StopAllAnimations()
{
    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:StopAllAnimations");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UUserWidget::SetPositionInViewport(struct FVector2D Position, bool bRemoveDPIScale)
{
	struct {
            struct FVector2D Position;
            bool bRemoveDPIScale;
	} params{ Position, bRemoveDPIScale };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:SetPositionInViewport");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::SetPlaybackSpeed(class UWidgetAnimation* InAnimation, float PlaybackSpeed)
{
	struct {
            class UWidgetAnimation* InAnimation;
            float PlaybackSpeed;
	} params{ InAnimation, PlaybackSpeed };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:SetPlaybackSpeed");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::SetPadding(struct FMargin InPadding)
{
	struct {
            struct FMargin InPadding;
	} params{ InPadding };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:SetPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::SetOwningPlayer(class APlayerController* LocalPlayerController)
{
	struct {
            class APlayerController* LocalPlayerController;
	} params{ LocalPlayerController };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:SetOwningPlayer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::SetNumLoopsToPlay(class UWidgetAnimation* InAnimation, int NumLoopsToPlay)
{
	struct {
            class UWidgetAnimation* InAnimation;
            int NumLoopsToPlay;
	} params{ InAnimation, NumLoopsToPlay };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:SetNumLoopsToPlay");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::SetInputActionPriority(int NewPriority)
{
	struct {
            int NewPriority;
	} params{ NewPriority };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:SetInputActionPriority");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::SetInputActionBlocking(bool bShouldBlock)
{
	struct {
            bool bShouldBlock;
	} params{ bShouldBlock };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:SetInputActionBlocking");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::SetForegroundColor(struct FSlateColor InForegroundColor)
{
	struct {
            struct FSlateColor InForegroundColor;
	} params{ InForegroundColor };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:SetForegroundColor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::SetDesiredSizeInViewport(struct FVector2D Size)
{
	struct {
            struct FVector2D Size;
	} params{ Size };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:SetDesiredSizeInViewport");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::SetColorAndOpacity(struct FLinearColor InColorAndOpacity)
{
	struct {
            struct FLinearColor InColorAndOpacity;
	} params{ InColorAndOpacity };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:SetColorAndOpacity");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::SetAnchorsInViewport(struct FAnchors Anchors)
{
	struct {
            struct FAnchors Anchors;
	} params{ Anchors };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:SetAnchorsInViewport");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::SetAlignmentInViewport(struct FVector2D Alignment)
{
	struct {
            struct FVector2D Alignment;
	} params{ Alignment };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:SetAlignmentInViewport");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::ReverseAnimation(class UWidgetAnimation* InAnimation)
{
	struct {
            class UWidgetAnimation* InAnimation;
	} params{ InAnimation };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:ReverseAnimation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::RemoveFromViewport()
{
    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:RemoveFromViewport");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UUserWidget::RegisterInputComponent()
{
    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:RegisterInputComponent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UUserWidget::PreConstruct(bool IsDesignTime)
{
	struct {
            bool IsDesignTime;
	} params{ IsDesignTime };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:PreConstruct");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::PlaySound(class USoundBase* SoundToPlay)
{
	struct {
            class USoundBase* SoundToPlay;
	} params{ SoundToPlay };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:PlaySound");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


class UUMGSequencePlayer* UUserWidget::PlayAnimationTimeRange(class UWidgetAnimation* InAnimation, float StartAtTime, float EndAtTime, int NumLoopsToPlay, char PlayMode, float PlaybackSpeed)
{
	struct {
            class UWidgetAnimation* InAnimation;
            float StartAtTime;
            float EndAtTime;
            int NumLoopsToPlay;
            char PlayMode;
            float PlaybackSpeed;
            class UUMGSequencePlayer* ReturnValue;
	} params{ InAnimation, StartAtTime, EndAtTime, NumLoopsToPlay, PlayMode, PlaybackSpeed };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:PlayAnimationTimeRange");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


class UUMGSequencePlayer* UUserWidget::PlayAnimationReverse(class UWidgetAnimation* InAnimation, float PlaybackSpeed)
{
	struct {
            class UWidgetAnimation* InAnimation;
            float PlaybackSpeed;
            class UUMGSequencePlayer* ReturnValue;
	} params{ InAnimation, PlaybackSpeed };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:PlayAnimationReverse");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


class UUMGSequencePlayer* UUserWidget::PlayAnimationForward(class UWidgetAnimation* InAnimation, float PlaybackSpeed)
{
	struct {
            class UWidgetAnimation* InAnimation;
            float PlaybackSpeed;
            class UUMGSequencePlayer* ReturnValue;
	} params{ InAnimation, PlaybackSpeed };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:PlayAnimationForward");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


class UUMGSequencePlayer* UUserWidget::PlayAnimation(class UWidgetAnimation* InAnimation, float StartAtTime, int NumLoopsToPlay, char PlayMode, float PlaybackSpeed)
{
	struct {
            class UWidgetAnimation* InAnimation;
            float StartAtTime;
            int NumLoopsToPlay;
            char PlayMode;
            float PlaybackSpeed;
            class UUMGSequencePlayer* ReturnValue;
	} params{ InAnimation, StartAtTime, NumLoopsToPlay, PlayMode, PlaybackSpeed };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:PlayAnimation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


float UUserWidget::PauseAnimation(class UWidgetAnimation* InAnimation)
{
	struct {
            class UWidgetAnimation* InAnimation;
            float ReturnValue;
	} params{ InAnimation };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:PauseAnimation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FEventReply UUserWidget::OnTouchStarted(struct FGeometry MyGeometry, struct FPointerEvent InTouchEvent)
{
	struct {
            struct FGeometry MyGeometry;
            struct FPointerEvent InTouchEvent;
            struct FEventReply ReturnValue;
	} params{ MyGeometry, InTouchEvent };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnTouchStarted");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FEventReply UUserWidget::OnTouchMoved(struct FGeometry MyGeometry, struct FPointerEvent InTouchEvent)
{
	struct {
            struct FGeometry MyGeometry;
            struct FPointerEvent InTouchEvent;
            struct FEventReply ReturnValue;
	} params{ MyGeometry, InTouchEvent };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnTouchMoved");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FEventReply UUserWidget::OnTouchGesture(struct FGeometry MyGeometry, struct FPointerEvent GestureEvent)
{
	struct {
            struct FGeometry MyGeometry;
            struct FPointerEvent GestureEvent;
            struct FEventReply ReturnValue;
	} params{ MyGeometry, GestureEvent };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnTouchGesture");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FEventReply UUserWidget::OnTouchForceChanged(struct FGeometry MyGeometry, struct FPointerEvent InTouchEvent)
{
	struct {
            struct FGeometry MyGeometry;
            struct FPointerEvent InTouchEvent;
            struct FEventReply ReturnValue;
	} params{ MyGeometry, InTouchEvent };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnTouchForceChanged");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FEventReply UUserWidget::OnTouchEnded(struct FGeometry MyGeometry, struct FPointerEvent InTouchEvent)
{
	struct {
            struct FGeometry MyGeometry;
            struct FPointerEvent InTouchEvent;
            struct FEventReply ReturnValue;
	} params{ MyGeometry, InTouchEvent };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnTouchEnded");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UUserWidget::OnRemovedFromFocusPath(struct FFocusEvent InFocusEvent)
{
	struct {
            struct FFocusEvent InFocusEvent;
	} params{ InFocusEvent };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnRemovedFromFocusPath");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


struct FEventReply UUserWidget::OnPreviewMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent)
{
	struct {
            struct FGeometry MyGeometry;
            struct FPointerEvent MouseEvent;
            struct FEventReply ReturnValue;
	} params{ MyGeometry, MouseEvent };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnPreviewMouseButtonDown");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FEventReply UUserWidget::OnPreviewKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent)
{
	struct {
            struct FGeometry MyGeometry;
            struct FKeyEvent InKeyEvent;
            struct FEventReply ReturnValue;
	} params{ MyGeometry, InKeyEvent };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnPreviewKeyDown");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UUserWidget::OnPaint(struct FPaintContext Context)
{
	struct {
            struct FPaintContext Context;
	} params{ Context };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnPaint");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


struct FEventReply UUserWidget::OnMouseWheel(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent)
{
	struct {
            struct FGeometry MyGeometry;
            struct FPointerEvent MouseEvent;
            struct FEventReply ReturnValue;
	} params{ MyGeometry, MouseEvent };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnMouseWheel");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FEventReply UUserWidget::OnMouseMove(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent)
{
	struct {
            struct FGeometry MyGeometry;
            struct FPointerEvent MouseEvent;
            struct FEventReply ReturnValue;
	} params{ MyGeometry, MouseEvent };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnMouseMove");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UUserWidget::OnMouseLeave(struct FPointerEvent MouseEvent)
{
	struct {
            struct FPointerEvent MouseEvent;
	} params{ MouseEvent };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnMouseLeave");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::OnMouseEnter(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent)
{
	struct {
            struct FGeometry MyGeometry;
            struct FPointerEvent MouseEvent;
	} params{ MyGeometry, MouseEvent };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnMouseEnter");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::OnMouseCaptureLost()
{
    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnMouseCaptureLost");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


struct FEventReply UUserWidget::OnMouseButtonUp(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent)
{
	struct {
            struct FGeometry MyGeometry;
            struct FPointerEvent MouseEvent;
            struct FEventReply ReturnValue;
	} params{ MyGeometry, MouseEvent };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnMouseButtonUp");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FEventReply UUserWidget::OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent)
{
	struct {
            struct FGeometry MyGeometry;
            struct FPointerEvent MouseEvent;
            struct FEventReply ReturnValue;
	} params{ MyGeometry, MouseEvent };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnMouseButtonDown");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FEventReply UUserWidget::OnMouseButtonDoubleClick(struct FGeometry InMyGeometry, struct FPointerEvent InMouseEvent)
{
	struct {
            struct FGeometry InMyGeometry;
            struct FPointerEvent InMouseEvent;
            struct FEventReply ReturnValue;
	} params{ InMyGeometry, InMouseEvent };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnMouseButtonDoubleClick");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FEventReply UUserWidget::OnMotionDetected(struct FGeometry MyGeometry, struct FMotionEvent InMotionEvent)
{
	struct {
            struct FGeometry MyGeometry;
            struct FMotionEvent InMotionEvent;
            struct FEventReply ReturnValue;
	} params{ MyGeometry, InMotionEvent };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnMotionDetected");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FEventReply UUserWidget::OnKeyUp(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent)
{
	struct {
            struct FGeometry MyGeometry;
            struct FKeyEvent InKeyEvent;
            struct FEventReply ReturnValue;
	} params{ MyGeometry, InKeyEvent };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnKeyUp");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FEventReply UUserWidget::OnKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent)
{
	struct {
            struct FGeometry MyGeometry;
            struct FKeyEvent InKeyEvent;
            struct FEventReply ReturnValue;
	} params{ MyGeometry, InKeyEvent };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnKeyDown");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FEventReply UUserWidget::OnKeyChar(struct FGeometry MyGeometry, struct FCharacterEvent InCharacterEvent)
{
	struct {
            struct FGeometry MyGeometry;
            struct FCharacterEvent InCharacterEvent;
            struct FEventReply ReturnValue;
	} params{ MyGeometry, InCharacterEvent };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnKeyChar");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UUserWidget::OnInitialized()
{
    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnInitialized");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


struct FEventReply UUserWidget::OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent)
{
	struct {
            struct FGeometry MyGeometry;
            struct FFocusEvent InFocusEvent;
            struct FEventReply ReturnValue;
	} params{ MyGeometry, InFocusEvent };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnFocusReceived");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UUserWidget::OnFocusLost(struct FFocusEvent InFocusEvent)
{
	struct {
            struct FFocusEvent InFocusEvent;
	} params{ InFocusEvent };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnFocusLost");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UUserWidget::OnDrop(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, class UDragDropOperation* Operation)
{
	struct {
            struct FGeometry MyGeometry;
            struct FPointerEvent PointerEvent;
            class UDragDropOperation* Operation;
            bool ReturnValue;
	} params{ MyGeometry, PointerEvent, Operation };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnDrop");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UUserWidget::OnDragOver(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, class UDragDropOperation* Operation)
{
	struct {
            struct FGeometry MyGeometry;
            struct FPointerEvent PointerEvent;
            class UDragDropOperation* Operation;
            bool ReturnValue;
	} params{ MyGeometry, PointerEvent, Operation };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnDragOver");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UUserWidget::OnDragLeave(struct FPointerEvent PointerEvent, class UDragDropOperation* Operation)
{
	struct {
            struct FPointerEvent PointerEvent;
            class UDragDropOperation* Operation;
	} params{ PointerEvent, Operation };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnDragLeave");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::OnDragEnter(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, class UDragDropOperation* Operation)
{
	struct {
            struct FGeometry MyGeometry;
            struct FPointerEvent PointerEvent;
            class UDragDropOperation* Operation;
	} params{ MyGeometry, PointerEvent, Operation };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnDragEnter");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::OnDragDetected(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, class UDragDropOperation* Operation)
{
	struct {
            struct FGeometry MyGeometry;
            struct FPointerEvent PointerEvent;
            class UDragDropOperation* Operation;
	} params{ MyGeometry, PointerEvent, Operation };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnDragDetected");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::OnDragCancelled(struct FPointerEvent PointerEvent, class UDragDropOperation* Operation)
{
	struct {
            struct FPointerEvent PointerEvent;
            class UDragDropOperation* Operation;
	} params{ PointerEvent, Operation };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnDragCancelled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::OnAnimationStarted(class UWidgetAnimation* Animation)
{
	struct {
            class UWidgetAnimation* Animation;
	} params{ Animation };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnAnimationStarted");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::OnAnimationFinished(class UWidgetAnimation* Animation)
{
	struct {
            class UWidgetAnimation* Animation;
	} params{ Animation };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnAnimationFinished");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


struct FEventReply UUserWidget::OnAnalogValueChanged(struct FGeometry MyGeometry, struct FAnalogInputEvent InAnalogInputEvent)
{
	struct {
            struct FGeometry MyGeometry;
            struct FAnalogInputEvent InAnalogInputEvent;
            struct FEventReply ReturnValue;
	} params{ MyGeometry, InAnalogInputEvent };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnAnalogValueChanged");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UUserWidget::OnAddedToFocusPath(struct FFocusEvent InFocusEvent)
{
	struct {
            struct FFocusEvent InFocusEvent;
	} params{ InFocusEvent };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:OnAddedToFocusPath");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::ListenForInputAction(FName ActionName, char EventType, bool bConsume, __int64/*DelegateProperty*/ Callback)
{
	struct {
            FName ActionName;
            char EventType;
            bool bConsume;
            __int64/*DelegateProperty*/ Callback;
	} params{ ActionName, EventType, bConsume, Callback };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:ListenForInputAction");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UUserWidget::IsPlayingAnimation()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:IsPlayingAnimation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UUserWidget::IsListeningForInputAction(FName ActionName)
{
	struct {
            FName ActionName;
            bool ReturnValue;
	} params{ ActionName };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:IsListeningForInputAction");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UUserWidget::IsInViewport()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:IsInViewport");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UUserWidget::IsInteractable()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:IsInteractable");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UUserWidget::IsAnyAnimationPlaying()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:IsAnyAnimationPlaying");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UUserWidget::IsAnimationPlayingForward(class UWidgetAnimation* InAnimation)
{
	struct {
            class UWidgetAnimation* InAnimation;
            bool ReturnValue;
	} params{ InAnimation };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:IsAnimationPlayingForward");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UUserWidget::IsAnimationPlaying(class UWidgetAnimation* InAnimation)
{
	struct {
            class UWidgetAnimation* InAnimation;
            bool ReturnValue;
	} params{ InAnimation };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:IsAnimationPlaying");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


class APawn* UUserWidget::GetOwningPlayerPawn()
{
	struct {
            class APawn* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:GetOwningPlayerPawn");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UUserWidget::GetIsVisible()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:GetIsVisible");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UUserWidget::GetAnimationCurrentTime(class UWidgetAnimation* InAnimation)
{
	struct {
            class UWidgetAnimation* InAnimation;
            float ReturnValue;
	} params{ InAnimation };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:GetAnimationCurrentTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


struct FAnchors UUserWidget::GetAnchorsInViewport()
{
	struct {
            struct FAnchors ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:GetAnchorsInViewport");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FVector2D UUserWidget::GetAlignmentInViewport()
{
	struct {
            struct FVector2D ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:GetAlignmentInViewport");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UUserWidget::Destruct()
{
    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:Destruct");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UUserWidget::Construct()
{
    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:Construct");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UUserWidget::CancelLatentActions()
{
    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:CancelLatentActions");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UUserWidget::BindToAnimationStarted(class UWidgetAnimation* Animation, __int64/*DelegateProperty*/ Delegate)
{
	struct {
            class UWidgetAnimation* Animation;
            __int64/*DelegateProperty*/ Delegate;
	} params{ Animation, Delegate };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:BindToAnimationStarted");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::BindToAnimationFinished(class UWidgetAnimation* Animation, __int64/*DelegateProperty*/ Delegate)
{
	struct {
            class UWidgetAnimation* Animation;
            __int64/*DelegateProperty*/ Delegate;
	} params{ Animation, Delegate };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:BindToAnimationFinished");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::BindToAnimationEvent(class UWidgetAnimation* Animation, __int64/*DelegateProperty*/ Delegate, EWidgetAnimationEvent AnimationEvent, FName UserTag)
{
	struct {
            class UWidgetAnimation* Animation;
            __int64/*DelegateProperty*/ Delegate;
            EWidgetAnimationEvent AnimationEvent;
            FName UserTag;
	} params{ Animation, Delegate, AnimationEvent, UserTag };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:BindToAnimationEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserWidget::AddToViewport(int ZOrder)
{
	struct {
            int ZOrder;
	} params{ ZOrder };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:AddToViewport");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UUserWidget::AddToPlayerScreen(int ZOrder)
{
	struct {
            int ZOrder;
            bool ReturnValue;
	} params{ ZOrder };

    static auto fn = UObject::FindObject("/Script/UMG.UserWidget:AddToPlayerScreen");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

bool UPanelWidget::RemoveChildAt(int Index)
{
	struct {
            int Index;
            bool ReturnValue;
	} params{ Index };

    static auto fn = UObject::FindObject("/Script/UMG.PanelWidget:RemoveChildAt");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UPanelWidget::RemoveChild(class UWidget* Content)
{
	struct {
            class UWidget* Content;
            bool ReturnValue;
	} params{ Content };

    static auto fn = UObject::FindObject("/Script/UMG.PanelWidget:RemoveChild");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UPanelWidget::HasChild(class UWidget* Content)
{
	struct {
            class UWidget* Content;
            bool ReturnValue;
	} params{ Content };

    static auto fn = UObject::FindObject("/Script/UMG.PanelWidget:HasChild");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UPanelWidget::HasAnyChildren()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.PanelWidget:HasAnyChildren");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


int UPanelWidget::GetChildrenCount()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.PanelWidget:GetChildrenCount");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


int UPanelWidget::GetChildIndex(class UWidget* Content)
{
	struct {
            class UWidget* Content;
            int ReturnValue;
	} params{ Content };

    static auto fn = UObject::FindObject("/Script/UMG.PanelWidget:GetChildIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


class UWidget* UPanelWidget::GetChildAt(int Index)
{
	struct {
            int Index;
            class UWidget* ReturnValue;
	} params{ Index };

    static auto fn = UObject::FindObject("/Script/UMG.PanelWidget:GetChildAt");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UPanelWidget::ClearChildren()
{
    static auto fn = UObject::FindObject("/Script/UMG.PanelWidget:ClearChildren");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


class UPanelSlot* UPanelWidget::AddChild(class UWidget* Content)
{
	struct {
            class UWidget* Content;
            class UPanelSlot* ReturnValue;
	} params{ Content };

    static auto fn = UObject::FindObject("/Script/UMG.PanelWidget:AddChild");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

class UPanelSlot* UContentWidget::SetContent(class UWidget* Content)
{
	struct {
            class UWidget* Content;
            class UPanelSlot* ReturnValue;
	} params{ Content };

    static auto fn = UObject::FindObject("/Script/UMG.ContentWidget:SetContent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


class UPanelSlot* UContentWidget::GetContentSlot()
{
	struct {
            class UPanelSlot* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.ContentWidget:GetContentSlot");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UWidget* UContentWidget::GetContent()
{
	struct {
            class UWidget* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.ContentWidget:GetContent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UBorder::SetVerticalAlignment(char InVerticalAlignment)
{
	struct {
            char InVerticalAlignment;
	} params{ InVerticalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.Border:SetVerticalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBorder::SetPadding(struct FMargin InPadding)
{
	struct {
            struct FMargin InPadding;
	} params{ InPadding };

    static auto fn = UObject::FindObject("/Script/UMG.Border:SetPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBorder::SetHorizontalAlignment(char InHorizontalAlignment)
{
	struct {
            char InHorizontalAlignment;
	} params{ InHorizontalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.Border:SetHorizontalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBorder::SetDesiredSizeScale(struct FVector2D InScale)
{
	struct {
            struct FVector2D InScale;
	} params{ InScale };

    static auto fn = UObject::FindObject("/Script/UMG.Border:SetDesiredSizeScale");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBorder::SetContentColorAndOpacity(struct FLinearColor InContentColorAndOpacity)
{
	struct {
            struct FLinearColor InContentColorAndOpacity;
	} params{ InContentColorAndOpacity };

    static auto fn = UObject::FindObject("/Script/UMG.Border:SetContentColorAndOpacity");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBorder::SetBrushFromTexture(class UTexture2D* Texture)
{
	struct {
            class UTexture2D* Texture;
	} params{ Texture };

    static auto fn = UObject::FindObject("/Script/UMG.Border:SetBrushFromTexture");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBorder::SetBrushFromMaterial(class UMaterialInterface* Material)
{
	struct {
            class UMaterialInterface* Material;
	} params{ Material };

    static auto fn = UObject::FindObject("/Script/UMG.Border:SetBrushFromMaterial");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBorder::SetBrushFromAsset(class USlateBrushAsset* Asset)
{
	struct {
            class USlateBrushAsset* Asset;
	} params{ Asset };

    static auto fn = UObject::FindObject("/Script/UMG.Border:SetBrushFromAsset");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBorder::SetBrushColor(struct FLinearColor InBrushColor)
{
	struct {
            struct FLinearColor InBrushColor;
	} params{ InBrushColor };

    static auto fn = UObject::FindObject("/Script/UMG.Border:SetBrushColor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBorder::SetBrush(struct FSlateBrush InBrush)
{
	struct {
            struct FSlateBrush InBrush;
	} params{ InBrush };

    static auto fn = UObject::FindObject("/Script/UMG.Border:SetBrush");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


class UMaterialInstanceDynamic* UBorder::GetDynamicMaterial()
{
	struct {
            class UMaterialInstanceDynamic* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Border:GetDynamicMaterial");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UButton::SetTouchMethod(char InTouchMethod)
{
	struct {
            char InTouchMethod;
	} params{ InTouchMethod };

    static auto fn = UObject::FindObject("/Script/UMG.Button:SetTouchMethod");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UButton::SetStyle(struct FButtonStyle InStyle)
{
	struct {
            struct FButtonStyle InStyle;
	} params{ InStyle };

    static auto fn = UObject::FindObject("/Script/UMG.Button:SetStyle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UButton::SetPressMethod(char InPressMethod)
{
	struct {
            char InPressMethod;
	} params{ InPressMethod };

    static auto fn = UObject::FindObject("/Script/UMG.Button:SetPressMethod");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UButton::SetColorAndOpacity(struct FLinearColor InColorAndOpacity)
{
	struct {
            struct FLinearColor InColorAndOpacity;
	} params{ InColorAndOpacity };

    static auto fn = UObject::FindObject("/Script/UMG.Button:SetColorAndOpacity");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UButton::SetClickMethod(char InClickMethod)
{
	struct {
            char InClickMethod;
	} params{ InClickMethod };

    static auto fn = UObject::FindObject("/Script/UMG.Button:SetClickMethod");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UButton::SetBackgroundColor(struct FLinearColor InBackgroundColor)
{
	struct {
            struct FLinearColor InBackgroundColor;
	} params{ InBackgroundColor };

    static auto fn = UObject::FindObject("/Script/UMG.Button:SetBackgroundColor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UButton::IsPressed()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Button:IsPressed");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UTextBlock::SetText(struct FText InText)
{
	struct {
            struct FText InText;
	} params{ InText };

    static auto fn = UObject::FindObject("/Script/UMG.TextBlock:SetText");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTextBlock::SetShadowOffset(struct FVector2D InShadowOffset)
{
	struct {
            struct FVector2D InShadowOffset;
	} params{ InShadowOffset };

    static auto fn = UObject::FindObject("/Script/UMG.TextBlock:SetShadowOffset");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTextBlock::SetShadowColorAndOpacity(struct FLinearColor InShadowColorAndOpacity)
{
	struct {
            struct FLinearColor InShadowColorAndOpacity;
	} params{ InShadowColorAndOpacity };

    static auto fn = UObject::FindObject("/Script/UMG.TextBlock:SetShadowColorAndOpacity");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTextBlock::SetOpacity(float InOpacity)
{
	struct {
            float InOpacity;
	} params{ InOpacity };

    static auto fn = UObject::FindObject("/Script/UMG.TextBlock:SetOpacity");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTextBlock::SetMinDesiredWidth(float InMinDesiredWidth)
{
	struct {
            float InMinDesiredWidth;
	} params{ InMinDesiredWidth };

    static auto fn = UObject::FindObject("/Script/UMG.TextBlock:SetMinDesiredWidth");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTextBlock::SetJustification(char InJustification)
{
	struct {
            char InJustification;
	} params{ InJustification };

    static auto fn = UObject::FindObject("/Script/UMG.TextBlock:SetJustification");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTextBlock::SetFont(struct FSlateFontInfo InFontInfo)
{
	struct {
            struct FSlateFontInfo InFontInfo;
	} params{ InFontInfo };

    static auto fn = UObject::FindObject("/Script/UMG.TextBlock:SetFont");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTextBlock::SetColorAndOpacity(struct FSlateColor InColorAndOpacity)
{
	struct {
            struct FSlateColor InColorAndOpacity;
	} params{ InColorAndOpacity };

    static auto fn = UObject::FindObject("/Script/UMG.TextBlock:SetColorAndOpacity");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTextBlock::SetAutoWrapText(bool InAutoTextWrap)
{
	struct {
            bool InAutoTextWrap;
	} params{ InAutoTextWrap };

    static auto fn = UObject::FindObject("/Script/UMG.TextBlock:SetAutoWrapText");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


struct FText UTextBlock::GetText()
{
	struct {
            struct FText ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.TextBlock:GetText");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UMaterialInstanceDynamic* UTextBlock::GetDynamicOutlineMaterial()
{
	struct {
            class UMaterialInstanceDynamic* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.TextBlock:GetDynamicOutlineMaterial");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UMaterialInstanceDynamic* UTextBlock::GetDynamicFontMaterial()
{
	struct {
            class UMaterialInstanceDynamic* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.TextBlock:GetDynamicFontMaterial");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UScrollBox::SetScrollOffset(float NewScrollOffset)
{
	struct {
            float NewScrollOffset;
	} params{ NewScrollOffset };

    static auto fn = UObject::FindObject("/Script/UMG.ScrollBox:SetScrollOffset");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UScrollBox::SetScrollBarVisibility(ESlateVisibility NewScrollBarVisibility)
{
	struct {
            ESlateVisibility NewScrollBarVisibility;
	} params{ NewScrollBarVisibility };

    static auto fn = UObject::FindObject("/Script/UMG.ScrollBox:SetScrollBarVisibility");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UScrollBox::SetScrollbarThickness(struct FVector2D NewScrollbarThickness)
{
	struct {
            struct FVector2D NewScrollbarThickness;
	} params{ NewScrollbarThickness };

    static auto fn = UObject::FindObject("/Script/UMG.ScrollBox:SetScrollbarThickness");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UScrollBox::SetOrientation(char NewOrientation)
{
	struct {
            char NewOrientation;
	} params{ NewOrientation };

    static auto fn = UObject::FindObject("/Script/UMG.ScrollBox:SetOrientation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UScrollBox::SetAlwaysShowScrollbar(bool NewAlwaysShowScrollbar)
{
	struct {
            bool NewAlwaysShowScrollbar;
	} params{ NewAlwaysShowScrollbar };

    static auto fn = UObject::FindObject("/Script/UMG.ScrollBox:SetAlwaysShowScrollbar");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UScrollBox::SetAllowOverscroll(bool NewAllowOverscroll)
{
	struct {
            bool NewAllowOverscroll;
	} params{ NewAllowOverscroll };

    static auto fn = UObject::FindObject("/Script/UMG.ScrollBox:SetAllowOverscroll");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UScrollBox::ScrollWidgetIntoView(class UWidget* WidgetToFind, bool AnimateScroll, EDescendantScrollDestination ScrollDestination)
{
	struct {
            class UWidget* WidgetToFind;
            bool AnimateScroll;
            EDescendantScrollDestination ScrollDestination;
	} params{ WidgetToFind, AnimateScroll, ScrollDestination };

    static auto fn = UObject::FindObject("/Script/UMG.ScrollBox:ScrollWidgetIntoView");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UScrollBox::ScrollToStart()
{
    static auto fn = UObject::FindObject("/Script/UMG.ScrollBox:ScrollToStart");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UScrollBox::ScrollToEnd()
{
    static auto fn = UObject::FindObject("/Script/UMG.ScrollBox:ScrollToEnd");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


float UScrollBox::GetViewOffsetFraction()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.ScrollBox:GetViewOffsetFraction");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UScrollBox::GetScrollOffset()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.ScrollBox:GetScrollOffset");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UImage::SetOpacity(float InOpacity)
{
	struct {
            float InOpacity;
	} params{ InOpacity };

    static auto fn = UObject::FindObject("/Script/UMG.Image:SetOpacity");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UImage::SetColorAndOpacity(struct FLinearColor InColorAndOpacity)
{
	struct {
            struct FLinearColor InColorAndOpacity;
	} params{ InColorAndOpacity };

    static auto fn = UObject::FindObject("/Script/UMG.Image:SetColorAndOpacity");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UImage::SetBrushTintColor(struct FSlateColor TintColor)
{
	struct {
            struct FSlateColor TintColor;
	} params{ TintColor };

    static auto fn = UObject::FindObject("/Script/UMG.Image:SetBrushTintColor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UImage::SetBrushSize(struct FVector2D DesiredSize)
{
	struct {
            struct FVector2D DesiredSize;
	} params{ DesiredSize };

    static auto fn = UObject::FindObject("/Script/UMG.Image:SetBrushSize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UImage::SetBrushFromTextureDynamic(class UTexture2DDynamic* Texture, bool bMatchSize)
{
	struct {
            class UTexture2DDynamic* Texture;
            bool bMatchSize;
	} params{ Texture, bMatchSize };

    static auto fn = UObject::FindObject("/Script/UMG.Image:SetBrushFromTextureDynamic");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UImage::SetBrushFromTexture(class UTexture2D* Texture, bool bMatchSize)
{
	struct {
            class UTexture2D* Texture;
            bool bMatchSize;
	} params{ Texture, bMatchSize };

    static auto fn = UObject::FindObject("/Script/UMG.Image:SetBrushFromTexture");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UImage::SetBrushFromSoftTexture(struct TSoftObjectPtr<struct UTexture2D*> SoftTexture, bool bMatchSize)
{
	struct {
            struct TSoftObjectPtr<struct UTexture2D*> SoftTexture;
            bool bMatchSize;
	} params{ SoftTexture, bMatchSize };

    static auto fn = UObject::FindObject("/Script/UMG.Image:SetBrushFromSoftTexture");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UImage::SetBrushFromSoftMaterial(struct TSoftObjectPtr<struct UMaterialInterface*> SoftMaterial)
{
	struct {
            struct TSoftObjectPtr<struct UMaterialInterface*> SoftMaterial;
	} params{ SoftMaterial };

    static auto fn = UObject::FindObject("/Script/UMG.Image:SetBrushFromSoftMaterial");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UImage::SetBrushFromMaterial(class UMaterialInterface* Material)
{
	struct {
            class UMaterialInterface* Material;
	} params{ Material };

    static auto fn = UObject::FindObject("/Script/UMG.Image:SetBrushFromMaterial");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UImage::SetBrushFromAtlasInterface(__int64/*InterfaceProperty*/ AtlasRegion, bool bMatchSize)
{
	struct {
            __int64/*InterfaceProperty*/ AtlasRegion;
            bool bMatchSize;
	} params{ AtlasRegion, bMatchSize };

    static auto fn = UObject::FindObject("/Script/UMG.Image:SetBrushFromAtlasInterface");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UImage::SetBrushFromAsset(class USlateBrushAsset* Asset)
{
	struct {
            class USlateBrushAsset* Asset;
	} params{ Asset };

    static auto fn = UObject::FindObject("/Script/UMG.Image:SetBrushFromAsset");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UImage::SetBrush(struct FSlateBrush InBrush)
{
	struct {
            struct FSlateBrush InBrush;
	} params{ InBrush };

    static auto fn = UObject::FindObject("/Script/UMG.Image:SetBrush");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


class UMaterialInstanceDynamic* UImage::GetDynamicMaterial()
{
	struct {
            class UMaterialInstanceDynamic* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Image:GetDynamicMaterial");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UListViewBase::ScrollToTop()
{
    static auto fn = UObject::FindObject("/Script/UMG.ListViewBase:ScrollToTop");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UListViewBase::ScrollToBottom()
{
    static auto fn = UObject::FindObject("/Script/UMG.ListViewBase:ScrollToBottom");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UListViewBase::RegenerateAllEntries()
{
    static auto fn = UObject::FindObject("/Script/UMG.ListViewBase:RegenerateAllEntries");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


TArray<class UUserWidget*> UListViewBase::GetDisplayedEntryWidgets()
{
	struct {
            TArray<class UUserWidget*> ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.ListViewBase:GetDisplayedEntryWidgets");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UListView::SetSelectionMode(char SelectionMode)
{
	struct {
            char SelectionMode;
	} params{ SelectionMode };

    static auto fn = UObject::FindObject("/Script/UMG.ListView:SetSelectionMode");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UListView::SetSelectedIndex(int Index)
{
	struct {
            int Index;
	} params{ Index };

    static auto fn = UObject::FindObject("/Script/UMG.ListView:SetSelectedIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UListView::ScrollIndexIntoView(int Index)
{
	struct {
            int Index;
	} params{ Index };

    static auto fn = UObject::FindObject("/Script/UMG.ListView:ScrollIndexIntoView");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UListView::NavigateToIndex(int Index)
{
	struct {
            int Index;
	} params{ Index };

    static auto fn = UObject::FindObject("/Script/UMG.ListView:NavigateToIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UListView::IsRefreshPending()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.ListView:IsRefreshPending");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


int UListView::GetNumItems()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.ListView:GetNumItems");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


TArray<class UObject*> UListView::GetListItems()
{
	struct {
            TArray<class UObject*> ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.ListView:GetListItems");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UObject* UListView::GetItemAt(int Index)
{
	struct {
            int Index;
            class UObject* ReturnValue;
	} params{ Index };

    static auto fn = UObject::FindObject("/Script/UMG.ListView:GetItemAt");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


int UListView::GetIndexForItem(class UObject* Item)
{
	struct {
            class UObject* Item;
            int ReturnValue;
	} params{ Item };

    static auto fn = UObject::FindObject("/Script/UMG.ListView:GetIndexForItem");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UListView::ClearListItems()
{
    static auto fn = UObject::FindObject("/Script/UMG.ListView:ClearListItems");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UListView::BP_SetSelectedItem(class UObject* Item)
{
	struct {
            class UObject* Item;
	} params{ Item };

    static auto fn = UObject::FindObject("/Script/UMG.ListView:BP_SetSelectedItem");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UListView::BP_SetListItems(TArray<class UObject*> InListItems)
{
	struct {
            TArray<class UObject*> InListItems;
	} params{ InListItems };

    static auto fn = UObject::FindObject("/Script/UMG.ListView:BP_SetListItems");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UListView::BP_SetItemSelection(class UObject* Item, bool bSelected)
{
	struct {
            class UObject* Item;
            bool bSelected;
	} params{ Item, bSelected };

    static auto fn = UObject::FindObject("/Script/UMG.ListView:BP_SetItemSelection");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UListView::BP_ScrollItemIntoView(class UObject* Item)
{
	struct {
            class UObject* Item;
	} params{ Item };

    static auto fn = UObject::FindObject("/Script/UMG.ListView:BP_ScrollItemIntoView");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UListView::BP_NavigateToItem(class UObject* Item)
{
	struct {
            class UObject* Item;
	} params{ Item };

    static auto fn = UObject::FindObject("/Script/UMG.ListView:BP_NavigateToItem");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UListView::BP_IsItemVisible(class UObject* Item)
{
	struct {
            class UObject* Item;
            bool ReturnValue;
	} params{ Item };

    static auto fn = UObject::FindObject("/Script/UMG.ListView:BP_IsItemVisible");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UListView::BP_GetSelectedItems(TArray<class UObject*> Items)
{
	struct {
            TArray<class UObject*> Items;
            bool ReturnValue;
	} params{ Items };

    static auto fn = UObject::FindObject("/Script/UMG.ListView:BP_GetSelectedItems");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


class UObject* UListView::BP_GetSelectedItem()
{
	struct {
            class UObject* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.ListView:BP_GetSelectedItem");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


int UListView::BP_GetNumItemsSelected()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.ListView:BP_GetNumItemsSelected");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UListView::BP_ClearSelection()
{
    static auto fn = UObject::FindObject("/Script/UMG.ListView:BP_ClearSelection");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UListView::BP_CancelScrollIntoView()
{
    static auto fn = UObject::FindObject("/Script/UMG.ListView:BP_CancelScrollIntoView");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UListView::AddItem(class UObject* Item)
{
	struct {
            class UObject* Item;
	} params{ Item };

    static auto fn = UObject::FindObject("/Script/UMG.ListView:AddItem");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UTileView::SetEntryWidth(float NewWidth)
{
	struct {
            float NewWidth;
	} params{ NewWidth };

    static auto fn = UObject::FindObject("/Script/UMG.TileView:SetEntryWidth");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTileView::SetEntryHeight(float NewHeight)
{
	struct {
            float NewHeight;
	} params{ NewHeight };

    static auto fn = UObject::FindObject("/Script/UMG.TileView:SetEntryHeight");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UTreeView::SetItemExpansion(class UObject* Item, bool bExpandItem)
{
	struct {
            class UObject* Item;
            bool bExpandItem;
	} params{ Item, bExpandItem };

    static auto fn = UObject::FindObject("/Script/UMG.TreeView:SetItemExpansion");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTreeView::ExpandAll()
{
    static auto fn = UObject::FindObject("/Script/UMG.TreeView:ExpandAll");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UTreeView::CollapseAll()
{
    static auto fn = UObject::FindObject("/Script/UMG.TreeView:CollapseAll");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

void UWidgetSwitcher::SetActiveWidgetIndex(int Index)
{
	struct {
            int Index;
	} params{ Index };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetSwitcher:SetActiveWidgetIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidgetSwitcher::SetActiveWidget(class UWidget* Widget)
{
	struct {
            class UWidget* Widget;
	} params{ Widget };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetSwitcher:SetActiveWidget");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


class UWidget* UWidgetSwitcher::GetWidgetAtIndex(int Index)
{
	struct {
            int Index;
            class UWidget* ReturnValue;
	} params{ Index };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetSwitcher:GetWidgetAtIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


int UWidgetSwitcher::GetNumWidgets()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetSwitcher:GetNumWidgets");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


int UWidgetSwitcher::GetActiveWidgetIndex()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetSwitcher:GetActiveWidgetIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UWidget* UWidgetSwitcher::GetActiveWidget()
{
	struct {
            class UWidget* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetSwitcher:GetActiveWidget");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

static class UAsyncTaskDownloadImage* UAsyncTaskDownloadImage::DownloadImage(struct FString URL)
{
	struct {
            struct FString URL;
            class UAsyncTaskDownloadImage* ReturnValue;
	} params{ URL };

    static auto fn = UObject::FindObject("/Script/UMG.AsyncTaskDownloadImage:DownloadImage");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UBackgroundBlur::SetVerticalAlignment(char InVerticalAlignment)
{
	struct {
            char InVerticalAlignment;
	} params{ InVerticalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.BackgroundBlur:SetVerticalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBackgroundBlur::SetPadding(struct FMargin InPadding)
{
	struct {
            struct FMargin InPadding;
	} params{ InPadding };

    static auto fn = UObject::FindObject("/Script/UMG.BackgroundBlur:SetPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBackgroundBlur::SetLowQualityFallbackBrush(struct FSlateBrush InBrush)
{
	struct {
            struct FSlateBrush InBrush;
	} params{ InBrush };

    static auto fn = UObject::FindObject("/Script/UMG.BackgroundBlur:SetLowQualityFallbackBrush");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBackgroundBlur::SetHorizontalAlignment(char InHorizontalAlignment)
{
	struct {
            char InHorizontalAlignment;
	} params{ InHorizontalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.BackgroundBlur:SetHorizontalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBackgroundBlur::SetBlurStrength(float InStrength)
{
	struct {
            float InStrength;
	} params{ InStrength };

    static auto fn = UObject::FindObject("/Script/UMG.BackgroundBlur:SetBlurStrength");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBackgroundBlur::SetBlurRadius(int InBlurRadius)
{
	struct {
            int InBlurRadius;
	} params{ InBlurRadius };

    static auto fn = UObject::FindObject("/Script/UMG.BackgroundBlur:SetBlurRadius");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBackgroundBlur::SetApplyAlphaToBlur(bool bInApplyAlphaToBlur)
{
	struct {
            bool bInApplyAlphaToBlur;
	} params{ bInApplyAlphaToBlur };

    static auto fn = UObject::FindObject("/Script/UMG.BackgroundBlur:SetApplyAlphaToBlur");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UBackgroundBlurSlot::SetVerticalAlignment(char InVerticalAlignment)
{
	struct {
            char InVerticalAlignment;
	} params{ InVerticalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.BackgroundBlurSlot:SetVerticalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBackgroundBlurSlot::SetPadding(struct FMargin InPadding)
{
	struct {
            struct FMargin InPadding;
	} params{ InPadding };

    static auto fn = UObject::FindObject("/Script/UMG.BackgroundBlurSlot:SetPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBackgroundBlurSlot::SetHorizontalAlignment(char InHorizontalAlignment)
{
	struct {
            char InHorizontalAlignment;
	} params{ InHorizontalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.BackgroundBlurSlot:SetHorizontalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

bool UBoolBinding::GetValue()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.BoolBinding:GetValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UBorderSlot::SetVerticalAlignment(char InVerticalAlignment)
{
	struct {
            char InVerticalAlignment;
	} params{ InVerticalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.BorderSlot:SetVerticalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBorderSlot::SetPadding(struct FMargin InPadding)
{
	struct {
            struct FMargin InPadding;
	} params{ InPadding };

    static auto fn = UObject::FindObject("/Script/UMG.BorderSlot:SetPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UBorderSlot::SetHorizontalAlignment(char InHorizontalAlignment)
{
	struct {
            char InHorizontalAlignment;
	} params{ InHorizontalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.BorderSlot:SetHorizontalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

struct FSlateBrush UBrushBinding::GetValue()
{
	struct {
            struct FSlateBrush ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.BrushBinding:GetValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UButtonSlot::SetVerticalAlignment(char InVerticalAlignment)
{
	struct {
            char InVerticalAlignment;
	} params{ InVerticalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.ButtonSlot:SetVerticalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UButtonSlot::SetPadding(struct FMargin InPadding)
{
	struct {
            struct FMargin InPadding;
	} params{ InPadding };

    static auto fn = UObject::FindObject("/Script/UMG.ButtonSlot:SetPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UButtonSlot::SetHorizontalAlignment(char InHorizontalAlignment)
{
	struct {
            char InHorizontalAlignment;
	} params{ InHorizontalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.ButtonSlot:SetHorizontalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

class UCanvasPanelSlot* UCanvasPanel::AddChildToCanvas(class UWidget* Content)
{
	struct {
            class UWidget* Content;
            class UCanvasPanelSlot* ReturnValue;
	} params{ Content };

    static auto fn = UObject::FindObject("/Script/UMG.CanvasPanel:AddChildToCanvas");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UCanvasPanelSlot::SetZOrder(int InZOrder)
{
	struct {
            int InZOrder;
	} params{ InZOrder };

    static auto fn = UObject::FindObject("/Script/UMG.CanvasPanelSlot:SetZOrder");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCanvasPanelSlot::SetSize(struct FVector2D InSize)
{
	struct {
            struct FVector2D InSize;
	} params{ InSize };

    static auto fn = UObject::FindObject("/Script/UMG.CanvasPanelSlot:SetSize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCanvasPanelSlot::SetPosition(struct FVector2D InPosition)
{
	struct {
            struct FVector2D InPosition;
	} params{ InPosition };

    static auto fn = UObject::FindObject("/Script/UMG.CanvasPanelSlot:SetPosition");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCanvasPanelSlot::SetOffsets(struct FMargin InOffset)
{
	struct {
            struct FMargin InOffset;
	} params{ InOffset };

    static auto fn = UObject::FindObject("/Script/UMG.CanvasPanelSlot:SetOffsets");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCanvasPanelSlot::SetMinimum(struct FVector2D InMinimumAnchors)
{
	struct {
            struct FVector2D InMinimumAnchors;
	} params{ InMinimumAnchors };

    static auto fn = UObject::FindObject("/Script/UMG.CanvasPanelSlot:SetMinimum");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCanvasPanelSlot::SetMaximum(struct FVector2D InMaximumAnchors)
{
	struct {
            struct FVector2D InMaximumAnchors;
	} params{ InMaximumAnchors };

    static auto fn = UObject::FindObject("/Script/UMG.CanvasPanelSlot:SetMaximum");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCanvasPanelSlot::SetLayout(struct FAnchorData InLayoutData)
{
	struct {
            struct FAnchorData InLayoutData;
	} params{ InLayoutData };

    static auto fn = UObject::FindObject("/Script/UMG.CanvasPanelSlot:SetLayout");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCanvasPanelSlot::SetAutoSize(bool InbAutoSize)
{
	struct {
            bool InbAutoSize;
	} params{ InbAutoSize };

    static auto fn = UObject::FindObject("/Script/UMG.CanvasPanelSlot:SetAutoSize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCanvasPanelSlot::SetAnchors(struct FAnchors InAnchors)
{
	struct {
            struct FAnchors InAnchors;
	} params{ InAnchors };

    static auto fn = UObject::FindObject("/Script/UMG.CanvasPanelSlot:SetAnchors");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCanvasPanelSlot::SetAlignment(struct FVector2D InAlignment)
{
	struct {
            struct FVector2D InAlignment;
	} params{ InAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.CanvasPanelSlot:SetAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


int UCanvasPanelSlot::GetZOrder()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.CanvasPanelSlot:GetZOrder");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FVector2D UCanvasPanelSlot::GetSize()
{
	struct {
            struct FVector2D ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.CanvasPanelSlot:GetSize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FVector2D UCanvasPanelSlot::GetPosition()
{
	struct {
            struct FVector2D ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.CanvasPanelSlot:GetPosition");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FMargin UCanvasPanelSlot::GetOffsets()
{
	struct {
            struct FMargin ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.CanvasPanelSlot:GetOffsets");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FAnchorData UCanvasPanelSlot::GetLayout()
{
	struct {
            struct FAnchorData ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.CanvasPanelSlot:GetLayout");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UCanvasPanelSlot::GetAutoSize()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.CanvasPanelSlot:GetAutoSize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FAnchors UCanvasPanelSlot::GetAnchors()
{
	struct {
            struct FAnchors ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.CanvasPanelSlot:GetAnchors");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FVector2D UCanvasPanelSlot::GetAlignment()
{
	struct {
            struct FVector2D ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.CanvasPanelSlot:GetAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UCheckBox::SetIsChecked(bool InIsChecked)
{
	struct {
            bool InIsChecked;
	} params{ InIsChecked };

    static auto fn = UObject::FindObject("/Script/UMG.CheckBox:SetIsChecked");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCheckBox::SetCheckedState(ECheckBoxState InCheckedState)
{
	struct {
            ECheckBoxState InCheckedState;
	} params{ InCheckedState };

    static auto fn = UObject::FindObject("/Script/UMG.CheckBox:SetCheckedState");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UCheckBox::IsPressed()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.CheckBox:IsPressed");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UCheckBox::IsChecked()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.CheckBox:IsChecked");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


ECheckBoxState UCheckBox::GetCheckedState()
{
	struct {
            ECheckBoxState ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.CheckBox:GetCheckedState");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

ECheckBoxState UCheckedStateBinding::GetValue()
{
	struct {
            ECheckBoxState ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.CheckedStateBinding:GetValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UCircularThrobber::SetRadius(float InRadius)
{
	struct {
            float InRadius;
	} params{ InRadius };

    static auto fn = UObject::FindObject("/Script/UMG.CircularThrobber:SetRadius");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCircularThrobber::SetPeriod(float InPeriod)
{
	struct {
            float InPeriod;
	} params{ InPeriod };

    static auto fn = UObject::FindObject("/Script/UMG.CircularThrobber:SetPeriod");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UCircularThrobber::SetNumberOfPieces(int InNumberOfPieces)
{
	struct {
            int InNumberOfPieces;
	} params{ InNumberOfPieces };

    static auto fn = UObject::FindObject("/Script/UMG.CircularThrobber:SetNumberOfPieces");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

struct FSlateColor UColorBinding::GetSlateValue()
{
	struct {
            struct FSlateColor ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.ColorBinding:GetSlateValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FLinearColor UColorBinding::GetLinearValue()
{
	struct {
            struct FLinearColor ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.ColorBinding:GetLinearValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UComboBoxString::SetSelectedOption(struct FString Option)
{
	struct {
            struct FString Option;
	} params{ Option };

    static auto fn = UObject::FindObject("/Script/UMG.ComboBoxString:SetSelectedOption");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UComboBoxString::RemoveOption(struct FString Option)
{
	struct {
            struct FString Option;
            bool ReturnValue;
	} params{ Option };

    static auto fn = UObject::FindObject("/Script/UMG.ComboBoxString:RemoveOption");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UComboBoxString::RefreshOptions()
{
    static auto fn = UObject::FindObject("/Script/UMG.ComboBoxString:RefreshOptions");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


struct FString UComboBoxString::GetSelectedOption()
{
	struct {
            struct FString ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.ComboBoxString:GetSelectedOption");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


int UComboBoxString::GetOptionCount()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.ComboBoxString:GetOptionCount");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FString UComboBoxString::GetOptionAtIndex(int Index)
{
	struct {
            int Index;
            struct FString ReturnValue;
	} params{ Index };

    static auto fn = UObject::FindObject("/Script/UMG.ComboBoxString:GetOptionAtIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


int UComboBoxString::FindOptionIndex(struct FString Option)
{
	struct {
            struct FString Option;
            int ReturnValue;
	} params{ Option };

    static auto fn = UObject::FindObject("/Script/UMG.ComboBoxString:FindOptionIndex");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UComboBoxString::ClearSelection()
{
    static auto fn = UObject::FindObject("/Script/UMG.ComboBoxString:ClearSelection");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UComboBoxString::ClearOptions()
{
    static auto fn = UObject::FindObject("/Script/UMG.ComboBoxString:ClearOptions");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UComboBoxString::AddOption(struct FString Option)
{
	struct {
            struct FString Option;
	} params{ Option };

    static auto fn = UObject::FindObject("/Script/UMG.ComboBoxString:AddOption");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UDragDropOperation::Drop(struct FPointerEvent PointerEvent)
{
	struct {
            struct FPointerEvent PointerEvent;
	} params{ PointerEvent };

    static auto fn = UObject::FindObject("/Script/UMG.DragDropOperation:Drop");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UDragDropOperation::Dragged(struct FPointerEvent PointerEvent)
{
	struct {
            struct FPointerEvent PointerEvent;
	} params{ PointerEvent };

    static auto fn = UObject::FindObject("/Script/UMG.DragDropOperation:Dragged");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UDragDropOperation::DragCancelled(struct FPointerEvent PointerEvent)
{
	struct {
            struct FPointerEvent PointerEvent;
	} params{ PointerEvent };

    static auto fn = UObject::FindObject("/Script/UMG.DragDropOperation:DragCancelled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UDynamicEntryBox::SetEntrySpacing(struct FVector2D InEntrySpacing)
{
	struct {
            struct FVector2D InEntrySpacing;
	} params{ InEntrySpacing };

    static auto fn = UObject::FindObject("/Script/UMG.DynamicEntryBox:SetEntrySpacing");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UDynamicEntryBox::Reset(bool bDeleteWidgets)
{
	struct {
            bool bDeleteWidgets;
	} params{ bDeleteWidgets };

    static auto fn = UObject::FindObject("/Script/UMG.DynamicEntryBox:Reset");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UDynamicEntryBox::RemoveEntry(class UUserWidget* EntryWidget)
{
	struct {
            class UUserWidget* EntryWidget;
	} params{ EntryWidget };

    static auto fn = UObject::FindObject("/Script/UMG.DynamicEntryBox:RemoveEntry");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


int UDynamicEntryBox::GetNumEntries()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.DynamicEntryBox:GetNumEntries");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


TArray<class UUserWidget*> UDynamicEntryBox::GetAllEntries()
{
	struct {
            TArray<class UUserWidget*> ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.DynamicEntryBox:GetAllEntries");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UUserWidget* UDynamicEntryBox::BP_CreateEntryOfClass(class UUserWidget* EntryClass)
{
	struct {
            class UUserWidget* EntryClass;
            class UUserWidget* ReturnValue;
	} params{ EntryClass };

    static auto fn = UObject::FindObject("/Script/UMG.DynamicEntryBox:BP_CreateEntryOfClass");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


class UUserWidget* UDynamicEntryBox::BP_CreateEntry()
{
	struct {
            class UUserWidget* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.DynamicEntryBox:BP_CreateEntry");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UEditableText::SetText(struct FText InText)
{
	struct {
            struct FText InText;
	} params{ InText };

    static auto fn = UObject::FindObject("/Script/UMG.EditableText:SetText");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UEditableText::SetIsReadOnly(bool InbIsReadyOnly)
{
	struct {
            bool InbIsReadyOnly;
	} params{ InbIsReadyOnly };

    static auto fn = UObject::FindObject("/Script/UMG.EditableText:SetIsReadOnly");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UEditableText::SetIsPassword(bool InbIsPassword)
{
	struct {
            bool InbIsPassword;
	} params{ InbIsPassword };

    static auto fn = UObject::FindObject("/Script/UMG.EditableText:SetIsPassword");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UEditableText::SetHintText(struct FText InHintText)
{
	struct {
            struct FText InHintText;
	} params{ InHintText };

    static auto fn = UObject::FindObject("/Script/UMG.EditableText:SetHintText");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


struct FText UEditableText::GetText()
{
	struct {
            struct FText ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.EditableText:GetText");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UEditableTextBox::SetText(struct FText InText)
{
	struct {
            struct FText InText;
	} params{ InText };

    static auto fn = UObject::FindObject("/Script/UMG.EditableTextBox:SetText");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UEditableTextBox::SetIsReadOnly(bool bReadOnly)
{
	struct {
            bool bReadOnly;
	} params{ bReadOnly };

    static auto fn = UObject::FindObject("/Script/UMG.EditableTextBox:SetIsReadOnly");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UEditableTextBox::SetIsPassword(bool bIsPassword)
{
	struct {
            bool bIsPassword;
	} params{ bIsPassword };

    static auto fn = UObject::FindObject("/Script/UMG.EditableTextBox:SetIsPassword");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UEditableTextBox::SetHintText(struct FText InText)
{
	struct {
            struct FText InText;
	} params{ InText };

    static auto fn = UObject::FindObject("/Script/UMG.EditableTextBox:SetHintText");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UEditableTextBox::SetError(struct FText InError)
{
	struct {
            struct FText InError;
	} params{ InError };

    static auto fn = UObject::FindObject("/Script/UMG.EditableTextBox:SetError");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UEditableTextBox::HasError()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.EditableTextBox:HasError");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FText UEditableTextBox::GetText()
{
	struct {
            struct FText ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.EditableTextBox:GetText");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UEditableTextBox::ClearError()
{
    static auto fn = UObject::FindObject("/Script/UMG.EditableTextBox:ClearError");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

void UExpandableArea::SetIsExpanded_Animated(bool IsExpanded)
{
	struct {
            bool IsExpanded;
	} params{ IsExpanded };

    static auto fn = UObject::FindObject("/Script/UMG.ExpandableArea:SetIsExpanded_Animated");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UExpandableArea::SetIsExpanded(bool IsExpanded)
{
	struct {
            bool IsExpanded;
	} params{ IsExpanded };

    static auto fn = UObject::FindObject("/Script/UMG.ExpandableArea:SetIsExpanded");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UExpandableArea::GetIsExpanded()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.ExpandableArea:GetIsExpanded");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

float UFloatBinding::GetValue()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.FloatBinding:GetValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UGridPanel::SetRowFill(int ColumnIndex, float Coefficient)
{
	struct {
            int ColumnIndex;
            float Coefficient;
	} params{ ColumnIndex, Coefficient };

    static auto fn = UObject::FindObject("/Script/UMG.GridPanel:SetRowFill");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGridPanel::SetColumnFill(int ColumnIndex, float Coefficient)
{
	struct {
            int ColumnIndex;
            float Coefficient;
	} params{ ColumnIndex, Coefficient };

    static auto fn = UObject::FindObject("/Script/UMG.GridPanel:SetColumnFill");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


class UGridSlot* UGridPanel::AddChildToGrid(class UWidget* Content)
{
	struct {
            class UWidget* Content;
            class UGridSlot* ReturnValue;
	} params{ Content };

    static auto fn = UObject::FindObject("/Script/UMG.GridPanel:AddChildToGrid");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UGridSlot::SetVerticalAlignment(char InVerticalAlignment)
{
	struct {
            char InVerticalAlignment;
	} params{ InVerticalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.GridSlot:SetVerticalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGridSlot::SetRowSpan(int InRowSpan)
{
	struct {
            int InRowSpan;
	} params{ InRowSpan };

    static auto fn = UObject::FindObject("/Script/UMG.GridSlot:SetRowSpan");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGridSlot::SetRow(int InRow)
{
	struct {
            int InRow;
	} params{ InRow };

    static auto fn = UObject::FindObject("/Script/UMG.GridSlot:SetRow");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGridSlot::SetPadding(struct FMargin InPadding)
{
	struct {
            struct FMargin InPadding;
	} params{ InPadding };

    static auto fn = UObject::FindObject("/Script/UMG.GridSlot:SetPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGridSlot::SetLayer(int InLayer)
{
	struct {
            int InLayer;
	} params{ InLayer };

    static auto fn = UObject::FindObject("/Script/UMG.GridSlot:SetLayer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGridSlot::SetHorizontalAlignment(char InHorizontalAlignment)
{
	struct {
            char InHorizontalAlignment;
	} params{ InHorizontalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.GridSlot:SetHorizontalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGridSlot::SetColumnSpan(int InColumnSpan)
{
	struct {
            int InColumnSpan;
	} params{ InColumnSpan };

    static auto fn = UObject::FindObject("/Script/UMG.GridSlot:SetColumnSpan");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UGridSlot::SetColumn(int InColumn)
{
	struct {
            int InColumn;
	} params{ InColumn };

    static auto fn = UObject::FindObject("/Script/UMG.GridSlot:SetColumn");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

class UHorizontalBoxSlot* UHorizontalBox::AddChildToHorizontalBox(class UWidget* Content)
{
	struct {
            class UWidget* Content;
            class UHorizontalBoxSlot* ReturnValue;
	} params{ Content };

    static auto fn = UObject::FindObject("/Script/UMG.HorizontalBox:AddChildToHorizontalBox");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UHorizontalBoxSlot::SetVerticalAlignment(char InVerticalAlignment)
{
	struct {
            char InVerticalAlignment;
	} params{ InVerticalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.HorizontalBoxSlot:SetVerticalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UHorizontalBoxSlot::SetSize(struct FSlateChildSize InSize)
{
	struct {
            struct FSlateChildSize InSize;
	} params{ InSize };

    static auto fn = UObject::FindObject("/Script/UMG.HorizontalBoxSlot:SetSize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UHorizontalBoxSlot::SetPadding(struct FMargin InPadding)
{
	struct {
            struct FMargin InPadding;
	} params{ InPadding };

    static auto fn = UObject::FindObject("/Script/UMG.HorizontalBoxSlot:SetPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UHorizontalBoxSlot::SetHorizontalAlignment(char InHorizontalAlignment)
{
	struct {
            char InHorizontalAlignment;
	} params{ InHorizontalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.HorizontalBoxSlot:SetHorizontalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UInputKeySelector::SetTextBlockVisibility(ESlateVisibility InVisibility)
{
	struct {
            ESlateVisibility InVisibility;
	} params{ InVisibility };

    static auto fn = UObject::FindObject("/Script/UMG.InputKeySelector:SetTextBlockVisibility");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UInputKeySelector::SetSelectedKey(struct FInputChord InSelectedKey)
{
	struct {
            struct FInputChord InSelectedKey;
	} params{ InSelectedKey };

    static auto fn = UObject::FindObject("/Script/UMG.InputKeySelector:SetSelectedKey");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UInputKeySelector::SetNoKeySpecifiedText(struct FText InNoKeySpecifiedText)
{
	struct {
            struct FText InNoKeySpecifiedText;
	} params{ InNoKeySpecifiedText };

    static auto fn = UObject::FindObject("/Script/UMG.InputKeySelector:SetNoKeySpecifiedText");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UInputKeySelector::SetKeySelectionText(struct FText InKeySelectionText)
{
	struct {
            struct FText InKeySelectionText;
	} params{ InKeySelectionText };

    static auto fn = UObject::FindObject("/Script/UMG.InputKeySelector:SetKeySelectionText");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UInputKeySelector::SetEscapeKeys(TArray<struct FKey> InKeys)
{
	struct {
            TArray<struct FKey> InKeys;
	} params{ InKeys };

    static auto fn = UObject::FindObject("/Script/UMG.InputKeySelector:SetEscapeKeys");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UInputKeySelector::SetAllowModifierKeys(bool bInAllowModifierKeys)
{
	struct {
            bool bInAllowModifierKeys;
	} params{ bInAllowModifierKeys };

    static auto fn = UObject::FindObject("/Script/UMG.InputKeySelector:SetAllowModifierKeys");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UInputKeySelector::SetAllowGamepadKeys(bool bInAllowGamepadKeys)
{
	struct {
            bool bInAllowGamepadKeys;
	} params{ bInAllowGamepadKeys };

    static auto fn = UObject::FindObject("/Script/UMG.InputKeySelector:SetAllowGamepadKeys");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UInputKeySelector::GetIsSelectingKey()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.InputKeySelector:GetIsSelectingKey");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

int UInt32Binding::GetValue()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Int32Binding:GetValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UInvalidationBox::SetCanCache(bool CanCache)
{
	struct {
            bool CanCache;
	} params{ CanCache };

    static auto fn = UObject::FindObject("/Script/UMG.InvalidationBox:SetCanCache");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UInvalidationBox::InvalidateCache()
{
    static auto fn = UObject::FindObject("/Script/UMG.InvalidationBox:InvalidateCache");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


bool UInvalidationBox::GetCanCache()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.InvalidationBox:GetCanCache");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

bool UNativeUserListEntry::IsListItemSelected()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.NativeUserListEntry:IsListItemSelected");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UNativeUserListEntry::IsListItemExpanded()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.NativeUserListEntry:IsListItemExpanded");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UListViewBase* UNativeUserListEntry::GetOwningListView()
{
	struct {
            class UListViewBase* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.NativeUserListEntry:GetOwningListView");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UUserListEntry::BP_OnItemSelectionChanged(bool bIsSelected)
{
	struct {
            bool bIsSelected;
	} params{ bIsSelected };

    static auto fn = UObject::FindObject("/Script/UMG.UserListEntry:BP_OnItemSelectionChanged");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserListEntry::BP_OnItemExpansionChanged(bool bIsExpanded)
{
	struct {
            bool bIsExpanded;
	} params{ bIsExpanded };

    static auto fn = UObject::FindObject("/Script/UMG.UserListEntry:BP_OnItemExpansionChanged");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUserListEntry::BP_OnEntryReleased()
{
    static auto fn = UObject::FindObject("/Script/UMG.UserListEntry:BP_OnEntryReleased");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

void UUserObjectListEntry::OnListItemObjectSet(class UObject* ListItemObject)
{
	struct {
            class UObject* ListItemObject;
	} params{ ListItemObject };

    static auto fn = UObject::FindObject("/Script/UMG.UserObjectListEntry:OnListItemObjectSet");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


class UObject* UUserObjectListEntry::GetListItemObject()
{
	struct {
            class UObject* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.UserObjectListEntry:GetListItemObject");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UMenuAnchor::ToggleOpen(bool bFocusOnOpen)
{
	struct {
            bool bFocusOnOpen;
	} params{ bFocusOnOpen };

    static auto fn = UObject::FindObject("/Script/UMG.MenuAnchor:ToggleOpen");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UMenuAnchor::ShouldOpenDueToClick()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.MenuAnchor:ShouldOpenDueToClick");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UMenuAnchor::Open(bool bFocusMenu)
{
	struct {
            bool bFocusMenu;
	} params{ bFocusMenu };

    static auto fn = UObject::FindObject("/Script/UMG.MenuAnchor:Open");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UMenuAnchor::IsOpen()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.MenuAnchor:IsOpen");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UMenuAnchor::HasOpenSubMenus()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.MenuAnchor:HasOpenSubMenus");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FVector2D UMenuAnchor::GetMenuPosition()
{
	struct {
            struct FVector2D ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.MenuAnchor:GetMenuPosition");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UMenuAnchor::Close()
{
    static auto fn = UObject::FindObject("/Script/UMG.MenuAnchor:Close");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

char UMouseCursorBinding::GetValue()
{
	struct {
            char ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.MouseCursorBinding:GetValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UMultiLineEditableText::SetText(struct FText InText)
{
	struct {
            struct FText InText;
	} params{ InText };

    static auto fn = UObject::FindObject("/Script/UMG.MultiLineEditableText:SetText");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMultiLineEditableText::SetIsReadOnly(bool bReadOnly)
{
	struct {
            bool bReadOnly;
	} params{ bReadOnly };

    static auto fn = UObject::FindObject("/Script/UMG.MultiLineEditableText:SetIsReadOnly");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


struct FText UMultiLineEditableText::GetText()
{
	struct {
            struct FText ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.MultiLineEditableText:GetText");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UMultiLineEditableTextBox::SetText(struct FText InText)
{
	struct {
            struct FText InText;
	} params{ InText };

    static auto fn = UObject::FindObject("/Script/UMG.MultiLineEditableTextBox:SetText");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMultiLineEditableTextBox::SetIsReadOnly(bool bReadOnly)
{
	struct {
            bool bReadOnly;
	} params{ bReadOnly };

    static auto fn = UObject::FindObject("/Script/UMG.MultiLineEditableTextBox:SetIsReadOnly");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMultiLineEditableTextBox::SetError(struct FText InError)
{
	struct {
            struct FText InError;
	} params{ InError };

    static auto fn = UObject::FindObject("/Script/UMG.MultiLineEditableTextBox:SetError");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


struct FText UMultiLineEditableTextBox::GetText()
{
	struct {
            struct FText ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.MultiLineEditableTextBox:GetText");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

class UOverlaySlot* UOverlay::AddChildToOverlay(class UWidget* Content)
{
	struct {
            class UWidget* Content;
            class UOverlaySlot* ReturnValue;
	} params{ Content };

    static auto fn = UObject::FindObject("/Script/UMG.Overlay:AddChildToOverlay");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UOverlaySlot::SetVerticalAlignment(char InVerticalAlignment)
{
	struct {
            char InVerticalAlignment;
	} params{ InVerticalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.OverlaySlot:SetVerticalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UOverlaySlot::SetPadding(struct FMargin InPadding)
{
	struct {
            struct FMargin InPadding;
	} params{ InPadding };

    static auto fn = UObject::FindObject("/Script/UMG.OverlaySlot:SetPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UOverlaySlot::SetHorizontalAlignment(char InHorizontalAlignment)
{
	struct {
            char InHorizontalAlignment;
	} params{ InHorizontalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.OverlaySlot:SetHorizontalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UProgressBar::SetPercent(float InPercent)
{
	struct {
            float InPercent;
	} params{ InPercent };

    static auto fn = UObject::FindObject("/Script/UMG.ProgressBar:SetPercent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UProgressBar::SetIsMarquee(bool InbIsMarquee)
{
	struct {
            bool InbIsMarquee;
	} params{ InbIsMarquee };

    static auto fn = UObject::FindObject("/Script/UMG.ProgressBar:SetIsMarquee");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UProgressBar::SetFillColorAndOpacity(struct FLinearColor InColor)
{
	struct {
            struct FLinearColor InColor;
	} params{ InColor };

    static auto fn = UObject::FindObject("/Script/UMG.ProgressBar:SetFillColorAndOpacity");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void URetainerBox::SetTextureParameter(FName TextureParameter)
{
	struct {
            FName TextureParameter;
	} params{ TextureParameter };

    static auto fn = UObject::FindObject("/Script/UMG.RetainerBox:SetTextureParameter");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void URetainerBox::SetRenderingPhase(int RenderPhase, int TotalPhases)
{
	struct {
            int RenderPhase;
            int TotalPhases;
	} params{ RenderPhase, TotalPhases };

    static auto fn = UObject::FindObject("/Script/UMG.RetainerBox:SetRenderingPhase");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void URetainerBox::SetEffectMaterial(class UMaterialInterface* EffectMaterial)
{
	struct {
            class UMaterialInterface* EffectMaterial;
	} params{ EffectMaterial };

    static auto fn = UObject::FindObject("/Script/UMG.RetainerBox:SetEffectMaterial");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void URetainerBox::RequestRender()
{
    static auto fn = UObject::FindObject("/Script/UMG.RetainerBox:RequestRender");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


class UMaterialInstanceDynamic* URetainerBox::GetEffectMaterial()
{
	struct {
            class UMaterialInstanceDynamic* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.RetainerBox:GetEffectMaterial");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void URichTextBlock::SetText(struct FText InText)
{
	struct {
            struct FText InText;
	} params{ InText };

    static auto fn = UObject::FindObject("/Script/UMG.RichTextBlock:SetText");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


class URichTextBlockDecorator* URichTextBlock::GetDecoratorByClass(class URichTextBlockDecorator* DecoratorClass)
{
	struct {
            class URichTextBlockDecorator* DecoratorClass;
            class URichTextBlockDecorator* ReturnValue;
	} params{ DecoratorClass };

    static auto fn = UObject::FindObject("/Script/UMG.RichTextBlock:GetDecoratorByClass");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void USafeZone::SetSidesToPad(bool InPadLeft, bool InPadRight, bool InPadTop, bool InPadBottom)
{
	struct {
            bool InPadLeft;
            bool InPadRight;
            bool InPadTop;
            bool InPadBottom;
	} params{ InPadLeft, InPadRight, InPadTop, InPadBottom };

    static auto fn = UObject::FindObject("/Script/UMG.SafeZone:SetSidesToPad");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UScaleBox::SetUserSpecifiedScale(float InUserSpecifiedScale)
{
	struct {
            float InUserSpecifiedScale;
	} params{ InUserSpecifiedScale };

    static auto fn = UObject::FindObject("/Script/UMG.ScaleBox:SetUserSpecifiedScale");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UScaleBox::SetStretchDirection(char InStretchDirection)
{
	struct {
            char InStretchDirection;
	} params{ InStretchDirection };

    static auto fn = UObject::FindObject("/Script/UMG.ScaleBox:SetStretchDirection");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UScaleBox::SetStretch(char InStretch)
{
	struct {
            char InStretch;
	} params{ InStretch };

    static auto fn = UObject::FindObject("/Script/UMG.ScaleBox:SetStretch");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UScaleBox::SetIgnoreInheritedScale(bool bInIgnoreInheritedScale)
{
	struct {
            bool bInIgnoreInheritedScale;
	} params{ bInIgnoreInheritedScale };

    static auto fn = UObject::FindObject("/Script/UMG.ScaleBox:SetIgnoreInheritedScale");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UScaleBoxSlot::SetVerticalAlignment(char InVerticalAlignment)
{
	struct {
            char InVerticalAlignment;
	} params{ InVerticalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.ScaleBoxSlot:SetVerticalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UScaleBoxSlot::SetPadding(struct FMargin InPadding)
{
	struct {
            struct FMargin InPadding;
	} params{ InPadding };

    static auto fn = UObject::FindObject("/Script/UMG.ScaleBoxSlot:SetPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UScaleBoxSlot::SetHorizontalAlignment(char InHorizontalAlignment)
{
	struct {
            char InHorizontalAlignment;
	} params{ InHorizontalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.ScaleBoxSlot:SetHorizontalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UScrollBar::SetState(float InOffsetFraction, float InThumbSizeFraction)
{
	struct {
            float InOffsetFraction;
            float InThumbSizeFraction;
	} params{ InOffsetFraction, InThumbSizeFraction };

    static auto fn = UObject::FindObject("/Script/UMG.ScrollBar:SetState");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UScrollBoxSlot::SetVerticalAlignment(char InVerticalAlignment)
{
	struct {
            char InVerticalAlignment;
	} params{ InVerticalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.ScrollBoxSlot:SetVerticalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UScrollBoxSlot::SetPadding(struct FMargin InPadding)
{
	struct {
            struct FMargin InPadding;
	} params{ InPadding };

    static auto fn = UObject::FindObject("/Script/UMG.ScrollBoxSlot:SetPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UScrollBoxSlot::SetHorizontalAlignment(char InHorizontalAlignment)
{
	struct {
            char InHorizontalAlignment;
	} params{ InHorizontalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.ScrollBoxSlot:SetHorizontalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void USizeBox::SetWidthOverride(float InWidthOverride)
{
	struct {
            float InWidthOverride;
	} params{ InWidthOverride };

    static auto fn = UObject::FindObject("/Script/UMG.SizeBox:SetWidthOverride");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USizeBox::SetMinDesiredWidth(float InMinDesiredWidth)
{
	struct {
            float InMinDesiredWidth;
	} params{ InMinDesiredWidth };

    static auto fn = UObject::FindObject("/Script/UMG.SizeBox:SetMinDesiredWidth");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USizeBox::SetMinDesiredHeight(float InMinDesiredHeight)
{
	struct {
            float InMinDesiredHeight;
	} params{ InMinDesiredHeight };

    static auto fn = UObject::FindObject("/Script/UMG.SizeBox:SetMinDesiredHeight");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USizeBox::SetMaxDesiredWidth(float InMaxDesiredWidth)
{
	struct {
            float InMaxDesiredWidth;
	} params{ InMaxDesiredWidth };

    static auto fn = UObject::FindObject("/Script/UMG.SizeBox:SetMaxDesiredWidth");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USizeBox::SetMaxDesiredHeight(float InMaxDesiredHeight)
{
	struct {
            float InMaxDesiredHeight;
	} params{ InMaxDesiredHeight };

    static auto fn = UObject::FindObject("/Script/UMG.SizeBox:SetMaxDesiredHeight");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USizeBox::SetMaxAspectRatio(float InMaxAspectRatio)
{
	struct {
            float InMaxAspectRatio;
	} params{ InMaxAspectRatio };

    static auto fn = UObject::FindObject("/Script/UMG.SizeBox:SetMaxAspectRatio");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USizeBox::SetHeightOverride(float InHeightOverride)
{
	struct {
            float InHeightOverride;
	} params{ InHeightOverride };

    static auto fn = UObject::FindObject("/Script/UMG.SizeBox:SetHeightOverride");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USizeBox::ClearWidthOverride()
{
    static auto fn = UObject::FindObject("/Script/UMG.SizeBox:ClearWidthOverride");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void USizeBox::ClearMinDesiredWidth()
{
    static auto fn = UObject::FindObject("/Script/UMG.SizeBox:ClearMinDesiredWidth");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void USizeBox::ClearMinDesiredHeight()
{
    static auto fn = UObject::FindObject("/Script/UMG.SizeBox:ClearMinDesiredHeight");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void USizeBox::ClearMaxDesiredWidth()
{
    static auto fn = UObject::FindObject("/Script/UMG.SizeBox:ClearMaxDesiredWidth");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void USizeBox::ClearMaxDesiredHeight()
{
    static auto fn = UObject::FindObject("/Script/UMG.SizeBox:ClearMaxDesiredHeight");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void USizeBox::ClearMaxAspectRatio()
{
    static auto fn = UObject::FindObject("/Script/UMG.SizeBox:ClearMaxAspectRatio");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void USizeBox::ClearHeightOverride()
{
    static auto fn = UObject::FindObject("/Script/UMG.SizeBox:ClearHeightOverride");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

void USizeBoxSlot::SetVerticalAlignment(char InVerticalAlignment)
{
	struct {
            char InVerticalAlignment;
	} params{ InVerticalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.SizeBoxSlot:SetVerticalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USizeBoxSlot::SetPadding(struct FMargin InPadding)
{
	struct {
            struct FMargin InPadding;
	} params{ InPadding };

    static auto fn = UObject::FindObject("/Script/UMG.SizeBoxSlot:SetPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USizeBoxSlot::SetHorizontalAlignment(char InHorizontalAlignment)
{
	struct {
            char InHorizontalAlignment;
	} params{ InHorizontalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.SizeBoxSlot:SetHorizontalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

static struct FVector2D USlateBlueprintLibrary::TransformVectorLocalToAbsolute(struct FGeometry Geometry, struct FVector2D LocalVector)
{
	struct {
            struct FGeometry Geometry;
            struct FVector2D LocalVector;
            struct FVector2D ReturnValue;
	} params{ Geometry, LocalVector };

    static auto fn = UObject::FindObject("/Script/UMG.SlateBlueprintLibrary:TransformVectorLocalToAbsolute");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FVector2D USlateBlueprintLibrary::TransformVectorAbsoluteToLocal(struct FGeometry Geometry, struct FVector2D AbsoluteVector)
{
	struct {
            struct FGeometry Geometry;
            struct FVector2D AbsoluteVector;
            struct FVector2D ReturnValue;
	} params{ Geometry, AbsoluteVector };

    static auto fn = UObject::FindObject("/Script/UMG.SlateBlueprintLibrary:TransformVectorAbsoluteToLocal");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static float USlateBlueprintLibrary::TransformScalarLocalToAbsolute(struct FGeometry Geometry, float LocalScalar)
{
	struct {
            struct FGeometry Geometry;
            float LocalScalar;
            float ReturnValue;
	} params{ Geometry, LocalScalar };

    static auto fn = UObject::FindObject("/Script/UMG.SlateBlueprintLibrary:TransformScalarLocalToAbsolute");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static float USlateBlueprintLibrary::TransformScalarAbsoluteToLocal(struct FGeometry Geometry, float AbsoluteScalar)
{
	struct {
            struct FGeometry Geometry;
            float AbsoluteScalar;
            float ReturnValue;
	} params{ Geometry, AbsoluteScalar };

    static auto fn = UObject::FindObject("/Script/UMG.SlateBlueprintLibrary:TransformScalarAbsoluteToLocal");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void USlateBlueprintLibrary::ScreenToWidgetLocal(class UObject* WorldContextObject, struct FGeometry Geometry, struct FVector2D ScreenPosition, struct FVector2D LocalCoordinate)
{
	struct {
            class UObject* WorldContextObject;
            struct FGeometry Geometry;
            struct FVector2D ScreenPosition;
            struct FVector2D LocalCoordinate;            void ReturnValue;
	} params{ WorldContextObject, Geometry, ScreenPosition, LocalCoordinate };

    static auto fn = UObject::FindObject("/Script/UMG.SlateBlueprintLibrary:ScreenToWidgetLocal");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void USlateBlueprintLibrary::ScreenToWidgetAbsolute(class UObject* WorldContextObject, struct FVector2D ScreenPosition, struct FVector2D AbsoluteCoordinate)
{
	struct {
            class UObject* WorldContextObject;
            struct FVector2D ScreenPosition;
            struct FVector2D AbsoluteCoordinate;            void ReturnValue;
	} params{ WorldContextObject, ScreenPosition, AbsoluteCoordinate };

    static auto fn = UObject::FindObject("/Script/UMG.SlateBlueprintLibrary:ScreenToWidgetAbsolute");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void USlateBlueprintLibrary::ScreenToViewport(class UObject* WorldContextObject, struct FVector2D ScreenPosition, struct FVector2D ViewportPosition)
{
	struct {
            class UObject* WorldContextObject;
            struct FVector2D ScreenPosition;
            struct FVector2D ViewportPosition;            void ReturnValue;
	} params{ WorldContextObject, ScreenPosition, ViewportPosition };

    static auto fn = UObject::FindObject("/Script/UMG.SlateBlueprintLibrary:ScreenToViewport");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void USlateBlueprintLibrary::LocalToViewport(class UObject* WorldContextObject, struct FGeometry Geometry, struct FVector2D LocalCoordinate, struct FVector2D PixelPosition, struct FVector2D ViewportPosition)
{
	struct {
            class UObject* WorldContextObject;
            struct FGeometry Geometry;
            struct FVector2D LocalCoordinate;
            struct FVector2D PixelPosition;
            struct FVector2D ViewportPosition;            void ReturnValue;
	} params{ WorldContextObject, Geometry, LocalCoordinate, PixelPosition, ViewportPosition };

    static auto fn = UObject::FindObject("/Script/UMG.SlateBlueprintLibrary:LocalToViewport");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FVector2D USlateBlueprintLibrary::LocalToAbsolute(struct FGeometry Geometry, struct FVector2D LocalCoordinate)
{
	struct {
            struct FGeometry Geometry;
            struct FVector2D LocalCoordinate;
            struct FVector2D ReturnValue;
	} params{ Geometry, LocalCoordinate };

    static auto fn = UObject::FindObject("/Script/UMG.SlateBlueprintLibrary:LocalToAbsolute");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool USlateBlueprintLibrary::IsUnderLocation(struct FGeometry Geometry, struct FVector2D AbsoluteCoordinate)
{
	struct {
            struct FGeometry Geometry;
            struct FVector2D AbsoluteCoordinate;
            bool ReturnValue;
	} params{ Geometry, AbsoluteCoordinate };

    static auto fn = UObject::FindObject("/Script/UMG.SlateBlueprintLibrary:IsUnderLocation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FVector2D USlateBlueprintLibrary::GetLocalSize(struct FGeometry Geometry)
{
	struct {
            struct FGeometry Geometry;
            struct FVector2D ReturnValue;
	} params{ Geometry };

    static auto fn = UObject::FindObject("/Script/UMG.SlateBlueprintLibrary:GetLocalSize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FVector2D USlateBlueprintLibrary::GetAbsoluteSize(struct FGeometry Geometry)
{
	struct {
            struct FGeometry Geometry;
            struct FVector2D ReturnValue;
	} params{ Geometry };

    static auto fn = UObject::FindObject("/Script/UMG.SlateBlueprintLibrary:GetAbsoluteSize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool USlateBlueprintLibrary::EqualEqual_SlateBrush(struct FSlateBrush A, struct FSlateBrush B)
{
	struct {
            struct FSlateBrush A;
            struct FSlateBrush B;
            bool ReturnValue;
	} params{ A, B };

    static auto fn = UObject::FindObject("/Script/UMG.SlateBlueprintLibrary:EqualEqual_SlateBrush");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void USlateBlueprintLibrary::AbsoluteToViewport(class UObject* WorldContextObject, struct FVector2D AbsoluteDesktopCoordinate, struct FVector2D PixelPosition, struct FVector2D ViewportPosition)
{
	struct {
            class UObject* WorldContextObject;
            struct FVector2D AbsoluteDesktopCoordinate;
            struct FVector2D PixelPosition;
            struct FVector2D ViewportPosition;            void ReturnValue;
	} params{ WorldContextObject, AbsoluteDesktopCoordinate, PixelPosition, ViewportPosition };

    static auto fn = UObject::FindObject("/Script/UMG.SlateBlueprintLibrary:AbsoluteToViewport");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FVector2D USlateBlueprintLibrary::AbsoluteToLocal(struct FGeometry Geometry, struct FVector2D AbsoluteCoordinate)
{
	struct {
            struct FGeometry Geometry;
            struct FVector2D AbsoluteCoordinate;
            struct FVector2D ReturnValue;
	} params{ Geometry, AbsoluteCoordinate };

    static auto fn = UObject::FindObject("/Script/UMG.SlateBlueprintLibrary:AbsoluteToLocal");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void USpacer::SetSize(struct FVector2D InSize)
{
	struct {
            struct FVector2D InSize;
	} params{ InSize };

    static auto fn = UObject::FindObject("/Script/UMG.Spacer:SetSize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void USpinBox::SetValue(float NewValue)
{
	struct {
            float NewValue;
	} params{ NewValue };

    static auto fn = UObject::FindObject("/Script/UMG.SpinBox:SetValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USpinBox::SetMinValue(float NewValue)
{
	struct {
            float NewValue;
	} params{ NewValue };

    static auto fn = UObject::FindObject("/Script/UMG.SpinBox:SetMinValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USpinBox::SetMinSliderValue(float NewValue)
{
	struct {
            float NewValue;
	} params{ NewValue };

    static auto fn = UObject::FindObject("/Script/UMG.SpinBox:SetMinSliderValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USpinBox::SetMaxValue(float NewValue)
{
	struct {
            float NewValue;
	} params{ NewValue };

    static auto fn = UObject::FindObject("/Script/UMG.SpinBox:SetMaxValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USpinBox::SetMaxSliderValue(float NewValue)
{
	struct {
            float NewValue;
	} params{ NewValue };

    static auto fn = UObject::FindObject("/Script/UMG.SpinBox:SetMaxSliderValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USpinBox::SetForegroundColor(struct FSlateColor InForegroundColor)
{
	struct {
            struct FSlateColor InForegroundColor;
	} params{ InForegroundColor };

    static auto fn = UObject::FindObject("/Script/UMG.SpinBox:SetForegroundColor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


float USpinBox::GetValue()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.SpinBox:GetValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float USpinBox::GetMinValue()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.SpinBox:GetMinValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float USpinBox::GetMinSliderValue()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.SpinBox:GetMinSliderValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float USpinBox::GetMaxValue()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.SpinBox:GetMaxValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float USpinBox::GetMaxSliderValue()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.SpinBox:GetMaxSliderValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void USpinBox::ClearMinValue()
{
    static auto fn = UObject::FindObject("/Script/UMG.SpinBox:ClearMinValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void USpinBox::ClearMinSliderValue()
{
    static auto fn = UObject::FindObject("/Script/UMG.SpinBox:ClearMinSliderValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void USpinBox::ClearMaxValue()
{
    static auto fn = UObject::FindObject("/Script/UMG.SpinBox:ClearMaxValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void USpinBox::ClearMaxSliderValue()
{
    static auto fn = UObject::FindObject("/Script/UMG.SpinBox:ClearMaxSliderValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

struct FText UTextBinding::GetTextValue()
{
	struct {
            struct FText ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.TextBinding:GetTextValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FString UTextBinding::GetStringValue()
{
	struct {
            struct FString ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.TextBinding:GetStringValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UThrobber::SetNumberOfPieces(int InNumberOfPieces)
{
	struct {
            int InNumberOfPieces;
	} params{ InNumberOfPieces };

    static auto fn = UObject::FindObject("/Script/UMG.Throbber:SetNumberOfPieces");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UThrobber::SetAnimateVertically(bool bInAnimateVertically)
{
	struct {
            bool bInAnimateVertically;
	} params{ bInAnimateVertically };

    static auto fn = UObject::FindObject("/Script/UMG.Throbber:SetAnimateVertically");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UThrobber::SetAnimateOpacity(bool bInAnimateOpacity)
{
	struct {
            bool bInAnimateOpacity;
	} params{ bInAnimateOpacity };

    static auto fn = UObject::FindObject("/Script/UMG.Throbber:SetAnimateOpacity");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UThrobber::SetAnimateHorizontally(bool bInAnimateHorizontally)
{
	struct {
            bool bInAnimateHorizontally;
	} params{ bInAnimateHorizontally };

    static auto fn = UObject::FindObject("/Script/UMG.Throbber:SetAnimateHorizontally");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UUMGSequencePlayer::SetUserTag(FName InUserTag)
{
	struct {
            FName InUserTag;
	} params{ InUserTag };

    static auto fn = UObject::FindObject("/Script/UMG.UMGSequencePlayer:SetUserTag");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


FName UUMGSequencePlayer::GetUserTag()
{
	struct {
            FName ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.UMGSequencePlayer:GetUserTag");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UUniformGridPanel::SetSlotPadding(struct FMargin InSlotPadding)
{
	struct {
            struct FMargin InSlotPadding;
	} params{ InSlotPadding };

    static auto fn = UObject::FindObject("/Script/UMG.UniformGridPanel:SetSlotPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUniformGridPanel::SetMinDesiredSlotWidth(float InMinDesiredSlotWidth)
{
	struct {
            float InMinDesiredSlotWidth;
	} params{ InMinDesiredSlotWidth };

    static auto fn = UObject::FindObject("/Script/UMG.UniformGridPanel:SetMinDesiredSlotWidth");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUniformGridPanel::SetMinDesiredSlotHeight(float InMinDesiredSlotHeight)
{
	struct {
            float InMinDesiredSlotHeight;
	} params{ InMinDesiredSlotHeight };

    static auto fn = UObject::FindObject("/Script/UMG.UniformGridPanel:SetMinDesiredSlotHeight");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


class UUniformGridSlot* UUniformGridPanel::AddChildToUniformGrid(class UWidget* Content)
{
	struct {
            class UWidget* Content;
            class UUniformGridSlot* ReturnValue;
	} params{ Content };

    static auto fn = UObject::FindObject("/Script/UMG.UniformGridPanel:AddChildToUniformGrid");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UUniformGridSlot::SetVerticalAlignment(char InVerticalAlignment)
{
	struct {
            char InVerticalAlignment;
	} params{ InVerticalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.UniformGridSlot:SetVerticalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUniformGridSlot::SetRow(int InRow)
{
	struct {
            int InRow;
	} params{ InRow };

    static auto fn = UObject::FindObject("/Script/UMG.UniformGridSlot:SetRow");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUniformGridSlot::SetHorizontalAlignment(char InHorizontalAlignment)
{
	struct {
            char InHorizontalAlignment;
	} params{ InHorizontalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.UniformGridSlot:SetHorizontalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UUniformGridSlot::SetColumn(int InColumn)
{
	struct {
            int InColumn;
	} params{ InColumn };

    static auto fn = UObject::FindObject("/Script/UMG.UniformGridSlot:SetColumn");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

class UVerticalBoxSlot* UVerticalBox::AddChildToVerticalBox(class UWidget* Content)
{
	struct {
            class UWidget* Content;
            class UVerticalBoxSlot* ReturnValue;
	} params{ Content };

    static auto fn = UObject::FindObject("/Script/UMG.VerticalBox:AddChildToVerticalBox");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UVerticalBoxSlot::SetVerticalAlignment(char InVerticalAlignment)
{
	struct {
            char InVerticalAlignment;
	} params{ InVerticalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.VerticalBoxSlot:SetVerticalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UVerticalBoxSlot::SetSize(struct FSlateChildSize InSize)
{
	struct {
            struct FSlateChildSize InSize;
	} params{ InSize };

    static auto fn = UObject::FindObject("/Script/UMG.VerticalBoxSlot:SetSize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UVerticalBoxSlot::SetPadding(struct FMargin InPadding)
{
	struct {
            struct FMargin InPadding;
	} params{ InPadding };

    static auto fn = UObject::FindObject("/Script/UMG.VerticalBoxSlot:SetPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UVerticalBoxSlot::SetHorizontalAlignment(char InHorizontalAlignment)
{
	struct {
            char InHorizontalAlignment;
	} params{ InHorizontalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.VerticalBoxSlot:SetHorizontalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

class AActor* UViewport::Spawn(class AActor* ActorClass)
{
	struct {
            class AActor* ActorClass;
            class AActor* ReturnValue;
	} params{ ActorClass };

    static auto fn = UObject::FindObject("/Script/UMG.Viewport:Spawn");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UViewport::SetViewRotation(struct FRotator Rotation)
{
	struct {
            struct FRotator Rotation;
	} params{ Rotation };

    static auto fn = UObject::FindObject("/Script/UMG.Viewport:SetViewRotation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UViewport::SetViewLocation(struct FVector Location)
{
	struct {
            struct FVector Location;
	} params{ Location };

    static auto fn = UObject::FindObject("/Script/UMG.Viewport:SetViewLocation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


struct FRotator UViewport::GetViewRotation()
{
	struct {
            struct FRotator ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Viewport:GetViewRotation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UWorld* UViewport::GetViewportWorld()
{
	struct {
            class UWorld* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Viewport:GetViewportWorld");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FVector UViewport::GetViewLocation()
{
	struct {
            struct FVector ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.Viewport:GetViewLocation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

ESlateVisibility UVisibilityBinding::GetValue()
{
	struct {
            ESlateVisibility ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.VisibilityBinding:GetValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UWidgetAnimation::UnbindFromAnimationStarted(class UUserWidget* Widget, __int64/*DelegateProperty*/ Delegate)
{
	struct {
            class UUserWidget* Widget;
            __int64/*DelegateProperty*/ Delegate;
	} params{ Widget, Delegate };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetAnimation:UnbindFromAnimationStarted");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidgetAnimation::UnbindFromAnimationFinished(class UUserWidget* Widget, __int64/*DelegateProperty*/ Delegate)
{
	struct {
            class UUserWidget* Widget;
            __int64/*DelegateProperty*/ Delegate;
	} params{ Widget, Delegate };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetAnimation:UnbindFromAnimationFinished");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidgetAnimation::UnbindAllFromAnimationStarted(class UUserWidget* Widget)
{
	struct {
            class UUserWidget* Widget;
	} params{ Widget };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetAnimation:UnbindAllFromAnimationStarted");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidgetAnimation::UnbindAllFromAnimationFinished(class UUserWidget* Widget)
{
	struct {
            class UUserWidget* Widget;
	} params{ Widget };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetAnimation:UnbindAllFromAnimationFinished");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


float UWidgetAnimation::GetStartTime()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetAnimation:GetStartTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UWidgetAnimation::GetEndTime()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetAnimation:GetEndTime");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UWidgetAnimation::BindToAnimationStarted(class UUserWidget* Widget, __int64/*DelegateProperty*/ Delegate)
{
	struct {
            class UUserWidget* Widget;
            __int64/*DelegateProperty*/ Delegate;
	} params{ Widget, Delegate };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetAnimation:BindToAnimationStarted");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidgetAnimation::BindToAnimationFinished(class UUserWidget* Widget, __int64/*DelegateProperty*/ Delegate)
{
	struct {
            class UUserWidget* Widget;
            __int64/*DelegateProperty*/ Delegate;
	} params{ Widget, Delegate };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetAnimation:BindToAnimationFinished");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

class UWidget* UWidgetBinding::GetValue()
{
	struct {
            class UWidget* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBinding:GetValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

static struct FEventReply UWidgetBlueprintLibrary::UnlockMouse(struct FEventReply Reply)
{
	struct {
            struct FEventReply Reply;
            struct FEventReply ReturnValue;
	} params{ Reply };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:UnlockMouse");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FEventReply UWidgetBlueprintLibrary::Unhandled()
{
	struct {
            struct FEventReply ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:Unhandled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static void UWidgetBlueprintLibrary::SetWindowTitleBarState(class UWidget* TitleBarContent, EWindowTitleBarMode Mode, bool bTitleBarDragEnabled, bool bWindowButtonsVisible, bool bTitleBarVisible)
{
	struct {
            class UWidget* TitleBarContent;
            EWindowTitleBarMode Mode;
            bool bTitleBarDragEnabled;
            bool bWindowButtonsVisible;
            bool bTitleBarVisible;            void ReturnValue;
	} params{ TitleBarContent, Mode, bTitleBarDragEnabled, bWindowButtonsVisible, bTitleBarVisible };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:SetWindowTitleBarState");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UWidgetBlueprintLibrary::SetWindowTitleBarOnCloseClickedDelegate(__int64/*DelegateProperty*/ Delegate)
{
	struct {
            __int64/*DelegateProperty*/ Delegate;            void ReturnValue;
	} params{ Delegate };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:SetWindowTitleBarOnCloseClickedDelegate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UWidgetBlueprintLibrary::SetWindowTitleBarCloseButtonActive(bool bActive)
{
	struct {
            bool bActive;            void ReturnValue;
	} params{ bActive };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:SetWindowTitleBarCloseButtonActive");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FEventReply UWidgetBlueprintLibrary::SetUserFocus(struct FEventReply Reply, class UWidget* FocusWidget, bool bInAllUsers)
{
	struct {
            struct FEventReply Reply;
            class UWidget* FocusWidget;
            bool bInAllUsers;
            struct FEventReply ReturnValue;
	} params{ Reply, FocusWidget, bInAllUsers };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:SetUserFocus");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FEventReply UWidgetBlueprintLibrary::SetMousePosition(struct FEventReply Reply, struct FVector2D NewMousePosition)
{
	struct {
            struct FEventReply Reply;
            struct FVector2D NewMousePosition;
            struct FEventReply ReturnValue;
	} params{ Reply, NewMousePosition };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:SetMousePosition");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UWidgetBlueprintLibrary::SetInputMode_UIOnlyEx(class APlayerController* PlayerController, class UWidget* InWidgetToFocus, EMouseLockMode InMouseLockMode)
{
	struct {
            class APlayerController* PlayerController;
            class UWidget* InWidgetToFocus;
            EMouseLockMode InMouseLockMode;            void ReturnValue;
	} params{ PlayerController, InWidgetToFocus, InMouseLockMode };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:SetInputMode_UIOnlyEx");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UWidgetBlueprintLibrary::SetInputMode_UIOnly(class APlayerController* Target, class UWidget* InWidgetToFocus, bool bLockMouseToViewport)
{
	struct {
            class APlayerController* Target;
            class UWidget* InWidgetToFocus;
            bool bLockMouseToViewport;            void ReturnValue;
	} params{ Target, InWidgetToFocus, bLockMouseToViewport };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:SetInputMode_UIOnly");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UWidgetBlueprintLibrary::SetInputMode_GameOnly(class APlayerController* PlayerController)
{
	struct {
            class APlayerController* PlayerController;            void ReturnValue;
	} params{ PlayerController };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:SetInputMode_GameOnly");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UWidgetBlueprintLibrary::SetInputMode_GameAndUIEx(class APlayerController* PlayerController, class UWidget* InWidgetToFocus, EMouseLockMode InMouseLockMode, bool bHideCursorDuringCapture)
{
	struct {
            class APlayerController* PlayerController;
            class UWidget* InWidgetToFocus;
            EMouseLockMode InMouseLockMode;
            bool bHideCursorDuringCapture;            void ReturnValue;
	} params{ PlayerController, InWidgetToFocus, InMouseLockMode, bHideCursorDuringCapture };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:SetInputMode_GameAndUIEx");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UWidgetBlueprintLibrary::SetInputMode_GameAndUI(class APlayerController* Target, class UWidget* InWidgetToFocus, bool bLockMouseToViewport, bool bHideCursorDuringCapture)
{
	struct {
            class APlayerController* Target;
            class UWidget* InWidgetToFocus;
            bool bLockMouseToViewport;
            bool bHideCursorDuringCapture;            void ReturnValue;
	} params{ Target, InWidgetToFocus, bLockMouseToViewport, bHideCursorDuringCapture };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:SetInputMode_GameAndUI");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UWidgetBlueprintLibrary::SetHardwareCursor(class UObject* WorldContextObject, char CursorShape, FName CursorName, struct FVector2D HotSpot)
{
	struct {
            class UObject* WorldContextObject;
            char CursorShape;
            FName CursorName;
            struct FVector2D HotSpot;
            bool ReturnValue;
	} params{ WorldContextObject, CursorShape, CursorName, HotSpot };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:SetHardwareCursor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UWidgetBlueprintLibrary::SetFocusToGameViewport()
{
    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:SetFocusToGameViewport");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static void UWidgetBlueprintLibrary::SetBrushResourceToTexture(struct FSlateBrush Brush, class UTexture2D* Texture)
{
	struct {
            struct FSlateBrush Brush;
            class UTexture2D* Texture;            void ReturnValue;
	} params{ Brush, Texture };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:SetBrushResourceToTexture");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UWidgetBlueprintLibrary::SetBrushResourceToMaterial(struct FSlateBrush Brush, class UMaterialInterface* Material)
{
	struct {
            struct FSlateBrush Brush;
            class UMaterialInterface* Material;            void ReturnValue;
	} params{ Brush, Material };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:SetBrushResourceToMaterial");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UWidgetBlueprintLibrary::RestorePreviousWindowTitleBarState()
{
    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:RestorePreviousWindowTitleBarState");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static struct FEventReply UWidgetBlueprintLibrary::ReleaseMouseCapture(struct FEventReply Reply)
{
	struct {
            struct FEventReply Reply;
            struct FEventReply ReturnValue;
	} params{ Reply };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:ReleaseMouseCapture");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FEventReply UWidgetBlueprintLibrary::ReleaseJoystickCapture(struct FEventReply Reply, bool bInAllJoysticks)
{
	struct {
            struct FEventReply Reply;
            bool bInAllJoysticks;
            struct FEventReply ReturnValue;
	} params{ Reply, bInAllJoysticks };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:ReleaseJoystickCapture");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FSlateBrush UWidgetBlueprintLibrary::NoResourceBrush()
{
	struct {
            struct FSlateBrush ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:NoResourceBrush");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static struct FSlateBrush UWidgetBlueprintLibrary::MakeBrushFromTexture(class UTexture2D* Texture, int Width, int Height)
{
	struct {
            class UTexture2D* Texture;
            int Width;
            int Height;
            struct FSlateBrush ReturnValue;
	} params{ Texture, Width, Height };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:MakeBrushFromTexture");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FSlateBrush UWidgetBlueprintLibrary::MakeBrushFromMaterial(class UMaterialInterface* Material, int Width, int Height)
{
	struct {
            class UMaterialInterface* Material;
            int Width;
            int Height;
            struct FSlateBrush ReturnValue;
	} params{ Material, Width, Height };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:MakeBrushFromMaterial");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FSlateBrush UWidgetBlueprintLibrary::MakeBrushFromAsset(class USlateBrushAsset* BrushAsset)
{
	struct {
            class USlateBrushAsset* BrushAsset;
            struct FSlateBrush ReturnValue;
	} params{ BrushAsset };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:MakeBrushFromAsset");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FEventReply UWidgetBlueprintLibrary::LockMouse(struct FEventReply Reply, class UWidget* CapturingWidget)
{
	struct {
            struct FEventReply Reply;
            class UWidget* CapturingWidget;
            struct FEventReply ReturnValue;
	} params{ Reply, CapturingWidget };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:LockMouse");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UWidgetBlueprintLibrary::IsDragDropping()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:IsDragDropping");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static struct FEventReply UWidgetBlueprintLibrary::Handled()
{
	struct {
            struct FEventReply ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:Handled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static void UWidgetBlueprintLibrary::GetSafeZonePadding(class UObject* WorldContextObject, struct FVector4 SafePadding, struct FVector2D SafePaddingScale, struct FVector4 SpillOverPadding)
{
	struct {
            class UObject* WorldContextObject;
            struct FVector4 SafePadding;
            struct FVector2D SafePaddingScale;
            struct FVector4 SpillOverPadding;            void ReturnValue;
	} params{ WorldContextObject, SafePadding, SafePaddingScale, SpillOverPadding };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:GetSafeZonePadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FKeyEvent UWidgetBlueprintLibrary::GetKeyEventFromAnalogInputEvent(struct FAnalogInputEvent Event)
{
	struct {
            struct FAnalogInputEvent Event;
            struct FKeyEvent ReturnValue;
	} params{ Event };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:GetKeyEventFromAnalogInputEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FInputEvent UWidgetBlueprintLibrary::GetInputEventFromPointerEvent(struct FPointerEvent Event)
{
	struct {
            struct FPointerEvent Event;
            struct FInputEvent ReturnValue;
	} params{ Event };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:GetInputEventFromPointerEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FInputEvent UWidgetBlueprintLibrary::GetInputEventFromNavigationEvent(struct FNavigationEvent Event)
{
	struct {
            struct FNavigationEvent Event;
            struct FInputEvent ReturnValue;
	} params{ Event };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:GetInputEventFromNavigationEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FInputEvent UWidgetBlueprintLibrary::GetInputEventFromKeyEvent(struct FKeyEvent Event)
{
	struct {
            struct FKeyEvent Event;
            struct FInputEvent ReturnValue;
	} params{ Event };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:GetInputEventFromKeyEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FInputEvent UWidgetBlueprintLibrary::GetInputEventFromCharacterEvent(struct FCharacterEvent Event)
{
	struct {
            struct FCharacterEvent Event;
            struct FInputEvent ReturnValue;
	} params{ Event };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:GetInputEventFromCharacterEvent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UMaterialInstanceDynamic* UWidgetBlueprintLibrary::GetDynamicMaterial(struct FSlateBrush Brush)
{
	struct {
            struct FSlateBrush Brush;
            class UMaterialInstanceDynamic* ReturnValue;
	} params{ Brush };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:GetDynamicMaterial");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UDragDropOperation* UWidgetBlueprintLibrary::GetDragDroppingContent()
{
	struct {
            class UDragDropOperation* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:GetDragDroppingContent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static class UTexture2D* UWidgetBlueprintLibrary::GetBrushResourceAsTexture2D(struct FSlateBrush Brush)
{
	struct {
            struct FSlateBrush Brush;
            class UTexture2D* ReturnValue;
	} params{ Brush };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:GetBrushResourceAsTexture2D");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UMaterialInterface* UWidgetBlueprintLibrary::GetBrushResourceAsMaterial(struct FSlateBrush Brush)
{
	struct {
            struct FSlateBrush Brush;
            class UMaterialInterface* ReturnValue;
	} params{ Brush };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:GetBrushResourceAsMaterial");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UObject* UWidgetBlueprintLibrary::GetBrushResource(struct FSlateBrush Brush)
{
	struct {
            struct FSlateBrush Brush;
            class UObject* ReturnValue;
	} params{ Brush };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:GetBrushResource");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UWidgetBlueprintLibrary::GetAllWidgetsWithInterface(class UObject* WorldContextObject, class UInterface* Interface, TArray<class UUserWidget*> FoundWidgets, bool TopLevelOnly)
{
	struct {
            class UObject* WorldContextObject;
            class UInterface* Interface;
            TArray<class UUserWidget*> FoundWidgets;
            bool TopLevelOnly;            void ReturnValue;
	} params{ WorldContextObject, Interface, FoundWidgets, TopLevelOnly };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:GetAllWidgetsWithInterface");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UWidgetBlueprintLibrary::GetAllWidgetsOfClass(class UObject* WorldContextObject, TArray<class UUserWidget*> FoundWidgets, class UUserWidget* WidgetClass, bool TopLevelOnly)
{
	struct {
            class UObject* WorldContextObject;
            TArray<class UUserWidget*> FoundWidgets;
            class UUserWidget* WidgetClass;
            bool TopLevelOnly;            void ReturnValue;
	} params{ WorldContextObject, FoundWidgets, WidgetClass, TopLevelOnly };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:GetAllWidgetsOfClass");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FEventReply UWidgetBlueprintLibrary::EndDragDrop(struct FEventReply Reply)
{
	struct {
            struct FEventReply Reply;
            struct FEventReply ReturnValue;
	} params{ Reply };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:EndDragDrop");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UWidgetBlueprintLibrary::DrawTextFormatted(struct FPaintContext Context, struct FText Text, struct FVector2D Position, class UFont* Font, int FontSize, FName FontTypeFace, struct FLinearColor Tint)
{
	struct {
            struct FPaintContext Context;
            struct FText Text;
            struct FVector2D Position;
            class UFont* Font;
            int FontSize;
            FName FontTypeFace;
            struct FLinearColor Tint;            void ReturnValue;
	} params{ Context, Text, Position, Font, FontSize, FontTypeFace, Tint };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:DrawTextFormatted");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UWidgetBlueprintLibrary::DrawText(struct FPaintContext Context, struct FString inString, struct FVector2D Position, struct FLinearColor Tint)
{
	struct {
            struct FPaintContext Context;
            struct FString inString;
            struct FVector2D Position;
            struct FLinearColor Tint;            void ReturnValue;
	} params{ Context, inString, Position, Tint };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:DrawText");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UWidgetBlueprintLibrary::DrawLines(struct FPaintContext Context, TArray<struct FVector2D> Points, struct FLinearColor Tint, bool bAntiAlias)
{
	struct {
            struct FPaintContext Context;
            TArray<struct FVector2D> Points;
            struct FLinearColor Tint;
            bool bAntiAlias;            void ReturnValue;
	} params{ Context, Points, Tint, bAntiAlias };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:DrawLines");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UWidgetBlueprintLibrary::DrawLine(struct FPaintContext Context, struct FVector2D PositionA, struct FVector2D PositionB, struct FLinearColor Tint, bool bAntiAlias)
{
	struct {
            struct FPaintContext Context;
            struct FVector2D PositionA;
            struct FVector2D PositionB;
            struct FLinearColor Tint;
            bool bAntiAlias;            void ReturnValue;
	} params{ Context, PositionA, PositionB, Tint, bAntiAlias };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:DrawLine");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UWidgetBlueprintLibrary::DrawBox(struct FPaintContext Context, struct FVector2D Position, struct FVector2D Size, class USlateBrushAsset* Brush, struct FLinearColor Tint)
{
	struct {
            struct FPaintContext Context;
            struct FVector2D Position;
            struct FVector2D Size;
            class USlateBrushAsset* Brush;
            struct FLinearColor Tint;            void ReturnValue;
	} params{ Context, Position, Size, Brush, Tint };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:DrawBox");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UWidgetBlueprintLibrary::DismissAllMenus()
{
    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:DismissAllMenus");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static struct FEventReply UWidgetBlueprintLibrary::DetectDragIfPressed(struct FPointerEvent PointerEvent, class UWidget* WidgetDetectingDrag, struct FKey DragKey)
{
	struct {
            struct FPointerEvent PointerEvent;
            class UWidget* WidgetDetectingDrag;
            struct FKey DragKey;
            struct FEventReply ReturnValue;
	} params{ PointerEvent, WidgetDetectingDrag, DragKey };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:DetectDragIfPressed");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FEventReply UWidgetBlueprintLibrary::DetectDrag(struct FEventReply Reply, class UWidget* WidgetDetectingDrag, struct FKey DragKey)
{
	struct {
            struct FEventReply Reply;
            class UWidget* WidgetDetectingDrag;
            struct FKey DragKey;
            struct FEventReply ReturnValue;
	} params{ Reply, WidgetDetectingDrag, DragKey };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:DetectDrag");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UDragDropOperation* UWidgetBlueprintLibrary::CreateDragDropOperation(class UDragDropOperation* OperationClass)
{
	struct {
            class UDragDropOperation* OperationClass;
            class UDragDropOperation* ReturnValue;
	} params{ OperationClass };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:CreateDragDropOperation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UUserWidget* UWidgetBlueprintLibrary::Create(class UObject* WorldContextObject, class UUserWidget* WidgetType, class APlayerController* OwningPlayer)
{
	struct {
            class UObject* WorldContextObject;
            class UUserWidget* WidgetType;
            class APlayerController* OwningPlayer;
            class UUserWidget* ReturnValue;
	} params{ WorldContextObject, WidgetType, OwningPlayer };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:Create");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FEventReply UWidgetBlueprintLibrary::ClearUserFocus(struct FEventReply Reply, bool bInAllUsers)
{
	struct {
            struct FEventReply Reply;
            bool bInAllUsers;
            struct FEventReply ReturnValue;
	} params{ Reply, bInAllUsers };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:ClearUserFocus");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FEventReply UWidgetBlueprintLibrary::CaptureMouse(struct FEventReply Reply, class UWidget* CapturingWidget)
{
	struct {
            struct FEventReply Reply;
            class UWidget* CapturingWidget;
            struct FEventReply ReturnValue;
	} params{ Reply, CapturingWidget };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:CaptureMouse");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FEventReply UWidgetBlueprintLibrary::CaptureJoystick(struct FEventReply Reply, class UWidget* CapturingWidget, bool bInAllJoysticks)
{
	struct {
            struct FEventReply Reply;
            class UWidget* CapturingWidget;
            bool bInAllJoysticks;
            struct FEventReply ReturnValue;
	} params{ Reply, CapturingWidget, bInAllJoysticks };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:CaptureJoystick");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UWidgetBlueprintLibrary::CancelDragDrop()
{
    static auto fn = UObject::FindObject("/Script/UMG.WidgetBlueprintLibrary:CancelDragDrop");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UWidgetComponent::SetWidget(class UUserWidget* Widget)
{
	struct {
            class UUserWidget* Widget;
	} params{ Widget };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetComponent:SetWidget");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidgetComponent::SetTintColorAndOpacity(struct FLinearColor NewTintColorAndOpacity)
{
	struct {
            struct FLinearColor NewTintColorAndOpacity;
	} params{ NewTintColorAndOpacity };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetComponent:SetTintColorAndOpacity");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidgetComponent::SetOwnerPlayer(class ULocalPlayer* LocalPlayer)
{
	struct {
            class ULocalPlayer* LocalPlayer;
	} params{ LocalPlayer };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetComponent:SetOwnerPlayer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidgetComponent::SetManuallyRedraw(bool bUseManualRedraw)
{
	struct {
            bool bUseManualRedraw;
	} params{ bUseManualRedraw };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetComponent:SetManuallyRedraw");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidgetComponent::SetDrawSize(struct FVector2D Size)
{
	struct {
            struct FVector2D Size;
	} params{ Size };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetComponent:SetDrawSize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidgetComponent::SetBackgroundColor(struct FLinearColor NewBackgroundColor)
{
	struct {
            struct FLinearColor NewBackgroundColor;
	} params{ NewBackgroundColor };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetComponent:SetBackgroundColor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidgetComponent::RequestRedraw()
{
    static auto fn = UObject::FindObject("/Script/UMG.WidgetComponent:RequestRedraw");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


class UUserWidget* UWidgetComponent::GetUserWidgetObject()
{
	struct {
            class UUserWidget* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetComponent:GetUserWidgetObject");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UTextureRenderTarget2D* UWidgetComponent::GetRenderTarget()
{
	struct {
            class UTextureRenderTarget2D* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetComponent:GetRenderTarget");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class ULocalPlayer* UWidgetComponent::GetOwnerPlayer()
{
	struct {
            class ULocalPlayer* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetComponent:GetOwnerPlayer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UMaterialInstanceDynamic* UWidgetComponent::GetMaterialInstance()
{
	struct {
            class UMaterialInstanceDynamic* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetComponent:GetMaterialInstance");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FVector2D UWidgetComponent::GetDrawSize()
{
	struct {
            struct FVector2D ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetComponent:GetDrawSize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UWidgetInteractionComponent::SetCustomHitResult(struct FHitResult HitResult)
{
	struct {
            struct FHitResult HitResult;
	} params{ HitResult };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetInteractionComponent:SetCustomHitResult");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UWidgetInteractionComponent::SendKeyChar(struct FString Characters, bool bRepeat)
{
	struct {
            struct FString Characters;
            bool bRepeat;
            bool ReturnValue;
	} params{ Characters, bRepeat };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetInteractionComponent:SendKeyChar");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UWidgetInteractionComponent::ScrollWheel(float ScrollDelta)
{
	struct {
            float ScrollDelta;
	} params{ ScrollDelta };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetInteractionComponent:ScrollWheel");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidgetInteractionComponent::ReleasePointerKey(struct FKey Key)
{
	struct {
            struct FKey Key;
	} params{ Key };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetInteractionComponent:ReleasePointerKey");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UWidgetInteractionComponent::ReleaseKey(struct FKey Key)
{
	struct {
            struct FKey Key;
            bool ReturnValue;
	} params{ Key };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetInteractionComponent:ReleaseKey");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UWidgetInteractionComponent::PressPointerKey(struct FKey Key)
{
	struct {
            struct FKey Key;
	} params{ Key };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetInteractionComponent:PressPointerKey");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UWidgetInteractionComponent::PressKey(struct FKey Key, bool bRepeat)
{
	struct {
            struct FKey Key;
            bool bRepeat;
            bool ReturnValue;
	} params{ Key, bRepeat };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetInteractionComponent:PressKey");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UWidgetInteractionComponent::PressAndReleaseKey(struct FKey Key)
{
	struct {
            struct FKey Key;
            bool ReturnValue;
	} params{ Key };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetInteractionComponent:PressAndReleaseKey");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


bool UWidgetInteractionComponent::IsOverInteractableWidget()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetInteractionComponent:IsOverInteractableWidget");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UWidgetInteractionComponent::IsOverHitTestVisibleWidget()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetInteractionComponent:IsOverHitTestVisibleWidget");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UWidgetInteractionComponent::IsOverFocusableWidget()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetInteractionComponent:IsOverFocusableWidget");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FHitResult UWidgetInteractionComponent::GetLastHitResult()
{
	struct {
            struct FHitResult ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetInteractionComponent:GetLastHitResult");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class UWidgetComponent* UWidgetInteractionComponent::GetHoveredWidgetComponent()
{
	struct {
            class UWidgetComponent* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetInteractionComponent:GetHoveredWidgetComponent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FVector2D UWidgetInteractionComponent::Get2DHitLocation()
{
	struct {
            struct FVector2D ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetInteractionComponent:Get2DHitLocation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

static class UVerticalBoxSlot* UWidgetLayoutLibrary::SlotAsVerticalBoxSlot(class UWidget* Widget)
{
	struct {
            class UWidget* Widget;
            class UVerticalBoxSlot* ReturnValue;
	} params{ Widget };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetLayoutLibrary:SlotAsVerticalBoxSlot");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UUniformGridSlot* UWidgetLayoutLibrary::SlotAsUniformGridSlot(class UWidget* Widget)
{
	struct {
            class UWidget* Widget;
            class UUniformGridSlot* ReturnValue;
	} params{ Widget };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetLayoutLibrary:SlotAsUniformGridSlot");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UOverlaySlot* UWidgetLayoutLibrary::SlotAsOverlaySlot(class UWidget* Widget)
{
	struct {
            class UWidget* Widget;
            class UOverlaySlot* ReturnValue;
	} params{ Widget };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetLayoutLibrary:SlotAsOverlaySlot");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UHorizontalBoxSlot* UWidgetLayoutLibrary::SlotAsHorizontalBoxSlot(class UWidget* Widget)
{
	struct {
            class UWidget* Widget;
            class UHorizontalBoxSlot* ReturnValue;
	} params{ Widget };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetLayoutLibrary:SlotAsHorizontalBoxSlot");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UGridSlot* UWidgetLayoutLibrary::SlotAsGridSlot(class UWidget* Widget)
{
	struct {
            class UWidget* Widget;
            class UGridSlot* ReturnValue;
	} params{ Widget };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetLayoutLibrary:SlotAsGridSlot");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UCanvasPanelSlot* UWidgetLayoutLibrary::SlotAsCanvasSlot(class UWidget* Widget)
{
	struct {
            class UWidget* Widget;
            class UCanvasPanelSlot* ReturnValue;
	} params{ Widget };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetLayoutLibrary:SlotAsCanvasSlot");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UBorderSlot* UWidgetLayoutLibrary::SlotAsBorderSlot(class UWidget* Widget)
{
	struct {
            class UWidget* Widget;
            class UBorderSlot* ReturnValue;
	} params{ Widget };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetLayoutLibrary:SlotAsBorderSlot");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UWidgetLayoutLibrary::RemoveAllWidgets(class UObject* WorldContextObject)
{
	struct {
            class UObject* WorldContextObject;            void ReturnValue;
	} params{ WorldContextObject };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetLayoutLibrary:RemoveAllWidgets");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UWidgetLayoutLibrary::ProjectWorldLocationToWidgetPosition(class APlayerController* PlayerController, struct FVector WorldLocation, struct FVector2D ScreenPosition)
{
	struct {
            class APlayerController* PlayerController;
            struct FVector WorldLocation;
            struct FVector2D ScreenPosition;
            bool ReturnValue;
	} params{ PlayerController, WorldLocation, ScreenPosition };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetLayoutLibrary:ProjectWorldLocationToWidgetPosition");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGeometry UWidgetLayoutLibrary::GetViewportWidgetGeometry(class UObject* WorldContextObject)
{
	struct {
            class UObject* WorldContextObject;
            struct FGeometry ReturnValue;
	} params{ WorldContextObject };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetLayoutLibrary:GetViewportWidgetGeometry");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FVector2D UWidgetLayoutLibrary::GetViewportSize(class UObject* WorldContextObject)
{
	struct {
            class UObject* WorldContextObject;
            struct FVector2D ReturnValue;
	} params{ WorldContextObject };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetLayoutLibrary:GetViewportSize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static float UWidgetLayoutLibrary::GetViewportScale(class UObject* WorldContextObject)
{
	struct {
            class UObject* WorldContextObject;
            float ReturnValue;
	} params{ WorldContextObject };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetLayoutLibrary:GetViewportScale");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FGeometry UWidgetLayoutLibrary::GetPlayerScreenWidgetGeometry(class APlayerController* PlayerController)
{
	struct {
            class APlayerController* PlayerController;
            struct FGeometry ReturnValue;
	} params{ PlayerController };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetLayoutLibrary:GetPlayerScreenWidgetGeometry");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UWidgetLayoutLibrary::GetMousePositionScaledByDPI(class APlayerController* Player, float LocationX, float LocationY)
{
	struct {
            class APlayerController* Player;
            float LocationX;
            float LocationY;
            bool ReturnValue;
	} params{ Player, LocationX, LocationY };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetLayoutLibrary:GetMousePositionScaledByDPI");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FVector2D UWidgetLayoutLibrary::GetMousePositionOnViewport(class UObject* WorldContextObject)
{
	struct {
            class UObject* WorldContextObject;
            struct FVector2D ReturnValue;
	} params{ WorldContextObject };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetLayoutLibrary:GetMousePositionOnViewport");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FVector2D UWidgetLayoutLibrary::GetMousePositionOnPlatform()
{
	struct {
            struct FVector2D ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetLayoutLibrary:GetMousePositionOnPlatform");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UWidgetSwitcherSlot::SetVerticalAlignment(char InVerticalAlignment)
{
	struct {
            char InVerticalAlignment;
	} params{ InVerticalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetSwitcherSlot:SetVerticalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidgetSwitcherSlot::SetPadding(struct FMargin InPadding)
{
	struct {
            struct FMargin InPadding;
	} params{ InPadding };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetSwitcherSlot:SetPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWidgetSwitcherSlot::SetHorizontalAlignment(char InHorizontalAlignment)
{
	struct {
            char InHorizontalAlignment;
	} params{ InHorizontalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.WidgetSwitcherSlot:SetHorizontalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UWindowTitleBarArea::SetVerticalAlignment(char InVerticalAlignment)
{
	struct {
            char InVerticalAlignment;
	} params{ InVerticalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.WindowTitleBarArea:SetVerticalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWindowTitleBarArea::SetPadding(struct FMargin InPadding)
{
	struct {
            struct FMargin InPadding;
	} params{ InPadding };

    static auto fn = UObject::FindObject("/Script/UMG.WindowTitleBarArea:SetPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWindowTitleBarArea::SetHorizontalAlignment(char InHorizontalAlignment)
{
	struct {
            char InHorizontalAlignment;
	} params{ InHorizontalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.WindowTitleBarArea:SetHorizontalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UWindowTitleBarAreaSlot::SetVerticalAlignment(char InVerticalAlignment)
{
	struct {
            char InVerticalAlignment;
	} params{ InVerticalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.WindowTitleBarAreaSlot:SetVerticalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWindowTitleBarAreaSlot::SetPadding(struct FMargin InPadding)
{
	struct {
            struct FMargin InPadding;
	} params{ InPadding };

    static auto fn = UObject::FindObject("/Script/UMG.WindowTitleBarAreaSlot:SetPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWindowTitleBarAreaSlot::SetHorizontalAlignment(char InHorizontalAlignment)
{
	struct {
            char InHorizontalAlignment;
	} params{ InHorizontalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.WindowTitleBarAreaSlot:SetHorizontalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UWrapBox::SetInnerSlotPadding(struct FVector2D InPadding)
{
	struct {
            struct FVector2D InPadding;
	} params{ InPadding };

    static auto fn = UObject::FindObject("/Script/UMG.WrapBox:SetInnerSlotPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


class UWrapBoxSlot* UWrapBox::AddChildWrapBox(class UWidget* Content)
{
	struct {
            class UWidget* Content;
            class UWrapBoxSlot* ReturnValue;
	} params{ Content };

    static auto fn = UObject::FindObject("/Script/UMG.WrapBox:AddChildWrapBox");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UWrapBoxSlot::SetVerticalAlignment(char InVerticalAlignment)
{
	struct {
            char InVerticalAlignment;
	} params{ InVerticalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.WrapBoxSlot:SetVerticalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWrapBoxSlot::SetPadding(struct FMargin InPadding)
{
	struct {
            struct FMargin InPadding;
	} params{ InPadding };

    static auto fn = UObject::FindObject("/Script/UMG.WrapBoxSlot:SetPadding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWrapBoxSlot::SetHorizontalAlignment(char InHorizontalAlignment)
{
	struct {
            char InHorizontalAlignment;
	} params{ InHorizontalAlignment };

    static auto fn = UObject::FindObject("/Script/UMG.WrapBoxSlot:SetHorizontalAlignment");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWrapBoxSlot::SetFillSpanWhenLessThan(float InFillSpanWhenLessThan)
{
	struct {
            float InFillSpanWhenLessThan;
	} params{ InFillSpanWhenLessThan };

    static auto fn = UObject::FindObject("/Script/UMG.WrapBoxSlot:SetFillSpanWhenLessThan");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWrapBoxSlot::SetFillEmptySpace(bool InbFillEmptySpace)
{
	struct {
            bool InbFillEmptySpace;
	} params{ InbFillEmptySpace };

    static auto fn = UObject::FindObject("/Script/UMG.WrapBoxSlot:SetFillEmptySpace");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

