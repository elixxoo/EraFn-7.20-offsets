#pragma once

#include "../SDK.hpp"

namespace SDK {


class UAnimSharingStateInstance : public UAnimInstance
{
	public:
	    class UAnimSequence* AnimationToPlay; // 0x268 Size: 0x8
	    float PermutationTimeOffset; // 0x270 Size: 0x4
	    float PlayRate; // 0x274 Size: 0x4
	    bool bStateBool; // 0x278 Size: 0x1
	    char UnknownData0[0x279]; // 0x279
	    void GetInstancedActors(TArray<class AActor*> Actors); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7d51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AnimationSharing.AnimSharingStateInstance");
			return (class UClass*)ptr;
		};

};

class UAnimSharingTransitionInstance : public UAnimInstance
{
	public:
	    TWeakObjectPtr<USkeletalMeshComponent*> FromComponent; // 0x268 Size: 0x8
	    TWeakObjectPtr<USkeletalMeshComponent*> ToComponent; // 0x270 Size: 0x8
	    float BlendTime; // 0x278 Size: 0x4
	    bool bBlendBool; // 0x27c Size: 0x1
	    char UnknownData0[0x3];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AnimationSharing.AnimSharingTransitionInstance");
			return (class UClass*)ptr;
		};

};

class UAnimSharingAdditiveInstance : public UAnimInstance
{
	public:
	    TWeakObjectPtr<USkeletalMeshComponent*> BaseComponent; // 0x268 Size: 0x8
	    TWeakObjectPtr<UAnimSequence*> AdditiveAnimation; // 0x270 Size: 0x8
	    float Alpha; // 0x278 Size: 0x4
	    bool bStateBool; // 0x27c Size: 0x1
	    char UnknownData0[0x3];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AnimationSharing.AnimSharingAdditiveInstance");
			return (class UClass*)ptr;
		};

};

class UAnimSharingInstance : public UObject
{
	public:
	    TArray<class AActor*> RegisteredActors; // 0x28 Size: 0x10
	    char UnknownData0[0x70]; // 0x38
	    class UAnimationSharingStateProcessor* StateProcessor; // 0xa8 Size: 0x8
	    char UnknownData1[0x38]; // 0xb0
	    TArray<class UAnimSequence*> UsedAnimationSequences; // 0xe8 Size: 0x10
	    char UnknownData2[0x10]; // 0xf8
	    class UEnum* StateEnum; // 0x108 Size: 0x8
	    class AActor* SharingActor; // 0x110 Size: 0x8
	    char UnknownData3[0x20];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AnimationSharing.AnimSharingInstance");
			return (class UClass*)ptr;
		};

};

class UAnimationSharingManager : public UObject
{
	public:
	    char UnknownData0[0x10];
	    TArray<class UAnimSharingInstance*> PerSkeletonData; // 0x38 Size: 0x10
	    char UnknownData1[0x48]; // 0x48
	    static bool AnimSharingEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f31];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AnimationSharing.AnimationSharingManager");
			return (class UClass*)ptr;
		};

};

class UAnimationSharingSetup : public UObject
{
	public:
	    TArray<struct FPerSkeletonAnimationSharingSetup> SkeletonSetups; // 0x28 Size: 0x10
	    struct FAnimationSharingScalability ScalabilitySettings; // 0x38 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AnimationSharing.AnimationSharingSetup");
			return (class UClass*)ptr;
		};

};

class UAnimationSharingStateProcessor : public UObject
{
	public:
	    struct TSoftObjectPtr<struct UEnum*> AnimationStateEnum; // 0x28 Size: 0x28
	    char UnknownData0[0x50]; // 0x50
	    void ProcessActorState(int OutState, class AActor* InActor, char CurrentState, char OnDemandState, bool bShouldProcess); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    class UEnum* GetAnimationStateEnum(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AnimationSharing.AnimationSharingStateProcessor");
			return (class UClass*)ptr;
		};

};


}