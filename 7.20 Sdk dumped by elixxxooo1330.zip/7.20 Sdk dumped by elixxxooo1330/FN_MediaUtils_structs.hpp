#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FMediaPlayerTrackOptions
{
	public:
	    int Audio; // 0x0 Size: 0x4
	    int Caption; // 0x4 Size: 0x4
	    int MetaData; // 0x8 Size: 0x4
	    int Script; // 0xc Size: 0x4
	    int Subtitle; // 0x10 Size: 0x4
	    int Text; // 0x14 Size: 0x4
	    int Video; // 0x18 Size: 0x4

};

struct FMediaPlayerOptions
{
	public:
	    struct FMediaPlayerTrackOptions Tracks; // 0x0 Size: 0x1c

};


}