#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class EMIDIEventType : uint8_t
{
    Unknown = 0,
    NoteOff = 8,
    NoteOn = 9,
    NoteAfterTouch = 10,
    ControlChange = 11,
    ProgramChange = 12,
    ChannelAfterTouch = 13,
    PitchBend = 14,
    EMIDIEventType_MAX = 15
};struct FOnMIDIEvent__DelegateSignature
{
	public:
	    class UMIDIDeviceController* MIDIDeviceController; // 0x0 Size: 0x8
	    int Timestamp; // 0x8 Size: 0x4
	    EMIDIEventType EventType; // 0xc Size: 0x1
	    char UnknownData0[0x3]; // 0xd
	    int Channel; // 0x10 Size: 0x4
	    int ControlID; // 0x14 Size: 0x4
	    int Velocity; // 0x18 Size: 0x4
	    int RawEventType; // 0x1c Size: 0x4

};

struct FFoundMIDIDevice
{
	public:
	    int DeviceID; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    struct FString DeviceName; // 0x8 Size: 0x10
	    bool bCanReceiveFrom; // 0x18 Size: 0x1
	    bool bCanSendTo; // 0x19 Size: 0x1
	    bool bIsAlreadyInUse; // 0x1a Size: 0x1
	    bool bIsDefaultInputDevice; // 0x1b Size: 0x1
	    bool bIsDefaultOutputDevice; // 0x1c Size: 0x1
	    char UnknownData1[0x3];

};


}