#pragma once

#include "../SDK.hpp"

namespace SDK {


class USocialChatChannelTab : public UCommonButton
{
	public:
	    class USocialChatChannel* ChatChannel; // 0xb28 Size: 0x8
	    class UCommonTextBlock* CommonText_ChannelName; // 0xb30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialUMG.SocialChatChannelTab");
			return (class UClass*)ptr;
		};

};

class USocialChatContainer : public UUserWidget
{
	public:
	    class USocialChatManager* ChatManager; // 0x228 Size: 0x8
	    TArray<class USocialChatChannel*> JoinedChannels; // 0x230 Size: 0x10
	    class USocialChatChannel* ActiveChannel; // 0x240 Size: 0x8
	    class UCommonButtonGroup* TabButtonGroup; // 0x248 Size: 0x8
	    char UnknownData0[0x8]; // 0x250
	    class USocialChatMessageList* ChatList_Messages; // 0x258 Size: 0x8
	    class UEditableText* EditableText_MessageEntry; // 0x260 Size: 0x8
	    class UCommonButton* Button_SendMessage; // 0x268 Size: 0x8
	    class UDynamicEntryBox* EntryBox_JoinedChannels; // 0x270 Size: 0x8
	    class UScrollBox* ScrollBox_Channels; // 0x278 Size: 0x8
	    char UnknownData1[0x280]; // 0x280
	    void SendCurrentMessage(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnChatOpenChanged(bool bShouldBeOpen); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleRightTabPressed(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleLeftTabPressed(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void FocusEditableText(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void DynamicHandleMessageTextCommitted(struct FText MessageText, char CommitMethod); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7d61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialUMG.SocialChatContainer");
			return (class UClass*)ptr;
		};

};

class USocialChatMessageEntry : public UUserWidget
{
	public:
	    char UnknownData0[0x18];
	    struct FSocialChatMessageEntryStyle DefaultStyle; // 0x240 Size: 0x120
	    class UTextBlock* Text_Message; // 0x360 Size: 0x8
	    class UTextBlock* Text_SenderName; // 0x368 Size: 0x8
	    class UTextBlock* Text_ChannelName; // 0x370 Size: 0x8
	    class UTextBlock* Text_Timestamp; // 0x378 Size: 0x8
	    class UHorizontalBox* HorizontalBox_Header; // 0x380 Size: 0x8
	    class UButton* Button_MessageButton; // 0x388 Size: 0x8
	    char UnknownData1[0x390]; // 0x390
	    void OnMessageSet(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool CanInteract(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7c51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialUMG.SocialChatMessageEntry");
			return (class UClass*)ptr;
		};

};

class USocialChatMessageList : public UListViewBase
{
	public:
	    char UnknownData0[0xa8];
	    bool bIsFocusable; // 0x2b0 Size: 0x1
	    char UnknownData1[0x7]; // 0x2b1
	    class USocialChatChannel* ActiveChannel; // 0x2b8 Size: 0x8
	    char UnknownData2[0x20];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialUMG.SocialChatMessageList");
			return (class UClass*)ptr;
		};

};

class USocialInteractionButton : public UCommonButton
{
	public:
	    struct FLinearColor DefaultIndicatorColor; // 0xb28 Size: 0x10
	    struct FLinearColor AlertingIndicatorColor; // 0xb38 Size: 0x10
	    char UnknownData0[0x30]; // 0xb48
	    class UCommonTextBlock* Text_InteractionName; // 0xb78 Size: 0x8
	    class UBorder* Border_InteractionIndicator; // 0xb80 Size: 0x8
	    char UnknownData1[0xb88]; // 0xb88
	    void OnInteractionSet(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool IsPlatformOnlyFriend(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    FName GetInteractionName(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7459];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialUMG.SocialInteractionButton");
			return (class UClass*)ptr;
		};

};

class USocialInteractionMenu : public UUserWidget
{
	public:
	    class UObject* SocialContext; // 0x228 Size: 0x8
	    char UnknownData0[0x40]; // 0x230
	    class UDynamicEntryBox* EntryBox_PositiveInteractions; // 0x270 Size: 0x8
	    class UDynamicEntryBox* EntryBox_NegativeInteractions; // 0x278 Size: 0x8
	    class USpacer* Spacer_InteractionSeparator; // 0x280 Size: 0x8
	    class UCommonWidgetSwitcher* Switcher_Confirmation; // 0x288 Size: 0x8
	    class UTextBlock* Text_ConfirmationLabel; // 0x290 Size: 0x8
	    class UCommonButton* Button_Confirm; // 0x298 Size: 0x8
	    class UCommonButton* Button_Decline; // 0x2a0 Size: 0x8
	    char UnknownData1[0x2a8]; // 0x2a8
	    void OnToggleConfirmation(bool bIsVisible); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnSocialContextSet(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    class UWidget* GetFirstEntryToCenter(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7d39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialUMG.SocialInteractionMenu");
			return (class UClass*)ptr;
		};

};

class UDesignerPreviewChatChannel : public USocialChatChannel
{
	public:
	    char UnknownData0[0x150];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialUMG.DesignerPreviewChatChannel");
			return (class UClass*)ptr;
		};

};

class USocialListEntry : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    class UTextBlock* Text_UserName; // 0xb30 Size: 0x8
	    class UMenuAnchor* MenuAnchor_Actions; // 0xb38 Size: 0x8
	    char UnknownData1[0xb40]; // 0xb40
	    class UWidget* HandleGetMenuContent(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-74a1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialUMG.SocialListEntry");
			return (class UClass*)ptr;
		};

};

class USocialUserListEntry : public USocialListEntry
{
	public:
	    class USocialUser* SocialUser; // 0xb40 Size: 0x8
	    class UTextBlock* Text_RichPresence; // 0xb48 Size: 0x8
	    char UnknownData0[0xb50]; // 0xb50
	    void OnUserPresenceChanged(EOnlineStatus OnlineStatus); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7491];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialUMG.SocialUserListEntry");
			return (class UClass*)ptr;
		};

};

class USocialInviteListEntry : public USocialListEntry
{
	public:
	    class USocialInvite* SocialInvite; // 0xb40 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialUMG.SocialInviteListEntry");
			return (class UClass*)ptr;
		};

};

class USocialUserListHeader : public UObject
{
	public:
	    char UnknownData0[0x68];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialUMG.SocialUserListHeader");
			return (class UClass*)ptr;
		};

};

class USocialInviteListHeader : public USocialUserListHeader
{
	public:
	    char UnknownData0[0x8];
	    TArray<class USocialInvite*> SocialInvites; // 0x70 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialUMG.SocialInviteListHeader");
			return (class UClass*)ptr;
		};

};

class USocialInvite : public UObject
{
	public:
	    class USocialUser* OtherUser; // 0x28 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialUMG.SocialInvite");
			return (class UClass*)ptr;
		};

};

class USocialFriendInvite : public USocialInvite
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialUMG.SocialFriendInvite");
			return (class UClass*)ptr;
		};

};

class USocialPartyInvite : public USocialInvite
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialUMG.SocialPartyInvite");
			return (class UClass*)ptr;
		};

};

class USocialUserListHeaderEntry : public UCommonButton
{
	public:
	    char UnknownData0[0x8];
	    class USocialUserListHeader* ListHeader; // 0xb30 Size: 0x8
	    class UTextBlock* Text_ListName; // 0xb38 Size: 0x8
	    class UTextBlock* Text_NumEntries; // 0xb40 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialUMG.SocialUserListHeaderEntry");
			return (class UClass*)ptr;
		};

};

class USocialUserTreeView : public UTreeView
{
	public:
	    class USocialUserListEntry* UserEntryWidgetClass; // 0x388 Size: 0x8
	    class USocialInviteListEntry* InviteEntryWidgetClass; // 0x390 Size: 0x8
	    class USocialInteractionMenu* ActionMenuClass; // 0x398 Size: 0x8
	    class USocialInteractionMenu* ActionMenu; // 0x3a0 Size: 0x8
	    char UnknownData0[0x10];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SocialUMG.SocialUserTreeView");
			return (class UClass*)ptr;
		};

};


}