#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class EQosResponseType : uint8_t
{
    NoResponse = 0,
    Success = 1,
    Failure = 2,
    EQosResponseType_MAX = 3
};

enum class EQosCompletionResult : uint8_t
{
    Invalid = 0,
    Success = 1,
    Failure = 2,
    Canceled = 3,
    EQosCompletionResult_MAX = 4
};

enum class EQosDatacenterResult : uint8_t
{
    Invalid = 0,
    Success = 1,
    Incomplete = 2,
    EQosDatacenterResult_MAX = 3
};struct FQosPingServerInfo
{
	public:
	    struct FString Address; // 0x0 Size: 0x10
	    int Port; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FQosRegionInfo
{
	public:
	    struct FText DisplayName; // 0x0 Size: 0x18
	    struct FString RegionId; // 0x18 Size: 0x10
	    bool bEnabled; // 0x28 Size: 0x1
	    bool bVisible; // 0x29 Size: 0x1
	    bool bAutoAssignable; // 0x2a Size: 0x1
	    char UnknownData0[0x5];

};


}