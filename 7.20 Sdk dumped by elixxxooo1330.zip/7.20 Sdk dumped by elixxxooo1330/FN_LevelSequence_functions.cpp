#include "../SDK.hpp"

void ULevelSequenceBurnInOptions::SetBurnIn(struct FSoftClassPath InBurnInClass)
{
	struct {
            struct FSoftClassPath InBurnInClass;
	} params{ InBurnInClass };

    static auto fn = UObject::FindObject("/Script/LevelSequence.LevelSequenceBurnInOptions:SetBurnIn");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void ALevelSequenceActor::SetSequence(class ULevelSequence* InSequence)
{
	struct {
            class ULevelSequence* InSequence;
	} params{ InSequence };

    static auto fn = UObject::FindObject("/Script/LevelSequence.LevelSequenceActor:SetSequence");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ALevelSequenceActor::SetReplicatePlayback(bool ReplicatePlayback)
{
	struct {
            bool ReplicatePlayback;
	} params{ ReplicatePlayback };

    static auto fn = UObject::FindObject("/Script/LevelSequence.LevelSequenceActor:SetReplicatePlayback");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ALevelSequenceActor::SetEventReceivers(TArray<class AActor*> AdditionalReceivers)
{
	struct {
            TArray<class AActor*> AdditionalReceivers;
	} params{ AdditionalReceivers };

    static auto fn = UObject::FindObject("/Script/LevelSequence.LevelSequenceActor:SetEventReceivers");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ALevelSequenceActor::SetBinding(struct FMovieSceneObjectBindingID Binding, TArray<class AActor*> Actors, bool bAllowBindingsFromAsset)
{
	struct {
            struct FMovieSceneObjectBindingID Binding;
            TArray<class AActor*> Actors;
            bool bAllowBindingsFromAsset;
	} params{ Binding, Actors, bAllowBindingsFromAsset };

    static auto fn = UObject::FindObject("/Script/LevelSequence.LevelSequenceActor:SetBinding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ALevelSequenceActor::ResetBindings()
{
    static auto fn = UObject::FindObject("/Script/LevelSequence.LevelSequenceActor:ResetBindings");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void ALevelSequenceActor::ResetBinding(struct FMovieSceneObjectBindingID Binding)
{
	struct {
            struct FMovieSceneObjectBindingID Binding;
	} params{ Binding };

    static auto fn = UObject::FindObject("/Script/LevelSequence.LevelSequenceActor:ResetBinding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void ALevelSequenceActor::RemoveBinding(struct FMovieSceneObjectBindingID Binding, class AActor* Actor)
{
	struct {
            struct FMovieSceneObjectBindingID Binding;
            class AActor* Actor;
	} params{ Binding, Actor };

    static auto fn = UObject::FindObject("/Script/LevelSequence.LevelSequenceActor:RemoveBinding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


class ULevelSequence* ALevelSequenceActor::LoadSequence()
{
	struct {
            class ULevelSequence* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/LevelSequence.LevelSequenceActor:LoadSequence");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


class ULevelSequence* ALevelSequenceActor::GetSequence()
{
	struct {
            class ULevelSequence* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/LevelSequence.LevelSequenceActor:GetSequence");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void ALevelSequenceActor::AddBinding(struct FMovieSceneObjectBindingID Binding, class AActor* Actor, bool bAllowBindingsFromAsset)
{
	struct {
            struct FMovieSceneObjectBindingID Binding;
            class AActor* Actor;
            bool bAllowBindingsFromAsset;
	} params{ Binding, Actor, bAllowBindingsFromAsset };

    static auto fn = UObject::FindObject("/Script/LevelSequence.LevelSequenceActor:AddBinding");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void ULevelSequenceBurnIn::SetSettings(class UObject* InSettings)
{
	struct {
            class UObject* InSettings;
	} params{ InSettings };

    static auto fn = UObject::FindObject("/Script/LevelSequence.LevelSequenceBurnIn:SetSettings");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


class ULevelSequenceBurnInInitSettings* ULevelSequenceBurnIn::GetSettingsClass()
{
	struct {
            class ULevelSequenceBurnInInitSettings* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/LevelSequence.LevelSequenceBurnIn:GetSettingsClass");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void ULevelSequenceDirector::OnCreated()
{
    static auto fn = UObject::FindObject("/Script/LevelSequence.LevelSequenceDirector:OnCreated");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

static class ULevelSequencePlayer* ULevelSequencePlayer::CreateLevelSequencePlayer(class UObject* WorldContextObject, class ULevelSequence* LevelSequence, struct FMovieSceneSequencePlaybackSettings Settings, class ALevelSequenceActor* OutActor)
{
	struct {
            class UObject* WorldContextObject;
            class ULevelSequence* LevelSequence;
            struct FMovieSceneSequencePlaybackSettings Settings;
            class ALevelSequenceActor* OutActor;
            class ULevelSequencePlayer* ReturnValue;
	} params{ WorldContextObject, LevelSequence, Settings, OutActor };

    static auto fn = UObject::FindObject("/Script/LevelSequence.LevelSequencePlayer:CreateLevelSequencePlayer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

