#pragma once

#include "../SDK.hpp"

namespace SDK {


class UBlueprintFunctionLibrary : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BlueprintFunctionLibrary");
			return (class UClass*)ptr;
		};

};

class UActorComponent : public UObject
{
	public:
	    char UnknownData0[0x8];
	    struct FActorComponentTickFunction PrimaryComponentTick; // 0x30 Size: 0x58
	    TArray<FName> ComponentTags; // 0x88 Size: 0x10
	    TArray<class UAssetUserData*> AssetUserData; // 0x98 Size: 0x10
	    bool bReplicates; // 0xac Size: 0x1
	    bool bNetAddressable; // 0xac Size: 0x1
	    bool bAutoActivate; // 0xad Size: 0x1
	    bool bIsActive; // 0xae Size: 0x1
	    bool bEditableWhenInherited; // 0xae Size: 0x1
	    bool bCanEverAffectNavigation; // 0xae Size: 0x1
	    bool bIsEditorOnly; // 0xae Size: 0x1
	    char UnknownData1[0x1]; // 0xaf
	    EComponentCreationMethod CreationMethod; // 0xb0 Size: 0x1
	    char UnknownData2[0x7]; // 0xb1
	    TArray<struct FSimpleMemberReference> UCSModifiedProperties; // 0xb8 Size: 0x10
	    MulticastDelegateProperty OnComponentActivated; // 0xc8 Size: 0x10
	    MulticastDelegateProperty OnComponentDeactivated; // 0xd8 Size: 0x10
	    char UnknownData3[0xe8]; // 0xe8
	    void ToggleActive(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetTickGroup(char NewTickGroup); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetTickableWhenPaused(bool bTickableWhenPaused); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetIsReplicated(bool ShouldReplicate); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetComponentTickInterval(float TickInterval); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetComponentTickEnabled(bool bEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetAutoActivate(bool bNewAutoActivate); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetActive(bool bNewActive, bool bReset); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void RemoveTickPrerequisiteComponent(class UActorComponent* PrerequisiteComponent); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void RemoveTickPrerequisiteActor(class AActor* PrerequisiteActor); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void ReceiveTick(float DeltaSeconds); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void ReceiveEndPlay(char EndPlayReason); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void ReceiveBeginPlay(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void OnRep_IsActive(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void K2_DestroyComponent(class UObject* Object); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    bool IsComponentTickEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    bool IsBeingDestroyed(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    bool IsActive(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    class AActor* GetOwner(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    float GetComponentTickInterval(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void Deactivate(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    bool ComponentHasTag(FName Tag); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void AddTickPrerequisiteComponent(class UActorComponent* PrerequisiteComponent); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void AddTickPrerequisiteActor(class AActor* PrerequisiteActor); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void Activate(bool bReset); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x-7ee9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ActorComponent");
			return (class UClass*)ptr;
		};

};

class USceneComponent : public UActorComponent
{
	public:
	    char UnknownData0[0x8];
	    TWeakObjectPtr<APhysicsVolume*> PhysicsVolume; // 0x100 Size: 0x8
	    class USceneComponent* AttachParent; // 0x108 Size: 0x8
	    FName AttachSocketName; // 0x110 Size: 0x8
	    TArray<class USceneComponent*> AttachChildren; // 0x118 Size: 0x10
	    TArray<class USceneComponent*> ClientAttachedChildren; // 0x128 Size: 0x10
	    char UnknownData1[0x2c]; // 0x138
	    struct FVector RelativeLocation; // 0x164 Size: 0xc
	    struct FRotator RelativeRotation; // 0x170 Size: 0xc
	    struct FVector RelativeScale3D; // 0x17c Size: 0xc
	    char UnknownData2[0x38]; // 0x188
	    struct FVector ComponentVelocity; // 0x1c0 Size: 0xc
	    bool bComponentToWorldUpdated; // 0x1cc Size: 0x1
	    bool bAbsoluteLocation; // 0x1cc Size: 0x1
	    bool bAbsoluteRotation; // 0x1cc Size: 0x1
	    bool bAbsoluteScale; // 0x1cc Size: 0x1
	    bool bVisible; // 0x1cc Size: 0x1
	    bool bHiddenInGame; // 0x1cc Size: 0x1
	    bool bShouldUpdatePhysicsVolume; // 0x1cc Size: 0x1
	    bool bBoundsChangeTriggersStreamingDataRebuild; // 0x1cd Size: 0x1
	    bool bUseAttachParentBound; // 0x1cd Size: 0x1
	    bool bAbsoluteTranslation; // 0x1cd Size: 0x1
	    char UnknownData3[0x8]; // 0x1d6
	    char Mobility; // 0x1ce Size: 0x1
	    char DetailMode; // 0x1cf Size: 0x1
	    char UnknownData4[0x40]; // 0x1d0
	    MulticastDelegateProperty PhysicsVolumeChangedDelegate; // 0x210 Size: 0x10
	    char UnknownData5[0x220]; // 0x220
	    void ToggleVisibility(bool bPropagateToChildren); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool SnapTo(class USceneComponent* InParent, FName InSocketName); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetWorldScale3D(struct FVector NewScale); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetVisibility(bool bNewVisibility, bool bPropagateToChildren); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetShouldUpdatePhysicsVolume(bool bInShouldUpdatePhysicsVolume); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetRelativeScale3D(struct FVector NewScale3D); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetMobility(char NewMobility); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetHiddenInGame(bool NewHidden, bool bPropagateToChildren); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void SetAbsolute(bool bNewAbsoluteLocation, bool bNewAbsoluteRotation, bool bNewAbsoluteScale); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void ResetRelativeTransform(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void OnRep_Visibility(bool OldValue); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void OnRep_Transform(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void OnRep_AttachSocketName(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void OnRep_AttachParent(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void OnRep_AttachChildren(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void K2_SetWorldTransform(struct FTransform NewTransform, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void K2_SetWorldRotation(struct FRotator NewRotation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void K2_SetWorldLocationAndRotation(struct FVector NewLocation, struct FRotator NewRotation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void K2_SetWorldLocation(struct FVector NewLocation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void K2_SetRelativeTransform(struct FTransform NewTransform, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void K2_SetRelativeRotation(struct FRotator NewRotation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void K2_SetRelativeLocationAndRotation(struct FVector NewLocation, struct FRotator NewRotation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void K2_SetRelativeLocation(struct FVector NewLocation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    struct FTransform K2_GetComponentToWorld(); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    struct FVector K2_GetComponentScale(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    struct FRotator K2_GetComponentRotation(); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    struct FVector K2_GetComponentLocation(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    void K2_DetachFromComponent(EDetachmentRule LocationRule, EDetachmentRule RotationRule, EDetachmentRule ScaleRule, bool bCallModify); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    bool K2_AttachToComponent(class USceneComponent* Parent, FName SocketName, EAttachmentRule LocationRule, EAttachmentRule RotationRule, EAttachmentRule ScaleRule, bool bWeldSimulatedBodies); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    bool K2_AttachTo(class USceneComponent* InParent, FName InSocketName, char AttachType, bool bWeldSimulatedBodies); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    void K2_AddWorldTransform(struct FTransform DeltaTransform, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    void K2_AddWorldRotation(struct FRotator DeltaRotation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    void K2_AddWorldOffset(struct FVector DeltaLocation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    void K2_AddRelativeRotation(struct FRotator DeltaRotation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    void K2_AddRelativeLocation(struct FVector DeltaLocation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    void K2_AddLocalTransform(struct FTransform DeltaTransform, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    void K2_AddLocalRotation(struct FRotator DeltaRotation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    void K2_AddLocalOffset(struct FVector DeltaLocation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    bool IsVisible(); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    bool IsSimulatingPhysics(FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    bool IsAnySimulatingPhysics(); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    struct FVector GetUpVector(); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    struct FTransform GetSocketTransform(FName InSocketName, char TransformSpace); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    struct FRotator GetSocketRotation(FName InSocketName); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    struct FQuat GetSocketQuaternion(FName InSocketName); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    struct FVector GetSocketLocation(FName InSocketName); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    bool GetShouldUpdatePhysicsVolume(); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    struct FVector GetRightVector(); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    struct FTransform GetRelativeTransform(); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    class APhysicsVolume* GetPhysicsVolume(); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    void GetParentComponents(TArray<class USceneComponent*> Parents); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    int GetNumChildrenComponents(); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    struct FVector GetForwardVector(); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    struct FVector GetComponentVelocity(); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    void GetChildrenComponents(bool bIncludeAllDescendants, TArray<class USceneComponent*> Children); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    class USceneComponent* GetChildComponent(int ChildIndex); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    FName GetAttachSocketName(); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x7fe1]; // 0x7fe1
	    class USceneComponent* GetAttachParent(); // 0x0 Size: 0x7fe1
	    char UnknownData63[0x7fe1]; // 0x7fe1
	    TArray<FName> GetAllSocketNames(); // 0x0 Size: 0x7fe1
	    char UnknownData64[0x7fe1]; // 0x7fe1
	    bool DoesSocketExist(FName InSocketName); // 0x0 Size: 0x7fe1
	    char UnknownData65[0x7fe1]; // 0x7fe1
	    void DetachFromParent(bool bMaintainWorldPosition, bool bCallModify); // 0x0 Size: 0x7fe1
	    char UnknownData66[0x-7d91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SceneComponent");
			return (class UClass*)ptr;
		};

};

class UPrimitiveComponent : public USceneComponent
{
	public:
	    float MinDrawDistance; // 0x250 Size: 0x4
	    float LDMaxDrawDistance; // 0x254 Size: 0x4
	    float CachedMaxDrawDistance; // 0x258 Size: 0x4
	    char DepthPriorityGroup; // 0x25c Size: 0x1
	    char ViewOwnerDepthPriorityGroup; // 0x25d Size: 0x1
	    char IndirectLightingCacheQuality; // 0x25e Size: 0x1
	    ELightmapType LightmapType; // 0x25f Size: 0x1
	    bool bNeverDistanceCull; // 0x260 Size: 0x1
	    bool bAlwaysCreatePhysicsState; // 0x260 Size: 0x1
	    bool bGenerateOverlapEvents; // 0x260 Size: 0x1
	    bool bMultiBodyOverlap; // 0x260 Size: 0x1
	    bool bCheckAsyncSceneOnMove; // 0x261 Size: 0x1
	    bool bTraceComplexOnMove; // 0x261 Size: 0x1
	    bool bReturnMaterialOnMove; // 0x261 Size: 0x1
	    bool bUseViewOwnerDepthPriorityGroup; // 0x261 Size: 0x1
	    bool bAllowCullDistanceVolume; // 0x261 Size: 0x1
	    bool bHasMotionBlurVelocityMeshes; // 0x261 Size: 0x1
	    bool bVisibleInReflectionCaptures; // 0x261 Size: 0x1
	    bool bRenderInMainPass; // 0x261 Size: 0x1
	    bool bRenderInMono; // 0x262 Size: 0x1
	    bool bReceivesDecals; // 0x262 Size: 0x1
	    bool bOwnerNoSee; // 0x262 Size: 0x1
	    bool bOnlyOwnerSee; // 0x262 Size: 0x1
	    bool bTreatAsBackgroundForOcclusion; // 0x262 Size: 0x1
	    bool bUseAsOccluder; // 0x262 Size: 0x1
	    bool bSelectable; // 0x262 Size: 0x1
	    bool bForceMipStreaming; // 0x262 Size: 0x1
	    bool bHasPerInstanceHitProxies; // 0x263 Size: 0x1
	    bool CastShadow; // 0x263 Size: 0x1
	    bool bAffectDynamicIndirectLighting; // 0x263 Size: 0x1
	    bool bAffectDistanceFieldLighting; // 0x263 Size: 0x1
	    bool bCastDynamicShadow; // 0x263 Size: 0x1
	    bool bCastStaticShadow; // 0x263 Size: 0x1
	    bool bCastVolumetricTranslucentShadow; // 0x263 Size: 0x1
	    bool bSelfShadowOnly; // 0x263 Size: 0x1
	    bool bCastFarShadow; // 0x264 Size: 0x1
	    bool bCastInsetShadow; // 0x264 Size: 0x1
	    bool bCastCinematicShadow; // 0x264 Size: 0x1
	    bool bCastHiddenShadow; // 0x264 Size: 0x1
	    bool bCastShadowAsTwoSided; // 0x264 Size: 0x1
	    bool bLightAsIfStatic; // 0x264 Size: 0x1
	    bool bLightAttachmentsAsGroup; // 0x264 Size: 0x1
	    bool bReceiveMobileCSMShadows; // 0x264 Size: 0x1
	    bool bSingleSampleShadowFromStationaryLights; // 0x265 Size: 0x1
	    bool bIgnoreRadialImpulse; // 0x265 Size: 0x1
	    bool bIgnoreRadialForce; // 0x265 Size: 0x1
	    bool bApplyImpulseOnDamage; // 0x265 Size: 0x1
	    bool bReplicatePhysicsToAutonomousProxy; // 0x265 Size: 0x1
	    bool AlwaysLoadOnClient; // 0x265 Size: 0x1
	    bool AlwaysLoadOnServer; // 0x265 Size: 0x1
	    bool bUseEditorCompositing; // 0x265 Size: 0x1
	    bool bRenderCustomDepth; // 0x266 Size: 0x1
	    char UnknownData0[0x26]; // 0x28d
	    char bHasCustomNavigableGeometry; // 0x267 Size: 0x1
	    char UnknownData1[0x1]; // 0x268
	    char CanCharacterStepUpOn; // 0x269 Size: 0x1
	    struct FLightingChannels LightingChannels; // 0x26a Size: 0x1
	    ERendererStencilMask CustomDepthStencilWriteMask; // 0x26b Size: 0x1
	    int CustomDepthStencilValue; // 0x26c Size: 0x4
	    int TranslucencySortPriority; // 0x270 Size: 0x4
	    int VisibilityId; // 0x274 Size: 0x4
	    char UnknownData2[0x4]; // 0x278
	    float LpvBiasMultiplier; // 0x27c Size: 0x4
	    char UnknownData3[0x8]; // 0x280
	    float BoundsScale; // 0x288 Size: 0x4
	    float LastSubmitTime; // 0x28c Size: 0x4
	    float LastRenderTime; // 0x290 Size: 0x4
	    float LastRenderTimeOnScreen; // 0x294 Size: 0x4
	    TArray<class AActor*> MoveIgnoreActors; // 0x298 Size: 0x10
	    TArray<class UPrimitiveComponent*> MoveIgnoreComponents; // 0x2a8 Size: 0x10
	    char UnknownData4[0x10]; // 0x2b8
	    struct FBodyInstance BodyInstance; // 0x2c8 Size: 0x150
	    MulticastDelegateProperty OnComponentHit; // 0x418 Size: 0x10
	    MulticastDelegateProperty OnComponentBeginOverlap; // 0x428 Size: 0x10
	    MulticastDelegateProperty OnComponentEndOverlap; // 0x438 Size: 0x10
	    MulticastDelegateProperty OnComponentWake; // 0x448 Size: 0x10
	    MulticastDelegateProperty OnComponentSleep; // 0x458 Size: 0x10
	    char UnknownData5[0x10]; // 0x468
	    MulticastDelegateProperty OnBeginCursorOver; // 0x478 Size: 0x10
	    MulticastDelegateProperty OnEndCursorOver; // 0x488 Size: 0x10
	    MulticastDelegateProperty OnClicked; // 0x498 Size: 0x10
	    MulticastDelegateProperty OnReleased; // 0x4a8 Size: 0x10
	    MulticastDelegateProperty OnInputTouchBegin; // 0x4b8 Size: 0x10
	    MulticastDelegateProperty OnInputTouchEnd; // 0x4c8 Size: 0x10
	    MulticastDelegateProperty OnInputTouchEnter; // 0x4d8 Size: 0x10
	    MulticastDelegateProperty OnInputTouchLeave; // 0x4e8 Size: 0x10
	    char UnknownData6[0x18]; // 0x4f8
	    class UPrimitiveComponent* LODParentPrimitive; // 0x510 Size: 0x8
	    struct FPrimitiveComponentPostPhysicsTickFunction PostPhysicsComponentTick; // 0x518 Size: 0x58
	    char UnknownData7[0x570]; // 0x570
	    void WakeRigidBody(FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void WakeAllRigidBodies(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetWalkableSlopeOverride(struct FWalkableSlopeOverride NewOverride); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetUseCCD(bool InUseCCD, FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetTranslucentSortPriority(int NewTranslucentSortPriority); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetSingleSampleShadowFromStationaryLights(bool bNewSingleSampleShadowFromStationaryLights); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void SetSimulatePhysics(bool bSimulate); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void SetRenderInMono(bool bValue); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void SetRenderInMainPass(bool bValue); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void SetRenderCustomDepth(bool bValue); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void SetReceivesDecals(bool bNewReceivesDecals); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void SetPhysMaterialOverride(class UPhysicalMaterial* NewPhysMaterial); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void SetPhysicsMaxAngularVelocityInRadians(float NewMaxAngVel, bool bAddToCurrent, FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void SetPhysicsMaxAngularVelocityInDegrees(float NewMaxAngVel, bool bAddToCurrent, FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void SetPhysicsMaxAngularVelocity(float NewMaxAngVel, bool bAddToCurrent, FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void SetPhysicsLinearVelocity(struct FVector NewVel, bool bAddToCurrent, FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void SetPhysicsAngularVelocityInRadians(struct FVector NewAngVel, bool bAddToCurrent, FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void SetPhysicsAngularVelocityInDegrees(struct FVector NewAngVel, bool bAddToCurrent, FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void SetPhysicsAngularVelocity(struct FVector NewAngVel, bool bAddToCurrent, FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void SetOwnerNoSee(bool bNewOwnerNoSee); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void SetOnlyOwnerSee(bool bNewOnlyOwnerSee); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void SetNotifyRigidBodyCollision(bool bNewNotifyRigidBodyCollision); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    void SetMaterialByName(FName MaterialSlotName, class UMaterialInterface* Material); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    void SetMaterial(int ElementIndex, class UMaterialInterface* Material); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    void SetMassScale(FName BoneName, float InMassScale); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    void SetMassOverrideInKg(FName BoneName, float MassInKg, bool bOverrideMass); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    void SetLockedAxis(char LockedAxis); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    void SetLinearDamping(float InDamping); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    void SetGenerateOverlapEvents(bool bInGenerateOverlapEvents); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    void SetEnableGravity(bool bGravityEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    void SetCustomDepthStencilWriteMask(ERendererStencilMask WriteMaskBit); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    void SetCustomDepthStencilValue(int Value); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    void SetCullDistance(float NewCullDistance); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    void SetConstraintMode(char ConstraintMode); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    void SetCollisionResponseToChannel(char Channel, char NewResponse); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    void SetCollisionResponseToAllChannels(char NewResponse); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    void SetCollisionProfileName(FName InCollisionProfileName); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    void SetCollisionObjectType(char Channel); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    void SetCollisionEnabled(char NewType); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    void SetCenterOfMass(struct FVector CenterOfMassOffset, FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    void SetCastShadow(bool NewCastShadow); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    void SetBoundsScale(float NewBoundsScale); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    void SetAngularDamping(float InDamping); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    void SetAllUseCCD(bool InUseCCD); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    void SetAllPhysicsLinearVelocity(struct FVector NewVel, bool bAddToCurrent); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    void SetAllPhysicsAngularVelocityInRadians(struct FVector NewAngVel, bool bAddToCurrent); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    void SetAllPhysicsAngularVelocityInDegrees(struct FVector NewAngVel, bool bAddToCurrent); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    void SetAllPhysicsAngularVelocity(struct FVector NewAngVel, bool bAddToCurrent); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    void SetAllMassScale(float InMassScale); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    struct FVector ScaleByMomentOfInertia(struct FVector InputVector, FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    void PutRigidBodyToSleep(FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    bool K2_SphereTraceComponent(struct FVector TraceStart, struct FVector TraceEnd, float SphereRadius, bool bTraceComplex, bool bShowTrace, bool bPersistentShowTrace, struct FVector HitLocation, struct FVector HitNormal, FName BoneName, struct FHitResult OutHit); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    bool K2_SphereOverlapComponent(struct FVector InSphereCentre, float InSphereRadius, bool bTraceComplex, bool bShowTrace, bool bPersistentShowTrace, struct FVector HitLocation, struct FVector HitNormal, FName BoneName, struct FHitResult OutHit); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    bool K2_LineTraceComponent(struct FVector TraceStart, struct FVector TraceEnd, bool bTraceComplex, bool bShowTrace, bool bPersistentShowTrace, struct FVector HitLocation, struct FVector HitNormal, FName BoneName, struct FHitResult OutHit); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    bool K2_IsQueryCollisionEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x7fe1]; // 0x7fe1
	    bool K2_IsPhysicsCollisionEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData63[0x7fe1]; // 0x7fe1
	    bool K2_IsCollisionEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData64[0x7fe1]; // 0x7fe1
	    bool K2_BoxOverlapComponent(struct FVector InBoxCentre, struct FBox InBox, bool bTraceComplex, bool bShowTrace, bool bPersistentShowTrace, struct FVector HitLocation, struct FVector HitNormal, FName BoneName, struct FHitResult OutHit); // 0x0 Size: 0x7fe1
	    char UnknownData65[0x7fe1]; // 0x7fe1
	    bool IsOverlappingComponent(class UPrimitiveComponent* OtherComp); // 0x0 Size: 0x7fe1
	    char UnknownData66[0x7fe1]; // 0x7fe1
	    bool IsOverlappingActor(class AActor* Other); // 0x0 Size: 0x7fe1
	    char UnknownData67[0x7fe1]; // 0x7fe1
	    bool IsGravityEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData68[0x7fe1]; // 0x7fe1
	    bool IsAnyRigidBodyAwake(); // 0x0 Size: 0x7fe1
	    char UnknownData69[0x7fe1]; // 0x7fe1
	    void IgnoreComponentWhenMoving(class UPrimitiveComponent* Component, bool bShouldIgnore); // 0x0 Size: 0x7fe1
	    char UnknownData70[0x7fe1]; // 0x7fe1
	    void IgnoreActorWhenMoving(class AActor* Actor, bool bShouldIgnore); // 0x0 Size: 0x7fe1
	    char UnknownData71[0x7fe1]; // 0x7fe1
	    struct FWalkableSlopeOverride GetWalkableSlopeOverride(); // 0x0 Size: 0x7fe1
	    char UnknownData72[0x7fe1]; // 0x7fe1
	    struct FVector GetPhysicsLinearVelocityAtPoint(struct FVector Point, FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData73[0x7fe1]; // 0x7fe1
	    struct FVector GetPhysicsLinearVelocity(FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData74[0x7fe1]; // 0x7fe1
	    struct FVector GetPhysicsAngularVelocityInRadians(FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData75[0x7fe1]; // 0x7fe1
	    struct FVector GetPhysicsAngularVelocityInDegrees(FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData76[0x7fe1]; // 0x7fe1
	    struct FVector GetPhysicsAngularVelocity(FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData77[0x7fe1]; // 0x7fe1
	    void GetOverlappingComponents(TArray<class UPrimitiveComponent*> OutOverlappingComponents); // 0x0 Size: 0x7fe1
	    char UnknownData78[0x7fe1]; // 0x7fe1
	    void GetOverlappingActors(TArray<class AActor*> OverlappingActors, class AActor* ClassFilter); // 0x0 Size: 0x7fe1
	    char UnknownData79[0x7fe1]; // 0x7fe1
	    int GetNumMaterials(); // 0x0 Size: 0x7fe1
	    char UnknownData80[0x7fe1]; // 0x7fe1
	    class UMaterialInterface* GetMaterialFromCollisionFaceIndex(int FaceIndex, int SectionIndex); // 0x0 Size: 0x7fe1
	    char UnknownData81[0x7fe1]; // 0x7fe1
	    class UMaterialInterface* GetMaterial(int ElementIndex); // 0x0 Size: 0x7fe1
	    char UnknownData82[0x7fe1]; // 0x7fe1
	    float GetMassScale(FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData83[0x7fe1]; // 0x7fe1
	    float GetMass(); // 0x0 Size: 0x7fe1
	    char UnknownData84[0x7fe1]; // 0x7fe1
	    float GetLinearDamping(); // 0x0 Size: 0x7fe1
	    char UnknownData85[0x7fe1]; // 0x7fe1
	    struct FVector GetInertiaTensor(FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData86[0x7fe1]; // 0x7fe1
	    bool GetGenerateOverlapEvents(); // 0x0 Size: 0x7fe1
	    char UnknownData87[0x7fe1]; // 0x7fe1
	    char GetCollisionResponseToChannel(char Channel); // 0x0 Size: 0x7fe1
	    char UnknownData88[0x7fe1]; // 0x7fe1
	    FName GetCollisionProfileName(); // 0x0 Size: 0x7fe1
	    char UnknownData89[0x7fe1]; // 0x7fe1
	    char GetCollisionObjectType(); // 0x0 Size: 0x7fe1
	    char UnknownData90[0x7fe1]; // 0x7fe1
	    char GetCollisionEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData91[0x7fe1]; // 0x7fe1
	    float GetClosestPointOnCollision(struct FVector Point, struct FVector OutPointOnBody, FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData92[0x7fe1]; // 0x7fe1
	    struct FVector GetCenterOfMass(FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData93[0x7fe1]; // 0x7fe1
	    float GetAngularDamping(); // 0x0 Size: 0x7fe1
	    char UnknownData94[0x7fe1]; // 0x7fe1
	    class UMaterialInstanceDynamic* CreateDynamicMaterialInstance(int ElementIndex, class UMaterialInterface* SourceMaterial, FName OptionalName); // 0x0 Size: 0x7fe1
	    char UnknownData95[0x7fe1]; // 0x7fe1
	    class UMaterialInstanceDynamic* CreateAndSetMaterialInstanceDynamicFromMaterial(int ElementIndex, class UMaterialInterface* Parent); // 0x0 Size: 0x7fe1
	    char UnknownData96[0x7fe1]; // 0x7fe1
	    class UMaterialInstanceDynamic* CreateAndSetMaterialInstanceDynamic(int ElementIndex); // 0x0 Size: 0x7fe1
	    char UnknownData97[0x7fe1]; // 0x7fe1
	    TArray<class UPrimitiveComponent*> CopyArrayOfMoveIgnoreComponents(); // 0x0 Size: 0x7fe1
	    char UnknownData98[0x7fe1]; // 0x7fe1
	    TArray<class AActor*> CopyArrayOfMoveIgnoreActors(); // 0x0 Size: 0x7fe1
	    char UnknownData99[0x7fe1]; // 0x7fe1
	    void ClearMoveIgnoreComponents(); // 0x0 Size: 0x7fe1
	    char UnknownData100[0x7fe1]; // 0x7fe1
	    void ClearMoveIgnoreActors(); // 0x0 Size: 0x7fe1
	    char UnknownData101[0x7fe1]; // 0x7fe1
	    bool CanCharacterStepUp(class APawn* Pawn); // 0x0 Size: 0x7fe1
	    char UnknownData102[0x7fe1]; // 0x7fe1
	    void AddTorqueInRadians(struct FVector Torque, FName BoneName, bool bAccelChange); // 0x0 Size: 0x7fe1
	    char UnknownData103[0x7fe1]; // 0x7fe1
	    void AddTorqueInDegrees(struct FVector Torque, FName BoneName, bool bAccelChange); // 0x0 Size: 0x7fe1
	    char UnknownData104[0x7fe1]; // 0x7fe1
	    void AddTorque(struct FVector Torque, FName BoneName, bool bAccelChange); // 0x0 Size: 0x7fe1
	    char UnknownData105[0x7fe1]; // 0x7fe1
	    void AddRadialImpulse(struct FVector Origin, float Radius, float Strength, char Falloff, bool bVelChange); // 0x0 Size: 0x7fe1
	    char UnknownData106[0x7fe1]; // 0x7fe1
	    void AddRadialForce(struct FVector Origin, float Radius, float Strength, char Falloff, bool bAccelChange); // 0x0 Size: 0x7fe1
	    char UnknownData107[0x7fe1]; // 0x7fe1
	    void AddImpulseAtLocation(struct FVector Impulse, struct FVector Location, FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData108[0x7fe1]; // 0x7fe1
	    void AddImpulse(struct FVector Impulse, FName BoneName, bool bVelChange); // 0x0 Size: 0x7fe1
	    char UnknownData109[0x7fe1]; // 0x7fe1
	    void AddForceAtLocationLocal(struct FVector Force, struct FVector Location, FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData110[0x7fe1]; // 0x7fe1
	    void AddForceAtLocation(struct FVector Force, struct FVector Location, FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData111[0x7fe1]; // 0x7fe1
	    void AddForce(struct FVector Force, FName BoneName, bool bAccelChange); // 0x0 Size: 0x7fe1
	    char UnknownData112[0x7fe1]; // 0x7fe1
	    void AddAngularImpulseInRadians(struct FVector Impulse, FName BoneName, bool bVelChange); // 0x0 Size: 0x7fe1
	    char UnknownData113[0x7fe1]; // 0x7fe1
	    void AddAngularImpulseInDegrees(struct FVector Impulse, FName BoneName, bool bVelChange); // 0x0 Size: 0x7fe1
	    char UnknownData114[0x7fe1]; // 0x7fe1
	    void AddAngularImpulse(struct FVector Impulse, FName BoneName, bool bVelChange); // 0x0 Size: 0x7fe1
	    char UnknownData115[0x-7a71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PrimitiveComponent");
			return (class UClass*)ptr;
		};

};

class UMeshComponent : public UPrimitiveComponent
{
	public:
	    TArray<class UMaterialInterface*> OverrideMaterials; // 0x570 Size: 0x10
	    bool bEnableMaterialParameterCaching; // 0x580 Size: 0x1
	    char UnknownData0[0x581]; // 0x581
	    void SetVectorParameterValueOnMaterials(FName ParameterName, struct FVector ParameterValue); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetScalarParameterValueOnMaterials(FName ParameterName, float ParameterValue); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void PrestreamTextures(float Seconds, bool bPrioritizeCharacterTextures, int CinematicTextureGroups); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool IsMaterialSlotNameValid(FName MaterialSlotName); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    TArray<FName> GetMaterialSlotNames(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    TArray<class UMaterialInterface*> GetMaterials(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    int GetMaterialIndex(FName MaterialSlotName); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7a41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MeshComponent");
			return (class UClass*)ptr;
		};

};

class USkinnedMeshComponent : public UMeshComponent
{
	public:
	    class USkeletalMesh* SkeletalMesh; // 0x5a0 Size: 0x8
	    TWeakObjectPtr<USkinnedMeshComponent*> MasterPoseComponent; // 0x5a8 Size: 0x8
	    char UnknownData0[0xa8]; // 0x5b0
	    class UPhysicsAsset* PhysicsAssetOverride; // 0x658 Size: 0x8
	    int ForcedLodModel; // 0x660 Size: 0x4
	    int MinLodModel; // 0x664 Size: 0x4
	    char UnknownData1[0x8]; // 0x668
	    float StreamingDistanceMultiplier; // 0x670 Size: 0x4
	    char UnknownData2[0xc]; // 0x674
	    TArray<struct FSkelMeshComponentLODInfo> LODInfo; // 0x680 Size: 0x10
	    char UnknownData3[0x24]; // 0x690
	    EVisibilityBasedAnimTickOption VisibilityBasedAnimTickOption; // 0x6b4 Size: 0x1
	    bool bOverrideMinLod; // 0x6b5 Size: 0x1
	    bool bUseBoundsFromMasterPoseComponent; // 0x6b5 Size: 0x1
	    bool bForceWireframe; // 0x6b5 Size: 0x1
	    bool bDisplayBones; // 0x6b5 Size: 0x1
	    bool bDisableMorphTarget; // 0x6b5 Size: 0x1
	    bool bHideSkin; // 0x6b5 Size: 0x1
	    bool bPerBoneMotionBlur; // 0x6b5 Size: 0x1
	    bool bComponentUseFixedSkelBounds; // 0x6b6 Size: 0x1
	    bool bConsiderAllBodiesForBounds; // 0x6b6 Size: 0x1
	    bool bSyncAttachParentLOD; // 0x6b6 Size: 0x1
	    bool bCanHighlightSelectedSections; // 0x6b6 Size: 0x1
	    bool bRecentlyRendered; // 0x6b6 Size: 0x1
	    bool bCastCapsuleDirectShadow; // 0x6b6 Size: 0x1
	    bool bCastCapsuleIndirectShadow; // 0x6b6 Size: 0x1
	    bool bCPUSkinning; // 0x6b6 Size: 0x1
	    bool bEnableUpdateRateOptimizations; // 0x6b7 Size: 0x1
	    bool bDisplayDebugUpdateRateOptimizations; // 0x6b7 Size: 0x1
	    bool bRenderStatic; // 0x6b7 Size: 0x1
	    bool bIgnoreMasterPoseComponentLOD; // 0x6b7 Size: 0x1
	    bool bCachedLocalBoundsUpToDate; // 0x6b7 Size: 0x1
	    bool bForceMeshObjectUpdate; // 0x6b7 Size: 0x1
	    char UnknownData4[0xe]; // 0x6ca
	    float CapsuleIndirectShadowMinVisibility; // 0x6bc Size: 0x4
	    char UnknownData5[0x8]; // 0x6c0
	    struct FBoxSphereBounds CachedLocalBounds; // 0x6c8 Size: 0x1c
	    char UnknownData6[0x6e4]; // 0x6e4
	    void UnHideBoneByName(FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void TransformToBoneSpace(FName BoneName, struct FVector InPosition, struct FRotator InRotation, struct FVector OutPosition, struct FRotator OutRotation); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void TransformFromBoneSpace(FName BoneName, struct FVector InPosition, struct FRotator InRotation, struct FVector OutPosition, struct FRotator OutRotation); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void ShowMaterialSection(int MaterialID, bool bShow, int LODIndex); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void ShowAllMaterialSections(int LODIndex); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetVertexColorOverride_LinearColor(int LODIndex, TArray<struct FLinearColor> VertexColors); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetSkinWeightOverride(int LODIndex, TArray<struct FSkelMeshSkinWeightInfo> SkinWeights); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void SetSkeletalMesh(class USkeletalMesh* NewMesh, bool bReinitPose); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void SetRenderStatic(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void SetPhysicsAsset(class UPhysicsAsset* NewPhysicsAsset, bool bForceReInit); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void SetMinLOD(int InNewMinLOD); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void SetMasterPoseComponent(class USkinnedMeshComponent* NewMasterBoneComponent, bool bForceUpdate); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void SetForcedLOD(int InNewForcedLOD); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void SetCastCapsuleIndirectShadow(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void SetCastCapsuleDirectShadow(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void SetCapsuleIndirectShadowMinVisibility(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    bool IsMaterialSectionShown(int MaterialID, int LODIndex); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    bool IsBoneHiddenByName(FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void HideBoneByName(FName BoneName, char PhysBodyOption); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    FName GetSocketBoneName(FName InSocketName); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    struct FVector GetRefPosePosition(int BoneIndex); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    FName GetParentBone(FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    int GetNumLODs(); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    int GetNumBones(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    struct FTransform GetDeltaTransformFromRefPose(FName BoneName, FName BaseName); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    FName GetBoneName(int BoneIndex); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    int GetBoneIndex(FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    FName FindClosestBone_K2(struct FVector TestLocation, struct FVector BoneLocation, float IgnoreScale, bool bRequirePhysicsAsset); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    void ClearVertexColorOverride(int LODIndex); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    void ClearSkinWeightOverride(int LODIndex); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    bool BoneIsChildOf(FName BoneName, FName ParentBoneName); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x-78e1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SkinnedMeshComponent");
			return (class UClass*)ptr;
		};

};

class USkeletalMeshComponent : public USkinnedMeshComponent
{
	public:
	    char UnknownData0[0x8];
	    class UObject* AnimBlueprintGeneratedClass; // 0x708 Size: 0x8
	    class UAnimInstance* AnimClass; // 0x710 Size: 0x8
	    class UAnimInstance* AnimScriptInstance; // 0x718 Size: 0x8
	    TArray<class UAnimInstance*> SubInstances; // 0x720 Size: 0x10
	    class UAnimInstance* PostProcessAnimInstance; // 0x730 Size: 0x8
	    struct FSingleAnimationPlayData AnimationData; // 0x738 Size: 0x18
	    char UnknownData1[0x10]; // 0x750
	    struct FVector RootBoneTranslation; // 0x760 Size: 0xc
	    struct FVector LineCheckBoundsScale; // 0x76c Size: 0xc
	    char UnknownData2[0x20]; // 0x778
	    TArray<struct FTransform> CachedBoneSpaceTransforms; // 0x798 Size: 0x10
	    TArray<struct FTransform> CachedComponentSpaceTransforms; // 0x7a8 Size: 0x10
	    char UnknownData3[0x20]; // 0x7b8
	    float GlobalAnimRateScale; // 0x7d8 Size: 0x4
	    EDynamicActorScene UseAsyncScene; // 0x7dc Size: 0x1
	    char KinematicBonesUpdateType; // 0x7dd Size: 0x1
	    char PhysicsTransformUpdateMode; // 0x7de Size: 0x1
	    char UnknownData4[0x1]; // 0x7df
	    char AnimationMode; // 0x7e0 Size: 0x1
	    bool bDisablePostProcessBlueprint; // 0x7e2 Size: 0x1
	    bool bUpdateOverlapsOnAnimationFinalize; // 0x7e2 Size: 0x1
	    bool bHasValidBodies; // 0x7e2 Size: 0x1
	    bool bBlendPhysics; // 0x7e2 Size: 0x1
	    bool bEnablePhysicsOnDedicatedServer; // 0x7e2 Size: 0x1
	    bool bUpdateJointsFromAnimation; // 0x7e3 Size: 0x1
	    bool bDisableClothSimulation; // 0x7e3 Size: 0x1
	    bool bAllowAnimCurveEvaluation; // 0x7e3 Size: 0x1
	    bool bDisableAnimCurves; // 0x7e3 Size: 0x1
	    bool bCollideWithEnvironment; // 0x7e3 Size: 0x1
	    bool bCollideWithAttachedChildren; // 0x7e4 Size: 0x1
	    bool bLocalSpaceSimulation; // 0x7e4 Size: 0x1
	    bool bResetAfterTeleport; // 0x7e4 Size: 0x1
	    bool bDeferKinematicBoneUpdate; // 0x7e4 Size: 0x1
	    bool bNoSkeletonUpdate; // 0x7e4 Size: 0x1
	    bool bPauseAnims; // 0x7e4 Size: 0x1
	    bool bUseRefPoseOnInitAnim; // 0x7e4 Size: 0x1
	    bool bEnablePerPolyCollision; // 0x7e5 Size: 0x1
	    bool bForceRefpose; // 0x7e5 Size: 0x1
	    bool bOnlyAllowAutonomousTickPose; // 0x7e5 Size: 0x1
	    bool bIsAutonomousTickPose; // 0x7e5 Size: 0x1
	    bool bOldForceRefPose; // 0x7e5 Size: 0x1
	    bool bShowPrePhysBones; // 0x7e5 Size: 0x1
	    bool bRequiredBonesUpToDate; // 0x7e5 Size: 0x1
	    bool bAnimTreeInitialised; // 0x7e5 Size: 0x1
	    bool bIncludeComponentLocationIntoBounds; // 0x7e6 Size: 0x1
	    bool bEnableLineCheckWithBounds; // 0x7e6 Size: 0x1
	    bool bUseBendingElements; // 0x7e6 Size: 0x1
	    bool bUseTetrahedralConstraints; // 0x7e6 Size: 0x1
	    bool bUseThinShellVolumeConstraints; // 0x7e6 Size: 0x1
	    bool bUseSelfCollisions; // 0x7e6 Size: 0x1
	    bool bUseContinuousCollisionDetection; // 0x7e6 Size: 0x1
	    bool bPropagateCurvesToSlaves; // 0x7e6 Size: 0x1
	    bool bSkipKinematicUpdateWhenInterpolating; // 0x7e7 Size: 0x1
	    bool bSkipBoundsUpdateWhenInterpolating; // 0x7e7 Size: 0x1
	    bool bNeedsQueuedAnimEventsDispatched; // 0x7e7 Size: 0x1
	    char UnknownData5[0x1d]; // 0x805
	    __int64/*UInt16Property*/ CachedAnimCurveUidVersion; // 0x7e8 Size: 0x2
	    char UnknownData6[0x2]; // 0x7ea
	    float ClothBlendWeight; // 0x7ec Size: 0x4
	    float EdgeStiffness; // 0x7f0 Size: 0x4
	    float BendingStiffness; // 0x7f4 Size: 0x4
	    float AreaStiffness; // 0x7f8 Size: 0x4
	    float VolumeStiffness; // 0x7fc Size: 0x4
	    float StrainLimitingStiffness; // 0x800 Size: 0x4
	    float ShapeTargetStiffness; // 0x804 Size: 0x4
	    TArray<FName> DisallowedAnimCurves; // 0x808 Size: 0x10
	    class UBodySetup* BodySetup; // 0x818 Size: 0x8
	    char UnknownData7[0x8]; // 0x820
	    MulticastDelegateProperty OnConstraintBroken; // 0x828 Size: 0x10
	    class UClothingSimulationFactory* ClothingSimulationFactory; // 0x838 Size: 0x8
	    char UnknownData8[0xf0]; // 0x840
	    float TeleportDistanceThreshold; // 0x930 Size: 0x4
	    float TeleportRotationThreshold; // 0x934 Size: 0x4
	    char UnknownData9[0x8]; // 0x938
	    uint32_t LastPoseTickFrame; // 0x940 Size: 0x4
	    char UnknownData10[0x5c]; // 0x944
	    class UClothingSimulationInteractor* ClothingInteractor; // 0x9a0 Size: 0x8
	    char UnknownData11[0xb8]; // 0x9a8
	    MulticastDelegateProperty OnAnimInitialized; // 0xa60 Size: 0x10
	    char UnknownData12[0xa70]; // 0xa70
	    void UnbindClothFromMasterPoseComponent(bool bRestoreSimulationSpace); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void ToggleDisablePostProcessBlueprint(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void TermBodiesBelow(FName ParentBoneName); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void SuspendClothingSimulation(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void Stop(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void SnapshotPose(struct FPoseSnapshot Snapshot); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void SetUpdateAnimationInEditor(bool NewUpdateState); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void SetTeleportRotationThreshold(float Threshold); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void SetTeleportDistanceThreshold(float Threshold); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void SetPosition(float InPos, bool bFireNotifies); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void SetPlayRate(float Rate); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void SetPhysicsBlendWeight(float PhysicsBlendWeight); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void SetNotifyRigidBodyCollisionBelow(bool bNewNotifyRigidBodyCollision, FName BoneName, bool bIncludeSelf); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void SetMorphTarget(FName MorphTargetName, float Value, bool bRemoveZeroWeight); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void SetEnablePhysicsBlending(bool bNewBlendPhysics); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void SetEnableGravityOnAllBodiesBelow(bool bEnableGravity, FName BoneName, bool bIncludeSelf); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void SetEnableBodyGravity(bool bEnableGravity, FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    void SetDisablePostProcessBlueprint(bool bInDisablePostProcess); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    void SetDisableAnimCurves(bool bInDisableAnimCurves); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    void SetConstraintProfileForAll(FName ProfileName, bool bDefaultIfNotFound); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    void SetConstraintProfile(FName JointName, FName ProfileName, bool bDefaultIfNotFound); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    void SetClothMaxDistanceScale(float Scale); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    void SetBodyNotifyRigidBodyCollision(bool bNewNotifyRigidBodyCollision, FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    void SetAnimationMode(char InAnimationMode); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    void SetAnimation(class UAnimationAsset* NewAnimToPlay); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    void SetAngularLimits(FName InBoneName, float Swing1LimitAngle, float TwistLimitAngle, float Swing2LimitAngle); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    void SetAllowedAnimCurvesEvaluation(TArray<FName> List, bool bAllow); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    void SetAllowAnimCurveEvaluation(bool bInAllow); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    void SetAllMotorsAngularVelocityDrive(bool bEnableSwingDrive, bool bEnableTwistDrive, bool bSkipCustomPhysicsType); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    void SetAllMotorsAngularPositionDrive(bool bEnableSwingDrive, bool bEnableTwistDrive, bool bSkipCustomPhysicsType); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    void SetAllMotorsAngularDriveParams(float InSpring, float InDamping, float InForceLimit, bool bSkipCustomPhysicsType); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    void SetAllBodiesSimulatePhysics(bool bNewSimulate); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    void SetAllBodiesPhysicsBlendWeight(float PhysicsBlendWeight, bool bSkipCustomPhysicsType); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    void SetAllBodiesBelowSimulatePhysics(FName InBoneName, bool bNewSimulate, bool bIncludeSelf); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    void SetAllBodiesBelowPhysicsBlendWeight(FName InBoneName, float PhysicsBlendWeight, bool bSkipCustomPhysicsType, bool bIncludeSelf); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    void ResumeClothingSimulation(); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    void ResetClothTeleportMode(); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    void ResetAnimInstanceDynamics(ETeleportType InTeleportType); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    void ResetAllowedAnimCurveEvaluation(); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    void ResetAllBodiesSimulatePhysics(); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    void PlayAnimation(class UAnimationAsset* NewAnimToPlay, bool bLooping); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    void Play(bool bLooping); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    void OverrideAnimationData(class UAnimationAsset* InAnimToPlay, bool bIsLooping, bool bIsPlaying, float Position, float PlayRate); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    void K2_SetAnimInstanceClass(class UObject* NewClass); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    bool K2_GetClosestPointOnPhysicsAsset(struct FVector WorldPosition, struct FVector ClosestWorldPosition, struct FVector Normal, FName BoneName, float Distance); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    bool IsPlaying(); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    bool IsClothingSimulationSuspended(); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    bool IsBodyGravityEnabled(FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    bool HasValidAnimationInstance(); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    float GetTeleportRotationThreshold(); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x7fe1]; // 0x7fe1
	    float GetTeleportDistanceThreshold(); // 0x0 Size: 0x7fe1
	    char UnknownData63[0x7fe1]; // 0x7fe1
	    class UAnimInstance* GetSubInstanceByName(FName InName); // 0x0 Size: 0x7fe1
	    char UnknownData64[0x7fe1]; // 0x7fe1
	    struct FVector GetSkeletalCenterOfMass(); // 0x0 Size: 0x7fe1
	    char UnknownData65[0x7fe1]; // 0x7fe1
	    class UAnimInstance* GetPostProcessInstance(); // 0x0 Size: 0x7fe1
	    char UnknownData66[0x7fe1]; // 0x7fe1
	    float GetPosition(); // 0x0 Size: 0x7fe1
	    char UnknownData67[0x7fe1]; // 0x7fe1
	    float GetPlayRate(); // 0x0 Size: 0x7fe1
	    char UnknownData68[0x7fe1]; // 0x7fe1
	    float GetMorphTarget(FName MorphTargetName); // 0x0 Size: 0x7fe1
	    char UnknownData69[0x7fe1]; // 0x7fe1
	    bool GetDisablePostProcessBlueprint(); // 0x0 Size: 0x7fe1
	    char UnknownData70[0x7fe1]; // 0x7fe1
	    bool GetDisableAnimCurves(); // 0x0 Size: 0x7fe1
	    char UnknownData71[0x7fe1]; // 0x7fe1
	    void GetCurrentJointAngles(FName InBoneName, float Swing1Angle, float TwistAngle, float Swing2Angle); // 0x0 Size: 0x7fe1
	    char UnknownData72[0x7fe1]; // 0x7fe1
	    float GetClothMaxDistanceScale(); // 0x0 Size: 0x7fe1
	    char UnknownData73[0x7fe1]; // 0x7fe1
	    class UClothingSimulationInteractor* GetClothingSimulationInteractor(); // 0x0 Size: 0x7fe1
	    char UnknownData74[0x7fe1]; // 0x7fe1
	    float GetBoneMass(FName BoneName, bool bScaleMass); // 0x0 Size: 0x7fe1
	    char UnknownData75[0x7fe1]; // 0x7fe1
	    class UAnimInstance* GetAnimInstance(); // 0x0 Size: 0x7fe1
	    char UnknownData76[0x7fe1]; // 0x7fe1
	    char GetAnimationMode(); // 0x0 Size: 0x7fe1
	    char UnknownData77[0x7fe1]; // 0x7fe1
	    bool GetAllowedAnimCurveEvaluate(); // 0x0 Size: 0x7fe1
	    char UnknownData78[0x7fe1]; // 0x7fe1
	    void ForceClothNextUpdateTeleportAndReset(); // 0x0 Size: 0x7fe1
	    char UnknownData79[0x7fe1]; // 0x7fe1
	    void ForceClothNextUpdateTeleport(); // 0x0 Size: 0x7fe1
	    char UnknownData80[0x7fe1]; // 0x7fe1
	    FName FindConstraintBoneName(int ConstraintIndex); // 0x0 Size: 0x7fe1
	    char UnknownData81[0x7fe1]; // 0x7fe1
	    void ClearMorphTargets(); // 0x0 Size: 0x7fe1
	    char UnknownData82[0x7fe1]; // 0x7fe1
	    void BreakConstraint(struct FVector Impulse, struct FVector HitLocation, FName InBoneName); // 0x0 Size: 0x7fe1
	    char UnknownData83[0x7fe1]; // 0x7fe1
	    void BindClothToMasterPoseComponent(); // 0x0 Size: 0x7fe1
	    char UnknownData84[0x7fe1]; // 0x7fe1
	    void AllowAnimCurveEvaluation(FName NameOfCurve, bool bAllow); // 0x0 Size: 0x7fe1
	    char UnknownData85[0x7fe1]; // 0x7fe1
	    void AddImpulseToAllBodiesBelow(struct FVector Impulse, FName BoneName, bool bVelChange, bool bIncludeSelf); // 0x0 Size: 0x7fe1
	    char UnknownData86[0x7fe1]; // 0x7fe1
	    void AddForceToAllBodiesBelow(struct FVector Force, FName BoneName, bool bAccelChange, bool bIncludeSelf); // 0x0 Size: 0x7fe1
	    char UnknownData87[0x7fe1]; // 0x7fe1
	    void AccumulateAllBodiesBelowPhysicsBlendWeight(FName InBoneName, float AddPhysicsBlendWeight, bool bSkipCustomPhysicsType); // 0x0 Size: 0x7fe1
	    char UnknownData88[0x-7421];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SkeletalMeshComponent");
			return (class UClass*)ptr;
		};

};

class UAnimInstance : public UObject
{
	public:
	    class USkeleton* CurrentSkeleton; // 0x28 Size: 0x8
	    char RootMotionMode; // 0x30 Size: 0x1
	    bool bUseMultiThreadedAnimationUpdate; // 0x31 Size: 0x1
	    bool bUsingCopyPoseFromMesh; // 0x31 Size: 0x1
	    bool bQueueMontageEvents; // 0x31 Size: 0x1
	    char UnknownData0[0x4]; // 0x34
	    MulticastDelegateProperty OnMontageBlendingOut; // 0x38 Size: 0x10
	    MulticastDelegateProperty OnMontageStarted; // 0x48 Size: 0x10
	    MulticastDelegateProperty OnMontageEnded; // 0x58 Size: 0x10
	    MulticastDelegateProperty OnAllMontageInstancesEnded; // 0x68 Size: 0x10
	    char UnknownData1[0x88]; // 0x78
	    struct FAnimNotifyQueue NotifyQueue; // 0x100 Size: 0x70
	    TArray<struct FAnimNotifyEvent> ActiveAnimNotifyState; // 0x170 Size: 0x10
	    char UnknownData2[0x180]; // 0x180
	    void UnlockAIResources(bool bUnlockMovement, bool UnlockAILogic); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    class APawn* TryGetPawnOwner(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void StopSlotAnimation(float InBlendOutTime, FName SlotNodeName); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SnapshotPose(struct FPoseSnapshot Snapshot); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetRootMotionMode(char Value); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetMorphTarget(FName MorphTargetName, float Value); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SavePoseSnapshot(FName SnapshotName); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void ResetDynamics(ETeleportType InTeleportType); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    class UAnimMontage* PlaySlotAnimationAsDynamicMontage(class UAnimSequenceBase* Asset, FName SlotNodeName, float BlendInTime, float BlendOutTime, float InPlayRate, int LoopCount, float BlendOutTriggerTime, float InTimeToStartMontageAt); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    float PlaySlotAnimation(class UAnimSequenceBase* Asset, FName SlotNodeName, float BlendInTime, float BlendOutTime, float InPlayRate, int LoopCount); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void Montage_Stop(float InBlendOutTime, class UAnimMontage* Montage); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void Montage_SetPosition(class UAnimMontage* Montage, float NewPosition); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void Montage_SetPlayRate(class UAnimMontage* Montage, float NewPlayRate); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void Montage_SetNextSection(FName SectionNameToChange, FName NextSection, class UAnimMontage* Montage); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void Montage_Resume(class UAnimMontage* Montage); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    float Montage_Play(class UAnimMontage* MontageToPlay, float InPlayRate, EMontagePlayReturnType ReturnValueType, float InTimeToStartMontageAt, bool bStopAllMontages); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void Montage_Pause(class UAnimMontage* Montage); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void Montage_JumpToSectionsEnd(FName SectionName, class UAnimMontage* Montage); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void Montage_JumpToSection(FName SectionName, class UAnimMontage* Montage); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    bool Montage_IsPlaying(class UAnimMontage* Montage); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    bool Montage_IsActive(class UAnimMontage* Montage); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    float Montage_GetPosition(class UAnimMontage* Montage); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    float Montage_GetPlayRate(class UAnimMontage* Montage); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    bool Montage_GetIsStopped(class UAnimMontage* Montage); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    FName Montage_GetCurrentSection(class UAnimMontage* Montage); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    float Montage_GetBlendTime(class UAnimMontage* Montage); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void LockAIResources(bool bLockMovement, bool LockAILogic); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    bool IsSyncGroupBetweenMarkers(FName InSyncGroupName, FName PreviousMarker, FName NextMarker, bool bRespectMarkerOrder); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    bool IsPlayingSlotAnimation(class UAnimSequenceBase* Asset, FName SlotNodeName); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    bool IsAnyMontagePlaying(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    bool HasMarkerBeenHitThisFrame(FName SyncGroup, FName MarkerName); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    bool GetTimeToClosestMarker(FName SyncGroup, FName MarkerName, float OutMarkerTime); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    struct FMarkerSyncAnimPosition GetSyncGroupPosition(FName InSyncGroupName); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    float GetRelevantAnimTimeRemainingFraction(int MachineIndex, int StateIndex); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    float GetRelevantAnimTimeRemaining(int MachineIndex, int StateIndex); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    float GetRelevantAnimTimeFraction(int MachineIndex, int StateIndex); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    float GetRelevantAnimTime(int MachineIndex, int StateIndex); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    float GetRelevantAnimLength(int MachineIndex, int StateIndex); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    class USkeletalMeshComponent* GetOwningComponent(); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    class AActor* GetOwningActor(); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    float GetInstanceTransitionTimeElapsedFraction(int MachineIndex, int TransitionIndex); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    float GetInstanceTransitionTimeElapsed(int MachineIndex, int TransitionIndex); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    float GetInstanceTransitionCrossfadeDuration(int MachineIndex, int TransitionIndex); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    float GetInstanceStateWeight(int MachineIndex, int StateIndex); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    float GetInstanceMachineWeight(int MachineIndex); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    float GetInstanceCurrentStateElapsedTime(int MachineIndex); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    float GetInstanceAssetPlayerTimeFromEndFraction(int AssetPlayerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    float GetInstanceAssetPlayerTimeFromEnd(int AssetPlayerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    float GetInstanceAssetPlayerTimeFraction(int AssetPlayerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    float GetInstanceAssetPlayerTime(int AssetPlayerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    float GetInstanceAssetPlayerLength(int AssetPlayerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    float GetCurveValue(FName CurveName); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    FName GetCurrentStateName(int MachineIndex); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    class UAnimMontage* GetCurrentActiveMontage(); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    void GetAllCurveNames(TArray<FName> OutNames); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    void GetActiveCurveNames(EAnimCurveType CurveType, TArray<FName> OutNames); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    void ClearMorphTargets(); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    float CalculateDirection(struct FVector Velocity, struct FRotator BaseRotation); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    void BlueprintUpdateAnimation(float DeltaTimeX); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    void BlueprintPostEvaluateAnimation(); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x7fe1]; // 0x7fe1
	    void BlueprintInitializeAnimation(); // 0x0 Size: 0x7fe1
	    char UnknownData63[0x7fe1]; // 0x7fe1
	    void BlueprintBeginPlay(); // 0x0 Size: 0x7fe1
	    char UnknownData64[0x-7d71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimInstance");
			return (class UClass*)ptr;
		};

};

class UEngine : public UObject
{
	public:
	    char UnknownData0[0x8];
	    class UFont* TinyFont; // 0x30 Size: 0x8
	    struct FSoftObjectPath TinyFontName; // 0x38 Size: 0x18
	    class UFont* SmallFont; // 0x50 Size: 0x8
	    struct FSoftObjectPath SmallFontName; // 0x58 Size: 0x18
	    class UFont* MediumFont; // 0x70 Size: 0x8
	    struct FSoftObjectPath MediumFontName; // 0x78 Size: 0x18
	    class UFont* LargeFont; // 0x90 Size: 0x8
	    struct FSoftObjectPath LargeFontName; // 0x98 Size: 0x18
	    class UFont* SubtitleFont; // 0xb0 Size: 0x8
	    struct FSoftObjectPath SubtitleFontName; // 0xb8 Size: 0x18
	    TArray<class UFont*> AdditionalFonts; // 0xd0 Size: 0x10
	    char UnknownData1[0x8]; // 0xe0
	    TArray<struct FString> AdditionalFontNames; // 0xe8 Size: 0x10
	    class UConsole* ConsoleClass; // 0xf8 Size: 0x8
	    struct FSoftClassPath ConsoleClassName; // 0x100 Size: 0x18
	    class UGameViewportClient* GameViewportClientClass; // 0x118 Size: 0x8
	    struct FSoftClassPath GameViewportClientClassName; // 0x120 Size: 0x18
	    class ULocalPlayer* LocalPlayerClass; // 0x138 Size: 0x8
	    struct FSoftClassPath LocalPlayerClassName; // 0x140 Size: 0x18
	    class AWorldSettings* WorldSettingsClass; // 0x158 Size: 0x8
	    struct FSoftClassPath WorldSettingsClassName; // 0x160 Size: 0x18
	    struct FSoftClassPath NavigationSystemClassName; // 0x178 Size: 0x18
	    class UNavigationSystemBase* NavigationSystemClass; // 0x190 Size: 0x8
	    struct FSoftClassPath NavigationSystemConfigClassName; // 0x198 Size: 0x18
	    class UNavigationSystemConfig* NavigationSystemConfigClass; // 0x1b0 Size: 0x8
	    struct FSoftClassPath AvoidanceManagerClassName; // 0x1b8 Size: 0x18
	    class UAvoidanceManager* AvoidanceManagerClass; // 0x1d0 Size: 0x8
	    class UPhysicsCollisionHandler* PhysicsCollisionHandlerClass; // 0x1d8 Size: 0x8
	    struct FSoftClassPath PhysicsCollisionHandlerClassName; // 0x1e0 Size: 0x18
	    struct FSoftClassPath GameUserSettingsClassName; // 0x1f8 Size: 0x18
	    class UGameUserSettings* GameUserSettingsClass; // 0x210 Size: 0x8
	    struct FSoftClassPath AIControllerClassName; // 0x218 Size: 0x18
	    class UGameUserSettings* GameUserSettings; // 0x230 Size: 0x8
	    class ALevelScriptActor* LevelScriptActorClass; // 0x238 Size: 0x8
	    struct FSoftClassPath LevelScriptActorClassName; // 0x240 Size: 0x18
	    struct FSoftClassPath DefaultBlueprintBaseClassName; // 0x258 Size: 0x18
	    struct FSoftClassPath GameSingletonClassName; // 0x270 Size: 0x18
	    class UObject* GameSingleton; // 0x288 Size: 0x8
	    struct FSoftClassPath AssetManagerClassName; // 0x290 Size: 0x18
	    class UAssetManager* AssetManager; // 0x2a8 Size: 0x8
	    class UTexture2D* DefaultTexture; // 0x2b0 Size: 0x8
	    struct FSoftObjectPath DefaultTextureName; // 0x2b8 Size: 0x18
	    class UTexture* DefaultDiffuseTexture; // 0x2d0 Size: 0x8
	    struct FSoftObjectPath DefaultDiffuseTextureName; // 0x2d8 Size: 0x18
	    class UTexture2D* DefaultBSPVertexTexture; // 0x2f0 Size: 0x8
	    struct FSoftObjectPath DefaultBSPVertexTextureName; // 0x2f8 Size: 0x18
	    class UTexture2D* HighFrequencyNoiseTexture; // 0x310 Size: 0x8
	    struct FSoftObjectPath HighFrequencyNoiseTextureName; // 0x318 Size: 0x18
	    class UTexture2D* DefaultBokehTexture; // 0x330 Size: 0x8
	    struct FSoftObjectPath DefaultBokehTextureName; // 0x338 Size: 0x18
	    class UTexture2D* DefaultBloomKernelTexture; // 0x350 Size: 0x8
	    struct FSoftObjectPath DefaultBloomKernelTextureName; // 0x358 Size: 0x18
	    class UMaterial* WireframeMaterial; // 0x370 Size: 0x8
	    struct FString WireframeMaterialName; // 0x378 Size: 0x10
	    class UMaterial* DebugMeshMaterial; // 0x388 Size: 0x8
	    struct FSoftObjectPath DebugMeshMaterialName; // 0x390 Size: 0x18
	    class UMaterial* LevelColorationLitMaterial; // 0x3a8 Size: 0x8
	    struct FString LevelColorationLitMaterialName; // 0x3b0 Size: 0x10
	    class UMaterial* LevelColorationUnlitMaterial; // 0x3c0 Size: 0x8
	    struct FString LevelColorationUnlitMaterialName; // 0x3c8 Size: 0x10
	    class UMaterial* LightingTexelDensityMaterial; // 0x3d8 Size: 0x8
	    struct FString LightingTexelDensityName; // 0x3e0 Size: 0x10
	    class UMaterial* ShadedLevelColorationLitMaterial; // 0x3f0 Size: 0x8
	    struct FString ShadedLevelColorationLitMaterialName; // 0x3f8 Size: 0x10
	    class UMaterial* ShadedLevelColorationUnlitMaterial; // 0x408 Size: 0x8
	    struct FString ShadedLevelColorationUnlitMaterialName; // 0x410 Size: 0x10
	    class UMaterial* RemoveSurfaceMaterial; // 0x420 Size: 0x8
	    struct FSoftObjectPath RemoveSurfaceMaterialName; // 0x428 Size: 0x18
	    class UMaterial* VertexColorMaterial; // 0x440 Size: 0x8
	    struct FString VertexColorMaterialName; // 0x448 Size: 0x10
	    class UMaterial* VertexColorViewModeMaterial_ColorOnly; // 0x458 Size: 0x8
	    struct FString VertexColorViewModeMaterialName_ColorOnly; // 0x460 Size: 0x10
	    class UMaterial* VertexColorViewModeMaterial_AlphaAsColor; // 0x470 Size: 0x8
	    struct FString VertexColorViewModeMaterialName_AlphaAsColor; // 0x478 Size: 0x10
	    class UMaterial* VertexColorViewModeMaterial_RedOnly; // 0x488 Size: 0x8
	    struct FString VertexColorViewModeMaterialName_RedOnly; // 0x490 Size: 0x10
	    class UMaterial* VertexColorViewModeMaterial_GreenOnly; // 0x4a0 Size: 0x8
	    struct FString VertexColorViewModeMaterialName_GreenOnly; // 0x4a8 Size: 0x10
	    class UMaterial* VertexColorViewModeMaterial_BlueOnly; // 0x4b8 Size: 0x8
	    struct FString VertexColorViewModeMaterialName_BlueOnly; // 0x4c0 Size: 0x10
	    struct FSoftObjectPath DebugEditorMaterialName; // 0x4d0 Size: 0x18
	    class UMaterial* ConstraintLimitMaterial; // 0x4e8 Size: 0x8
	    class UMaterialInstanceDynamic* ConstraintLimitMaterialX; // 0x4f0 Size: 0x8
	    class UMaterialInstanceDynamic* ConstraintLimitMaterialXAxis; // 0x4f8 Size: 0x8
	    class UMaterialInstanceDynamic* ConstraintLimitMaterialY; // 0x500 Size: 0x8
	    class UMaterialInstanceDynamic* ConstraintLimitMaterialYAxis; // 0x508 Size: 0x8
	    class UMaterialInstanceDynamic* ConstraintLimitMaterialZ; // 0x510 Size: 0x8
	    class UMaterialInstanceDynamic* ConstraintLimitMaterialZAxis; // 0x518 Size: 0x8
	    class UMaterialInstanceDynamic* ConstraintLimitMaterialPrismatic; // 0x520 Size: 0x8
	    class UMaterial* InvalidLightmapSettingsMaterial; // 0x528 Size: 0x8
	    struct FSoftObjectPath InvalidLightmapSettingsMaterialName; // 0x530 Size: 0x18
	    class UMaterial* PreviewShadowsIndicatorMaterial; // 0x548 Size: 0x8
	    struct FSoftObjectPath PreviewShadowsIndicatorMaterialName; // 0x550 Size: 0x18
	    class UMaterial* ArrowMaterial; // 0x568 Size: 0x8
	    struct FSoftObjectPath ArrowMaterialName; // 0x570 Size: 0x18
	    struct FLinearColor LightingOnlyBrightness; // 0x588 Size: 0x10
	    TArray<struct FLinearColor> ShaderComplexityColors; // 0x598 Size: 0x10
	    TArray<struct FLinearColor> QuadComplexityColors; // 0x5a8 Size: 0x10
	    TArray<struct FLinearColor> LightComplexityColors; // 0x5b8 Size: 0x10
	    TArray<struct FLinearColor> StationaryLightOverlapColors; // 0x5c8 Size: 0x10
	    TArray<struct FLinearColor> LODColorationColors; // 0x5d8 Size: 0x10
	    TArray<struct FLinearColor> HLODColorationColors; // 0x5e8 Size: 0x10
	    TArray<struct FLinearColor> StreamingAccuracyColors; // 0x5f8 Size: 0x10
	    float MaxPixelShaderAdditiveComplexityCount; // 0x608 Size: 0x4
	    float MaxES2PixelShaderAdditiveComplexityCount; // 0x60c Size: 0x4
	    float MaxES3PixelShaderAdditiveComplexityCount; // 0x610 Size: 0x4
	    float MinLightMapDensity; // 0x614 Size: 0x4
	    float IdealLightMapDensity; // 0x618 Size: 0x4
	    float MaxLightMapDensity; // 0x61c Size: 0x4
	    bool bRenderLightMapDensityGrayscale; // 0x620 Size: 0x1
	    char UnknownData2[0x3]; // 0x621
	    float RenderLightMapDensityGrayscaleScale; // 0x624 Size: 0x4
	    float RenderLightMapDensityColorScale; // 0x628 Size: 0x4
	    struct FLinearColor LightMapDensityVertexMappedColor; // 0x62c Size: 0x10
	    struct FLinearColor LightMapDensitySelectedColor; // 0x63c Size: 0x10
	    char UnknownData3[0x4]; // 0x64c
	    TArray<struct FStatColorMapping> StatColorMappings; // 0x650 Size: 0x10
	    class UPhysicalMaterial* DefaultPhysMaterial; // 0x660 Size: 0x8
	    struct FSoftObjectPath DefaultPhysMaterialName; // 0x668 Size: 0x18
	    TArray<struct FGameNameRedirect> ActiveGameNameRedirects; // 0x680 Size: 0x10
	    TArray<struct FClassRedirect> ActiveClassRedirects; // 0x690 Size: 0x10
	    TArray<struct FPluginRedirect> ActivePluginRedirects; // 0x6a0 Size: 0x10
	    TArray<struct FStructRedirect> ActiveStructRedirects; // 0x6b0 Size: 0x10
	    class UTexture2D* PreIntegratedSkinBRDFTexture; // 0x6c0 Size: 0x8
	    struct FSoftObjectPath PreIntegratedSkinBRDFTextureName; // 0x6c8 Size: 0x18
	    class UTexture2D* MiniFontTexture; // 0x6e0 Size: 0x8
	    struct FSoftObjectPath MiniFontTextureName; // 0x6e8 Size: 0x18
	    class UTexture* WeightMapPlaceholderTexture; // 0x700 Size: 0x8
	    struct FSoftObjectPath WeightMapPlaceholderTextureName; // 0x708 Size: 0x18
	    class UTexture2D* LightMapDensityTexture; // 0x720 Size: 0x8
	    struct FSoftObjectPath LightMapDensityTextureName; // 0x728 Size: 0x18
	    char UnknownData4[0x8]; // 0x740
	    class UGameViewportClient* GameViewport; // 0x748 Size: 0x8
	    TArray<struct FString> DeferredCommands; // 0x750 Size: 0x10
	    int TickCycles; // 0x760 Size: 0x4
	    int GameCycles; // 0x764 Size: 0x4
	    int ClientCycles; // 0x768 Size: 0x4
	    float NearClipPlane; // 0x76c Size: 0x4
	    bool bHardwareSurveyEnabled; // 0x770 Size: 0x1
	    bool bSubtitlesEnabled; // 0x770 Size: 0x1
	    bool bSubtitlesForcedOff; // 0x770 Size: 0x1
	    char UnknownData5[0x1]; // 0x773
	    int MaximumLoopIterationCount; // 0x774 Size: 0x4
	    bool bCanBlueprintsTickByDefault; // 0x778 Size: 0x1
	    bool bOptimizeAnimBlueprintMemberVariableAccess; // 0x778 Size: 0x1
	    bool bAllowMultiThreadedAnimationUpdate; // 0x778 Size: 0x1
	    bool bEnableEditorPSysRealtimeLOD; // 0x778 Size: 0x1
	    bool bSmoothFrameRate; // 0x778 Size: 0x1
	    bool bUseFixedFrameRate; // 0x778 Size: 0x1
	    char UnknownData6[0x2]; // 0x77e
	    float FixedFrameRate; // 0x77c Size: 0x4
	    struct FFloatRange SmoothedFrameRateRange; // 0x780 Size: 0x10
	    class UEngineCustomTimeStep* DefaultCustomTimeStep; // 0x790 Size: 0x8
	    class UEngineCustomTimeStep* CurrentCustomTimeStep; // 0x798 Size: 0x8
	    struct FSoftClassPath CustomTimeStepClassName; // 0x7a0 Size: 0x18
	    class UTimecodeProvider* DefaultTimecodeProvider; // 0x7b8 Size: 0x8
	    class UTimecodeProvider* CustomTimecodeProvider; // 0x7c0 Size: 0x8
	    struct FSoftClassPath DefaultTimecodeProviderClassName; // 0x7c8 Size: 0x18
	    struct FSoftClassPath TimecodeProviderClassName; // 0x7e0 Size: 0x18
	    struct FFrameRate DefaultTimecodeFrameRate; // 0x7f8 Size: 0x8
	    bool bCheckForMultiplePawnsSpawnedInAFrame; // 0x800 Size: 0x1
	    char UnknownData7[0x3]; // 0x801
	    int NumPawnsAllowedToBeSpawnedInAFrame; // 0x804 Size: 0x4
	    bool bShouldGenerateLowQualityLightmaps; // 0x808 Size: 0x1
	    char UnknownData8[0x3]; // 0x809
	    struct FColor C_WorldBox; // 0x80c Size: 0x4
	    struct FColor C_BrushWire; // 0x810 Size: 0x4
	    struct FColor C_AddWire; // 0x814 Size: 0x4
	    struct FColor C_SubtractWire; // 0x818 Size: 0x4
	    struct FColor C_SemiSolidWire; // 0x81c Size: 0x4
	    struct FColor C_NonSolidWire; // 0x820 Size: 0x4
	    struct FColor C_WireBackground; // 0x824 Size: 0x4
	    struct FColor C_ScaleBoxHi; // 0x828 Size: 0x4
	    struct FColor C_VolumeCollision; // 0x82c Size: 0x4
	    struct FColor C_BSPCollision; // 0x830 Size: 0x4
	    struct FColor C_OrthoBackground; // 0x834 Size: 0x4
	    struct FColor C_Volume; // 0x838 Size: 0x4
	    struct FColor C_BrushShape; // 0x83c Size: 0x4
	    float StreamingDistanceFactor; // 0x840 Size: 0x4
	    char UnknownData9[0x4]; // 0x844
	    struct FDirectoryPath GameScreenshotSaveDirectory; // 0x848 Size: 0x10
	    char TransitionType; // 0x858 Size: 0x1
	    char UnknownData10[0x7]; // 0x859
	    struct FString TransitionDescription; // 0x860 Size: 0x10
	    struct FString TransitionGameMode; // 0x870 Size: 0x10
	    float MeshLODRange; // 0x880 Size: 0x4
	    bool bAllowMatureLanguage; // 0x884 Size: 0x1
	    char UnknownData11[0x3]; // 0x885
	    float CameraRotationThreshold; // 0x888 Size: 0x4
	    float CameraTranslationThreshold; // 0x88c Size: 0x4
	    float PrimitiveProbablyVisibleTime; // 0x890 Size: 0x4
	    float MaxOcclusionPixelsFraction; // 0x894 Size: 0x4
	    bool bPauseOnLossOfFocus; // 0x898 Size: 0x1
	    char UnknownData12[0x3]; // 0x899
	    int MaxParticleResize; // 0x89c Size: 0x4
	    int MaxParticleResizeWarn; // 0x8a0 Size: 0x4
	    char UnknownData13[0x4]; // 0x8a4
	    TArray<struct FDropNoteInfo> PendingDroppedNotes; // 0x8a8 Size: 0x10
	    float NetClientTicksPerSecond; // 0x8b8 Size: 0x4
	    float DisplayGamma; // 0x8bc Size: 0x4
	    float MinDesiredFrameRate; // 0x8c0 Size: 0x4
	    struct FLinearColor DefaultSelectedMaterialColor; // 0x8c4 Size: 0x10
	    struct FLinearColor SelectedMaterialColor; // 0x8d4 Size: 0x10
	    struct FLinearColor SelectionOutlineColor; // 0x8e4 Size: 0x10
	    struct FLinearColor SubduedSelectionOutlineColor; // 0x8f4 Size: 0x10
	    struct FLinearColor SelectedMaterialColorOverride; // 0x904 Size: 0x10
	    bool bIsOverridingSelectedColor; // 0x914 Size: 0x1
	    bool bEnableOnScreenDebugMessages; // 0x918 Size: 0x1
	    bool bEnableOnScreenDebugMessagesDisplay; // 0x918 Size: 0x1
	    bool bSuppressMapWarnings; // 0x918 Size: 0x1
	    bool bDisableAILogging; // 0x918 Size: 0x1
	    char UnknownData14[0x3]; // 0x919
	    uint32_t bEnableVisualLogRecordingOnStart; // 0x91c Size: 0x4
	    char UnknownData15[0x4]; // 0x920
	    int ScreenSaverInhibitorSemaphore; // 0x924 Size: 0x4
	    bool bLockReadOnlyLevels; // 0x928 Size: 0x1
	    char UnknownData16[0x7]; // 0x929
	    struct FString ParticleEventManagerClassPath; // 0x930 Size: 0x10
	    char UnknownData17[0x10]; // 0x940
	    float SelectionHighlightIntensity; // 0x950 Size: 0x4
	    float SelectionMeshSectionHighlightIntensity; // 0x954 Size: 0x4
	    float BSPSelectionHighlightIntensity; // 0x958 Size: 0x4
	    float HoverHighlightIntensity; // 0x95c Size: 0x4
	    float SelectionHighlightIntensityBillboards; // 0x960 Size: 0x4
	    char UnknownData18[0x22c]; // 0x964
	    TArray<struct FNetDriverDefinition> NetDriverDefinitions; // 0xb90 Size: 0x10
	    TArray<struct FString> ServerActors; // 0xba0 Size: 0x10
	    TArray<struct FString> RuntimeServerActors; // 0xbb0 Size: 0x10
	    bool bStartedLoadMapMovie; // 0xbc0 Size: 0x1
	    char UnknownData19[0x17]; // 0xbc1
	    int NextWorldContextHandle; // 0xbd8 Size: 0x4
	    char UnknownData20[0xcc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Engine");
			return (class UClass*)ptr;
		};

};

class UPlayer : public UObject
{
	public:
	    char UnknownData0[0x8];
	    class APlayerController* PlayerController; // 0x30 Size: 0x8
	    int CurrentNetSpeed; // 0x38 Size: 0x4
	    int ConfiguredInternetSpeed; // 0x3c Size: 0x4
	    int ConfiguredLanSpeed; // 0x40 Size: 0x4
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Player");
			return (class UClass*)ptr;
		};

};

class ULocalPlayer : public UPlayer
{
	public:
	    char UnknownData0[0x28];
	    class UGameViewportClient* ViewportClient; // 0x70 Size: 0x8
	    char UnknownData1[0x1c]; // 0x78
	    char AspectRatioAxisConstraint; // 0x94 Size: 0x1
	    char UnknownData2[0x3]; // 0x95
	    class APlayerController* PendingLevelPlayerControllerClass; // 0x98 Size: 0x8
	    bool bSentSplitJoin; // 0xa0 Size: 0x1
	    char UnknownData3[0x67]; // 0xa1
	    int ControllerId; // 0x108 Size: 0x4
	    char UnknownData4[0x19c];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LocalPlayer");
			return (class UClass*)ptr;
		};

};

class USubsystem : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Subsystem");
			return (class UClass*)ptr;
		};

};

class UGameInstance : public UObject
{
	public:
	    char UnknownData0[0x10];
	    TArray<class ULocalPlayer*> LocalPlayers; // 0x38 Size: 0x10
	    class UOnlineSession* OnlineSession; // 0x48 Size: 0x8
	    TArray<class UObject*> ReferencedObjects; // 0x50 Size: 0x10
	    char UnknownData1[0x60]; // 0x60
	    void ReceiveShutdown(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void ReceiveInit(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void HandleTravelError(char FailureType); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void HandleNetworkError(char FailureType, bool bIsServer); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void DebugRemovePlayer(int ControllerId); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void DebugCreatePlayer(int ControllerId); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7e79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.GameInstance");
			return (class UClass*)ptr;
		};

};

class UGameInstanceSubsystem : public USubsystem
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.GameInstanceSubsystem");
			return (class UClass*)ptr;
		};

};

class UBlueprintGeneratedClass : public UClass
{
	public:
	    int NumReplicatedProperties; // 0x208 Size: 0x4
	    bool bHasInstrumentation; // 0x20c Size: 0x1
	    bool bHasNativizedParent; // 0x20c Size: 0x1
	    bool bHasCookedComponentInstancingData; // 0x20c Size: 0x1
	    char UnknownData0[0x1]; // 0x20f
	    TArray<class UDynamicBlueprintBinding*> DynamicBindingObjects; // 0x210 Size: 0x10
	    TArray<class UActorComponent*> ComponentTemplates; // 0x220 Size: 0x10
	    TArray<class UTimelineTemplate*> Timelines; // 0x230 Size: 0x10
	    class USimpleConstructionScript* SimpleConstructionScript; // 0x240 Size: 0x8
	    class UInheritableComponentHandler* InheritableComponentHandler; // 0x248 Size: 0x8
	    class UFunction* UberGraphFunction; // 0x250 Size: 0x8
	    __int64/*MapProperty*/ CookedComponentInstancingData; // 0x258 Size: 0x50
	    char UnknownData1[0x38];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BlueprintGeneratedClass");
			return (class UClass*)ptr;
		};

};

class AActor : public UObject
{
	public:
	    struct FActorTickFunction PrimaryActorTick; // 0x28 Size: 0x58
	    bool bHidden; // 0x80 Size: 0x1
	    bool bNetTemporary; // 0x80 Size: 0x1
	    bool bNetStartup; // 0x80 Size: 0x1
	    bool bOnlyRelevantToOwner; // 0x80 Size: 0x1
	    bool bAlwaysRelevant; // 0x80 Size: 0x1
	    bool bReplicateMovement; // 0x80 Size: 0x1
	    bool bTearOff; // 0x80 Size: 0x1
	    bool bExchangedRoles; // 0x80 Size: 0x1
	    bool bNetLoadOnClient; // 0x81 Size: 0x1
	    bool bNetUseOwnerRelevancy; // 0x81 Size: 0x1
	    bool bRelevantForNetworkReplays; // 0x81 Size: 0x1
	    bool bRelevantForLevelBounds; // 0x81 Size: 0x1
	    bool bReplayRewindable; // 0x81 Size: 0x1
	    bool bAllowTickBeforeBeginPlay; // 0x81 Size: 0x1
	    bool bAutoDestroyWhenFinished; // 0x81 Size: 0x1
	    bool bBlockInput; // 0x81 Size: 0x1
	    bool bCanBeDamaged; // 0x82 Size: 0x1
	    bool bCollideWhenPlacing; // 0x82 Size: 0x1
	    bool bFindCameraComponentWhenViewTarget; // 0x82 Size: 0x1
	    bool bGenerateOverlapEventsDuringLevelStreaming; // 0x82 Size: 0x1
	    bool bIgnoresOriginShifting; // 0x82 Size: 0x1
	    bool bEnableAutoLODGeneration; // 0x82 Size: 0x1
	    bool bIsEditorOnlyActor; // 0x82 Size: 0x1
	    bool bActorSeamlessTraveled; // 0x82 Size: 0x1
	    bool bReplicates; // 0x83 Size: 0x1
	    bool bCanBeInCluster; // 0x83 Size: 0x1
	    bool bAllowReceiveTickEventOnDedicatedServer; // 0x83 Size: 0x1
	    bool bActorEnableCollision; // 0x84 Size: 0x1
	    bool bActorIsBeingDestroyed; // 0x84 Size: 0x1
	    char UnknownData0[0x18]; // 0x9d
	    char RemoteRole; // 0x85 Size: 0x1
	    char UnknownData1[0x2]; // 0x86
	    struct FRepMovement ReplicatedMovement; // 0x88 Size: 0x34
	    float InitialLifeSpan; // 0xbc Size: 0x4
	    float CustomTimeDilation; // 0xc0 Size: 0x4
	    char UnknownData2[0x4]; // 0xc4
	    struct FRepAttachment AttachmentReplication; // 0xc8 Size: 0x40
	    class AActor* Owner; // 0x108 Size: 0x8
	    FName NetDriverName; // 0x110 Size: 0x8
	    char Role; // 0x118 Size: 0x1
	    char NetDormancy; // 0x119 Size: 0x1
	    ESpawnActorCollisionHandlingMethod SpawnCollisionHandlingMethod; // 0x11a Size: 0x1
	    char AutoReceiveInput; // 0x11b Size: 0x1
	    int InputPriority; // 0x11c Size: 0x4
	    class UInputComponent* InputComponent; // 0x120 Size: 0x8
	    float NetCullDistanceSquared; // 0x128 Size: 0x4
	    int NetTag; // 0x12c Size: 0x4
	    float NetUpdateFrequency; // 0x130 Size: 0x4
	    float MinNetUpdateFrequency; // 0x134 Size: 0x4
	    float NetPriority; // 0x138 Size: 0x4
	    char UnknownData3[0x4]; // 0x13c
	    class APawn* Instigator; // 0x140 Size: 0x8
	    TArray<class AActor*> Children; // 0x148 Size: 0x10
	    class USceneComponent* RootComponent; // 0x158 Size: 0x8
	    TArray<class AMatineeActor*> ControllingMatineeActors; // 0x160 Size: 0x10
	    char UnknownData4[0x8]; // 0x170
	    TArray<FName> Layers; // 0x178 Size: 0x10
	    TWeakObjectPtr<UChildActorComponent*> ParentComponent; // 0x188 Size: 0x8
	    TArray<FName> Tags; // 0x190 Size: 0x10
	    MulticastDelegateProperty OnTakeAnyDamage; // 0x1a0 Size: 0x10
	    MulticastDelegateProperty OnTakePointDamage; // 0x1b0 Size: 0x10
	    MulticastDelegateProperty OnTakeRadialDamage; // 0x1c0 Size: 0x10
	    MulticastDelegateProperty OnActorBeginOverlap; // 0x1d0 Size: 0x10
	    MulticastDelegateProperty OnActorEndOverlap; // 0x1e0 Size: 0x10
	    MulticastDelegateProperty OnBeginCursorOver; // 0x1f0 Size: 0x10
	    MulticastDelegateProperty OnEndCursorOver; // 0x200 Size: 0x10
	    MulticastDelegateProperty OnClicked; // 0x210 Size: 0x10
	    MulticastDelegateProperty OnReleased; // 0x220 Size: 0x10
	    MulticastDelegateProperty OnInputTouchBegin; // 0x230 Size: 0x10
	    MulticastDelegateProperty OnInputTouchEnd; // 0x240 Size: 0x10
	    MulticastDelegateProperty OnInputTouchEnter; // 0x250 Size: 0x10
	    MulticastDelegateProperty OnInputTouchLeave; // 0x260 Size: 0x10
	    MulticastDelegateProperty OnActorHit; // 0x270 Size: 0x10
	    MulticastDelegateProperty OnDestroyed; // 0x280 Size: 0x10
	    MulticastDelegateProperty OnEndPlay; // 0x290 Size: 0x10
	    char UnknownData5[0x60]; // 0x2a0
	    TArray<class UActorComponent*> InstanceComponents; // 0x300 Size: 0x10
	    TArray<class UActorComponent*> BlueprintCreatedComponents; // 0x310 Size: 0x10
	    char UnknownData6[0x320]; // 0x320
	    bool WasRecentlyRendered(float Tolerance); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void UserConstructionScript(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void TearOff(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SnapRootComponentTo(class AActor* InParentActor, FName InSocketName); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetTickGroup(char NewTickGroup); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetTickableWhenPaused(bool bTickableWhenPaused); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetReplicates(bool bInReplicates); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void SetReplicateMovement(bool bInReplicateMovement); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void SetOwner(class AActor* NewOwner); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void SetNetDormancy(char NewDormancy); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void SetLifeSpan(float InLifespan); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void SetActorTickInterval(float TickInterval); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void SetActorTickEnabled(bool bEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void SetActorScale3D(struct FVector NewScale3D); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void SetActorRelativeScale3D(struct FVector NewRelativeScale); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void SetActorHiddenInGame(bool bNewHidden); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void SetActorEnableCollision(bool bNewActorEnableCollision); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void RemoveTickPrerequisiteComponent(class UActorComponent* PrerequisiteComponent); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void RemoveTickPrerequisiteActor(class AActor* PrerequisiteActor); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void ReceiveTick(float DeltaSeconds); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void ReceiveRadialDamage(float DamageReceived, class UDamageType* DamageType, struct FVector Origin, struct FHitResult HitInfo, class AController* InstigatedBy, class AActor* DamageCauser); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void ReceivePointDamage(float Damage, class UDamageType* DamageType, struct FVector HitLocation, struct FVector HitNormal, class UPrimitiveComponent* HitComponent, FName BoneName, struct FVector ShotFromDirection, class AController* InstigatedBy, class AActor* DamageCauser, struct FHitResult HitInfo); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void ReceiveHit(class UPrimitiveComponent* MyComp, class AActor* Other, class UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult Hit); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    void ReceiveEndPlay(char EndPlayReason); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    void ReceiveDestroyed(); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    void ReceiveBeginPlay(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    void ReceiveAnyDamage(float Damage, class UDamageType* DamageType, class AController* InstigatedBy, class AActor* DamageCauser); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    void ReceiveActorOnReleased(struct FKey ButtonReleased); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    void ReceiveActorOnInputTouchLeave(char FingerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    void ReceiveActorOnInputTouchEnter(char FingerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    void ReceiveActorOnInputTouchEnd(char FingerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    void ReceiveActorOnInputTouchBegin(char FingerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    void ReceiveActorOnClicked(struct FKey ButtonPressed); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    void ReceiveActorEndOverlap(class AActor* OtherActor); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    void ReceiveActorEndCursorOver(); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    void ReceiveActorBeginOverlap(class AActor* OtherActor); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    void ReceiveActorBeginCursorOver(); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    void PrestreamTextures(float Seconds, bool bEnableStreaming, int CinematicTextureGroups); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    void OnRep_ReplicateMovement(); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    void OnRep_ReplicatedMovement(); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    void OnRep_Owner(); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    void OnRep_Instigator(); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    void OnRep_AttachmentReplication(); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    void MakeNoise(float Loudness, class APawn* NoiseInstigator, struct FVector NoiseLocation, float MaxRange, FName Tag); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    class UMaterialInstanceDynamic* MakeMIDForMaterial(class UMaterialInterface* Parent); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    bool K2_TeleportTo(struct FVector DestLocation, struct FRotator DestRotation); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    bool K2_SetActorTransform(struct FTransform NewTransform, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    bool K2_SetActorRotation(struct FRotator NewRotation, bool bTeleportPhysics); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    void K2_SetActorRelativeTransform(struct FTransform NewRelativeTransform, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    void K2_SetActorRelativeRotation(struct FRotator NewRelativeRotation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    void K2_SetActorRelativeLocation(struct FVector NewRelativeLocation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    bool K2_SetActorLocationAndRotation(struct FVector NewLocation, struct FRotator NewRotation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    bool K2_SetActorLocation(struct FVector NewLocation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    void K2_OnReset(); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    void K2_OnEndViewTarget(class APlayerController* PC); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    void K2_OnBecomeViewTarget(class APlayerController* PC); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x7fe1]; // 0x7fe1
	    class USceneComponent* K2_GetRootComponent(); // 0x0 Size: 0x7fe1
	    char UnknownData63[0x7fe1]; // 0x7fe1
	    struct FRotator K2_GetActorRotation(); // 0x0 Size: 0x7fe1
	    char UnknownData64[0x7fe1]; // 0x7fe1
	    struct FVector K2_GetActorLocation(); // 0x0 Size: 0x7fe1
	    char UnknownData65[0x7fe1]; // 0x7fe1
	    void K2_DetachFromActor(EDetachmentRule LocationRule, EDetachmentRule RotationRule, EDetachmentRule ScaleRule); // 0x0 Size: 0x7fe1
	    char UnknownData66[0x7fe1]; // 0x7fe1
	    void K2_DestroyComponent(class UActorComponent* Component); // 0x0 Size: 0x7fe1
	    char UnknownData67[0x7fe1]; // 0x7fe1
	    void K2_DestroyActor(); // 0x0 Size: 0x7fe1
	    char UnknownData68[0x7fe1]; // 0x7fe1
	    void K2_AttachToComponent(class USceneComponent* Parent, FName SocketName, EAttachmentRule LocationRule, EAttachmentRule RotationRule, EAttachmentRule ScaleRule, bool bWeldSimulatedBodies); // 0x0 Size: 0x7fe1
	    char UnknownData69[0x7fe1]; // 0x7fe1
	    void K2_AttachToActor(class AActor* ParentActor, FName SocketName, EAttachmentRule LocationRule, EAttachmentRule RotationRule, EAttachmentRule ScaleRule, bool bWeldSimulatedBodies); // 0x0 Size: 0x7fe1
	    char UnknownData70[0x7fe1]; // 0x7fe1
	    void K2_AttachRootComponentToActor(class AActor* InParentActor, FName InSocketName, char AttachLocationType, bool bWeldSimulatedBodies); // 0x0 Size: 0x7fe1
	    char UnknownData71[0x7fe1]; // 0x7fe1
	    void K2_AttachRootComponentTo(class USceneComponent* InParent, FName InSocketName, char AttachLocationType, bool bWeldSimulatedBodies); // 0x0 Size: 0x7fe1
	    char UnknownData72[0x7fe1]; // 0x7fe1
	    void K2_AddActorWorldTransform(struct FTransform DeltaTransform, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData73[0x7fe1]; // 0x7fe1
	    void K2_AddActorWorldRotation(struct FRotator DeltaRotation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData74[0x7fe1]; // 0x7fe1
	    void K2_AddActorWorldOffset(struct FVector DeltaLocation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData75[0x7fe1]; // 0x7fe1
	    void K2_AddActorLocalTransform(struct FTransform NewTransform, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData76[0x7fe1]; // 0x7fe1
	    void K2_AddActorLocalRotation(struct FRotator DeltaRotation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData77[0x7fe1]; // 0x7fe1
	    void K2_AddActorLocalOffset(struct FVector DeltaLocation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData78[0x7fe1]; // 0x7fe1
	    bool IsOverlappingActor(class AActor* Other); // 0x0 Size: 0x7fe1
	    char UnknownData79[0x7fe1]; // 0x7fe1
	    bool IsChildActor(); // 0x0 Size: 0x7fe1
	    char UnknownData80[0x7fe1]; // 0x7fe1
	    bool IsActorTickEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData81[0x7fe1]; // 0x7fe1
	    bool IsActorBeingDestroyed(); // 0x0 Size: 0x7fe1
	    char UnknownData82[0x7fe1]; // 0x7fe1
	    bool HasAuthority(); // 0x0 Size: 0x7fe1
	    char UnknownData83[0x7fe1]; // 0x7fe1
	    float GetVerticalDistanceTo(class AActor* OtherActor); // 0x0 Size: 0x7fe1
	    char UnknownData84[0x7fe1]; // 0x7fe1
	    struct FVector GetVelocity(); // 0x0 Size: 0x7fe1
	    char UnknownData85[0x7fe1]; // 0x7fe1
	    struct FTransform GetTransform(); // 0x0 Size: 0x7fe1
	    char UnknownData86[0x7fe1]; // 0x7fe1
	    bool GetTickableWhenPaused(); // 0x0 Size: 0x7fe1
	    char UnknownData87[0x7fe1]; // 0x7fe1
	    float GetSquaredDistanceTo(class AActor* OtherActor); // 0x0 Size: 0x7fe1
	    char UnknownData88[0x7fe1]; // 0x7fe1
	    char GetRemoteRole(); // 0x0 Size: 0x7fe1
	    char UnknownData89[0x7fe1]; // 0x7fe1
	    class UChildActorComponent* GetParentComponent(); // 0x0 Size: 0x7fe1
	    char UnknownData90[0x7fe1]; // 0x7fe1
	    class AActor* GetParentActor(); // 0x0 Size: 0x7fe1
	    char UnknownData91[0x7fe1]; // 0x7fe1
	    class AActor* GetOwner(); // 0x0 Size: 0x7fe1
	    char UnknownData92[0x7fe1]; // 0x7fe1
	    void GetOverlappingComponents(TArray<class UPrimitiveComponent*> OverlappingComponents); // 0x0 Size: 0x7fe1
	    char UnknownData93[0x7fe1]; // 0x7fe1
	    void GetOverlappingActors(TArray<class AActor*> OverlappingActors, class AActor* ClassFilter); // 0x0 Size: 0x7fe1
	    char UnknownData94[0x7fe1]; // 0x7fe1
	    char GetLocalRole(); // 0x0 Size: 0x7fe1
	    char UnknownData95[0x7fe1]; // 0x7fe1
	    float GetLifeSpan(); // 0x0 Size: 0x7fe1
	    char UnknownData96[0x7fe1]; // 0x7fe1
	    class AController* GetInstigatorController(); // 0x0 Size: 0x7fe1
	    char UnknownData97[0x7fe1]; // 0x7fe1
	    class APawn* GetInstigator(); // 0x0 Size: 0x7fe1
	    char UnknownData98[0x7fe1]; // 0x7fe1
	    struct FVector GetInputVectorAxisValue(struct FKey InputAxisKey); // 0x0 Size: 0x7fe1
	    char UnknownData99[0x7fe1]; // 0x7fe1
	    float GetInputAxisValue(FName InputAxisName); // 0x0 Size: 0x7fe1
	    char UnknownData100[0x7fe1]; // 0x7fe1
	    float GetInputAxisKeyValue(struct FKey InputAxisKey); // 0x0 Size: 0x7fe1
	    char UnknownData101[0x7fe1]; // 0x7fe1
	    float GetHorizontalDotProductTo(class AActor* OtherActor); // 0x0 Size: 0x7fe1
	    char UnknownData102[0x7fe1]; // 0x7fe1
	    float GetHorizontalDistanceTo(class AActor* OtherActor); // 0x0 Size: 0x7fe1
	    char UnknownData103[0x7fe1]; // 0x7fe1
	    float GetGameTimeSinceCreation(); // 0x0 Size: 0x7fe1
	    char UnknownData104[0x7fe1]; // 0x7fe1
	    float GetDotProductTo(class AActor* OtherActor); // 0x0 Size: 0x7fe1
	    char UnknownData105[0x7fe1]; // 0x7fe1
	    float GetDistanceTo(class AActor* OtherActor); // 0x0 Size: 0x7fe1
	    char UnknownData106[0x7fe1]; // 0x7fe1
	    TArray<class UActorComponent*> GetComponentsByTag(class UActorComponent* ComponentClass, FName Tag); // 0x0 Size: 0x7fe1
	    char UnknownData107[0x7fe1]; // 0x7fe1
	    TArray<class UActorComponent*> GetComponentsByClass(class UActorComponent* ComponentClass); // 0x0 Size: 0x7fe1
	    char UnknownData108[0x7fe1]; // 0x7fe1
	    class UActorComponent* GetComponentByClass(class UActorComponent* ComponentClass); // 0x0 Size: 0x7fe1
	    char UnknownData109[0x7fe1]; // 0x7fe1
	    FName GetAttachParentSocketName(); // 0x0 Size: 0x7fe1
	    char UnknownData110[0x7fe1]; // 0x7fe1
	    class AActor* GetAttachParentActor(); // 0x0 Size: 0x7fe1
	    char UnknownData111[0x7fe1]; // 0x7fe1
	    void GetAttachedActors(TArray<class AActor*> OutActors); // 0x0 Size: 0x7fe1
	    char UnknownData112[0x7fe1]; // 0x7fe1
	    void GetAllChildActors(TArray<class AActor*> ChildActors, bool bIncludeDescendants); // 0x0 Size: 0x7fe1
	    char UnknownData113[0x7fe1]; // 0x7fe1
	    struct FVector GetActorUpVector(); // 0x0 Size: 0x7fe1
	    char UnknownData114[0x7fe1]; // 0x7fe1
	    float GetActorTimeDilation(); // 0x0 Size: 0x7fe1
	    char UnknownData115[0x7fe1]; // 0x7fe1
	    float GetActorTickInterval(); // 0x0 Size: 0x7fe1
	    char UnknownData116[0x7fe1]; // 0x7fe1
	    struct FVector GetActorScale3D(); // 0x0 Size: 0x7fe1
	    char UnknownData117[0x7fe1]; // 0x7fe1
	    struct FVector GetActorRightVector(); // 0x0 Size: 0x7fe1
	    char UnknownData118[0x7fe1]; // 0x7fe1
	    struct FVector GetActorRelativeScale3D(); // 0x0 Size: 0x7fe1
	    char UnknownData119[0x7fe1]; // 0x7fe1
	    struct FVector GetActorForwardVector(); // 0x0 Size: 0x7fe1
	    char UnknownData120[0x7fe1]; // 0x7fe1
	    void GetActorEyesViewPoint(struct FVector OutLocation, struct FRotator OutRotation); // 0x0 Size: 0x7fe1
	    char UnknownData121[0x7fe1]; // 0x7fe1
	    bool GetActorEnableCollision(); // 0x0 Size: 0x7fe1
	    char UnknownData122[0x7fe1]; // 0x7fe1
	    void GetActorBounds(bool bOnlyCollidingComponents, struct FVector Origin, struct FVector BoxExtent); // 0x0 Size: 0x7fe1
	    char UnknownData123[0x7fe1]; // 0x7fe1
	    void ForceNetUpdate(); // 0x0 Size: 0x7fe1
	    char UnknownData124[0x7fe1]; // 0x7fe1
	    void FlushNetDormancy(); // 0x0 Size: 0x7fe1
	    char UnknownData125[0x7fe1]; // 0x7fe1
	    void EnableInput(class APlayerController* PlayerController); // 0x0 Size: 0x7fe1
	    char UnknownData126[0x7fe1]; // 0x7fe1
	    void DisableInput(class APlayerController* PlayerController); // 0x0 Size: 0x7fe1
	    char UnknownData127[0x7fe1]; // 0x7fe1
	    void DetachRootComponentFromParent(bool bMaintainWorldPosition); // 0x0 Size: 0x7fe1
	    char UnknownData128[0x7fe1]; // 0x7fe1
	    void AddTickPrerequisiteComponent(class UActorComponent* PrerequisiteComponent); // 0x0 Size: 0x7fe1
	    char UnknownData129[0x7fe1]; // 0x7fe1
	    void AddTickPrerequisiteActor(class AActor* PrerequisiteActor); // 0x0 Size: 0x7fe1
	    char UnknownData130[0x7fe1]; // 0x7fe1
	    class UActorComponent* AddComponent(FName TemplateName, bool bManualAttachment, struct FTransform RelativeTransform, class UObject* ComponentTemplateContext); // 0x0 Size: 0x7fe1
	    char UnknownData131[0x7fe1]; // 0x7fe1
	    bool ActorHasTag(FName Tag); // 0x0 Size: 0x7fe1
	    char UnknownData132[0x-7cb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Actor");
			return (class UClass*)ptr;
		};

};

class AInfo : public AActor
{
	public:
	    char UnknownData0[0x330];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Info");
			return (class UClass*)ptr;
		};

};

class UOnlineBlueprintCallProxyBase : public UObject
{
	public:
	    void Activate(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.OnlineBlueprintCallProxyBase");
			return (class UClass*)ptr;
		};

};

class UNetConnection : public UPlayer
{
	public:
	    TArray<class UChildConnection*> Children; // 0x48 Size: 0x10
	    class UNetDriver* Driver; // 0x58 Size: 0x8
	    class UPackageMap* PackageMapClass; // 0x60 Size: 0x8
	    class UPackageMap* PackageMap; // 0x68 Size: 0x8
	    TArray<class UChannel*> OpenChannels; // 0x70 Size: 0x10
	    TArray<class AActor*> SentTemporaries; // 0x80 Size: 0x10
	    class AActor* ViewTarget; // 0x90 Size: 0x8
	    class AActor* OwningActor; // 0x98 Size: 0x8
	    int MaxPacket; // 0xa0 Size: 0x4
	    bool InternalAck; // 0xa4 Size: 0x1
	    char UnknownData0[0xab]; // 0xa5
	    struct FUniqueNetIdRepl PlayerID; // 0x150 Size: 0x28
	    char UnknownData1[0x68]; // 0x178
	    double LastReceiveTime; // 0x1e0 Size: 0x8
	    char UnknownData2[0x15d8]; // 0x1e8
	    TArray<class UChannel*> ChannelsToTick; // 0x17c0 Size: 0x10
	    char UnknownData3[0x158];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.NetConnection");
			return (class UClass*)ptr;
		};

};

class UNetDriver : public UObject
{
	public:
	    char UnknownData0[0x8];
	    struct FString NetConnectionClassName; // 0x30 Size: 0x10
	    struct FString ReplicationDriverClassName; // 0x40 Size: 0x10
	    int MaxDownloadSize; // 0x50 Size: 0x4
	    bool bClampListenServerTickRate; // 0x54 Size: 0x1
	    char UnknownData1[0x3]; // 0x55
	    int NetServerMaxTickRate; // 0x58 Size: 0x4
	    int MaxInternetClientRate; // 0x5c Size: 0x4
	    int MaxClientRate; // 0x60 Size: 0x4
	    float ServerTravelPause; // 0x64 Size: 0x4
	    float SpawnPrioritySeconds; // 0x68 Size: 0x4
	    float RelevantTimeout; // 0x6c Size: 0x4
	    float KeepAliveTime; // 0x70 Size: 0x4
	    float InitialConnectTimeout; // 0x74 Size: 0x4
	    float ConnectionTimeout; // 0x78 Size: 0x4
	    float TimeoutMultiplierForUnoptimizedBuilds; // 0x7c Size: 0x4
	    bool bNoTimeouts; // 0x80 Size: 0x1
	    char UnknownData2[0x7]; // 0x81
	    class UNetConnection* ServerConnection; // 0x88 Size: 0x8
	    TArray<class UNetConnection*> ClientConnections; // 0x90 Size: 0x10
	    char UnknownData3[0x60]; // 0xa0
	    int RecentlyDisconnectedTrackingTime; // 0x100 Size: 0x4
	    char UnknownData4[0x3c]; // 0x104
	    class UWorld* World; // 0x140 Size: 0x8
	    class UPackage* WorldPackage; // 0x148 Size: 0x8
	    char UnknownData5[0x20]; // 0x150
	    class UObject* NetConnectionClass; // 0x170 Size: 0x8
	    class UObject* ReplicationDriverClass; // 0x178 Size: 0x8
	    class UProperty* RoleProperty; // 0x180 Size: 0x8
	    class UProperty* RemoteRoleProperty; // 0x188 Size: 0x8
	    FName NetDriverName; // 0x190 Size: 0x8
	    char UnknownData6[0x40]; // 0x198
	    TArray<struct FChannelDefinition> ChannelDefinitions; // 0x1d8 Size: 0x10
	    __int64/*MapProperty*/ ChannelDefinitionMap; // 0x1e8 Size: 0x50
	    TArray<class UChannel*> ActorChannelPool; // 0x238 Size: 0x10
	    char UnknownData7[0x8]; // 0x248
	    float Time; // 0x250 Size: 0x4
	    char UnknownData8[0x4a4]; // 0x254
	    class UReplicationDriver* ReplicationDriver; // 0x6f8 Size: 0x8
	    char UnknownData9[0x20];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.NetDriver");
			return (class UClass*)ptr;
		};

};

class UBlueprintAsyncActionBase : public UObject
{
	public:
	    void Activate(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7fb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BlueprintAsyncActionBase");
			return (class UClass*)ptr;
		};

};

class UOnlineEngineInterface : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.OnlineEngineInterface");
			return (class UClass*)ptr;
		};

};

class UDeveloperSettings : public UObject
{
	public:
	    char UnknownData0[0x38];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DeveloperSettings");
			return (class UClass*)ptr;
		};

};

class UOnlineSession : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.OnlineSession");
			return (class UClass*)ptr;
		};

};

class AHUD : public AActor
{
	public:
	    class APlayerController* PlayerOwner; // 0x330 Size: 0x8
	    bool bLostFocusPaused; // 0x338 Size: 0x1
	    bool bShowHUD; // 0x338 Size: 0x1
	    bool bShowDebugInfo; // 0x338 Size: 0x1
	    char UnknownData0[0x1]; // 0x33b
	    int CurrentTargetIndex; // 0x33c Size: 0x4
	    bool bShowHitBoxDebugInfo; // 0x340 Size: 0x1
	    bool bShowOverlays; // 0x340 Size: 0x1
	    bool bEnableDebugTextShadow; // 0x340 Size: 0x1
	    char UnknownData1[0x5]; // 0x343
	    TArray<class AActor*> PostRenderedActors; // 0x348 Size: 0x10
	    char UnknownData2[0x8]; // 0x358
	    TArray<FName> DebugDisplay; // 0x360 Size: 0x10
	    TArray<FName> ToggledDebugCategories; // 0x370 Size: 0x10
	    class UCanvas* Canvas; // 0x380 Size: 0x8
	    class UCanvas* DebugCanvas; // 0x388 Size: 0x8
	    TArray<struct FDebugTextInfo> DebugTextList; // 0x390 Size: 0x10
	    class AActor* ShowDebugTargetDesiredClass; // 0x3a0 Size: 0x8
	    class AActor* ShowDebugTargetActor; // 0x3a8 Size: 0x8
	    char UnknownData3[0x3b0]; // 0x3b0
	    void ShowHUD(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void ShowDebugToggleSubCategory(FName Category); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ShowDebugForReticleTargetToggle(class AActor* DesiredClass); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ShowDebug(FName DebugType); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void RemoveDebugText(class AActor* SrcActor, bool bLeaveDurationText); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void RemoveAllDebugStrings(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void ReceiveHitBoxRelease(FName BoxName); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void ReceiveHitBoxEndCursorOver(FName BoxName); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void ReceiveHitBoxClick(FName BoxName); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void ReceiveHitBoxBeginCursorOver(FName BoxName); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void ReceiveDrawHUD(int SizeX, int SizeY); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    struct FVector Project(struct FVector Location); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void PreviousDebugTarget(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void NextDebugTarget(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void GetTextSize(struct FString Text, float OutWidth, float OutHeight, class UFont* Font, float Scale); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    class APlayerController* GetOwningPlayerController(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    class APawn* GetOwningPawn(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void GetActorsInSelectionRectangle(class AActor* ClassFilter, struct FVector2D FirstPoint, struct FVector2D SecondPoint, TArray<class AActor*> OutActors, bool bIncludeNonCollidingComponents, bool bActorMustBeFullyEnclosed); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void DrawTextureSimple(class UTexture* Texture, float ScreenX, float ScreenY, float Scale, bool bScalePosition); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void DrawTexture(class UTexture* Texture, float ScreenX, float ScreenY, float ScreenW, float ScreenH, float TextureU, float TextureV, float TextureUWidth, float TextureVHeight, struct FLinearColor TintColor, char BlendMode, float Scale, bool bScalePosition, float Rotation, struct FVector2D RotPivot); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void DrawText(struct FString Text, struct FLinearColor TextColor, float ScreenX, float ScreenY, class UFont* Font, float Scale, bool bScalePosition); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void DrawRect(struct FLinearColor RectColor, float ScreenX, float ScreenY, float ScreenW, float ScreenH); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void DrawMaterialTriangle(class UMaterialInterface* Material, struct FVector2D V0_Pos, struct FVector2D V1_Pos, struct FVector2D V2_Pos, struct FVector2D V0_UV, struct FVector2D V1_UV, struct FVector2D V2_UV, struct FLinearColor V0_Color, struct FLinearColor V1_Color, struct FLinearColor V2_Color); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void DrawMaterialSimple(class UMaterialInterface* Material, float ScreenX, float ScreenY, float ScreenW, float ScreenH, float Scale, bool bScalePosition); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void DrawMaterial(class UMaterialInterface* Material, float ScreenX, float ScreenY, float ScreenW, float ScreenH, float MaterialU, float MaterialV, float MaterialUWidth, float MaterialVHeight, float Scale, bool bScalePosition, float Rotation, struct FVector2D RotPivot); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void DrawLine(float StartScreenX, float StartScreenY, float EndScreenX, float EndScreenY, struct FLinearColor LineColor, float LineThickness); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    void Deproject(float ScreenX, float ScreenY, struct FVector WorldPosition, struct FVector WorldDirection); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    void AddHitBox(struct FVector2D Position, struct FVector2D Size, FName InName, bool bConsumesInput, int Priority); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    void AddDebugText(struct FString DebugText, class AActor* SrcActor, float Duration, struct FVector Offset, struct FVector DesiredOffset, struct FColor TextColor, bool bSkipOverwriteCheck, bool bAbsoluteLocation, bool bKeepAttachedToActor, class UFont* InFont, float FontScale, bool bDrawShadow); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x-7bc1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.HUD");
			return (class UClass*)ptr;
		};

};

class APawn : public AActor
{
	public:
	    char UnknownData0[0x8];
	    bool bUseControllerRotationPitch; // 0x338 Size: 0x1
	    bool bUseControllerRotationYaw; // 0x338 Size: 0x1
	    bool bUseControllerRotationRoll; // 0x338 Size: 0x1
	    bool bCanAffectNavigationGeneration; // 0x338 Size: 0x1
	    float BaseEyeHeight; // 0x33c Size: 0x4
	    char AutoPossessPlayer; // 0x340 Size: 0x1
	    EAutoPossessAI AutoPossessAI; // 0x341 Size: 0x1
	    char RemoteViewPitch; // 0x342 Size: 0x1
	    char UnknownData1[0x5]; // 0x343
	    class AController* AIControllerClass; // 0x348 Size: 0x8
	    class APlayerState* PlayerState; // 0x350 Size: 0x8
	    char UnknownData2[0x8]; // 0x358
	    class AController* LastHitBy; // 0x360 Size: 0x8
	    class AController* Controller; // 0x368 Size: 0x8
	    char UnknownData3[0x4]; // 0x370
	    struct FVector ControlInputVector; // 0x374 Size: 0xc
	    struct FVector LastControlInputVector; // 0x380 Size: 0xc
	    char UnknownData4[0x38c]; // 0x38c
	    void SpawnDefaultController(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetCanAffectNavigationGeneration(bool bNewValue, bool bForceUpdate); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ReceiveUnpossessed(class AController* OldController); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void ReceivePossessed(class AController* NewController); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void PawnMakeNoise(float Loudness, struct FVector NoiseLocation, bool bUseNoiseMakerLocation, class AActor* NoiseMaker); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnRep_PlayerState(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnRep_Controller(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void LaunchPawn(struct FVector LaunchVelocity, bool bXYOverride, bool bZOverride); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    struct FVector K2_GetMovementInputVector(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    bool IsPlayerControlled(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    bool IsMoveInputIgnored(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    bool IsLocallyControlled(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    bool IsControlled(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    struct FVector GetPendingMovementInputVector(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    struct FVector GetNavAgentLocation(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    class UPawnMovementComponent* GetMovementComponent(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    static class AActor* GetMovementBaseActor(class APawn* Pawn); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    struct FVector GetLastMovementInputVector(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    struct FRotator GetControlRotation(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    class AController* GetController(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    struct FRotator GetBaseAimRotation(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void DetachFromControllerPendingDestroy(); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    struct FVector ConsumeMovementInputVector(); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void AddMovementInput(struct FVector WorldDirection, float ScaleValue, bool bForce); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void AddControllerYawInput(float Val); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    void AddControllerRollInput(float Val); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    void AddControllerPitchInput(float Val); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x-7c51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Pawn");
			return (class UClass*)ptr;
		};

};

class ADefaultPawn : public APawn
{
	public:
	    float BaseTurnRate; // 0x390 Size: 0x4
	    float BaseLookUpRate; // 0x394 Size: 0x4
	    class UPawnMovementComponent* MovementComponent; // 0x398 Size: 0x8
	    class USphereComponent* CollisionComponent; // 0x3a0 Size: 0x8
	    class UStaticMeshComponent* MeshComponent; // 0x3a8 Size: 0x8
	    bool bAddDefaultMovementBindings; // 0x3b0 Size: 0x1
	    char UnknownData0[0x3b1]; // 0x3b1
	    void TurnAtRate(float Rate); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void MoveUp_World(float Val); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void MoveRight(float Val); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void MoveForward(float Val); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void LookUpAtRate(float Rate); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7c29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DefaultPawn");
			return (class UClass*)ptr;
		};

};

class UBlueprintCore : public UObject
{
	public:
	    class UObject* SkeletonGeneratedClass; // 0x28 Size: 0x8
	    class UObject* GeneratedClass; // 0x30 Size: 0x8
	    bool bLegacyNeedToPurgeSkelRefs; // 0x38 Size: 0x1
	    bool bLegacyGeneratedClassIsAuthoritative; // 0x39 Size: 0x1
	    char UnknownData0[0x2]; // 0x3a
	    struct FGuid BlueprintGuid; // 0x3c Size: 0x10
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BlueprintCore");
			return (class UClass*)ptr;
		};

};

class UBlueprint : public UBlueprintCore
{
	public:
	    bool bRecompileOnLoad; // 0x50 Size: 0x1
	    char UnknownData0[0x7]; // 0x51
	    class UObject* ParentClass; // 0x58 Size: 0x8
	    class UObject* PRIVATE_InnermostPreviousCDO; // 0x60 Size: 0x8
	    bool bHasBeenRegenerated; // 0x68 Size: 0x1
	    bool bIsRegeneratingOnLoad; // 0x68 Size: 0x1
	    char UnknownData1[0x6]; // 0x6a
	    class USimpleConstructionScript* SimpleConstructionScript; // 0x70 Size: 0x8
	    TArray<class UActorComponent*> ComponentTemplates; // 0x78 Size: 0x10
	    TArray<class UTimelineTemplate*> Timelines; // 0x88 Size: 0x10
	    class UInheritableComponentHandler* InheritableComponentHandler; // 0x98 Size: 0x8
	    char BlueprintType; // 0xa0 Size: 0x1
	    char UnknownData2[0x3]; // 0xa1
	    int BlueprintSystemVersion; // 0xa4 Size: 0x4
	    bool bNativize; // 0xd8 Size: 0x1
	    char UnknownData3[0x37];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Blueprint");
			return (class UClass*)ptr;
		};

};

class UDataAsset : public UObject
{
	public:
	    class UDataAsset* NativeClass; // 0x28 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DataAsset");
			return (class UClass*)ptr;
		};

};

class UChannel : public UObject
{
	public:
	    class UNetConnection* Connection; // 0x28 Size: 0x8
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Channel");
			return (class UClass*)ptr;
		};

};

class UVoiceChannel : public UChannel
{
	public:
	    char UnknownData0[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.VoiceChannel");
			return (class UClass*)ptr;
		};

};

class UReplicationDriver : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ReplicationDriver");
			return (class UClass*)ptr;
		};

};

class UReplicationConnectionDriver : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ReplicationConnectionDriver");
			return (class UClass*)ptr;
		};

};

class UCommandlet : public UObject
{
	public:
	    struct FString HelpDescription; // 0x28 Size: 0x10
	    struct FString HelpUsage; // 0x38 Size: 0x10
	    struct FString HelpWebLink; // 0x48 Size: 0x10
	    TArray<struct FString> HelpParamNames; // 0x58 Size: 0x10
	    TArray<struct FString> HelpParamDescriptions; // 0x68 Size: 0x10
	    bool IsServer; // 0x78 Size: 0x1
	    bool IsClient; // 0x78 Size: 0x1
	    bool IsEditor; // 0x78 Size: 0x1
	    bool LogToConsole; // 0x78 Size: 0x1
	    bool ShowErrorCount; // 0x78 Size: 0x1
	    bool ShowProgress; // 0x78 Size: 0x1
	    char UnknownData0[0x2];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Commandlet");
			return (class UClass*)ptr;
		};

};

class UMaterialExpression : public UObject
{
	public:
	    class UMaterial* Material; // 0x28 Size: 0x8
	    class UMaterialFunction* Function; // 0x30 Size: 0x8
	    bool bIsParameterExpression; // 0x38 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpression");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionTextureBase : public UMaterialExpression
{
	public:
	    class UTexture* Texture; // 0x40 Size: 0x8
	    char SamplerType; // 0x48 Size: 0x1
	    bool IsDefaultMeshpaintTexture; // 0x4c Size: 0x1
	    char UnknownData0[0x6];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionTextureBase");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionTextureSample : public UMaterialExpressionTextureBase
{
	public:
	    struct FExpressionInput Coordinates; // 0x50 Size: 0xc
	    char UnknownData0[0x8]; // 0x5c
	    struct FExpressionInput TextureObject; // 0x64 Size: 0xc
	    char UnknownData1[0x8]; // 0x70
	    struct FExpressionInput MipValue; // 0x78 Size: 0xc
	    char UnknownData2[0x8]; // 0x84
	    struct FExpressionInput CoordinatesDX; // 0x8c Size: 0xc
	    char UnknownData3[0x8]; // 0x98
	    struct FExpressionInput CoordinatesDY; // 0xa0 Size: 0xc
	    char UnknownData4[0x8]; // 0xac
	    struct FExpressionInput AutomaticViewMipBiasValue; // 0xb4 Size: 0xc
	    char UnknownData5[0x8]; // 0xc0
	    char MipValueMode; // 0xc8 Size: 0x1
	    char SamplerSource; // 0xc9 Size: 0x1
	    char UnknownData6[0x2]; // 0xca
	    uint32_t ConstCoordinate; // 0xcc Size: 0x4
	    int ConstMipValue; // 0xd0 Size: 0x4
	    bool AutomaticViewMipBias; // 0xd4 Size: 0x1
	    char UnknownData7[0xb];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionTextureSample");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionTextureSampleParameter : public UMaterialExpressionTextureSample
{
	public:
	    FName ParameterName; // 0xe0 Size: 0x8
	    struct FGuid ExpressionGUID; // 0xe8 Size: 0x10
	    FName Group; // 0xf8 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionTextureSampleParameter");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionTextureSampleParameter2D : public UMaterialExpressionTextureSampleParameter
{
	public:
	    char UnknownData0[0x100];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionTextureSampleParameter2D");
			return (class UClass*)ptr;
		};

};

class ACharacter : public APawn
{
	public:
	    class USkeletalMeshComponent* Mesh; // 0x390 Size: 0x8
	    class UCharacterMovementComponent* CharacterMovement; // 0x398 Size: 0x8
	    class UCapsuleComponent* CapsuleComponent; // 0x3a0 Size: 0x8
	    struct FBasedMovementInfo BasedMovement; // 0x3a8 Size: 0x30
	    struct FBasedMovementInfo ReplicatedBasedMovement; // 0x3d8 Size: 0x30
	    float AnimRootMotionTranslationScale; // 0x408 Size: 0x4
	    struct FVector BaseTranslationOffset; // 0x40c Size: 0xc
	    char UnknownData0[0x8]; // 0x418
	    struct FQuat BaseRotationOffset; // 0x420 Size: 0x10
	    float ReplicatedServerLastTransformUpdateTimeStamp; // 0x430 Size: 0x4
	    float ReplayLastTransformUpdateTimeStamp; // 0x434 Size: 0x4
	    char ReplicatedMovementMode; // 0x438 Size: 0x1
	    bool bInBaseReplication; // 0x439 Size: 0x1
	    char UnknownData1[0x2]; // 0x43a
	    float CrouchedEyeHeight; // 0x43c Size: 0x4
	    bool bIsCrouched; // 0x440 Size: 0x1
	    bool bProxyIsJumpForceApplied; // 0x440 Size: 0x1
	    bool bPressedJump; // 0x440 Size: 0x1
	    bool bClientUpdating; // 0x440 Size: 0x1
	    bool bClientWasFalling; // 0x440 Size: 0x1
	    bool bClientResimulateRootMotion; // 0x440 Size: 0x1
	    bool bClientResimulateRootMotionSources; // 0x440 Size: 0x1
	    bool bSimGravityDisabled; // 0x440 Size: 0x1
	    bool bClientCheckEncroachmentOnNetUpdate; // 0x441 Size: 0x1
	    bool bServerMoveIgnoreRootMotion; // 0x441 Size: 0x1
	    bool bWasJumping; // 0x441 Size: 0x1
	    char UnknownData2[0x7]; // 0x44b
	    float JumpKeyHoldTime; // 0x444 Size: 0x4
	    float JumpForceTimeRemaining; // 0x448 Size: 0x4
	    float ProxyJumpForceStartedTime; // 0x44c Size: 0x4
	    float JumpMaxHoldTime; // 0x450 Size: 0x4
	    int JumpMaxCount; // 0x454 Size: 0x4
	    int JumpCurrentCount; // 0x458 Size: 0x4
	    char UnknownData3[0x4]; // 0x45c
	    MulticastDelegateProperty OnReachedJumpApex; // 0x460 Size: 0x10
	    char UnknownData4[0x10]; // 0x470
	    MulticastDelegateProperty MovementModeChangedDelegate; // 0x480 Size: 0x10
	    MulticastDelegateProperty OnCharacterMovementUpdated; // 0x490 Size: 0x10
	    struct FRootMotionSourceGroup SavedRootMotion; // 0x4a0 Size: 0xf8
	    char UnknownData5[0x8]; // 0x598
	    struct FRootMotionMovementParams ClientRootMotionParams; // 0x5a0 Size: 0x40
	    TArray<struct FSimulatedRootMotionReplicatedMove> RootMotionRepMoves; // 0x5e0 Size: 0x10
	    struct FRepRootMotionMontage RepRootMotion; // 0x5f0 Size: 0x158
	    char UnknownData6[0x748]; // 0x748
	    void UnCrouch(bool bClientSimulation); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void StopJumping(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void StopAnimMontage(class UAnimMontage* AnimMontage); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void ServerMoveOld(float OldTimeStamp, struct FVector_NetQuantize10 OldAccel, char OldMoveFlags); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void ServerMoveNoBase(float Timestamp, struct FVector_NetQuantize10 InAccel, struct FVector_NetQuantize100 ClientLoc, char CompressedMoveFlags, char ClientRoll, uint32_t View, char ClientMovementMode); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void ServerMoveDualNoBase(float TimeStamp0, struct FVector_NetQuantize10 InAccel0, char PendingFlags, uint32_t View0, float Timestamp, struct FVector_NetQuantize10 InAccel, struct FVector_NetQuantize100 ClientLoc, char NewFlags, char ClientRoll, uint32_t View, char ClientMovementMode); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void ServerMoveDualHybridRootMotion(float TimeStamp0, struct FVector_NetQuantize10 InAccel0, char PendingFlags, uint32_t View0, float Timestamp, struct FVector_NetQuantize10 InAccel, struct FVector_NetQuantize100 ClientLoc, char NewFlags, char ClientRoll, uint32_t View, class UPrimitiveComponent* ClientMovementBase, FName ClientBaseBoneName, char ClientMovementMode); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void ServerMoveDual(float TimeStamp0, struct FVector_NetQuantize10 InAccel0, char PendingFlags, uint32_t View0, float Timestamp, struct FVector_NetQuantize10 InAccel, struct FVector_NetQuantize100 ClientLoc, char NewFlags, char ClientRoll, uint32_t View, class UPrimitiveComponent* ClientMovementBase, FName ClientBaseBoneName, char ClientMovementMode); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void ServerMove(float Timestamp, struct FVector_NetQuantize10 InAccel, struct FVector_NetQuantize100 ClientLoc, char CompressedMoveFlags, char ClientRoll, uint32_t View, class UPrimitiveComponent* ClientMovementBase, FName ClientBaseBoneName, char ClientMovementMode); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void RootMotionDebugClientPrintOnScreen(struct FString inString); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    float PlayAnimMontage(class UAnimMontage* AnimMontage, float InPlayRate, FName StartSectionName); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void OnWalkingOffLedge(struct FVector PreviousFloorImpactNormal, struct FVector PreviousFloorContactNormal, struct FVector PreviousLocation, float TimeDelta); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void OnRep_RootMotion(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void OnRep_ReplicatedBasedMovement(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void OnRep_ReplayLastTransformUpdateTimeStamp(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void OnRep_IsCrouched(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void OnLaunched(struct FVector LaunchVelocity, bool bXYOverride, bool bZOverride); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void OnLanded(struct FHitResult Hit); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void OnJumped(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void LaunchCharacter(struct FVector LaunchVelocity, bool bXYOverride, bool bZOverride); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void K2_UpdateCustomMovement(float DeltaTime); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void K2_OnStartCrouch(float HalfHeightAdjust, float ScaledHalfHeightAdjust); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void K2_OnMovementModeChanged(char PrevMovementMode, char NewMovementMode, char PrevCustomMode, char NewCustomMode); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    void K2_OnEndCrouch(float HalfHeightAdjust, float ScaledHalfHeightAdjust); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    void Jump(); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    bool IsPlayingRootMotion(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    bool IsPlayingNetworkedRootMotionMontage(); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    bool IsJumpProvidingForce(); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    bool HasAnyRootMotion(); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    class UAnimMontage* GetCurrentMontage(); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    struct FVector GetBaseTranslationOffset(); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    struct FRotator GetBaseRotationOffsetRotator(); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    float GetAnimRootMotionTranslationScale(); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    void Crouch(bool bClientSimulation); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    void ClientVeryShortAdjustPosition(float Timestamp, struct FVector NewLoc, class UPrimitiveComponent* NewBase, FName NewBaseBoneName, bool bHasBase, bool bBaseRelativePosition, char ServerMovementMode); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    void ClientCheatWalk(); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    void ClientCheatGhost(); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    void ClientCheatFly(); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    void ClientAdjustRootMotionSourcePosition(float Timestamp, struct FRootMotionSourceGroup ServerRootMotion, bool bHasAnimRootMotion, float ServerMontageTrackPosition, struct FVector ServerLoc, struct FVector_NetQuantizeNormal ServerRotation, float ServerVelZ, class UPrimitiveComponent* ServerBase, FName ServerBoneName, bool bHasBase, bool bBaseRelativePosition, char ServerMovementMode); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    void ClientAdjustRootMotionPosition(float Timestamp, float ServerMontageTrackPosition, struct FVector ServerLoc, struct FVector_NetQuantizeNormal ServerRotation, float ServerVelZ, class UPrimitiveComponent* ServerBase, FName ServerBoneName, bool bHasBase, bool bBaseRelativePosition, char ServerMovementMode); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    void ClientAdjustPosition(float Timestamp, struct FVector NewLoc, struct FVector NewVel, class UPrimitiveComponent* NewBase, FName NewBaseBoneName, bool bHasBase, bool bBaseRelativePosition, char ServerMovementMode); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    void ClientAckGoodMove(float Timestamp); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    bool CanJumpInternal(); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    bool CanJump(); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    void CacheInitialMeshOffset(struct FVector MeshRelativeLocation, struct FRotator MeshRelativeRotation); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x-7891];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Character");
			return (class UClass*)ptr;
		};

};

class USplineComponent : public UPrimitiveComponent
{
	public:
	    struct FSplineCurves SplineCurves; // 0x570 Size: 0x60
	    struct FInterpCurveVector SplineInfo; // 0x5d0 Size: 0x18
	    struct FInterpCurveQuat SplineRotInfo; // 0x5e8 Size: 0x18
	    struct FInterpCurveVector SplineScaleInfo; // 0x600 Size: 0x18
	    struct FInterpCurveFloat SplineReparamTable; // 0x618 Size: 0x18
	    bool bAllowSplineEditingPerInstance; // 0x630 Size: 0x1
	    char UnknownData0[0x3]; // 0x631
	    int ReparamStepsPerSegment; // 0x634 Size: 0x4
	    float Duration; // 0x638 Size: 0x4
	    bool bStationaryEndpoints; // 0x63c Size: 0x1
	    bool bSplineHasBeenEdited; // 0x63d Size: 0x1
	    bool bModifiedByConstructionScript; // 0x63e Size: 0x1
	    bool bInputSplinePointsToConstructionScript; // 0x63f Size: 0x1
	    bool bDrawDebug; // 0x640 Size: 0x1
	    bool bClosedLoop; // 0x641 Size: 0x1
	    bool bLoopPositionOverride; // 0x642 Size: 0x1
	    char UnknownData1[0x1]; // 0x643
	    float LoopPosition; // 0x644 Size: 0x4
	    struct FVector DefaultUpVector; // 0x648 Size: 0xc
	    char UnknownData2[0x654]; // 0x654
	    void UpdateSpline(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetWorldLocationAtSplinePoint(int PointIndex, struct FVector InLocation); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetUpVectorAtSplinePoint(int PointIndex, struct FVector InUpVector, char CoordinateSpace, bool bUpdateSpline); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetUnselectedSplineSegmentColor(struct FLinearColor SegmentColor); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetTangentsAtSplinePoint(int PointIndex, struct FVector InArriveTangent, struct FVector InLeaveTangent, char CoordinateSpace, bool bUpdateSpline); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetTangentAtSplinePoint(int PointIndex, struct FVector InTangent, char CoordinateSpace, bool bUpdateSpline); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetSplineWorldPoints(TArray<struct FVector> Points); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetSplinePointType(int PointIndex, char Type, bool bUpdateSpline); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetSplinePoints(TArray<struct FVector> Points, char CoordinateSpace, bool bUpdateSpline); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetSplineLocalPoints(TArray<struct FVector> Points); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetSelectedSplineSegmentColor(struct FLinearColor SegmentColor); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void SetLocationAtSplinePoint(int PointIndex, struct FVector InLocation, char CoordinateSpace, bool bUpdateSpline); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void SetDrawDebug(bool bShow); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void SetDefaultUpVector(struct FVector UpVector, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void SetClosedLoopAtPosition(bool bInClosedLoop, float Key, bool bUpdateSpline); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void SetClosedLoop(bool bInClosedLoop, bool bUpdateSpline); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void RemoveSplinePoint(int Index, bool bUpdateSpline); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    bool IsClosedLoop(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    struct FVector GetWorldTangentAtDistanceAlongSpline(float Distance); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    struct FRotator GetWorldRotationAtTime(float Time, bool bUseConstantVelocity); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    struct FRotator GetWorldRotationAtDistanceAlongSpline(float Distance); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    struct FVector GetWorldLocationAtTime(float Time, bool bUseConstantVelocity); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    struct FVector GetWorldLocationAtSplinePoint(int PointIndex); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    struct FVector GetWorldLocationAtDistanceAlongSpline(float Distance); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    struct FVector GetWorldDirectionAtTime(float Time, bool bUseConstantVelocity); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    struct FVector GetWorldDirectionAtDistanceAlongSpline(float Distance); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    struct FVector GetUpVectorAtTime(float Time, char CoordinateSpace, bool bUseConstantVelocity); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    struct FVector GetUpVectorAtSplinePoint(int PointIndex, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    struct FVector GetUpVectorAtDistanceAlongSpline(float Distance, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    struct FTransform GetTransformAtTime(float Time, char CoordinateSpace, bool bUseConstantVelocity, bool bUseScale); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    struct FTransform GetTransformAtSplinePoint(int PointIndex, char CoordinateSpace, bool bUseScale); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    struct FTransform GetTransformAtDistanceAlongSpline(float Distance, char CoordinateSpace, bool bUseScale); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    struct FVector GetTangentAtTime(float Time, char CoordinateSpace, bool bUseConstantVelocity); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    struct FVector GetTangentAtSplinePoint(int PointIndex, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    struct FVector GetTangentAtDistanceAlongSpline(float Distance, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    char GetSplinePointType(int PointIndex); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    float GetSplineLength(); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    struct FVector GetScaleAtTime(float Time, bool bUseConstantVelocity); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    struct FVector GetScaleAtSplinePoint(int PointIndex); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    struct FVector GetScaleAtDistanceAlongSpline(float Distance); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    struct FRotator GetRotationAtTime(float Time, char CoordinateSpace, bool bUseConstantVelocity); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    struct FRotator GetRotationAtSplinePoint(int PointIndex, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    struct FRotator GetRotationAtDistanceAlongSpline(float Distance, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    float GetRollAtTime(float Time, char CoordinateSpace, bool bUseConstantVelocity); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    float GetRollAtSplinePoint(int PointIndex, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    float GetRollAtDistanceAlongSpline(float Distance, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    struct FVector GetRightVectorAtTime(float Time, char CoordinateSpace, bool bUseConstantVelocity); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    struct FVector GetRightVectorAtSplinePoint(int PointIndex, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    struct FVector GetRightVectorAtDistanceAlongSpline(float Distance, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    int GetNumberOfSplinePoints(); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    struct FVector GetLocationAtTime(float Time, char CoordinateSpace, bool bUseConstantVelocity); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    struct FVector GetLocationAtSplinePoint(int PointIndex, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    struct FVector GetLocationAtDistanceAlongSpline(float Distance, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    void GetLocationAndTangentAtSplinePoint(int PointIndex, struct FVector Location, struct FVector Tangent, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    void GetLocalLocationAndTangentAtSplinePoint(int PointIndex, struct FVector LocalLocation, struct FVector LocalTangent); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    struct FVector GetLeaveTangentAtSplinePoint(int PointIndex, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    float GetInputKeyAtDistanceAlongSpline(float Distance); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    float GetDistanceAlongSplineAtSplinePoint(int PointIndex); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    struct FVector GetDirectionAtTime(float Time, char CoordinateSpace, bool bUseConstantVelocity); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    struct FVector GetDirectionAtSplinePoint(int PointIndex, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x7fe1]; // 0x7fe1
	    struct FVector GetDirectionAtDistanceAlongSpline(float Distance, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData63[0x7fe1]; // 0x7fe1
	    struct FVector GetDefaultUpVector(char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData64[0x7fe1]; // 0x7fe1
	    struct FVector GetArriveTangentAtSplinePoint(int PointIndex, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData65[0x7fe1]; // 0x7fe1
	    struct FVector FindUpVectorClosestToWorldLocation(struct FVector WorldLocation, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData66[0x7fe1]; // 0x7fe1
	    struct FTransform FindTransformClosestToWorldLocation(struct FVector WorldLocation, char CoordinateSpace, bool bUseScale); // 0x0 Size: 0x7fe1
	    char UnknownData67[0x7fe1]; // 0x7fe1
	    struct FVector FindTangentClosestToWorldLocation(struct FVector WorldLocation, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData68[0x7fe1]; // 0x7fe1
	    struct FVector FindScaleClosestToWorldLocation(struct FVector WorldLocation); // 0x0 Size: 0x7fe1
	    char UnknownData69[0x7fe1]; // 0x7fe1
	    struct FRotator FindRotationClosestToWorldLocation(struct FVector WorldLocation, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData70[0x7fe1]; // 0x7fe1
	    float FindRollClosestToWorldLocation(struct FVector WorldLocation, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData71[0x7fe1]; // 0x7fe1
	    struct FVector FindRightVectorClosestToWorldLocation(struct FVector WorldLocation, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData72[0x7fe1]; // 0x7fe1
	    struct FVector FindLocationClosestToWorldLocation(struct FVector WorldLocation, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData73[0x7fe1]; // 0x7fe1
	    float FindInputKeyClosestToWorldLocation(struct FVector WorldLocation); // 0x0 Size: 0x7fe1
	    char UnknownData74[0x7fe1]; // 0x7fe1
	    struct FVector FindDirectionClosestToWorldLocation(struct FVector WorldLocation, char CoordinateSpace); // 0x0 Size: 0x7fe1
	    char UnknownData75[0x7fe1]; // 0x7fe1
	    void ClearSplinePoints(bool bUpdateSpline); // 0x0 Size: 0x7fe1
	    char UnknownData76[0x7fe1]; // 0x7fe1
	    void AddSplineWorldPoint(struct FVector Position); // 0x0 Size: 0x7fe1
	    char UnknownData77[0x7fe1]; // 0x7fe1
	    void AddSplinePointAtIndex(struct FVector Position, int Index, char CoordinateSpace, bool bUpdateSpline); // 0x0 Size: 0x7fe1
	    char UnknownData78[0x7fe1]; // 0x7fe1
	    void AddSplinePoint(struct FVector Position, char CoordinateSpace, bool bUpdateSpline); // 0x0 Size: 0x7fe1
	    char UnknownData79[0x7fe1]; // 0x7fe1
	    void AddSplineLocalPoint(struct FVector Position); // 0x0 Size: 0x7fe1
	    char UnknownData80[0x7fe1]; // 0x7fe1
	    void AddPoints(TArray<struct FSplinePoint> Points, bool bUpdateSpline); // 0x0 Size: 0x7fe1
	    char UnknownData81[0x7fe1]; // 0x7fe1
	    void AddPoint(struct FSplinePoint Point, bool bUpdateSpline); // 0x0 Size: 0x7fe1
	    char UnknownData82[0x-7981];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SplineComponent");
			return (class UClass*)ptr;
		};

};

class UMovementComponent : public UActorComponent
{
	public:
	    class USceneComponent* UpdatedComponent; // 0xf8 Size: 0x8
	    class UPrimitiveComponent* UpdatedPrimitive; // 0x100 Size: 0x8
	    char UnknownData0[0x4]; // 0x108
	    struct FVector Velocity; // 0x10c Size: 0xc
	    struct FVector PlaneConstraintNormal; // 0x118 Size: 0xc
	    struct FVector PlaneConstraintOrigin; // 0x124 Size: 0xc
	    bool bUpdateOnlyIfRendered; // 0x130 Size: 0x1
	    bool bAutoUpdateTickRegistration; // 0x130 Size: 0x1
	    bool bTickBeforeOwner; // 0x130 Size: 0x1
	    bool bAutoRegisterUpdatedComponent; // 0x130 Size: 0x1
	    bool bConstrainToPlane; // 0x130 Size: 0x1
	    bool bSnapToPlaneAtStart; // 0x130 Size: 0x1
	    bool bAutoRegisterPhysicsVolumeUpdates; // 0x130 Size: 0x1
	    bool bComponentShouldUpdatePhysicsVolume; // 0x130 Size: 0x1
	    char UnknownData1[0x5]; // 0x138
	    EPlaneConstraintAxisSetting PlaneConstraintAxisSetting; // 0x133 Size: 0x1
	    char UnknownData2[0x134]; // 0x134
	    void StopMovementImmediately(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SnapUpdatedComponentToPlane(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetUpdatedComponent(class USceneComponent* NewUpdatedComponent); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetPlaneConstraintOrigin(struct FVector PlaneOrigin); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetPlaneConstraintNormal(struct FVector PlaneNormal); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetPlaneConstraintFromVectors(struct FVector Forward, struct FVector Up); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetPlaneConstraintEnabled(bool bEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetPlaneConstraintAxisSetting(EPlaneConstraintAxisSetting NewAxisSetting); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void PhysicsVolumeChanged(class APhysicsVolume* NewVolume); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    bool K2_MoveUpdatedComponent(struct FVector Delta, struct FRotator NewRotation, struct FHitResult OutHit, bool bSweep, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    float K2_GetModifiedMaxSpeed(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    float K2_GetMaxSpeedModifier(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    bool IsExceedingMaxSpeed(float MaxSpeed); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    struct FVector GetPlaneConstraintOrigin(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    struct FVector GetPlaneConstraintNormal(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    EPlaneConstraintAxisSetting GetPlaneConstraintAxisSetting(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    class APhysicsVolume* GetPhysicsVolume(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    float GetMaxSpeed(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    float GetGravityZ(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    struct FVector ConstrainNormalToPlane(struct FVector Normal); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    struct FVector ConstrainLocationToPlane(struct FVector Location); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    struct FVector ConstrainDirectionToPlane(struct FVector Direction); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x-7ea9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MovementComponent");
			return (class UClass*)ptr;
		};

};

class UNavMovementComponent : public UMovementComponent
{
	public:
	    struct FNavAgentProperties NavAgentProps; // 0x138 Size: 0x30
	    float FixedPathBrakingDistance; // 0x168 Size: 0x4
	    bool bUpdateNavAgentWithOwnersCollision; // 0x16c Size: 0x1
	    bool bUseAccelerationForPaths; // 0x16c Size: 0x1
	    bool bUseFixedBrakingDistanceForPaths; // 0x16c Size: 0x1
	    char UnknownData0[0x2]; // 0x16f
	    struct FMovementProperties MovementState; // 0x16d Size: 0x1
	    char UnknownData1[0x2]; // 0x16e
	    class UObject* PathFollowingComp; // 0x170 Size: 0x8
	    char UnknownData2[0x178]; // 0x178
	    void StopMovementKeepPathing(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void StopActiveMovement(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool IsSwimming(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool IsMovingOnGround(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool IsFlying(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool IsFalling(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool IsCrouching(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7e69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.NavMovementComponent");
			return (class UClass*)ptr;
		};

};

class UPawnMovementComponent : public UNavMovementComponent
{
	public:
	    class APawn* PawnOwner; // 0x178 Size: 0x8
	    char UnknownData0[0x180]; // 0x180
	    struct FVector K2_GetInputVector(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool IsMoveInputIgnored(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    struct FVector GetPendingInputVector(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    class APawn* GetPawnOwner(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    struct FVector GetLastInputVector(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    struct FVector ConsumeInputVector(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void AddInputVector(struct FVector WorldVector, bool bForce); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7e61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PawnMovementComponent");
			return (class UClass*)ptr;
		};

};

class UPrimaryDataAsset : public UDataAsset
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PrimaryDataAsset");
			return (class UClass*)ptr;
		};

};

class ASpectatorPawn : public ADefaultPawn
{
	public:
	    char UnknownData0[0x3b8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SpectatorPawn");
			return (class UClass*)ptr;
		};

};

class AController : public AActor
{
	public:
	    char UnknownData0[0x8];
	    class APlayerState* PlayerState; // 0x338 Size: 0x8
	    char UnknownData1[0x8]; // 0x340
	    MulticastDelegateProperty OnInstigatedAnyDamage; // 0x348 Size: 0x10
	    FName StateName; // 0x358 Size: 0x8
	    class APawn* Pawn; // 0x360 Size: 0x8
	    char UnknownData2[0x8]; // 0x368
	    class ACharacter* Character; // 0x370 Size: 0x8
	    class USceneComponent* TransformComponent; // 0x378 Size: 0x8
	    char UnknownData3[0x18]; // 0x380
	    struct FRotator ControlRotation; // 0x398 Size: 0xc
	    bool bAttachToPawn; // 0x3a4 Size: 0x1
	    bool bIsPlayerController; // 0x3a4 Size: 0x1
	    char UnknownData4[0x3a6]; // 0x3a6
	    void UnPossess(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void StopMovement(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetInitialLocationAndRotation(struct FVector NewLocation, struct FRotator NewRotation); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetIgnoreMoveInput(bool bNewMoveInput); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetIgnoreLookInput(bool bNewLookInput); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetControlRotation(struct FRotator NewRotation); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void ResetIgnoreMoveInput(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void ResetIgnoreLookInput(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void ResetIgnoreInputFlags(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void ReceiveInstigatedAnyDamage(float Damage, class UDamageType* DamageType, class AActor* DamagedActor, class AActor* DamageCauser); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void Possess(class APawn* InPawn); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void OnRep_PlayerState(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void OnRep_Pawn(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    bool LineOfSightTo(class AActor* Other, struct FVector ViewPoint, bool bAlternateChecks); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    class APawn* K2_GetPawn(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    bool IsPlayerController(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    bool IsMoveInputIgnored(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    bool IsLookInputIgnored(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    bool IsLocalPlayerController(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    bool IsLocalController(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    class AActor* GetViewTarget(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    struct FRotator GetDesiredRotation(); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    struct FRotator GetControlRotation(); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void ClientSetRotation(struct FRotator NewRotation, bool bResetCamera); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void ClientSetLocation(struct FVector NewLocation, struct FRotator NewRotation); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    class APlayerController* CastToPlayerController(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x-7c31];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Controller");
			return (class UClass*)ptr;
		};

};

class UAISystemBase : public UObject
{
	public:
	    struct FSoftClassPath AISystemClassName; // 0x28 Size: 0x18
	    FName AISystemModuleName; // 0x40 Size: 0x8
	    bool bInstantiateAISystemOnClient; // 0x50 Size: 0x1
	    char UnknownData0[0xf];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AISystemBase");
			return (class UClass*)ptr;
		};

};

class UAvoidanceManager : public UObject
{
	public:
	    char UnknownData0[0x8];
	    float DefaultTimeToLive; // 0x30 Size: 0x4
	    float LockTimeAfterAvoid; // 0x34 Size: 0x4
	    float LockTimeAfterClean; // 0x38 Size: 0x4
	    float DeltaTimeToPredict; // 0x3c Size: 0x4
	    float ArtificialRadiusExpansion; // 0x40 Size: 0x4
	    float TestHeightDifference; // 0x44 Size: 0x4
	    float HeightCheckMargin; // 0x48 Size: 0x4
	    char UnknownData1[0x4c]; // 0x4c
	    bool RegisterMovementComponent(class UMovementComponent* MovementComp, float AvoidanceWeight); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    int GetObjectCount(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    int GetNewAvoidanceUID(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    struct FVector GetAvoidanceVelocityForComponent(class UMovementComponent* MovementComp); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7f01];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AvoidanceManager");
			return (class UClass*)ptr;
		};

};

class UProjectileMovementComponent : public UMovementComponent
{
	public:
	    float InitialSpeed; // 0x138 Size: 0x4
	    float MaxSpeed; // 0x13c Size: 0x4
	    bool bRotationFollowsVelocity; // 0x140 Size: 0x1
	    bool bShouldBounce; // 0x140 Size: 0x1
	    bool bInitialVelocityInLocalSpace; // 0x140 Size: 0x1
	    bool bForceSubStepping; // 0x140 Size: 0x1
	    bool bSimulationEnabled; // 0x140 Size: 0x1
	    bool bSweepCollision; // 0x140 Size: 0x1
	    bool bIsHomingProjectile; // 0x140 Size: 0x1
	    bool bBounceAngleAffectsFriction; // 0x140 Size: 0x1
	    bool bIsSliding; // 0x141 Size: 0x1
	    bool bInterpMovement; // 0x141 Size: 0x1
	    bool bInterpRotation; // 0x141 Size: 0x1
	    char UnknownData0[0x7]; // 0x14b
	    float PreviousHitTime; // 0x144 Size: 0x4
	    struct FVector PreviousHitNormal; // 0x148 Size: 0xc
	    float ProjectileGravityScale; // 0x154 Size: 0x4
	    float Buoyancy; // 0x158 Size: 0x4
	    float Bounciness; // 0x15c Size: 0x4
	    float Friction; // 0x160 Size: 0x4
	    float BounceVelocityStopSimulatingThreshold; // 0x164 Size: 0x4
	    float MinFrictionFraction; // 0x168 Size: 0x4
	    char UnknownData1[0x4]; // 0x16c
	    MulticastDelegateProperty OnProjectileBounce; // 0x170 Size: 0x10
	    MulticastDelegateProperty OnProjectileStop; // 0x180 Size: 0x10
	    float HomingAccelerationMagnitude; // 0x190 Size: 0x4
	    TWeakObjectPtr<USceneComponent*> HomingTargetComponent; // 0x194 Size: 0x8
	    float MaxSimulationTimeStep; // 0x19c Size: 0x4
	    int MaxSimulationIterations; // 0x1a0 Size: 0x4
	    int BounceAdditionalIterations; // 0x1a4 Size: 0x4
	    float InterpLocationTime; // 0x1a8 Size: 0x4
	    float InterpRotationTime; // 0x1ac Size: 0x4
	    float InterpLocationMaxLagDistance; // 0x1b0 Size: 0x4
	    float InterpLocationSnapToTargetDistance; // 0x1b4 Size: 0x4
	    char UnknownData2[0x1b8]; // 0x1b8
	    void StopSimulating(struct FHitResult HitResult); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetVelocityInLocalSpace(struct FVector NewVelocity); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetInterpolatedComponent(class USceneComponent* Component); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ResetInterpolation(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnProjectileStopDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnProjectileBounceDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void MoveInterpolationTarget(struct FVector NewLocation, struct FRotator NewRotation); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    struct FVector LimitVelocity(struct FVector NewVelocity); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    bool IsVelocityUnderSimulationThreshold(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    bool IsInterpolationComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7de1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ProjectileMovementComponent");
			return (class UClass*)ptr;
		};

};

class UChildActorComponent : public USceneComponent
{
	public:
	    class AActor* ChildActorClass; // 0x248 Size: 0x8
	    class AActor* ChildActor; // 0x250 Size: 0x8
	    class AActor* ChildActorTemplate; // 0x258 Size: 0x8
	    char UnknownData0[0x260]; // 0x260
	    void SetChildActorClass(class AActor* InClass); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7d61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ChildActorComponent");
			return (class UClass*)ptr;
		};

};

class UWorld : public UObject
{
	public:
	    char UnknownData0[0x8];
	    class ULevel* PersistentLevel; // 0x30 Size: 0x8
	    class UNetDriver* NetDriver; // 0x38 Size: 0x8
	    class ULineBatchComponent* LineBatcher; // 0x40 Size: 0x8
	    class ULineBatchComponent* PersistentLineBatcher; // 0x48 Size: 0x8
	    class ULineBatchComponent* ForegroundLineBatcher; // 0x50 Size: 0x8
	    class AGameNetworkManager* NetworkManager; // 0x58 Size: 0x8
	    class UPhysicsCollisionHandler* PhysicsCollisionHandler; // 0x60 Size: 0x8
	    TArray<class UObject*> ExtraReferencedObjects; // 0x68 Size: 0x10
	    TArray<class UObject*> PerModuleDataObjects; // 0x78 Size: 0x10
	    TArray<class ULevelStreaming*> StreamingLevels; // 0x88 Size: 0x10
	    struct FStreamingLevelsToConsider StreamingLevelsToConsider; // 0x98 Size: 0x28
	    struct FString StreamingLevelsPrefix; // 0xc0 Size: 0x10
	    class ULevel* CurrentLevelPendingVisibility; // 0xd0 Size: 0x8
	    class ULevel* CurrentLevelPendingInvisibility; // 0xd8 Size: 0x8
	    class UDemoNetDriver* DemoNetDriver; // 0xe0 Size: 0x8
	    class AParticleEventManager* MyParticleEventManager; // 0xe8 Size: 0x8
	    class APhysicsVolume* DefaultPhysicsVolume; // 0xf0 Size: 0x8
	    bool bAreConstraintsDirty; // 0x10e Size: 0x1
	    char UnknownData1[0x17]; // 0xf9
	    class UNavigationSystemBase* NavigationSystem; // 0x110 Size: 0x8
	    class AGameModeBase* AuthorityGameMode; // 0x118 Size: 0x8
	    class AGameStateBase* GameState; // 0x120 Size: 0x8
	    class UAISystemBase* AISystem; // 0x128 Size: 0x8
	    class UAvoidanceManager* AvoidanceManager; // 0x130 Size: 0x8
	    TArray<class ULevel*> Levels; // 0x138 Size: 0x10
	    TArray<struct FLevelCollection> LevelCollections; // 0x148 Size: 0x10
	    char UnknownData2[0x8]; // 0x158
	    class UGameInstance* OwningGameInstance; // 0x160 Size: 0x8
	    TArray<class UMaterialParameterCollectionInstance*> ParameterCollectionInstances; // 0x168 Size: 0x10
	    class UCanvas* CanvasForRenderingToTarget; // 0x178 Size: 0x8
	    class UCanvas* CanvasForDrawMaterialToRenderTarget; // 0x180 Size: 0x8
	    char UnknownData3[0x60]; // 0x188
	    TArray<class UActorComponent*> ComponentsThatNeedEndOfFrameUpdate; // 0x1e8 Size: 0x10
	    TArray<class UActorComponent*> ComponentsThatNeedEndOfFrameUpdate_OnGameThread; // 0x1f8 Size: 0x10
	    char UnknownData4[0x3b8]; // 0x208
	    class UWorldComposition* WorldComposition; // 0x5c0 Size: 0x8
	    char UnknownData5[0x70]; // 0x5c8
	    struct FWorldPSCPool PSCPool; // 0x638 Size: 0x58
	    char UnknownData6[0x690]; // 0x690
	    void HandleTimelineScrubbed(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7951];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.World");
			return (class UClass*)ptr;
		};

};

class UNavigationSystemBase : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.NavigationSystemBase");
			return (class UClass*)ptr;
		};

};

class UNavigationSystemConfig : public UObject
{
	public:
	    struct FSoftClassPath NavigationSystemClass; // 0x28 Size: 0x18
	    bool bIsOverriden; // 0x40 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.NavigationSystemConfig");
			return (class UClass*)ptr;
		};

};

class UStaticMeshComponent : public UMeshComponent
{
	public:
	    int ForcedLodModel; // 0x5a0 Size: 0x4
	    int PreviousLODLevel; // 0x5a4 Size: 0x4
	    int MinLOD; // 0x5a8 Size: 0x4
	    int SubDivisionStepSize; // 0x5ac Size: 0x4
	    class UStaticMesh* StaticMesh; // 0x5b0 Size: 0x8
	    struct FColor WireframeColorOverride; // 0x5b8 Size: 0x4
	    bool bOverrideWireframeColor; // 0x5bc Size: 0x1
	    bool bOverrideMinLod; // 0x5bc Size: 0x1
	    bool bOverrideNavigationExport; // 0x5bc Size: 0x1
	    bool bForceNavigationObstacle; // 0x5bc Size: 0x1
	    bool bDisallowMeshPaintPerInstance; // 0x5bc Size: 0x1
	    bool bIgnoreInstanceForTextureStreaming; // 0x5bc Size: 0x1
	    bool bOverrideLightMapRes; // 0x5bc Size: 0x1
	    bool bCastDistanceFieldIndirectShadow; // 0x5bc Size: 0x1
	    bool bOverrideDistanceFieldSelfShadowBias; // 0x5bd Size: 0x1
	    bool bUseSubDivisions; // 0x5bd Size: 0x1
	    bool bUseDefaultCollision; // 0x5bd Size: 0x1
	    bool bReverseCulling; // 0x5bd Size: 0x1
	    char UnknownData0[0x8]; // 0x5c8
	    int OverriddenLightMapRes; // 0x5c0 Size: 0x4
	    float DistanceFieldIndirectShadowMinVisibility; // 0x5c4 Size: 0x4
	    float DistanceFieldSelfShadowBias; // 0x5c8 Size: 0x4
	    float StreamingDistanceMultiplier; // 0x5cc Size: 0x4
	    TArray<struct FStaticMeshComponentLODInfo> LODData; // 0x5d0 Size: 0x10
	    TArray<struct FStreamingTextureBuildInfo> StreamingTextureData; // 0x5e0 Size: 0x10
	    struct FLightmassPrimitiveSettings LightmassSettings; // 0x5f0 Size: 0x18
	    char UnknownData1[0x608]; // 0x608
	    bool SetStaticMesh(class UStaticMesh* NewMesh); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetReverseCulling(bool ReverseCulling); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetForcedLodModel(int NewForcedLodModel); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetDistanceFieldSelfShadowBias(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnRep_StaticMesh(class UStaticMesh* OldStaticMesh); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void GetLocalBounds(struct FVector Min, struct FVector Max); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-79d1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.StaticMeshComponent");
			return (class UClass*)ptr;
		};

};

class UAnimNotify : public UObject
{
	public:
	    bool Received_Notify(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    struct FString GetNotifyName(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7fa9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimNotify");
			return (class UClass*)ptr;
		};

};

class UAnimNotify_PlaySound : public UAnimNotify
{
	public:
	    class USoundBase* Sound; // 0x38 Size: 0x8
	    float VolumeMultiplier; // 0x40 Size: 0x4
	    float PitchMultiplier; // 0x44 Size: 0x4
	    bool bFollow; // 0x48 Size: 0x1
	    char UnknownData0[0x3]; // 0x49
	    FName AttachName; // 0x4c Size: 0x8
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimNotify_PlaySound");
			return (class UClass*)ptr;
		};

};

class UAnimNotify_PlayParticleEffect : public UAnimNotify
{
	public:
	    class UParticleSystem* PSTemplate; // 0x38 Size: 0x8
	    struct FVector LocationOffset; // 0x40 Size: 0xc
	    struct FRotator RotationOffset; // 0x4c Size: 0xc
	    struct FVector Scale; // 0x58 Size: 0xc
	    bool Attached; // 0x80 Size: 0x1
	    char UnknownData0[0x1f]; // 0x65
	    FName SocketName; // 0x84 Size: 0x8
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimNotify_PlayParticleEffect");
			return (class UClass*)ptr;
		};

};

class UAnimNotifyState : public UObject
{
	public:
	    bool Received_NotifyTick(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, float FrameDeltaTime); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    bool Received_NotifyEnd(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    bool Received_NotifyBegin(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, float TotalDuration); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    struct FString GetNotifyName(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7fb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimNotifyState");
			return (class UClass*)ptr;
		};

};

class ACameraActor : public AActor
{
	public:
	    char AutoActivateForPlayer; // 0x330 Size: 0x1
	    char UnknownData0[0x7]; // 0x331
	    class UCameraComponent* CameraComponent; // 0x338 Size: 0x8
	    class USceneComponent* SceneComponent; // 0x340 Size: 0x8
	    bool bConstrainAspectRatio; // 0x350 Size: 0x1
	    char UnknownData1[0xb]; // 0x349
	    float AspectRatio; // 0x354 Size: 0x4
	    float FOVAngle; // 0x358 Size: 0x4
	    float PostProcessBlendWeight; // 0x35c Size: 0x4
	    struct FPostProcessSettings PostProcessSettings; // 0x360 Size: 0x4e0
	    char UnknownData2[0x840]; // 0x840
	    int GetAutoActivatePlayerIndex(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-77a1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CameraActor");
			return (class UClass*)ptr;
		};

};

class UAssetManager : public UObject
{
	public:
	    char UnknownData0[0x288];
	    TArray<class UObject*> ObjectReferenceList; // 0x2b0 Size: 0x10
	    bool bIsGlobalAsyncScanEnvironment; // 0x2c0 Size: 0x1
	    bool bShouldGuessTypeAndName; // 0x2c1 Size: 0x1
	    bool bShouldUseSynchronousLoad; // 0x2c2 Size: 0x1
	    bool bIsLoadingFromPakFiles; // 0x2c3 Size: 0x1
	    bool bShouldAcquireMissingChunksOnLoad; // 0x2c4 Size: 0x1
	    bool bOnlyCookProductionAssets; // 0x2c5 Size: 0x1
	    bool bIsBulkScanning; // 0x2c6 Size: 0x1
	    bool bIsPrimaryAssetDirectoryCurrent; // 0x2c7 Size: 0x1
	    bool bIsManagementDatabaseCurrent; // 0x2c8 Size: 0x1
	    bool bUpdateManagementDatabaseAfterScan; // 0x2c9 Size: 0x1
	    bool bIncludeOnlyOnDiskAssets; // 0x2ca Size: 0x1
	    char UnknownData1[0x1]; // 0x2cb
	    int NumberOfSpawnedNotifications; // 0x2cc Size: 0x4
	    char UnknownData2[0x158];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AssetManager");
			return (class UClass*)ptr;
		};

};

class APlayerController : public AController
{
	public:
	    class UPlayer* Player; // 0x3b0 Size: 0x8
	    class APawn* AcknowledgedPawn; // 0x3b8 Size: 0x8
	    class UInterpTrackInstDirector* ControllingDirTrackInst; // 0x3c0 Size: 0x8
	    class AHUD* MyHUD; // 0x3c8 Size: 0x8
	    class APlayerCameraManager* PlayerCameraManager; // 0x3d0 Size: 0x8
	    class APlayerCameraManager* PlayerCameraManagerClass; // 0x3d8 Size: 0x8
	    bool bAutoManageActiveCameraTarget; // 0x3e0 Size: 0x1
	    char UnknownData0[0x3]; // 0x3e1
	    struct FRotator TargetViewRotation; // 0x3e4 Size: 0xc
	    char UnknownData1[0xc]; // 0x3f0
	    float SmoothTargetViewRotationSpeed; // 0x3fc Size: 0x4
	    char UnknownData2[0x8]; // 0x400
	    TArray<class AActor*> HiddenActors; // 0x408 Size: 0x10
	    TArray<TWeakObjectPtr<UPrimitiveComponent*>> HiddenPrimitiveComponents; // 0x418 Size: 0x10
	    char UnknownData3[0x4]; // 0x428
	    float LastSpectatorStateSynchTime; // 0x42c Size: 0x4
	    struct FVector LastSpectatorSyncLocation; // 0x430 Size: 0xc
	    struct FRotator LastSpectatorSyncRotation; // 0x43c Size: 0xc
	    int ClientCap; // 0x448 Size: 0x4
	    char UnknownData4[0x4]; // 0x44c
	    class UCheatManager* CheatManager; // 0x450 Size: 0x8
	    class UCheatManager* CheatClass; // 0x458 Size: 0x8
	    class UPlayerInput* PlayerInput; // 0x460 Size: 0x8
	    TArray<struct FActiveForceFeedbackEffect> ActiveForceFeedbackEffects; // 0x468 Size: 0x10
	    bool bPlayerIsWaiting; // 0x4e8 Size: 0x1
	    char UnknownData5[0x73]; // 0x479
	    char NetPlayerIndex; // 0x4ec Size: 0x1
	    char UnknownData6[0x3b]; // 0x4ed
	    class UNetConnection* PendingSwapConnection; // 0x528 Size: 0x8
	    class UNetConnection* NetConnection; // 0x530 Size: 0x8
	    char UnknownData7[0xc]; // 0x538
	    float InputYawScale; // 0x544 Size: 0x4
	    float InputPitchScale; // 0x548 Size: 0x4
	    float InputRollScale; // 0x54c Size: 0x4
	    bool bShowMouseCursor; // 0x550 Size: 0x1
	    bool bEnableClickEvents; // 0x550 Size: 0x1
	    bool bEnableTouchEvents; // 0x550 Size: 0x1
	    bool bEnableMouseOverEvents; // 0x550 Size: 0x1
	    bool bEnableTouchOverEvents; // 0x550 Size: 0x1
	    bool bForceFeedbackEnabled; // 0x550 Size: 0x1
	    char UnknownData8[0x2]; // 0x556
	    float ForceFeedbackScale; // 0x554 Size: 0x4
	    TArray<struct FKey> ClickEventKeys; // 0x558 Size: 0x10
	    char DefaultMouseCursor; // 0x568 Size: 0x1
	    char CurrentMouseCursor; // 0x569 Size: 0x1
	    char DefaultClickTraceChannel; // 0x56a Size: 0x1
	    char CurrentClickTraceChannel; // 0x56b Size: 0x1
	    float HitResultTraceDistance; // 0x56c Size: 0x4
	    __int64/*UInt16Property*/ SeamlessTravelCount; // 0x570 Size: 0x2
	    __int64/*UInt16Property*/ LastCompletedSeamlessTravelCount; // 0x572 Size: 0x2
	    char UnknownData9[0x74]; // 0x574
	    class UInputComponent* InactiveStateInputComponent; // 0x5e8 Size: 0x8
	    bool bShouldPerformFullTickWhenPaused; // 0x5f0 Size: 0x1
	    char UnknownData10[0x17]; // 0x5f1
	    class UTouchInterface* CurrentTouchInterface; // 0x608 Size: 0x8
	    char UnknownData11[0x50]; // 0x610
	    class ASpectatorPawn* SpectatorPawn; // 0x660 Size: 0x8
	    bool bIsLocalPlayerController; // 0x66c Size: 0x1
	    char UnknownData12[0x7]; // 0x669
	    struct FVector SpawnLocation; // 0x670 Size: 0xc
	    char UnknownData13[0x67c]; // 0x67c
	    bool WasInputKeyJustReleased(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    bool WasInputKeyJustPressed(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void ToggleSpeaking(bool bInSpeaking); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void SwitchLevel(struct FString URL); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void StopHapticEffect(EControllerHand Hand); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void StartFire(char FireModeNum); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void SetVirtualJoystickVisibility(bool bVisible); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void SetViewTargetWithBlend(class AActor* NewViewTarget, float BlendTime, char BlendFunc, float BlendExp, bool bLockOutgoing); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void SetName(struct FString S); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void SetMouseLocation(int X, int Y); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void SetMouseCursorWidget(char Cursor, class UUserWidget* CursorWidget); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void SetHapticsByValue(float Frequency, float Amplitude, EControllerHand Hand); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void SetDisableHaptics(bool bNewDisabled); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void SetControllerLightColor(struct FColor Color); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void SetCinematicMode(bool bInCinematicMode, bool bHidePlayer, bool bAffectsHUD, bool bAffectsMovement, bool bAffectsTurning); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void SetAudioListenerOverride(class USceneComponent* AttachToComponent, struct FVector Location, struct FRotator Rotation); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    void SetAudioListenerAttenuationOverride(class USceneComponent* AttachToComponent, struct FVector AttenuationLocationOVerride); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    void ServerViewSelf(struct FViewTargetTransitionParams TransitionParams); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    void ServerViewPrevPlayer(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    void ServerViewNextPlayer(); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    void ServerVerifyViewTarget(); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    void ServerUpdateMultipleLevelsVisibility(TArray<struct FUpdateLevelVisibilityLevelInfo> LevelVisibilities); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    void ServerUpdateLevelVisibility(FName PackageName, bool bIsVisible); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    void ServerUpdateCamera(struct FVector_NetQuantize CamLoc, int CamPitchAndYaw); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    void ServerUnmutePlayer(struct FUniqueNetIdRepl PlayerID); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    void ServerToggleAILogging(); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    void ServerShortTimeout(); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    void ServerSetSpectatorWaiting(bool bWaiting); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    void ServerSetSpectatorLocation(struct FVector NewLoc, struct FRotator NewRot); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    void ServerRestartPlayer(); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    void ServerPause(); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    void ServerNotifyLoadedWorld(FName WorldPackageName); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    void ServerMutePlayer(struct FUniqueNetIdRepl PlayerID); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    void ServerCheckClientPossessionReliable(); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    void ServerCheckClientPossession(); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    void ServerChangeName(struct FString S); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    void ServerCamera(FName NewMode); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    void ServerAcknowledgePossession(class APawn* P); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    void SendToConsole(struct FString Command); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    void RestartLevel(); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    void ResetControllerLightColor(); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    bool ProjectWorldLocationToScreen(struct FVector WorldLocation, struct FVector2D ScreenLocation, bool bPlayerViewportRelative); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    void PlayHapticEffect(class UHapticFeedbackEffect_Base* HapticEffect, EControllerHand Hand, float Scale, bool bLoop); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    void PlayDynamicForceFeedback(float Intensity, float Duration, bool bAffectsLeftLarge, bool bAffectsLeftSmall, bool bAffectsRightLarge, bool bAffectsRightSmall, char Action, struct FLatentActionInfo LatentInfo); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    void Pause(); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    void OnServerStartedVisualLogger(bool bIsLogging); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    void LocalTravel(struct FString URL); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    bool IsInputKeyDown(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    void GetViewportSize(int SizeX, int SizeY); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x7fe1]; // 0x7fe1
	    class ASpectatorPawn* GetSpectatorPawn(); // 0x0 Size: 0x7fe1
	    char UnknownData63[0x7fe1]; // 0x7fe1
	    bool GetMousePosition(float LocationX, float LocationY); // 0x0 Size: 0x7fe1
	    char UnknownData64[0x7fe1]; // 0x7fe1
	    struct FVector GetInputVectorKeyState(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData65[0x7fe1]; // 0x7fe1
	    void GetInputTouchState(char FingerIndex, float LocationX, float LocationY, bool bIsCurrentlyPressed); // 0x0 Size: 0x7fe1
	    char UnknownData66[0x7fe1]; // 0x7fe1
	    void GetInputMouseDelta(float DeltaX, float DeltaY); // 0x0 Size: 0x7fe1
	    char UnknownData67[0x7fe1]; // 0x7fe1
	    void GetInputMotionState(struct FVector Tilt, struct FVector RotationRate, struct FVector Gravity, struct FVector Acceleration); // 0x0 Size: 0x7fe1
	    char UnknownData68[0x7fe1]; // 0x7fe1
	    float GetInputKeyTimeDown(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData69[0x7fe1]; // 0x7fe1
	    void GetInputAnalogStickState(char WhichStick, float StickX, float StickY); // 0x0 Size: 0x7fe1
	    char UnknownData70[0x7fe1]; // 0x7fe1
	    float GetInputAnalogKeyState(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData71[0x7fe1]; // 0x7fe1
	    class AHUD* GetHUD(); // 0x0 Size: 0x7fe1
	    char UnknownData72[0x7fe1]; // 0x7fe1
	    bool GetHitResultUnderFingerForObjects(char FingerIndex, TArray<char> ObjectTypes, bool bTraceComplex, struct FHitResult HitResult); // 0x0 Size: 0x7fe1
	    char UnknownData73[0x7fe1]; // 0x7fe1
	    bool GetHitResultUnderFingerByChannel(char FingerIndex, char TraceChannel, bool bTraceComplex, struct FHitResult HitResult); // 0x0 Size: 0x7fe1
	    char UnknownData74[0x7fe1]; // 0x7fe1
	    bool GetHitResultUnderFinger(char FingerIndex, char TraceChannel, bool bTraceComplex, struct FHitResult HitResult); // 0x0 Size: 0x7fe1
	    char UnknownData75[0x7fe1]; // 0x7fe1
	    bool GetHitResultUnderCursorForObjects(TArray<char> ObjectTypes, bool bTraceComplex, struct FHitResult HitResult); // 0x0 Size: 0x7fe1
	    char UnknownData76[0x7fe1]; // 0x7fe1
	    bool GetHitResultUnderCursorByChannel(char TraceChannel, bool bTraceComplex, struct FHitResult HitResult); // 0x0 Size: 0x7fe1
	    char UnknownData77[0x7fe1]; // 0x7fe1
	    bool GetHitResultUnderCursor(char TraceChannel, bool bTraceComplex, struct FHitResult HitResult); // 0x0 Size: 0x7fe1
	    char UnknownData78[0x7fe1]; // 0x7fe1
	    struct FVector GetFocalLocation(); // 0x0 Size: 0x7fe1
	    char UnknownData79[0x7fe1]; // 0x7fe1
	    void FOV(float NewFOV); // 0x0 Size: 0x7fe1
	    char UnknownData80[0x7fe1]; // 0x7fe1
	    void EnableCheats(); // 0x0 Size: 0x7fe1
	    char UnknownData81[0x7fe1]; // 0x7fe1
	    bool DeprojectScreenPositionToWorld(float ScreenX, float ScreenY, struct FVector WorldLocation, struct FVector WorldDirection); // 0x0 Size: 0x7fe1
	    char UnknownData82[0x7fe1]; // 0x7fe1
	    bool DeprojectMousePositionToWorld(struct FVector WorldLocation, struct FVector WorldDirection); // 0x0 Size: 0x7fe1
	    char UnknownData83[0x7fe1]; // 0x7fe1
	    void ConsoleKey(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData84[0x7fe1]; // 0x7fe1
	    void ClientWasKicked(struct FText KickReason); // 0x0 Size: 0x7fe1
	    char UnknownData85[0x7fe1]; // 0x7fe1
	    void ClientVoiceHandshakeComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData86[0x7fe1]; // 0x7fe1
	    void ClientUpdateMultipleLevelsStreamingStatus(TArray<struct FUpdateLevelStreamingLevelStatus> LevelStatuses); // 0x0 Size: 0x7fe1
	    char UnknownData87[0x7fe1]; // 0x7fe1
	    void ClientUpdateLevelStreamingStatus(FName PackageName, bool bNewShouldBeLoaded, bool bNewShouldBeVisible, bool bNewShouldBlockOnLoad, int LODIndex); // 0x0 Size: 0x7fe1
	    char UnknownData88[0x7fe1]; // 0x7fe1
	    void ClientUnmutePlayer(struct FUniqueNetIdRepl PlayerID); // 0x0 Size: 0x7fe1
	    char UnknownData89[0x7fe1]; // 0x7fe1
	    void ClientTravelInternal(struct FString URL, char TravelType, bool bSeamless, struct FGuid MapPackageGuid); // 0x0 Size: 0x7fe1
	    char UnknownData90[0x7fe1]; // 0x7fe1
	    void ClientTravel(struct FString URL, char TravelType, bool bSeamless, struct FGuid MapPackageGuid); // 0x0 Size: 0x7fe1
	    char UnknownData91[0x7fe1]; // 0x7fe1
	    void ClientTeamMessage(class APlayerState* SenderPlayerState, struct FString S, FName Type, float MsgLifeTime); // 0x0 Size: 0x7fe1
	    char UnknownData92[0x7fe1]; // 0x7fe1
	    void ClientStopForceFeedback(class UForceFeedbackEffect* ForceFeedbackEffect, FName Tag); // 0x0 Size: 0x7fe1
	    char UnknownData93[0x7fe1]; // 0x7fe1
	    void ClientStopCameraShake(class UCameraShake* Shake, bool bImmediately); // 0x0 Size: 0x7fe1
	    char UnknownData94[0x7fe1]; // 0x7fe1
	    void ClientStopCameraAnim(class UCameraAnim* AnimToStop); // 0x0 Size: 0x7fe1
	    char UnknownData95[0x7fe1]; // 0x7fe1
	    void ClientStartOnlineSession(); // 0x0 Size: 0x7fe1
	    char UnknownData96[0x7fe1]; // 0x7fe1
	    void ClientSpawnCameraLensEffect(class AEmitterCameraLensEffectBase* LensEffectEmitterClass); // 0x0 Size: 0x7fe1
	    char UnknownData97[0x7fe1]; // 0x7fe1
	    void ClientSetViewTarget(class AActor* A, struct FViewTargetTransitionParams TransitionParams); // 0x0 Size: 0x7fe1
	    char UnknownData98[0x7fe1]; // 0x7fe1
	    void ClientSetSpectatorWaiting(bool bWaiting); // 0x0 Size: 0x7fe1
	    char UnknownData99[0x7fe1]; // 0x7fe1
	    void ClientSetHUD(class AHUD* NewHUDClass); // 0x0 Size: 0x7fe1
	    char UnknownData100[0x7fe1]; // 0x7fe1
	    void ClientSetForceMipLevelsToBeResident(class UMaterialInterface* Material, float ForceDuration, int CinematicTextureGroups); // 0x0 Size: 0x7fe1
	    char UnknownData101[0x7fe1]; // 0x7fe1
	    void ClientSetCinematicMode(bool bInCinematicMode, bool bAffectsMovement, bool bAffectsTurning, bool bAffectsHUD); // 0x0 Size: 0x7fe1
	    char UnknownData102[0x7fe1]; // 0x7fe1
	    void ClientSetCameraMode(FName NewCamMode); // 0x0 Size: 0x7fe1
	    char UnknownData103[0x7fe1]; // 0x7fe1
	    void ClientSetCameraFade(bool bEnableFading, struct FColor FadeColor, struct FVector2D FadeAlpha, float FadeTime, bool bFadeAudio); // 0x0 Size: 0x7fe1
	    char UnknownData104[0x7fe1]; // 0x7fe1
	    void ClientSetBlockOnAsyncLoading(); // 0x0 Size: 0x7fe1
	    char UnknownData105[0x7fe1]; // 0x7fe1
	    void ClientReturnToMainMenuWithTextReason(struct FText ReturnReason); // 0x0 Size: 0x7fe1
	    char UnknownData106[0x7fe1]; // 0x7fe1
	    void ClientReturnToMainMenu(struct FString ReturnReason); // 0x0 Size: 0x7fe1
	    char UnknownData107[0x7fe1]; // 0x7fe1
	    void ClientRetryClientRestart(class APawn* NewPawn); // 0x0 Size: 0x7fe1
	    char UnknownData108[0x7fe1]; // 0x7fe1
	    void ClientRestart(class APawn* NewPawn); // 0x0 Size: 0x7fe1
	    char UnknownData109[0x7fe1]; // 0x7fe1
	    void ClientReset(); // 0x0 Size: 0x7fe1
	    char UnknownData110[0x7fe1]; // 0x7fe1
	    void ClientRepObjRef(class UObject* Object); // 0x0 Size: 0x7fe1
	    char UnknownData111[0x7fe1]; // 0x7fe1
	    void ClientReceiveLocalizedMessage(class ULocalMessage* MESSAGE, int Switch, class APlayerState* RelatedPlayerState_1, class APlayerState* RelatedPlayerState_2, class UObject* OptionalObject); // 0x0 Size: 0x7fe1
	    char UnknownData112[0x7fe1]; // 0x7fe1
	    void ClientPrestreamTextures(class AActor* ForcedActor, float ForceDuration, bool bEnableStreaming, int CinematicTextureGroups); // 0x0 Size: 0x7fe1
	    char UnknownData113[0x7fe1]; // 0x7fe1
	    void ClientPrepareMapChange(FName LevelName, bool bFirst, bool bLast); // 0x0 Size: 0x7fe1
	    char UnknownData114[0x7fe1]; // 0x7fe1
	    void ClientPlaySoundAtLocation(class USoundBase* Sound, struct FVector Location, float VolumeMultiplier, float PitchMultiplier); // 0x0 Size: 0x7fe1
	    char UnknownData115[0x7fe1]; // 0x7fe1
	    void ClientPlaySound(class USoundBase* Sound, float VolumeMultiplier, float PitchMultiplier); // 0x0 Size: 0x7fe1
	    char UnknownData116[0x7fe1]; // 0x7fe1
	    void ClientPlayForceFeedback(class UForceFeedbackEffect* ForceFeedbackEffect, bool bLooping, bool bIgnoreTimeDilation, FName Tag); // 0x0 Size: 0x7fe1
	    char UnknownData117[0x7fe1]; // 0x7fe1
	    void ClientPlayCameraShake(class UCameraShake* Shake, float Scale, char PlaySpace, struct FRotator UserPlaySpaceRot); // 0x0 Size: 0x7fe1
	    char UnknownData118[0x7fe1]; // 0x7fe1
	    void ClientPlayCameraAnim(class UCameraAnim* AnimToPlay, float Scale, float Rate, float BlendInTime, float BlendOutTime, bool bLoop, bool bRandomStartTime, char Space, struct FRotator CustomPlaySpace); // 0x0 Size: 0x7fe1
	    char UnknownData119[0x7fe1]; // 0x7fe1
	    void ClientMutePlayer(struct FUniqueNetIdRepl PlayerID); // 0x0 Size: 0x7fe1
	    char UnknownData120[0x7fe1]; // 0x7fe1
	    void ClientMessage(struct FString S, FName Type, float MsgLifeTime); // 0x0 Size: 0x7fe1
	    char UnknownData121[0x7fe1]; // 0x7fe1
	    void ClientIgnoreMoveInput(bool bIgnore); // 0x0 Size: 0x7fe1
	    char UnknownData122[0x7fe1]; // 0x7fe1
	    void ClientIgnoreLookInput(bool bIgnore); // 0x0 Size: 0x7fe1
	    char UnknownData123[0x7fe1]; // 0x7fe1
	    void ClientGotoState(FName NewState); // 0x0 Size: 0x7fe1
	    char UnknownData124[0x7fe1]; // 0x7fe1
	    void ClientGameEnded(class AActor* EndGameFocus, bool bIsWinner); // 0x0 Size: 0x7fe1
	    char UnknownData125[0x7fe1]; // 0x7fe1
	    void ClientForceGarbageCollection(); // 0x0 Size: 0x7fe1
	    char UnknownData126[0x7fe1]; // 0x7fe1
	    void ClientFlushLevelStreaming(); // 0x0 Size: 0x7fe1
	    char UnknownData127[0x7fe1]; // 0x7fe1
	    void ClientEndOnlineSession(); // 0x0 Size: 0x7fe1
	    char UnknownData128[0x7fe1]; // 0x7fe1
	    void ClientEnableNetworkVoice(bool bEnable); // 0x0 Size: 0x7fe1
	    char UnknownData129[0x7fe1]; // 0x7fe1
	    void ClientCommitMapChange(); // 0x0 Size: 0x7fe1
	    char UnknownData130[0x7fe1]; // 0x7fe1
	    void ClientClearCameraLensEffects(); // 0x0 Size: 0x7fe1
	    char UnknownData131[0x7fe1]; // 0x7fe1
	    void ClientCapBandwidth(int Cap); // 0x0 Size: 0x7fe1
	    char UnknownData132[0x7fe1]; // 0x7fe1
	    void ClientCancelPendingMapChange(); // 0x0 Size: 0x7fe1
	    char UnknownData133[0x7fe1]; // 0x7fe1
	    void ClientAddTextureStreamingLoc(struct FVector InLoc, float Duration, bool bOverrideLocation); // 0x0 Size: 0x7fe1
	    char UnknownData134[0x7fe1]; // 0x7fe1
	    void ClearAudioListenerOverride(); // 0x0 Size: 0x7fe1
	    char UnknownData135[0x7fe1]; // 0x7fe1
	    void ClearAudioListenerAttenuationOverride(); // 0x0 Size: 0x7fe1
	    char UnknownData136[0x7fe1]; // 0x7fe1
	    bool CanRestartPlayer(); // 0x0 Size: 0x7fe1
	    char UnknownData137[0x7fe1]; // 0x7fe1
	    void Camera(FName NewMode); // 0x0 Size: 0x7fe1
	    char UnknownData138[0x7fe1]; // 0x7fe1
	    void AddYawInput(float Val); // 0x0 Size: 0x7fe1
	    char UnknownData139[0x7fe1]; // 0x7fe1
	    void AddRollInput(float Val); // 0x0 Size: 0x7fe1
	    char UnknownData140[0x7fe1]; // 0x7fe1
	    void AddPitchInput(float Val); // 0x0 Size: 0x7fe1
	    char UnknownData141[0x7fe1]; // 0x7fe1
	    void ActivateTouchInterface(class UTouchInterface* NewTouchInterface); // 0x0 Size: 0x7fe1
	    char UnknownData142[0x-7961];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PlayerController");
			return (class UClass*)ptr;
		};

};

class UCheatManager : public UObject
{
	public:
	    class ADebugCameraController* DebugCameraControllerRef; // 0x28 Size: 0x8
	    class ADebugCameraController* DebugCameraControllerClass; // 0x30 Size: 0x8
	    char UnknownData0[0x38]; // 0x38
	    void Walk(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void ViewSelf(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void ViewPlayer(struct FString S); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void ViewClass(class AActor* DesiredClass); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void ViewActor(FName ActorName); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void UpdateSafeArea(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ToggleServerStatReplicatorUpdateStatNet(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void ToggleServerStatReplicatorClientOverwrite(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void ToggleDebugCamera(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void ToggleAILogging(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void TestCollisionDistance(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void Teleport(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void Summon(struct FString ClassName); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void StreamLevelOut(FName PackageName); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void StreamLevelIn(FName PackageName); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void SpawnServerStatReplicator(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void Slomo(float NewTimeDilation); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void SetWorldOrigin(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void SetMouseSensitivityToDefault(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void ServerToggleAILogging(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void ReceiveInitCheatManager(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void ReceiveEndPlay(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void PlayersOnly(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void OnlyLoadLevel(FName PackageName); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void LogLoc(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void InvertMouse(); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void God(); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void Ghost(); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void FreezeFrame(float Delay); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    void Fly(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    void FlushLog(); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    void EnableDebugCamera(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    void DumpVoiceMutingState(); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    void DumpPartyState(); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    void DumpOnlineSessionState(); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    void DumpChatState(); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    void DisableDebugCamera(); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    void DestroyTarget(); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    void DestroyServerStatReplicator(); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    void DestroyPawns(class APawn* aClass); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    void DestroyAllPawnsExceptTarget(); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    void DestroyAll(class AActor* aClass); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    void DebugCapsuleSweepSize(float HalfHeight, float Radius); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    void DebugCapsuleSweepPawn(); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    void DebugCapsuleSweepComplex(bool bTraceComplex); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    void DebugCapsuleSweepClear(); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    void DebugCapsuleSweepChannel(char Channel); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    void DebugCapsuleSweepCapture(); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    void DebugCapsuleSweep(); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    void DamageTarget(float DamageAmount); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    void CheatScript(struct FString ScriptName); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    void ChangeSize(float F); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    void BugItStringCreator(struct FVector ViewLocation, struct FRotator ViewRotation, struct FString GoString, struct FString LocString); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    void BugItGo(float X, float Y, float Z, float Pitch, float Yaw, float Roll); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    void BugIt(struct FString ScreenShotDescription); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x-7f69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CheatManager");
			return (class UClass*)ptr;
		};

};

class UScriptViewportClient : public UObject
{
	public:
	    char UnknownData0[0x38];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ScriptViewportClient");
			return (class UClass*)ptr;
		};

};

class UGameViewportClient : public UScriptViewportClient
{
	public:
	    char UnknownData0[0x8];
	    class UConsole* ViewportConsole; // 0x40 Size: 0x8
	    TArray<struct FDebugDisplayProperty> DebugProperties; // 0x48 Size: 0x10
	    char UnknownData1[0x20]; // 0x58
	    class UWorld* World; // 0x78 Size: 0x8
	    class UGameInstance* GameInstance; // 0x80 Size: 0x8
	    char UnknownData2[0x88]; // 0x88
	    void SSSwapControllers(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void ShowTitleSafeArea(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetConsoleTarget(int PlayerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7cf9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.GameViewportClient");
			return (class UClass*)ptr;
		};

};

class UConsole : public UObject
{
	public:
	    char UnknownData0[0x10];
	    class ULocalPlayer* ConsoleTargetPlayer; // 0x38 Size: 0x8
	    class UTexture2D* DefaultTexture_Black; // 0x40 Size: 0x8
	    class UTexture2D* DefaultTexture_White; // 0x48 Size: 0x8
	    char UnknownData1[0x18]; // 0x50
	    TArray<struct FString> HistoryBuffer; // 0x68 Size: 0x10
	    char UnknownData2[0xb8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Console");
			return (class UClass*)ptr;
		};

};

class AEmitter : public AActor
{
	public:
	    class UParticleSystemComponent* ParticleSystemComponent; // 0x330 Size: 0x8
	    bool bDestroyOnSystemFinish; // 0x338 Size: 0x1
	    bool bPostUpdateTickGroup; // 0x338 Size: 0x1
	    bool bCurrentlyActive; // 0x338 Size: 0x1
	    char UnknownData0[0x5]; // 0x33b
	    MulticastDelegateProperty OnParticleSpawn; // 0x340 Size: 0x10
	    MulticastDelegateProperty OnParticleBurst; // 0x350 Size: 0x10
	    MulticastDelegateProperty OnParticleDeath; // 0x360 Size: 0x10
	    MulticastDelegateProperty OnParticleCollide; // 0x370 Size: 0x10
	    char UnknownData1[0x380]; // 0x380
	    void ToggleActive(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetVectorParameter(FName ParameterName, struct FVector Param); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetTemplate(class UParticleSystem* NewTemplate); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetMaterialParameter(FName ParameterName, class UMaterialInterface* Param); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetFloatParameter(FName ParameterName, float Param); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetColorParameter(FName ParameterName, struct FLinearColor Param); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetActorParameter(FName ParameterName, class AActor* Param); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnRep_bCurrentlyActive(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnParticleSystemFinished(class UParticleSystemComponent* FinishedComponent); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    bool IsActive(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void Deactivate(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void Activate(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x-7c61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Emitter");
			return (class UClass*)ptr;
		};

};

class AEmitterCameraLensEffectBase : public AEmitter
{
	public:
	    class UParticleSystem* PS_CameraEffect; // 0x380 Size: 0x8
	    class UParticleSystem* PS_CameraEffectNonExtremeContent; // 0x388 Size: 0x8
	    class APlayerCameraManager* BaseCamera; // 0x390 Size: 0x8
	    char UnknownData0[0x8]; // 0x398
	    struct FTransform RelativeTransform; // 0x3a0 Size: 0x30
	    float BaseFOV; // 0x3d0 Size: 0x4
	    bool bAllowMultipleInstances; // 0x3d4 Size: 0x1
	    bool bResetWhenRetriggered; // 0x3d4 Size: 0x1
	    char UnknownData1[0x2]; // 0x3d6
	    TArray<class AEmitterCameraLensEffectBase*> EmittersToTreatAsSame; // 0x3d8 Size: 0x10
	    float DistFromCamera; // 0x3e8 Size: 0x4
	    char UnknownData2[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.EmitterCameraLensEffectBase");
			return (class UClass*)ptr;
		};

};

class UGameEngine : public UEngine
{
	public:
	    float MaxDeltaTime; // 0xca8 Size: 0x4
	    float ServerFlushLogInterval; // 0xcac Size: 0x4
	    class UGameInstance* GameInstance; // 0xcb0 Size: 0x8
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.GameEngine");
			return (class UClass*)ptr;
		};

};

class APlayerCameraManager : public AActor
{
	public:
	    class APlayerController* PCOwner; // 0x330 Size: 0x8
	    class USceneComponent* TransformComponent; // 0x338 Size: 0x8
	    char UnknownData0[0x8]; // 0x340
	    float DefaultFOV; // 0x348 Size: 0x4
	    char UnknownData1[0x4]; // 0x34c
	    float DefaultOrthoWidth; // 0x350 Size: 0x4
	    char UnknownData2[0x4]; // 0x354
	    float DefaultAspectRatio; // 0x358 Size: 0x4
	    char UnknownData3[0x44]; // 0x35c
	    struct FCameraCacheEntry CameraCache; // 0x3a0 Size: 0x540
	    struct FCameraCacheEntry LastFrameCameraCache; // 0x8e0 Size: 0x540
	    struct FTViewTarget ViewTarget; // 0xe20 Size: 0x550
	    struct FTViewTarget PendingViewTarget; // 0x1370 Size: 0x550
	    char UnknownData4[0x20]; // 0x18c0
	    struct FCameraCacheEntry CameraCachePrivate; // 0x18e0 Size: 0x540
	    struct FCameraCacheEntry LastFrameCameraCachePrivate; // 0x1e20 Size: 0x540
	    TArray<class UCameraModifier*> ModifierList; // 0x2360 Size: 0x10
	    TArray<class UCameraModifier*> DefaultModifiers; // 0x2370 Size: 0x10
	    float FreeCamDistance; // 0x2380 Size: 0x4
	    struct FVector FreeCamOffset; // 0x2384 Size: 0xc
	    struct FVector ViewTargetOffset; // 0x2390 Size: 0xc
	    char UnknownData5[0x14]; // 0x239c
	    TArray<class AEmitterCameraLensEffectBase*> CameraLensEffects; // 0x23b0 Size: 0x10
	    class UCameraModifier_CameraShake* CachedCameraShakeMod; // 0x23c0 Size: 0x8
	    class UCameraAnimInst* AnimInstPool; // 0x23c8 Size: 0x8
	    char UnknownData6[0x38]; // 0x23d0
	    TArray<struct FPostProcessSettings> PostProcessBlendCache; // 0x2408 Size: 0x10
	    char UnknownData7[0x10]; // 0x2418
	    TArray<class UCameraAnimInst*> ActiveAnims; // 0x2428 Size: 0x10
	    TArray<class UCameraAnimInst*> FreeAnims; // 0x2438 Size: 0x10
	    class ACameraActor* AnimCameraActor; // 0x2448 Size: 0x8
	    bool bIsOrthographic; // 0x2450 Size: 0x1
	    bool bDefaultConstrainAspectRatio; // 0x2450 Size: 0x1
	    bool bClientSimulatingViewTarget; // 0x2450 Size: 0x1
	    bool bUseClientSideCameraUpdates; // 0x2450 Size: 0x1
	    bool bGameCameraCutThisFrame; // 0x2451 Size: 0x1
	    char UnknownData8[0x1]; // 0x2455
	    float ViewPitchMin; // 0x2454 Size: 0x4
	    float ViewPitchMax; // 0x2458 Size: 0x4
	    float ViewYawMin; // 0x245c Size: 0x4
	    float ViewYawMax; // 0x2460 Size: 0x4
	    float ViewRollMin; // 0x2464 Size: 0x4
	    float ViewRollMax; // 0x2468 Size: 0x4
	    char UnknownData9[0x4]; // 0x246c
	    float ServerUpdateCameraTimeout; // 0x2470 Size: 0x4
	    char UnknownData10[0x2474]; // 0x2474
	    void StopCameraShake(class UCameraShake* ShakeInstance, bool bImmediately); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void StopCameraFade(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void StopCameraAnimInst(class UCameraAnimInst* AnimInst, bool bImmediate); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void StopAllInstancesOfCameraShake(class UCameraShake* Shake, bool bImmediately); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void StopAllInstancesOfCameraAnim(class UCameraAnim* Anim, bool bImmediate); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void StopAllCameraShakes(bool bImmediately); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void StopAllCameraAnims(bool bImmediate); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void StartCameraFade(float FromAlpha, float ToAlpha, float Duration, struct FLinearColor Color, bool bShouldFadeAudio, bool bHoldWhenFinished); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void SetManualCameraFade(float InFadeAmount, struct FLinearColor Color, bool bInFadeAudio); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    bool RemoveCameraModifier(class UCameraModifier* ModifierToRemove); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void RemoveCameraLensEffect(class AEmitterCameraLensEffectBase* Emitter); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    class UCameraShake* PlayCameraShake(class UCameraShake* ShakeClass, float Scale, char PlaySpace, struct FRotator UserPlaySpaceRot); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    class UCameraAnimInst* PlayCameraAnim(class UCameraAnim* Anim, float Rate, float Scale, float BlendInTime, float BlendOutTime, bool bLoop, bool bRandomStartTime, float Duration, char PlaySpace, struct FRotator UserPlaySpaceRot); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void PhotographyCameraModify(struct FVector NewCameraLocation, struct FVector PreviousCameraLocation, struct FVector OriginalCameraLocation, struct FVector ResultCameraLocation); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void OnPhotographySessionStart(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void OnPhotographySessionEnd(); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void OnPhotographyMultiPartCaptureStart(); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void OnPhotographyMultiPartCaptureEnd(); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    class APlayerController* GetOwningPlayerController(); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    float GetFOVAngle(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    struct FRotator GetCameraRotation(); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    struct FVector GetCameraLocation(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    class UCameraModifier* FindCameraModifierByClass(class UCameraModifier* ModifierClass); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    void ClearCameraLensEffects(); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    bool BlueprintUpdateCamera(class AActor* CameraTarget, struct FVector NewCameraLocation, struct FRotator NewCameraRotation, float NewCameraFOV); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    class UCameraModifier* AddNewCameraModifier(class UCameraModifier* ModifierClass); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    class AEmitterCameraLensEffectBase* AddCameraLensEffect(class AEmitterCameraLensEffectBase* LensEffectEmitterClass); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x-5b61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PlayerCameraManager");
			return (class UClass*)ptr;
		};

};

class AGameModeBase : public AInfo
{
	public:
	    struct FString OptionsString; // 0x330 Size: 0x10
	    class AGameSession* GameSessionClass; // 0x340 Size: 0x8
	    class AGameStateBase* GameStateClass; // 0x348 Size: 0x8
	    class APlayerController* PlayerControllerClass; // 0x350 Size: 0x8
	    class APlayerState* PlayerStateClass; // 0x358 Size: 0x8
	    class AHUD* HUDClass; // 0x360 Size: 0x8
	    class APawn* DefaultPawnClass; // 0x368 Size: 0x8
	    class ASpectatorPawn* SpectatorClass; // 0x370 Size: 0x8
	    class APlayerController* ReplaySpectatorPlayerControllerClass; // 0x378 Size: 0x8
	    class AServerStatReplicator* ServerStatReplicatorClass; // 0x380 Size: 0x8
	    class AGameSession* GameSession; // 0x388 Size: 0x8
	    class AGameStateBase* GameState; // 0x390 Size: 0x8
	    class AServerStatReplicator* ServerStatReplicator; // 0x398 Size: 0x8
	    struct FText DefaultPlayerName; // 0x3a0 Size: 0x18
	    bool bUseSeamlessTravel; // 0x3b8 Size: 0x1
	    bool bStartPlayersAsSpectators; // 0x3b8 Size: 0x1
	    bool bPauseable; // 0x3b8 Size: 0x1
	    char UnknownData0[0x3bb]; // 0x3bb
	    void StartPlay(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    class APawn* SpawnDefaultPawnFor(class AController* NewPlayer, class AActor* StartSpot); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    class APawn* SpawnDefaultPawnAtTransform(class AController* NewPlayer, struct FTransform SpawnTransform); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool ShouldReset(class AActor* ActorToReset); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void ReturnToMainMenuHost(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void RestartPlayerAtTransform(class AController* NewPlayer, struct FTransform SpawnTransform); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void RestartPlayerAtPlayerStart(class AController* NewPlayer, class AActor* StartSpot); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void RestartPlayer(class AController* NewPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void ResetLevel(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool PlayerCanRestart(class APlayerController* Player); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    bool MustSpectate(class APlayerController* NewPlayerController); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void K2_PostLogin(class APlayerController* NewPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void K2_OnSwapPlayerControllers(class APlayerController* OldPC, class APlayerController* NewPC); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void K2_OnRestartPlayer(class AController* NewPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void K2_OnLogout(class AController* ExitingController); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void K2_OnChangeName(class AController* Other, struct FString NewName, bool bNameChange); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    class AActor* K2_FindPlayerStart(class AController* Player, struct FString IncomingName); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void InitStartSpot(class AActor* StartSpot, class AController* NewPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void InitializeHUDForPlayer(class APlayerController* NewPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    bool HasMatchStarted(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void HandleStartingNewPlayer(class APlayerController* NewPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    int GetNumSpectators(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    int GetNumPlayers(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    class UObject* GetDefaultPawnClassForController(class AController* InController); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    class AActor* FindPlayerStart(class AController* Player, struct FString IncomingName); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    class AActor* ChoosePlayerStart(class AController* Player); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void ChangeName(class AController* Controller, struct FString NewName, bool bNameChange); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    bool CanSpectate(class APlayerController* Viewer, class APlayerState* ViewTarget); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x-7c11];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.GameModeBase");
			return (class UClass*)ptr;
		};

};

class AGameMode : public AGameModeBase
{
	public:
	    FName MatchState; // 0x3d0 Size: 0x8
	    bool bDelayedStart; // 0x3d8 Size: 0x1
	    char UnknownData0[0x3]; // 0x3d9
	    int NumSpectators; // 0x3dc Size: 0x4
	    int NumPlayers; // 0x3e0 Size: 0x4
	    int NumBots; // 0x3e4 Size: 0x4
	    float MinRespawnDelay; // 0x3e8 Size: 0x4
	    int NumTravellingPlayers; // 0x3ec Size: 0x4
	    class ULocalMessage* EngineMessageClass; // 0x3f0 Size: 0x8
	    TArray<class APlayerState*> InactivePlayerArray; // 0x3f8 Size: 0x10
	    float InactivePlayerStateLifeSpan; // 0x408 Size: 0x4
	    int MaxInactivePlayers; // 0x40c Size: 0x4
	    bool bHandleDedicatedServerReplays; // 0x410 Size: 0x1
	    char UnknownData1[0x411]; // 0x411
	    void StartMatch(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetBandwidthLimit(float AsyncIOBandwidthLimit); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void Say(struct FString Msg); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void RestartGame(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool ReadyToStartMatch(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool ReadyToEndMatch(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void K2_OnSetMatchState(FName NewState); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    bool IsMatchInProgress(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool HasMatchEnded(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    FName GetMatchState(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void EndMatch(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void AbortMatch(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x-7bc9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.GameMode");
			return (class UClass*)ptr;
		};

};

class ABrush : public AActor
{
	public:
	    char BrushType; // 0x330 Size: 0x1
	    char UnknownData0[0x3]; // 0x331
	    struct FColor BrushColor; // 0x334 Size: 0x4
	    int PolyFlags; // 0x338 Size: 0x4
	    bool bColored; // 0x33c Size: 0x1
	    bool bSolidWhenSelected; // 0x33c Size: 0x1
	    bool bPlaceableFromClassBrowser; // 0x33c Size: 0x1
	    bool bNotForClientOrServer; // 0x33c Size: 0x1
	    class UModel* Brush; // 0x340 Size: 0x8
	    class UBrushComponent* BrushComponent; // 0x348 Size: 0x8
	    bool bInManipulation; // 0x350 Size: 0x1
	    char UnknownData1[0x7]; // 0x351
	    TArray<struct FGeomSelection> SavedSelections; // 0x358 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Brush");
			return (class UClass*)ptr;
		};

};

class AVolume : public ABrush
{
	public:
	    char UnknownData0[0x368];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Volume");
			return (class UClass*)ptr;
		};

};

class AGameSession : public AInfo
{
	public:
	    int MaxSpectators; // 0x330 Size: 0x4
	    int MaxPlayers; // 0x334 Size: 0x4
	    int MaxPartySize; // 0x338 Size: 0x4
	    char MaxSplitscreensPerConnection; // 0x33c Size: 0x1
	    bool bRequiresPushToTalk; // 0x33d Size: 0x1
	    char UnknownData0[0x2]; // 0x33e
	    FName SessionName; // 0x340 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.GameSession");
			return (class UClass*)ptr;
		};

};

class AGameStateBase : public AInfo
{
	public:
	    class AGameModeBase* GameModeClass; // 0x330 Size: 0x8
	    class AGameModeBase* AuthorityGameMode; // 0x338 Size: 0x8
	    class ASpectatorPawn* SpectatorClass; // 0x340 Size: 0x8
	    TArray<class APlayerState*> PlayerArray; // 0x348 Size: 0x10
	    bool bReplicatedHasBegunPlay; // 0x358 Size: 0x1
	    char UnknownData0[0x3]; // 0x359
	    float ReplicatedWorldTimeSeconds; // 0x35c Size: 0x4
	    float ServerWorldTimeSecondsDelta; // 0x360 Size: 0x4
	    float ServerWorldTimeSecondsUpdateFrequency; // 0x364 Size: 0x4
	    char UnknownData1[0x368]; // 0x368
	    void OnRep_SpectatorClass(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void OnRep_ReplicatedWorldTimeSeconds(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnRep_ReplicatedHasBegunPlay(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnRep_GameModeClass(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool HasMatchStarted(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool HasBegunPlay(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    float GetServerWorldTimeSeconds(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    float GetPlayerStartTime(class AController* Controller); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    float GetPlayerRespawnDelay(class AController* Controller); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7c71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.GameStateBase");
			return (class UClass*)ptr;
		};

};

class AGameState : public AGameStateBase
{
	public:
	    FName MatchState; // 0x370 Size: 0x8
	    FName PreviousMatchState; // 0x378 Size: 0x8
	    int ElapsedTime; // 0x380 Size: 0x4
	    char UnknownData0[0x384]; // 0x384
	    void OnRep_MatchState(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void OnRep_ElapsedTime(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7c51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.GameState");
			return (class UClass*)ptr;
		};

};

class UGameUserSettings : public UObject
{
	public:
	    bool bUseVSync; // 0x28 Size: 0x1
	    bool bUseDynamicResolution; // 0x29 Size: 0x1
	    char UnknownData0[0x4e]; // 0x2a
	    uint32_t ResolutionSizeX; // 0x78 Size: 0x4
	    uint32_t ResolutionSizeY; // 0x7c Size: 0x4
	    uint32_t LastUserConfirmedResolutionSizeX; // 0x80 Size: 0x4
	    uint32_t LastUserConfirmedResolutionSizeY; // 0x84 Size: 0x4
	    int WindowPosX; // 0x88 Size: 0x4
	    int WindowPosY; // 0x8c Size: 0x4
	    int FullscreenMode; // 0x90 Size: 0x4
	    int LastConfirmedFullscreenMode; // 0x94 Size: 0x4
	    int PreferredFullscreenMode; // 0x98 Size: 0x4
	    uint32_t Version; // 0x9c Size: 0x4
	    int AudioQualityLevel; // 0xa0 Size: 0x4
	    int LastConfirmedAudioQualityLevel; // 0xa4 Size: 0x4
	    float FrameRateLimit; // 0xa8 Size: 0x4
	    char UnknownData1[0x4]; // 0xac
	    int DesiredScreenWidth; // 0xb0 Size: 0x4
	    bool bUseDesiredScreenHeight; // 0xb4 Size: 0x1
	    char UnknownData2[0x3]; // 0xb5
	    int DesiredScreenHeight; // 0xb8 Size: 0x4
	    int LastUserConfirmedDesiredScreenWidth; // 0xbc Size: 0x4
	    int LastUserConfirmedDesiredScreenHeight; // 0xc0 Size: 0x4
	    float LastRecommendedScreenWidth; // 0xc4 Size: 0x4
	    float LastRecommendedScreenHeight; // 0xc8 Size: 0x4
	    float LastCPUBenchmarkResult; // 0xcc Size: 0x4
	    float LastGPUBenchmarkResult; // 0xd0 Size: 0x4
	    char UnknownData3[0x4]; // 0xd4
	    TArray<float> LastCPUBenchmarkSteps; // 0xd8 Size: 0x10
	    TArray<float> LastGPUBenchmarkSteps; // 0xe8 Size: 0x10
	    float LastGPUBenchmarkMultiplier; // 0xf8 Size: 0x4
	    bool bUseHDRDisplayOutput; // 0xfc Size: 0x1
	    char UnknownData4[0x3]; // 0xfd
	    int HDRDisplayOutputNits; // 0x100 Size: 0x4
	    char UnknownData5[0x4]; // 0x104
	    MulticastDelegateProperty OnGameUserSettingsUINeedsUpdate; // 0x108 Size: 0x10
	    char UnknownData6[0x118]; // 0x118
	    void ValidateSettings(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool SupportsHDRDisplayOutput(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetVSyncEnabled(bool bEnable); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetVisualEffectQuality(int Value); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetViewDistanceQuality(int Value); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetToDefaults(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetTextureQuality(int Value); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void SetShadowQuality(int Value); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void SetScreenResolution(struct FIntPoint Resolution); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void SetResolutionScaleValueEx(float NewScaleValue); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void SetResolutionScaleValue(int NewScaleValue); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void SetResolutionScaleNormalized(float NewScaleNormalized); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void SetPostProcessingQuality(int Value); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void SetOverallScalabilityLevel(int Value); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void SetFullscreenMode(char InFullscreenMode); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void SetFrameRateLimit(float NewLimit); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void SetFoliageQuality(int Value); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void SetDynamicResolutionEnabled(bool bEnable); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void SetBenchmarkFallbackValues(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void SetAudioQualityLevel(int QualityLevel); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void SetAntiAliasingQuality(int Value); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void SaveSettings(); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void RunHardwareBenchmark(int WorkScale, float CPUMultiplier, float GPUMultiplier); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    void RevertVideoMode(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    void ResetToCurrentSettings(); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    void LoadSettings(bool bForceReload); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    bool IsVSyncEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    bool IsVSyncDirty(); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    bool IsScreenResolutionDirty(); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    bool IsHDREnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    bool IsFullscreenModeDirty(); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    bool IsDynamicResolutionEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    bool IsDynamicResolutionDirty(); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    bool IsDirty(); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    int GetVisualEffectQuality(); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    int GetViewDistanceQuality(); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    int GetTextureQuality(); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    static int GetSyncInterval(); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    int GetShadowQuality(); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    struct FIntPoint GetScreenResolution(); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    void GetResolutionScaleInformationEx(float CurrentScaleNormalized, float CurrentScaleValue, float MinScaleValue, float MaxScaleValue); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    void GetResolutionScaleInformation(float CurrentScaleNormalized, int CurrentScaleValue, int MinScaleValue, int MaxScaleValue); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    float GetRecommendedResolutionScale(); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    char GetPreferredFullscreenMode(); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    int GetPostProcessingQuality(); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    int GetOverallScalabilityLevel(); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    struct FIntPoint GetLastConfirmedScreenResolution(); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    char GetLastConfirmedFullscreenMode(); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    static class UGameUserSettings* GetGameUserSettings(); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    char GetFullscreenMode(); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    float GetFrameRateLimit(); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    int GetFoliageQuality(); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    struct FIntPoint GetDesktopResolution(); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    static struct FIntPoint GetDefaultWindowPosition(); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    static char GetDefaultWindowMode(); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    float GetDefaultResolutionScale(); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x7fe1]; // 0x7fe1
	    static struct FIntPoint GetDefaultResolution(); // 0x0 Size: 0x7fe1
	    char UnknownData63[0x7fe1]; // 0x7fe1
	    int GetCurrentHDRDisplayNits(); // 0x0 Size: 0x7fe1
	    char UnknownData64[0x7fe1]; // 0x7fe1
	    int GetAudioQualityLevel(); // 0x0 Size: 0x7fe1
	    char UnknownData65[0x7fe1]; // 0x7fe1
	    int GetAntiAliasingQuality(); // 0x0 Size: 0x7fe1
	    char UnknownData66[0x7fe1]; // 0x7fe1
	    void EnableHDRDisplayOutput(bool bEnable, int DisplayNits); // 0x0 Size: 0x7fe1
	    char UnknownData67[0x7fe1]; // 0x7fe1
	    void ConfirmVideoMode(); // 0x0 Size: 0x7fe1
	    char UnknownData68[0x7fe1]; // 0x7fe1
	    void ApplySettings(bool bCheckForCommandLineOverrides); // 0x0 Size: 0x7fe1
	    char UnknownData69[0x7fe1]; // 0x7fe1
	    void ApplyResolutionSettings(bool bCheckForCommandLineOverrides); // 0x0 Size: 0x7fe1
	    char UnknownData70[0x7fe1]; // 0x7fe1
	    void ApplyNonResolutionSettings(); // 0x0 Size: 0x7fe1
	    char UnknownData71[0x7fe1]; // 0x7fe1
	    void ApplyHardwareBenchmarkResults(); // 0x0 Size: 0x7fe1
	    char UnknownData72[0x-7ec9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.GameUserSettings");
			return (class UClass*)ptr;
		};

};

class AStaticMeshActor : public AActor
{
	public:
	    class UStaticMeshComponent* StaticMeshComponent; // 0x330 Size: 0x8
	    bool bStaticMeshReplicateMovement; // 0x338 Size: 0x1
	    ENavDataGatheringMode NavigationGeometryGatheringMode; // 0x339 Size: 0x1
	    char UnknownData0[0x33a]; // 0x33a
	    void SetMobility(char InMobility); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7ca1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.StaticMeshActor");
			return (class UClass*)ptr;
		};

};

class UDataTable : public UObject
{
	public:
	    class UScriptStruct* RowStruct; // 0x28 Size: 0x8
	    bool bStripFromClientBuilds; // 0x80 Size: 0x1
	    char UnknownData0[0x6f];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DataTable");
			return (class UClass*)ptr;
		};

};

class UCameraComponent : public USceneComponent
{
	public:
	    float FieldOfView; // 0x248 Size: 0x4
	    float OrthoWidth; // 0x24c Size: 0x4
	    float OrthoNearClipPlane; // 0x250 Size: 0x4
	    float OrthoFarClipPlane; // 0x254 Size: 0x4
	    float AspectRatio; // 0x258 Size: 0x4
	    bool bConstrainAspectRatio; // 0x25c Size: 0x1
	    bool bUseFieldOfViewForLOD; // 0x25c Size: 0x1
	    bool bLockToHmd; // 0x25c Size: 0x1
	    bool bUsePawnControlRotation; // 0x25c Size: 0x1
	    char UnknownData0[0x3]; // 0x260
	    char ProjectionMode; // 0x25d Size: 0x1
	    char UnknownData1[0x32]; // 0x25e
	    float PostProcessBlendWeight; // 0x290 Size: 0x4
	    char UnknownData2[0x2c]; // 0x294
	    struct FPostProcessSettings PostProcessSettings; // 0x2c0 Size: 0x4e0
	    char UnknownData3[0x7a0]; // 0x7a0
	    void SetUseFieldOfViewForLOD(bool bInUseFieldOfViewForLOD); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetProjectionMode(char InProjectionMode); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetPostProcessBlendWeight(float InPostProcessBlendWeight); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetOrthoWidth(float InOrthoWidth); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetOrthoNearClipPlane(float InOrthoNearClipPlane); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetOrthoFarClipPlane(float InOrthoFarClipPlane); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetFieldOfView(float InFieldOfView); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetConstraintAspectRatio(bool bInConstrainAspectRatio); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetAspectRatio(float InAspectRatio); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void RemoveBlendable(__int64/*InterfaceProperty*/ InBlendableObject); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void GetCameraView(float DeltaTime, struct FMinimalViewInfo DesiredView); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void AddOrUpdateBlendable(__int64/*InterfaceProperty*/ InBlendableObject, float InWeight); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x-7841];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CameraComponent");
			return (class UClass*)ptr;
		};

};

class UAssetUserData : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AssetUserData");
			return (class UClass*)ptr;
		};

};

class ALevelScriptActor : public AActor
{
	public:
	    bool bInputEnabled; // 0x330 Size: 0x1
	    char UnknownData0[0x331]; // 0x331
	    void WorldOriginLocationChanged(struct FIntVector OldOriginLocation, struct FIntVector NewOriginLocation); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetCinematicMode(bool bCinematicMode, bool bHidePlayer, bool bAffectsHUD, bool bAffectsMovement, bool bAffectsTurning); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool RemoteEvent(FName EventName); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void LevelReset(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7ca9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LevelScriptActor");
			return (class UClass*)ptr;
		};

};

class ULocalPlayerSubsystem : public USubsystem
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LocalPlayerSubsystem");
			return (class UClass*)ptr;
		};

};

class UNavAreaBase : public UObject
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.NavAreaBase");
			return (class UClass*)ptr;
		};

};

class UCharacterMovementComponent : public UPawnMovementComponent
{
	public:
	    char UnknownData0[0x10];
	    class ACharacter* CharacterOwner; // 0x190 Size: 0x8
	    float GravityScale; // 0x198 Size: 0x4
	    float MaxStepHeight; // 0x19c Size: 0x4
	    float JumpZVelocity; // 0x1a0 Size: 0x4
	    float JumpOffJumpZFactor; // 0x1a4 Size: 0x4
	    float WalkableFloorAngle; // 0x1a8 Size: 0x4
	    float WalkableFloorZ; // 0x1ac Size: 0x4
	    char MovementMode; // 0x1b0 Size: 0x1
	    char CustomMovementMode; // 0x1b1 Size: 0x1
	    ENetworkSmoothingMode NetworkSmoothingMode; // 0x1b2 Size: 0x1
	    char UnknownData1[0x1]; // 0x1b3
	    float GroundFriction; // 0x1b4 Size: 0x4
	    char UnknownData2[0x24]; // 0x1b8
	    float MaxWalkSpeed; // 0x1dc Size: 0x4
	    float MaxWalkSpeedCrouched; // 0x1e0 Size: 0x4
	    float MaxSwimSpeed; // 0x1e4 Size: 0x4
	    float MaxFlySpeed; // 0x1e8 Size: 0x4
	    float MaxCustomMovementSpeed; // 0x1ec Size: 0x4
	    float MaxAcceleration; // 0x1f0 Size: 0x4
	    float MinAnalogWalkSpeed; // 0x1f4 Size: 0x4
	    float BrakingFrictionFactor; // 0x1f8 Size: 0x4
	    float BrakingFriction; // 0x1fc Size: 0x4
	    float BrakingSubStepTime; // 0x200 Size: 0x4
	    float BrakingDecelerationWalking; // 0x204 Size: 0x4
	    float BrakingDecelerationFalling; // 0x208 Size: 0x4
	    float BrakingDecelerationSwimming; // 0x20c Size: 0x4
	    float BrakingDecelerationFlying; // 0x210 Size: 0x4
	    float AirControl; // 0x214 Size: 0x4
	    float AirControlBoostMultiplier; // 0x218 Size: 0x4
	    float AirControlBoostVelocityThreshold; // 0x21c Size: 0x4
	    float FallingLateralFriction; // 0x220 Size: 0x4
	    float CrouchedHalfHeight; // 0x224 Size: 0x4
	    float Buoyancy; // 0x228 Size: 0x4
	    float PerchRadiusThreshold; // 0x22c Size: 0x4
	    float PerchAdditionalHeight; // 0x230 Size: 0x4
	    struct FRotator RotationRate; // 0x234 Size: 0xc
	    bool bUseSeparateBrakingFriction; // 0x240 Size: 0x1
	    bool bApplyGravityWhileJumping; // 0x240 Size: 0x1
	    bool bUseControllerDesiredRotation; // 0x240 Size: 0x1
	    bool bOrientRotationToMovement; // 0x240 Size: 0x1
	    bool bSweepWhileNavWalking; // 0x240 Size: 0x1
	    bool bMovementInProgress; // 0x240 Size: 0x1
	    bool bEnableScopedMovementUpdates; // 0x240 Size: 0x1
	    bool bEnableServerDualMoveScopedMovementUpdates; // 0x241 Size: 0x1
	    bool bForceMaxAccel; // 0x241 Size: 0x1
	    bool bRunPhysicsWithNoController; // 0x241 Size: 0x1
	    bool bForceNextFloorCheck; // 0x241 Size: 0x1
	    bool bShrinkProxyCapsule; // 0x241 Size: 0x1
	    bool bCanWalkOffLedges; // 0x241 Size: 0x1
	    bool bCanWalkOffLedgesWhenCrouching; // 0x241 Size: 0x1
	    bool bNetworkSkipProxyPredictionOnNetUpdate; // 0x242 Size: 0x1
	    bool bNetworkAlwaysReplicateTransformUpdateTimestamp; // 0x242 Size: 0x1
	    bool bDeferUpdateMoveComponent; // 0x242 Size: 0x1
	    bool bEnablePhysicsInteraction; // 0x242 Size: 0x1
	    bool bTouchForceScaledToMass; // 0x242 Size: 0x1
	    bool bPushForceScaledToMass; // 0x242 Size: 0x1
	    bool bPushForceUsingZOffset; // 0x242 Size: 0x1
	    bool bScalePushForceToVelocity; // 0x243 Size: 0x1
	    char UnknownData3[0xe]; // 0x256
	    class USceneComponent* DeferredUpdatedMoveComponent; // 0x248 Size: 0x8
	    float MaxOutOfWaterStepHeight; // 0x250 Size: 0x4
	    float OutofWaterZ; // 0x254 Size: 0x4
	    float Mass; // 0x258 Size: 0x4
	    float StandingDownwardForceScale; // 0x25c Size: 0x4
	    float InitialPushForceFactor; // 0x260 Size: 0x4
	    float PushForceFactor; // 0x264 Size: 0x4
	    float PushForcePointZOffsetFactor; // 0x268 Size: 0x4
	    float TouchForceFactor; // 0x26c Size: 0x4
	    float MinTouchForce; // 0x270 Size: 0x4
	    float MaxTouchForce; // 0x274 Size: 0x4
	    float RepulsionForce; // 0x278 Size: 0x4
	    struct FVector Acceleration; // 0x27c Size: 0xc
	    char UnknownData4[0x8]; // 0x288
	    struct FQuat LastUpdateRotation; // 0x290 Size: 0x10
	    struct FVector LastUpdateLocation; // 0x2a0 Size: 0xc
	    struct FVector LastUpdateVelocity; // 0x2ac Size: 0xc
	    float ServerLastTransformUpdateTimeStamp; // 0x2b8 Size: 0x4
	    float ServerLastClientGoodMoveAckTime; // 0x2bc Size: 0x4
	    float ServerLastClientAdjustmentTime; // 0x2c0 Size: 0x4
	    struct FVector PendingImpulseToApply; // 0x2c4 Size: 0xc
	    struct FVector PendingForceToApply; // 0x2d0 Size: 0xc
	    float AnalogInputModifier; // 0x2dc Size: 0x4
	    char UnknownData5[0x8]; // 0x2e0
	    float MaxSimulationTimeStep; // 0x2e8 Size: 0x4
	    int MaxSimulationIterations; // 0x2ec Size: 0x4
	    float MaxDepenetrationWithGeometry; // 0x2f0 Size: 0x4
	    float MaxDepenetrationWithGeometryAsProxy; // 0x2f4 Size: 0x4
	    float MaxDepenetrationWithPawn; // 0x2f8 Size: 0x4
	    float MaxDepenetrationWithPawnAsProxy; // 0x2fc Size: 0x4
	    float NetworkSimulatedSmoothLocationTime; // 0x300 Size: 0x4
	    float NetworkSimulatedSmoothRotationTime; // 0x304 Size: 0x4
	    float ListenServerNetworkSimulatedSmoothLocationTime; // 0x308 Size: 0x4
	    float ListenServerNetworkSimulatedSmoothRotationTime; // 0x30c Size: 0x4
	    float NetProxyShrinkRadius; // 0x310 Size: 0x4
	    float NetProxyShrinkHalfHeight; // 0x314 Size: 0x4
	    float NetworkMaxSmoothUpdateDistance; // 0x318 Size: 0x4
	    float NetworkNoSmoothUpdateDistance; // 0x31c Size: 0x4
	    float NetworkMinTimeBetweenClientAckGoodMoves; // 0x320 Size: 0x4
	    float NetworkMinTimeBetweenClientAdjustments; // 0x324 Size: 0x4
	    float NetworkMinTimeBetweenClientAdjustmentsLargeCorrection; // 0x328 Size: 0x4
	    float NetworkLargeClientCorrectionDistance; // 0x32c Size: 0x4
	    float LedgeCheckThreshold; // 0x330 Size: 0x4
	    float JumpOutOfWaterPitch; // 0x334 Size: 0x4
	    struct FFindFloorResult CurrentFloor; // 0x338 Size: 0x94
	    char DefaultLandMovementMode; // 0x3cc Size: 0x1
	    char DefaultWaterMovementMode; // 0x3cd Size: 0x1
	    char GroundMovementMode; // 0x3ce Size: 0x1
	    bool bMaintainHorizontalGroundVelocity; // 0x3cf Size: 0x1
	    bool bImpartBaseVelocityX; // 0x3cf Size: 0x1
	    bool bImpartBaseVelocityY; // 0x3cf Size: 0x1
	    bool bImpartBaseVelocityZ; // 0x3cf Size: 0x1
	    bool bImpartBaseAngularVelocity; // 0x3cf Size: 0x1
	    bool bJustTeleported; // 0x3cf Size: 0x1
	    bool bNetworkUpdateReceived; // 0x3cf Size: 0x1
	    bool bNetworkMovementModeChanged; // 0x3cf Size: 0x1
	    bool bIgnoreClientMovementErrorChecksAndCorrection; // 0x3d0 Size: 0x1
	    bool bNotifyApex; // 0x3d0 Size: 0x1
	    bool bCheatFlying; // 0x3d0 Size: 0x1
	    bool bWantsToCrouch; // 0x3d0 Size: 0x1
	    bool bCrouchMaintainsBaseLocation; // 0x3d0 Size: 0x1
	    bool bIgnoreBaseRotation; // 0x3d0 Size: 0x1
	    bool bFastAttachedMove; // 0x3d0 Size: 0x1
	    bool bAlwaysCheckFloor; // 0x3d0 Size: 0x1
	    bool bUseFlatBaseForFloorChecks; // 0x3d1 Size: 0x1
	    bool bPerformingJumpOff; // 0x3d1 Size: 0x1
	    bool bWantsToLeaveNavWalking; // 0x3d1 Size: 0x1
	    bool bUseRVOAvoidance; // 0x3d1 Size: 0x1
	    bool bRequestedMoveUseAcceleration; // 0x3d1 Size: 0x1
	    bool bWasSimulatingRootMotion; // 0x3d1 Size: 0x1
	    bool bAllowPhysicsRotationDuringAnimRootMotion; // 0x3d1 Size: 0x1
	    bool bHasRequestedVelocity; // 0x3d2 Size: 0x1
	    bool bRequestedMoveWithMaxSpeed; // 0x3d2 Size: 0x1
	    bool bWasAvoidanceUpdated; // 0x3d2 Size: 0x1
	    bool bProjectNavMeshWalking; // 0x3d2 Size: 0x1
	    bool bProjectNavMeshOnBothWorldChannels; // 0x3d2 Size: 0x1
	    char UnknownData6[0x7]; // 0x3eb
	    float AvoidanceConsiderationRadius; // 0x3e4 Size: 0x4
	    struct FVector RequestedVelocity; // 0x3e8 Size: 0xc
	    int AvoidanceUID; // 0x3f4 Size: 0x4
	    struct FNavAvoidanceMask AvoidanceGroup; // 0x3f8 Size: 0x4
	    struct FNavAvoidanceMask GroupsToAvoid; // 0x3fc Size: 0x4
	    struct FNavAvoidanceMask GroupsToIgnore; // 0x400 Size: 0x4
	    float AvoidanceWeight; // 0x404 Size: 0x4
	    struct FVector PendingLaunchVelocity; // 0x408 Size: 0xc
	    char UnknownData7[0xa4]; // 0x414
	    float NavMeshProjectionInterval; // 0x4b8 Size: 0x4
	    float NavMeshProjectionTimer; // 0x4bc Size: 0x4
	    float NavMeshProjectionInterpSpeed; // 0x4c0 Size: 0x4
	    float NavMeshProjectionHeightScaleUp; // 0x4c4 Size: 0x4
	    float NavMeshProjectionHeightScaleDown; // 0x4c8 Size: 0x4
	    float NavWalkingFloorDistTolerance; // 0x4cc Size: 0x4
	    struct FCharacterMovementComponentPostPhysicsTickFunction PostPhysicsTickFunction; // 0x4d0 Size: 0x58
	    char UnknownData8[0x10]; // 0x528
	    float MinTimeBetweenTimeStampResets; // 0x538 Size: 0x4
	    char UnknownData9[0x4]; // 0x53c
	    struct FRootMotionSourceGroup CurrentRootMotion; // 0x540 Size: 0xf8
	    char UnknownData10[0x98]; // 0x638
	    struct FRootMotionMovementParams RootMotionParams; // 0x6d0 Size: 0x40
	    struct FVector AnimRootMotionVelocity; // 0x710 Size: 0xc
	    char UnknownData11[0x71c]; // 0x71c
	    void SetWalkableFloorZ(float InWalkableFloorZ); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetWalkableFloorAngle(float InWalkableFloorAngle); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void SetMovementMode(char NewMovementMode, char NewCustomMode); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void SetGroupsToIgnoreMask(struct FNavAvoidanceMask GroupMask); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void SetGroupsToIgnore(int GroupFlags); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void SetGroupsToAvoidMask(struct FNavAvoidanceMask GroupMask); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void SetGroupsToAvoid(int GroupFlags); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void SetAvoidanceGroupMask(struct FNavAvoidanceMask GroupMask); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void SetAvoidanceGroup(int GroupFlags); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void SetAvoidanceEnabled(bool bEnable); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    float K2_GetWalkableFloorZ(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    float K2_GetWalkableFloorAngle(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    float K2_GetModifiedMaxAcceleration(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void K2_FindFloor(struct FVector CapsuleLocation, struct FFindFloorResult FloorResult); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void K2_ComputeFloorDist(struct FVector CapsuleLocation, float LineDistance, float SweepDistance, float SweepRadius, struct FFindFloorResult FloorResult); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    bool IsWalking(); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    bool IsWalkable(struct FHitResult Hit); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    float GetValidPerchRadius(); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    float GetPerchRadiusThreshold(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    class UPrimitiveComponent* GetMovementBase(); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    float GetMinAnalogSpeed(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    float GetMaxJumpHeightWithJumpTime(); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    float GetMaxJumpHeight(); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    float GetMaxBrakingDeceleration(); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    float GetMaxAcceleration(); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    struct FVector GetLastUpdateVelocity(); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    struct FRotator GetLastUpdateRotation(); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    struct FVector GetLastUpdateLocation(); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    struct FVector GetImpartedMovementBaseVelocity(); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    struct FVector GetCurrentAcceleration(); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    class ACharacter* GetCharacterOwner(); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    float GetAnalogInputModifier(); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    void DisableMovement(); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    void ClearAccumulatedForces(); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    void CapsuleTouched(class UPrimitiveComponent* OverlappedComp, class AActor* Other, class UPrimitiveComponent* OtherComp, int OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    void CalcVelocity(float DeltaTime, float Friction, bool bFluid, float BrakingDeceleration); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    void AddImpulse(struct FVector Impulse, bool bVelocityChange); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    void AddForce(struct FVector Force); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x-78a1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CharacterMovementComponent");
			return (class UClass*)ptr;
		};

};

class UShapeComponent : public UPrimitiveComponent
{
	public:
	    class UBodySetup* ShapeBodySetup; // 0x570 Size: 0x8
	    struct FColor ShapeColor; // 0x578 Size: 0x4
	    bool bDrawOnlyIfSelected; // 0x57c Size: 0x1
	    bool bShouldCollideWhenPlacing; // 0x57c Size: 0x1
	    bool bDynamicObstacle; // 0x57c Size: 0x1
	    char UnknownData0[0x1]; // 0x57f
	    class UNavAreaBase* AreaClass; // 0x580 Size: 0x8
	    char UnknownData1[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ShapeComponent");
			return (class UClass*)ptr;
		};

};

class UBoxComponent : public UShapeComponent
{
	public:
	    struct FVector BoxExtent; // 0x588 Size: 0xc
	    float LineThickness; // 0x594 Size: 0x4
	    char UnknownData0[0x598]; // 0x598
	    void SetBoxExtent(struct FVector InBoxExtent, bool bUpdateOverlaps); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    struct FVector GetUnscaledBoxExtent(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    struct FVector GetScaledBoxExtent(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7a41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BoxComponent");
			return (class UClass*)ptr;
		};

};

class UNavLinkDefinition : public UObject
{
	public:
	    TArray<struct FNavigationLink> Links; // 0x28 Size: 0x10
	    TArray<struct FNavigationSegmentLink> SegmentLinks; // 0x38 Size: 0x10
	    char UnknownData0[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.NavLinkDefinition");
			return (class UClass*)ptr;
		};

};

class ULocalMessage : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LocalMessage");
			return (class UClass*)ptr;
		};

};

class ANavigationObjectBase : public AActor
{
	public:
	    char UnknownData0[0x8];
	    class UCapsuleComponent* CapsuleComponent; // 0x338 Size: 0x8
	    class UBillboardComponent* GoodSprite; // 0x340 Size: 0x8
	    class UBillboardComponent* BadSprite; // 0x348 Size: 0x8
	    bool bIsPIEPlayerStart; // 0x350 Size: 0x1
	    char UnknownData1[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.NavigationObjectBase");
			return (class UClass*)ptr;
		};

};

class UPlayerInput : public UObject
{
	public:
	    char UnknownData0[0xf8];
	    TArray<struct FKeyBind> DebugExecBindings; // 0x120 Size: 0x10
	    char UnknownData1[0x30]; // 0x130
	    TArray<FName> InvertedAxis; // 0x160 Size: 0x10
	    char UnknownData2[0x170]; // 0x170
	    void SetMouseSensitivity(float SensitivityX, float SensitivityY); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetBind(FName BindName, struct FString Command); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void InvertAxisKey(struct FKey AxisKey); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void InvertAxis(FName AxisName); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ClearSmoothing(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7c39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PlayerInput");
			return (class UClass*)ptr;
		};

};

class ASkeletalMeshActor : public AActor
{
	public:
	    char UnknownData0[0x8];
	    bool bShouldDoAnimNotifies; // 0x338 Size: 0x1
	    bool bWakeOnLevelStart; // 0x338 Size: 0x1
	    char UnknownData1[0x6]; // 0x33a
	    class USkeletalMeshComponent* SkeletalMeshComponent; // 0x340 Size: 0x8
	    class USkeletalMesh* ReplicatedMesh; // 0x348 Size: 0x8
	    class UPhysicsAsset* ReplicatedPhysAsset; // 0x350 Size: 0x8
	    class UMaterialInterface* ReplicatedMaterial0; // 0x358 Size: 0x8
	    class UMaterialInterface* ReplicatedMaterial1; // 0x360 Size: 0x8
	    char UnknownData2[0x368]; // 0x368
	    void OnRep_ReplicatedPhysAsset(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnRep_ReplicatedMesh(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnRep_ReplicatedMaterial1(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnRep_ReplicatedMaterial0(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7c29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SkeletalMeshActor");
			return (class UClass*)ptr;
		};

};

class APlayerStart : public ANavigationObjectBase
{
	public:
	    FName PlayerStartTag; // 0x358 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PlayerStart");
			return (class UClass*)ptr;
		};

};

class APlayerState : public AInfo
{
	public:
	    float Score; // 0x330 Size: 0x4
	    char UnknownData0[0x4]; // 0x334
	    struct FString PlayerName; // 0x338 Size: 0x10
	    char UnknownData1[0x10]; // 0x348
	    int PlayerID; // 0x358 Size: 0x4
	    char Ping; // 0x35c Size: 0x1
	    bool bShouldUpdateReplicatedPing; // 0x35e Size: 0x1
	    bool bIsSpectator; // 0x35e Size: 0x1
	    bool bOnlySpectator; // 0x35e Size: 0x1
	    bool bIsABot; // 0x35e Size: 0x1
	    bool bIsInactive; // 0x35e Size: 0x1
	    bool bFromPreviousLevel; // 0x35e Size: 0x1
	    char UnknownData2[0x3]; // 0x363
	    int StartTime; // 0x360 Size: 0x4
	    char UnknownData3[0x4]; // 0x364
	    class ULocalMessage* EngineMessageClass; // 0x368 Size: 0x8
	    char UnknownData4[0x8]; // 0x370
	    struct FString SavedNetworkAddress; // 0x378 Size: 0x10
	    struct FUniqueNetIdRepl UniqueId; // 0x388 Size: 0x28
	    char UnknownData5[0x8]; // 0x3b0
	    class APawn* PawnPrivate; // 0x3b8 Size: 0x8
	    char UnknownData6[0x18]; // 0x3c0
	    struct FString PlayerNamePrivate; // 0x3d8 Size: 0x10
	    char UnknownData7[0x3e8]; // 0x3e8
	    void ReceiveOverrideWith(class APlayerState* OldPlayerState); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void ReceiveCopyProperties(class APlayerState* NewPlayerState); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnRep_UniqueId(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnRep_Score(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void OnRep_PlayerName(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void OnRep_PlayerId(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void OnRep_bIsInactive(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    struct FString GetPlayerName(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x-7be9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PlayerState");
			return (class UClass*)ptr;
		};

};

class UAudioComponent : public USceneComponent
{
	public:
	    class USoundBase* Sound; // 0x248 Size: 0x8
	    TArray<struct FAudioComponentParam> InstanceParameters; // 0x250 Size: 0x10
	    class USoundClass* SoundClassOverride; // 0x260 Size: 0x8
	    bool bAutoDestroy; // 0x268 Size: 0x1
	    bool bStopWhenOwnerDestroyed; // 0x268 Size: 0x1
	    bool bShouldRemainActiveIfDropped; // 0x268 Size: 0x1
	    bool bAllowSpatialization; // 0x268 Size: 0x1
	    bool bOverrideAttenuation; // 0x268 Size: 0x1
	    bool bOverrideSubtitlePriority; // 0x268 Size: 0x1
	    bool bIsUISound; // 0x268 Size: 0x1
	    bool bEnableLowPassFilter; // 0x268 Size: 0x1
	    bool bOverridePriority; // 0x269 Size: 0x1
	    bool bSuppressSubtitles; // 0x269 Size: 0x1
	    bool bAutoManageAttachment; // 0x26a Size: 0x1
	    char UnknownData0[0x3]; // 0x273
	    FName AudioComponentUserID; // 0x270 Size: 0x8
	    float PitchModulationMin; // 0x278 Size: 0x4
	    float PitchModulationMax; // 0x27c Size: 0x4
	    float VolumeModulationMin; // 0x280 Size: 0x4
	    float VolumeModulationMax; // 0x284 Size: 0x4
	    float VolumeMultiplier; // 0x288 Size: 0x4
	    int EnvelopeFollowerAttackTime; // 0x28c Size: 0x4
	    int EnvelopeFollowerReleaseTime; // 0x290 Size: 0x4
	    float Priority; // 0x294 Size: 0x4
	    float SubtitlePriority; // 0x298 Size: 0x4
	    float PitchMultiplier; // 0x29c Size: 0x4
	    float LowPassFilterFrequency; // 0x2a0 Size: 0x4
	    char UnknownData1[0x4]; // 0x2a4
	    class USoundAttenuation* AttenuationSettings; // 0x2a8 Size: 0x8
	    struct FSoundAttenuationSettings AttenuationOverrides; // 0x2b0 Size: 0x2e8
	    class USoundConcurrency* ConcurrencySettings; // 0x598 Size: 0x8
	    char UnknownData2[0x4]; // 0x5a0
	    EAttachmentRule AutoAttachLocationRule; // 0x5a4 Size: 0x1
	    EAttachmentRule AutoAttachRotationRule; // 0x5a5 Size: 0x1
	    EAttachmentRule AutoAttachScaleRule; // 0x5a6 Size: 0x1
	    char UnknownData3[0x1]; // 0x5a7
	    MulticastDelegateProperty OnAudioFinished; // 0x5a8 Size: 0x10
	    char UnknownData4[0x18]; // 0x5b8
	    MulticastDelegateProperty OnAudioPlaybackPercent; // 0x5d0 Size: 0x10
	    char UnknownData5[0x18]; // 0x5e0
	    MulticastDelegateProperty OnAudioSingleEnvelopeValue; // 0x5f8 Size: 0x10
	    char UnknownData6[0x18]; // 0x608
	    MulticastDelegateProperty OnAudioMultiEnvelopeValue; // 0x620 Size: 0x10
	    char UnknownData7[0x18]; // 0x630
	    __int64/*DelegateProperty*/ OnQueueSubtitles; // 0x648 Size: 0x10
	    TWeakObjectPtr<USceneComponent*> AutoAttachParent; // 0x658 Size: 0x8
	    FName AutoAttachSocketName; // 0x660 Size: 0x8
	    char UnknownData8[0x668]; // 0x668
	    void Stop(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetWaveParameter(FName InName, class USoundWave* InWave); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetVolumeMultiplier(float NewVolumeMultiplier); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetUISound(bool bInUISound); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetSubmixSend(class USoundSubmix* Submix, float SendLevel); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void SetSound(class USoundBase* NewSound); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void SetPitchMultiplier(float NewPitchMultiplier); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void SetPaused(bool bPause); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void SetLowPassFilterFrequency(float InLowPassFilterFrequency); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void SetLowPassFilterEnabled(bool InLowPassFilterEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void SetIntParameter(FName InName, int inInt); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void SetFloatParameter(FName InName, float InFloat); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void SetBoolParameter(FName InName, bool InBool); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void Play(float StartTime); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    bool IsPlaying(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void FadeOut(float FadeOutDuration, float FadeVolumeLevel); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void FadeIn(float FadeInDuration, float FadeVolumeLevel, float StartTime); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    bool BP_GetAttenuationSettingsToApply(struct FSoundAttenuationSettings OutAttenuationSettings); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void AdjustVolume(float AdjustVolumeDuration, float AdjustVolumeLevel); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void AdjustAttenuation(struct FSoundAttenuationSettings InAttenuationSettings); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x-7941];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AudioComponent");
			return (class UClass*)ptr;
		};

};

class AWorldSettings : public AInfo
{
	public:
	    char UnknownData0[0x8];
	    int VisibilityCellSize; // 0x338 Size: 0x4
	    char VisibilityAggressiveness; // 0x33c Size: 0x1
	    bool bPrecomputeVisibility; // 0x33d Size: 0x1
	    bool bPlaceCellsOnlyAlongCameraTracks; // 0x33d Size: 0x1
	    bool bEnableWorldBoundsChecks; // 0x33d Size: 0x1
	    bool bEnableNavigationSystem; // 0x33d Size: 0x1
	    bool bEnableAISystem; // 0x33d Size: 0x1
	    bool bEnableWorldComposition; // 0x33d Size: 0x1
	    bool bUseClientSideLevelStreamingVolumes; // 0x33d Size: 0x1
	    bool bEnableWorldOriginRebasing; // 0x33d Size: 0x1
	    bool bWorldGravitySet; // 0x33e Size: 0x1
	    bool bGlobalGravitySet; // 0x33e Size: 0x1
	    bool bMinimizeBSPSections; // 0x33e Size: 0x1
	    bool bForceNoPrecomputedLighting; // 0x33e Size: 0x1
	    bool bHighPriorityLoading; // 0x33e Size: 0x1
	    bool bHighPriorityLoadingLocal; // 0x33e Size: 0x1
	    bool bOverrideDefaultBroadphaseSettings; // 0x33e Size: 0x1
	    char UnknownData1[0xc]; // 0x34c
	    class UNavigationSystemConfig* NavigationSystemConfig; // 0x340 Size: 0x8
	    class UNavigationSystemConfig* NavigationSystemConfigOverride; // 0x348 Size: 0x8
	    float WorldToMeters; // 0x350 Size: 0x4
	    float KillZ; // 0x354 Size: 0x4
	    class UDamageType* KillZDamageType; // 0x358 Size: 0x8
	    float WorldGravityZ; // 0x360 Size: 0x4
	    float GlobalGravityZ; // 0x364 Size: 0x4
	    class ADefaultPhysicsVolume* DefaultPhysicsVolumeClass; // 0x368 Size: 0x8
	    class UPhysicsCollisionHandler* PhysicsCollisionHandlerClass; // 0x370 Size: 0x8
	    class AGameModeBase* DefaultGameMode; // 0x378 Size: 0x8
	    class AGameNetworkManager* GameNetworkManagerClass; // 0x380 Size: 0x8
	    int PackedLightAndShadowMapTextureSize; // 0x388 Size: 0x4
	    struct FVector DefaultColorScale; // 0x38c Size: 0xc
	    float DefaultMaxDistanceFieldOcclusionDistance; // 0x398 Size: 0x4
	    float GlobalDistanceFieldViewDistance; // 0x39c Size: 0x4
	    float DynamicIndirectShadowsSelfShadowingIntensity; // 0x3a0 Size: 0x4
	    char UnknownData2[0x4]; // 0x3a4
	    struct FReverbSettings DefaultReverbSettings; // 0x3a8 Size: 0x20
	    struct FInteriorSettings DefaultAmbientZoneSettings; // 0x3c8 Size: 0x24
	    float MonoCullingDistance; // 0x3ec Size: 0x4
	    class USoundMix* DefaultBaseSoundMix; // 0x3f0 Size: 0x8
	    float TimeDilation; // 0x3f8 Size: 0x4
	    float MatineeTimeDilation; // 0x3fc Size: 0x4
	    float DemoPlayTimeDilation; // 0x400 Size: 0x4
	    float MinGlobalTimeDilation; // 0x404 Size: 0x4
	    float MaxGlobalTimeDilation; // 0x408 Size: 0x4
	    float MinUndilatedFrameTime; // 0x40c Size: 0x4
	    float MaxUndilatedFrameTime; // 0x410 Size: 0x4
	    struct FBroadphaseSettings BroadphaseSettings; // 0x414 Size: 0x24
	    class APlayerState* Pauser; // 0x438 Size: 0x8
	    TArray<struct FNetViewer> ReplicationViewers; // 0x440 Size: 0x10
	    TArray<class UAssetUserData*> AssetUserData; // 0x450 Size: 0x10
	    int MaxNumberOfBookmarks; // 0x460 Size: 0x4
	    char UnknownData3[0x4]; // 0x464
	    class UBookmarkBase* DefaultBookmarkClass; // 0x468 Size: 0x8
	    TArray<class UBookmarkBase*> BookmarkArray; // 0x470 Size: 0x10
	    class UBookmarkBase* LastBookmarkClass; // 0x480 Size: 0x8
	    char UnknownData4[0x488]; // 0x488
	    void OnRep_WorldGravityZ(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7b59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.WorldSettings");
			return (class UClass*)ptr;
		};

};

class APhysicsVolume : public AVolume
{
	public:
	    float TerminalVelocity; // 0x368 Size: 0x4
	    int Priority; // 0x36c Size: 0x4
	    float FluidFriction; // 0x370 Size: 0x4
	    bool bWaterVolume; // 0x374 Size: 0x1
	    bool bPhysicsOnContact; // 0x374 Size: 0x1
	    char UnknownData0[0x2];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PhysicsVolume");
			return (class UClass*)ptr;
		};

};

class UFloatingPawnMovement : public UPawnMovementComponent
{
	public:
	    float MaxSpeed; // 0x180 Size: 0x4
	    float Acceleration; // 0x184 Size: 0x4
	    float Deceleration; // 0x188 Size: 0x4
	    float TurningBoost; // 0x18c Size: 0x4
	    bool bPositionCorrected; // 0x190 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.FloatingPawnMovement");
			return (class UClass*)ptr;
		};

};

class USpectatorPawnMovement : public UFloatingPawnMovement
{
	public:
	    bool bIgnoreTimeDilation; // 0x198 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SpectatorPawnMovement");
			return (class UClass*)ptr;
		};

};

class UInstancedStaticMeshComponent : public UStaticMeshComponent
{
	public:
	    TArray<struct FInstancedStaticMeshInstanceData> PerInstanceSMData; // 0x608 Size: 0x10
	    int InstancingRandomSeed; // 0x618 Size: 0x4
	    int InstanceStartCullDistance; // 0x61c Size: 0x4
	    int InstanceEndCullDistance; // 0x620 Size: 0x4
	    char UnknownData0[0x4]; // 0x624
	    TArray<int> InstanceReorderTable; // 0x628 Size: 0x10
	    char UnknownData1[0x48]; // 0x638
	    int NumPendingLightmaps; // 0x680 Size: 0x4
	    char UnknownData2[0x4]; // 0x684
	    TArray<struct FInstancedStaticMeshMappingInfo> CachedMappings; // 0x688 Size: 0x10
	    char UnknownData3[0x698]; // 0x698
	    bool UpdateInstanceTransform(int InstanceIndex, struct FTransform NewInstanceTransform, bool bWorldSpace, bool bMarkRenderStateDirty, bool bTeleport); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetCullDistances(int StartCullDistance, int EndCullDistance); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool RemoveInstance(int InstanceIndex); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool GetInstanceTransform(int InstanceIndex, struct FTransform OutInstanceTransform, bool bWorldSpace); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    TArray<int> GetInstancesOverlappingSphere(struct FVector Center, float Radius, bool bSphereInWorldSpace); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    TArray<int> GetInstancesOverlappingBox(struct FBox Box, bool bBoxInWorldSpace); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    int GetInstanceCount(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void ClearInstances(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    int AddInstanceWorldSpace(struct FTransform WorldTransform); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    int AddInstance(struct FTransform InstanceTransform); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x-7941];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InstancedStaticMeshComponent");
			return (class UClass*)ptr;
		};

};

class UHierarchicalInstancedStaticMeshComponent : public UInstancedStaticMeshComponent
{
	public:
	    char UnknownData0[0x8];
	    TArray<int> SortedInstances; // 0x6a8 Size: 0x10
	    int NumBuiltInstances; // 0x6b8 Size: 0x4
	    char UnknownData1[0x4]; // 0x6bc
	    struct FBox BuiltInstanceBounds; // 0x6c0 Size: 0x1c
	    struct FBox UnbuiltInstanceBounds; // 0x6dc Size: 0x1c
	    TArray<struct FBox> UnbuiltInstanceBoundsList; // 0x6f8 Size: 0x10
	    bool bEnableDensityScaling; // 0x708 Size: 0x1
	    char UnknownData2[0x7]; // 0x709
	    int OcclusionLayerNumNodes; // 0x710 Size: 0x4
	    struct FBoxSphereBounds CacheMeshExtendedBounds; // 0x714 Size: 0x1c
	    bool bDisableCollision; // 0x734 Size: 0x1
	    char UnknownData3[0x7]; // 0x731
	    int InstanceCountToRender; // 0x738 Size: 0x4
	    char UnknownData4[0x73c]; // 0x73c
	    bool RemoveInstances(TArray<int> InstancesToRemove); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7851];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.HierarchicalInstancedStaticMeshComponent");
			return (class UClass*)ptr;
		};

};

class UMaterialInterface : public UObject
{
	public:
	    char UnknownData0[0x10];
	    class USubsurfaceProfile* SubsurfaceProfile; // 0x38 Size: 0x8
	    char UnknownData1[0x10]; // 0x40
	    struct FLightmassMaterialInterfaceSettings LightmassSettings; // 0x50 Size: 0x14
	    char UnknownData2[0x4]; // 0x64
	    TArray<struct FMaterialTextureInfo> TextureStreamingData; // 0x68 Size: 0x10
	    TArray<class UAssetUserData*> AssetUserData; // 0x78 Size: 0x10
	    char UnknownData3[0x88]; // 0x88
	    void SetForceMipLevelsToBeResident(bool OverrideForceMiplevelsToBeResident, bool bForceMiplevelsToBeResidentValue, float ForceDuration, int CinematicTextureGroups); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    class UPhysicalMaterial* GetPhysicalMaterial(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    class UMaterial* GetBaseMaterial(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7f59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialInterface");
			return (class UClass*)ptr;
		};

};

class UMaterialInstance : public UMaterialInterface
{
	public:
	    class UPhysicalMaterial* PhysMaterial; // 0x88 Size: 0x8
	    class UMaterialInterface* Parent; // 0x90 Size: 0x8
	    bool bHasStaticPermutationResource; // 0x9a Size: 0x1
	    bool bOverrideSubsurfaceProfile; // 0x9a Size: 0x1
	    char UnknownData0[0x6]; // 0x9a
	    TArray<struct FScalarParameterValue> ScalarParameterValues; // 0xa0 Size: 0x10
	    TArray<struct FVectorParameterValue> VectorParameterValues; // 0xb0 Size: 0x10
	    TArray<struct FTextureParameterValue> TextureParameterValues; // 0xc0 Size: 0x10
	    TArray<struct FFontParameterValue> FontParameterValues; // 0xd0 Size: 0x10
	    struct FMaterialInstanceBasePropertyOverrides BasePropertyOverrides; // 0xe0 Size: 0x8
	    char UnknownData1[0x20]; // 0xe8
	    TArray<class UTexture*> PermutationTextureReferences; // 0x108 Size: 0x10
	    struct FStaticParameterSet StaticParameters; // 0x118 Size: 0x40
	    char UnknownData2[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialInstance");
			return (class UClass*)ptr;
		};

};

class UMaterialInstanceConstant : public UMaterialInstance
{
	public:
	    struct FLinearColor K2_GetVectorParameterValue(FName ParameterName); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    class UTexture* K2_GetTextureParameterValue(FName ParameterName); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    float K2_GetScalarParameterValue(FName ParameterName); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7e09];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialInstanceConstant");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionCustomOutput : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionCustomOutput");
			return (class UClass*)ptr;
		};

};

class UEngineCustomTimeStep : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.EngineCustomTimeStep");
			return (class UClass*)ptr;
		};

};

class UDynamicBlueprintBinding : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DynamicBlueprintBinding");
			return (class UClass*)ptr;
		};

};

class USoundEffectPreset : public UObject
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundEffectPreset");
			return (class UClass*)ptr;
		};

};

class USoundEffectSubmixPreset : public USoundEffectPreset
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundEffectSubmixPreset");
			return (class UClass*)ptr;
		};

};

class USoundBase : public UObject
{
	public:
	    class USoundClass* SoundClassObject; // 0x28 Size: 0x8
	    bool bDebug; // 0x30 Size: 0x1
	    bool bOverrideConcurrency; // 0x30 Size: 0x1
	    bool bOutputToBusOnly; // 0x30 Size: 0x1
	    bool bIgnoreFocus; // 0x30 Size: 0x1
	    bool bHasDelayNode; // 0x30 Size: 0x1
	    bool bHasConcatenatorNode; // 0x30 Size: 0x1
	    bool bHasVirtualizeWhenSilent; // 0x30 Size: 0x1
	    bool bBypassVolumeScaleForPriority; // 0x30 Size: 0x1
	    class USoundConcurrency* SoundConcurrencySettings; // 0x38 Size: 0x8
	    struct FSoundConcurrencySettings ConcurrencyOverrides; // 0x40 Size: 0x10
	    float Duration; // 0x50 Size: 0x4
	    float MaxDistance; // 0x54 Size: 0x4
	    float TotalSamples; // 0x58 Size: 0x4
	    float Priority; // 0x5c Size: 0x4
	    class USoundAttenuation* AttenuationSettings; // 0x60 Size: 0x8
	    class USoundSubmix* SoundSubmixObject; // 0x68 Size: 0x8
	    TArray<struct FSoundSubmixSendInfo> SoundSubmixSends; // 0x70 Size: 0x10
	    class USoundEffectSourcePresetChain* SourceEffectChain; // 0x80 Size: 0x8
	    TArray<struct FSoundSourceBusSendInfo> BusSends; // 0x88 Size: 0x10
	    TArray<struct FSoundSourceBusSendInfo> PreEffectBusSends; // 0x98 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundBase");
			return (class UClass*)ptr;
		};

};

class USoundWave : public USoundBase
{
	public:
	    int CompressionQuality; // 0xa8 Size: 0x4
	    int StreamingPriority; // 0xac Size: 0x4
	    ESoundwaveSampleRateSettings SampleRateQuality; // 0xb0 Size: 0x1
	    char UnknownData0[0x1]; // 0xb1
	    char SoundGroup; // 0xb2 Size: 0x1
	    bool bLooping; // 0xb3 Size: 0x1
	    bool bStreaming; // 0xb3 Size: 0x1
	    bool bMature; // 0xb3 Size: 0x1
	    bool bManualWordWrap; // 0xb4 Size: 0x1
	    bool bSingleLine; // 0xb4 Size: 0x1
	    bool bVirtualizeWhenSilent; // 0xb4 Size: 0x1
	    bool bIsAmbisonics; // 0xb4 Size: 0x1
	    char UnknownData1[0xe]; // 0xba
	    struct FString SpokenText; // 0xc8 Size: 0x10
	    float SubtitlePriority; // 0xd8 Size: 0x4
	    float Volume; // 0xdc Size: 0x4
	    float Pitch; // 0xe0 Size: 0x4
	    int NumChannels; // 0xe4 Size: 0x4
	    int SampleRate; // 0xe8 Size: 0x4
	    char UnknownData2[0x4]; // 0xec
	    TArray<struct FSubtitleCue> Subtitles; // 0xf0 Size: 0x10
	    TArray<struct FLocalizedSubtitle> LocalizedSubtitles; // 0x100 Size: 0x10
	    class UCurveTable* Curves; // 0x110 Size: 0x8
	    class UCurveTable* InternalCurves; // 0x118 Size: 0x8
	    char UnknownData3[0xe8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundWave");
			return (class UClass*)ptr;
		};

};

class USoundWaveProcedural : public USoundWave
{
	public:
	    char UnknownData0[0x260];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundWaveProcedural");
			return (class UClass*)ptr;
		};

};

class UModel : public UObject
{
	public:
	    char UnknownData0[0x2d0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Model");
			return (class UClass*)ptr;
		};

};

class UActorChannel : public UChannel
{
	public:
	    class AActor* Actor; // 0x70 Size: 0x8
	    char UnknownData0[0xe0]; // 0x78
	    TArray<class UObject*> CreateSubObjects; // 0x158 Size: 0x10
	    char UnknownData1[0xd8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ActorChannel");
			return (class UClass*)ptr;
		};

};

class UAnimationAsset : public UObject
{
	public:
	    char UnknownData0[0x10];
	    class USkeleton* Skeleton; // 0x38 Size: 0x8
	    char UnknownData1[0x20]; // 0x40
	    TArray<class UAnimMetaData*> MetaData; // 0x60 Size: 0x10
	    TArray<class UAssetUserData*> AssetUserData; // 0x70 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimationAsset");
			return (class UClass*)ptr;
		};

};

class UBlendSpaceBase : public UAnimationAsset
{
	public:
	    char UnknownData0[0x8];
	    bool bRotationBlendInMeshSpace; // 0x88 Size: 0x1
	    char UnknownData1[0x3]; // 0x89
	    float AnimLength; // 0x8c Size: 0x4
	    struct FInterpolationParameter* InterpolationParam; // 0x90 Size: 0x8
	    char UnknownData2[0x10]; // 0x98
	    float TargetWeightInterpolationSpeedPerSec; // 0xa8 Size: 0x4
	    char NotifyTriggerMode; // 0xac Size: 0x1
	    char UnknownData3[0x3]; // 0xad
	    TArray<struct FPerBoneInterpolation> PerBoneBlend; // 0xb0 Size: 0x10
	    int SampleIndexWithMarkers; // 0xc0 Size: 0x4
	    char UnknownData4[0x4]; // 0xc4
	    TArray<struct FBlendSample> SampleData; // 0xc8 Size: 0x10
	    TArray<struct FEditorElement> GridSamples; // 0xd8 Size: 0x10
	    struct FBlendParameter* BlendParameters; // 0xe8 Size: 0x20
	    char UnknownData5[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BlendSpaceBase");
			return (class UClass*)ptr;
		};

};

class UBlendSpace : public UBlendSpaceBase
{
	public:
	    char AxisToScaleAnimation; // 0x148 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BlendSpace");
			return (class UClass*)ptr;
		};

};

class UAimOffsetBlendSpace : public UBlendSpace
{
	public:
	    char UnknownData0[0x150];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AimOffsetBlendSpace");
			return (class UClass*)ptr;
		};

};

class UBlendSpace1D : public UBlendSpaceBase
{
	public:
	    bool bScaleAnimation; // 0x148 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BlendSpace1D");
			return (class UClass*)ptr;
		};

};

class UAimOffsetBlendSpace1D : public UBlendSpace1D
{
	public:
	    char UnknownData0[0x150];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AimOffsetBlendSpace1D");
			return (class UClass*)ptr;
		};

};

class AAmbientSound : public AActor
{
	public:
	    class UAudioComponent* AudioComponent; // 0x330 Size: 0x8
	    char UnknownData0[0x338]; // 0x338
	    void Stop(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void Play(float StartTime); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void FadeOut(float FadeOutDuration, float FadeVolumeLevel); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void FadeIn(float FadeInDuration, float FadeVolumeLevel); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void AdjustVolume(float AdjustVolumeDuration, float AdjustVolumeLevel); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7ca9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AmbientSound");
			return (class UClass*)ptr;
		};

};

class UAnimationSettings : public UDeveloperSettings
{
	public:
	    int CompressCommandletVersion; // 0x38 Size: 0x4
	    char UnknownData0[0x4]; // 0x3c
	    TArray<struct FString> KeyEndEffectorsMatchNameArray; // 0x40 Size: 0x10
	    class UAnimCompress* DefaultCompressionAlgorithm; // 0x50 Size: 0x8
	    char RotationCompressionFormat; // 0x58 Size: 0x1
	    char TranslationCompressionFormat; // 0x59 Size: 0x1
	    char UnknownData1[0x2]; // 0x5a
	    float MaxCurveError; // 0x5c Size: 0x4
	    float AlternativeCompressionThreshold; // 0x60 Size: 0x4
	    bool ForceRecompression; // 0x64 Size: 0x1
	    bool bOnlyCheckForMissingSkeletalMeshes; // 0x65 Size: 0x1
	    bool bForceBelowThreshold; // 0x66 Size: 0x1
	    bool bFirstRecompressUsingCurrentOrDefault; // 0x67 Size: 0x1
	    bool bRaiseMaxErrorToExisting; // 0x68 Size: 0x1
	    bool bTryExhaustiveSearch; // 0x69 Size: 0x1
	    bool bEnableSegmenting; // 0x6a Size: 0x1
	    bool bEnablePerformanceLog; // 0x6b Size: 0x1
	    bool bStripAnimationDataOnDedicatedServer; // 0x6c Size: 0x1
	    bool bTickAnimationOnSkeletalMeshInit; // 0x6d Size: 0x1
	    char UnknownData2[0x2];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimationSettings");
			return (class UClass*)ptr;
		};

};

class UAnimBlueprint : public UBlueprint
{
	public:
	    char UnknownData0[0x8];
	    class USkeleton* TargetSkeleton; // 0xe8 Size: 0x8
	    TArray<struct FAnimGroupInfo> Groups; // 0xf0 Size: 0x10
	    bool bUseMultiThreadedAnimationUpdate; // 0x100 Size: 0x1
	    bool bWarnAboutBlueprintUsage; // 0x101 Size: 0x1
	    char UnknownData1[0x6];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimBlueprint");
			return (class UClass*)ptr;
		};

};

class UAnimBlueprintGeneratedClass : public UBlueprintGeneratedClass
{
	public:
	    char UnknownData0[0x8];
	    TArray<struct FBakedAnimationStateMachine> BakedStateMachines; // 0x2e8 Size: 0x10
	    class USkeleton* TargetSkeleton; // 0x2f8 Size: 0x8
	    TArray<struct FAnimNotifyEvent> AnimNotifies; // 0x300 Size: 0x10
	    char UnknownData1[0x8]; // 0x310
	    TArray<int> OrderedSavedPoseIndices; // 0x318 Size: 0x10
	    char UnknownData2[0x18]; // 0x328
	    TArray<FName> SyncGroupNames; // 0x340 Size: 0x10
	    TArray<struct FExposedValueHandler> EvaluateGraphExposedInputs; // 0x350 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimBlueprintGeneratedClass");
			return (class UClass*)ptr;
		};

};

class UAnimClassData : public UObject
{
	public:
	    char UnknownData0[0x8];
	    TArray<struct FBakedAnimationStateMachine> BakedStateMachines; // 0x30 Size: 0x10
	    class USkeleton* TargetSkeleton; // 0x40 Size: 0x8
	    TArray<struct FAnimNotifyEvent> AnimNotifies; // 0x48 Size: 0x10
	    int RootAnimNodeIndex; // 0x58 Size: 0x4
	    char UnknownData1[0x4]; // 0x5c
	    TArray<int> OrderedSavedPoseIndices; // 0x60 Size: 0x10
	    class UStructProperty* RootAnimNodeProperty; // 0x70 Size: 0x8
	    TArray<class UStructProperty*> AnimNodeProperties; // 0x78 Size: 0x10
	    TArray<FName> SyncGroupNames; // 0x88 Size: 0x10
	    TArray<struct FExposedValueHandler> EvaluateGraphExposedInputs; // 0x98 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimClassData");
			return (class UClass*)ptr;
		};

};

class UAnimClassInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimClassInterface");
			return (class UClass*)ptr;
		};

};

class UAnimSequenceBase : public UAnimationAsset
{
	public:
	    TArray<struct FAnimNotifyEvent> Notifies; // 0x80 Size: 0x10
	    float SequenceLength; // 0x90 Size: 0x4
	    float RateScale; // 0x94 Size: 0x4
	    struct FRawCurveTracks RawCurveData; // 0x98 Size: 0x10
	    char UnknownData0[0xa8]; // 0xa8
	    float GetPlayLength(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f39];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimSequenceBase");
			return (class UClass*)ptr;
		};

};

class UAnimCompositeBase : public UAnimSequenceBase
{
	public:
	    char UnknownData0[0xa8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimCompositeBase");
			return (class UClass*)ptr;
		};

};

class UAnimComposite : public UAnimCompositeBase
{
	public:
	    struct FAnimTrack AnimationTrack; // 0xa8 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimComposite");
			return (class UClass*)ptr;
		};

};

class UAnimCompress : public UObject
{
	public:
	    struct FString Description; // 0x28 Size: 0x10
	    bool bNeedsSkeleton; // 0x38 Size: 0x1
	    bool bEnableSegmenting; // 0x38 Size: 0x1
	    char UnknownData0[0x2]; // 0x3a
	    uint32_t IdealNumFramesPerSegment; // 0x3c Size: 0x4
	    uint32_t MaxNumFramesPerSegment; // 0x40 Size: 0x4
	    char TranslationCompressionFormat; // 0x44 Size: 0x1
	    char RotationCompressionFormat; // 0x45 Size: 0x1
	    char ScaleCompressionFormat; // 0x46 Size: 0x1
	    char UnknownData1[0x1]; // 0x47
	    float MaxCurveError; // 0x48 Size: 0x4
	    char UnknownData2[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimCompress");
			return (class UClass*)ptr;
		};

};

class UAnimCompress_Automatic : public UAnimCompress
{
	public:
	    float MaxEndEffectorError; // 0x50 Size: 0x4
	    bool bRunCurrentDefaultCompressor; // 0x54 Size: 0x1
	    bool bAutoReplaceIfExistingErrorTooGreat; // 0x54 Size: 0x1
	    bool bRaiseMaxErrorToExisting; // 0x54 Size: 0x1
	    bool bTryExhaustiveSearch; // 0x54 Size: 0x1

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimCompress_Automatic");
			return (class UClass*)ptr;
		};

};

class UAnimCompress_BitwiseCompressOnly : public UAnimCompress
{
	public:
	    char UnknownData0[0x50];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimCompress_BitwiseCompressOnly");
			return (class UClass*)ptr;
		};

};

class UAnimCompress_LeastDestructive : public UAnimCompress
{
	public:
	    char UnknownData0[0x50];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimCompress_LeastDestructive");
			return (class UClass*)ptr;
		};

};

class UAnimCompress_RemoveLinearKeys : public UAnimCompress
{
	public:
	    float MaxPosDiff; // 0x50 Size: 0x4
	    float MaxAngleDiff; // 0x54 Size: 0x4
	    float MaxScaleDiff; // 0x58 Size: 0x4
	    float MaxEffectorDiff; // 0x5c Size: 0x4
	    float MinEffectorDiff; // 0x60 Size: 0x4
	    float EffectorDiffSocket; // 0x64 Size: 0x4
	    float ParentKeyScale; // 0x68 Size: 0x4
	    bool bRetarget; // 0x6c Size: 0x1
	    bool bActuallyFilterLinearKeys; // 0x6c Size: 0x1
	    bool bOptimizeForForwardPlayback; // 0x6c Size: 0x1
	    bool bUseDecompression; // 0x6c Size: 0x1
	    bool bUseMultithreading; // 0x6c Size: 0x1
	    char UnknownData0[0x-1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimCompress_RemoveLinearKeys");
			return (class UClass*)ptr;
		};

};

class UAnimCompress_PerTrackCompression : public UAnimCompress_RemoveLinearKeys
{
	public:
	    float MaxZeroingThreshold; // 0x70 Size: 0x4
	    float MaxPosDiffBitwise; // 0x74 Size: 0x4
	    float MaxAngleDiffBitwise; // 0x78 Size: 0x4
	    float MaxScaleDiffBitwise; // 0x7c Size: 0x4
	    TArray<char> AllowedRotationFormats; // 0x80 Size: 0x10
	    TArray<char> AllowedTranslationFormats; // 0x90 Size: 0x10
	    TArray<char> AllowedScaleFormats; // 0xa0 Size: 0x10
	    bool bResampleAnimation; // 0xb0 Size: 0x1
	    char UnknownData0[0x3]; // 0xb1
	    float ResampledFramerate; // 0xb4 Size: 0x4
	    int MinKeysForResampling; // 0xb8 Size: 0x4
	    bool bUseAdaptiveError; // 0xbc Size: 0x1
	    bool bUseOverrideForEndEffectors; // 0xbc Size: 0x1
	    char UnknownData1[0x2]; // 0xbe
	    int TrackHeightBias; // 0xc0 Size: 0x4
	    float ParentingDivisor; // 0xc4 Size: 0x4
	    float ParentingDivisorExponent; // 0xc8 Size: 0x4
	    bool bUseAdaptiveError2; // 0xcc Size: 0x1
	    char UnknownData2[0x3]; // 0xcd
	    float RotationErrorSourceRatio; // 0xd0 Size: 0x4
	    float TranslationErrorSourceRatio; // 0xd4 Size: 0x4
	    float ScaleErrorSourceRatio; // 0xd8 Size: 0x4
	    float MaxErrorPerTrackRatio; // 0xdc Size: 0x4
	    float PerturbationProbeSize; // 0xe0 Size: 0x4
	    char UnknownData3[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimCompress_PerTrackCompression");
			return (class UClass*)ptr;
		};

};

class UAnimCompress_RemoveEverySecondKey : public UAnimCompress
{
	public:
	    int MinKeys; // 0x50 Size: 0x4
	    bool bStartAtSecondKey; // 0x54 Size: 0x1
	    char UnknownData0[0x3];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimCompress_RemoveEverySecondKey");
			return (class UClass*)ptr;
		};

};

class UAnimCompress_RemoveTrivialKeys : public UAnimCompress
{
	public:
	    float MaxPosDiff; // 0x50 Size: 0x4
	    float MaxAngleDiff; // 0x54 Size: 0x4
	    float MaxScaleDiff; // 0x58 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimCompress_RemoveTrivialKeys");
			return (class UClass*)ptr;
		};

};

class UAnimMetaData : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimMetaData");
			return (class UClass*)ptr;
		};

};

class UAnimMontage : public UAnimCompositeBase
{
	public:
	    struct FAlphaBlend BlendIn; // 0xa8 Size: 0x30
	    float BlendInTime; // 0xd8 Size: 0x4
	    char UnknownData0[0x4]; // 0xdc
	    struct FAlphaBlend BlendOut; // 0xe0 Size: 0x30
	    float BlendOutTime; // 0x110 Size: 0x4
	    float BlendOutTriggerTime; // 0x114 Size: 0x4
	    FName SyncGroup; // 0x118 Size: 0x8
	    int SyncSlotIndex; // 0x120 Size: 0x4
	    char UnknownData1[0x4]; // 0x124
	    struct FMarkerSyncData MarkerData; // 0x128 Size: 0x20
	    TArray<struct FCompositeSection> CompositeSections; // 0x148 Size: 0x10
	    TArray<struct FSlotAnimationTrack> SlotAnimTracks; // 0x158 Size: 0x10
	    TArray<struct FBranchingPoint> BranchingPoints; // 0x168 Size: 0x10
	    bool bEnableRootMotionTranslation; // 0x178 Size: 0x1
	    bool bEnableRootMotionRotation; // 0x179 Size: 0x1
	    bool bEnableAutoBlendOut; // 0x17a Size: 0x1
	    char RootMotionRootLock; // 0x17b Size: 0x1
	    char UnknownData2[0x4]; // 0x17c
	    TArray<struct FBranchingPointMarker> BranchingPointMarkers; // 0x180 Size: 0x10
	    TArray<int> BranchingPointStateNotifyIndices; // 0x190 Size: 0x10
	    struct FTimeStretchCurve TimeStretchCurve; // 0x1a0 Size: 0x28
	    FName TimeStretchCurveName; // 0x1c8 Size: 0x8
	    char UnknownData3[0x1d0]; // 0x1d0
	    float GetDefaultBlendOutTime(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7e11];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimMontage");
			return (class UClass*)ptr;
		};

};

class UAnimNotify_PauseClothingSimulation : public UAnimNotify
{
	public:
	    char UnknownData0[0x38];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimNotify_PauseClothingSimulation");
			return (class UClass*)ptr;
		};

};

class UAnimNotify_ResetClothingSimulation : public UAnimNotify
{
	public:
	    char UnknownData0[0x38];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimNotify_ResetClothingSimulation");
			return (class UClass*)ptr;
		};

};

class UAnimNotify_ResetDynamics : public UAnimNotify
{
	public:
	    char UnknownData0[0x38];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimNotify_ResetDynamics");
			return (class UClass*)ptr;
		};

};

class UAnimNotify_ResumeClothingSimulation : public UAnimNotify
{
	public:
	    char UnknownData0[0x38];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimNotify_ResumeClothingSimulation");
			return (class UClass*)ptr;
		};

};

class UAnimNotifyState_DisableRootMotion : public UAnimNotifyState
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimNotifyState_DisableRootMotion");
			return (class UClass*)ptr;
		};

};

class UAnimNotifyState_TimedParticleEffect : public UAnimNotifyState
{
	public:
	    class UParticleSystem* PSTemplate; // 0x30 Size: 0x8
	    FName SocketName; // 0x38 Size: 0x8
	    struct FVector LocationOffset; // 0x40 Size: 0xc
	    struct FRotator RotationOffset; // 0x4c Size: 0xc
	    bool bDestroyAtEnd; // 0x58 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimNotifyState_TimedParticleEffect");
			return (class UClass*)ptr;
		};

};

class UAnimNotifyState_Trail : public UAnimNotifyState
{
	public:
	    class UParticleSystem* PSTemplate; // 0x30 Size: 0x8
	    FName FirstSocketName; // 0x38 Size: 0x8
	    FName SecondSocketName; // 0x40 Size: 0x8
	    char WidthScaleMode; // 0x48 Size: 0x1
	    char UnknownData0[0x3]; // 0x49
	    FName WidthScaleCurve; // 0x4c Size: 0x8
	    bool bRecycleSpawnedSystems; // 0x54 Size: 0x1
	    char UnknownData1[0x55]; // 0x55
	    class UParticleSystem* OverridePSTemplate(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimNotifyState_Trail");
			return (class UClass*)ptr;
		};

};

class UAnimSequence : public UAnimSequenceBase
{
	public:
	    int NumFrames; // 0xa8 Size: 0x4
	    char UnknownData0[0x4]; // 0xac
	    TArray<struct FTrackToSkeletonMap> TrackToSkeletonMapTable; // 0xb0 Size: 0x10
	    char UnknownData1[0xa4]; // 0xc0
	    char AdditiveAnimType; // 0x164 Size: 0x1
	    char RefPoseType; // 0x165 Size: 0x1
	    char UnknownData2[0x2]; // 0x166
	    class UAnimSequence* RefPoseSeq; // 0x168 Size: 0x8
	    int RefFrameIndex; // 0x170 Size: 0x4
	    int EncodingPkgVersion; // 0x174 Size: 0x4
	    FName RetargetSource; // 0x178 Size: 0x8
	    EAnimInterpolationType Interpolation; // 0x180 Size: 0x1
	    bool bEnableRootMotion; // 0x181 Size: 0x1
	    char RootMotionRootLock; // 0x182 Size: 0x1
	    bool bForceRootLock; // 0x183 Size: 0x1
	    bool bUseNormalizedRootMotionScale; // 0x184 Size: 0x1
	    bool bRootMotionSettingsCopiedFromMontage; // 0x185 Size: 0x1
	    char UnknownData3[0x2]; // 0x186
	    TArray<struct FAnimSyncMarker> AuthoredSyncMarkers; // 0x188 Size: 0x10
	    char UnknownData4[0x18];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimSequence");
			return (class UClass*)ptr;
		};

};

class UAnimSet : public UObject
{
	public:
	    bool bAnimRotationOnly; // 0x28 Size: 0x1
	    char UnknownData0[0x7]; // 0x29
	    TArray<FName> TrackBoneNames; // 0x30 Size: 0x10
	    TArray<struct FAnimSetMeshLinkup> LinkupCache; // 0x40 Size: 0x10
	    TArray<char> BoneUseAnimTranslation; // 0x50 Size: 0x10
	    TArray<char> ForceUseMeshTranslation; // 0x60 Size: 0x10
	    TArray<FName> UseTranslationBoneNames; // 0x70 Size: 0x10
	    TArray<FName> ForceMeshTranslationBoneNames; // 0x80 Size: 0x10
	    FName PreviewSkelMeshName; // 0x90 Size: 0x8
	    FName BestRatioSkelMeshName; // 0x98 Size: 0x8
	    char UnknownData1[0x50];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimSet");
			return (class UClass*)ptr;
		};

};

class UAnimSingleNodeInstance : public UAnimInstance
{
	public:
	    class UAnimationAsset* CurrentAsset; // 0x268 Size: 0x8
	    __int64/*DelegateProperty*/ PostEvaluateAnimEvent; // 0x270 Size: 0x10
	    char UnknownData0[0x280]; // 0x280
	    void StopAnim(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetReverse(bool bInReverse); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetPreviewCurveOverride(FName PoseName, float Value, bool bRemoveIfZero); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetPositionWithPreviousTime(float InPosition, float InPreviousTime, bool bFireNotifies); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetPosition(float InPosition, bool bFireNotifies); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetPlayRate(float InPlayRate); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetPlaying(bool bIsPlaying); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetLooping(bool bIsLooping); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetBlendSpaceInput(struct FVector InBlendInput); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetAnimationAsset(class UAnimationAsset* NewAsset, bool bIsLooping, float InPlayRate); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void PlayAnim(bool bIsLooping, float InPlayRate, float InStartPosition); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    float GetLength(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    class UAnimationAsset* GetAnimationAsset(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x-7d61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimSingleNodeInstance");
			return (class UClass*)ptr;
		};

};

class UAnimStateMachineTypes : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AnimStateMachineTypes");
			return (class UClass*)ptr;
		};

};

class UApplicationLifecycleComponent : public UActorComponent
{
	public:
	    MulticastDelegateProperty ApplicationWillDeactivateDelegate; // 0xf8 Size: 0x10
	    MulticastDelegateProperty ApplicationHasReactivatedDelegate; // 0x108 Size: 0x10
	    MulticastDelegateProperty ApplicationWillEnterBackgroundDelegate; // 0x118 Size: 0x10
	    MulticastDelegateProperty ApplicationHasEnteredForegroundDelegate; // 0x128 Size: 0x10
	    MulticastDelegateProperty ApplicationWillTerminateDelegate; // 0x138 Size: 0x10
	    MulticastDelegateProperty ApplicationShouldUnloadResourcesDelegate; // 0x148 Size: 0x10
	    MulticastDelegateProperty ApplicationReceivedStartupArgumentsDelegate; // 0x158 Size: 0x10
	    MulticastDelegateProperty OnTemperatureChangeDelegate; // 0x168 Size: 0x10
	    MulticastDelegateProperty OnLowPowerModeDelegate; // 0x178 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ApplicationLifecycleComponent");
			return (class UClass*)ptr;
		};

};

class UArrowComponent : public UPrimitiveComponent
{
	public:
	    struct FColor ArrowColor; // 0x570 Size: 0x4
	    float ArrowSize; // 0x574 Size: 0x4
	    bool bIsScreenSizeScaled; // 0x578 Size: 0x1
	    char UnknownData0[0x3]; // 0x579
	    float ScreenSize; // 0x57c Size: 0x4
	    bool bTreatAsASprite; // 0x580 Size: 0x1
	    char UnknownData1[0x581]; // 0x581
	    void SetArrowColor(struct FLinearColor NewColor); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7a51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ArrowComponent");
			return (class UClass*)ptr;
		};

};

class UAssetExportTask : public UObject
{
	public:
	    class UObject* Object; // 0x28 Size: 0x8
	    class UExporter* Exporter; // 0x30 Size: 0x8
	    struct FString Filename; // 0x38 Size: 0x10
	    bool bSelected; // 0x48 Size: 0x1
	    bool bReplaceIdentical; // 0x49 Size: 0x1
	    bool bPrompt; // 0x4a Size: 0x1
	    bool bAutomated; // 0x4b Size: 0x1
	    bool bUseFileArchive; // 0x4c Size: 0x1
	    bool bWriteEmptyFiles; // 0x4d Size: 0x1
	    char UnknownData0[0x2]; // 0x4e
	    TArray<class UObject*> IgnoreObjectList; // 0x50 Size: 0x10
	    class UObject* Options; // 0x60 Size: 0x8
	    TArray<struct FString> Errors; // 0x68 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AssetExportTask");
			return (class UClass*)ptr;
		};

};

class UAssetImportData : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AssetImportData");
			return (class UClass*)ptr;
		};

};

class UAssetManagerSettings : public UDeveloperSettings
{
	public:
	    TArray<struct FPrimaryAssetTypeInfo> PrimaryAssetTypesToScan; // 0x38 Size: 0x10
	    TArray<struct FDirectoryPath> DirectoriesToExclude; // 0x48 Size: 0x10
	    TArray<struct FPrimaryAssetRulesOverride> PrimaryAssetRules; // 0x58 Size: 0x10
	    TArray<struct FPrimaryAssetRulesCustomOverride> CustomPrimaryAssetRules; // 0x68 Size: 0x10
	    bool bOnlyCookProductionAssets; // 0x78 Size: 0x1
	    bool bShouldManagerDetermineTypeAndName; // 0x79 Size: 0x1
	    bool bShouldGuessTypeAndNameInEditor; // 0x7a Size: 0x1
	    bool bShouldAcquireMissingChunksOnLoad; // 0x7b Size: 0x1
	    char UnknownData0[0x4]; // 0x7c
	    TArray<struct FAssetManagerRedirect> PrimaryAssetIdRedirects; // 0x80 Size: 0x10
	    TArray<struct FAssetManagerRedirect> PrimaryAssetTypeRedirects; // 0x90 Size: 0x10
	    TArray<struct FAssetManagerRedirect> AssetPathRedirects; // 0xa0 Size: 0x10
	    __int64/*SetProperty*/ MetaDataTagsForAssetRegistry; // 0xb0 Size: 0x50

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AssetManagerSettings");
			return (class UClass*)ptr;
		};

};

class UAssetMappingTable : public UObject
{
	public:
	    TArray<struct FAssetMapping> MappedAssets; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AssetMappingTable");
			return (class UClass*)ptr;
		};

};

class UAsyncActionLoadPrimaryAssetBase : public UBlueprintAsyncActionBase
{
	public:
	    char UnknownData0[0x78];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AsyncActionLoadPrimaryAssetBase");
			return (class UClass*)ptr;
		};

};

class UAsyncActionLoadPrimaryAsset : public UAsyncActionLoadPrimaryAssetBase
{
	public:
	    MulticastDelegateProperty Completed; // 0x78 Size: 0x10
	    char UnknownData0[0x88]; // 0x88
	    static class UAsyncActionLoadPrimaryAsset* AsyncLoadPrimaryAsset(class UObject* WorldContextObject, struct FPrimaryAssetId PrimaryAsset, TArray<FName> LoadBundles); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AsyncActionLoadPrimaryAsset");
			return (class UClass*)ptr;
		};

};

class UAsyncActionLoadPrimaryAssetClass : public UAsyncActionLoadPrimaryAssetBase
{
	public:
	    MulticastDelegateProperty Completed; // 0x78 Size: 0x10
	    char UnknownData0[0x88]; // 0x88
	    static class UAsyncActionLoadPrimaryAssetClass* AsyncLoadPrimaryAssetClass(class UObject* WorldContextObject, struct FPrimaryAssetId PrimaryAsset, TArray<FName> LoadBundles); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AsyncActionLoadPrimaryAssetClass");
			return (class UClass*)ptr;
		};

};

class UAsyncActionLoadPrimaryAssetList : public UAsyncActionLoadPrimaryAssetBase
{
	public:
	    MulticastDelegateProperty Completed; // 0x78 Size: 0x10
	    char UnknownData0[0x88]; // 0x88
	    static class UAsyncActionLoadPrimaryAssetList* AsyncLoadPrimaryAssetList(class UObject* WorldContextObject, TArray<struct FPrimaryAssetId> PrimaryAssetList, TArray<FName> LoadBundles); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AsyncActionLoadPrimaryAssetList");
			return (class UClass*)ptr;
		};

};

class UAsyncActionLoadPrimaryAssetClassList : public UAsyncActionLoadPrimaryAssetBase
{
	public:
	    MulticastDelegateProperty Completed; // 0x78 Size: 0x10
	    char UnknownData0[0x88]; // 0x88
	    static class UAsyncActionLoadPrimaryAssetClassList* AsyncLoadPrimaryAssetClassList(class UObject* WorldContextObject, TArray<struct FPrimaryAssetId> PrimaryAssetList, TArray<FName> LoadBundles); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AsyncActionLoadPrimaryAssetClassList");
			return (class UClass*)ptr;
		};

};

class UAsyncActionChangePrimaryAssetBundles : public UAsyncActionLoadPrimaryAssetBase
{
	public:
	    MulticastDelegateProperty Completed; // 0x78 Size: 0x10
	    char UnknownData0[0x88]; // 0x88
	    static class UAsyncActionChangePrimaryAssetBundles* AsyncChangeBundleStateForPrimaryAssetList(class UObject* WorldContextObject, TArray<struct FPrimaryAssetId> PrimaryAssetList, TArray<FName> AddBundles, TArray<FName> RemoveBundles); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static class UAsyncActionChangePrimaryAssetBundles* AsyncChangeBundleStateForMatchingPrimaryAssets(class UObject* WorldContextObject, TArray<FName> NewBundles, TArray<FName> OldBundles); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AsyncActionChangePrimaryAssetBundles");
			return (class UClass*)ptr;
		};

};

class AAtmosphericFog : public AInfo
{
	public:
	    class UAtmosphericFogComponent* AtmosphericFogComponent; // 0x330 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AtmosphericFog");
			return (class UClass*)ptr;
		};

};

class UAtmosphericFogComponent : public USceneComponent
{
	public:
	    float SunMultiplier; // 0x248 Size: 0x4
	    float FogMultiplier; // 0x24c Size: 0x4
	    float DensityMultiplier; // 0x250 Size: 0x4
	    float DensityOffset; // 0x254 Size: 0x4
	    float DistanceScale; // 0x258 Size: 0x4
	    float AltitudeScale; // 0x25c Size: 0x4
	    float DistanceOffset; // 0x260 Size: 0x4
	    float GroundOffset; // 0x264 Size: 0x4
	    float StartDistance; // 0x268 Size: 0x4
	    float SunDiscScale; // 0x26c Size: 0x4
	    float DefaultBrightness; // 0x270 Size: 0x4
	    struct FColor DefaultLightColor; // 0x274 Size: 0x4
	    bool bDisableSunDisk; // 0x278 Size: 0x1
	    bool bDisableGroundScattering; // 0x278 Size: 0x1
	    char UnknownData0[0x2]; // 0x27a
	    struct FAtmospherePrecomputeParameters PrecomputeParams; // 0x27c Size: 0x2c
	    class UTexture2D* TransmittanceTexture; // 0x2a8 Size: 0x8
	    class UTexture2D* IrradianceTexture; // 0x2b0 Size: 0x8
	    char UnknownData1[0x2b8]; // 0x2b8
	    void StartPrecompute(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetSunMultiplier(float NewSunMultiplier); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetStartDistance(float NewStartDistance); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetPrecomputeParams(float DensityHeight, int MaxScatteringOrder, int InscatterAltitudeSampleNum); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetFogMultiplier(float NewFogMultiplier); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetDistanceScale(float NewDistanceScale); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetDistanceOffset(float NewDistanceOffset); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetDensityOffset(float NewDensityOffset); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetDensityMultiplier(float NewDensityMultiplier); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetDefaultLightColor(struct FLinearColor NewLightColor); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetDefaultBrightness(float NewBrightness); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetAltitudeScale(float NewAltitudeScale); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void DisableSunDisk(bool NewSunDisk); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void DisableGroundScattering(bool NewGroundScattering); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x-7bb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AtmosphericFogComponent");
			return (class UClass*)ptr;
		};

};

class UAudioSettings : public UDeveloperSettings
{
	public:
	    struct FSoftObjectPath DefaultSoundClassName; // 0x38 Size: 0x18
	    struct FSoftObjectPath DefaultMediaSoundClassName; // 0x50 Size: 0x18
	    struct FSoftObjectPath DefaultSoundConcurrencyName; // 0x68 Size: 0x18
	    struct FSoftObjectPath DefaultBaseSoundMix; // 0x80 Size: 0x18
	    struct FSoftObjectPath VoiPSoundClass; // 0x98 Size: 0x18
	    EVoiceSampleRate VoiPSampleRate; // 0xb0 Size: 0x4
	    float VoipBufferingDelay; // 0xb4 Size: 0x4
	    float DefaultReverbSendLevel; // 0xb8 Size: 0x4
	    int MaximumConcurrentStreams; // 0xbc Size: 0x4
	    TArray<struct FAudioQualitySettings> QualityLevels; // 0xc0 Size: 0x10
	    bool bAllowVirtualizedSounds; // 0xd0 Size: 0x1
	    bool bDisableMasterEQ; // 0xd0 Size: 0x1
	    bool bAllowCenterChannel3DPanning; // 0xd0 Size: 0x1
	    char UnknownData0[0x1]; // 0xd3
	    uint32_t MaxWaveInstances; // 0xd4 Size: 0x4
	    uint32_t NumStoppingSources; // 0xd8 Size: 0x4
	    EPanningMethod PanningMethod; // 0xdc Size: 0x1
	    EMonoChannelUpmixMethod MonoChannelUpmixMethod; // 0xdd Size: 0x1
	    char UnknownData1[0x2]; // 0xde
	    struct FString DialogueFilenameFormat; // 0xe0 Size: 0x10
	    char UnknownData2[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AudioSettings");
			return (class UClass*)ptr;
		};

};

class AAudioVolume : public AVolume
{
	public:
	    float Priority; // 0x368 Size: 0x4
	    bool bEnabled; // 0x36c Size: 0x1
	    char UnknownData0[0x3]; // 0x36d
	    struct FReverbSettings Settings; // 0x370 Size: 0x20
	    struct FInteriorSettings AmbientZoneSettings; // 0x390 Size: 0x24
	    char UnknownData1[0x3b4]; // 0x3b4
	    void SetReverbSettings(struct FReverbSettings NewReverbSettings); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetPriority(float NewPriority); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetInteriorSettings(struct FInteriorSettings NewInteriorSettings); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetEnabled(bool bNewEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnRep_bEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7c29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AudioVolume");
			return (class UClass*)ptr;
		};

};

class UAutomationTestSettings : public UObject
{
	public:
	    TArray<struct FString> EngineTestModules; // 0x28 Size: 0x10
	    TArray<struct FString> EditorTestModules; // 0x38 Size: 0x10
	    struct FSoftObjectPath AutomationTestmap; // 0x48 Size: 0x18
	    TArray<struct FEditorMapPerformanceTestDefinition> EditorPerformanceTestMaps; // 0x60 Size: 0x10
	    TArray<struct FSoftObjectPath> AssetsToOpen; // 0x70 Size: 0x10
	    struct FBuildPromotionTestSettings BuildPromotionTest; // 0x80 Size: 0x1f0
	    struct FMaterialEditorPromotionSettings MaterialEditorPromotionTest; // 0x270 Size: 0x30
	    struct FParticleEditorPromotionSettings ParticleEditorPromotionTest; // 0x2a0 Size: 0x10
	    struct FBlueprintEditorPromotionSettings BlueprintEditorPromotionTest; // 0x2b0 Size: 0x30
	    TArray<struct FString> TestLevelFolders; // 0x2e0 Size: 0x10
	    TArray<struct FExternalToolDefinition> ExternalTools; // 0x2f0 Size: 0x10
	    TArray<struct FEditorImportExportTestDefinition> ImportExportTestDefinitions; // 0x300 Size: 0x10
	    TArray<struct FLaunchOnTestSettings> LaunchOnSettings; // 0x310 Size: 0x10
	    struct FIntPoint DefaultScreenshotResolution; // 0x320 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AutomationTestSettings");
			return (class UClass*)ptr;
		};

};

class UBillboardComponent : public UPrimitiveComponent
{
	public:
	    class UTexture2D* Sprite; // 0x570 Size: 0x8
	    bool bIsScreenSizeScaled; // 0x578 Size: 0x1
	    char UnknownData0[0x3]; // 0x579
	    float ScreenSize; // 0x57c Size: 0x4
	    float U; // 0x580 Size: 0x4
	    float UL; // 0x584 Size: 0x4
	    float V; // 0x588 Size: 0x4
	    float VL; // 0x58c Size: 0x4
	    char UnknownData1[0x590]; // 0x590
	    void SetUV(int NewU, int NewUL, int NewV, int NewVL); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetSpriteAndUV(class UTexture2D* NewSprite, int NewU, int NewUL, int NewV, int NewVL); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetSprite(class UTexture2D* NewSprite); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7a51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BillboardComponent");
			return (class UClass*)ptr;
		};

};

class UBlendableInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BlendableInterface");
			return (class UClass*)ptr;
		};

};

class USkeleton : public UObject
{
	public:
	    char UnknownData0[0x10];
	    TArray<struct FBoneNode> BoneTree; // 0x38 Size: 0x10
	    TArray<struct FTransform> RefLocalPoses; // 0x48 Size: 0x10
	    char UnknownData1[0x118]; // 0x58
	    struct FGuid VirtualBoneGuid; // 0x170 Size: 0x10
	    TArray<struct FVirtualBone> VirtualBones; // 0x180 Size: 0x10
	    TArray<class USkeletalMeshSocket*> Sockets; // 0x190 Size: 0x10
	    char UnknownData2[0x50]; // 0x1a0
	    struct FSmartNameContainer SmartNames; // 0x1f0 Size: 0x50
	    char UnknownData3[0x28]; // 0x240
	    TArray<class UBlendProfile*> BlendProfiles; // 0x268 Size: 0x10
	    TArray<struct FAnimSlotGroup> SlotGroups; // 0x278 Size: 0x10
	    char UnknownData4[0xc8]; // 0x288
	    TArray<class UAssetUserData*> AssetUserData; // 0x350 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Skeleton");
			return (class UClass*)ptr;
		};

};

class UBlendProfile : public UObject
{
	public:
	    char UnknownData0[0x8];
	    class USkeleton* OwningSkeleton; // 0x30 Size: 0x8
	    TArray<struct FBlendProfileBoneEntry> ProfileEntries; // 0x38 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BlendProfile");
			return (class UClass*)ptr;
		};

};

class ABlockingVolume : public AVolume
{
	public:
	    char UnknownData0[0x368];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BlockingVolume");
			return (class UClass*)ptr;
		};

};

class UBlueprintMapLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void SetMapPropertyByName(class UObject* Object, FName PropertyName, __int64/*MapProperty*/ Value); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void Map_Values(__int64/*MapProperty*/ TargetMap, TArray<int> Values); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static bool Map_Remove(__int64/*MapProperty*/ TargetMap, int Key); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static int Map_Length(__int64/*MapProperty*/ TargetMap); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static void Map_Keys(__int64/*MapProperty*/ TargetMap, TArray<int> Keys); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static bool Map_Find(__int64/*MapProperty*/ TargetMap, int Key, int Value); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static bool Map_Contains(__int64/*MapProperty*/ TargetMap, int Key); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static void Map_Clear(__int64/*MapProperty*/ TargetMap); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static void Map_Add(__int64/*MapProperty*/ TargetMap, int Key, int Value); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BlueprintMapLibrary");
			return (class UClass*)ptr;
		};

};

class UBlueprintPathsLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static struct FString VideoCaptureDir(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void ValidatePath(struct FString InPath, bool bDidSucceed, struct FText OutReason); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static void Split(struct FString InPath, struct FString PathPart, struct FString FilenamePart, struct FString ExtensionPart); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static struct FString SourceConfigDir(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static bool ShouldSaveToUserDir(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static struct FString ShaderWorkingDir(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static void SetProjectFilePath(struct FString NewGameProjectFilePath); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static struct FString SetExtension(struct FString InPath, struct FString InNewExtension); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static struct FString ScreenShotDir(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static struct FString SandboxesDir(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static struct FString RootDir(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static void RemoveDuplicateSlashes(struct FString InPath, struct FString OutPath); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    static struct FString ProjectUserDir(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    static struct FString ProjectSavedDir(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    static struct FString ProjectPluginsDir(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    static struct FString ProjectPersistentDownloadDir(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    static struct FString ProjectModsDir(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    static struct FString ProjectLogDir(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    static struct FString ProjectIntermediateDir(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    static struct FString ProjectDir(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    static struct FString ProjectContentDir(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    static struct FString ProjectConfigDir(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    static struct FString ProfilingDir(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    static void NormalizeFilename(struct FString InPath, struct FString OutPath); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    static void NormalizeDirectoryName(struct FString InPath, struct FString OutPath); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    static struct FString MakeValidFileName(struct FString inString, struct FString InReplacementChar); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    static void MakeStandardFilename(struct FString InPath, struct FString OutPath); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    static void MakePlatformFilename(struct FString InPath, struct FString OutPath); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    static bool MakePathRelativeTo(struct FString InPath, struct FString InRelativeTo, struct FString OutPath); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    static struct FString LaunchDir(); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    static bool IsSamePath(struct FString PathA, struct FString PathB); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    static bool IsRestrictedPath(struct FString InPath); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    static bool IsRelative(struct FString InPath); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    static bool IsProjectFilePathSet(); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    static bool IsDrive(struct FString InPath); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    static bool HasProjectPersistentDownloadDir(); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    static TArray<struct FString> GetToolTipLocalizationPaths(); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    static TArray<struct FString> GetRestrictedFolderNames(); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    static struct FString GetRelativePathToRoot(); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    static TArray<struct FString> GetPropertyNameLocalizationPaths(); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    static struct FString GetProjectFilePath(); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    static struct FString GetPath(struct FString InPath); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    static struct FString GetInvalidFileSystemChars(); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    static TArray<struct FString> GetGameLocalizationPaths(); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    static struct FString GetExtension(struct FString InPath, bool bIncludeDot); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    static TArray<struct FString> GetEngineLocalizationPaths(); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    static TArray<struct FString> GetEditorLocalizationPaths(); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    static struct FString GetCleanFilename(struct FString InPath); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    static struct FString GetBaseFilename(struct FString InPath, bool bRemovePath); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    static struct FString GeneratedConfigDir(); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    static struct FString GameUserDeveloperDir(); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    static struct FString GameSourceDir(); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    static struct FString GameDevelopersDir(); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    static struct FString GameAgnosticSavedDir(); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    static bool FileExists(struct FString InPath); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    static struct FString FeaturePackDir(); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    static struct FString EnterprisePluginsDir(); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    static struct FString EnterpriseFeaturePackDir(); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    static struct FString EnterpriseDir(); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    static struct FString EngineVersionAgnosticUserDir(); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    static struct FString EngineUserDir(); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    static struct FString EngineSourceDir(); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    static struct FString EngineSavedDir(); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x7fe1]; // 0x7fe1
	    static struct FString EnginePluginsDir(); // 0x0 Size: 0x7fe1
	    char UnknownData63[0x7fe1]; // 0x7fe1
	    static struct FString EngineIntermediateDir(); // 0x0 Size: 0x7fe1
	    char UnknownData64[0x7fe1]; // 0x7fe1
	    static struct FString EngineDir(); // 0x0 Size: 0x7fe1
	    char UnknownData65[0x7fe1]; // 0x7fe1
	    static struct FString EngineContentDir(); // 0x0 Size: 0x7fe1
	    char UnknownData66[0x7fe1]; // 0x7fe1
	    static struct FString EngineConfigDir(); // 0x0 Size: 0x7fe1
	    char UnknownData67[0x7fe1]; // 0x7fe1
	    static bool DirectoryExists(struct FString InPath); // 0x0 Size: 0x7fe1
	    char UnknownData68[0x7fe1]; // 0x7fe1
	    static struct FString DiffDir(); // 0x0 Size: 0x7fe1
	    char UnknownData69[0x7fe1]; // 0x7fe1
	    static struct FString CreateTempFilename(struct FString Path, struct FString Prefix, struct FString Extension); // 0x0 Size: 0x7fe1
	    char UnknownData70[0x7fe1]; // 0x7fe1
	    static struct FString ConvertToSandboxPath(struct FString InPath, struct FString InSandboxName); // 0x0 Size: 0x7fe1
	    char UnknownData71[0x7fe1]; // 0x7fe1
	    static struct FString ConvertRelativePathToFull(struct FString InPath, struct FString InBasePath); // 0x0 Size: 0x7fe1
	    char UnknownData72[0x7fe1]; // 0x7fe1
	    static struct FString ConvertFromSandboxPath(struct FString InPath, struct FString InSandboxName); // 0x0 Size: 0x7fe1
	    char UnknownData73[0x7fe1]; // 0x7fe1
	    static struct FString Combine(TArray<struct FString> InPaths); // 0x0 Size: 0x7fe1
	    char UnknownData74[0x7fe1]; // 0x7fe1
	    static bool CollapseRelativeDirectories(struct FString InPath, struct FString OutPath); // 0x0 Size: 0x7fe1
	    char UnknownData75[0x7fe1]; // 0x7fe1
	    static struct FString CloudDir(); // 0x0 Size: 0x7fe1
	    char UnknownData76[0x7fe1]; // 0x7fe1
	    static struct FString ChangeExtension(struct FString InPath, struct FString InNewExtension); // 0x0 Size: 0x7fe1
	    char UnknownData77[0x7fe1]; // 0x7fe1
	    static struct FString BugItDir(); // 0x0 Size: 0x7fe1
	    char UnknownData78[0x7fe1]; // 0x7fe1
	    static struct FString AutomationTransientDir(); // 0x0 Size: 0x7fe1
	    char UnknownData79[0x7fe1]; // 0x7fe1
	    static struct FString AutomationLogDir(); // 0x0 Size: 0x7fe1
	    char UnknownData80[0x7fe1]; // 0x7fe1
	    static struct FString AutomationDir(); // 0x0 Size: 0x7fe1
	    char UnknownData81[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BlueprintPathsLibrary");
			return (class UClass*)ptr;
		};

};

class UPlatformGameInstance : public UGameInstance
{
	public:
	    MulticastDelegateProperty ApplicationWillDeactivateDelegate; // 0x168 Size: 0x10
	    MulticastDelegateProperty ApplicationHasReactivatedDelegate; // 0x178 Size: 0x10
	    MulticastDelegateProperty ApplicationWillEnterBackgroundDelegate; // 0x188 Size: 0x10
	    MulticastDelegateProperty ApplicationHasEnteredForegroundDelegate; // 0x198 Size: 0x10
	    MulticastDelegateProperty ApplicationWillTerminateDelegate; // 0x1a8 Size: 0x10
	    MulticastDelegateProperty ApplicationShouldUnloadResourcesDelegate; // 0x1b8 Size: 0x10
	    MulticastDelegateProperty ApplicationReceivedStartupArgumentsDelegate; // 0x1c8 Size: 0x10
	    MulticastDelegateProperty ApplicationRegisteredForRemoteNotificationsDelegate; // 0x1d8 Size: 0x10
	    MulticastDelegateProperty ApplicationRegisteredForUserNotificationsDelegate; // 0x1e8 Size: 0x10
	    MulticastDelegateProperty ApplicationFailedToRegisterForRemoteNotificationsDelegate; // 0x1f8 Size: 0x10
	    MulticastDelegateProperty ApplicationReceivedRemoteNotificationDelegate; // 0x208 Size: 0x10
	    MulticastDelegateProperty ApplicationReceivedLocalNotificationDelegate; // 0x218 Size: 0x10
	    MulticastDelegateProperty ApplicationReceivedScreenOrientationChangedNotificationDelegate; // 0x228 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PlatformGameInstance");
			return (class UClass*)ptr;
		};

};

class UBlueprintPlatformLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void ScheduleLocalNotificationFromNow(int inSecondsFromNow, struct FText Title, struct FText Body, struct FText Action, struct FString ActivationEvent); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void ScheduleLocalNotificationBadgeFromNow(int inSecondsFromNow, struct FString ActivationEvent); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static void ScheduleLocalNotificationBadgeAtTime(struct FDateTime FireDateTime, bool LocalTime, struct FString ActivationEvent); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static void ScheduleLocalNotificationAtTime(struct FDateTime FireDateTime, bool LocalTime, struct FText Title, struct FText Body, struct FText Action, struct FString ActivationEvent); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static void GetLaunchNotification(bool NotificationLaunchedApp, struct FString ActivationEvent, int FireDate); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static char GetDeviceOrientation(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static void ClearAllLocalNotifications(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static void CancelLocalNotification(struct FString ActivationEvent); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BlueprintPlatformLibrary");
			return (class UClass*)ptr;
		};

};

class UBlueprintSetLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void SetSetPropertyByName(class UObject* Object, FName PropertyName, __int64/*SetProperty*/ Value); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void Set_Union(__int64/*SetProperty*/ A, __int64/*SetProperty*/ B, __int64/*SetProperty*/ Result); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static void Set_ToArray(__int64/*SetProperty*/ A, TArray<int> Result); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static void Set_RemoveItems(__int64/*SetProperty*/ TargetSet, TArray<int> Items); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static bool Set_Remove(__int64/*SetProperty*/ TargetSet, int Item); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static int Set_Length(__int64/*SetProperty*/ TargetSet); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static void Set_Intersection(__int64/*SetProperty*/ A, __int64/*SetProperty*/ B, __int64/*SetProperty*/ Result); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static void Set_Difference(__int64/*SetProperty*/ A, __int64/*SetProperty*/ B, __int64/*SetProperty*/ Result); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static bool Set_Contains(__int64/*SetProperty*/ TargetSet, int ItemToFind); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static void Set_Clear(__int64/*SetProperty*/ TargetSet); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static void Set_AddItems(__int64/*SetProperty*/ TargetSet, TArray<int> NewItems); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static void Set_Add(__int64/*SetProperty*/ TargetSet, int NewItem); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BlueprintSetLibrary");
			return (class UClass*)ptr;
		};

};

class UBodySetup : public UObject
{
	public:
	    struct FKAggregateGeom AggGeom; // 0x28 Size: 0x58
	    FName BoneName; // 0x80 Size: 0x8
	    char PhysicsType; // 0x88 Size: 0x1
	    bool bAlwaysFullAnimWeight; // 0x89 Size: 0x1
	    bool bConsiderForBounds; // 0x89 Size: 0x1
	    bool bMeshCollideAll; // 0x89 Size: 0x1
	    bool bDoubleSidedGeometry; // 0x89 Size: 0x1
	    bool bGenerateNonMirroredCollision; // 0x89 Size: 0x1
	    bool bSharedCookedData; // 0x89 Size: 0x1
	    bool bGenerateMirroredCollision; // 0x89 Size: 0x1
	    char UnknownData0[0x5]; // 0x90
	    char CollisionReponse; // 0x8b Size: 0x1
	    char CollisionTraceFlag; // 0x8c Size: 0x1
	    char UnknownData1[0x3]; // 0x8d
	    class UPhysicalMaterial* PhysMaterial; // 0x90 Size: 0x8
	    struct FWalkableSlopeOverride WalkableSlopeOverride; // 0x98 Size: 0x10
	    char UnknownData2[0x68]; // 0xa8
	    struct FBodyInstance DefaultInstance; // 0x110 Size: 0x150
	    char UnknownData3[0x8]; // 0x260
	    struct FVector BuildScale3D; // 0x268 Size: 0xc
	    char UnknownData4[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BodySetup");
			return (class UClass*)ptr;
		};

};

class UBoneMaskFilter : public UObject
{
	public:
	    TArray<struct FInputBlendPose> BlendPoses; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BoneMaskFilter");
			return (class UClass*)ptr;
		};

};

class UBookmarkBase : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BookmarkBase");
			return (class UClass*)ptr;
		};

};

class UBookMark : public UBookmarkBase
{
	public:
	    struct FVector Location; // 0x28 Size: 0xc
	    struct FRotator Rotation; // 0x34 Size: 0xc
	    TArray<struct FString> HiddenLevels; // 0x40 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BookMark");
			return (class UClass*)ptr;
		};

};

class UBookMark2D : public UBookmarkBase
{
	public:
	    float Zoom2D; // 0x28 Size: 0x4
	    struct FIntPoint Location; // 0x2c Size: 0x8
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BookMark2D");
			return (class UClass*)ptr;
		};

};

class AReflectionCapture : public AActor
{
	public:
	    class UReflectionCaptureComponent* CaptureComponent; // 0x330 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ReflectionCapture");
			return (class UClass*)ptr;
		};

};

class ABoxReflectionCapture : public AReflectionCapture
{
	public:
	    char UnknownData0[0x338];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BoxReflectionCapture");
			return (class UClass*)ptr;
		};

};

class UReflectionCaptureComponent : public USceneComponent
{
	public:
	    class UBillboardComponent* CaptureOffsetComponent; // 0x248 Size: 0x8
	    EReflectionSourceType ReflectionSourceType; // 0x250 Size: 0x1
	    char UnknownData0[0x7]; // 0x251
	    class UTextureCube* Cubemap; // 0x258 Size: 0x8
	    float SourceCubemapAngle; // 0x260 Size: 0x4
	    float Brightness; // 0x264 Size: 0x4
	    struct FVector CaptureOffset; // 0x268 Size: 0xc
	    struct FGuid MapBuildDataId; // 0x274 Size: 0x10
	    char UnknownData1[0x3c];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ReflectionCaptureComponent");
			return (class UClass*)ptr;
		};

};

class UBoxReflectionCaptureComponent : public UReflectionCaptureComponent
{
	public:
	    float BoxTransitionDistance; // 0x2c0 Size: 0x4
	    char UnknownData0[0x4]; // 0x2c4
	    class UBoxComponent* PreviewInfluenceBox; // 0x2c8 Size: 0x8
	    class UBoxComponent* PreviewCaptureBox; // 0x2d0 Size: 0x8
	    char UnknownData1[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BoxReflectionCaptureComponent");
			return (class UClass*)ptr;
		};

};

class UBreakpoint : public UObject
{
	public:
	    bool bEnabled; // 0x28 Size: 0x1
	    char UnknownData0[0x7]; // 0x29
	    class UEdGraphNode* Node; // 0x30 Size: 0x8
	    bool bStepOnce; // 0x38 Size: 0x1
	    bool bStepOnce_WasPreviouslyDisabled; // 0x38 Size: 0x1
	    bool bStepOnce_RemoveAfterHit; // 0x38 Size: 0x1
	    char UnknownData1[0x5];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Breakpoint");
			return (class UClass*)ptr;
		};

};

class UBrushBuilder : public UObject
{
	public:
	    struct FString BitmapFilename; // 0x28 Size: 0x10
	    struct FString Tooltip; // 0x38 Size: 0x10
	    bool NotifyBadParams; // 0x48 Size: 0x1
	    char UnknownData0[0x7]; // 0x49
	    TArray<struct FVector> Vertices; // 0x50 Size: 0x10
	    TArray<struct FBuilderPoly> Polys; // 0x60 Size: 0x10
	    FName Layer; // 0x70 Size: 0x8
	    bool MergeCoplanars; // 0x78 Size: 0x1
	    char UnknownData1[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BrushBuilder");
			return (class UClass*)ptr;
		};

};

class UBrushComponent : public UPrimitiveComponent
{
	public:
	    class UModel* Brush; // 0x570 Size: 0x8
	    class UBodySetup* BrushBodySetup; // 0x578 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BrushComponent");
			return (class UClass*)ptr;
		};

};

class ABrushShape : public ABrush
{
	public:
	    char UnknownData0[0x368];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.BrushShape");
			return (class UClass*)ptr;
		};

};

class UButtonStyleAsset : public UObject
{
	public:
	    struct FButtonStyle ButtonStyle; // 0x28 Size: 0x278

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ButtonStyleAsset");
			return (class UClass*)ptr;
		};

};

class UCameraAnim : public UObject
{
	public:
	    class UInterpGroup* CameraInterpGroup; // 0x28 Size: 0x8
	    float AnimLength; // 0x30 Size: 0x4
	    struct FBox BoundingBox; // 0x34 Size: 0x1c
	    bool bRelativeToInitialTransform; // 0x50 Size: 0x1
	    bool bRelativeToInitialFOV; // 0x50 Size: 0x1
	    char UnknownData0[0x2]; // 0x52
	    float BaseFOV; // 0x54 Size: 0x4
	    char UnknownData1[0x8]; // 0x58
	    struct FPostProcessSettings BasePostProcessSettings; // 0x60 Size: 0x4e0
	    float BasePostProcessBlendWeight; // 0x540 Size: 0x4
	    char UnknownData2[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CameraAnim");
			return (class UClass*)ptr;
		};

};

class UCameraAnimInst : public UObject
{
	public:
	    class UCameraAnim* CamAnim; // 0x28 Size: 0x8
	    class UInterpGroupInst* InterpGroupInst; // 0x30 Size: 0x8
	    char UnknownData0[0x18]; // 0x38
	    float PlayRate; // 0x50 Size: 0x4
	    char UnknownData1[0x14]; // 0x54
	    class UInterpTrackMove* MoveTrack; // 0x68 Size: 0x8
	    class UInterpTrackInstMove* MoveInst; // 0x70 Size: 0x8
	    char PlaySpace; // 0x78 Size: 0x1
	    char UnknownData2[0x79]; // 0x79
	    void Stop(bool bImmediate); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetScale(float NewDuration); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetDuration(float NewDuration); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7ed1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CameraAnimInst");
			return (class UClass*)ptr;
		};

};

class ACameraBlockingVolume : public AVolume
{
	public:
	    char UnknownData0[0x368];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CameraBlockingVolume");
			return (class UClass*)ptr;
		};

};

class UCameraModifier : public UObject
{
	public:
	    bool bDebug; // 0x28 Size: 0x1
	    bool bExclusive; // 0x28 Size: 0x1
	    char UnknownData0[0x2]; // 0x2a
	    char Priority; // 0x2c Size: 0x1
	    char UnknownData1[0x3]; // 0x2d
	    class APlayerCameraManager* CameraOwner; // 0x30 Size: 0x8
	    float AlphaInTime; // 0x38 Size: 0x4
	    float AlphaOutTime; // 0x3c Size: 0x4
	    float Alpha; // 0x40 Size: 0x4
	    char UnknownData2[0x44]; // 0x44
	    bool IsDisabled(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    class AActor* GetViewTarget(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void EnableModifier(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void DisableModifier(bool bImmediate); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void BlueprintModifyPostProcess(float DeltaTime, float PostProcessBlendWeight, struct FPostProcessSettings PostProcessSettings); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void BlueprintModifyCamera(float DeltaTime, struct FVector ViewLocation, struct FRotator ViewRotation, float FOV, struct FVector NewViewLocation, struct FRotator NewViewRotation, float NewFOV); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7f99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CameraModifier");
			return (class UClass*)ptr;
		};

};

class UCameraModifier_CameraShake : public UCameraModifier
{
	public:
	    TArray<class UCameraShake*> ActiveShakes; // 0x48 Size: 0x10
	    __int64/*MapProperty*/ ExpiredPooledShakesMap; // 0x58 Size: 0x50
	    float SplitScreenShakeScale; // 0xa8 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CameraModifier_CameraShake");
			return (class UClass*)ptr;
		};

};

class UCameraShake : public UObject
{
	public:
	    bool bSingleInstance; // 0x28 Size: 0x1
	    char UnknownData0[0x3]; // 0x29
	    float OscillationDuration; // 0x2c Size: 0x4
	    float OscillationBlendInTime; // 0x30 Size: 0x4
	    float OscillationBlendOutTime; // 0x34 Size: 0x4
	    struct FROscillator RotOscillation; // 0x38 Size: 0x24
	    struct FVOscillator LocOscillation; // 0x5c Size: 0x24
	    struct FFOscillator FOVOscillation; // 0x80 Size: 0xc
	    float AnimPlayRate; // 0x8c Size: 0x4
	    float AnimScale; // 0x90 Size: 0x4
	    float AnimBlendInTime; // 0x94 Size: 0x4
	    float AnimBlendOutTime; // 0x98 Size: 0x4
	    float RandomAnimSegmentDuration; // 0x9c Size: 0x4
	    class UCameraAnim* Anim; // 0xa0 Size: 0x8
	    bool bRandomAnimSegment; // 0xa8 Size: 0x1
	    char UnknownData1[0x17]; // 0xa9
	    class APlayerCameraManager* CameraOwner; // 0xc0 Size: 0x8
	    char UnknownData2[0x80]; // 0xc8
	    float ShakeScale; // 0x148 Size: 0x4
	    float OscillatorTimeRemaining; // 0x14c Size: 0x4
	    class UCameraAnimInst* AnimInst; // 0x150 Size: 0x8
	    char UnknownData3[0x158]; // 0x158
	    void ReceiveStopShake(bool bImmediately); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void ReceivePlayShake(float Scale); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool ReceiveIsFinished(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void BlueprintUpdateCameraShake(float DeltaTime, float Alpha, struct FMinimalViewInfo POV, struct FMinimalViewInfo ModifiedPOV); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7e81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CameraShake");
			return (class UClass*)ptr;
		};

};

class UCanvas : public UObject
{
	public:
	    float OrgX; // 0x28 Size: 0x4
	    float OrgY; // 0x2c Size: 0x4
	    float ClipX; // 0x30 Size: 0x4
	    float ClipY; // 0x34 Size: 0x4
	    struct FColor DrawColor; // 0x38 Size: 0x4
	    bool bCenterX; // 0x3c Size: 0x1
	    bool bCenterY; // 0x3c Size: 0x1
	    bool bNoSmooth; // 0x3c Size: 0x1
	    char UnknownData0[0x1]; // 0x3f
	    int SizeX; // 0x40 Size: 0x4
	    int SizeY; // 0x44 Size: 0x4
	    char UnknownData1[0x8]; // 0x48
	    struct FPlane ColorModulate; // 0x50 Size: 0x10
	    class UTexture2D* DefaultTexture; // 0x60 Size: 0x8
	    class UTexture2D* GradientTexture0; // 0x68 Size: 0x8
	    class UReporterGraph* ReporterGraph; // 0x70 Size: 0x8
	    char UnknownData2[0x78]; // 0x78
	    struct FVector2D K2_TextSize(class UFont* RenderFont, struct FString RenderText, struct FVector2D Scale); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    struct FVector2D K2_StrLen(class UFont* RenderFont, struct FString RenderText); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    struct FVector K2_Project(struct FVector WorldLocation); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void K2_DrawTriangle(class UTexture* RenderTexture, TArray<struct FCanvasUVTri> Triangles); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void K2_DrawTexture(class UTexture* RenderTexture, struct FVector2D ScreenPosition, struct FVector2D ScreenSize, struct FVector2D CoordinatePosition, struct FVector2D CoordinateSize, struct FLinearColor RenderColor, char BlendMode, float Rotation, struct FVector2D PivotPoint); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void K2_DrawText(class UFont* RenderFont, struct FString RenderText, struct FVector2D ScreenPosition, struct FVector2D Scale, struct FLinearColor RenderColor, float Kerning, struct FLinearColor ShadowColor, struct FVector2D ShadowOffset, bool bCentreX, bool bCentreY, bool bOutlined, struct FLinearColor OutlineColor); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void K2_DrawPolygon(class UTexture* RenderTexture, struct FVector2D ScreenPosition, struct FVector2D Radius, int NumberOfSides, struct FLinearColor RenderColor); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void K2_DrawMaterialTriangle(class UMaterialInterface* RenderMaterial, TArray<struct FCanvasUVTri> Triangles); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void K2_DrawMaterial(class UMaterialInterface* RenderMaterial, struct FVector2D ScreenPosition, struct FVector2D ScreenSize, struct FVector2D CoordinatePosition, struct FVector2D CoordinateSize, float Rotation, struct FVector2D PivotPoint); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void K2_DrawLine(struct FVector2D ScreenPositionA, struct FVector2D ScreenPositionB, float Thickness, struct FLinearColor RenderColor); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void K2_DrawBox(struct FVector2D ScreenPosition, struct FVector2D ScreenSize, float Thickness, struct FLinearColor RenderColor); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void K2_DrawBorder(class UTexture* BorderTexture, class UTexture* BackgroundTexture, class UTexture* LeftBorderTexture, class UTexture* RightBorderTexture, class UTexture* TopBorderTexture, class UTexture* BottomBorderTexture, struct FVector2D ScreenPosition, struct FVector2D ScreenSize, struct FVector2D CoordinatePosition, struct FVector2D CoordinateSize, struct FLinearColor RenderColor, struct FVector2D BorderScale, struct FVector2D BackgroundScale, float Rotation, struct FVector2D PivotPoint, struct FVector2D CornerSize); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void K2_Deproject(struct FVector2D ScreenPosition, struct FVector WorldOrigin, struct FVector WorldDirection); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x-7d21];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Canvas");
			return (class UClass*)ptr;
		};

};

class UTexture : public UObject
{
	public:
	    char UnknownData0[0x8];
	    struct FGuid LightingGuid; // 0x30 Size: 0x10
	    int LODBias; // 0x40 Size: 0x4
	    int NumCinematicMipLevels; // 0x44 Size: 0x4
	    char CompressionSettings; // 0x48 Size: 0x1
	    char Filter; // 0x49 Size: 0x1
	    char LODGroup; // 0x4a Size: 0x1
	    bool SRGB; // 0x4b Size: 0x1
	    bool NeverStream; // 0x4b Size: 0x1
	    bool bNoTiling; // 0x4b Size: 0x1
	    bool bUseCinematicMipLevels; // 0x4b Size: 0x1
	    bool bAsyncResourceReleaseHasBeenStarted; // 0x4b Size: 0x1
	    char UnknownData1[0x4]; // 0x50
	    int CachedCombinedLODBias; // 0x4c Size: 0x4
	    TArray<class UAssetUserData*> AssetUserData; // 0x50 Size: 0x10
	    char UnknownData2[0x58];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Texture");
			return (class UClass*)ptr;
		};

};

class UTextureRenderTarget : public UTexture
{
	public:
	    float TargetGamma; // 0xb8 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.TextureRenderTarget");
			return (class UClass*)ptr;
		};

};

class UTextureRenderTarget2D : public UTextureRenderTarget
{
	public:
	    int SizeX; // 0xc0 Size: 0x4
	    int SizeY; // 0xc4 Size: 0x4
	    struct FLinearColor ClearColor; // 0xc8 Size: 0x10
	    char AddressX; // 0xd8 Size: 0x1
	    char AddressY; // 0xd9 Size: 0x1
	    bool bForceLinearGamma; // 0xda Size: 0x1
	    bool bHDR; // 0xda Size: 0x1
	    bool bGPUSharedFlag; // 0xda Size: 0x1
	    bool bAutoGenerateMips; // 0xda Size: 0x1
	    char UnknownData0[0x3]; // 0xde
	    char RenderTargetFormat; // 0xdb Size: 0x1
	    char OverrideFormat; // 0xdc Size: 0x1
	    char UnknownData1[0xb];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.TextureRenderTarget2D");
			return (class UClass*)ptr;
		};

};

class UCanvasRenderTarget2D : public UTextureRenderTarget2D
{
	public:
	    MulticastDelegateProperty OnCanvasRenderTargetUpdate; // 0xe8 Size: 0x10
	    TWeakObjectPtr<UWorld*> World; // 0xf8 Size: 0x8
	    bool bShouldClearRenderTargetOnReceiveUpdate; // 0x100 Size: 0x1
	    char UnknownData0[0x101]; // 0x101
	    void UpdateResource(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void ReceiveUpdate(class UCanvas* Canvas, int Width, int Height); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void GetSize(int Width, int Height); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static class UCanvasRenderTarget2D* CreateCanvasRenderTarget2D(class UObject* WorldContextObject, class UCanvasRenderTarget2D* CanvasRenderTarget2DClass, int Width, int Height); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7ed9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CanvasRenderTarget2D");
			return (class UClass*)ptr;
		};

};

class UCapsuleComponent : public UShapeComponent
{
	public:
	    float CapsuleHalfHeight; // 0x588 Size: 0x4
	    float CapsuleRadius; // 0x58c Size: 0x4
	    char UnknownData0[0x590]; // 0x590
	    void SetCapsuleSize(float InRadius, float InHalfHeight, bool bUpdateOverlaps); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetCapsuleRadius(float Radius, bool bUpdateOverlaps); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetCapsuleHalfHeight(float HalfHeight, bool bUpdateOverlaps); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void GetUnscaledCapsuleSize_WithoutHemisphere(float OutRadius, float OutHalfHeightWithoutHemisphere); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void GetUnscaledCapsuleSize(float OutRadius, float OutHalfHeight); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    float GetUnscaledCapsuleRadius(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    float GetUnscaledCapsuleHalfHeight_WithoutHemisphere(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    float GetUnscaledCapsuleHalfHeight(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    float GetShapeScale(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void GetScaledCapsuleSize_WithoutHemisphere(float OutRadius, float OutHalfHeightWithoutHemisphere); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void GetScaledCapsuleSize(float OutRadius, float OutHalfHeight); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    float GetScaledCapsuleRadius(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    float GetScaledCapsuleHalfHeight_WithoutHemisphere(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    float GetScaledCapsuleHalfHeight(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x-7a51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CapsuleComponent");
			return (class UClass*)ptr;
		};

};

class UCheckBoxStyleAsset : public UObject
{
	public:
	    struct FCheckBoxStyle CheckBoxStyle; // 0x28 Size: 0x580

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CheckBoxStyleAsset");
			return (class UClass*)ptr;
		};

};

class UChildConnection : public UNetConnection
{
	public:
	    class UNetConnection* Parent; // 0x1928 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ChildConnection");
			return (class UClass*)ptr;
		};

};

class UPlatformInterfaceBase : public UObject
{
	public:
	    TArray<struct FDelegateArray> AllDelegates; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PlatformInterfaceBase");
			return (class UClass*)ptr;
		};

};

class UCloudStorageBase : public UPlatformInterfaceBase
{
	public:
	    TArray<struct FString> LocalCloudFiles; // 0x38 Size: 0x10
	    bool bSuppressDelegateCalls; // 0x48 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CloudStorageBase");
			return (class UClass*)ptr;
		};

};

class UCollisionProfile : public UDeveloperSettings
{
	public:
	    TArray<struct FCollisionResponseTemplate> Profiles; // 0x38 Size: 0x10
	    TArray<struct FCustomChannelSetup> DefaultChannelResponses; // 0x48 Size: 0x10
	    TArray<struct FCustomProfile> EditProfiles; // 0x58 Size: 0x10
	    TArray<struct FRedirector> ProfileRedirects; // 0x68 Size: 0x10
	    TArray<struct FRedirector> CollisionChannelRedirects; // 0x78 Size: 0x10
	    char UnknownData0[0xd0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CollisionProfile");
			return (class UClass*)ptr;
		};

};

class UComponentDelegateBinding : public UDynamicBlueprintBinding
{
	public:
	    TArray<struct FBlueprintComponentDelegateBinding> ComponentDelegateBindings; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ComponentDelegateBinding");
			return (class UClass*)ptr;
		};

};

class UCurveTable : public UObject
{
	public:
	    char UnknownData0[0xa0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CurveTable");
			return (class UClass*)ptr;
		};

};

class UCompositeCurveTable : public UCurveTable
{
	public:
	    TArray<class UCurveTable*> ParentTables; // 0xa0 Size: 0x10
	    char UnknownData0[0x8]; // 0xb0
	    TArray<class UCurveTable*> OldParentTables; // 0xb8 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CompositeCurveTable");
			return (class UClass*)ptr;
		};

};

class UCompositeDataTable : public UDataTable
{
	public:
	    TArray<class UDataTable*> ParentTables; // 0xa0 Size: 0x10
	    char UnknownData0[0x8]; // 0xb0
	    TArray<class UDataTable*> OldParentTables; // 0xb8 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CompositeDataTable");
			return (class UClass*)ptr;
		};

};

class UControlChannel : public UChannel
{
	public:
	    char UnknownData0[0x88];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ControlChannel");
			return (class UClass*)ptr;
		};

};

class UControlRigInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ControlRigInterface");
			return (class UClass*)ptr;
		};

};

class UStreamingSettings : public UDeveloperSettings
{
	public:
	    bool AsyncLoadingThreadEnabled; // 0x38 Size: 0x1
	    bool WarnIfTimeLimitExceeded; // 0x38 Size: 0x1
	    char UnknownData0[0x2]; // 0x3a
	    float TimeLimitExceededMultiplier; // 0x3c Size: 0x4
	    float TimeLimitExceededMinTime; // 0x40 Size: 0x4
	    int MinBulkDataSizeForAsyncLoading; // 0x44 Size: 0x4
	    bool UseBackgroundLevelStreaming; // 0x48 Size: 0x1
	    bool AsyncLoadingUseFullTimeLimit; // 0x48 Size: 0x1
	    char UnknownData1[0x2]; // 0x4a
	    float AsyncLoadingTimeLimit; // 0x4c Size: 0x4
	    float PriorityAsyncLoadingExtraTime; // 0x50 Size: 0x4
	    float LevelStreamingActorsUpdateTimeLimit; // 0x54 Size: 0x4
	    float PriorityLevelStreamingActorsUpdateExtraTime; // 0x58 Size: 0x4
	    int LevelStreamingComponentsRegistrationGranularity; // 0x5c Size: 0x4
	    float LevelStreamingUnregisterComponentsTimeLimit; // 0x60 Size: 0x4
	    int LevelStreamingComponentsUnregistrationGranularity; // 0x64 Size: 0x4
	    bool EventDrivenLoaderEnabled; // 0x68 Size: 0x1
	    char UnknownData2[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.StreamingSettings");
			return (class UClass*)ptr;
		};

};

class UGarbageCollectionSettings : public UDeveloperSettings
{
	public:
	    float TimeBetweenPurgingPendingKillObjects; // 0x38 Size: 0x4
	    bool FlushStreamingOnGC; // 0x3c Size: 0x1
	    bool AllowParallelGC; // 0x3c Size: 0x1
	    bool IncrementalBeginDestroyEnabled; // 0x3c Size: 0x1
	    bool CreateGCClusters; // 0x3c Size: 0x1
	    bool MergeGCClusters; // 0x3c Size: 0x1
	    bool ActorClusteringEnabled; // 0x3c Size: 0x1
	    bool BlueprintClusteringEnabled; // 0x3c Size: 0x1
	    bool UseDisregardForGCOnDedicatedServers; // 0x3c Size: 0x1
	    char UnknownData0[0x4]; // 0x44
	    int MinGCClusterSize; // 0x40 Size: 0x4
	    int NumRetriesBeforeForcingGC; // 0x44 Size: 0x4
	    int MaxObjectsNotConsideredByGC; // 0x48 Size: 0x4
	    int SizeOfPermanentObjectPool; // 0x4c Size: 0x4
	    int MaxObjectsInGame; // 0x50 Size: 0x4
	    int MaxObjectsInEditor; // 0x54 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.GarbageCollectionSettings");
			return (class UClass*)ptr;
		};

};

class ACullDistanceVolume : public AVolume
{
	public:
	    TArray<struct FCullDistanceSizePair> CullDistances; // 0x368 Size: 0x10
	    bool bEnabled; // 0x378 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CullDistanceVolume");
			return (class UClass*)ptr;
		};

};

class UCurveBase : public UObject
{
	public:
	    void GetValueRange(float MinValue, float MaxValue); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void GetTimeRange(float MinTime, float MaxTime); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7fb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CurveBase");
			return (class UClass*)ptr;
		};

};

class UCurveEdPresetCurve : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CurveEdPresetCurve");
			return (class UClass*)ptr;
		};

};

class UCurveFloat : public UCurveBase
{
	public:
	    struct FRichCurve FloatCurve; // 0x30 Size: 0x80
	    bool bIsEventCurve; // 0xb0 Size: 0x1
	    char UnknownData0[0xb1]; // 0xb1
	    float GetFloatValue(float InTime); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f29];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CurveFloat");
			return (class UClass*)ptr;
		};

};

class UCurveLinearColor : public UCurveBase
{
	public:
	    struct FRichCurve* FloatCurves; // 0x30 Size: 0x80
	    char UnknownData0[0x180]; // 0xb0
	    float AdjustHue; // 0x230 Size: 0x4
	    float AdjustSaturation; // 0x234 Size: 0x4
	    float AdjustBrightness; // 0x238 Size: 0x4
	    float AdjustBrightnessCurve; // 0x23c Size: 0x4
	    float AdjustVibrance; // 0x240 Size: 0x4
	    float AdjustMinAlpha; // 0x244 Size: 0x4
	    float AdjustMaxAlpha; // 0x248 Size: 0x4
	    char UnknownData1[0x24c]; // 0x24c
	    struct FLinearColor GetLinearColorValue(float InTime); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    struct FLinearColor GetClampedLinearColorValue(float InTime); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7d91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CurveLinearColor");
			return (class UClass*)ptr;
		};

};

class UTexture2D : public UTexture
{
	public:
	    int StreamingIndex; // 0xb8 Size: 0x4
	    int LevelIndex; // 0xbc Size: 0x4
	    int FirstResourceMemMip; // 0xc0 Size: 0x4
	    bool bTemporarilyDisableStreaming; // 0xc4 Size: 0x1
	    bool bIsStreamable; // 0xc4 Size: 0x1
	    bool bHasStreamingUpdatePending; // 0xc4 Size: 0x1
	    bool bForceMiplevelsToBeResident; // 0xc4 Size: 0x1
	    bool bIgnoreStreamingMipBias; // 0xc4 Size: 0x1
	    bool bGlobalForceMipLevelsToBeResident; // 0xc4 Size: 0x1
	    char UnknownData0[0x5]; // 0xca
	    char AddressX; // 0xc5 Size: 0x1
	    char AddressY; // 0xc6 Size: 0x1
	    char UnknownData1[0x1]; // 0xc7
	    struct FIntPoint ImportedSize; // 0xc8 Size: 0x8
	    double ForceMipLevelsToBeResidentTimestamp; // 0xd0 Size: 0x8
	    char UnknownData2[0xd8]; // 0xd8
	    int Blueprint_GetSizeY(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    int Blueprint_GetSizeX(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7ef1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Texture2D");
			return (class UClass*)ptr;
		};

};

class UCurveLinearColorAtlas : public UTexture2D
{
	public:
	    uint32_t TextureSize; // 0xf0 Size: 0x4
	    uint32_t GradientPixelSize; // 0xf4 Size: 0x4
	    TArray<class UCurveLinearColor*> GradientCurves; // 0xf8 Size: 0x10
	    char UnknownData0[0x108]; // 0x108
	    bool GetCurvePosition(class UCurveLinearColor* InCurve, float Position); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7ed9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CurveLinearColorAtlas");
			return (class UClass*)ptr;
		};

};

class UCurveSourceInterface : public UInterface
{
	public:
	    float GetCurveValue(FName CurveName); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void GetCurves(TArray<struct FNamedCurveValue> OutValues); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    FName GetBindingName(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CurveSourceInterface");
			return (class UClass*)ptr;
		};

};

class UCurveVector : public UCurveBase
{
	public:
	    struct FRichCurve* FloatCurves; // 0x30 Size: 0x80
	    char UnknownData0[0xb0]; // 0xb0
	    struct FVector GetVectorValue(float InTime); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7e31];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.CurveVector");
			return (class UClass*)ptr;
		};

};

class UDamageType : public UObject
{
	public:
	    bool bCausedByWorld; // 0x28 Size: 0x1
	    bool bScaleMomentumByMass; // 0x28 Size: 0x1
	    bool bRadialDamageVelChange; // 0x28 Size: 0x1
	    char UnknownData0[0x1]; // 0x2b
	    float DamageImpulse; // 0x2c Size: 0x4
	    float DestructibleImpulse; // 0x30 Size: 0x4
	    float DestructibleDamageSpreadScale; // 0x34 Size: 0x4
	    float DamageFalloff; // 0x38 Size: 0x4
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DamageType");
			return (class UClass*)ptr;
		};

};

class UDataTableFunctionLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void GetDataTableRowNames(class UDataTable* Table, TArray<FName> OutRowNames); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static bool GetDataTableRowFromName(class UDataTable* Table, FName RowName, struct FTableRowBase OutRow); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static TArray<struct FString> GetDataTableColumnAsString(class UDataTable* DataTable, FName PropertyName); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static void EvaluateCurveTableRow(class UCurveTable* CurveTable, FName RowName, float InXY, char OutResult, float OutXY, struct FString ContextString); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static bool DoesDataTableRowExist(class UDataTable* Table, FName RowName); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DataTableFunctionLibrary");
			return (class UClass*)ptr;
		};

};

class ADebugCameraController : public APlayerController
{
	public:
	    bool bShowSelectedInfo; // 0x680 Size: 0x1
	    bool bIsFrozenRendering; // 0x680 Size: 0x1
	    char UnknownData0[0x6]; // 0x682
	    class UDrawFrustumComponent* DrawFrustum; // 0x688 Size: 0x8
	    char UnknownData1[0x20]; // 0x690
	    float SpeedScale; // 0x6b0 Size: 0x4
	    float InitialMaxSpeed; // 0x6b4 Size: 0x4
	    float InitialAccel; // 0x6b8 Size: 0x4
	    float InitialDecel; // 0x6bc Size: 0x4
	    char UnknownData2[0x6c0]; // 0x6c0
	    void ToggleDisplay(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void ShowDebugSelectedInfo(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetPawnMovementSpeedScale(float NewSpeedScale); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ReceiveOnDeactivate(class APlayerController* RestoredPC); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ReceiveOnActorSelected(class AActor* NewSelectedActor, struct FVector SelectHitLocation, struct FVector SelectHitNormal, struct FHitResult Hit); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void ReceiveOnActivate(class APlayerController* OriginalPC); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    class AActor* GetSelectedActor(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7919];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DebugCameraController");
			return (class UClass*)ptr;
		};

};

class ADebugCameraHUD : public AHUD
{
	public:
	    char UnknownData0[0x420];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DebugCameraHUD");
			return (class UClass*)ptr;
		};

};

class UDebugDrawService : public UBlueprintFunctionLibrary
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DebugDrawService");
			return (class UClass*)ptr;
		};

};

class ADecalActor : public AActor
{
	public:
	    class UDecalComponent* Decal; // 0x330 Size: 0x8
	    char UnknownData0[0x338]; // 0x338
	    void SetDecalMaterial(class UMaterialInterface* NewDecalMaterial); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    class UMaterialInterface* GetDecalMaterial(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    class UMaterialInstanceDynamic* CreateDynamicMaterialInstance(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7ca9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DecalActor");
			return (class UClass*)ptr;
		};

};

class UDecalComponent : public USceneComponent
{
	public:
	    class UMaterialInterface* DecalMaterial; // 0x248 Size: 0x8
	    int SortOrder; // 0x250 Size: 0x4
	    float FadeScreenSize; // 0x254 Size: 0x4
	    float FadeStartDelay; // 0x258 Size: 0x4
	    float FadeDuration; // 0x25c Size: 0x4
	    float FadeInDuration; // 0x260 Size: 0x4
	    float FadeInStartDelay; // 0x264 Size: 0x4
	    bool bDestroyOwnerAfterFade; // 0x268 Size: 0x1
	    char UnknownData0[0x3]; // 0x269
	    struct FVector DecalSize; // 0x26c Size: 0xc
	    char UnknownData1[0x278]; // 0x278
	    void SetSortOrder(int Value); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetFadeScreenSize(float NewFadeScreenSize); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetFadeOut(float StartDelay, float Duration, bool DestroyOwnerAfterFade); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetFadeIn(float StartDelay, float Duaration); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetDecalMaterial(class UMaterialInterface* NewDecalMaterial); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    float GetFadeStartDelay(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    float GetFadeInStartDelay(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    float GetFadeInDuration(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    float GetFadeDuration(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    class UMaterialInterface* GetDecalMaterial(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    class UMaterialInstanceDynamic* CreateDynamicMaterialInstance(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7d51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DecalComponent");
			return (class UClass*)ptr;
		};

};

class ADefaultPhysicsVolume : public APhysicsVolume
{
	public:
	    char UnknownData0[0x378];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DefaultPhysicsVolume");
			return (class UClass*)ptr;
		};

};

class UDemoNetConnection : public UNetConnection
{
	public:
	    char UnknownData0[0x1948];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DemoNetConnection");
			return (class UClass*)ptr;
		};

};

class UDemoNetDriver : public UNetDriver
{
	public:
	    char UnknownData0[0xf8];
	    __int64/*MapProperty*/ RollbackNetStartupActors; // 0x818 Size: 0x50
	    char UnknownData1[0x29c]; // 0x868
	    float CheckpointSaveMaxMSPerFrame; // 0xb04 Size: 0x4
	    bool bIsLocalReplay; // 0xb38 Size: 0x1
	    char UnknownData2[0x32f];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DemoNetDriver");
			return (class UClass*)ptr;
		};

};

class UPendingNetGame : public UObject
{
	public:
	    char UnknownData0[0x8];
	    class UNetDriver* NetDriver; // 0x30 Size: 0x8
	    class UDemoNetDriver* DemoNetDriver; // 0x38 Size: 0x8
	    char UnknownData1[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PendingNetGame");
			return (class UClass*)ptr;
		};

};

class UDemoPendingNetGame : public UPendingNetGame
{
	public:
	    char UnknownData0[0xc0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DemoPendingNetGame");
			return (class UClass*)ptr;
		};

};

class UDestructibleInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DestructibleInterface");
			return (class UClass*)ptr;
		};

};

class UTextureLODSettings : public UObject
{
	public:
	    TArray<struct FTextureLODGroup> TextureLODGroups; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.TextureLODSettings");
			return (class UClass*)ptr;
		};

};

class UDeviceProfile : public UTextureLODSettings
{
	public:
	    struct FString DeviceType; // 0x38 Size: 0x10
	    struct FString BaseProfileName; // 0x48 Size: 0x10
	    class UObject* Parent; // 0x58 Size: 0x8
	    char UnknownData0[0x18]; // 0x60
	    TArray<struct FString> CVars; // 0x78 Size: 0x10
	    char UnknownData1[0x10];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DeviceProfile");
			return (class UClass*)ptr;
		};

};

class UDeviceProfileManager : public UObject
{
	public:
	    TArray<class UObject*> Profiles; // 0x28 Size: 0x10
	    char UnknownData0[0x70];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DeviceProfileManager");
			return (class UClass*)ptr;
		};

};

class UDialogueSoundWaveProxy : public USoundBase
{
	public:
	    char UnknownData0[0xc8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DialogueSoundWaveProxy");
			return (class UClass*)ptr;
		};

};

class UDialogueVoice : public UObject
{
	public:
	    char Gender; // 0x28 Size: 0x1
	    char Plurality; // 0x29 Size: 0x1
	    char UnknownData0[0x2]; // 0x2a
	    struct FGuid LocalizationGUID; // 0x2c Size: 0x10
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DialogueVoice");
			return (class UClass*)ptr;
		};

};

class UDialogueWave : public UObject
{
	public:
	    bool bMature; // 0x28 Size: 0x1
	    bool bOverride_SubtitleOverride; // 0x28 Size: 0x1
	    char UnknownData0[0x6]; // 0x2a
	    struct FString SpokenText; // 0x30 Size: 0x10
	    struct FString SubtitleOverride; // 0x40 Size: 0x10
	    TArray<struct FDialogueContextMapping> ContextMappings; // 0x50 Size: 0x10
	    struct FGuid LocalizationGUID; // 0x60 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DialogueWave");
			return (class UClass*)ptr;
		};

};

class ALight : public AActor
{
	public:
	    class ULightComponent* LightComponent; // 0x330 Size: 0x8
	    bool bEnabled; // 0x338 Size: 0x1
	    char UnknownData0[0x339]; // 0x339
	    void ToggleEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetLightFunctionScale(struct FVector NewLightFunctionScale); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetLightFunctionMaterial(class UMaterialInterface* NewLightFunctionMaterial); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetLightFunctionFadeDistance(float NewLightFunctionFadeDistance); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetLightColor(struct FLinearColor NewLightColor); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetEnabled(bool bSetEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetCastShadows(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetBrightness(float NewBrightness); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetAffectTranslucentLighting(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnRep_bEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    bool IsEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    struct FLinearColor GetLightColor(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    float GetBrightness(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x-7ca1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Light");
			return (class UClass*)ptr;
		};

};

class ADirectionalLight : public ALight
{
	public:
	    char UnknownData0[0x340];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DirectionalLight");
			return (class UClass*)ptr;
		};

};

class ULightComponentBase : public USceneComponent
{
	public:
	    struct FGuid LightGuid; // 0x248 Size: 0x10
	    float Brightness; // 0x258 Size: 0x4
	    float Intensity; // 0x25c Size: 0x4
	    struct FColor LightColor; // 0x260 Size: 0x4
	    bool bAffectsWorld; // 0x264 Size: 0x1
	    bool CastShadows; // 0x264 Size: 0x1
	    bool CastStaticShadows; // 0x264 Size: 0x1
	    bool CastDynamicShadows; // 0x264 Size: 0x1
	    bool bAffectTranslucentLighting; // 0x264 Size: 0x1
	    bool bTransmission; // 0x264 Size: 0x1
	    bool bCastVolumetricShadow; // 0x264 Size: 0x1
	    char UnknownData0[0x3]; // 0x26b
	    float IndirectLightingIntensity; // 0x268 Size: 0x4
	    float VolumetricScatteringIntensity; // 0x26c Size: 0x4
	    char UnknownData1[0x270]; // 0x270
	    void SetCastVolumetricShadow(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetCastShadows(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    struct FLinearColor GetLightColor(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7d71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LightComponentBase");
			return (class UClass*)ptr;
		};

};

class ULightComponent : public ULightComponentBase
{
	public:
	    float Temperature; // 0x270 Size: 0x4
	    float MaxDrawDistance; // 0x274 Size: 0x4
	    float MaxDistanceFadeRange; // 0x278 Size: 0x4
	    bool bUseTemperature; // 0x27c Size: 0x1
	    char UnknownData0[0x3]; // 0x27d
	    int ShadowMapChannel; // 0x280 Size: 0x4
	    char UnknownData1[0x4]; // 0x284
	    float MinRoughness; // 0x288 Size: 0x4
	    float SpecularScale; // 0x28c Size: 0x4
	    float ShadowResolutionScale; // 0x290 Size: 0x4
	    float ShadowBias; // 0x294 Size: 0x4
	    float ShadowSharpen; // 0x298 Size: 0x4
	    float ContactShadowLength; // 0x29c Size: 0x4
	    bool ContactShadowLengthInWS; // 0x2a0 Size: 0x1
	    bool InverseSquaredFalloff; // 0x2a0 Size: 0x1
	    bool CastTranslucentShadows; // 0x2a0 Size: 0x1
	    bool bCastShadowsFromCinematicObjectsOnly; // 0x2a0 Size: 0x1
	    bool bAffectDynamicIndirectLighting; // 0x2a0 Size: 0x1
	    bool bForceCachedShadowsForMovablePrimitives; // 0x2a0 Size: 0x1
	    char UnknownData2[0x2]; // 0x2a6
	    struct FLightingChannels LightingChannels; // 0x2a4 Size: 0x1
	    char UnknownData3[0x3]; // 0x2a5
	    class UMaterialInterface* LightFunctionMaterial; // 0x2a8 Size: 0x8
	    struct FVector LightFunctionScale; // 0x2b0 Size: 0xc
	    char UnknownData4[0x4]; // 0x2bc
	    class UTextureLightProfile* IESTexture; // 0x2c0 Size: 0x8
	    bool bUseIESBrightness; // 0x2c8 Size: 0x1
	    char UnknownData5[0x3]; // 0x2c9
	    float IESBrightnessScale; // 0x2cc Size: 0x4
	    float LightFunctionFadeDistance; // 0x2d0 Size: 0x4
	    float DisabledBrightness; // 0x2d4 Size: 0x4
	    bool bEnableLightShaftBloom; // 0x2d8 Size: 0x1
	    char UnknownData6[0x3]; // 0x2d9
	    float BloomScale; // 0x2dc Size: 0x4
	    float BloomThreshold; // 0x2e0 Size: 0x4
	    struct FColor BloomTint; // 0x2e4 Size: 0x4
	    bool bUseRayTracedDistanceFieldShadows; // 0x2e8 Size: 0x1
	    char UnknownData7[0x3]; // 0x2e9
	    float RayStartOffsetDepthScale; // 0x2ec Size: 0x4
	    char UnknownData8[0x2f0]; // 0x2f0
	    void SetVolumetricScatteringIntensity(float NewIntensity); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetTransmission(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetTemperature(float NewTemperature); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetShadowBias(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetLightFunctionScale(struct FVector NewLightFunctionScale); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void SetLightFunctionMaterial(class UMaterialInterface* NewLightFunctionMaterial); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void SetLightFunctionFadeDistance(float NewLightFunctionFadeDistance); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void SetLightFunctionDisabledBrightness(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void SetLightColor(struct FLinearColor NewLightColor, bool bSRGB); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void SetIntensity(float NewIntensity); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void SetIndirectLightingIntensity(float NewIntensity); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void SetIESTexture(class UTextureLightProfile* NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void SetForceCachedShadowsForMovablePrimitives(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void SetEnableLightShaftBloom(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void SetBloomTint(struct FColor NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void SetBloomThreshold(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void SetBloomScale(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void SetAffectTranslucentLighting(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void SetAffectDynamicIndirectLighting(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x-7c61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LightComponent");
			return (class UClass*)ptr;
		};

};

class UDirectionalLightComponent : public ULightComponent
{
	public:
	    bool bEnableLightShaftOcclusion; // 0x378 Size: 0x1
	    char UnknownData0[0x3]; // 0x379
	    float OcclusionMaskDarkness; // 0x37c Size: 0x4
	    float OcclusionDepthRange; // 0x380 Size: 0x4
	    struct FVector LightShaftOverrideDirection; // 0x384 Size: 0xc
	    float WholeSceneDynamicShadowRadius; // 0x390 Size: 0x4
	    float DynamicShadowDistanceMovableLight; // 0x394 Size: 0x4
	    float DynamicShadowDistanceStationaryLight; // 0x398 Size: 0x4
	    int DynamicShadowCascades; // 0x39c Size: 0x4
	    float CascadeDistributionExponent; // 0x3a0 Size: 0x4
	    float CascadeTransitionFraction; // 0x3a4 Size: 0x4
	    float ShadowDistanceFadeoutFraction; // 0x3a8 Size: 0x4
	    bool bUseInsetShadowsForMovableObjects; // 0x3ac Size: 0x1
	    char UnknownData1[0x3]; // 0x3ad
	    int FarShadowCascadeCount; // 0x3b0 Size: 0x4
	    float FarShadowDistance; // 0x3b4 Size: 0x4
	    float DistanceFieldShadowDistance; // 0x3b8 Size: 0x4
	    float LightSourceAngle; // 0x3bc Size: 0x4
	    float LightSourceSoftAngle; // 0x3c0 Size: 0x4
	    float TraceDistance; // 0x3c4 Size: 0x4
	    struct FLightmassDirectionalLightSettings LightmassSettings; // 0x3c8 Size: 0x10
	    bool bCastModulatedShadows; // 0x3d8 Size: 0x1
	    char UnknownData2[0x3]; // 0x3d9
	    struct FColor ModulatedShadowColor; // 0x3dc Size: 0x4
	    bool bUsedAsAtmosphereSunLight; // 0x3e0 Size: 0x1
	    char UnknownData3[0x3e1]; // 0x3e1
	    void SetShadowDistanceFadeoutFraction(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetOcclusionMaskDarkness(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetLightShaftOverrideDirection(struct FVector NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetEnableLightShaftOcclusion(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetDynamicShadowDistanceStationaryLight(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetDynamicShadowDistanceMovableLight(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetDynamicShadowCascades(int NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetCascadeTransitionFraction(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetCascadeDistributionExponent(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7bf1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DirectionalLightComponent");
			return (class UClass*)ptr;
		};

};

class UDistribution : public UObject
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Distribution");
			return (class UClass*)ptr;
		};

};

class UDistributionFloat : public UDistribution
{
	public:
	    bool bCanBeBaked; // 0x30 Size: 0x1
	    bool bBakedDataSuccesfully; // 0x30 Size: 0x1
	    char UnknownData0[0x6];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DistributionFloat");
			return (class UClass*)ptr;
		};

};

class UDistributionFloatConstant : public UDistributionFloat
{
	public:
	    float Constant; // 0x38 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DistributionFloatConstant");
			return (class UClass*)ptr;
		};

};

class UDistributionFloatConstantCurve : public UDistributionFloat
{
	public:
	    struct FInterpCurveFloat ConstantCurve; // 0x38 Size: 0x18

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DistributionFloatConstantCurve");
			return (class UClass*)ptr;
		};

};

class UDistributionFloatParameterBase : public UDistributionFloatConstant
{
	public:
	    FName ParameterName; // 0x40 Size: 0x8
	    float MinInput; // 0x48 Size: 0x4
	    float MaxInput; // 0x4c Size: 0x4
	    float MinOutput; // 0x50 Size: 0x4
	    float MaxOutput; // 0x54 Size: 0x4
	    char ParamMode; // 0x58 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DistributionFloatParameterBase");
			return (class UClass*)ptr;
		};

};

class UDistributionFloatParticleParameter : public UDistributionFloatParameterBase
{
	public:
	    char UnknownData0[0x60];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DistributionFloatParticleParameter");
			return (class UClass*)ptr;
		};

};

class UDistributionFloatUniform : public UDistributionFloat
{
	public:
	    float Min; // 0x38 Size: 0x4
	    float Max; // 0x3c Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DistributionFloatUniform");
			return (class UClass*)ptr;
		};

};

class UDistributionFloatUniformCurve : public UDistributionFloat
{
	public:
	    struct FInterpCurveVector2D ConstantCurve; // 0x38 Size: 0x18

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DistributionFloatUniformCurve");
			return (class UClass*)ptr;
		};

};

class UDistributionVector : public UDistribution
{
	public:
	    bool bCanBeBaked; // 0x30 Size: 0x1
	    bool bIsDirty; // 0x30 Size: 0x1
	    bool bBakedDataSuccesfully; // 0x30 Size: 0x1
	    char UnknownData0[0x5];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DistributionVector");
			return (class UClass*)ptr;
		};

};

class UDistributionVectorConstant : public UDistributionVector
{
	public:
	    struct FVector Constant; // 0x38 Size: 0xc
	    bool bLockAxes; // 0x44 Size: 0x1
	    char UnknownData0[0x3]; // 0x45
	    char LockedAxes; // 0x48 Size: 0x1
	    char UnknownData1[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DistributionVectorConstant");
			return (class UClass*)ptr;
		};

};

class UDistributionVectorConstantCurve : public UDistributionVector
{
	public:
	    struct FInterpCurveVector ConstantCurve; // 0x38 Size: 0x18
	    bool bLockAxes; // 0x50 Size: 0x1
	    char UnknownData0[0x3]; // 0x51
	    char LockedAxes; // 0x54 Size: 0x1
	    char UnknownData1[0x3];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DistributionVectorConstantCurve");
			return (class UClass*)ptr;
		};

};

class UDistributionVectorParameterBase : public UDistributionVectorConstant
{
	public:
	    FName ParameterName; // 0x50 Size: 0x8
	    struct FVector MinInput; // 0x58 Size: 0xc
	    struct FVector MaxInput; // 0x64 Size: 0xc
	    struct FVector MinOutput; // 0x70 Size: 0xc
	    struct FVector MaxOutput; // 0x7c Size: 0xc
	    char ParamModes; // 0x88 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DistributionVectorParameterBase");
			return (class UClass*)ptr;
		};

};

class UDistributionVectorParticleParameter : public UDistributionVectorParameterBase
{
	public:
	    char UnknownData0[0x90];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DistributionVectorParticleParameter");
			return (class UClass*)ptr;
		};

};

class UDistributionVectorUniform : public UDistributionVector
{
	public:
	    struct FVector Max; // 0x38 Size: 0xc
	    struct FVector Min; // 0x44 Size: 0xc
	    bool bLockAxes; // 0x50 Size: 0x1
	    char UnknownData0[0x3]; // 0x51
	    char LockedAxes; // 0x54 Size: 0x1
	    char MirrorFlags; // 0x55 Size: 0x1
	    bool bUseExtremes; // 0x58 Size: 0x1
	    char UnknownData1[0x9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DistributionVectorUniform");
			return (class UClass*)ptr;
		};

};

class UDistributionVectorUniformCurve : public UDistributionVector
{
	public:
	    struct FInterpCurveTwoVectors ConstantCurve; // 0x38 Size: 0x18
	    bool bLockAxes1; // 0x50 Size: 0x1
	    bool bLockAxes2; // 0x50 Size: 0x1
	    char UnknownData0[0x2]; // 0x52
	    char LockedAxes; // 0x54 Size: 0x1
	    char UnknownData1[0x1]; // 0x55
	    char MirrorFlags; // 0x56 Size: 0x1
	    bool bUseExtremes; // 0x5c Size: 0x1
	    char UnknownData2[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DistributionVectorUniformCurve");
			return (class UClass*)ptr;
		};

};

class ADocumentationActor : public AActor
{
	public:
	    char UnknownData0[0x338];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DocumentationActor");
			return (class UClass*)ptr;
		};

};

class UDPICustomScalingRule : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DPICustomScalingRule");
			return (class UClass*)ptr;
		};

};

class UDrawFrustumComponent : public UPrimitiveComponent
{
	public:
	    struct FColor FrustumColor; // 0x570 Size: 0x4
	    float FrustumAngle; // 0x574 Size: 0x4
	    float FrustumAspectRatio; // 0x578 Size: 0x4
	    float FrustumStartDist; // 0x57c Size: 0x4
	    float FrustumEndDist; // 0x580 Size: 0x4
	    char UnknownData0[0x4]; // 0x584
	    class UTexture* Texture; // 0x588 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DrawFrustumComponent");
			return (class UClass*)ptr;
		};

};

class USphereComponent : public UShapeComponent
{
	public:
	    float SphereRadius; // 0x588 Size: 0x4
	    char UnknownData0[0x58c]; // 0x58c
	    void SetSphereRadius(float InSphereRadius, bool bUpdateOverlaps); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    float GetUnscaledSphereRadius(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    float GetShapeScale(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    float GetScaledSphereRadius(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7a51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SphereComponent");
			return (class UClass*)ptr;
		};

};

class UDrawSphereComponent : public USphereComponent
{
	public:
	    char UnknownData0[0x590];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.DrawSphereComponent");
			return (class UClass*)ptr;
		};

};

class UEdGraph : public UObject
{
	public:
	    class UEdGraphSchema* Schema; // 0x28 Size: 0x8
	    TArray<class UEdGraphNode*> Nodes; // 0x30 Size: 0x10
	    bool bEditable; // 0x40 Size: 0x1
	    bool bAllowDeletion; // 0x40 Size: 0x1
	    bool bAllowRenaming; // 0x40 Size: 0x1
	    char UnknownData0[0x1d];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.EdGraph");
			return (class UClass*)ptr;
		};

};

class UEdGraphNode : public UObject
{
	public:
	    char UnknownData0[0x10];
	    TArray<class UEdGraphPin_Deprecated*> DeprecatedPins; // 0x38 Size: 0x10
	    int NodePosX; // 0x48 Size: 0x4
	    int NodePosY; // 0x4c Size: 0x4
	    int NodeWidth; // 0x50 Size: 0x4
	    int NodeHeight; // 0x54 Size: 0x4
	    char AdvancedPinDisplay; // 0x58 Size: 0x1
	    ENodeEnabledState EnabledState; // 0x59 Size: 0x1
	    bool bDisplayAsDisabled; // 0x5b Size: 0x1
	    bool bUserSetEnabledState; // 0x5b Size: 0x1
	    bool bIsNodeEnabled; // 0x5b Size: 0x1
	    bool bHasCompilerMessage; // 0x5b Size: 0x1
	    bool bCommentBubblePinned; // 0x5b Size: 0x1
	    bool bCommentBubbleVisible; // 0x5c Size: 0x1
	    bool bCommentBubbleMakeVisible; // 0x5c Size: 0x1
	    char UnknownData1[0x1]; // 0x61
	    struct FString NodeComment; // 0x60 Size: 0x10
	    int ErrorType; // 0x70 Size: 0x4
	    char UnknownData2[0x4]; // 0x74
	    struct FString ErrorMsg; // 0x78 Size: 0x10
	    struct FGuid NodeGuid; // 0x88 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.EdGraphNode");
			return (class UClass*)ptr;
		};

};

class UEdGraphNode_Documentation : public UEdGraphNode
{
	public:
	    struct FString Link; // 0x98 Size: 0x10
	    struct FString Excerpt; // 0xa8 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.EdGraphNode_Documentation");
			return (class UClass*)ptr;
		};

};

class UEdGraphPin_Deprecated : public UObject
{
	public:
	    struct FString PinName; // 0x28 Size: 0x10
	    struct FString PinToolTip; // 0x38 Size: 0x10
	    char Direction; // 0x48 Size: 0x1
	    char UnknownData0[0x7]; // 0x49
	    struct FEdGraphPinType PinType; // 0x50 Size: 0x58
	    struct FString DefaultValue; // 0xa8 Size: 0x10
	    struct FString AutogeneratedDefaultValue; // 0xb8 Size: 0x10
	    class UObject* DefaultObject; // 0xc8 Size: 0x8
	    struct FText DefaultTextValue; // 0xd0 Size: 0x18
	    TArray<class UEdGraphPin_Deprecated*> LinkedTo; // 0xe8 Size: 0x10
	    TArray<class UEdGraphPin_Deprecated*> SubPins; // 0xf8 Size: 0x10
	    class UEdGraphPin_Deprecated* ParentPin; // 0x108 Size: 0x8
	    class UEdGraphPin_Deprecated* ReferencePassThroughConnection; // 0x110 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.EdGraphPin_Deprecated");
			return (class UClass*)ptr;
		};

};

class UEdGraphSchema : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.EdGraphSchema");
			return (class UClass*)ptr;
		};

};

class UEngineBaseTypes : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.EngineBaseTypes");
			return (class UClass*)ptr;
		};

};

class UEngineHandlerComponentFactory : public UHandlerComponentFactory
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.EngineHandlerComponentFactory");
			return (class UClass*)ptr;
		};

};

class UEngineMessage : public ULocalMessage
{
	public:
	    struct FString FailedPlaceMessage; // 0x28 Size: 0x10
	    struct FString MaxedOutMessage; // 0x38 Size: 0x10
	    struct FString EnteredMessage; // 0x48 Size: 0x10
	    struct FString LeftMessage; // 0x58 Size: 0x10
	    struct FString GlobalNameChange; // 0x68 Size: 0x10
	    struct FString SpecEnteredMessage; // 0x78 Size: 0x10
	    struct FString NewPlayerMessage; // 0x88 Size: 0x10
	    struct FString NewSpecMessage; // 0x98 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.EngineMessage");
			return (class UClass*)ptr;
		};

};

class UEngineTypes : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.EngineTypes");
			return (class UClass*)ptr;
		};

};

class AExponentialHeightFog : public AInfo
{
	public:
	    class UExponentialHeightFogComponent* Component; // 0x330 Size: 0x8
	    bool bEnabled; // 0x338 Size: 0x1
	    char UnknownData0[0x339]; // 0x339
	    void OnRep_bEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7ca1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ExponentialHeightFog");
			return (class UClass*)ptr;
		};

};

class UExponentialHeightFogComponent : public USceneComponent
{
	public:
	    float FogDensity; // 0x248 Size: 0x4
	    float FogHeightFalloff; // 0x24c Size: 0x4
	    struct FExponentialHeightFogData SecondFogData; // 0x250 Size: 0xc
	    struct FLinearColor FogInscatteringColor; // 0x25c Size: 0x10
	    char UnknownData0[0x4]; // 0x26c
	    class UTextureCube* InscatteringColorCubemap; // 0x270 Size: 0x8
	    float InscatteringColorCubemapAngle; // 0x278 Size: 0x4
	    struct FLinearColor InscatteringTextureTint; // 0x27c Size: 0x10
	    float FullyDirectionalInscatteringColorDistance; // 0x28c Size: 0x4
	    float NonDirectionalInscatteringColorDistance; // 0x290 Size: 0x4
	    float DirectionalInscatteringExponent; // 0x294 Size: 0x4
	    float DirectionalInscatteringStartDistance; // 0x298 Size: 0x4
	    struct FLinearColor DirectionalInscatteringColor; // 0x29c Size: 0x10
	    float FogMaxOpacity; // 0x2ac Size: 0x4
	    float StartDistance; // 0x2b0 Size: 0x4
	    float FogCutoffDistance; // 0x2b4 Size: 0x4
	    bool bEnableVolumetricFog; // 0x2b8 Size: 0x1
	    char UnknownData1[0x3]; // 0x2b9
	    float VolumetricFogScatteringDistribution; // 0x2bc Size: 0x4
	    struct FColor VolumetricFogAlbedo; // 0x2c0 Size: 0x4
	    struct FLinearColor VolumetricFogEmissive; // 0x2c4 Size: 0x10
	    float VolumetricFogExtinctionScale; // 0x2d4 Size: 0x4
	    float VolumetricFogDistance; // 0x2d8 Size: 0x4
	    float VolumetricFogStaticLightingScatteringIntensity; // 0x2dc Size: 0x4
	    bool bOverrideLightColorsWithFogInscatteringColors; // 0x2e0 Size: 0x1
	    char UnknownData2[0x2e1]; // 0x2e1
	    void SetVolumetricFogScatteringDistribution(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetVolumetricFogExtinctionScale(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetVolumetricFogEmissive(struct FLinearColor NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetVolumetricFogDistance(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetVolumetricFogAlbedo(struct FColor NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetVolumetricFog(bool bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetStartDistance(float Value); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetNonDirectionalInscatteringColorDistance(float Value); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetInscatteringTextureTint(struct FLinearColor Value); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetInscatteringColorCubemapAngle(float Value); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetInscatteringColorCubemap(class UTextureCube* Value); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void SetFullyDirectionalInscatteringColorDistance(float Value); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void SetFogMaxOpacity(float Value); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void SetFogInscatteringColor(struct FLinearColor Value); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void SetFogHeightFalloff(float Value); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void SetFogDensity(float Value); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void SetFogCutoffDistance(float Value); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void SetDirectionalInscatteringStartDistance(float Value); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void SetDirectionalInscatteringExponent(float Value); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void SetDirectionalInscatteringColor(struct FLinearColor Value); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x-7cf1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ExponentialHeightFogComponent");
			return (class UClass*)ptr;
		};

};

class UExporter : public UObject
{
	public:
	    class UObject* SupportedClass; // 0x28 Size: 0x8
	    class UObject* ExportRootScope; // 0x30 Size: 0x8
	    TArray<struct FString> FormatExtension; // 0x38 Size: 0x10
	    TArray<struct FString> FormatDescription; // 0x48 Size: 0x10
	    int PreferredFormatIndex; // 0x58 Size: 0x4
	    int TextIndent; // 0x5c Size: 0x4
	    bool bText; // 0x60 Size: 0x1
	    bool bSelectedOnly; // 0x60 Size: 0x1
	    bool bForceFileOperations; // 0x60 Size: 0x1
	    char UnknownData0[0x5]; // 0x63
	    class UAssetExportTask* ExportTask; // 0x68 Size: 0x8
	    char UnknownData1[0x70]; // 0x70
	    bool ScriptRunAssetExportTask(class UAssetExportTask* Task); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static bool RunAssetExportTasks(TArray<class UAssetExportTask*> ExportTasks); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static bool RunAssetExportTask(class UAssetExportTask* Task); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7f69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Exporter");
			return (class UClass*)ptr;
		};

};

class UFont : public UObject
{
	public:
	    char UnknownData0[0x8];
	    EFontCacheType FontCacheType; // 0x30 Size: 0x1
	    char UnknownData1[0x7]; // 0x31
	    TArray<struct FFontCharacter> Characters; // 0x38 Size: 0x10
	    TArray<class UTexture2D*> Textures; // 0x48 Size: 0x10
	    int IsRemapped; // 0x58 Size: 0x4
	    float EmScale; // 0x5c Size: 0x4
	    float Ascent; // 0x60 Size: 0x4
	    float Descent; // 0x64 Size: 0x4
	    float Leading; // 0x68 Size: 0x4
	    int Kerning; // 0x6c Size: 0x4
	    struct FFontImportOptionsData ImportOptions; // 0x70 Size: 0xb0
	    int NumCharacters; // 0x120 Size: 0x4
	    char UnknownData2[0x4]; // 0x124
	    TArray<int> MaxCharHeight; // 0x128 Size: 0x10
	    float ScalingFactor; // 0x138 Size: 0x4
	    int LegacyFontSize; // 0x13c Size: 0x4
	    FName LegacyFontName; // 0x140 Size: 0x8
	    struct FCompositeFont CompositeFont; // 0x148 Size: 0x38
	    char UnknownData3[0x50];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Font");
			return (class UClass*)ptr;
		};

};

class UFontFace : public UObject
{
	public:
	    char UnknownData0[0x8];
	    struct FString SourceFilename; // 0x30 Size: 0x10
	    EFontHinting Hinting; // 0x40 Size: 0x1
	    EFontLoadingPolicy LoadingPolicy; // 0x41 Size: 0x1
	    EFontLayoutMethod LayoutMethod; // 0x42 Size: 0x1
	    char UnknownData1[0x15];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.FontFace");
			return (class UClass*)ptr;
		};

};

class UFontImportOptions : public UObject
{
	public:
	    struct FFontImportOptionsData Data; // 0x28 Size: 0xb0

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.FontImportOptions");
			return (class UClass*)ptr;
		};

};

class UForceFeedbackAttenuation : public UObject
{
	public:
	    struct FForceFeedbackAttenuationSettings Attenuation; // 0x28 Size: 0xb0

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ForceFeedbackAttenuation");
			return (class UClass*)ptr;
		};

};

class UForceFeedbackComponent : public USceneComponent
{
	public:
	    class UForceFeedbackEffect* ForceFeedbackEffect; // 0x248 Size: 0x8
	    bool bAutoDestroy; // 0x250 Size: 0x1
	    bool bStopWhenOwnerDestroyed; // 0x250 Size: 0x1
	    bool bLooping; // 0x250 Size: 0x1
	    bool bIgnoreTimeDilation; // 0x250 Size: 0x1
	    bool bOverrideAttenuation; // 0x250 Size: 0x1
	    char UnknownData0[0x1]; // 0x255
	    float IntensityMultiplier; // 0x254 Size: 0x4
	    class UForceFeedbackAttenuation* AttenuationSettings; // 0x258 Size: 0x8
	    struct FForceFeedbackAttenuationSettings AttenuationOverrides; // 0x260 Size: 0xb0
	    MulticastDelegateProperty OnForceFeedbackFinished; // 0x310 Size: 0x10
	    char UnknownData1[0x320]; // 0x320
	    void Stop(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetIntensityMultiplier(float NewIntensityMultiplier); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetForceFeedbackEffect(class UForceFeedbackEffect* NewForceFeedbackEffect); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void Play(float StartTime); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool BP_GetAttenuationSettingsToApply(struct FForceFeedbackAttenuationSettings OutAttenuationSettings); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void AdjustAttenuation(struct FForceFeedbackAttenuationSettings InAttenuationSettings); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7cb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ForceFeedbackComponent");
			return (class UClass*)ptr;
		};

};

class UForceFeedbackEffect : public UObject
{
	public:
	    TArray<struct FForceFeedbackChannelDetails> ChannelDetails; // 0x28 Size: 0x10
	    float Duration; // 0x38 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ForceFeedbackEffect");
			return (class UClass*)ptr;
		};

};

class AGameNetworkManager : public AInfo
{
	public:
	    int AdjustedNetSpeed; // 0x330 Size: 0x4
	    float LastNetSpeedUpdateTime; // 0x334 Size: 0x4
	    int TotalNetBandwidth; // 0x338 Size: 0x4
	    int MinDynamicBandwidth; // 0x33c Size: 0x4
	    int MaxDynamicBandwidth; // 0x340 Size: 0x4
	    bool bIsStandbyCheckingEnabled; // 0x344 Size: 0x1
	    bool bHasStandbyCheatTriggered; // 0x344 Size: 0x1
	    char UnknownData0[0x2]; // 0x346
	    float StandbyRxCheatTime; // 0x348 Size: 0x4
	    float StandbyTxCheatTime; // 0x34c Size: 0x4
	    int BadPingThreshold; // 0x350 Size: 0x4
	    float PercentMissingForRxStandby; // 0x354 Size: 0x4
	    float PercentMissingForTxStandby; // 0x358 Size: 0x4
	    float PercentForBadPing; // 0x35c Size: 0x4
	    float JoinInProgressStandbyWaitTime; // 0x360 Size: 0x4
	    float MoveRepSize; // 0x364 Size: 0x4
	    float MAXPOSITIONERRORSQUARED; // 0x368 Size: 0x4
	    float MAXNEARZEROVELOCITYSQUARED; // 0x36c Size: 0x4
	    float CLIENTADJUSTUPDATECOST; // 0x370 Size: 0x4
	    float MAXCLIENTUPDATEINTERVAL; // 0x374 Size: 0x4
	    float MaxClientForcedUpdateDuration; // 0x378 Size: 0x4
	    float MaxMoveDeltaTime; // 0x37c Size: 0x4
	    float MaxClientSmoothingDeltaTime; // 0x380 Size: 0x4
	    float ClientNetSendMoveDeltaTime; // 0x384 Size: 0x4
	    float ClientNetSendMoveDeltaTimeThrottled; // 0x388 Size: 0x4
	    float ClientNetSendMoveDeltaTimeStationary; // 0x38c Size: 0x4
	    int ClientNetSendMoveThrottleAtNetSpeed; // 0x390 Size: 0x4
	    int ClientNetSendMoveThrottleOverPlayerCount; // 0x394 Size: 0x4
	    bool ClientAuthorativePosition; // 0x398 Size: 0x1
	    char UnknownData1[0x3]; // 0x399
	    float ClientErrorUpdateRateLimit; // 0x39c Size: 0x4
	    bool bMovementTimeDiscrepancyDetection; // 0x3a0 Size: 0x1
	    bool bMovementTimeDiscrepancyResolution; // 0x3a1 Size: 0x1
	    char UnknownData2[0x2]; // 0x3a2
	    float MovementTimeDiscrepancyMaxTimeMargin; // 0x3a4 Size: 0x4
	    float MovementTimeDiscrepancyMinTimeMargin; // 0x3a8 Size: 0x4
	    float MovementTimeDiscrepancyResolutionRate; // 0x3ac Size: 0x4
	    float MovementTimeDiscrepancyDriftAllowance; // 0x3b0 Size: 0x4
	    bool bMovementTimeDiscrepancyForceCorrectionsDuringResolution; // 0x3b4 Size: 0x1
	    bool bUseDistanceBasedRelevancy; // 0x3b5 Size: 0x1
	    char UnknownData3[0xa];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.GameNetworkManager");
			return (class UClass*)ptr;
		};

};

class UGameplayStatics : public UBlueprintFunctionLibrary
{
	public:
	    static void UnloadStreamLevel(class UObject* WorldContextObject, FName LevelName, struct FLatentActionInfo LatentInfo, bool bShouldBlockOnUnload); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static bool SuggestProjectileVelocity_CustomArc(class UObject* WorldContextObject, struct FVector OutLaunchVelocity, struct FVector StartPos, struct FVector EndPos, float OverrideGravityZ, float ArcParam); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static class UAudioComponent* SpawnSoundAttached(class USoundBase* Sound, class USceneComponent* AttachToComponent, FName AttachPointName, struct FVector Location, struct FRotator Rotation, char LocationType, bool bStopWhenAttachedToDestroyed, float VolumeMultiplier, float PitchMultiplier, float StartTime, class USoundAttenuation* AttenuationSettings, class USoundConcurrency* ConcurrencySettings, bool bAutoDestroy); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static class UAudioComponent* SpawnSoundAtLocation(class UObject* WorldContextObject, class USoundBase* Sound, struct FVector Location, struct FRotator Rotation, float VolumeMultiplier, float PitchMultiplier, float StartTime, class USoundAttenuation* AttenuationSettings, class USoundConcurrency* ConcurrencySettings, bool bAutoDestroy); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static class UAudioComponent* SpawnSound2D(class UObject* WorldContextObject, class USoundBase* Sound, float VolumeMultiplier, float PitchMultiplier, float StartTime, class USoundConcurrency* ConcurrencySettings, bool bPersistAcrossLevelTransition, bool bAutoDestroy); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static class UObject* SpawnObject(class UObject* ObjectClass, class UObject* Outer); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static class UForceFeedbackComponent* SpawnForceFeedbackAttached(class UForceFeedbackEffect* ForceFeedbackEffect, class USceneComponent* AttachToComponent, FName AttachPointName, struct FVector Location, struct FRotator Rotation, char LocationType, bool bStopWhenAttachedToDestroyed, bool bLooping, float IntensityMultiplier, float StartTime, class UForceFeedbackAttenuation* AttenuationSettings, bool bAutoDestroy); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static class UForceFeedbackComponent* SpawnForceFeedbackAtLocation(class UObject* WorldContextObject, class UForceFeedbackEffect* ForceFeedbackEffect, struct FVector Location, struct FRotator Rotation, bool bLooping, float IntensityMultiplier, float StartTime, class UForceFeedbackAttenuation* AttenuationSettings, bool bAutoDestroy); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static class UParticleSystemComponent* SpawnEmitterAttached(class UParticleSystem* EmitterTemplate, class USceneComponent* AttachToComponent, FName AttachPointName, struct FVector Location, struct FRotator Rotation, struct FVector Scale, char LocationType, bool bAutoDestroy, EPSCPoolMethod PoolingMethod); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static class UParticleSystemComponent* SpawnEmitterAtLocation(class UObject* WorldContextObject, class UParticleSystem* EmitterTemplate, struct FVector Location, struct FRotator Rotation, struct FVector Scale, bool bAutoDestroy, EPSCPoolMethod PoolingMethod); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static class UAudioComponent* SpawnDialogueAttached(class UDialogueWave* Dialogue, struct FDialogueContext Context, class USceneComponent* AttachToComponent, FName AttachPointName, struct FVector Location, struct FRotator Rotation, char LocationType, bool bStopWhenAttachedToDestroyed, float VolumeMultiplier, float PitchMultiplier, float StartTime, class USoundAttenuation* AttenuationSettings, bool bAutoDestroy); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static class UAudioComponent* SpawnDialogueAtLocation(class UObject* WorldContextObject, class UDialogueWave* Dialogue, struct FDialogueContext Context, struct FVector Location, struct FRotator Rotation, float VolumeMultiplier, float PitchMultiplier, float StartTime, class USoundAttenuation* AttenuationSettings, bool bAutoDestroy); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    static class UAudioComponent* SpawnDialogue2D(class UObject* WorldContextObject, class UDialogueWave* Dialogue, struct FDialogueContext Context, float VolumeMultiplier, float PitchMultiplier, float StartTime, bool bAutoDestroy); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    static class UDecalComponent* SpawnDecalAttached(class UMaterialInterface* DecalMaterial, struct FVector DecalSize, class USceneComponent* AttachToComponent, FName AttachPointName, struct FVector Location, struct FRotator Rotation, char LocationType, float LifeSpan); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    static class UDecalComponent* SpawnDecalAtLocation(class UObject* WorldContextObject, class UMaterialInterface* DecalMaterial, struct FVector DecalSize, struct FVector Location, struct FRotator Rotation, float LifeSpan); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    static void SetWorldOriginLocation(class UObject* WorldContextObject, struct FIntVector NewLocation); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    static void SetSubtitlesEnabled(bool bEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    static void SetSoundMixClassOverride(class UObject* WorldContextObject, class USoundMix* InSoundMixModifier, class USoundClass* InSoundClass, float Volume, float Pitch, float FadeInTime, bool bApplyToChildren); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    static void SetPlayerControllerID(class APlayerController* Player, int ControllerId); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    static void SetGlobalTimeDilation(class UObject* WorldContextObject, float TimeDilation); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    static void SetGlobalPitchModulation(class UObject* WorldContextObject, float PitchModulation, float TimeSec); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    static void SetGlobalListenerFocusParameters(class UObject* WorldContextObject, float FocusAzimuthScale, float NonFocusAzimuthScale, float FocusDistanceScale, float NonFocusDistanceScale, float FocusVolumeScale, float NonFocusVolumeScale, float FocusPriorityScale, float NonFocusPriorityScale); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    static bool SetGamePaused(class UObject* WorldContextObject, bool bPaused); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    static void SetEnableWorldRendering(class UObject* WorldContextObject, bool bEnable); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    static void SetBaseSoundMix(class UObject* WorldContextObject, class USoundMix* InSoundMix); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    static bool SaveGameToSlot(class USaveGame* SaveGameObject, struct FString SlotName, int UserIndex); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    static void RemovePlayer(class APlayerController* Player, bool bDestroyPawn); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    static struct FVector RebaseZeroOriginOntoLocal(class UObject* WorldContextObject, struct FVector WorldLocation); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    static struct FVector RebaseLocalOriginOntoZero(class UObject* WorldContextObject, struct FVector WorldLocation); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    static void PushSoundMixModifier(class UObject* WorldContextObject, class USoundMix* InSoundMixModifier); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    static bool ProjectWorldToScreen(class APlayerController* Player, struct FVector WorldPosition, struct FVector2D ScreenPosition, bool bPlayerViewportRelative); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    static void PopSoundMixModifier(class UObject* WorldContextObject, class USoundMix* InSoundMixModifier); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    static void PlayWorldCameraShake(class UObject* WorldContextObject, class UCameraShake* Shake, struct FVector Epicenter, float InnerRadius, float OuterRadius, float Falloff, bool bOrientShakeTowardsEpicenter); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    static void PlaySoundAtLocation(class UObject* WorldContextObject, class USoundBase* Sound, struct FVector Location, struct FRotator Rotation, float VolumeMultiplier, float PitchMultiplier, float StartTime, class USoundAttenuation* AttenuationSettings, class USoundConcurrency* ConcurrencySettings, class AActor* OwningActor); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    static void PlaySound2D(class UObject* WorldContextObject, class USoundBase* Sound, float VolumeMultiplier, float PitchMultiplier, float StartTime, class USoundConcurrency* ConcurrencySettings, class AActor* OwningActor); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    static void PlayDialogueAtLocation(class UObject* WorldContextObject, class UDialogueWave* Dialogue, struct FDialogueContext Context, struct FVector Location, struct FRotator Rotation, float VolumeMultiplier, float PitchMultiplier, float StartTime, class USoundAttenuation* AttenuationSettings); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    static void PlayDialogue2D(class UObject* WorldContextObject, class UDialogueWave* Dialogue, struct FDialogueContext Context, float VolumeMultiplier, float PitchMultiplier, float StartTime); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    static struct FString ParseOption(struct FString Options, struct FString Key); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    static void OpenLevel(class UObject* WorldContextObject, FName LevelName, bool bAbsolute, struct FString Options); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    static struct FHitResult MakeHitResult(bool bBlockingHit, bool bInitialOverlap, float Time, float Distance, struct FVector Location, struct FVector ImpactPoint, struct FVector Normal, struct FVector ImpactNormal, class UPhysicalMaterial* PhysMat, class AActor* HitActor, class UPrimitiveComponent* HitComponent, FName HitBoneName, int HitItem, int FaceIndex, struct FVector TraceStart, struct FVector TraceEnd); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    static void LoadStreamLevel(class UObject* WorldContextObject, FName LevelName, bool bMakeVisibleAfterLoad, bool bShouldBlockOnLoad, struct FLatentActionInfo LatentInfo); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    static class USaveGame* LoadGameFromSlot(struct FString SlotName, int UserIndex); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    static bool IsGamePaused(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    static bool HasOption(struct FString Options, struct FString InKey); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    static bool HasLaunchOption(struct FString OptionToCheck); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    static int GrassOverlappingSphereCount(class UObject* WorldContextObject, class UStaticMesh* StaticMesh, struct FVector CenterPosition, float Radius); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    static struct FIntVector GetWorldOriginLocation(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    static float GetWorldDeltaSeconds(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    static float GetUnpausedTimeSeconds(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    static float GetTimeSeconds(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    static char GetSurfaceType(struct FHitResult Hit); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    static class ULevelStreaming* GetStreamingLevel(class UObject* WorldContextObject, FName PackageName); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    static float GetRealTimeSeconds(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    static class APawn* GetPlayerPawn(class UObject* WorldContextObject, int PlayerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    static int GetPlayerControllerID(class APlayerController* Player); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    static class APlayerController* GetPlayerController(class UObject* WorldContextObject, int PlayerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    static class ACharacter* GetPlayerCharacter(class UObject* WorldContextObject, int PlayerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    static class APlayerCameraManager* GetPlayerCameraManager(class UObject* WorldContextObject, int PlayerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    static struct FString GetPlatformName(); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    static class UObject* GetObjectClass(class UObject* Object); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    static void GetKeyValue(struct FString Pair, struct FString Key, struct FString Value); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    static int GetIntOption(struct FString Options, struct FString Key, int DefaultValue); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    static float GetGlobalTimeDilation(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x7fe1]; // 0x7fe1
	    static class AGameStateBase* GetGameState(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData63[0x7fe1]; // 0x7fe1
	    static class AGameModeBase* GetGameMode(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData64[0x7fe1]; // 0x7fe1
	    static class UGameInstance* GetGameInstance(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData65[0x7fe1]; // 0x7fe1
	    static bool GetEnableWorldRendering(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData66[0x7fe1]; // 0x7fe1
	    static class UReverbEffect* GetCurrentReverbEffect(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData67[0x7fe1]; // 0x7fe1
	    static struct FString GetCurrentLevelName(class UObject* WorldContextObject, bool bRemovePrefixString); // 0x0 Size: 0x7fe1
	    char UnknownData68[0x7fe1]; // 0x7fe1
	    static float GetAudioTimeSeconds(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData69[0x7fe1]; // 0x7fe1
	    static void GetAllActorsWithTag(class UObject* WorldContextObject, FName Tag, TArray<class AActor*> OutActors); // 0x0 Size: 0x7fe1
	    char UnknownData70[0x7fe1]; // 0x7fe1
	    static void GetAllActorsWithInterface(class UObject* WorldContextObject, class UInterface* Interface, TArray<class AActor*> OutActors); // 0x0 Size: 0x7fe1
	    char UnknownData71[0x7fe1]; // 0x7fe1
	    static void GetAllActorsOfClass(class UObject* WorldContextObject, class AActor* ActorClass, TArray<class AActor*> OutActors); // 0x0 Size: 0x7fe1
	    char UnknownData72[0x7fe1]; // 0x7fe1
	    static void GetActorArrayBounds(TArray<class AActor*> Actors, bool bOnlyCollidingComponents, struct FVector Center, struct FVector BoxExtent); // 0x0 Size: 0x7fe1
	    char UnknownData73[0x7fe1]; // 0x7fe1
	    static struct FVector GetActorArrayAverageLocation(TArray<class AActor*> Actors); // 0x0 Size: 0x7fe1
	    char UnknownData74[0x7fe1]; // 0x7fe1
	    static void GetAccurateRealTime(class UObject* WorldContextObject, int Seconds, float PartialSeconds); // 0x0 Size: 0x7fe1
	    char UnknownData75[0x7fe1]; // 0x7fe1
	    static void FlushLevelStreaming(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData76[0x7fe1]; // 0x7fe1
	    static class AActor* FinishSpawningActor(class AActor* Actor, struct FTransform SpawnTransform); // 0x0 Size: 0x7fe1
	    char UnknownData77[0x7fe1]; // 0x7fe1
	    static bool FindCollisionUV(struct FHitResult Hit, int UVChannel, struct FVector2D UV); // 0x0 Size: 0x7fe1
	    char UnknownData78[0x7fe1]; // 0x7fe1
	    static void EnableLiveStreaming(bool Enable); // 0x0 Size: 0x7fe1
	    char UnknownData79[0x7fe1]; // 0x7fe1
	    static bool DoesSaveGameExist(struct FString SlotName, int UserIndex); // 0x0 Size: 0x7fe1
	    char UnknownData80[0x7fe1]; // 0x7fe1
	    static bool DeprojectScreenToWorld(class APlayerController* Player, struct FVector2D ScreenPosition, struct FVector WorldPosition, struct FVector WorldDirection); // 0x0 Size: 0x7fe1
	    char UnknownData81[0x7fe1]; // 0x7fe1
	    static bool DeleteGameInSlot(struct FString SlotName, int UserIndex); // 0x0 Size: 0x7fe1
	    char UnknownData82[0x7fe1]; // 0x7fe1
	    static void DeactivateReverbEffect(class UObject* WorldContextObject, FName TagName); // 0x0 Size: 0x7fe1
	    char UnknownData83[0x7fe1]; // 0x7fe1
	    static class UAudioComponent* CreateSound2D(class UObject* WorldContextObject, class USoundBase* Sound, float VolumeMultiplier, float PitchMultiplier, float StartTime, class USoundConcurrency* ConcurrencySettings, bool bPersistAcrossLevelTransition, bool bAutoDestroy); // 0x0 Size: 0x7fe1
	    char UnknownData84[0x7fe1]; // 0x7fe1
	    static class USaveGame* CreateSaveGameObjectFromBlueprint(class UBlueprint* SaveGameBlueprint); // 0x0 Size: 0x7fe1
	    char UnknownData85[0x7fe1]; // 0x7fe1
	    static class USaveGame* CreateSaveGameObject(class USaveGame* SaveGameClass); // 0x0 Size: 0x7fe1
	    char UnknownData86[0x7fe1]; // 0x7fe1
	    static class APlayerController* CreatePlayer(class UObject* WorldContextObject, int ControllerId, bool bSpawnPawn); // 0x0 Size: 0x7fe1
	    char UnknownData87[0x7fe1]; // 0x7fe1
	    static void ClearSoundMixModifiers(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData88[0x7fe1]; // 0x7fe1
	    static void ClearSoundMixClassOverride(class UObject* WorldContextObject, class USoundMix* InSoundMixModifier, class USoundClass* InSoundClass, float FadeOutTime); // 0x0 Size: 0x7fe1
	    char UnknownData89[0x7fe1]; // 0x7fe1
	    static void CancelAsyncLoading(); // 0x0 Size: 0x7fe1
	    char UnknownData90[0x7fe1]; // 0x7fe1
	    static void BreakHitResult(struct FHitResult Hit, bool bBlockingHit, bool bInitialOverlap, float Time, float Distance, struct FVector Location, struct FVector ImpactPoint, struct FVector Normal, struct FVector ImpactNormal, class UPhysicalMaterial* PhysMat, class AActor* HitActor, class UPrimitiveComponent* HitComponent, FName HitBoneName, int HitItem, int FaceIndex, struct FVector TraceStart, struct FVector TraceEnd); // 0x0 Size: 0x7fe1
	    char UnknownData91[0x7fe1]; // 0x7fe1
	    static bool BlueprintSuggestProjectileVelocity(class UObject* WorldContextObject, struct FVector TossVelocity, struct FVector StartLocation, struct FVector EndLocation, float LaunchSpeed, float OverrideGravityZ, char TraceOption, float CollisionRadius, bool bFavorHighArc, bool bDrawDebug); // 0x0 Size: 0x7fe1
	    char UnknownData92[0x7fe1]; // 0x7fe1
	    static bool Blueprint_PredictProjectilePath_ByTraceChannel(class UObject* WorldContextObject, struct FHitResult OutHit, TArray<struct FVector> OutPathPositions, struct FVector OutLastTraceDestination, struct FVector StartPos, struct FVector LaunchVelocity, bool bTracePath, float ProjectileRadius, char TraceChannel, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, float DrawDebugTime, float SimFrequency, float MaxSimTime, float OverrideGravityZ); // 0x0 Size: 0x7fe1
	    char UnknownData93[0x7fe1]; // 0x7fe1
	    static bool Blueprint_PredictProjectilePath_ByObjectType(class UObject* WorldContextObject, struct FHitResult OutHit, TArray<struct FVector> OutPathPositions, struct FVector OutLastTraceDestination, struct FVector StartPos, struct FVector LaunchVelocity, bool bTracePath, float ProjectileRadius, TArray<char> ObjectTypes, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, float DrawDebugTime, float SimFrequency, float MaxSimTime, float OverrideGravityZ); // 0x0 Size: 0x7fe1
	    char UnknownData94[0x7fe1]; // 0x7fe1
	    static bool Blueprint_PredictProjectilePath_Advanced(class UObject* WorldContextObject, struct FPredictProjectilePathParams PredictParams, struct FPredictProjectilePathResult PredictResult); // 0x0 Size: 0x7fe1
	    char UnknownData95[0x7fe1]; // 0x7fe1
	    static class AActor* BeginSpawningActorFromClass(class UObject* WorldContextObject, class AActor* ActorClass, struct FTransform SpawnTransform, bool bNoCollisionFail, class AActor* Owner); // 0x0 Size: 0x7fe1
	    char UnknownData96[0x7fe1]; // 0x7fe1
	    static class AActor* BeginSpawningActorFromBlueprint(class UObject* WorldContextObject, class UBlueprint* Blueprint, struct FTransform SpawnTransform, bool bNoCollisionFail); // 0x0 Size: 0x7fe1
	    char UnknownData97[0x7fe1]; // 0x7fe1
	    static class AActor* BeginDeferredActorSpawnFromClass(class UObject* WorldContextObject, class AActor* ActorClass, struct FTransform SpawnTransform, ESpawnActorCollisionHandlingMethod CollisionHandlingOverride, class AActor* Owner); // 0x0 Size: 0x7fe1
	    char UnknownData98[0x7fe1]; // 0x7fe1
	    static bool AreSubtitlesEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData99[0x7fe1]; // 0x7fe1
	    static bool AreAnyListenersWithinRange(class UObject* WorldContextObject, struct FVector Location, float MaximumRange); // 0x0 Size: 0x7fe1
	    char UnknownData100[0x7fe1]; // 0x7fe1
	    static bool ApplyRadialDamageWithFalloff(class UObject* WorldContextObject, float BaseDamage, float MinimumDamage, struct FVector Origin, float DamageInnerRadius, float DamageOuterRadius, float DamageFalloff, class UDamageType* DamageTypeClass, TArray<class AActor*> IgnoreActors, class AActor* DamageCauser, class AController* InstigatedByController, char DamagePreventionChannel); // 0x0 Size: 0x7fe1
	    char UnknownData101[0x7fe1]; // 0x7fe1
	    static bool ApplyRadialDamage(class UObject* WorldContextObject, float BaseDamage, struct FVector Origin, float DamageRadius, class UDamageType* DamageTypeClass, TArray<class AActor*> IgnoreActors, class AActor* DamageCauser, class AController* InstigatedByController, bool bDoFullDamage, char DamagePreventionChannel); // 0x0 Size: 0x7fe1
	    char UnknownData102[0x7fe1]; // 0x7fe1
	    static float ApplyPointDamage(class AActor* DamagedActor, float BaseDamage, struct FVector HitFromDirection, struct FHitResult HitInfo, class AController* EventInstigator, class AActor* DamageCauser, class UDamageType* DamageTypeClass); // 0x0 Size: 0x7fe1
	    char UnknownData103[0x7fe1]; // 0x7fe1
	    static float ApplyDamage(class AActor* DamagedActor, float BaseDamage, class AController* EventInstigator, class AActor* DamageCauser, class UDamageType* DamageTypeClass); // 0x0 Size: 0x7fe1
	    char UnknownData104[0x7fe1]; // 0x7fe1
	    static void ActivateReverbEffect(class UObject* WorldContextObject, class UReverbEffect* ReverbEffect, FName TagName, float Priority, float Volume, float FadeTime); // 0x0 Size: 0x7fe1
	    char UnknownData105[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.GameplayStatics");
			return (class UClass*)ptr;
		};

};

class ASpotLight : public ALight
{
	public:
	    class USpotLightComponent* SpotLightComponent; // 0x340 Size: 0x8
	    char UnknownData0[0x348]; // 0x348
	    void SetOuterConeAngle(float NewOuterConeAngle); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetInnerConeAngle(float NewInnerConeAngle); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7c99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SpotLight");
			return (class UClass*)ptr;
		};

};

class AGeneratedMeshAreaLight : public ASpotLight
{
	public:
	    char UnknownData0[0x348];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.GeneratedMeshAreaLight");
			return (class UClass*)ptr;
		};

};

class UHapticFeedbackEffect_Base : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.HapticFeedbackEffect_Base");
			return (class UClass*)ptr;
		};

};

class UHapticFeedbackEffect_Buffer : public UHapticFeedbackEffect_Base
{
	public:
	    TArray<char> Amplitudes; // 0x28 Size: 0x10
	    int SampleRate; // 0x38 Size: 0x4
	    char UnknownData0[0x2c];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.HapticFeedbackEffect_Buffer");
			return (class UClass*)ptr;
		};

};

class UHapticFeedbackEffect_Curve : public UHapticFeedbackEffect_Base
{
	public:
	    struct FHapticFeedbackDetails_Curve HapticDetails; // 0x28 Size: 0x110

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.HapticFeedbackEffect_Curve");
			return (class UClass*)ptr;
		};

};

class UHapticFeedbackEffect_SoundWave : public UHapticFeedbackEffect_Base
{
	public:
	    class USoundWave* SoundWave; // 0x28 Size: 0x8
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.HapticFeedbackEffect_SoundWave");
			return (class UClass*)ptr;
		};

};

class UHealthSnapshotBlueprintLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void StopPerformanceSnapshots(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void StartPerformanceSnapshots(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static void LogPerformanceSnapshot(struct FString SnapshotTitle, bool bResetStats); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.HealthSnapshotBlueprintLibrary");
			return (class UClass*)ptr;
		};

};

class UHLODProxy : public UObject
{
	public:
	    TArray<struct FHLODProxyMesh> ProxyMeshes; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.HLODProxy");
			return (class UClass*)ptr;
		};

};

class UAmbisonicsSubmixSettingsBase : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.AmbisonicsSubmixSettingsBase");
			return (class UClass*)ptr;
		};

};

class USpatializationPluginSourceSettingsBase : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SpatializationPluginSourceSettingsBase");
			return (class UClass*)ptr;
		};

};

class UOcclusionPluginSourceSettingsBase : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.OcclusionPluginSourceSettingsBase");
			return (class UClass*)ptr;
		};

};

class UReverbPluginSourceSettingsBase : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ReverbPluginSourceSettingsBase");
			return (class UClass*)ptr;
		};

};

class UImportanceSamplingLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static float RandomSobolFloat(int Index, int Dimension, float Seed); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static struct FVector RandomSobolCell3D(int Index, int NumCells, struct FVector Cell, struct FVector Seed); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static struct FVector2D RandomSobolCell2D(int Index, int NumCells, struct FVector2D Cell, struct FVector2D Seed); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static float NextSobolFloat(int Index, int Dimension, float PreviousValue); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static struct FVector NextSobolCell3D(int Index, int NumCells, struct FVector PreviousValue); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static struct FVector2D NextSobolCell2D(int Index, int NumCells, struct FVector2D PreviousValue); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static struct FImportanceTexture MakeImportanceTexture(class UTexture2D* Texture, char WeightingFunc); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static void ImportanceSample(struct FImportanceTexture Texture, struct FVector2D Rand, int Samples, float Intensity, struct FVector2D SamplePosition, struct FLinearColor SampleColor, float SampleIntensity, float SampleSize); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static void BreakImportanceTexture(struct FImportanceTexture ImportanceTexture, class UTexture2D* Texture, char WeightingFunc); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ImportanceSamplingLibrary");
			return (class UClass*)ptr;
		};

};

class UImportantToggleSettingInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ImportantToggleSettingInterface");
			return (class UClass*)ptr;
		};

};

class UInGameAdManager : public UPlatformInterfaceBase
{
	public:
	    bool bShouldPauseWhileAdOpen; // 0x38 Size: 0x1
	    char UnknownData0[0x7]; // 0x39
	    TArray<__int64/*DelegateProperty*/> ClickedBannerDelegates; // 0x40 Size: 0x10
	    TArray<__int64/*DelegateProperty*/> ClosedAdDelegates; // 0x50 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InGameAdManager");
			return (class UClass*)ptr;
		};

};

class UInheritableComponentHandler : public UObject
{
	public:
	    TArray<struct FComponentOverrideRecord> Records; // 0x28 Size: 0x10
	    TArray<class UActorComponent*> UnnecessaryComponents; // 0x38 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InheritableComponentHandler");
			return (class UClass*)ptr;
		};

};

class UInputDelegateBinding : public UDynamicBlueprintBinding
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InputDelegateBinding");
			return (class UClass*)ptr;
		};

};

class UInputActionDelegateBinding : public UInputDelegateBinding
{
	public:
	    TArray<struct FBlueprintInputActionDelegateBinding> InputActionDelegateBindings; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InputActionDelegateBinding");
			return (class UClass*)ptr;
		};

};

class UInputAxisDelegateBinding : public UInputDelegateBinding
{
	public:
	    TArray<struct FBlueprintInputAxisDelegateBinding> InputAxisDelegateBindings; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InputAxisDelegateBinding");
			return (class UClass*)ptr;
		};

};

class UInputAxisKeyDelegateBinding : public UInputDelegateBinding
{
	public:
	    TArray<struct FBlueprintInputAxisKeyDelegateBinding> InputAxisKeyDelegateBindings; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InputAxisKeyDelegateBinding");
			return (class UClass*)ptr;
		};

};

class UInputComponent : public UActorComponent
{
	public:
	    char UnknownData0[0x70];
	    TArray<struct FCachedKeyToActionInfo> CachedKeyToActionInfo; // 0x168 Size: 0x10
	    char UnknownData1[0x178]; // 0x178
	    bool WasControllerKeyJustReleased(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool WasControllerKeyJustPressed(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool IsControllerKeyDown(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void GetTouchState(int FingerIndex, float LocationX, float LocationY, bool bIsCurrentlyPressed); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    struct FVector GetControllerVectorKeyState(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void GetControllerMouseDelta(float DeltaX, float DeltaY); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    float GetControllerKeyTimeDown(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void GetControllerAnalogStickState(char WhichStick, float StickX, float StickY); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    float GetControllerAnalogKeyState(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7e61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InputComponent");
			return (class UClass*)ptr;
		};

};

class UInputKeyDelegateBinding : public UInputDelegateBinding
{
	public:
	    TArray<struct FBlueprintInputKeyDelegateBinding> InputKeyDelegateBindings; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InputKeyDelegateBinding");
			return (class UClass*)ptr;
		};

};

class UInputSettings : public UObject
{
	public:
	    TArray<struct FInputAxisConfigEntry> AxisConfig; // 0x28 Size: 0x10
	    bool bAltEnterTogglesFullscreen; // 0x38 Size: 0x1
	    bool bF11TogglesFullscreen; // 0x38 Size: 0x1
	    bool bUseMouseForTouch; // 0x38 Size: 0x1
	    bool bEnableMouseSmoothing; // 0x38 Size: 0x1
	    bool bEnableFOVScaling; // 0x38 Size: 0x1
	    bool bCaptureMouseOnLaunch; // 0x38 Size: 0x1
	    bool bDefaultViewportMouseLock; // 0x38 Size: 0x1
	    bool bAlwaysShowTouchInterface; // 0x38 Size: 0x1
	    bool bShowConsoleOnFourFingerTap; // 0x39 Size: 0x1
	    bool bEnableGestureRecognizer; // 0x39 Size: 0x1
	    bool bUseAutocorrect; // 0x3a Size: 0x1
	    char UnknownData0[0x3]; // 0x43
	    TArray<struct FString> ExcludedAutocorrectOS; // 0x40 Size: 0x10
	    TArray<struct FString> ExcludedAutocorrectCultures; // 0x50 Size: 0x10
	    TArray<struct FString> ExcludedAutocorrectDeviceModels; // 0x60 Size: 0x10
	    EMouseCaptureMode DefaultViewportMouseCaptureMode; // 0x70 Size: 0x1
	    EMouseLockMode DefaultViewportMouseLockMode; // 0x71 Size: 0x1
	    char UnknownData1[0x2]; // 0x72
	    float FOVScale; // 0x74 Size: 0x4
	    float DoubleClickTime; // 0x78 Size: 0x4
	    char UnknownData2[0x4]; // 0x7c
	    TArray<struct FInputActionKeyMapping> ActionMappings; // 0x80 Size: 0x10
	    TArray<struct FInputAxisKeyMapping> AxisMappings; // 0x90 Size: 0x10
	    struct FSoftObjectPath DefaultTouchInterface; // 0xa0 Size: 0x18
	    struct FKey ConsoleKey; // 0xb8 Size: 0x18
	    TArray<struct FKey> ConsoleKeys; // 0xd0 Size: 0x10
	    char UnknownData3[0xe0]; // 0xe0
	    void SaveKeyMappings(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void RemoveAxisMapping(struct FInputAxisKeyMapping KeyMapping, bool bForceRebuildKeymaps); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void RemoveActionMapping(struct FInputActionKeyMapping KeyMapping, bool bForceRebuildKeymaps); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static class UInputSettings* GetInputSettings(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void GetAxisNames(TArray<FName> AxisNames); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void GetAxisMappingByName(FName InAxisName, TArray<struct FInputAxisKeyMapping> OutMappings); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void GetActionNames(TArray<FName> ActionNames); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void GetActionMappingByName(FName InActionName, TArray<struct FInputActionKeyMapping> OutMappings); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void ForceRebuildKeymaps(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void AddAxisMapping(struct FInputAxisKeyMapping KeyMapping, bool bForceRebuildKeymaps); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void AddActionMapping(struct FInputActionKeyMapping KeyMapping, bool bForceRebuildKeymaps); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x-7f01];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InputSettings");
			return (class UClass*)ptr;
		};

};

class UInputTouchDelegateBinding : public UInputDelegateBinding
{
	public:
	    TArray<struct FBlueprintInputTouchDelegateBinding> InputTouchDelegateBindings; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InputTouchDelegateBinding");
			return (class UClass*)ptr;
		};

};

class UInputVectorAxisDelegateBinding : public UInputAxisKeyDelegateBinding
{
	public:
	    char UnknownData0[0x38];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InputVectorAxisDelegateBinding");
			return (class UClass*)ptr;
		};

};

class UInterface_AssetUserData : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Interface_AssetUserData");
			return (class UClass*)ptr;
		};

};

class UInterface_CollisionDataProvider : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Interface_CollisionDataProvider");
			return (class UClass*)ptr;
		};

};

class UInterface_PostProcessVolume : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Interface_PostProcessVolume");
			return (class UClass*)ptr;
		};

};

class UInterface_PreviewMeshProvider : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Interface_PreviewMeshProvider");
			return (class UClass*)ptr;
		};

};

class UInterpCurveEdSetup : public UObject
{
	public:
	    TArray<struct FCurveEdTab> Tabs; // 0x28 Size: 0x10
	    int ActiveTab; // 0x38 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpCurveEdSetup");
			return (class UClass*)ptr;
		};

};

class UInterpData : public UObject
{
	public:
	    float InterpLength; // 0x28 Size: 0x4
	    float PathBuildTime; // 0x2c Size: 0x4
	    TArray<class UInterpGroup*> InterpGroups; // 0x30 Size: 0x10
	    class UInterpCurveEdSetup* CurveEdSetup; // 0x40 Size: 0x8
	    float EdSectionStart; // 0x48 Size: 0x4
	    float EdSectionEnd; // 0x4c Size: 0x4
	    bool bShouldBakeAndPrune; // 0x50 Size: 0x1
	    char UnknownData0[0x7]; // 0x51
	    class UInterpGroupDirector* CachedDirectorGroup; // 0x58 Size: 0x8
	    TArray<FName> AllEventNames; // 0x60 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpData");
			return (class UClass*)ptr;
		};

};

class UInterpFilter : public UObject
{
	public:
	    struct FString Caption; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpFilter");
			return (class UClass*)ptr;
		};

};

class UInterpFilter_Classes : public UInterpFilter
{
	public:
	    char UnknownData0[0x38];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpFilter_Classes");
			return (class UClass*)ptr;
		};

};

class UInterpFilter_Custom : public UInterpFilter
{
	public:
	    char UnknownData0[0x38];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpFilter_Custom");
			return (class UClass*)ptr;
		};

};

class UInterpGroup : public UObject
{
	public:
	    char UnknownData0[0x8];
	    TArray<class UInterpTrack*> InterpTracks; // 0x30 Size: 0x10
	    FName GroupName; // 0x40 Size: 0x8
	    struct FColor GroupColor; // 0x48 Size: 0x4
	    bool bCollapsed; // 0x4c Size: 0x1
	    bool bVisible; // 0x4c Size: 0x1
	    bool bIsFolder; // 0x4c Size: 0x1
	    bool bIsParented; // 0x4c Size: 0x1
	    bool bIsSelected; // 0x4c Size: 0x1
	    char UnknownData1[0x-1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpGroup");
			return (class UClass*)ptr;
		};

};

class UInterpGroupCamera : public UInterpGroup
{
	public:
	    class UCameraAnim* CameraAnimInst; // 0x50 Size: 0x8
	    float CompressTolerance; // 0x58 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpGroupCamera");
			return (class UClass*)ptr;
		};

};

class UInterpGroupDirector : public UInterpGroup
{
	public:
	    char UnknownData0[0x50];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpGroupDirector");
			return (class UClass*)ptr;
		};

};

class UInterpGroupInst : public UObject
{
	public:
	    class UInterpGroup* Group; // 0x28 Size: 0x8
	    class AActor* GroupActor; // 0x30 Size: 0x8
	    TArray<class UInterpTrackInst*> TrackInst; // 0x38 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpGroupInst");
			return (class UClass*)ptr;
		};

};

class UInterpGroupInstCamera : public UInterpGroupInst
{
	public:
	    char UnknownData0[0x48];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpGroupInstCamera");
			return (class UClass*)ptr;
		};

};

class UInterpGroupInstDirector : public UInterpGroupInst
{
	public:
	    char UnknownData0[0x48];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpGroupInstDirector");
			return (class UClass*)ptr;
		};

};

class UInterpToMovementComponent : public UMovementComponent
{
	public:
	    float Duration; // 0x138 Size: 0x4
	    bool bPauseOnImpact; // 0x13c Size: 0x1
	    char UnknownData0[0x3]; // 0x13d
	    EInterpToBehaviourType BehaviourType; // 0x140 Size: 0x1
	    bool bForceSubStepping; // 0x144 Size: 0x1
	    char UnknownData1[0x6]; // 0x142
	    MulticastDelegateProperty OnInterpToReverse; // 0x148 Size: 0x10
	    MulticastDelegateProperty OnInterpToStop; // 0x158 Size: 0x10
	    MulticastDelegateProperty OnWaitBeginDelegate; // 0x168 Size: 0x10
	    MulticastDelegateProperty OnWaitEndDelegate; // 0x178 Size: 0x10
	    MulticastDelegateProperty OnResetDelegate; // 0x188 Size: 0x10
	    float MaxSimulationTimeStep; // 0x198 Size: 0x4
	    int MaxSimulationIterations; // 0x19c Size: 0x4
	    TArray<struct FInterpControlPoint> ControlPoints; // 0x1a0 Size: 0x10
	    char UnknownData2[0x1b0]; // 0x1b0
	    void StopSimulating(struct FHitResult HitResult); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void RestartMovement(float InitialDirection); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnInterpToWaitEndDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnInterpToWaitBeginDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnInterpToStopDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnInterpToReverseDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnInterpToResetDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void FinaliseControlPoints(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x-7e09];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpToMovementComponent");
			return (class UClass*)ptr;
		};

};

class UInterpTrack : public UObject
{
	public:
	    char UnknownData0[0x10];
	    TArray<class UInterpTrack*> SubTracks; // 0x38 Size: 0x10
	    class UInterpTrackInst* TrackInstClass; // 0x48 Size: 0x8
	    char ActiveCondition; // 0x50 Size: 0x1
	    char UnknownData1[0x7]; // 0x51
	    struct FString TrackTitle; // 0x58 Size: 0x10
	    bool bOnePerGroup; // 0x68 Size: 0x1
	    bool bDirGroupOnly; // 0x68 Size: 0x1
	    bool bDisableTrack; // 0x68 Size: 0x1
	    bool bIsSelected; // 0x68 Size: 0x1
	    bool bIsAnimControlTrack; // 0x68 Size: 0x1
	    bool bSubTrackOnly; // 0x68 Size: 0x1
	    bool bVisible; // 0x68 Size: 0x1
	    bool bIsRecording; // 0x68 Size: 0x1

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrack");
			return (class UClass*)ptr;
		};

};

class UInterpTrackFloatBase : public UInterpTrack
{
	public:
	    struct FInterpCurveFloat FloatTrack; // 0x70 Size: 0x18
	    float CurveTension; // 0x88 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackFloatBase");
			return (class UClass*)ptr;
		};

};

class UInterpTrackAnimControl : public UInterpTrackFloatBase
{
	public:
	    FName SlotName; // 0x90 Size: 0x8
	    TArray<struct FAnimControlTrackKey> AnimSeqs; // 0x98 Size: 0x10
	    bool bSkipAnimNotifiers; // 0xa8 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackAnimControl");
			return (class UClass*)ptr;
		};

};

class UInterpTrackVectorBase : public UInterpTrack
{
	public:
	    struct FInterpCurveVector VectorTrack; // 0x70 Size: 0x18
	    float CurveTension; // 0x88 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackVectorBase");
			return (class UClass*)ptr;
		};

};

class UInterpTrackAudioMaster : public UInterpTrackVectorBase
{
	public:
	    char UnknownData0[0x90];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackAudioMaster");
			return (class UClass*)ptr;
		};

};

class UInterpTrackBoolProp : public UInterpTrack
{
	public:
	    TArray<struct FBoolTrackKey> BoolTrack; // 0x70 Size: 0x10
	    FName PropertyName; // 0x80 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackBoolProp");
			return (class UClass*)ptr;
		};

};

class UInterpTrackColorProp : public UInterpTrackVectorBase
{
	public:
	    FName PropertyName; // 0x90 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackColorProp");
			return (class UClass*)ptr;
		};

};

class UInterpTrackColorScale : public UInterpTrackVectorBase
{
	public:
	    char UnknownData0[0x90];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackColorScale");
			return (class UClass*)ptr;
		};

};

class UInterpTrackDirector : public UInterpTrack
{
	public:
	    TArray<struct FDirectorTrackCut> CutTrack; // 0x70 Size: 0x10
	    bool bSimulateCameraCutsOnClients; // 0x80 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackDirector");
			return (class UClass*)ptr;
		};

};

class UInterpTrackEvent : public UInterpTrack
{
	public:
	    TArray<struct FEventTrackKey> EventTrack; // 0x70 Size: 0x10
	    bool bFireEventsWhenForwards; // 0x80 Size: 0x1
	    bool bFireEventsWhenBackwards; // 0x80 Size: 0x1
	    bool bFireEventsWhenJumpingForwards; // 0x80 Size: 0x1
	    bool bUseCustomEventName; // 0x80 Size: 0x1
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackEvent");
			return (class UClass*)ptr;
		};

};

class UInterpTrackFade : public UInterpTrackFloatBase
{
	public:
	    bool bPersistFade; // 0x90 Size: 0x1
	    bool bFadeAudio; // 0x90 Size: 0x1
	    char UnknownData0[0x2]; // 0x92
	    struct FLinearColor FadeColor; // 0x94 Size: 0x10
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackFade");
			return (class UClass*)ptr;
		};

};

class UInterpTrackFloatAnimBPParam : public UInterpTrackFloatBase
{
	public:
	    class UObject* AnimBlueprintClass; // 0x90 Size: 0x8
	    class UAnimInstance* AnimClass; // 0x98 Size: 0x8
	    FName ParamName; // 0xa0 Size: 0x8
	    char UnknownData0[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackFloatAnimBPParam");
			return (class UClass*)ptr;
		};

};

class UInterpTrackFloatMaterialParam : public UInterpTrackFloatBase
{
	public:
	    TArray<class UMaterialInterface*> TargetMaterials; // 0x90 Size: 0x10
	    FName ParamName; // 0xa0 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackFloatMaterialParam");
			return (class UClass*)ptr;
		};

};

class UInterpTrackFloatParticleParam : public UInterpTrackFloatBase
{
	public:
	    FName ParamName; // 0x90 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackFloatParticleParam");
			return (class UClass*)ptr;
		};

};

class UInterpTrackFloatProp : public UInterpTrackFloatBase
{
	public:
	    FName PropertyName; // 0x90 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackFloatProp");
			return (class UClass*)ptr;
		};

};

class UInterpTrackInst : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackInst");
			return (class UClass*)ptr;
		};

};

class UInterpTrackInstAnimControl : public UInterpTrackInst
{
	public:
	    float LastUpdatePosition; // 0x28 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackInstAnimControl");
			return (class UClass*)ptr;
		};

};

class UInterpTrackInstAudioMaster : public UInterpTrackInst
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackInstAudioMaster");
			return (class UClass*)ptr;
		};

};

class UInterpTrackInstProperty : public UInterpTrackInst
{
	public:
	    class UProperty* InterpProperty; // 0x28 Size: 0x8
	    class UObject* PropertyOuterObjectInst; // 0x30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackInstProperty");
			return (class UClass*)ptr;
		};

};

class UInterpTrackInstBoolProp : public UInterpTrackInstProperty
{
	public:
	    char UnknownData0[0x8];
	    class UBoolProperty* BoolProperty; // 0x40 Size: 0x8
	    bool ResetBool; // 0x48 Size: 0x1
	    char UnknownData1[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackInstBoolProp");
			return (class UClass*)ptr;
		};

};

class UInterpTrackInstColorProp : public UInterpTrackInstProperty
{
	public:
	    char UnknownData0[0x8];
	    struct FColor ResetColor; // 0x40 Size: 0x4
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackInstColorProp");
			return (class UClass*)ptr;
		};

};

class UInterpTrackInstColorScale : public UInterpTrackInst
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackInstColorScale");
			return (class UClass*)ptr;
		};

};

class UInterpTrackInstDirector : public UInterpTrackInst
{
	public:
	    class AActor* OldViewTarget; // 0x28 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackInstDirector");
			return (class UClass*)ptr;
		};

};

class UInterpTrackInstEvent : public UInterpTrackInst
{
	public:
	    float LastUpdatePosition; // 0x28 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackInstEvent");
			return (class UClass*)ptr;
		};

};

class UInterpTrackInstFade : public UInterpTrackInst
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackInstFade");
			return (class UClass*)ptr;
		};

};

class UInterpTrackInstFloatAnimBPParam : public UInterpTrackInst
{
	public:
	    class UAnimInstance* AnimScriptInstance; // 0x28 Size: 0x8
	    float ResetFloat; // 0x30 Size: 0x4
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackInstFloatAnimBPParam");
			return (class UClass*)ptr;
		};

};

class UInterpTrackInstFloatMaterialParam : public UInterpTrackInst
{
	public:
	    TArray<class UMaterialInstanceDynamic*> MaterialInstances; // 0x28 Size: 0x10
	    TArray<float> ResetFloats; // 0x38 Size: 0x10
	    TArray<struct FPrimitiveMaterialRef> PrimitiveMaterialRefs; // 0x48 Size: 0x10
	    class UInterpTrackFloatMaterialParam* InstancedTrack; // 0x58 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackInstFloatMaterialParam");
			return (class UClass*)ptr;
		};

};

class UInterpTrackInstFloatParticleParam : public UInterpTrackInst
{
	public:
	    float ResetFloat; // 0x28 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackInstFloatParticleParam");
			return (class UClass*)ptr;
		};

};

class UInterpTrackInstFloatProp : public UInterpTrackInstProperty
{
	public:
	    char UnknownData0[0x8];
	    float ResetFloat; // 0x40 Size: 0x4
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackInstFloatProp");
			return (class UClass*)ptr;
		};

};

class UInterpTrackInstLinearColorProp : public UInterpTrackInstProperty
{
	public:
	    char UnknownData0[0x8];
	    struct FLinearColor ResetColor; // 0x40 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackInstLinearColorProp");
			return (class UClass*)ptr;
		};

};

class UInterpTrackInstMove : public UInterpTrackInst
{
	public:
	    struct FVector ResetLocation; // 0x28 Size: 0xc
	    struct FRotator ResetRotation; // 0x34 Size: 0xc

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackInstMove");
			return (class UClass*)ptr;
		};

};

class UInterpTrackInstParticleReplay : public UInterpTrackInst
{
	public:
	    float LastUpdatePosition; // 0x28 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackInstParticleReplay");
			return (class UClass*)ptr;
		};

};

class UInterpTrackInstSlomo : public UInterpTrackInst
{
	public:
	    float OldTimeDilation; // 0x28 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackInstSlomo");
			return (class UClass*)ptr;
		};

};

class UInterpTrackInstSound : public UInterpTrackInst
{
	public:
	    float LastUpdatePosition; // 0x28 Size: 0x4
	    char UnknownData0[0x4]; // 0x2c
	    class UAudioComponent* PlayAudioComp; // 0x30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackInstSound");
			return (class UClass*)ptr;
		};

};

class UInterpTrackInstToggle : public UInterpTrackInst
{
	public:
	    char Action; // 0x28 Size: 0x1
	    char UnknownData0[0x3]; // 0x29
	    float LastUpdatePosition; // 0x2c Size: 0x4
	    bool bSavedActiveState; // 0x30 Size: 0x1
	    char UnknownData1[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackInstToggle");
			return (class UClass*)ptr;
		};

};

class UInterpTrackInstVectorMaterialParam : public UInterpTrackInst
{
	public:
	    TArray<class UMaterialInstanceDynamic*> MaterialInstances; // 0x28 Size: 0x10
	    TArray<struct FVector> ResetVectors; // 0x38 Size: 0x10
	    TArray<struct FPrimitiveMaterialRef> PrimitiveMaterialRefs; // 0x48 Size: 0x10
	    class UInterpTrackVectorMaterialParam* InstancedTrack; // 0x58 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackInstVectorMaterialParam");
			return (class UClass*)ptr;
		};

};

class UInterpTrackInstVectorProp : public UInterpTrackInstProperty
{
	public:
	    char UnknownData0[0x8];
	    struct FVector ResetVector; // 0x40 Size: 0xc
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackInstVectorProp");
			return (class UClass*)ptr;
		};

};

class UInterpTrackInstVisibility : public UInterpTrackInst
{
	public:
	    char Action; // 0x28 Size: 0x1
	    char UnknownData0[0x3]; // 0x29
	    float LastUpdatePosition; // 0x2c Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackInstVisibility");
			return (class UClass*)ptr;
		};

};

class UInterpTrackLinearColorBase : public UInterpTrack
{
	public:
	    struct FInterpCurveLinearColor LinearColorTrack; // 0x70 Size: 0x18
	    float CurveTension; // 0x88 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackLinearColorBase");
			return (class UClass*)ptr;
		};

};

class UInterpTrackLinearColorProp : public UInterpTrackLinearColorBase
{
	public:
	    FName PropertyName; // 0x90 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackLinearColorProp");
			return (class UClass*)ptr;
		};

};

class UInterpTrackMove : public UInterpTrack
{
	public:
	    struct FInterpCurveVector PosTrack; // 0x70 Size: 0x18
	    struct FInterpCurveVector EulerTrack; // 0x88 Size: 0x18
	    struct FInterpLookupTrack LookupTrack; // 0xa0 Size: 0x10
	    FName LookAtGroupName; // 0xb0 Size: 0x8
	    float LinCurveTension; // 0xb8 Size: 0x4
	    float AngCurveTension; // 0xbc Size: 0x4
	    bool bUseQuatInterpolation; // 0xc0 Size: 0x1
	    bool bShowArrowAtKeys; // 0xc0 Size: 0x1
	    bool bDisableMovement; // 0xc0 Size: 0x1
	    bool bShowTranslationOnCurveEd; // 0xc0 Size: 0x1
	    bool bShowRotationOnCurveEd; // 0xc0 Size: 0x1
	    bool bHide3DTrack; // 0xc0 Size: 0x1
	    char UnknownData0[0x2]; // 0xc6
	    char RotMode; // 0xc4 Size: 0x1
	    char UnknownData1[0x3];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackMove");
			return (class UClass*)ptr;
		};

};

class UInterpTrackMoveAxis : public UInterpTrackFloatBase
{
	public:
	    char MoveAxis; // 0x90 Size: 0x1
	    char UnknownData0[0x7]; // 0x91
	    struct FInterpLookupTrack LookupTrack; // 0x98 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackMoveAxis");
			return (class UClass*)ptr;
		};

};

class UInterpTrackParticleReplay : public UInterpTrack
{
	public:
	    TArray<struct FParticleReplayTrackKey> TrackKeys; // 0x70 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackParticleReplay");
			return (class UClass*)ptr;
		};

};

class UInterpTrackSlomo : public UInterpTrackFloatBase
{
	public:
	    char UnknownData0[0x90];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackSlomo");
			return (class UClass*)ptr;
		};

};

class UInterpTrackSound : public UInterpTrackVectorBase
{
	public:
	    TArray<struct FSoundTrackKey> Sounds; // 0x90 Size: 0x10
	    bool bPlayOnReverse; // 0xa0 Size: 0x1
	    bool bContinueSoundOnMatineeEnd; // 0xa0 Size: 0x1
	    bool bSuppressSubtitles; // 0xa0 Size: 0x1
	    bool bTreatAsDialogue; // 0xa0 Size: 0x1
	    bool bAttach; // 0xa0 Size: 0x1
	    char UnknownData0[0x3];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackSound");
			return (class UClass*)ptr;
		};

};

class UInterpTrackToggle : public UInterpTrack
{
	public:
	    TArray<struct FToggleTrackKey> ToggleTrack; // 0x70 Size: 0x10
	    bool bActivateSystemEachUpdate; // 0x80 Size: 0x1
	    bool bActivateWithJustAttachedFlag; // 0x80 Size: 0x1
	    bool bFireEventsWhenForwards; // 0x80 Size: 0x1
	    bool bFireEventsWhenBackwards; // 0x80 Size: 0x1
	    bool bFireEventsWhenJumpingForwards; // 0x80 Size: 0x1
	    char UnknownData0[0x3];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackToggle");
			return (class UClass*)ptr;
		};

};

class UInterpTrackVectorMaterialParam : public UInterpTrackVectorBase
{
	public:
	    TArray<class UMaterialInterface*> TargetMaterials; // 0x90 Size: 0x10
	    FName ParamName; // 0xa0 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackVectorMaterialParam");
			return (class UClass*)ptr;
		};

};

class UInterpTrackVectorProp : public UInterpTrackVectorBase
{
	public:
	    FName PropertyName; // 0x90 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackVectorProp");
			return (class UClass*)ptr;
		};

};

class UInterpTrackVisibility : public UInterpTrack
{
	public:
	    TArray<struct FVisibilityTrackKey> VisibilityTrack; // 0x70 Size: 0x10
	    bool bFireEventsWhenForwards; // 0x80 Size: 0x1
	    bool bFireEventsWhenBackwards; // 0x80 Size: 0x1
	    bool bFireEventsWhenJumpingForwards; // 0x80 Size: 0x1
	    char UnknownData0[0x5];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.InterpTrackVisibility");
			return (class UClass*)ptr;
		};

};

class UIntSerialization : public UObject
{
	public:
	    __int64/*UInt16Property*/ UnsignedInt16Variable; // 0x28 Size: 0x2
	    char UnknownData0[0x2]; // 0x2a
	    uint32_t UnsignedInt32Variable; // 0x2c Size: 0x4
	    uint64_t UnsignedInt64Variable; // 0x30 Size: 0x8
	    int8_t SignedInt8Variable; // 0x38 Size: 0x1
	    char UnknownData1[0x1]; // 0x39
	    int16_t SignedInt16Variable; // 0x3a Size: 0x2
	    char UnknownData2[0x4]; // 0x3c
	    int64_t SignedInt64Variable; // 0x40 Size: 0x8
	    char UnsignedInt8Variable; // 0x48 Size: 0x1
	    char UnknownData3[0x3]; // 0x49
	    int SignedInt32Variable; // 0x4c Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.IntSerialization");
			return (class UClass*)ptr;
		};

};

class AKillZVolume : public APhysicsVolume
{
	public:
	    char UnknownData0[0x378];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.KillZVolume");
			return (class UClass*)ptr;
		};

};

class UKismetArrayLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void SetArrayPropertyByName(class UObject* Object, FName PropertyName, TArray<int> Value); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void FilterArray(TArray<class AActor*> TargetArray, class AActor* FilterClass, TArray<class AActor*> FilteredArray); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static void Array_Swap(TArray<int> TargetArray, int FirstIndex, int SecondIndex); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static void Array_Shuffle(TArray<int> TargetArray); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static void Array_Set(TArray<int> TargetArray, int Index, int Item, bool bSizeToFit); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static void Array_Resize(TArray<int> TargetArray, int Size); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static bool Array_RemoveItem(TArray<int> TargetArray, int Item); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static void Array_Remove(TArray<int> TargetArray, int IndexToRemove); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static int Array_Length(TArray<int> TargetArray); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static int Array_LastIndex(TArray<int> TargetArray); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static bool Array_IsValidIndex(TArray<int> TargetArray, int IndexToTest); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static void Array_Insert(TArray<int> TargetArray, int NewItem, int Index); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    static void Array_Get(TArray<int> TargetArray, int Index, int Item); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    static int Array_Find(TArray<int> TargetArray, int ItemToFind); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    static bool Array_Contains(TArray<int> TargetArray, int ItemToFind); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    static void Array_Clear(TArray<int> TargetArray); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    static void Array_Append(TArray<int> TargetArray, TArray<int> SourceArray); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    static int Array_AddUnique(TArray<int> TargetArray, int NewItem); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    static int Array_Add(TArray<int> TargetArray, int NewItem); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.KismetArrayLibrary");
			return (class UClass*)ptr;
		};

};

class UKismetGuidLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void Parse_StringToGuid(struct FString GuidString, struct FGuid OutGuid, bool Success); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static bool NotEqual_GuidGuid(struct FGuid A, struct FGuid B); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static struct FGuid NewGuid(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static bool IsValid_Guid(struct FGuid InGuid); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static void Invalidate_Guid(struct FGuid InGuid); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_GuidGuid(struct FGuid A, struct FGuid B); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static struct FString Conv_GuidToString(struct FGuid InGuid); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.KismetGuidLibrary");
			return (class UClass*)ptr;
		};

};

class UKismetInputLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static bool PointerEvent_IsTouchEvent(struct FPointerEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static bool PointerEvent_IsMouseButtonDown(struct FPointerEvent Input, struct FKey MouseButton); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static float PointerEvent_GetWheelDelta(struct FPointerEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static int PointerEvent_GetUserIndex(struct FPointerEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static int PointerEvent_GetTouchpadIndex(struct FPointerEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static struct FVector2D PointerEvent_GetScreenSpacePosition(struct FPointerEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static int PointerEvent_GetPointerIndex(struct FPointerEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static struct FVector2D PointerEvent_GetLastScreenSpacePosition(struct FPointerEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static ESlateGesture PointerEvent_GetGestureType(struct FPointerEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static struct FVector2D PointerEvent_GetGestureDelta(struct FPointerEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static struct FKey PointerEvent_GetEffectingButton(struct FPointerEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static struct FVector2D PointerEvent_GetCursorDelta(struct FPointerEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    static bool Key_IsVectorAxis(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    static bool Key_IsValid(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    static bool Key_IsMouseButton(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    static bool Key_IsModifierKey(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    static bool Key_IsKeyboardKey(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    static bool Key_IsGamepadKey(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    static bool Key_IsFloatAxis(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    static struct FText Key_GetDisplayName(struct FKey Key); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    static bool InputEvent_IsShiftDown(struct FInputEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    static bool InputEvent_IsRightShiftDown(struct FInputEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    static bool InputEvent_IsRightControlDown(struct FInputEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    static bool InputEvent_IsRightCommandDown(struct FInputEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    static bool InputEvent_IsRightAltDown(struct FInputEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    static bool InputEvent_IsRepeat(struct FInputEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    static bool InputEvent_IsLeftShiftDown(struct FInputEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    static bool InputEvent_IsLeftControlDown(struct FInputEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    static bool InputEvent_IsLeftCommandDown(struct FInputEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    static bool InputEvent_IsLeftAltDown(struct FInputEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    static bool InputEvent_IsControlDown(struct FInputEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    static bool InputEvent_IsCommandDown(struct FInputEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    static bool InputEvent_IsAltDown(struct FInputEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    static int GetUserIndex(struct FKeyEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    static struct FKey GetKey(struct FKeyEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    static float GetAnalogValue(struct FAnalogInputEvent Input); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_KeyKey(struct FKey A, struct FKey B); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_InputChordInputChord(struct FInputChord A, struct FInputChord B); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    static void CalibrateTilt(); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.KismetInputLibrary");
			return (class UClass*)ptr;
		};

};

class UKismetInternationalizationLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static bool SetCurrentLocale(struct FString Culture, bool SaveToConfig); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static bool SetCurrentLanguageAndLocale(struct FString Culture, bool SaveToConfig); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static bool SetCurrentLanguage(struct FString Culture, bool SaveToConfig); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static bool SetCurrentCulture(struct FString Culture, bool SaveToConfig); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static bool SetCurrentAssetGroupCulture(FName AssetGroup, struct FString Culture, bool SaveToConfig); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static struct FString GetCurrentLocale(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static struct FString GetCurrentLanguage(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static struct FString GetCurrentCulture(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static struct FString GetCurrentAssetGroupCulture(FName AssetGroup); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static void ClearCurrentAssetGroupCulture(FName AssetGroup, bool SaveToConfig); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.KismetInternationalizationLibrary");
			return (class UClass*)ptr;
		};

};

class UKismetMaterialLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void SetVectorParameterValue(class UObject* WorldContextObject, class UMaterialParameterCollection* Collection, FName ParameterName, struct FLinearColor ParameterValue); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void SetScalarParameterValue(class UObject* WorldContextObject, class UMaterialParameterCollection* Collection, FName ParameterName, float ParameterValue); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static struct FLinearColor GetVectorParameterValue(class UObject* WorldContextObject, class UMaterialParameterCollection* Collection, FName ParameterName); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static float GetScalarParameterValue(class UObject* WorldContextObject, class UMaterialParameterCollection* Collection, FName ParameterName); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static class UMaterialInstanceDynamic* CreateDynamicMaterialInstance(class UObject* WorldContextObject, class UMaterialInterface* Parent, FName OptionalName); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.KismetMaterialLibrary");
			return (class UClass*)ptr;
		};

};

class UKismetMathLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static int Xor_IntInt(int A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static int64_t Xor_Int64Int64(int64_t A, int64_t B); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static float VSizeXY(struct FVector A); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static float VSizeSquared(struct FVector A); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static float VSize2DSquared(struct FVector2D A); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static float VSize2D(struct FVector2D A); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static float VSize(struct FVector A); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static struct FVector VLerp(struct FVector A, struct FVector B, float Alpha); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static struct FVector VInterpTo_Constant(struct FVector Current, struct FVector Target, float DeltaTime, float InterpSpeed); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static struct FVector VInterpTo(struct FVector Current, struct FVector Target, float DeltaTime, float InterpSpeed); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static struct FVector VectorSpringInterp(struct FVector Current, struct FVector Target, struct FVectorSpringState SpringState, float Stiffness, float CriticalDampingFactor, float DeltaTime, float Mass); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static struct FVector2D Vector2DInterpTo_Constant(struct FVector2D Current, struct FVector2D Target, float DeltaTime, float InterpSpeed); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    static struct FVector2D Vector2DInterpTo(struct FVector2D Current, struct FVector2D Target, float DeltaTime, float InterpSpeed); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    static struct FVector VEase(struct FVector A, struct FVector B, float Alpha, char EasingFunc, float BlendExp, int Steps); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    static struct FDateTime UtcNow(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    static struct FRotator TransformRotation(struct FTransform T, struct FRotator Rotation); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    static struct FVector TransformLocation(struct FTransform T, struct FVector Location); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    static struct FVector TransformDirection(struct FTransform T, struct FVector Direction); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    static float Transform_Determinant(struct FTransform Transform); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    static struct FDateTime Today(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    static struct FTransform TLerp(struct FTransform A, struct FTransform B, float Alpha, char InterpMode); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    static struct FTransform TInterpTo(struct FTransform Current, struct FTransform Target, float DeltaTime, float InterpSpeed); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    static struct FTimespan TimespanZeroValue(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    static float TimespanRatio(struct FTimespan A, struct FTimespan B); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    static struct FTimespan TimespanMinValue(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    static struct FTimespan TimespanMaxValue(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    static bool TimespanFromString(struct FString TimespanString, struct FTimespan Result); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    static struct FTransform TEase(struct FTransform A, struct FTransform B, float Alpha, char EasingFunc, float BlendExp, int Steps); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    static float Tan(float A); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    static struct FVector Subtract_VectorVector(struct FVector A, struct FVector B); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    static struct FVector Subtract_VectorInt(struct FVector A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    static struct FVector Subtract_VectorFloat(struct FVector A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    static struct FVector2D Subtract_Vector2DVector2D(struct FVector2D A, struct FVector2D B); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    static struct FVector2D Subtract_Vector2DFloat(struct FVector2D A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    static struct FTimespan Subtract_TimespanTimespan(struct FTimespan A, struct FTimespan B); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    static int Subtract_IntInt(int A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    static int64_t Subtract_Int64Int64(int64_t A, int64_t B); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    static float Subtract_FloatFloat(float A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    static struct FDateTime Subtract_DateTimeTimespan(struct FDateTime A, struct FTimespan B); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    static struct FTimespan Subtract_DateTimeDateTime(struct FDateTime A, struct FDateTime B); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    static char Subtract_ByteByte(char A, char B); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    static float Square(float A); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    static float Sqrt(float A); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    static float Sin(float A); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    static int64_t SignOfInteger64(int64_t A); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    static int SignOfInteger(int A); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    static float SignOfFloat(float A); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    static void SetRandomStreamSeed(struct FRandomStream Stream, int NewSeed); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    static struct FVector SelectVector(struct FVector A, struct FVector B, bool bPickA); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    static struct FTransform SelectTransform(struct FTransform A, struct FTransform B, bool bPickA); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    static struct FString SelectString(struct FString A, struct FString B, bool bPickA); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    static struct FRotator SelectRotator(struct FRotator A, struct FRotator B, bool bPickA); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    static class UObject* SelectObject(class UObject* A, class UObject* B, bool bSelectA); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    static int SelectInt(int A, int B, bool bPickA); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    static float SelectFloat(float A, float B, bool bPickA); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    static struct FLinearColor SelectColor(struct FLinearColor A, struct FLinearColor B, bool bPickA); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    static class UObject* SelectClass(class UObject* A, class UObject* B, bool bSelectA); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    static void SeedRandomStream(struct FRandomStream Stream); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    static int64_t Round64(float A); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    static int Round(float A); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    static struct FRotator RotatorFromAxisAndAngle(struct FVector Axis, float Angle); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    static struct FVector RotateAngleAxis(struct FVector InVect, float AngleDeg, struct FVector Axis); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    static struct FRotator RLerp(struct FRotator A, struct FRotator B, float Alpha, bool bShortestPath); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x7fe1]; // 0x7fe1
	    static struct FRotator RInterpTo_Constant(struct FRotator Current, struct FRotator Target, float DeltaTime, float InterpSpeed); // 0x0 Size: 0x7fe1
	    char UnknownData63[0x7fe1]; // 0x7fe1
	    static struct FRotator RInterpTo(struct FRotator Current, struct FRotator Target, float DeltaTime, float InterpSpeed); // 0x0 Size: 0x7fe1
	    char UnknownData64[0x7fe1]; // 0x7fe1
	    static void RGBToHSV_Vector(struct FLinearColor RGB, struct FLinearColor HSV); // 0x0 Size: 0x7fe1
	    char UnknownData65[0x7fe1]; // 0x7fe1
	    static void RGBToHSV(struct FLinearColor InColor, float H, float S, float V, float A); // 0x0 Size: 0x7fe1
	    char UnknownData66[0x7fe1]; // 0x7fe1
	    static void ResetVectorSpringState(struct FVectorSpringState SpringState); // 0x0 Size: 0x7fe1
	    char UnknownData67[0x7fe1]; // 0x7fe1
	    static void ResetRandomStream(struct FRandomStream Stream); // 0x0 Size: 0x7fe1
	    char UnknownData68[0x7fe1]; // 0x7fe1
	    static void ResetFloatSpringState(struct FFloatSpringState SpringState); // 0x0 Size: 0x7fe1
	    char UnknownData69[0x7fe1]; // 0x7fe1
	    static struct FRotator REase(struct FRotator A, struct FRotator B, float Alpha, bool bShortestPath, char EasingFunc, float BlendExp, int Steps); // 0x0 Size: 0x7fe1
	    char UnknownData70[0x7fe1]; // 0x7fe1
	    static struct FVector RandomUnitVectorInEllipticalConeInRadiansFromStream(struct FVector ConeDir, float MaxYawInRadians, float MaxPitchInRadians, struct FRandomStream Stream); // 0x0 Size: 0x7fe1
	    char UnknownData71[0x7fe1]; // 0x7fe1
	    static struct FVector RandomUnitVectorInEllipticalConeInRadians(struct FVector ConeDir, float MaxYawInRadians, float MaxPitchInRadians); // 0x0 Size: 0x7fe1
	    char UnknownData72[0x7fe1]; // 0x7fe1
	    static struct FVector RandomUnitVectorInEllipticalConeInDegreesFromStream(struct FVector ConeDir, float MaxYawInDegrees, float MaxPitchInDegrees, struct FRandomStream Stream); // 0x0 Size: 0x7fe1
	    char UnknownData73[0x7fe1]; // 0x7fe1
	    static struct FVector RandomUnitVectorInEllipticalConeInDegrees(struct FVector ConeDir, float MaxYawInDegrees, float MaxPitchInDegrees); // 0x0 Size: 0x7fe1
	    char UnknownData74[0x7fe1]; // 0x7fe1
	    static struct FVector RandomUnitVectorInConeInRadiansFromStream(struct FVector ConeDir, float ConeHalfAngleInRadians, struct FRandomStream Stream); // 0x0 Size: 0x7fe1
	    char UnknownData75[0x7fe1]; // 0x7fe1
	    static struct FVector RandomUnitVectorInConeInRadians(struct FVector ConeDir, float ConeHalfAngleInRadians); // 0x0 Size: 0x7fe1
	    char UnknownData76[0x7fe1]; // 0x7fe1
	    static struct FVector RandomUnitVectorInConeInDegreesFromStream(struct FVector ConeDir, float ConeHalfAngleInDegrees, struct FRandomStream Stream); // 0x0 Size: 0x7fe1
	    char UnknownData77[0x7fe1]; // 0x7fe1
	    static struct FVector RandomUnitVectorInConeInDegrees(struct FVector ConeDir, float ConeHalfAngleInDegrees); // 0x0 Size: 0x7fe1
	    char UnknownData78[0x7fe1]; // 0x7fe1
	    static struct FVector RandomUnitVectorFromStream(struct FRandomStream Stream); // 0x0 Size: 0x7fe1
	    char UnknownData79[0x7fe1]; // 0x7fe1
	    static struct FVector RandomUnitVector(); // 0x0 Size: 0x7fe1
	    char UnknownData80[0x7fe1]; // 0x7fe1
	    static struct FRotator RandomRotatorFromStream(bool bRoll, struct FRandomStream Stream); // 0x0 Size: 0x7fe1
	    char UnknownData81[0x7fe1]; // 0x7fe1
	    static struct FRotator RandomRotator(bool bRoll); // 0x0 Size: 0x7fe1
	    char UnknownData82[0x7fe1]; // 0x7fe1
	    static struct FVector RandomPointInBoundingBox(struct FVector Origin, struct FVector BoxExtent); // 0x0 Size: 0x7fe1
	    char UnknownData83[0x7fe1]; // 0x7fe1
	    static int RandomIntegerInRangeFromStream(int Min, int Max, struct FRandomStream Stream); // 0x0 Size: 0x7fe1
	    char UnknownData84[0x7fe1]; // 0x7fe1
	    static int RandomIntegerInRange(int Min, int Max); // 0x0 Size: 0x7fe1
	    char UnknownData85[0x7fe1]; // 0x7fe1
	    static int RandomIntegerFromStream(int Max, struct FRandomStream Stream); // 0x0 Size: 0x7fe1
	    char UnknownData86[0x7fe1]; // 0x7fe1
	    static int64_t RandomInteger64InRange(int64_t Min, int64_t Max); // 0x0 Size: 0x7fe1
	    char UnknownData87[0x7fe1]; // 0x7fe1
	    static int64_t RandomInteger64(int64_t Max); // 0x0 Size: 0x7fe1
	    char UnknownData88[0x7fe1]; // 0x7fe1
	    static int RandomInteger(int Max); // 0x0 Size: 0x7fe1
	    char UnknownData89[0x7fe1]; // 0x7fe1
	    static float RandomFloatInRangeFromStream(float Min, float Max, struct FRandomStream Stream); // 0x0 Size: 0x7fe1
	    char UnknownData90[0x7fe1]; // 0x7fe1
	    static float RandomFloatInRange(float Min, float Max); // 0x0 Size: 0x7fe1
	    char UnknownData91[0x7fe1]; // 0x7fe1
	    static float RandomFloatFromStream(struct FRandomStream Stream); // 0x0 Size: 0x7fe1
	    char UnknownData92[0x7fe1]; // 0x7fe1
	    static float RandomFloat(); // 0x0 Size: 0x7fe1
	    char UnknownData93[0x7fe1]; // 0x7fe1
	    static bool RandomBoolWithWeightFromStream(float Weight, struct FRandomStream RandomStream); // 0x0 Size: 0x7fe1
	    char UnknownData94[0x7fe1]; // 0x7fe1
	    static bool RandomBoolWithWeight(float Weight); // 0x0 Size: 0x7fe1
	    char UnknownData95[0x7fe1]; // 0x7fe1
	    static bool RandomBoolFromStream(struct FRandomStream Stream); // 0x0 Size: 0x7fe1
	    char UnknownData96[0x7fe1]; // 0x7fe1
	    static bool RandomBool(); // 0x0 Size: 0x7fe1
	    char UnknownData97[0x7fe1]; // 0x7fe1
	    static float RadiansToDegrees(float A); // 0x0 Size: 0x7fe1
	    char UnknownData98[0x7fe1]; // 0x7fe1
	    static struct FVector ProjectVectorOnToVector(struct FVector V, struct FVector Target); // 0x0 Size: 0x7fe1
	    char UnknownData99[0x7fe1]; // 0x7fe1
	    static struct FVector ProjectVectorOnToPlane(struct FVector V, struct FVector PlaneNormal); // 0x0 Size: 0x7fe1
	    char UnknownData100[0x7fe1]; // 0x7fe1
	    static struct FVector ProjectPointOnToPlane(struct FVector Point, struct FVector PlaneBase, struct FVector PlaneNormal); // 0x0 Size: 0x7fe1
	    char UnknownData101[0x7fe1]; // 0x7fe1
	    static bool PointsAreCoplanar(TArray<struct FVector> Points, float Tolerance); // 0x0 Size: 0x7fe1
	    char UnknownData102[0x7fe1]; // 0x7fe1
	    static float PerlinNoise1D(float Value); // 0x0 Size: 0x7fe1
	    char UnknownData103[0x7fe1]; // 0x7fe1
	    static int Percent_IntInt(int A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData104[0x7fe1]; // 0x7fe1
	    static float Percent_FloatFloat(float A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData105[0x7fe1]; // 0x7fe1
	    static char Percent_ByteByte(char A, char B); // 0x0 Size: 0x7fe1
	    char UnknownData106[0x7fe1]; // 0x7fe1
	    static int Or_IntInt(int A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData107[0x7fe1]; // 0x7fe1
	    static int64_t Or_Int64Int64(int64_t A, int64_t B); // 0x0 Size: 0x7fe1
	    char UnknownData108[0x7fe1]; // 0x7fe1
	    static struct FDateTime Now(); // 0x0 Size: 0x7fe1
	    char UnknownData109[0x7fe1]; // 0x7fe1
	    static bool NotEqual_VectorVector(struct FVector A, struct FVector B, float ErrorTolerance); // 0x0 Size: 0x7fe1
	    char UnknownData110[0x7fe1]; // 0x7fe1
	    static bool NotEqual_Vector2DVector2D(struct FVector2D A, struct FVector2D B, float ErrorTolerance); // 0x0 Size: 0x7fe1
	    char UnknownData111[0x7fe1]; // 0x7fe1
	    static bool NotEqual_TimespanTimespan(struct FTimespan A, struct FTimespan B); // 0x0 Size: 0x7fe1
	    char UnknownData112[0x7fe1]; // 0x7fe1
	    static bool NotEqual_RotatorRotator(struct FRotator A, struct FRotator B, float ErrorTolerance); // 0x0 Size: 0x7fe1
	    char UnknownData113[0x7fe1]; // 0x7fe1
	    static bool NotEqual_ObjectObject(class UObject* A, class UObject* B); // 0x0 Size: 0x7fe1
	    char UnknownData114[0x7fe1]; // 0x7fe1
	    static bool NotEqual_NameName(FName A, FName B); // 0x0 Size: 0x7fe1
	    char UnknownData115[0x7fe1]; // 0x7fe1
	    static bool NotEqual_IntInt(int A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData116[0x7fe1]; // 0x7fe1
	    static bool NotEqual_Int64Int64(int64_t A, int64_t B); // 0x0 Size: 0x7fe1
	    char UnknownData117[0x7fe1]; // 0x7fe1
	    static bool NotEqual_FloatFloat(float A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData118[0x7fe1]; // 0x7fe1
	    static bool NotEqual_DateTimeDateTime(struct FDateTime A, struct FDateTime B); // 0x0 Size: 0x7fe1
	    char UnknownData119[0x7fe1]; // 0x7fe1
	    static bool NotEqual_ClassClass(class UObject* A, class UObject* B); // 0x0 Size: 0x7fe1
	    char UnknownData120[0x7fe1]; // 0x7fe1
	    static bool NotEqual_ByteByte(char A, char B); // 0x0 Size: 0x7fe1
	    char UnknownData121[0x7fe1]; // 0x7fe1
	    static bool NotEqual_BoolBool(bool A, bool B); // 0x0 Size: 0x7fe1
	    char UnknownData122[0x7fe1]; // 0x7fe1
	    static bool Not_PreBool(bool A); // 0x0 Size: 0x7fe1
	    char UnknownData123[0x7fe1]; // 0x7fe1
	    static int64_t Not_Int64(int64_t A); // 0x0 Size: 0x7fe1
	    char UnknownData124[0x7fe1]; // 0x7fe1
	    static int Not_Int(int A); // 0x0 Size: 0x7fe1
	    char UnknownData125[0x7fe1]; // 0x7fe1
	    static float NormalizeToRange(float Value, float RangeMin, float RangeMax); // 0x0 Size: 0x7fe1
	    char UnknownData126[0x7fe1]; // 0x7fe1
	    static struct FRotator NormalizedDeltaRotator(struct FRotator A, struct FRotator B); // 0x0 Size: 0x7fe1
	    char UnknownData127[0x7fe1]; // 0x7fe1
	    static float NormalizeAxis(float Angle); // 0x0 Size: 0x7fe1
	    char UnknownData128[0x7fe1]; // 0x7fe1
	    static struct FVector2D Normal2D(struct FVector2D A); // 0x0 Size: 0x7fe1
	    char UnknownData129[0x7fe1]; // 0x7fe1
	    static struct FVector Normal(struct FVector A); // 0x0 Size: 0x7fe1
	    char UnknownData130[0x7fe1]; // 0x7fe1
	    static struct FVector NegateVector(struct FVector A); // 0x0 Size: 0x7fe1
	    char UnknownData131[0x7fe1]; // 0x7fe1
	    static struct FRotator NegateRotator(struct FRotator A); // 0x0 Size: 0x7fe1
	    char UnknownData132[0x7fe1]; // 0x7fe1
	    static bool NearlyEqual_TransformTransform(struct FTransform A, struct FTransform B, float LocationTolerance, float RotationTolerance, float Scale3DTolerance); // 0x0 Size: 0x7fe1
	    char UnknownData133[0x7fe1]; // 0x7fe1
	    static bool NearlyEqual_FloatFloat(float A, float B, float ErrorTolerance); // 0x0 Size: 0x7fe1
	    char UnknownData134[0x7fe1]; // 0x7fe1
	    static float MultiplyMultiply_FloatFloat(float Base, float Exp); // 0x0 Size: 0x7fe1
	    char UnknownData135[0x7fe1]; // 0x7fe1
	    static float MultiplyByPi(float Value); // 0x0 Size: 0x7fe1
	    char UnknownData136[0x7fe1]; // 0x7fe1
	    static struct FVector Multiply_VectorVector(struct FVector A, struct FVector B); // 0x0 Size: 0x7fe1
	    char UnknownData137[0x7fe1]; // 0x7fe1
	    static struct FVector Multiply_VectorInt(struct FVector A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData138[0x7fe1]; // 0x7fe1
	    static struct FVector Multiply_VectorFloat(struct FVector A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData139[0x7fe1]; // 0x7fe1
	    static struct FVector2D Multiply_Vector2DVector2D(struct FVector2D A, struct FVector2D B); // 0x0 Size: 0x7fe1
	    char UnknownData140[0x7fe1]; // 0x7fe1
	    static struct FVector2D Multiply_Vector2DFloat(struct FVector2D A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData141[0x7fe1]; // 0x7fe1
	    static struct FTimespan Multiply_TimespanFloat(struct FTimespan A, float Scalar); // 0x0 Size: 0x7fe1
	    char UnknownData142[0x7fe1]; // 0x7fe1
	    static struct FRotator Multiply_RotatorInt(struct FRotator A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData143[0x7fe1]; // 0x7fe1
	    static struct FRotator Multiply_RotatorFloat(struct FRotator A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData144[0x7fe1]; // 0x7fe1
	    static struct FLinearColor Multiply_LinearColorLinearColor(struct FLinearColor A, struct FLinearColor B); // 0x0 Size: 0x7fe1
	    char UnknownData145[0x7fe1]; // 0x7fe1
	    static struct FLinearColor Multiply_LinearColorFloat(struct FLinearColor A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData146[0x7fe1]; // 0x7fe1
	    static int Multiply_IntInt(int A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData147[0x7fe1]; // 0x7fe1
	    static float Multiply_IntFloat(int A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData148[0x7fe1]; // 0x7fe1
	    static int64_t Multiply_Int64Int64(int64_t A, int64_t B); // 0x0 Size: 0x7fe1
	    char UnknownData149[0x7fe1]; // 0x7fe1
	    static float Multiply_FloatFloat(float A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData150[0x7fe1]; // 0x7fe1
	    static char Multiply_ByteByte(char A, char B); // 0x0 Size: 0x7fe1
	    char UnknownData151[0x7fe1]; // 0x7fe1
	    static struct FVector MirrorVectorByNormal(struct FVector InVect, struct FVector InNormal); // 0x0 Size: 0x7fe1
	    char UnknownData152[0x7fe1]; // 0x7fe1
	    static void MinOfIntArray(TArray<int> IntArray, int IndexOfMinValue, int MinValue); // 0x0 Size: 0x7fe1
	    char UnknownData153[0x7fe1]; // 0x7fe1
	    static void MinOfFloatArray(TArray<float> FloatArray, int IndexOfMinValue, float MinValue); // 0x0 Size: 0x7fe1
	    char UnknownData154[0x7fe1]; // 0x7fe1
	    static void MinOfByteArray(TArray<char> ByteArray, int IndexOfMinValue, char MinValue); // 0x0 Size: 0x7fe1
	    char UnknownData155[0x7fe1]; // 0x7fe1
	    static int64_t MinInt64(int64_t A, int64_t B); // 0x0 Size: 0x7fe1
	    char UnknownData156[0x7fe1]; // 0x7fe1
	    static void MinimumAreaRectangle(class UObject* WorldContextObject, TArray<struct FVector> InVerts, struct FVector SampleSurfaceNormal, struct FVector OutRectCenter, struct FRotator OutRectRotation, float OutSideLengthX, float OutSideLengthY, bool bDebugDraw); // 0x0 Size: 0x7fe1
	    char UnknownData157[0x7fe1]; // 0x7fe1
	    static int Min(int A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData158[0x7fe1]; // 0x7fe1
	    static void MaxOfIntArray(TArray<int> IntArray, int IndexOfMaxValue, int MaxValue); // 0x0 Size: 0x7fe1
	    char UnknownData159[0x7fe1]; // 0x7fe1
	    static void MaxOfFloatArray(TArray<float> FloatArray, int IndexOfMaxValue, float MaxValue); // 0x0 Size: 0x7fe1
	    char UnknownData160[0x7fe1]; // 0x7fe1
	    static void MaxOfByteArray(TArray<char> ByteArray, int IndexOfMaxValue, char MaxValue); // 0x0 Size: 0x7fe1
	    char UnknownData161[0x7fe1]; // 0x7fe1
	    static int64_t MaxInt64(int64_t A, int64_t B); // 0x0 Size: 0x7fe1
	    char UnknownData162[0x7fe1]; // 0x7fe1
	    static int Max(int A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData163[0x7fe1]; // 0x7fe1
	    static struct FVector Matrix_GetOrigin(struct FMatrix InMatrix); // 0x0 Size: 0x7fe1
	    char UnknownData164[0x7fe1]; // 0x7fe1
	    static float MapRangeUnclamped(float Value, float InRangeA, float InRangeB, float OutRangeA, float OutRangeB); // 0x0 Size: 0x7fe1
	    char UnknownData165[0x7fe1]; // 0x7fe1
	    static float MapRangeClamped(float Value, float InRangeA, float InRangeB, float OutRangeA, float OutRangeB); // 0x0 Size: 0x7fe1
	    char UnknownData166[0x7fe1]; // 0x7fe1
	    static struct FVector2D MakeVector2D(float X, float Y); // 0x0 Size: 0x7fe1
	    char UnknownData167[0x7fe1]; // 0x7fe1
	    static struct FVector MakeVector(float X, float Y, float Z); // 0x0 Size: 0x7fe1
	    char UnknownData168[0x7fe1]; // 0x7fe1
	    static struct FTransform MakeTransform(struct FVector Location, struct FRotator Rotation, struct FVector Scale); // 0x0 Size: 0x7fe1
	    char UnknownData169[0x7fe1]; // 0x7fe1
	    static struct FTimespan MakeTimespan2(int days, int Hours, int Minutes, int Seconds, int FractionNano); // 0x0 Size: 0x7fe1
	    char UnknownData170[0x7fe1]; // 0x7fe1
	    static struct FTimespan MakeTimespan(int days, int Hours, int Minutes, int Seconds, int Milliseconds); // 0x0 Size: 0x7fe1
	    char UnknownData171[0x7fe1]; // 0x7fe1
	    static struct FRotator MakeRotFromZY(struct FVector Z, struct FVector Y); // 0x0 Size: 0x7fe1
	    char UnknownData172[0x7fe1]; // 0x7fe1
	    static struct FRotator MakeRotFromZX(struct FVector Z, struct FVector X); // 0x0 Size: 0x7fe1
	    char UnknownData173[0x7fe1]; // 0x7fe1
	    static struct FRotator MakeRotFromZ(struct FVector Z); // 0x0 Size: 0x7fe1
	    char UnknownData174[0x7fe1]; // 0x7fe1
	    static struct FRotator MakeRotFromYZ(struct FVector Y, struct FVector Z); // 0x0 Size: 0x7fe1
	    char UnknownData175[0x7fe1]; // 0x7fe1
	    static struct FRotator MakeRotFromYX(struct FVector Y, struct FVector X); // 0x0 Size: 0x7fe1
	    char UnknownData176[0x7fe1]; // 0x7fe1
	    static struct FRotator MakeRotFromY(struct FVector Y); // 0x0 Size: 0x7fe1
	    char UnknownData177[0x7fe1]; // 0x7fe1
	    static struct FRotator MakeRotFromXZ(struct FVector X, struct FVector Z); // 0x0 Size: 0x7fe1
	    char UnknownData178[0x7fe1]; // 0x7fe1
	    static struct FRotator MakeRotFromXY(struct FVector X, struct FVector Y); // 0x0 Size: 0x7fe1
	    char UnknownData179[0x7fe1]; // 0x7fe1
	    static struct FRotator MakeRotFromX(struct FVector X); // 0x0 Size: 0x7fe1
	    char UnknownData180[0x7fe1]; // 0x7fe1
	    static struct FRotator MakeRotator(float Roll, float Pitch, float Yaw); // 0x0 Size: 0x7fe1
	    char UnknownData181[0x7fe1]; // 0x7fe1
	    static struct FRotator MakeRotationFromAxes(struct FVector Forward, struct FVector Right, struct FVector Up); // 0x0 Size: 0x7fe1
	    char UnknownData182[0x7fe1]; // 0x7fe1
	    static struct FTransform MakeRelativeTransform(struct FTransform A, struct FTransform RelativeTo); // 0x0 Size: 0x7fe1
	    char UnknownData183[0x7fe1]; // 0x7fe1
	    static struct FRandomStream MakeRandomStream(int InitialSeed); // 0x0 Size: 0x7fe1
	    char UnknownData184[0x7fe1]; // 0x7fe1
	    static struct FQualifiedFrameTime MakeQualifiedFrameTime(struct FFrameNumber Frame, struct FFrameRate FrameRate, float SubFrame); // 0x0 Size: 0x7fe1
	    char UnknownData185[0x7fe1]; // 0x7fe1
	    static float MakePulsatingValue(float InCurrentTime, float InPulsesPerSecond, float InPhase); // 0x0 Size: 0x7fe1
	    char UnknownData186[0x7fe1]; // 0x7fe1
	    static struct FPlane MakePlaneFromPointAndNormal(struct FVector Point, struct FVector Normal); // 0x0 Size: 0x7fe1
	    char UnknownData187[0x7fe1]; // 0x7fe1
	    static struct FFrameRate MakeFrameRate(int Numerator, int Denominator); // 0x0 Size: 0x7fe1
	    char UnknownData188[0x7fe1]; // 0x7fe1
	    static struct FDateTime MakeDateTime(int Year, int Month, int Day, int Hour, int Minute, int Second, int Millisecond); // 0x0 Size: 0x7fe1
	    char UnknownData189[0x7fe1]; // 0x7fe1
	    static struct FLinearColor MakeColor(float R, float G, float B, float A); // 0x0 Size: 0x7fe1
	    char UnknownData190[0x7fe1]; // 0x7fe1
	    static struct FBox2D MakeBox2D(struct FVector2D Min, struct FVector2D Max); // 0x0 Size: 0x7fe1
	    char UnknownData191[0x7fe1]; // 0x7fe1
	    static struct FBox MakeBox(struct FVector Min, struct FVector Max); // 0x0 Size: 0x7fe1
	    char UnknownData192[0x7fe1]; // 0x7fe1
	    static float Loge(float A); // 0x0 Size: 0x7fe1
	    char UnknownData193[0x7fe1]; // 0x7fe1
	    static float Log(float A, float Base); // 0x0 Size: 0x7fe1
	    char UnknownData194[0x7fe1]; // 0x7fe1
	    static bool LinePlaneIntersection_OriginNormal(struct FVector LineStart, struct FVector LineEnd, struct FVector PlaneOrigin, struct FVector PlaneNormal, float T, struct FVector Intersection); // 0x0 Size: 0x7fe1
	    char UnknownData195[0x7fe1]; // 0x7fe1
	    static bool LinePlaneIntersection(struct FVector LineStart, struct FVector LineEnd, struct FPlane APlane, float T, struct FVector Intersection); // 0x0 Size: 0x7fe1
	    char UnknownData196[0x7fe1]; // 0x7fe1
	    static struct FLinearColor LinearColorLerpUsingHSV(struct FLinearColor A, struct FLinearColor B, float Alpha); // 0x0 Size: 0x7fe1
	    char UnknownData197[0x7fe1]; // 0x7fe1
	    static struct FLinearColor LinearColorLerp(struct FLinearColor A, struct FLinearColor B, float Alpha); // 0x0 Size: 0x7fe1
	    char UnknownData198[0x7fe1]; // 0x7fe1
	    static struct FVector LessLess_VectorRotator(struct FVector A, struct FRotator B); // 0x0 Size: 0x7fe1
	    char UnknownData199[0x7fe1]; // 0x7fe1
	    static bool LessEqual_TimespanTimespan(struct FTimespan A, struct FTimespan B); // 0x0 Size: 0x7fe1
	    char UnknownData200[0x7fe1]; // 0x7fe1
	    static bool LessEqual_IntInt(int A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData201[0x7fe1]; // 0x7fe1
	    static bool LessEqual_Int64Int64(int64_t A, int64_t B); // 0x0 Size: 0x7fe1
	    char UnknownData202[0x7fe1]; // 0x7fe1
	    static bool LessEqual_FloatFloat(float A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData203[0x7fe1]; // 0x7fe1
	    static bool LessEqual_DateTimeDateTime(struct FDateTime A, struct FDateTime B); // 0x0 Size: 0x7fe1
	    char UnknownData204[0x7fe1]; // 0x7fe1
	    static bool LessEqual_ByteByte(char A, char B); // 0x0 Size: 0x7fe1
	    char UnknownData205[0x7fe1]; // 0x7fe1
	    static bool Less_TimespanTimespan(struct FTimespan A, struct FTimespan B); // 0x0 Size: 0x7fe1
	    char UnknownData206[0x7fe1]; // 0x7fe1
	    static bool Less_IntInt(int A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData207[0x7fe1]; // 0x7fe1
	    static bool Less_Int64Int64(int64_t A, int64_t B); // 0x0 Size: 0x7fe1
	    char UnknownData208[0x7fe1]; // 0x7fe1
	    static bool Less_FloatFloat(float A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData209[0x7fe1]; // 0x7fe1
	    static bool Less_DateTimeDateTime(struct FDateTime A, struct FDateTime B); // 0x0 Size: 0x7fe1
	    char UnknownData210[0x7fe1]; // 0x7fe1
	    static bool Less_ByteByte(char A, char B); // 0x0 Size: 0x7fe1
	    char UnknownData211[0x7fe1]; // 0x7fe1
	    static float Lerp(float A, float B, float Alpha); // 0x0 Size: 0x7fe1
	    char UnknownData212[0x7fe1]; // 0x7fe1
	    static bool IsPointInBoxWithTransform(struct FVector Point, struct FTransform BoxWorldTransform, struct FVector BoxExtent); // 0x0 Size: 0x7fe1
	    char UnknownData213[0x7fe1]; // 0x7fe1
	    static bool IsPointInBox(struct FVector Point, struct FVector BoxOrigin, struct FVector BoxExtent); // 0x0 Size: 0x7fe1
	    char UnknownData214[0x7fe1]; // 0x7fe1
	    static bool IsMorning(struct FDateTime A); // 0x0 Size: 0x7fe1
	    char UnknownData215[0x7fe1]; // 0x7fe1
	    static bool IsLeapYear(int Year); // 0x0 Size: 0x7fe1
	    char UnknownData216[0x7fe1]; // 0x7fe1
	    static bool IsAfternoon(struct FDateTime A); // 0x0 Size: 0x7fe1
	    char UnknownData217[0x7fe1]; // 0x7fe1
	    static struct FTransform InvertTransform(struct FTransform T); // 0x0 Size: 0x7fe1
	    char UnknownData218[0x7fe1]; // 0x7fe1
	    static struct FRotator InverseTransformRotation(struct FTransform T, struct FRotator Rotation); // 0x0 Size: 0x7fe1
	    char UnknownData219[0x7fe1]; // 0x7fe1
	    static struct FVector InverseTransformLocation(struct FTransform T, struct FVector Location); // 0x0 Size: 0x7fe1
	    char UnknownData220[0x7fe1]; // 0x7fe1
	    static struct FVector InverseTransformDirection(struct FTransform T, struct FVector Direction); // 0x0 Size: 0x7fe1
	    char UnknownData221[0x7fe1]; // 0x7fe1
	    static bool InRange_IntInt(int Value, int Min, int Max, bool InclusiveMin, bool InclusiveMax); // 0x0 Size: 0x7fe1
	    char UnknownData222[0x7fe1]; // 0x7fe1
	    static bool InRange_Int64Int64(int64_t Value, int64_t Min, int64_t Max, bool InclusiveMin, bool InclusiveMax); // 0x0 Size: 0x7fe1
	    char UnknownData223[0x7fe1]; // 0x7fe1
	    static bool InRange_FloatFloat(float Value, float Min, float Max, bool InclusiveMin, bool InclusiveMax); // 0x0 Size: 0x7fe1
	    char UnknownData224[0x7fe1]; // 0x7fe1
	    static float Hypotenuse(float Width, float Height); // 0x0 Size: 0x7fe1
	    char UnknownData225[0x7fe1]; // 0x7fe1
	    static void HSVToRGB_Vector(struct FLinearColor HSV, struct FLinearColor RGB); // 0x0 Size: 0x7fe1
	    char UnknownData226[0x7fe1]; // 0x7fe1
	    static struct FLinearColor HSVToRGB(float H, float S, float V, float A); // 0x0 Size: 0x7fe1
	    char UnknownData227[0x7fe1]; // 0x7fe1
	    static float GridSnap_Float(float Location, float GridSize); // 0x0 Size: 0x7fe1
	    char UnknownData228[0x7fe1]; // 0x7fe1
	    static struct FVector GreaterGreater_VectorRotator(struct FVector A, struct FRotator B); // 0x0 Size: 0x7fe1
	    char UnknownData229[0x7fe1]; // 0x7fe1
	    static bool GreaterEqual_TimespanTimespan(struct FTimespan A, struct FTimespan B); // 0x0 Size: 0x7fe1
	    char UnknownData230[0x7fe1]; // 0x7fe1
	    static bool GreaterEqual_IntInt(int A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData231[0x7fe1]; // 0x7fe1
	    static bool GreaterEqual_Int64Int64(int64_t A, int64_t B); // 0x0 Size: 0x7fe1
	    char UnknownData232[0x7fe1]; // 0x7fe1
	    static bool GreaterEqual_FloatFloat(float A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData233[0x7fe1]; // 0x7fe1
	    static bool GreaterEqual_DateTimeDateTime(struct FDateTime A, struct FDateTime B); // 0x0 Size: 0x7fe1
	    char UnknownData234[0x7fe1]; // 0x7fe1
	    static bool GreaterEqual_ByteByte(char A, char B); // 0x0 Size: 0x7fe1
	    char UnknownData235[0x7fe1]; // 0x7fe1
	    static bool Greater_TimespanTimespan(struct FTimespan A, struct FTimespan B); // 0x0 Size: 0x7fe1
	    char UnknownData236[0x7fe1]; // 0x7fe1
	    static bool Greater_IntInt(int A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData237[0x7fe1]; // 0x7fe1
	    static bool Greater_Int64Int64(int64_t A, int64_t B); // 0x0 Size: 0x7fe1
	    char UnknownData238[0x7fe1]; // 0x7fe1
	    static bool Greater_FloatFloat(float A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData239[0x7fe1]; // 0x7fe1
	    static bool Greater_DateTimeDateTime(struct FDateTime A, struct FDateTime B); // 0x0 Size: 0x7fe1
	    char UnknownData240[0x7fe1]; // 0x7fe1
	    static bool Greater_ByteByte(char A, char B); // 0x0 Size: 0x7fe1
	    char UnknownData241[0x7fe1]; // 0x7fe1
	    static int GetYear(struct FDateTime A); // 0x0 Size: 0x7fe1
	    char UnknownData242[0x7fe1]; // 0x7fe1
	    static void GetYawPitchFromVector(struct FVector InVec, float Yaw, float Pitch); // 0x0 Size: 0x7fe1
	    char UnknownData243[0x7fe1]; // 0x7fe1
	    static struct FVector GetVectorArrayAverage(TArray<struct FVector> Vectors); // 0x0 Size: 0x7fe1
	    char UnknownData244[0x7fe1]; // 0x7fe1
	    static struct FVector GetUpVector(struct FRotator InRot); // 0x0 Size: 0x7fe1
	    char UnknownData245[0x7fe1]; // 0x7fe1
	    static float GetTotalSeconds(struct FTimespan A); // 0x0 Size: 0x7fe1
	    char UnknownData246[0x7fe1]; // 0x7fe1
	    static float GetTotalMinutes(struct FTimespan A); // 0x0 Size: 0x7fe1
	    char UnknownData247[0x7fe1]; // 0x7fe1
	    static float GetTotalMilliseconds(struct FTimespan A); // 0x0 Size: 0x7fe1
	    char UnknownData248[0x7fe1]; // 0x7fe1
	    static float GetTotalHours(struct FTimespan A); // 0x0 Size: 0x7fe1
	    char UnknownData249[0x7fe1]; // 0x7fe1
	    static float GetTotalDays(struct FTimespan A); // 0x0 Size: 0x7fe1
	    char UnknownData250[0x7fe1]; // 0x7fe1
	    static struct FTimespan GetTimeOfDay(struct FDateTime A); // 0x0 Size: 0x7fe1
	    char UnknownData251[0x7fe1]; // 0x7fe1
	    static float GetTAU(); // 0x0 Size: 0x7fe1
	    char UnknownData252[0x7fe1]; // 0x7fe1
	    static void GetSlopeDegreeAngles(struct FVector MyRightYAxis, struct FVector FloorNormal, struct FVector UpVector, float OutSlopePitchDegreeAngle, float OutSlopeRollDegreeAngle); // 0x0 Size: 0x7fe1
	    char UnknownData253[0x7fe1]; // 0x7fe1
	    static int GetSeconds(struct FTimespan A); // 0x0 Size: 0x7fe1
	    char UnknownData254[0x7fe1]; // 0x7fe1
	    static int GetSecond(struct FDateTime A); // 0x0 Size: 0x7fe1
	    char UnknownData255[0x7fe1]; // 0x7fe1
	    static struct FVector GetRightVector(struct FRotator InRot); // 0x0 Size: 0x7fe1
	    char UnknownData256[0x7fe1]; // 0x7fe1
	    static struct FVector GetReflectionVector(struct FVector Direction, struct FVector SurfaceNormal); // 0x0 Size: 0x7fe1
	    char UnknownData257[0x7fe1]; // 0x7fe1
	    static float GetPointDistanceToSegment(struct FVector Point, struct FVector SegmentStart, struct FVector SegmentEnd); // 0x0 Size: 0x7fe1
	    char UnknownData258[0x7fe1]; // 0x7fe1
	    static float GetPointDistanceToLine(struct FVector Point, struct FVector LineOrigin, struct FVector LineDirection); // 0x0 Size: 0x7fe1
	    char UnknownData259[0x7fe1]; // 0x7fe1
	    static float GetPI(); // 0x0 Size: 0x7fe1
	    char UnknownData260[0x7fe1]; // 0x7fe1
	    static int GetMonth(struct FDateTime A); // 0x0 Size: 0x7fe1
	    char UnknownData261[0x7fe1]; // 0x7fe1
	    static int GetMinutes(struct FTimespan A); // 0x0 Size: 0x7fe1
	    char UnknownData262[0x7fe1]; // 0x7fe1
	    static int GetMinute(struct FDateTime A); // 0x0 Size: 0x7fe1
	    char UnknownData263[0x7fe1]; // 0x7fe1
	    static float GetMinElement(struct FVector A); // 0x0 Size: 0x7fe1
	    char UnknownData264[0x7fe1]; // 0x7fe1
	    static int GetMilliseconds(struct FTimespan A); // 0x0 Size: 0x7fe1
	    char UnknownData265[0x7fe1]; // 0x7fe1
	    static int GetMillisecond(struct FDateTime A); // 0x0 Size: 0x7fe1
	    char UnknownData266[0x7fe1]; // 0x7fe1
	    static float GetMaxElement(struct FVector A); // 0x0 Size: 0x7fe1
	    char UnknownData267[0x7fe1]; // 0x7fe1
	    static int GetHours(struct FTimespan A); // 0x0 Size: 0x7fe1
	    char UnknownData268[0x7fe1]; // 0x7fe1
	    static int GetHour12(struct FDateTime A); // 0x0 Size: 0x7fe1
	    char UnknownData269[0x7fe1]; // 0x7fe1
	    static int GetHour(struct FDateTime A); // 0x0 Size: 0x7fe1
	    char UnknownData270[0x7fe1]; // 0x7fe1
	    static struct FVector GetForwardVector(struct FRotator InRot); // 0x0 Size: 0x7fe1
	    char UnknownData271[0x7fe1]; // 0x7fe1
	    static struct FTimespan GetDuration(struct FTimespan A); // 0x0 Size: 0x7fe1
	    char UnknownData272[0x7fe1]; // 0x7fe1
	    static struct FVector GetDirectionUnitVector(struct FVector From, struct FVector To); // 0x0 Size: 0x7fe1
	    char UnknownData273[0x7fe1]; // 0x7fe1
	    static int GetDays(struct FTimespan A); // 0x0 Size: 0x7fe1
	    char UnknownData274[0x7fe1]; // 0x7fe1
	    static int GetDayOfYear(struct FDateTime A); // 0x0 Size: 0x7fe1
	    char UnknownData275[0x7fe1]; // 0x7fe1
	    static int GetDay(struct FDateTime A); // 0x0 Size: 0x7fe1
	    char UnknownData276[0x7fe1]; // 0x7fe1
	    static struct FDateTime GetDate(struct FDateTime A); // 0x0 Size: 0x7fe1
	    char UnknownData277[0x7fe1]; // 0x7fe1
	    static void GetAzimuthAndElevation(struct FVector InDirection, struct FTransform ReferenceFrame, float Azimuth, float Elevation); // 0x0 Size: 0x7fe1
	    char UnknownData278[0x7fe1]; // 0x7fe1
	    static void GetAxes(struct FRotator A, struct FVector X, struct FVector Y, struct FVector Z); // 0x0 Size: 0x7fe1
	    char UnknownData279[0x7fe1]; // 0x7fe1
	    static struct FIntVector FTruncVector(struct FVector InVector); // 0x0 Size: 0x7fe1
	    char UnknownData280[0x7fe1]; // 0x7fe1
	    static int64_t FTrunc64(float A); // 0x0 Size: 0x7fe1
	    char UnknownData281[0x7fe1]; // 0x7fe1
	    static int FTrunc(float A); // 0x0 Size: 0x7fe1
	    char UnknownData282[0x7fe1]; // 0x7fe1
	    static struct FTimespan FromSeconds(float Seconds); // 0x0 Size: 0x7fe1
	    char UnknownData283[0x7fe1]; // 0x7fe1
	    static struct FTimespan FromMinutes(float Minutes); // 0x0 Size: 0x7fe1
	    char UnknownData284[0x7fe1]; // 0x7fe1
	    static struct FTimespan FromMilliseconds(float Milliseconds); // 0x0 Size: 0x7fe1
	    char UnknownData285[0x7fe1]; // 0x7fe1
	    static struct FTimespan FromHours(float Hours); // 0x0 Size: 0x7fe1
	    char UnknownData286[0x7fe1]; // 0x7fe1
	    static struct FTimespan FromDays(float days); // 0x0 Size: 0x7fe1
	    char UnknownData287[0x7fe1]; // 0x7fe1
	    static float Fraction(float A); // 0x0 Size: 0x7fe1
	    char UnknownData288[0x7fe1]; // 0x7fe1
	    static int FMod(float Dividend, float Divisor, float Remainder); // 0x0 Size: 0x7fe1
	    char UnknownData289[0x7fe1]; // 0x7fe1
	    static float FMin(float A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData290[0x7fe1]; // 0x7fe1
	    static float FMax(float A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData291[0x7fe1]; // 0x7fe1
	    static float FloatSpringInterp(float Current, float Target, struct FFloatSpringState SpringState, float Stiffness, float CriticalDampingFactor, float DeltaTime, float Mass); // 0x0 Size: 0x7fe1
	    char UnknownData292[0x7fe1]; // 0x7fe1
	    static float FixedTurn(float InCurrent, float InDesired, float InDeltaRate); // 0x0 Size: 0x7fe1
	    char UnknownData293[0x7fe1]; // 0x7fe1
	    static float FInterpTo_Constant(float Current, float Target, float DeltaTime, float InterpSpeed); // 0x0 Size: 0x7fe1
	    char UnknownData294[0x7fe1]; // 0x7fe1
	    static float FInterpTo(float Current, float Target, float DeltaTime, float InterpSpeed); // 0x0 Size: 0x7fe1
	    char UnknownData295[0x7fe1]; // 0x7fe1
	    static float FInterpEaseInOut(float A, float B, float Alpha, float Exponent); // 0x0 Size: 0x7fe1
	    char UnknownData296[0x7fe1]; // 0x7fe1
	    static void FindNearestPointsOnLineSegments(struct FVector Segment1Start, struct FVector Segment1End, struct FVector Segment2Start, struct FVector Segment2End, struct FVector Segment1Point, struct FVector Segment2Point); // 0x0 Size: 0x7fe1
	    char UnknownData297[0x7fe1]; // 0x7fe1
	    static struct FRotator FindLookAtRotation(struct FVector Start, struct FVector Target); // 0x0 Size: 0x7fe1
	    char UnknownData298[0x7fe1]; // 0x7fe1
	    static struct FVector FindClosestPointOnSegment(struct FVector Point, struct FVector SegmentStart, struct FVector SegmentEnd); // 0x0 Size: 0x7fe1
	    char UnknownData299[0x7fe1]; // 0x7fe1
	    static struct FVector FindClosestPointOnLine(struct FVector Point, struct FVector LineOrigin, struct FVector LineDirection); // 0x0 Size: 0x7fe1
	    char UnknownData300[0x7fe1]; // 0x7fe1
	    static int64_t FFloor64(float A); // 0x0 Size: 0x7fe1
	    char UnknownData301[0x7fe1]; // 0x7fe1
	    static int FFloor(float A); // 0x0 Size: 0x7fe1
	    char UnknownData302[0x7fe1]; // 0x7fe1
	    static float FClamp(float Value, float Min, float Max); // 0x0 Size: 0x7fe1
	    char UnknownData303[0x7fe1]; // 0x7fe1
	    static int64_t FCeil64(float A); // 0x0 Size: 0x7fe1
	    char UnknownData304[0x7fe1]; // 0x7fe1
	    static int FCeil(float A); // 0x0 Size: 0x7fe1
	    char UnknownData305[0x7fe1]; // 0x7fe1
	    static float Exp(float A); // 0x0 Size: 0x7fe1
	    char UnknownData306[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_VectorVector(struct FVector A, struct FVector B, float ErrorTolerance); // 0x0 Size: 0x7fe1
	    char UnknownData307[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_Vector2DVector2D(struct FVector2D A, struct FVector2D B, float ErrorTolerance); // 0x0 Size: 0x7fe1
	    char UnknownData308[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_TransformTransform(struct FTransform A, struct FTransform B); // 0x0 Size: 0x7fe1
	    char UnknownData309[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_TimespanTimespan(struct FTimespan A, struct FTimespan B); // 0x0 Size: 0x7fe1
	    char UnknownData310[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_RotatorRotator(struct FRotator A, struct FRotator B, float ErrorTolerance); // 0x0 Size: 0x7fe1
	    char UnknownData311[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_ObjectObject(class UObject* A, class UObject* B); // 0x0 Size: 0x7fe1
	    char UnknownData312[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_NameName(FName A, FName B); // 0x0 Size: 0x7fe1
	    char UnknownData313[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_IntInt(int A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData314[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_Int64Int64(int64_t A, int64_t B); // 0x0 Size: 0x7fe1
	    char UnknownData315[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_FloatFloat(float A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData316[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_DateTimeDateTime(struct FDateTime A, struct FDateTime B); // 0x0 Size: 0x7fe1
	    char UnknownData317[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_ClassClass(class UObject* A, class UObject* B); // 0x0 Size: 0x7fe1
	    char UnknownData318[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_ByteByte(char A, char B); // 0x0 Size: 0x7fe1
	    char UnknownData319[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_BoolBool(bool A, bool B); // 0x0 Size: 0x7fe1
	    char UnknownData320[0x7fe1]; // 0x7fe1
	    static float Ease(float A, float B, float Alpha, char EasingFunc, float BlendExp, int Steps); // 0x0 Size: 0x7fe1
	    char UnknownData321[0x7fe1]; // 0x7fe1
	    static float DotProduct2D(struct FVector2D A, struct FVector2D B); // 0x0 Size: 0x7fe1
	    char UnknownData322[0x7fe1]; // 0x7fe1
	    static float Dot_VectorVector(struct FVector A, struct FVector B); // 0x0 Size: 0x7fe1
	    char UnknownData323[0x7fe1]; // 0x7fe1
	    static struct FVector Divide_VectorVector(struct FVector A, struct FVector B); // 0x0 Size: 0x7fe1
	    char UnknownData324[0x7fe1]; // 0x7fe1
	    static struct FVector Divide_VectorInt(struct FVector A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData325[0x7fe1]; // 0x7fe1
	    static struct FVector Divide_VectorFloat(struct FVector A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData326[0x7fe1]; // 0x7fe1
	    static struct FVector2D Divide_Vector2DVector2D(struct FVector2D A, struct FVector2D B); // 0x0 Size: 0x7fe1
	    char UnknownData327[0x7fe1]; // 0x7fe1
	    static struct FVector2D Divide_Vector2DFloat(struct FVector2D A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData328[0x7fe1]; // 0x7fe1
	    static struct FTimespan Divide_TimespanFloat(struct FTimespan A, float Scalar); // 0x0 Size: 0x7fe1
	    char UnknownData329[0x7fe1]; // 0x7fe1
	    static int Divide_IntInt(int A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData330[0x7fe1]; // 0x7fe1
	    static int64_t Divide_Int64Int64(int64_t A, int64_t B); // 0x0 Size: 0x7fe1
	    char UnknownData331[0x7fe1]; // 0x7fe1
	    static float Divide_FloatFloat(float A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData332[0x7fe1]; // 0x7fe1
	    static char Divide_ByteByte(char A, char B); // 0x0 Size: 0x7fe1
	    char UnknownData333[0x7fe1]; // 0x7fe1
	    static float DegTan(float A); // 0x0 Size: 0x7fe1
	    char UnknownData334[0x7fe1]; // 0x7fe1
	    static float DegSin(float A); // 0x0 Size: 0x7fe1
	    char UnknownData335[0x7fe1]; // 0x7fe1
	    static float DegreesToRadians(float A); // 0x0 Size: 0x7fe1
	    char UnknownData336[0x7fe1]; // 0x7fe1
	    static float DegCos(float A); // 0x0 Size: 0x7fe1
	    char UnknownData337[0x7fe1]; // 0x7fe1
	    static float DegAtan2(float A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData338[0x7fe1]; // 0x7fe1
	    static float DegAtan(float A); // 0x0 Size: 0x7fe1
	    char UnknownData339[0x7fe1]; // 0x7fe1
	    static float DegAsin(float A); // 0x0 Size: 0x7fe1
	    char UnknownData340[0x7fe1]; // 0x7fe1
	    static float DegAcos(float A); // 0x0 Size: 0x7fe1
	    char UnknownData341[0x7fe1]; // 0x7fe1
	    static int DaysInYear(int Year); // 0x0 Size: 0x7fe1
	    char UnknownData342[0x7fe1]; // 0x7fe1
	    static int DaysInMonth(int Year, int Month); // 0x0 Size: 0x7fe1
	    char UnknownData343[0x7fe1]; // 0x7fe1
	    static struct FDateTime DateTimeMinValue(); // 0x0 Size: 0x7fe1
	    char UnknownData344[0x7fe1]; // 0x7fe1
	    static struct FDateTime DateTimeMaxValue(); // 0x0 Size: 0x7fe1
	    char UnknownData345[0x7fe1]; // 0x7fe1
	    static bool DateTimeFromString(struct FString DateTimeString, struct FDateTime Result); // 0x0 Size: 0x7fe1
	    char UnknownData346[0x7fe1]; // 0x7fe1
	    static bool DateTimeFromIsoString(struct FString IsoString, struct FDateTime Result); // 0x0 Size: 0x7fe1
	    char UnknownData347[0x7fe1]; // 0x7fe1
	    static float CrossProduct2D(struct FVector2D A, struct FVector2D B); // 0x0 Size: 0x7fe1
	    char UnknownData348[0x7fe1]; // 0x7fe1
	    static struct FVector Cross_VectorVector(struct FVector A, struct FVector B); // 0x0 Size: 0x7fe1
	    char UnknownData349[0x7fe1]; // 0x7fe1
	    static struct FVector CreateVectorFromYawPitch(float Yaw, float Pitch, float Length); // 0x0 Size: 0x7fe1
	    char UnknownData350[0x7fe1]; // 0x7fe1
	    static float Cos(float A); // 0x0 Size: 0x7fe1
	    char UnknownData351[0x7fe1]; // 0x7fe1
	    static struct FVector2D Conv_VectorToVector2D(struct FVector InVector); // 0x0 Size: 0x7fe1
	    char UnknownData352[0x7fe1]; // 0x7fe1
	    static struct FTransform Conv_VectorToTransform(struct FVector InLocation); // 0x0 Size: 0x7fe1
	    char UnknownData353[0x7fe1]; // 0x7fe1
	    static struct FRotator Conv_VectorToRotator(struct FVector InVec); // 0x0 Size: 0x7fe1
	    char UnknownData354[0x7fe1]; // 0x7fe1
	    static struct FLinearColor Conv_VectorToLinearColor(struct FVector InVec); // 0x0 Size: 0x7fe1
	    char UnknownData355[0x7fe1]; // 0x7fe1
	    static struct FVector Conv_Vector2DToVector(struct FVector2D InVector2D, float Z); // 0x0 Size: 0x7fe1
	    char UnknownData356[0x7fe1]; // 0x7fe1
	    static struct FVector Conv_RotatorToVector(struct FRotator InRot); // 0x0 Size: 0x7fe1
	    char UnknownData357[0x7fe1]; // 0x7fe1
	    static struct FTransform Conv_RotatorToTransform(struct FRotator InRotator); // 0x0 Size: 0x7fe1
	    char UnknownData358[0x7fe1]; // 0x7fe1
	    static struct FTransform Conv_MatrixToTransform(struct FMatrix InMatrix); // 0x0 Size: 0x7fe1
	    char UnknownData359[0x7fe1]; // 0x7fe1
	    static struct FRotator Conv_MatrixToRotator(struct FMatrix InMatrix); // 0x0 Size: 0x7fe1
	    char UnknownData360[0x7fe1]; // 0x7fe1
	    static struct FVector Conv_LinearColorToVector(struct FLinearColor InLinearColor); // 0x0 Size: 0x7fe1
	    char UnknownData361[0x7fe1]; // 0x7fe1
	    static struct FColor Conv_LinearColorToColor(struct FLinearColor InLinearColor); // 0x0 Size: 0x7fe1
	    char UnknownData362[0x7fe1]; // 0x7fe1
	    static struct FVector Conv_IntVectorToVector(struct FIntVector InIntVector); // 0x0 Size: 0x7fe1
	    char UnknownData363[0x7fe1]; // 0x7fe1
	    static struct FIntVector Conv_IntToIntVector(int inInt); // 0x0 Size: 0x7fe1
	    char UnknownData364[0x7fe1]; // 0x7fe1
	    static int64_t Conv_IntToInt64(int inInt); // 0x0 Size: 0x7fe1
	    char UnknownData365[0x7fe1]; // 0x7fe1
	    static float Conv_IntToFloat(int inInt); // 0x0 Size: 0x7fe1
	    char UnknownData366[0x7fe1]; // 0x7fe1
	    static char Conv_IntToByte(int inInt); // 0x0 Size: 0x7fe1
	    char UnknownData367[0x7fe1]; // 0x7fe1
	    static bool Conv_IntToBool(int inInt); // 0x0 Size: 0x7fe1
	    char UnknownData368[0x7fe1]; // 0x7fe1
	    static struct FVector Conv_FloatToVector(float InFloat); // 0x0 Size: 0x7fe1
	    char UnknownData369[0x7fe1]; // 0x7fe1
	    static struct FLinearColor Conv_FloatToLinearColor(float InFloat); // 0x0 Size: 0x7fe1
	    char UnknownData370[0x7fe1]; // 0x7fe1
	    static struct FLinearColor Conv_ColorToLinearColor(struct FColor InColor); // 0x0 Size: 0x7fe1
	    char UnknownData371[0x7fe1]; // 0x7fe1
	    static int Conv_ByteToInt(char InByte); // 0x0 Size: 0x7fe1
	    char UnknownData372[0x7fe1]; // 0x7fe1
	    static float Conv_ByteToFloat(char InByte); // 0x0 Size: 0x7fe1
	    char UnknownData373[0x7fe1]; // 0x7fe1
	    static int Conv_BoolToInt(bool InBool); // 0x0 Size: 0x7fe1
	    char UnknownData374[0x7fe1]; // 0x7fe1
	    static float Conv_BoolToFloat(bool InBool); // 0x0 Size: 0x7fe1
	    char UnknownData375[0x7fe1]; // 0x7fe1
	    static char Conv_BoolToByte(bool InBool); // 0x0 Size: 0x7fe1
	    char UnknownData376[0x7fe1]; // 0x7fe1
	    static struct FTransform ComposeTransforms(struct FTransform A, struct FTransform B); // 0x0 Size: 0x7fe1
	    char UnknownData377[0x7fe1]; // 0x7fe1
	    static struct FRotator ComposeRotators(struct FRotator A, struct FRotator B); // 0x0 Size: 0x7fe1
	    char UnknownData378[0x7fe1]; // 0x7fe1
	    static bool ClassIsChildOf(class UObject* TestClass, class UObject* ParentClass); // 0x0 Size: 0x7fe1
	    char UnknownData379[0x7fe1]; // 0x7fe1
	    static struct FVector ClampVectorSize(struct FVector A, float Min, float Max); // 0x0 Size: 0x7fe1
	    char UnknownData380[0x7fe1]; // 0x7fe1
	    static int64_t ClampInt64(int64_t Value, int64_t Min, int64_t Max); // 0x0 Size: 0x7fe1
	    char UnknownData381[0x7fe1]; // 0x7fe1
	    static float ClampAxis(float Angle); // 0x0 Size: 0x7fe1
	    char UnknownData382[0x7fe1]; // 0x7fe1
	    static float ClampAngle(float AngleDegrees, float MinAngleDegrees, float MaxAngleDegrees); // 0x0 Size: 0x7fe1
	    char UnknownData383[0x7fe1]; // 0x7fe1
	    static int Clamp(int Value, int Min, int Max); // 0x0 Size: 0x7fe1
	    char UnknownData384[0x7fe1]; // 0x7fe1
	    static struct FLinearColor CInterpTo(struct FLinearColor Current, struct FLinearColor Target, float DeltaTime, float InterpSpeed); // 0x0 Size: 0x7fe1
	    char UnknownData385[0x7fe1]; // 0x7fe1
	    static void BreakVector2D(struct FVector2D InVec, float X, float Y); // 0x0 Size: 0x7fe1
	    char UnknownData386[0x7fe1]; // 0x7fe1
	    static void BreakVector(struct FVector InVec, float X, float Y, float Z); // 0x0 Size: 0x7fe1
	    char UnknownData387[0x7fe1]; // 0x7fe1
	    static void BreakTransform(struct FTransform InTransform, struct FVector Location, struct FRotator Rotation, struct FVector Scale); // 0x0 Size: 0x7fe1
	    char UnknownData388[0x7fe1]; // 0x7fe1
	    static void BreakTimespan2(struct FTimespan InTimespan, int days, int Hours, int Minutes, int Seconds, int FractionNano); // 0x0 Size: 0x7fe1
	    char UnknownData389[0x7fe1]; // 0x7fe1
	    static void BreakTimespan(struct FTimespan InTimespan, int days, int Hours, int Minutes, int Seconds, int Milliseconds); // 0x0 Size: 0x7fe1
	    char UnknownData390[0x7fe1]; // 0x7fe1
	    static void BreakRotIntoAxes(struct FRotator InRot, struct FVector X, struct FVector Y, struct FVector Z); // 0x0 Size: 0x7fe1
	    char UnknownData391[0x7fe1]; // 0x7fe1
	    static void BreakRotator(struct FRotator InRot, float Roll, float Pitch, float Yaw); // 0x0 Size: 0x7fe1
	    char UnknownData392[0x7fe1]; // 0x7fe1
	    static void BreakRandomStream(struct FRandomStream InRandomStream, int InitialSeed); // 0x0 Size: 0x7fe1
	    char UnknownData393[0x7fe1]; // 0x7fe1
	    static void BreakQualifiedFrameTime(struct FQualifiedFrameTime InFrameTime, struct FFrameNumber Frame, struct FFrameRate FrameRate, float SubFrame); // 0x0 Size: 0x7fe1
	    char UnknownData394[0x7fe1]; // 0x7fe1
	    static void BreakFrameRate(struct FFrameRate InFrameRate, int Numerator, int Denominator); // 0x0 Size: 0x7fe1
	    char UnknownData395[0x7fe1]; // 0x7fe1
	    static void BreakDateTime(struct FDateTime InDateTime, int Year, int Month, int Day, int Hour, int Minute, int Second, int Millisecond); // 0x0 Size: 0x7fe1
	    char UnknownData396[0x7fe1]; // 0x7fe1
	    static void BreakColor(struct FLinearColor InColor, float R, float G, float B, float A); // 0x0 Size: 0x7fe1
	    char UnknownData397[0x7fe1]; // 0x7fe1
	    static bool BooleanXOR(bool A, bool B); // 0x0 Size: 0x7fe1
	    char UnknownData398[0x7fe1]; // 0x7fe1
	    static bool BooleanOR(bool A, bool B); // 0x0 Size: 0x7fe1
	    char UnknownData399[0x7fe1]; // 0x7fe1
	    static bool BooleanNOR(bool A, bool B); // 0x0 Size: 0x7fe1
	    char UnknownData400[0x7fe1]; // 0x7fe1
	    static bool BooleanNAND(bool A, bool B); // 0x0 Size: 0x7fe1
	    char UnknownData401[0x7fe1]; // 0x7fe1
	    static bool BooleanAND(bool A, bool B); // 0x0 Size: 0x7fe1
	    char UnknownData402[0x7fe1]; // 0x7fe1
	    static char BMin(char A, char B); // 0x0 Size: 0x7fe1
	    char UnknownData403[0x7fe1]; // 0x7fe1
	    static char BMax(char A, char B); // 0x0 Size: 0x7fe1
	    char UnknownData404[0x7fe1]; // 0x7fe1
	    static float Atan2(float A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData405[0x7fe1]; // 0x7fe1
	    static float Atan(float A); // 0x0 Size: 0x7fe1
	    char UnknownData406[0x7fe1]; // 0x7fe1
	    static float Asin(float A); // 0x0 Size: 0x7fe1
	    char UnknownData407[0x7fe1]; // 0x7fe1
	    static int And_IntInt(int A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData408[0x7fe1]; // 0x7fe1
	    static int64_t And_Int64Int64(int64_t A, int64_t B); // 0x0 Size: 0x7fe1
	    char UnknownData409[0x7fe1]; // 0x7fe1
	    static struct FVector Add_VectorVector(struct FVector A, struct FVector B); // 0x0 Size: 0x7fe1
	    char UnknownData410[0x7fe1]; // 0x7fe1
	    static struct FVector Add_VectorInt(struct FVector A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData411[0x7fe1]; // 0x7fe1
	    static struct FVector Add_VectorFloat(struct FVector A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData412[0x7fe1]; // 0x7fe1
	    static struct FVector2D Add_Vector2DVector2D(struct FVector2D A, struct FVector2D B); // 0x0 Size: 0x7fe1
	    char UnknownData413[0x7fe1]; // 0x7fe1
	    static struct FVector2D Add_Vector2DFloat(struct FVector2D A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData414[0x7fe1]; // 0x7fe1
	    static struct FTimespan Add_TimespanTimespan(struct FTimespan A, struct FTimespan B); // 0x0 Size: 0x7fe1
	    char UnknownData415[0x7fe1]; // 0x7fe1
	    static int Add_IntInt(int A, int B); // 0x0 Size: 0x7fe1
	    char UnknownData416[0x7fe1]; // 0x7fe1
	    static int64_t Add_Int64Int64(int64_t A, int64_t B); // 0x0 Size: 0x7fe1
	    char UnknownData417[0x7fe1]; // 0x7fe1
	    static float Add_FloatFloat(float A, float B); // 0x0 Size: 0x7fe1
	    char UnknownData418[0x7fe1]; // 0x7fe1
	    static struct FDateTime Add_DateTimeTimespan(struct FDateTime A, struct FTimespan B); // 0x0 Size: 0x7fe1
	    char UnknownData419[0x7fe1]; // 0x7fe1
	    static char Add_ByteByte(char A, char B); // 0x0 Size: 0x7fe1
	    char UnknownData420[0x7fe1]; // 0x7fe1
	    static float Acos(float A); // 0x0 Size: 0x7fe1
	    char UnknownData421[0x7fe1]; // 0x7fe1
	    static int64_t Abs_Int64(int64_t A); // 0x0 Size: 0x7fe1
	    char UnknownData422[0x7fe1]; // 0x7fe1
	    static int Abs_Int(int A); // 0x0 Size: 0x7fe1
	    char UnknownData423[0x7fe1]; // 0x7fe1
	    static float Abs(float A); // 0x0 Size: 0x7fe1
	    char UnknownData424[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.KismetMathLibrary");
			return (class UClass*)ptr;
		};

};

class UKismetNodeHelperLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void MarkBit(int Data, int Index); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static bool HasUnmarkedBit(int Data, int NumBits); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static bool HasMarkedBit(int Data, int NumBits); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static char GetValidValue(class UEnum* Enum, char EnumeratorValue); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static int GetUnmarkedBit(int Data, int StartIdx, int NumBits, bool bRandom); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static int GetRandomUnmarkedBit(int Data, int StartIdx, int NumBits); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static int GetFirstUnmarkedBit(int Data, int StartIdx, int NumBits); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static char GetEnumeratorValueFromIndex(class UEnum* Enum, char EnumeratorIndex); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static struct FString GetEnumeratorUserFriendlyName(class UEnum* Enum, char EnumeratorValue); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static FName GetEnumeratorName(class UEnum* Enum, char EnumeratorValue); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static void ClearBit(int Data, int Index); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static void ClearAllBits(int Data); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    static bool BitIsMarked(int Data, int Index); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.KismetNodeHelperLibrary");
			return (class UClass*)ptr;
		};

};

class UKismetRenderingLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static class UTexture2D* RenderTargetCreateStaticTexture2DEditorOnly(class UTextureRenderTarget2D* RenderTarget, struct FString Name, char CompressionSettings, char MipSettings); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void ReleaseRenderTarget2D(class UTextureRenderTarget2D* TextureRenderTarget); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static struct FColor ReadRenderTargetUV(class UObject* WorldContextObject, class UTextureRenderTarget2D* TextureRenderTarget, float U, float V); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static struct FLinearColor ReadRenderTargetRawUV(class UObject* WorldContextObject, class UTextureRenderTarget2D* TextureRenderTarget, float U, float V); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static struct FLinearColor ReadRenderTargetRawPixel(class UObject* WorldContextObject, class UTextureRenderTarget2D* TextureRenderTarget, int X, int Y); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static struct FColor ReadRenderTargetPixel(class UObject* WorldContextObject, class UTextureRenderTarget2D* TextureRenderTarget, int X, int Y); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static struct FSkelMeshSkinWeightInfo MakeSkinWeightInfo(int Bone0, char Weight0, int Bone1, char Weight1, int Bone2, char Weight2, int Bone3, char Weight3); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static class UTexture2D* ImportFileAsTexture2D(class UObject* WorldContextObject, struct FString Filename); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static class UTexture2D* ImportBufferAsTexture2D(class UObject* WorldContextObject, TArray<char> Buffer); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static void ExportTexture2D(class UObject* WorldContextObject, class UTexture2D* Texture, struct FString FilePath, struct FString Filename); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static void ExportRenderTarget(class UObject* WorldContextObject, class UTextureRenderTarget2D* TextureRenderTarget, struct FString FilePath, struct FString Filename); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static void EndDrawCanvasToRenderTarget(class UObject* WorldContextObject, struct FDrawToRenderTargetContext Context); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    static void DrawMaterialToRenderTarget(class UObject* WorldContextObject, class UTextureRenderTarget2D* TextureRenderTarget, class UMaterialInterface* Material); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    static class UTextureRenderTarget2D* CreateRenderTarget2D(class UObject* WorldContextObject, int Width, int Height, char Format); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    static void ConvertRenderTargetToTexture2DEditorOnly(class UObject* WorldContextObject, class UTextureRenderTarget2D* RenderTarget, class UTexture2D* Texture); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    static void ClearRenderTarget2D(class UObject* WorldContextObject, class UTextureRenderTarget2D* TextureRenderTarget, struct FLinearColor ClearColor); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    static void BreakSkinWeightInfo(struct FSkelMeshSkinWeightInfo InWeight, int Bone0, char Weight0, int Bone1, char Weight1, int Bone2, char Weight2, int Bone3, char Weight3); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    static void BeginDrawCanvasToRenderTarget(class UObject* WorldContextObject, class UTextureRenderTarget2D* TextureRenderTarget, class UCanvas* Canvas, struct FVector2D Size, struct FDrawToRenderTargetContext Context); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.KismetRenderingLibrary");
			return (class UClass*)ptr;
		};

};

class UKismetStringLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static struct FString TrimTrailing(struct FString SourceString); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static struct FString Trim(struct FString SourceString); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static struct FString ToUpper(struct FString SourceString); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static struct FString ToLower(struct FString SourceString); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static struct FString TimeSecondsToString(float InSeconds); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static bool StartsWith(struct FString SourceString, struct FString InPrefix, char SearchCase); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static bool Split(struct FString SourceString, struct FString InStr, struct FString LeftS, struct FString RightS, char SearchCase, char SearchDir); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static struct FString RightPad(struct FString SourceString, int ChCount); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static struct FString RightChop(struct FString SourceString, int Count); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static struct FString Right(struct FString SourceString, int Count); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static struct FString Reverse(struct FString SourceString); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static int ReplaceInline(struct FString SourceString, struct FString SearchText, struct FString ReplacementText, char SearchCase); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    static struct FString Replace(struct FString SourceString, struct FString From, struct FString To, char SearchCase); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    static TArray<struct FString> ParseIntoArray(struct FString SourceString, struct FString Delimiter, bool CullEmptyStrings); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    static bool NotEqual_StrStr(struct FString A, struct FString B); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    static bool NotEqual_StriStri(struct FString A, struct FString B); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    static struct FString Mid(struct FString SourceString, int Start, int Count); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    static bool MatchesWildcard(struct FString SourceString, struct FString Wildcard, char SearchCase); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    static int Len(struct FString S); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    static struct FString LeftPad(struct FString SourceString, int ChCount); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    static struct FString LeftChop(struct FString SourceString, int Count); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    static struct FString Left(struct FString SourceString, int Count); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    static struct FString JoinStringArray(TArray<struct FString> SourceArray, struct FString Separator); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    static bool IsNumeric(struct FString SourceString); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    static struct FString GetSubstring(struct FString SourceString, int StartIndex, int Length); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    static int GetCharacterAsNumber(struct FString SourceString, int Index); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    static TArray<struct FString> GetCharacterArrayFromString(struct FString SourceString); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    static int FindSubstring(struct FString SearchIn, struct FString Substring, bool bUseCase, bool bSearchFromEnd, int StartPosition); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_StrStr(struct FString A, struct FString B); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_StriStri(struct FString A, struct FString B); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    static bool EndsWith(struct FString SourceString, struct FString InSuffix, char SearchCase); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    static int CullArray(struct FString SourceString, TArray<struct FString> inArray); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    static struct FString Conv_VectorToString(struct FVector InVec); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    static struct FString Conv_Vector2dToString(struct FVector2D InVec); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    static struct FString Conv_TransformToString(struct FTransform InTrans); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    static void Conv_StringToVector2D(struct FString inString, struct FVector2D OutConvertedVector2D, bool OutIsValid); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    static void Conv_StringToVector(struct FString inString, struct FVector OutConvertedVector, bool OutIsValid); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    static void Conv_StringToRotator(struct FString inString, struct FRotator OutConvertedRotator, bool OutIsValid); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    static FName Conv_StringToName(struct FString inString); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    static int Conv_StringToInt(struct FString inString); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    static float Conv_StringToFloat(struct FString inString); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    static void Conv_StringToColor(struct FString inString, struct FLinearColor OutConvertedColor, bool OutIsValid); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    static struct FString Conv_RotatorToString(struct FRotator InRot); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    static struct FString Conv_ObjectToString(class UObject* InObj); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    static struct FString Conv_NameToString(FName InName); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    static struct FString Conv_IntVectorToString(struct FIntVector InIntVec); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    static struct FString Conv_IntToString(int inInt); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    static struct FString Conv_FloatToString(float InFloat); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    static struct FString Conv_ColorToString(struct FLinearColor InColor); // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    static struct FString Conv_ByteToString(char InByte); // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    static struct FString Conv_BoolToString(bool InBool); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    static bool Contains(struct FString SearchIn, struct FString Substring, bool bUseCase, bool bSearchFromEnd); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    static struct FString Concat_StrStr(struct FString A, struct FString B); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    static struct FString BuildString_Vector2d(struct FString AppendTo, struct FString Prefix, struct FVector2D InVector2D, struct FString Suffix); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    static struct FString BuildString_Vector(struct FString AppendTo, struct FString Prefix, struct FVector InVector, struct FString Suffix); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    static struct FString BuildString_Rotator(struct FString AppendTo, struct FString Prefix, struct FRotator InRot, struct FString Suffix); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    static struct FString BuildString_Object(struct FString AppendTo, struct FString Prefix, class UObject* InObj, struct FString Suffix); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    static struct FString BuildString_Name(struct FString AppendTo, struct FString Prefix, FName InName, struct FString Suffix); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    static struct FString BuildString_IntVector(struct FString AppendTo, struct FString Prefix, struct FIntVector InIntVector, struct FString Suffix); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    static struct FString BuildString_Int(struct FString AppendTo, struct FString Prefix, int inInt, struct FString Suffix); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    static struct FString BuildString_Float(struct FString AppendTo, struct FString Prefix, float InFloat, struct FString Suffix); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    static struct FString BuildString_Color(struct FString AppendTo, struct FString Prefix, struct FLinearColor InColor, struct FString Suffix); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    static struct FString BuildString_Bool(struct FString AppendTo, struct FString Prefix, bool InBool, struct FString Suffix); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.KismetStringLibrary");
			return (class UClass*)ptr;
		};

};

class UKismetStringTableLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static bool IsRegisteredTableId(FName TableId); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static bool IsRegisteredTableEntry(FName TableId, struct FString Key); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static struct FString GetTableNamespace(FName TableId); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static struct FString GetTableEntrySourceString(FName TableId, struct FString Key); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static struct FString GetTableEntryMetaData(FName TableId, struct FString Key, FName MetaDataId); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static TArray<FName> GetRegisteredStringTables(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static TArray<FName> GetMetaDataIdsFromStringTableEntry(FName TableId, struct FString Key); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static TArray<struct FString> GetKeysFromStringTable(FName TableId); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.KismetStringTableLibrary");
			return (class UClass*)ptr;
		};

};

class UKismetSystemLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void UnregisterForRemoteNotifications(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void UnloadPrimaryAssetList(TArray<struct FPrimaryAssetId> PrimaryAssetIdList); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static void UnloadPrimaryAsset(struct FPrimaryAssetId PrimaryAssetId); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static void TransactObject(class UObject* Object); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static void StackTrace(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static bool SphereTraceSingleForObjects(class UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, TArray<char> ObjectTypes, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static bool SphereTraceSingleByProfile(class UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, FName ProfileName, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static bool SphereTraceSingle(class UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, char TraceChannel, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static bool SphereTraceMultiForObjects(class UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, TArray<char> ObjectTypes, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static bool SphereTraceMultiByProfile(class UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, FName ProfileName, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static bool SphereTraceMulti(class UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, char TraceChannel, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static bool SphereOverlapComponents(class UObject* WorldContextObject, struct FVector SpherePos, float SphereRadius, TArray<char> ObjectTypes, class UObject* ComponentClassFilter, TArray<class AActor*> ActorsToIgnore, TArray<class UPrimitiveComponent*> OutComponents); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    static bool SphereOverlapActors(class UObject* WorldContextObject, struct FVector SpherePos, float SphereRadius, TArray<char> ObjectTypes, class UObject* ActorClassFilter, TArray<class AActor*> ActorsToIgnore, TArray<class AActor*> OutActors); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    static void ShowPlatformSpecificLeaderboardScreen(struct FString CategoryName); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    static void ShowPlatformSpecificAchievementsScreen(class APlayerController* SpecificPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    static void ShowInterstitialAd(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    static void ShowAdBanner(int AdIdIndex, bool bShowOnBottomOfScreen); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    static void SetWindowTitle(struct FText Title); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    static void SetVolumeButtonsHandledBySystem(bool bEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    static void SetVectorPropertyByName(class UObject* Object, FName PropertyName, struct FVector Value); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    static void SetUserActivity(struct FUserActivity UserActivity); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    static void SetTransformPropertyByName(class UObject* Object, FName PropertyName, struct FTransform Value); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    static void SetTextPropertyByName(class UObject* Object, FName PropertyName, struct FText Value); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    static void SetSuppressViewportTransitionMessage(class UObject* WorldContextObject, bool bState); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    static void SetStructurePropertyByName(class UObject* Object, FName PropertyName, struct FGenericStruct Value); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    static void SetStringPropertyByName(class UObject* Object, FName PropertyName, struct FString Value); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    static void SetSoftObjectPropertyByName(class UObject* Object, FName PropertyName, struct TSoftObjectPtr<struct UObject*> Value); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    static void SetSoftClassPropertyByName(class UObject* Object, FName PropertyName, __int64/*SoftClassProperty*/ Value); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    static void SetRotatorPropertyByName(class UObject* Object, FName PropertyName, struct FRotator Value); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    static void SetObjectPropertyByName(class UObject* Object, FName PropertyName, class UObject* Value); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    static void SetNamePropertyByName(class UObject* Object, FName PropertyName, FName Value); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    static void SetLinearColorPropertyByName(class UObject* Object, FName PropertyName, struct FLinearColor Value); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    static void SetIntPropertyByName(class UObject* Object, FName PropertyName, int Value); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    static void SetInterfacePropertyByName(class UObject* Object, FName PropertyName, __int64/*InterfaceProperty*/ Value); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    static void SetInt64PropertyByName(class UObject* Object, FName PropertyName, int64_t Value); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    static void SetFloatPropertyByName(class UObject* Object, FName PropertyName, float Value); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    static void SetCollisionProfileNameProperty(class UObject* Object, FName PropertyName, struct FCollisionProfileName Value); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    static void SetClassPropertyByName(class UObject* Object, FName PropertyName, class UObject* Value); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    static void SetBytePropertyByName(class UObject* Object, FName PropertyName, char Value); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    static void SetBoolPropertyByName(class UObject* Object, FName PropertyName, bool Value); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    static void RetriggerableDelay(class UObject* WorldContextObject, float Duration, struct FLatentActionInfo LatentInfo); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    static void ResetGamepadAssignmentToController(int ControllerId); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    static void ResetGamepadAssignments(); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    static void RegisterForRemoteNotifications(); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    static void QuitGame(class UObject* WorldContextObject, class APlayerController* SpecificPlayer, char QuitPreference, bool bIgnorePlatformRestrictions); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    static void PrintWarning(struct FString inString); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    static void PrintText(class UObject* WorldContextObject, struct FText InText, bool bPrintToScreen, bool bPrintToLog, struct FLinearColor TextColor, float Duration); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x7fe1]; // 0x7fe1
	    static void PrintString(class UObject* WorldContextObject, struct FString inString, bool bPrintToScreen, bool bPrintToLog, struct FLinearColor TextColor, float Duration); // 0x0 Size: 0x7fe1
	    char UnknownData47[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnAssetLoaded__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData48[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ OnAssetClassLoaded__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData49[0x7fe1]; // 0x7fe1
	    static bool NotEqual_SoftObjectReference(struct TSoftObjectPtr<struct UObject*> A, struct TSoftObjectPtr<struct UObject*> B); // 0x0 Size: 0x7fe1
	    char UnknownData50[0x7fe1]; // 0x7fe1
	    static bool NotEqual_SoftClassReference(__int64/*SoftClassProperty*/ A, __int64/*SoftClassProperty*/ B); // 0x0 Size: 0x7fe1
	    char UnknownData51[0x7fe1]; // 0x7fe1
	    static bool NotEqual_PrimaryAssetType(struct FPrimaryAssetType A, struct FPrimaryAssetType B); // 0x0 Size: 0x7fe1
	    char UnknownData52[0x7fe1]; // 0x7fe1
	    static bool NotEqual_PrimaryAssetId(struct FPrimaryAssetId A, struct FPrimaryAssetId B); // 0x0 Size: 0x7fe1
	    char UnknownData53[0x7fe1]; // 0x7fe1
	    static struct FString NormalizeFilename(struct FString InFilename); // 0x0 Size: 0x7fe1
	    char UnknownData54[0x7fe1]; // 0x7fe1
	    static void MoveComponentTo(class USceneComponent* Component, struct FVector TargetRelativeLocation, struct FRotator TargetRelativeRotation, bool bEaseOut, bool bEaseIn, float OverTime, bool bForceShortestRotationPath, char MoveAction, struct FLatentActionInfo LatentInfo); // 0x0 Size: 0x7fe1
	    char UnknownData55[0x7fe1]; // 0x7fe1
	    static struct FSoftObjectPath MakeSoftObjectPath(struct FString PathString); // 0x0 Size: 0x7fe1
	    char UnknownData56[0x7fe1]; // 0x7fe1
	    static struct FSoftClassPath MakeSoftClassPath(struct FString PathString); // 0x0 Size: 0x7fe1
	    char UnknownData57[0x7fe1]; // 0x7fe1
	    static struct FText MakeLiteralText(struct FText Value); // 0x0 Size: 0x7fe1
	    char UnknownData58[0x7fe1]; // 0x7fe1
	    static struct FString MakeLiteralString(struct FString Value); // 0x0 Size: 0x7fe1
	    char UnknownData59[0x7fe1]; // 0x7fe1
	    static FName MakeLiteralName(FName Value); // 0x0 Size: 0x7fe1
	    char UnknownData60[0x7fe1]; // 0x7fe1
	    static int MakeLiteralInt(int Value); // 0x0 Size: 0x7fe1
	    char UnknownData61[0x7fe1]; // 0x7fe1
	    static float MakeLiteralFloat(float Value); // 0x0 Size: 0x7fe1
	    char UnknownData62[0x7fe1]; // 0x7fe1
	    static char MakeLiteralByte(char Value); // 0x0 Size: 0x7fe1
	    char UnknownData63[0x7fe1]; // 0x7fe1
	    static bool MakeLiteralBool(bool Value); // 0x0 Size: 0x7fe1
	    char UnknownData64[0x7fe1]; // 0x7fe1
	    static void LoadInterstitialAd(int AdIdIndex); // 0x0 Size: 0x7fe1
	    char UnknownData65[0x7fe1]; // 0x7fe1
	    static void LoadAssetClass(class UObject* WorldContextObject, __int64/*SoftClassProperty*/ AssetClass, __int64/*DelegateProperty*/ OnLoaded, struct FLatentActionInfo LatentInfo); // 0x0 Size: 0x7fe1
	    char UnknownData66[0x7fe1]; // 0x7fe1
	    static void LoadAsset(class UObject* WorldContextObject, struct TSoftObjectPtr<struct UObject*> Asset, __int64/*DelegateProperty*/ OnLoaded, struct FLatentActionInfo LatentInfo); // 0x0 Size: 0x7fe1
	    char UnknownData67[0x7fe1]; // 0x7fe1
	    static bool LineTraceSingleForObjects(class UObject* WorldContextObject, struct FVector Start, struct FVector End, TArray<char> ObjectTypes, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData68[0x7fe1]; // 0x7fe1
	    static bool LineTraceSingleByProfile(class UObject* WorldContextObject, struct FVector Start, struct FVector End, FName ProfileName, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData69[0x7fe1]; // 0x7fe1
	    static bool LineTraceSingle(class UObject* WorldContextObject, struct FVector Start, struct FVector End, char TraceChannel, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData70[0x7fe1]; // 0x7fe1
	    static bool LineTraceMultiForObjects(class UObject* WorldContextObject, struct FVector Start, struct FVector End, TArray<char> ObjectTypes, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData71[0x7fe1]; // 0x7fe1
	    static bool LineTraceMultiByProfile(class UObject* WorldContextObject, struct FVector Start, struct FVector End, FName ProfileName, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData72[0x7fe1]; // 0x7fe1
	    static bool LineTraceMulti(class UObject* WorldContextObject, struct FVector Start, struct FVector End, char TraceChannel, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData73[0x7fe1]; // 0x7fe1
	    static void LaunchURL(struct FString URL); // 0x0 Size: 0x7fe1
	    char UnknownData74[0x7fe1]; // 0x7fe1
	    static void K2_UnPauseTimerHandle(class UObject* WorldContextObject, struct FTimerHandle Handle); // 0x0 Size: 0x7fe1
	    char UnknownData75[0x7fe1]; // 0x7fe1
	    static void K2_UnPauseTimerDelegate(__int64/*DelegateProperty*/ Delegate); // 0x0 Size: 0x7fe1
	    char UnknownData76[0x7fe1]; // 0x7fe1
	    static void K2_UnPauseTimer(class UObject* Object, struct FString FunctionName); // 0x0 Size: 0x7fe1
	    char UnknownData77[0x7fe1]; // 0x7fe1
	    static bool K2_TimerExistsHandle(class UObject* WorldContextObject, struct FTimerHandle Handle); // 0x0 Size: 0x7fe1
	    char UnknownData78[0x7fe1]; // 0x7fe1
	    static bool K2_TimerExistsDelegate(__int64/*DelegateProperty*/ Delegate); // 0x0 Size: 0x7fe1
	    char UnknownData79[0x7fe1]; // 0x7fe1
	    static bool K2_TimerExists(class UObject* Object, struct FString FunctionName); // 0x0 Size: 0x7fe1
	    char UnknownData80[0x7fe1]; // 0x7fe1
	    static struct FTimerHandle K2_SetTimerDelegate(__int64/*DelegateProperty*/ Delegate, float Time, bool bLooping); // 0x0 Size: 0x7fe1
	    char UnknownData81[0x7fe1]; // 0x7fe1
	    static struct FTimerHandle K2_SetTimer(class UObject* Object, struct FString FunctionName, float Time, bool bLooping); // 0x0 Size: 0x7fe1
	    char UnknownData82[0x7fe1]; // 0x7fe1
	    static void K2_PauseTimerHandle(class UObject* WorldContextObject, struct FTimerHandle Handle); // 0x0 Size: 0x7fe1
	    char UnknownData83[0x7fe1]; // 0x7fe1
	    static void K2_PauseTimerDelegate(__int64/*DelegateProperty*/ Delegate); // 0x0 Size: 0x7fe1
	    char UnknownData84[0x7fe1]; // 0x7fe1
	    static void K2_PauseTimer(class UObject* Object, struct FString FunctionName); // 0x0 Size: 0x7fe1
	    char UnknownData85[0x7fe1]; // 0x7fe1
	    static bool K2_IsValidTimerHandle(struct FTimerHandle Handle); // 0x0 Size: 0x7fe1
	    char UnknownData86[0x7fe1]; // 0x7fe1
	    static bool K2_IsTimerPausedHandle(class UObject* WorldContextObject, struct FTimerHandle Handle); // 0x0 Size: 0x7fe1
	    char UnknownData87[0x7fe1]; // 0x7fe1
	    static bool K2_IsTimerPausedDelegate(__int64/*DelegateProperty*/ Delegate); // 0x0 Size: 0x7fe1
	    char UnknownData88[0x7fe1]; // 0x7fe1
	    static bool K2_IsTimerPaused(class UObject* Object, struct FString FunctionName); // 0x0 Size: 0x7fe1
	    char UnknownData89[0x7fe1]; // 0x7fe1
	    static bool K2_IsTimerActiveHandle(class UObject* WorldContextObject, struct FTimerHandle Handle); // 0x0 Size: 0x7fe1
	    char UnknownData90[0x7fe1]; // 0x7fe1
	    static bool K2_IsTimerActiveDelegate(__int64/*DelegateProperty*/ Delegate); // 0x0 Size: 0x7fe1
	    char UnknownData91[0x7fe1]; // 0x7fe1
	    static bool K2_IsTimerActive(class UObject* Object, struct FString FunctionName); // 0x0 Size: 0x7fe1
	    char UnknownData92[0x7fe1]; // 0x7fe1
	    static struct FTimerHandle K2_InvalidateTimerHandle(struct FTimerHandle Handle); // 0x0 Size: 0x7fe1
	    char UnknownData93[0x7fe1]; // 0x7fe1
	    static float K2_GetTimerRemainingTimeHandle(class UObject* WorldContextObject, struct FTimerHandle Handle); // 0x0 Size: 0x7fe1
	    char UnknownData94[0x7fe1]; // 0x7fe1
	    static float K2_GetTimerRemainingTimeDelegate(__int64/*DelegateProperty*/ Delegate); // 0x0 Size: 0x7fe1
	    char UnknownData95[0x7fe1]; // 0x7fe1
	    static float K2_GetTimerRemainingTime(class UObject* Object, struct FString FunctionName); // 0x0 Size: 0x7fe1
	    char UnknownData96[0x7fe1]; // 0x7fe1
	    static float K2_GetTimerElapsedTimeHandle(class UObject* WorldContextObject, struct FTimerHandle Handle); // 0x0 Size: 0x7fe1
	    char UnknownData97[0x7fe1]; // 0x7fe1
	    static float K2_GetTimerElapsedTimeDelegate(__int64/*DelegateProperty*/ Delegate); // 0x0 Size: 0x7fe1
	    char UnknownData98[0x7fe1]; // 0x7fe1
	    static float K2_GetTimerElapsedTime(class UObject* Object, struct FString FunctionName); // 0x0 Size: 0x7fe1
	    char UnknownData99[0x7fe1]; // 0x7fe1
	    static void K2_ClearTimerHandle(class UObject* WorldContextObject, struct FTimerHandle Handle); // 0x0 Size: 0x7fe1
	    char UnknownData100[0x7fe1]; // 0x7fe1
	    static void K2_ClearTimerDelegate(__int64/*DelegateProperty*/ Delegate); // 0x0 Size: 0x7fe1
	    char UnknownData101[0x7fe1]; // 0x7fe1
	    static void K2_ClearTimer(class UObject* Object, struct FString FunctionName); // 0x0 Size: 0x7fe1
	    char UnknownData102[0x7fe1]; // 0x7fe1
	    static void K2_ClearAndInvalidateTimerHandle(class UObject* WorldContextObject, struct FTimerHandle Handle); // 0x0 Size: 0x7fe1
	    char UnknownData103[0x7fe1]; // 0x7fe1
	    static bool IsValidSoftObjectReference(struct TSoftObjectPtr<struct UObject*> SoftObjectReference); // 0x0 Size: 0x7fe1
	    char UnknownData104[0x7fe1]; // 0x7fe1
	    static bool IsValidSoftClassReference(__int64/*SoftClassProperty*/ SoftClassReference); // 0x0 Size: 0x7fe1
	    char UnknownData105[0x7fe1]; // 0x7fe1
	    static bool IsValidPrimaryAssetType(struct FPrimaryAssetType PrimaryAssetType); // 0x0 Size: 0x7fe1
	    char UnknownData106[0x7fe1]; // 0x7fe1
	    static bool IsValidPrimaryAssetId(struct FPrimaryAssetId PrimaryAssetId); // 0x0 Size: 0x7fe1
	    char UnknownData107[0x7fe1]; // 0x7fe1
	    static bool IsValidClass(class UObject* Class); // 0x0 Size: 0x7fe1
	    char UnknownData108[0x7fe1]; // 0x7fe1
	    static bool IsValid(class UObject* Object); // 0x0 Size: 0x7fe1
	    char UnknownData109[0x7fe1]; // 0x7fe1
	    static bool IsUnattended(); // 0x0 Size: 0x7fe1
	    char UnknownData110[0x7fe1]; // 0x7fe1
	    static bool IsStandalone(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData111[0x7fe1]; // 0x7fe1
	    static bool IsServer(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData112[0x7fe1]; // 0x7fe1
	    static bool IsScreensaverEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData113[0x7fe1]; // 0x7fe1
	    static bool IsPackagedForDistribution(); // 0x0 Size: 0x7fe1
	    char UnknownData114[0x7fe1]; // 0x7fe1
	    static bool IsLoggedIn(class APlayerController* SpecificPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData115[0x7fe1]; // 0x7fe1
	    static bool IsInterstitialAdRequested(); // 0x0 Size: 0x7fe1
	    char UnknownData116[0x7fe1]; // 0x7fe1
	    static bool IsInterstitialAdAvailable(); // 0x0 Size: 0x7fe1
	    char UnknownData117[0x7fe1]; // 0x7fe1
	    static bool IsDedicatedServer(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData118[0x7fe1]; // 0x7fe1
	    static bool IsControllerAssignedToGamepad(int ControllerId); // 0x0 Size: 0x7fe1
	    char UnknownData119[0x7fe1]; // 0x7fe1
	    static void HideAdBanner(); // 0x0 Size: 0x7fe1
	    char UnknownData120[0x7fe1]; // 0x7fe1
	    static bool GetVolumeButtonsHandledBySystem(); // 0x0 Size: 0x7fe1
	    char UnknownData121[0x7fe1]; // 0x7fe1
	    static struct FString GetUniqueDeviceId(); // 0x0 Size: 0x7fe1
	    char UnknownData122[0x7fe1]; // 0x7fe1
	    static bool GetSupportedFullscreenResolutions(TArray<struct FIntPoint> Resolutions); // 0x0 Size: 0x7fe1
	    char UnknownData123[0x7fe1]; // 0x7fe1
	    static struct TSoftObjectPtr<struct UObject*> GetSoftObjectReferenceFromPrimaryAssetId(struct FPrimaryAssetId PrimaryAssetId); // 0x0 Size: 0x7fe1
	    char UnknownData124[0x7fe1]; // 0x7fe1
	    static __int64/*SoftClassProperty*/ GetSoftClassReferenceFromPrimaryAssetId(struct FPrimaryAssetId PrimaryAssetId); // 0x0 Size: 0x7fe1
	    char UnknownData125[0x7fe1]; // 0x7fe1
	    static int GetRenderingMaterialQualityLevel(); // 0x0 Size: 0x7fe1
	    char UnknownData126[0x7fe1]; // 0x7fe1
	    static int GetRenderingDetailMode(); // 0x0 Size: 0x7fe1
	    char UnknownData127[0x7fe1]; // 0x7fe1
	    static struct FString GetProjectSavedDirectory(); // 0x0 Size: 0x7fe1
	    char UnknownData128[0x7fe1]; // 0x7fe1
	    static struct FString GetProjectDirectory(); // 0x0 Size: 0x7fe1
	    char UnknownData129[0x7fe1]; // 0x7fe1
	    static struct FString GetProjectContentDirectory(); // 0x0 Size: 0x7fe1
	    char UnknownData130[0x7fe1]; // 0x7fe1
	    static void GetPrimaryAssetsWithBundleState(TArray<FName> RequiredBundles, TArray<FName> ExcludedBundles, TArray<struct FPrimaryAssetType> ValidTypes, bool bForceCurrentState, TArray<struct FPrimaryAssetId> OutPrimaryAssetIdList); // 0x0 Size: 0x7fe1
	    char UnknownData131[0x7fe1]; // 0x7fe1
	    static void GetPrimaryAssetIdList(struct FPrimaryAssetType PrimaryAssetType, TArray<struct FPrimaryAssetId> OutPrimaryAssetIdList); // 0x0 Size: 0x7fe1
	    char UnknownData132[0x7fe1]; // 0x7fe1
	    static struct FPrimaryAssetId GetPrimaryAssetIdFromSoftObjectReference(struct TSoftObjectPtr<struct UObject*> SoftObjectReference); // 0x0 Size: 0x7fe1
	    char UnknownData133[0x7fe1]; // 0x7fe1
	    static struct FPrimaryAssetId GetPrimaryAssetIdFromSoftClassReference(__int64/*SoftClassProperty*/ SoftClassReference); // 0x0 Size: 0x7fe1
	    char UnknownData134[0x7fe1]; // 0x7fe1
	    static struct FPrimaryAssetId GetPrimaryAssetIdFromObject(class UObject* Object); // 0x0 Size: 0x7fe1
	    char UnknownData135[0x7fe1]; // 0x7fe1
	    static struct FPrimaryAssetId GetPrimaryAssetIdFromClass(class UObject* Class); // 0x0 Size: 0x7fe1
	    char UnknownData136[0x7fe1]; // 0x7fe1
	    static TArray<struct FString> GetPreferredLanguages(); // 0x0 Size: 0x7fe1
	    char UnknownData137[0x7fe1]; // 0x7fe1
	    static struct FString GetPlatformUserName(); // 0x0 Size: 0x7fe1
	    char UnknownData138[0x7fe1]; // 0x7fe1
	    static struct FString GetPathName(class UObject* Object); // 0x0 Size: 0x7fe1
	    char UnknownData139[0x7fe1]; // 0x7fe1
	    static struct FString GetObjectName(class UObject* Object); // 0x0 Size: 0x7fe1
	    char UnknownData140[0x7fe1]; // 0x7fe1
	    static class UObject* GetObjectFromPrimaryAssetId(struct FPrimaryAssetId PrimaryAssetId); // 0x0 Size: 0x7fe1
	    char UnknownData141[0x7fe1]; // 0x7fe1
	    static int GetMinYResolutionForUI(); // 0x0 Size: 0x7fe1
	    char UnknownData142[0x7fe1]; // 0x7fe1
	    static int GetMinYResolutionFor3DView(); // 0x0 Size: 0x7fe1
	    char UnknownData143[0x7fe1]; // 0x7fe1
	    static struct FString GetLocalCurrencySymbol(); // 0x0 Size: 0x7fe1
	    char UnknownData144[0x7fe1]; // 0x7fe1
	    static struct FString GetLocalCurrencyCode(); // 0x0 Size: 0x7fe1
	    char UnknownData145[0x7fe1]; // 0x7fe1
	    static float GetGameTimeInSeconds(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData146[0x7fe1]; // 0x7fe1
	    static struct FString GetGamepadControllerName(int ControllerId); // 0x0 Size: 0x7fe1
	    char UnknownData147[0x7fe1]; // 0x7fe1
	    static struct FString GetGameName(); // 0x0 Size: 0x7fe1
	    char UnknownData148[0x7fe1]; // 0x7fe1
	    static struct FString GetGameBundleId(); // 0x0 Size: 0x7fe1
	    char UnknownData149[0x7fe1]; // 0x7fe1
	    static struct FString GetEngineVersion(); // 0x0 Size: 0x7fe1
	    char UnknownData150[0x7fe1]; // 0x7fe1
	    static struct FString GetDisplayName(class UObject* Object); // 0x0 Size: 0x7fe1
	    char UnknownData151[0x7fe1]; // 0x7fe1
	    static struct FString GetDeviceId(); // 0x0 Size: 0x7fe1
	    char UnknownData152[0x7fe1]; // 0x7fe1
	    static struct FString GetDefaultLocale(); // 0x0 Size: 0x7fe1
	    char UnknownData153[0x7fe1]; // 0x7fe1
	    static struct FString GetDefaultLanguage(); // 0x0 Size: 0x7fe1
	    char UnknownData154[0x7fe1]; // 0x7fe1
	    static bool GetCurrentBundleState(struct FPrimaryAssetId PrimaryAssetId, bool bForceCurrentState, TArray<FName> OutBundles); // 0x0 Size: 0x7fe1
	    char UnknownData155[0x7fe1]; // 0x7fe1
	    static bool GetConvenientWindowedResolutions(TArray<struct FIntPoint> Resolutions); // 0x0 Size: 0x7fe1
	    char UnknownData156[0x7fe1]; // 0x7fe1
	    static int GetConsoleVariableIntValue(class UObject* WorldContextObject, struct FString VariableName); // 0x0 Size: 0x7fe1
	    char UnknownData157[0x7fe1]; // 0x7fe1
	    static float GetConsoleVariableFloatValue(class UObject* WorldContextObject, struct FString VariableName); // 0x0 Size: 0x7fe1
	    char UnknownData158[0x7fe1]; // 0x7fe1
	    static void GetComponentBounds(class USceneComponent* Component, struct FVector Origin, struct FVector BoxExtent, float SphereRadius); // 0x0 Size: 0x7fe1
	    char UnknownData159[0x7fe1]; // 0x7fe1
	    static struct FString GetCommandLine(); // 0x0 Size: 0x7fe1
	    char UnknownData160[0x7fe1]; // 0x7fe1
	    static class UObject* GetClassFromPrimaryAssetId(struct FPrimaryAssetId PrimaryAssetId); // 0x0 Size: 0x7fe1
	    char UnknownData161[0x7fe1]; // 0x7fe1
	    static struct FString GetClassDisplayName(class UObject* Class); // 0x0 Size: 0x7fe1
	    char UnknownData162[0x7fe1]; // 0x7fe1
	    static int GetAdIDCount(); // 0x0 Size: 0x7fe1
	    char UnknownData163[0x7fe1]; // 0x7fe1
	    static void GetActorListFromComponentList(TArray<class UPrimitiveComponent*> ComponentList, class UObject* ActorClassFilter, TArray<class AActor*> OutActorList); // 0x0 Size: 0x7fe1
	    char UnknownData164[0x7fe1]; // 0x7fe1
	    static void GetActorBounds(class AActor* Actor, struct FVector Origin, struct FVector BoxExtent); // 0x0 Size: 0x7fe1
	    char UnknownData165[0x7fe1]; // 0x7fe1
	    static void ForceCloseAdBanner(); // 0x0 Size: 0x7fe1
	    char UnknownData166[0x7fe1]; // 0x7fe1
	    static void FlushPersistentDebugLines(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData167[0x7fe1]; // 0x7fe1
	    static void FlushDebugStrings(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData168[0x7fe1]; // 0x7fe1
	    static void ExecuteConsoleCommand(class UObject* WorldContextObject, struct FString Command, class APlayerController* SpecificPlayer); // 0x0 Size: 0x7fe1
	    char UnknownData169[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_SoftObjectReference(struct TSoftObjectPtr<struct UObject*> A, struct TSoftObjectPtr<struct UObject*> B); // 0x0 Size: 0x7fe1
	    char UnknownData170[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_SoftClassReference(__int64/*SoftClassProperty*/ A, __int64/*SoftClassProperty*/ B); // 0x0 Size: 0x7fe1
	    char UnknownData171[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_PrimaryAssetType(struct FPrimaryAssetType A, struct FPrimaryAssetType B); // 0x0 Size: 0x7fe1
	    char UnknownData172[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_PrimaryAssetId(struct FPrimaryAssetId A, struct FPrimaryAssetId B); // 0x0 Size: 0x7fe1
	    char UnknownData173[0x7fe1]; // 0x7fe1
	    static int EndTransaction(); // 0x0 Size: 0x7fe1
	    char UnknownData174[0x7fe1]; // 0x7fe1
	    static void DrawDebugString(class UObject* WorldContextObject, struct FVector TextLocation, struct FString Text, class AActor* TestBaseActor, struct FLinearColor TextColor, float Duration); // 0x0 Size: 0x7fe1
	    char UnknownData175[0x7fe1]; // 0x7fe1
	    static void DrawDebugSphere(class UObject* WorldContextObject, struct FVector Center, float Radius, int Segments, struct FLinearColor LineColor, float Duration, float Thickness); // 0x0 Size: 0x7fe1
	    char UnknownData176[0x7fe1]; // 0x7fe1
	    static void DrawDebugPoint(class UObject* WorldContextObject, struct FVector Position, float Size, struct FLinearColor PointColor, float Duration); // 0x0 Size: 0x7fe1
	    char UnknownData177[0x7fe1]; // 0x7fe1
	    static void DrawDebugPlane(class UObject* WorldContextObject, struct FPlane PlaneCoordinates, struct FVector Location, float Size, struct FLinearColor PlaneColor, float Duration); // 0x0 Size: 0x7fe1
	    char UnknownData178[0x7fe1]; // 0x7fe1
	    static void DrawDebugLine(class UObject* WorldContextObject, struct FVector LineStart, struct FVector LineEnd, struct FLinearColor LineColor, float Duration, float Thickness); // 0x0 Size: 0x7fe1
	    char UnknownData179[0x7fe1]; // 0x7fe1
	    static void DrawDebugFrustum(class UObject* WorldContextObject, struct FTransform FrustumTransform, struct FLinearColor FrustumColor, float Duration, float Thickness); // 0x0 Size: 0x7fe1
	    char UnknownData180[0x7fe1]; // 0x7fe1
	    static void DrawDebugFloatHistoryTransform(class UObject* WorldContextObject, struct FDebugFloatHistory FloatHistory, struct FTransform DrawTransform, struct FVector2D DrawSize, struct FLinearColor DrawColor, float Duration); // 0x0 Size: 0x7fe1
	    char UnknownData181[0x7fe1]; // 0x7fe1
	    static void DrawDebugFloatHistoryLocation(class UObject* WorldContextObject, struct FDebugFloatHistory FloatHistory, struct FVector DrawLocation, struct FVector2D DrawSize, struct FLinearColor DrawColor, float Duration); // 0x0 Size: 0x7fe1
	    char UnknownData182[0x7fe1]; // 0x7fe1
	    static void DrawDebugCylinder(class UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, int Segments, struct FLinearColor LineColor, float Duration, float Thickness); // 0x0 Size: 0x7fe1
	    char UnknownData183[0x7fe1]; // 0x7fe1
	    static void DrawDebugCoordinateSystem(class UObject* WorldContextObject, struct FVector AxisLoc, struct FRotator AxisRot, float Scale, float Duration, float Thickness); // 0x0 Size: 0x7fe1
	    char UnknownData184[0x7fe1]; // 0x7fe1
	    static void DrawDebugConeInDegrees(class UObject* WorldContextObject, struct FVector Origin, struct FVector Direction, float Length, float AngleWidth, float AngleHeight, int NumSides, struct FLinearColor LineColor, float Duration, float Thickness); // 0x0 Size: 0x7fe1
	    char UnknownData185[0x7fe1]; // 0x7fe1
	    static void DrawDebugCone(class UObject* WorldContextObject, struct FVector Origin, struct FVector Direction, float Length, float AngleWidth, float AngleHeight, int NumSides, struct FLinearColor LineColor, float Duration, float Thickness); // 0x0 Size: 0x7fe1
	    char UnknownData186[0x7fe1]; // 0x7fe1
	    static void DrawDebugCircle(class UObject* WorldContextObject, struct FVector Center, float Radius, int NumSegments, struct FLinearColor LineColor, float Duration, float Thickness, struct FVector YAxis, struct FVector ZAxis, bool bDrawAxis); // 0x0 Size: 0x7fe1
	    char UnknownData187[0x7fe1]; // 0x7fe1
	    static void DrawDebugCapsule(class UObject* WorldContextObject, struct FVector Center, float HalfHeight, float Radius, struct FRotator Rotation, struct FLinearColor LineColor, float Duration, float Thickness); // 0x0 Size: 0x7fe1
	    char UnknownData188[0x7fe1]; // 0x7fe1
	    static void DrawDebugCamera(class ACameraActor* CameraActor, struct FLinearColor CameraColor, float Duration); // 0x0 Size: 0x7fe1
	    char UnknownData189[0x7fe1]; // 0x7fe1
	    static void DrawDebugBox(class UObject* WorldContextObject, struct FVector Center, struct FVector Extent, struct FLinearColor LineColor, struct FRotator Rotation, float Duration, float Thickness); // 0x0 Size: 0x7fe1
	    char UnknownData190[0x7fe1]; // 0x7fe1
	    static void DrawDebugArrow(class UObject* WorldContextObject, struct FVector LineStart, struct FVector LineEnd, float ArrowSize, struct FLinearColor LineColor, float Duration, float Thickness); // 0x0 Size: 0x7fe1
	    char UnknownData191[0x7fe1]; // 0x7fe1
	    static bool DoesImplementInterface(class UObject* TestObject, class UInterface* Interface); // 0x0 Size: 0x7fe1
	    char UnknownData192[0x7fe1]; // 0x7fe1
	    static void Delay(class UObject* WorldContextObject, float Duration, struct FLatentActionInfo LatentInfo); // 0x0 Size: 0x7fe1
	    char UnknownData193[0x7fe1]; // 0x7fe1
	    static void CreateCopyForUndoBuffer(class UObject* ObjectToModify); // 0x0 Size: 0x7fe1
	    char UnknownData194[0x7fe1]; // 0x7fe1
	    static struct FString ConvertToRelativePath(struct FString Filename); // 0x0 Size: 0x7fe1
	    char UnknownData195[0x7fe1]; // 0x7fe1
	    static struct FString ConvertToAbsolutePath(struct FString Filename); // 0x0 Size: 0x7fe1
	    char UnknownData196[0x7fe1]; // 0x7fe1
	    static struct FString Conv_SoftObjectReferenceToString(struct TSoftObjectPtr<struct UObject*> SoftObjectReference); // 0x0 Size: 0x7fe1
	    char UnknownData197[0x7fe1]; // 0x7fe1
	    static class UObject* Conv_SoftObjectReferenceToObject(struct TSoftObjectPtr<struct UObject*> SoftObject); // 0x0 Size: 0x7fe1
	    char UnknownData198[0x7fe1]; // 0x7fe1
	    static struct FString Conv_SoftClassReferenceToString(__int64/*SoftClassProperty*/ SoftClassReference); // 0x0 Size: 0x7fe1
	    char UnknownData199[0x7fe1]; // 0x7fe1
	    static class UObject* Conv_SoftClassReferenceToClass(__int64/*SoftClassProperty*/ SoftClass); // 0x0 Size: 0x7fe1
	    char UnknownData200[0x7fe1]; // 0x7fe1
	    static struct FString Conv_PrimaryAssetTypeToString(struct FPrimaryAssetType PrimaryAssetType); // 0x0 Size: 0x7fe1
	    char UnknownData201[0x7fe1]; // 0x7fe1
	    static struct FString Conv_PrimaryAssetIdToString(struct FPrimaryAssetId PrimaryAssetId); // 0x0 Size: 0x7fe1
	    char UnknownData202[0x7fe1]; // 0x7fe1
	    static struct TSoftObjectPtr<struct UObject*> Conv_ObjectToSoftObjectReference(class UObject* Object); // 0x0 Size: 0x7fe1
	    char UnknownData203[0x7fe1]; // 0x7fe1
	    static class UObject* Conv_InterfaceToObject(__int64/*InterfaceProperty*/ Interface); // 0x0 Size: 0x7fe1
	    char UnknownData204[0x7fe1]; // 0x7fe1
	    static __int64/*SoftClassProperty*/ Conv_ClassToSoftClassReference(class UObject* Class); // 0x0 Size: 0x7fe1
	    char UnknownData205[0x7fe1]; // 0x7fe1
	    static void ControlScreensaver(bool bAllowScreenSaver); // 0x0 Size: 0x7fe1
	    char UnknownData206[0x7fe1]; // 0x7fe1
	    static bool ComponentOverlapComponents(class UPrimitiveComponent* Component, struct FTransform ComponentTransform, TArray<char> ObjectTypes, class UObject* ComponentClassFilter, TArray<class AActor*> ActorsToIgnore, TArray<class UPrimitiveComponent*> OutComponents); // 0x0 Size: 0x7fe1
	    char UnknownData207[0x7fe1]; // 0x7fe1
	    static bool ComponentOverlapActors(class UPrimitiveComponent* Component, struct FTransform ComponentTransform, TArray<char> ObjectTypes, class UObject* ActorClassFilter, TArray<class AActor*> ActorsToIgnore, TArray<class AActor*> OutActors); // 0x0 Size: 0x7fe1
	    char UnknownData208[0x7fe1]; // 0x7fe1
	    static void CollectGarbage(); // 0x0 Size: 0x7fe1
	    char UnknownData209[0x7fe1]; // 0x7fe1
	    static bool CapsuleTraceSingleForObjects(class UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, float HalfHeight, TArray<char> ObjectTypes, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData210[0x7fe1]; // 0x7fe1
	    static bool CapsuleTraceSingleByProfile(class UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, float HalfHeight, FName ProfileName, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData211[0x7fe1]; // 0x7fe1
	    static bool CapsuleTraceSingle(class UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, float HalfHeight, char TraceChannel, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData212[0x7fe1]; // 0x7fe1
	    static bool CapsuleTraceMultiForObjects(class UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, float HalfHeight, TArray<char> ObjectTypes, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData213[0x7fe1]; // 0x7fe1
	    static bool CapsuleTraceMultiByProfile(class UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, float HalfHeight, FName ProfileName, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData214[0x7fe1]; // 0x7fe1
	    static bool CapsuleTraceMulti(class UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, float HalfHeight, char TraceChannel, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData215[0x7fe1]; // 0x7fe1
	    static bool CapsuleOverlapComponents(class UObject* WorldContextObject, struct FVector CapsulePos, float Radius, float HalfHeight, TArray<char> ObjectTypes, class UObject* ComponentClassFilter, TArray<class AActor*> ActorsToIgnore, TArray<class UPrimitiveComponent*> OutComponents); // 0x0 Size: 0x7fe1
	    char UnknownData216[0x7fe1]; // 0x7fe1
	    static bool CapsuleOverlapActors(class UObject* WorldContextObject, struct FVector CapsulePos, float Radius, float HalfHeight, TArray<char> ObjectTypes, class UObject* ActorClassFilter, TArray<class AActor*> ActorsToIgnore, TArray<class AActor*> OutActors); // 0x0 Size: 0x7fe1
	    char UnknownData217[0x7fe1]; // 0x7fe1
	    static bool CanLaunchURL(struct FString URL); // 0x0 Size: 0x7fe1
	    char UnknownData218[0x7fe1]; // 0x7fe1
	    static void CancelTransaction(int Index); // 0x0 Size: 0x7fe1
	    char UnknownData219[0x7fe1]; // 0x7fe1
	    static void BreakSoftObjectPath(struct FSoftObjectPath InSoftObjectPath, struct FString PathString); // 0x0 Size: 0x7fe1
	    char UnknownData220[0x7fe1]; // 0x7fe1
	    static void BreakSoftClassPath(struct FSoftClassPath InSoftClassPath, struct FString PathString); // 0x0 Size: 0x7fe1
	    char UnknownData221[0x7fe1]; // 0x7fe1
	    static bool BoxTraceSingleForObjects(class UObject* WorldContextObject, struct FVector Start, struct FVector End, struct FVector HalfSize, struct FRotator Orientation, TArray<char> ObjectTypes, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData222[0x7fe1]; // 0x7fe1
	    static bool BoxTraceSingleByProfile(class UObject* WorldContextObject, struct FVector Start, struct FVector End, struct FVector HalfSize, struct FRotator Orientation, FName ProfileName, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData223[0x7fe1]; // 0x7fe1
	    static bool BoxTraceSingle(class UObject* WorldContextObject, struct FVector Start, struct FVector End, struct FVector HalfSize, struct FRotator Orientation, char TraceChannel, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData224[0x7fe1]; // 0x7fe1
	    static bool BoxTraceMultiForObjects(class UObject* WorldContextObject, struct FVector Start, struct FVector End, struct FVector HalfSize, struct FRotator Orientation, TArray<char> ObjectTypes, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData225[0x7fe1]; // 0x7fe1
	    static bool BoxTraceMultiByProfile(class UObject* WorldContextObject, struct FVector Start, struct FVector End, struct FVector HalfSize, struct FRotator Orientation, FName ProfileName, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData226[0x7fe1]; // 0x7fe1
	    static bool BoxTraceMulti(class UObject* WorldContextObject, struct FVector Start, struct FVector End, struct FVector HalfSize, struct FRotator Orientation, char TraceChannel, bool bTraceComplex, TArray<class AActor*> ActorsToIgnore, char DrawDebugType, TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // 0x0 Size: 0x7fe1
	    char UnknownData227[0x7fe1]; // 0x7fe1
	    static bool BoxOverlapComponents(class UObject* WorldContextObject, struct FVector BoxPos, struct FVector Extent, TArray<char> ObjectTypes, class UObject* ComponentClassFilter, TArray<class AActor*> ActorsToIgnore, TArray<class UPrimitiveComponent*> OutComponents); // 0x0 Size: 0x7fe1
	    char UnknownData228[0x7fe1]; // 0x7fe1
	    static bool BoxOverlapActors(class UObject* WorldContextObject, struct FVector BoxPos, struct FVector BoxExtent, TArray<char> ObjectTypes, class UObject* ActorClassFilter, TArray<class AActor*> ActorsToIgnore, TArray<class AActor*> OutActors); // 0x0 Size: 0x7fe1
	    char UnknownData229[0x7fe1]; // 0x7fe1
	    static int BeginTransaction(struct FString Context, struct FText Description, class UObject* PrimaryObject); // 0x0 Size: 0x7fe1
	    char UnknownData230[0x7fe1]; // 0x7fe1
	    static struct FDebugFloatHistory AddFloatHistorySample(float Value, struct FDebugFloatHistory FloatHistory); // 0x0 Size: 0x7fe1
	    char UnknownData231[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.KismetSystemLibrary");
			return (class UClass*)ptr;
		};

};

class UKismetTextLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static struct FText TextTrimTrailing(struct FText InText); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static struct FText TextTrimPrecedingAndTrailing(struct FText InText); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static struct FText TextTrimPreceding(struct FText InText); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static struct FText TextToUpper(struct FText InText); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static struct FText TextToLower(struct FText InText); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static bool TextIsTransient(struct FText InText); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static bool TextIsFromStringTable(struct FText Text); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static bool TextIsEmpty(struct FText InText); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static bool TextIsCultureInvariant(struct FText InText); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static struct FText TextFromStringTable(FName TableId, struct FString Key); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    static bool StringTableIdAndKeyFromText(struct FText Text, FName OutTableId, struct FString OutKey); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    static struct FText PolyglotDataToText(struct FPolyglotTextData PolyglotData); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    static bool NotEqual_TextText(struct FText A, struct FText B); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    static bool NotEqual_IgnoreCase_TextText(struct FText A, struct FText B); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    static void IsPolyglotDataValid(struct FPolyglotTextData PolyglotData, bool IsValid, struct FText ErrorMessage); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    static struct FText GetEmptyText(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    static struct FText Format(struct FText InPattern, TArray<struct FFormatArgumentData> InArgs); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    static bool FindTextInLocalizationTable(struct FString Namespace, struct FString Key, struct FText OutText); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_TextText(struct FText A, struct FText B); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    static bool EqualEqual_IgnoreCase_TextText(struct FText A, struct FText B); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    static struct FText Conv_VectorToText(struct FVector InVec); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    static struct FText Conv_Vector2dToText(struct FVector2D InVec); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    static struct FText Conv_TransformToText(struct FTransform InTrans); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    static struct FString Conv_TextToString(struct FText InText); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    static struct FText Conv_StringToText(struct FString inString); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    static struct FText Conv_RotatorToText(struct FRotator InRot); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    static struct FText Conv_ObjectToText(class UObject* InObj); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    static struct FText Conv_NameToText(FName InName); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    static struct FText Conv_IntToText(int Value, bool bAlwaysSign, bool bUseGrouping, int MinimumIntegralDigits, int MaximumIntegralDigits); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    static struct FText Conv_FloatToText(float Value, char RoundingMode, bool bAlwaysSign, bool bUseGrouping, int MinimumIntegralDigits, int MaximumIntegralDigits, int MinimumFractionalDigits, int MaximumFractionalDigits); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    static struct FText Conv_ColorToText(struct FLinearColor InColor); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    static struct FText Conv_ByteToText(char Value); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    static struct FText Conv_BoolToText(bool InBool); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    static struct FText AsTimeZoneTime_DateTime(struct FDateTime InDateTime, struct FString InTimeZone); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    static struct FText AsTimeZoneDateTime_DateTime(struct FDateTime InDateTime, struct FString InTimeZone); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    static struct FText AsTimeZoneDate_DateTime(struct FDateTime InDateTime, struct FString InTimeZone); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    static struct FText AsTimespan_Timespan(struct FTimespan InTimespan); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    static struct FText AsTime_DateTime(struct FDateTime In); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    static struct FText AsPercent_Float(float Value, char RoundingMode, bool bAlwaysSign, bool bUseGrouping, int MinimumIntegralDigits, int MaximumIntegralDigits, int MinimumFractionalDigits, int MaximumFractionalDigits); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    static struct FText AsDateTime_DateTime(struct FDateTime In); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    static struct FText AsDate_DateTime(struct FDateTime InDateTime); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    static struct FText AsCurrencyBase(int BaseValue, struct FString CurrencyCode); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    static struct FText AsCurrency_Integer(int Value, char RoundingMode, bool bAlwaysSign, bool bUseGrouping, int MinimumIntegralDigits, int MaximumIntegralDigits, int MinimumFractionalDigits, int MaximumFractionalDigits, struct FString CurrencyCode); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    static struct FText AsCurrency_Float(float Value, char RoundingMode, bool bAlwaysSign, bool bUseGrouping, int MinimumIntegralDigits, int MaximumIntegralDigits, int MinimumFractionalDigits, int MaximumFractionalDigits, struct FString CurrencyCode); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.KismetTextLibrary");
			return (class UClass*)ptr;
		};

};

class ULayer : public UObject
{
	public:
	    FName LayerName; // 0x28 Size: 0x8
	    bool bIsVisible; // 0x30 Size: 0x1
	    char UnknownData0[0x7]; // 0x31
	    TArray<struct FLayerActorStats> ActorStats; // 0x38 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Layer");
			return (class UClass*)ptr;
		};

};

class ULevel : public UObject
{
	public:
	    char UnknownData0[0x90];
	    class UWorld* OwningWorld; // 0xb8 Size: 0x8
	    class UModel* Model; // 0xc0 Size: 0x8
	    TArray<class UModelComponent*> ModelComponents; // 0xc8 Size: 0x10
	    class ULevelActorContainer* ActorCluster; // 0xd8 Size: 0x8
	    int NumTextureStreamingUnbuiltComponents; // 0xe0 Size: 0x4
	    int NumTextureStreamingDirtyResources; // 0xe4 Size: 0x4
	    class ALevelScriptActor* LevelScriptActor; // 0xe8 Size: 0x8
	    class ANavigationObjectBase* NavListStart; // 0xf0 Size: 0x8
	    class ANavigationObjectBase* NavListEnd; // 0xf8 Size: 0x8
	    TArray<class UNavigationDataChunk*> NavDataChunks; // 0x100 Size: 0x10
	    float LightmapTotalSize; // 0x110 Size: 0x4
	    float ShadowmapTotalSize; // 0x114 Size: 0x4
	    TArray<struct FVector> StaticNavigableGeometry; // 0x118 Size: 0x10
	    TArray<struct FGuid> StreamingTextureGuids; // 0x128 Size: 0x10
	    char UnknownData1[0x98]; // 0x138
	    struct FGuid LevelBuildDataId; // 0x1d0 Size: 0x10
	    class UMapBuildDataRegistry* MapBuildData; // 0x1e0 Size: 0x8
	    struct FIntVector LightBuildLevelOffset; // 0x1e8 Size: 0xc
	    bool bIsLightingScenario; // 0x1f4 Size: 0x1
	    bool bTextureStreamingRotationChanged; // 0x1f4 Size: 0x1
	    bool bStaticComponentsRegisteredInStreamingManager; // 0x1f4 Size: 0x1
	    bool bIsVisible; // 0x1f4 Size: 0x1
	    char UnknownData2[0x48]; // 0x1f8
	    class AWorldSettings* WorldSettings; // 0x240 Size: 0x8
	    char UnknownData3[0x8]; // 0x248
	    TArray<class UAssetUserData*> AssetUserData; // 0x250 Size: 0x10
	    char UnknownData4[0x10]; // 0x260
	    TArray<struct FReplicatedStaticActorDestructionInfo> DestroyedReplicatedStaticActors; // 0x270 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Level");
			return (class UClass*)ptr;
		};

};

class ULevelActorContainer : public UObject
{
	public:
	    TArray<class AActor*> Actors; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LevelActorContainer");
			return (class UClass*)ptr;
		};

};

class ALevelBounds : public AActor
{
	public:
	    bool bAutoUpdateBounds; // 0x330 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LevelBounds");
			return (class UClass*)ptr;
		};

};

class ULevelScriptBlueprint : public UBlueprint
{
	public:
	    char UnknownData0[0xe0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LevelScriptBlueprint");
			return (class UClass*)ptr;
		};

};

class ULevelStreaming : public UObject
{
	public:
	    struct TSoftObjectPtr<struct UWorld*> WorldAsset; // 0x28 Size: 0x28
	    FName PackageNameToLoad; // 0x50 Size: 0x8
	    TArray<FName> LODPackageNames; // 0x58 Size: 0x10
	    char UnknownData0[0x18]; // 0x68
	    struct FTransform LevelTransform; // 0x80 Size: 0x30
	    int LevelLODIndex; // 0xb0 Size: 0x4
	    int StreamingPriority; // 0xb4 Size: 0x4
	    bool bShouldBeVisible; // 0xba Size: 0x1
	    bool bShouldBeLoaded; // 0xba Size: 0x1
	    bool bLocked; // 0xba Size: 0x1
	    bool bIsStatic; // 0xba Size: 0x1
	    bool bShouldBlockOnLoad; // 0xba Size: 0x1
	    bool bShouldBlockOnUnload; // 0xba Size: 0x1
	    bool bDisableDistanceStreaming; // 0xbb Size: 0x1
	    bool bDrawOnLevelStatusMap; // 0xbb Size: 0x1
	    char UnknownData1[0x4]; // 0xc0
	    struct FLinearColor LevelColor; // 0xbc Size: 0x10
	    char UnknownData2[0x4]; // 0xcc
	    TArray<class ALevelStreamingVolume*> EditorStreamingVolumes; // 0xd0 Size: 0x10
	    float MinTimeBetweenVolumeUnloadRequests; // 0xe0 Size: 0x4
	    char UnknownData3[0x4]; // 0xe4
	    MulticastDelegateProperty OnLevelLoaded; // 0xe8 Size: 0x10
	    MulticastDelegateProperty OnLevelUnloaded; // 0xf8 Size: 0x10
	    MulticastDelegateProperty OnLevelShown; // 0x108 Size: 0x10
	    MulticastDelegateProperty OnLevelHidden; // 0x118 Size: 0x10
	    class ULevel* LoadedLevel; // 0x128 Size: 0x8
	    class ULevel* PendingUnloadLevel; // 0x130 Size: 0x8
	    char UnknownData4[0x138]; // 0x138
	    bool ShouldBeLoaded(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetShouldBeVisible(bool bInShouldBeVisible); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetShouldBeLoaded(bool bInShouldBeLoaded); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetPriority(int NewPriority); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetLevelLODIndex(int LODIndex); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    bool IsStreamingStatePending(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    bool IsLevelVisible(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    bool IsLevelLoaded(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    FName GetWorldAssetPackageFName(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    class ALevelScriptActor* GetLevelScriptActor(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    class ULevelStreaming* CreateInstance(struct FString UniqueInstanceName); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x-7e91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LevelStreaming");
			return (class UClass*)ptr;
		};

};

class ULevelStreamingAlwaysLoaded : public ULevelStreaming
{
	public:
	    char UnknownData0[0x150];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LevelStreamingAlwaysLoaded");
			return (class UClass*)ptr;
		};

};

class ULevelStreamingDynamic : public ULevelStreaming
{
	public:
	    bool bInitiallyLoaded; // 0x148 Size: 0x1
	    bool bInitiallyVisible; // 0x148 Size: 0x1
	    char UnknownData0[0x14a]; // 0x14a
	    static class ULevelStreamingDynamic* LoadLevelInstanceBySoftObjectPtr(class UObject* WorldContextObject, struct TSoftObjectPtr<struct UWorld*> Level, struct FVector Location, struct FRotator Rotation, bool bOutSuccess); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static class ULevelStreamingDynamic* LoadLevelInstance(class UObject* WorldContextObject, struct FString LevelName, struct FVector Location, struct FRotator Rotation, bool bOutSuccess); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7e91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LevelStreamingDynamic");
			return (class UClass*)ptr;
		};

};

class ULevelStreamingPersistent : public ULevelStreaming
{
	public:
	    char UnknownData0[0x150];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LevelStreamingPersistent");
			return (class UClass*)ptr;
		};

};

class ALevelStreamingVolume : public AVolume
{
	public:
	    TArray<FName> StreamingLevelNames; // 0x368 Size: 0x10
	    bool bEditorPreVisOnly; // 0x378 Size: 0x1
	    bool bDisabled; // 0x378 Size: 0x1
	    char UnknownData0[0x2]; // 0x37a
	    char StreamingUsage; // 0x37c Size: 0x1
	    char UnknownData1[0x3];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LevelStreamingVolume");
			return (class UClass*)ptr;
		};

};

class ULightmappedSurfaceCollection : public UObject
{
	public:
	    class UModel* SourceModel; // 0x28 Size: 0x8
	    TArray<int> Surfaces; // 0x30 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LightmappedSurfaceCollection");
			return (class UClass*)ptr;
		};

};

class ULightMapTexture2D : public UTexture2D
{
	public:
	    char UnknownData0[0xf8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LightMapTexture2D");
			return (class UClass*)ptr;
		};

};

class ALightmassCharacterIndirectDetailVolume : public AVolume
{
	public:
	    char UnknownData0[0x368];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LightmassCharacterIndirectDetailVolume");
			return (class UClass*)ptr;
		};

};

class ALightmassImportanceVolume : public AVolume
{
	public:
	    char UnknownData0[0x368];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LightmassImportanceVolume");
			return (class UClass*)ptr;
		};

};

class ALightmassPortal : public AActor
{
	public:
	    class ULightmassPortalComponent* PortalComponent; // 0x330 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LightmassPortal");
			return (class UClass*)ptr;
		};

};

class ULightmassPortalComponent : public USceneComponent
{
	public:
	    class UBoxComponent* PreviewBox; // 0x248 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LightmassPortalComponent");
			return (class UClass*)ptr;
		};

};

class ULightmassPrimitiveSettingsObject : public UObject
{
	public:
	    struct FLightmassPrimitiveSettings LightmassSettings; // 0x28 Size: 0x18

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LightmassPrimitiveSettingsObject");
			return (class UClass*)ptr;
		};

};

class ULineBatchComponent : public UPrimitiveComponent
{
	public:
	    char UnknownData0[0x5b0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LineBatchComponent");
			return (class UClass*)ptr;
		};

};

class ULocalLightComponent : public ULightComponent
{
	public:
	    ELightUnits IntensityUnits; // 0x378 Size: 0x1
	    char UnknownData0[0x3]; // 0x379
	    float Radius; // 0x37c Size: 0x4
	    float AttenuationRadius; // 0x380 Size: 0x4
	    struct FLightmassPointLightSettings LightmassSettings; // 0x384 Size: 0xc
	    char UnknownData1[0x390]; // 0x390
	    void SetAttenuationRadius(float NewRadius); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static float GetUnitsConversionFactor(ELightUnits SrcUnits, ELightUnits TargetUnits, float CosHalfConeAngle); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7c51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LocalLightComponent");
			return (class UClass*)ptr;
		};

};

class ALODActor : public AActor
{
	public:
	    class UStaticMeshComponent* StaticMeshComponent; // 0x330 Size: 0x8
	    class UHLODProxy* Proxy; // 0x338 Size: 0x8
	    FName Key; // 0x340 Size: 0x8
	    float LODDrawDistance; // 0x348 Size: 0x4
	    int LODLevel; // 0x34c Size: 0x4
	    TArray<class AActor*> SubActors; // 0x350 Size: 0x10
	    char CachedNumHLODLevels; // 0x360 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LODActor");
			return (class UClass*)ptr;
		};

};

class UMapBuildDataRegistry : public UObject
{
	public:
	    char LevelLightingQuality; // 0x28 Size: 0x1
	    char UnknownData0[0x1a7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MapBuildDataRegistry");
			return (class UClass*)ptr;
		};

};

class UMaterial : public UMaterialInterface
{
	public:
	    class UPhysicalMaterial* PhysMaterial; // 0x88 Size: 0x8
	    struct FScalarMaterialInput Metallic; // 0x90 Size: 0xc
	    char UnknownData0[0x8]; // 0x9c
	    struct FScalarMaterialInput Specular; // 0xa4 Size: 0xc
	    char UnknownData1[0x8]; // 0xb0
	    struct FVectorMaterialInput Normal; // 0xb8 Size: 0xc
	    char UnknownData2[0x8]; // 0xc4
	    struct FColorMaterialInput EmissiveColor; // 0xcc Size: 0xc
	    char UnknownData3[0x8]; // 0xd8
	    char MaterialDomain; // 0xe0 Size: 0x1
	    char BlendMode; // 0xe1 Size: 0x1
	    char DecalBlendMode; // 0xe2 Size: 0x1
	    char MaterialDecalResponse; // 0xe3 Size: 0x1
	    char ShadingModel; // 0xe4 Size: 0x1
	    char UnknownData4[0x3]; // 0xe5
	    float OpacityMaskClipValue; // 0xe8 Size: 0x4
	    bool bCastDynamicShadowAsMasked; // 0xec Size: 0x1
	    char UnknownData5[0x3]; // 0xed
	    struct FVectorMaterialInput WorldPositionOffset; // 0xf0 Size: 0xc
	    char UnknownData6[0x8]; // 0xfc
	    struct FScalarMaterialInput Refraction; // 0x104 Size: 0xc
	    char UnknownData7[0x8]; // 0x110
	    struct FMaterialAttributesInput MaterialAttributes; // 0x118 Size: 0x10
	    char UnknownData8[0x8]; // 0x128
	    struct FScalarMaterialInput PixelDepthOffset; // 0x130 Size: 0xc
	    bool bEnableSeparateTranslucency; // 0x144 Size: 0x1
	    bool bEnableMobileSeparateTranslucency; // 0x144 Size: 0x1
	    bool bEnableResponsiveAA; // 0x144 Size: 0x1
	    bool bScreenSpaceReflections; // 0x144 Size: 0x1
	    bool bContactShadows; // 0x144 Size: 0x1
	    bool TwoSided; // 0x144 Size: 0x1
	    bool DitheredLODTransition; // 0x144 Size: 0x1
	    bool DitherOpacityMask; // 0x144 Size: 0x1
	    bool bAllowNegativeEmissiveColor; // 0x145 Size: 0x1
	    char UnknownData9[0x3]; // 0x145
	    int NumCustomizedUVs; // 0x148 Size: 0x4
	    char TranslucencyLightingMode; // 0x14c Size: 0x1
	    char UnknownData10[0x3]; // 0x14d
	    float TranslucencyDirectionalLightingIntensity; // 0x150 Size: 0x4
	    bool AllowTranslucentCustomDepthWrites; // 0x154 Size: 0x1
	    char UnknownData11[0x3]; // 0x155
	    float TranslucentShadowDensityScale; // 0x158 Size: 0x4
	    float TranslucentSelfShadowDensityScale; // 0x15c Size: 0x4
	    float TranslucentSelfShadowSecondDensityScale; // 0x160 Size: 0x4
	    float TranslucentSelfShadowSecondOpacity; // 0x164 Size: 0x4
	    float TranslucentBackscatteringExponent; // 0x168 Size: 0x4
	    struct FLinearColor TranslucentMultipleScatteringExtinction; // 0x16c Size: 0x10
	    float TranslucentShadowStartOffset; // 0x17c Size: 0x4
	    bool bDisableDepthTest; // 0x180 Size: 0x1
	    bool bWriteOnlyAlpha; // 0x180 Size: 0x1
	    bool bGenerateSphericalParticleNormals; // 0x180 Size: 0x1
	    bool bTangentSpaceNormal; // 0x180 Size: 0x1
	    bool bUseEmissiveForDynamicAreaLighting; // 0x180 Size: 0x1
	    bool bBlockGI; // 0x180 Size: 0x1
	    bool bUsedAsSpecialEngineMaterial; // 0x180 Size: 0x1
	    bool bUsedWithSkeletalMesh; // 0x180 Size: 0x1
	    bool bUsedWithEditorCompositing; // 0x181 Size: 0x1
	    bool bUsedWithParticleSprites; // 0x181 Size: 0x1
	    bool bUsedWithBeamTrails; // 0x181 Size: 0x1
	    bool bUsedWithMeshParticles; // 0x181 Size: 0x1
	    bool bUsedWithNiagaraSprites; // 0x181 Size: 0x1
	    bool bUsedWithNiagaraRibbons; // 0x181 Size: 0x1
	    bool bUsedWithNiagaraMeshParticles; // 0x181 Size: 0x1
	    bool bUsedWithGeometryCache; // 0x181 Size: 0x1
	    bool bUsedWithStaticLighting; // 0x182 Size: 0x1
	    bool bUsedWithMorphTargets; // 0x182 Size: 0x1
	    bool bUsedWithSplineMeshes; // 0x182 Size: 0x1
	    bool bUsedWithInstancedStaticMeshes; // 0x182 Size: 0x1
	    bool bUsesDistortion; // 0x182 Size: 0x1
	    bool bUsedWithClothing; // 0x182 Size: 0x1
	    bool bUsedWithUI; // 0x182 Size: 0x1
	    bool bAutomaticallySetUsageInEditor; // 0x182 Size: 0x1
	    bool bFullyRough; // 0x183 Size: 0x1
	    bool bUseFullPrecision; // 0x183 Size: 0x1
	    bool bUseLightmapDirectionality; // 0x183 Size: 0x1
	    bool bUseHQForwardReflections; // 0x183 Size: 0x1
	    bool bUsePlanarForwardReflections; // 0x183 Size: 0x1
	    bool bNormalCurvatureToRoughness; // 0x183 Size: 0x1
	    char UnknownData12[0x1a]; // 0x19e
	    char D3D11TessellationMode; // 0x184 Size: 0x1
	    bool bEnableCrackFreeDisplacement; // 0x188 Size: 0x1
	    bool bEnableAdaptiveTessellation; // 0x188 Size: 0x1
	    char UnknownData13[0x5]; // 0x187
	    float MaxDisplacement; // 0x18c Size: 0x4
	    bool Wireframe; // 0x190 Size: 0x1
	    bool bOutputVelocityOnBasePass; // 0x190 Size: 0x1
	    char UnknownData14[0x6]; // 0x192
	    TArray<class UMaterialExpression*> Expressions; // 0x198 Size: 0x10
	    TArray<struct FMaterialFunctionInfo> MaterialFunctionInfos; // 0x1a8 Size: 0x10
	    TArray<struct FMaterialParameterCollectionInfo> MaterialParameterCollectionInfos; // 0x1b8 Size: 0x10
	    bool bCanMaskedBeAssumedOpaque; // 0x1c8 Size: 0x1
	    bool bIsMasked; // 0x1c8 Size: 0x1
	    bool bIsPreviewMaterial; // 0x1c8 Size: 0x1
	    bool bIsFunctionPreviewMaterial; // 0x1c8 Size: 0x1
	    bool bUseMaterialAttributes; // 0x1c8 Size: 0x1
	    bool bUseTranslucencyVertexFog; // 0x1c8 Size: 0x1
	    bool bComputeFogPerPixel; // 0x1c8 Size: 0x1
	    bool bAllowDevelopmentShaderCompile; // 0x1c8 Size: 0x1
	    bool bIsMaterialEditorStatsMaterial; // 0x1c9 Size: 0x1
	    char UnknownData15[0x5]; // 0x1d1
	    uint32_t UsageFlagWarnings; // 0x1cc Size: 0x4
	    char BlendableLocation; // 0x1d0 Size: 0x1
	    char UnknownData16[0x3]; // 0x1d1
	    int BlendablePriority; // 0x1d4 Size: 0x4
	    bool BlendableOutputAlpha; // 0x1d8 Size: 0x1
	    char RefractionMode; // 0x1d9 Size: 0x1
	    char UnknownData17[0x2]; // 0x1da
	    float RefractionDepthBias; // 0x1dc Size: 0x4
	    struct FGuid StateId; // 0x1e0 Size: 0x10
	    char UnknownData18[0x20]; // 0x1f0
	    TArray<bool> CachedQualityLevelsUsed; // 0x210 Size: 0x10
	    char UnknownData19[0x80]; // 0x220
	    TArray<class UTexture*> ExpressionTextureReferences; // 0x2a0 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Material");
			return (class UClass*)ptr;
		};

};

class UMaterialBillboardComponent : public UPrimitiveComponent
{
	public:
	    TArray<struct FMaterialSpriteElement> Elements; // 0x570 Size: 0x10
	    char UnknownData0[0x580]; // 0x580
	    void SetElements(TArray<struct FMaterialSpriteElement> NewElements); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void AddElement(class UMaterialInterface* Material, class UCurveFloat* DistanceToOpacityCurve, bool bSizeIsInScreenSpace, float BaseSizeX, float BaseSizeY, class UCurveFloat* DistanceToSizeCurve); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7a61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialBillboardComponent");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionAbs : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionAbs");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionActorPositionWS : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionActorPositionWS");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionAdd : public UMaterialExpression
{
	public:
	    struct FExpressionInput A; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput B; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    float ConstA; // 0x68 Size: 0x4
	    float ConstB; // 0x6c Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionAdd");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionAntialiasedTextureMask : public UMaterialExpressionTextureSampleParameter2D
{
	public:
	    float Threshold; // 0x100 Size: 0x4
	    char Channel; // 0x104 Size: 0x1
	    char UnknownData0[0x3];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionAntialiasedTextureMask");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionAppendVector : public UMaterialExpression
{
	public:
	    struct FExpressionInput A; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput B; // 0x54 Size: 0xc
	    char UnknownData1[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionAppendVector");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionArccosine : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionArccosine");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionArccosineFast : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionArccosineFast");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionArcsine : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionArcsine");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionArcsineFast : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionArcsineFast");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionArctangent : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionArctangent");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionArctangent2 : public UMaterialExpression
{
	public:
	    struct FExpressionInput Y; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput X; // 0x54 Size: 0xc
	    char UnknownData1[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionArctangent2");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionArctangent2Fast : public UMaterialExpression
{
	public:
	    struct FExpressionInput Y; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput X; // 0x54 Size: 0xc
	    char UnknownData1[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionArctangent2Fast");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionArctangentFast : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionArctangentFast");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionAtmosphericFogColor : public UMaterialExpression
{
	public:
	    struct FExpressionInput WorldPosition; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionAtmosphericFogColor");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionAtmosphericLightColor : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionAtmosphericLightColor");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionAtmosphericLightVector : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionAtmosphericLightVector");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionBentNormalCustomOutput : public UMaterialExpressionCustomOutput
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionBentNormalCustomOutput");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionBlackBody : public UMaterialExpression
{
	public:
	    struct FExpressionInput Temp; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionBlackBody");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionBlendMaterialAttributes : public UMaterialExpression
{
	public:
	    struct FMaterialAttributesInput A; // 0x40 Size: 0x10
	    char UnknownData0[0x8]; // 0x50
	    struct FMaterialAttributesInput B; // 0x58 Size: 0x10
	    char UnknownData1[0x8]; // 0x68
	    struct FExpressionInput Alpha; // 0x70 Size: 0xc
	    char UnknownData2[0x8]; // 0x7c
	    char PixelAttributeBlendType; // 0x84 Size: 0x1
	    char VertexAttributeBlendType; // 0x85 Size: 0x1
	    char UnknownData3[0x2];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionBlendMaterialAttributes");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionBreakMaterialAttributes : public UMaterialExpression
{
	public:
	    struct FMaterialAttributesInput MaterialAttributes; // 0x40 Size: 0x10
	    char UnknownData0[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionBreakMaterialAttributes");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionBumpOffset : public UMaterialExpression
{
	public:
	    struct FExpressionInput Coordinate; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput Height; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    struct FExpressionInput HeightRatioInput; // 0x68 Size: 0xc
	    char UnknownData2[0x8]; // 0x74
	    float HeightRatio; // 0x7c Size: 0x4
	    float ReferencePlane; // 0x80 Size: 0x4
	    uint32_t ConstCoordinate; // 0x84 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionBumpOffset");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionCameraPositionWS : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionCameraPositionWS");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionCameraVectorWS : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionCameraVectorWS");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionCeil : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionCeil");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionParameter : public UMaterialExpression
{
	public:
	    FName ParameterName; // 0x40 Size: 0x8
	    struct FGuid ExpressionGUID; // 0x48 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionParameter");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionVectorParameter : public UMaterialExpressionParameter
{
	public:
	    struct FLinearColor DefaultValue; // 0x58 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionVectorParameter");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionChannelMaskParameter : public UMaterialExpressionVectorParameter
{
	public:
	    char MaskChannel; // 0x68 Size: 0x1
	    char UnknownData0[0x3]; // 0x69
	    struct FExpressionInput Input; // 0x6c Size: 0xc
	    char UnknownData1[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionChannelMaskParameter");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionClamp : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput Min; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    struct FExpressionInput Max; // 0x68 Size: 0xc
	    char UnknownData2[0x8]; // 0x74
	    char ClampMode; // 0x7c Size: 0x1
	    char UnknownData3[0x3]; // 0x7d
	    float MinDefault; // 0x80 Size: 0x4
	    float MaxDefault; // 0x84 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionClamp");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionClearCoatNormalCustomOutput : public UMaterialExpressionCustomOutput
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionClearCoatNormalCustomOutput");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionCollectionParameter : public UMaterialExpression
{
	public:
	    class UMaterialParameterCollection* Collection; // 0x40 Size: 0x8
	    FName ParameterName; // 0x48 Size: 0x8
	    struct FGuid ParameterId; // 0x50 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionCollectionParameter");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionComment : public UMaterialExpression
{
	public:
	    int SizeX; // 0x40 Size: 0x4
	    int SizeY; // 0x44 Size: 0x4
	    struct FString Text; // 0x48 Size: 0x10
	    struct FLinearColor CommentColor; // 0x58 Size: 0x10
	    int FontSize; // 0x68 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionComment");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionComponentMask : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    bool R; // 0x54 Size: 0x1
	    bool G; // 0x54 Size: 0x1
	    bool B; // 0x54 Size: 0x1
	    bool A; // 0x54 Size: 0x1
	    char UnknownData0[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionComponentMask");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionConstant : public UMaterialExpression
{
	public:
	    float R; // 0x40 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionConstant");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionConstant2Vector : public UMaterialExpression
{
	public:
	    float R; // 0x40 Size: 0x4
	    float G; // 0x44 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionConstant2Vector");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionConstant3Vector : public UMaterialExpression
{
	public:
	    struct FLinearColor Constant; // 0x40 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionConstant3Vector");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionConstant4Vector : public UMaterialExpression
{
	public:
	    struct FLinearColor Constant; // 0x40 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionConstant4Vector");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionConstantBiasScale : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    float Bias; // 0x54 Size: 0x4
	    float Scale; // 0x58 Size: 0x4
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionConstantBiasScale");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionCosine : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    float Period; // 0x54 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionCosine");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionCrossProduct : public UMaterialExpression
{
	public:
	    struct FExpressionInput A; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput B; // 0x54 Size: 0xc
	    char UnknownData1[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionCrossProduct");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionScalarParameter : public UMaterialExpressionParameter
{
	public:
	    float DefaultValue; // 0x58 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionScalarParameter");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionCurveAtlasRowParameter : public UMaterialExpressionScalarParameter
{
	public:
	    class UCurveLinearColor* Curve; // 0x60 Size: 0x8
	    class UCurveLinearColorAtlas* Atlas; // 0x68 Size: 0x8
	    struct FExpressionInput InputTime; // 0x70 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionCurveAtlasRowParameter");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionCustom : public UMaterialExpression
{
	public:
	    struct FString Code; // 0x40 Size: 0x10
	    char OutputType; // 0x50 Size: 0x1
	    char UnknownData0[0x7]; // 0x51
	    struct FString Description; // 0x58 Size: 0x10
	    TArray<struct FCustomInput> Inputs; // 0x68 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionCustom");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionDDX : public UMaterialExpression
{
	public:
	    struct FExpressionInput Value; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionDDX");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionDDY : public UMaterialExpression
{
	public:
	    struct FExpressionInput Value; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionDDY");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionDecalDerivative : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionDecalDerivative");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionDecalLifetimeOpacity : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionDecalLifetimeOpacity");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionDecalMipmapLevel : public UMaterialExpression
{
	public:
	    struct FExpressionInput TextureSize; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    float ConstWidth; // 0x54 Size: 0x4
	    float ConstHeight; // 0x58 Size: 0x4
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionDecalMipmapLevel");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionDepthFade : public UMaterialExpression
{
	public:
	    struct FExpressionInput InOpacity; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput FadeDistance; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    float OpacityDefault; // 0x68 Size: 0x4
	    float FadeDistanceDefault; // 0x6c Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionDepthFade");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionDepthOfFieldFunction : public UMaterialExpression
{
	public:
	    char FunctionValue; // 0x40 Size: 0x1
	    char UnknownData0[0x3]; // 0x41
	    struct FExpressionInput Depth; // 0x44 Size: 0xc
	    char UnknownData1[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionDepthOfFieldFunction");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionDeriveNormalZ : public UMaterialExpression
{
	public:
	    struct FExpressionInput InXY; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionDeriveNormalZ");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionDesaturation : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput Fraction; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    struct FLinearColor LuminanceFactors; // 0x68 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionDesaturation");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionDistance : public UMaterialExpression
{
	public:
	    struct FExpressionInput A; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput B; // 0x54 Size: 0xc
	    char UnknownData1[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionDistance");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionDistanceCullFade : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionDistanceCullFade");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionDistanceFieldGradient : public UMaterialExpression
{
	public:
	    struct FExpressionInput Position; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionDistanceFieldGradient");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionDistanceToNearestSurface : public UMaterialExpression
{
	public:
	    struct FExpressionInput Position; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionDistanceToNearestSurface");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionDivide : public UMaterialExpression
{
	public:
	    struct FExpressionInput A; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput B; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    float ConstA; // 0x68 Size: 0x4
	    float ConstB; // 0x6c Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionDivide");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionDotProduct : public UMaterialExpression
{
	public:
	    struct FExpressionInput A; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput B; // 0x54 Size: 0xc
	    char UnknownData1[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionDotProduct");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionDynamicParameter : public UMaterialExpression
{
	public:
	    TArray<struct FString> ParamNames; // 0x40 Size: 0x10
	    struct FLinearColor DefaultValue; // 0x50 Size: 0x10
	    uint32_t ParameterIndex; // 0x60 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionDynamicParameter");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionEyeAdaptation : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionEyeAdaptation");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionFeatureLevelSwitch : public UMaterialExpression
{
	public:
	    struct FExpressionInput Default; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput* Inputs; // 0x54 Size: 0xc
	    char UnknownData1[0x48];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionFeatureLevelSwitch");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionFloor : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionFloor");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionFmod : public UMaterialExpression
{
	public:
	    struct FExpressionInput A; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput B; // 0x54 Size: 0xc
	    char UnknownData1[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionFmod");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionFontSample : public UMaterialExpression
{
	public:
	    class UFont* Font; // 0x40 Size: 0x8
	    int FontTexturePage; // 0x48 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionFontSample");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionFontSampleParameter : public UMaterialExpressionFontSample
{
	public:
	    FName ParameterName; // 0x50 Size: 0x8
	    struct FGuid ExpressionGUID; // 0x58 Size: 0x10
	    FName Group; // 0x68 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionFontSampleParameter");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionFrac : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionFrac");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionFresnel : public UMaterialExpression
{
	public:
	    struct FExpressionInput ExponentIn; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    float Exponent; // 0x54 Size: 0x4
	    struct FExpressionInput BaseReflectFractionIn; // 0x58 Size: 0xc
	    char UnknownData1[0x8]; // 0x64
	    float BaseReflectFraction; // 0x6c Size: 0x4
	    struct FExpressionInput Normal; // 0x70 Size: 0xc
	    char UnknownData2[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionFresnel");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionFunctionInput : public UMaterialExpression
{
	public:
	    struct FExpressionInput Preview; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    FName InputName; // 0x54 Size: 0x8
	    char UnknownData1[0x4]; // 0x5c
	    struct FString Description; // 0x60 Size: 0x10
	    struct FGuid ID; // 0x70 Size: 0x10
	    char InputType; // 0x80 Size: 0x1
	    char UnknownData2[0xf]; // 0x81
	    struct FVector4 PreviewValue; // 0x90 Size: 0x10
	    bool bUsePreviewValueAsDefault; // 0xa0 Size: 0x1
	    char UnknownData3[0x3]; // 0xa1
	    int SortPriority; // 0xa4 Size: 0x4
	    bool bCompilingFunctionPreview; // 0xa8 Size: 0x1
	    char UnknownData4[0x17];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionFunctionInput");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionFunctionOutput : public UMaterialExpression
{
	public:
	    FName OutputName; // 0x40 Size: 0x8
	    struct FString Description; // 0x48 Size: 0x10
	    int SortPriority; // 0x58 Size: 0x4
	    struct FExpressionInput A; // 0x5c Size: 0xc
	    bool bLastPreviewed; // 0x70 Size: 0x1
	    char UnknownData0[0xb]; // 0x69
	    struct FGuid ID; // 0x74 Size: 0x10
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionFunctionOutput");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionGetMaterialAttributes : public UMaterialExpression
{
	public:
	    struct FMaterialAttributesInput MaterialAttributes; // 0x40 Size: 0x10
	    char UnknownData0[0x8]; // 0x50
	    TArray<struct FGuid> AttributeGetTypes; // 0x58 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionGetMaterialAttributes");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionGIReplace : public UMaterialExpression
{
	public:
	    struct FExpressionInput Default; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput StaticIndirect; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    struct FExpressionInput DynamicIndirect; // 0x68 Size: 0xc
	    char UnknownData2[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionGIReplace");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionIf : public UMaterialExpression
{
	public:
	    struct FExpressionInput A; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput B; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    struct FExpressionInput AGreaterThanB; // 0x68 Size: 0xc
	    char UnknownData2[0x8]; // 0x74
	    struct FExpressionInput AEqualsB; // 0x7c Size: 0xc
	    char UnknownData3[0x8]; // 0x88
	    struct FExpressionInput ALessThanB; // 0x90 Size: 0xc
	    char UnknownData4[0x8]; // 0x9c
	    float EqualsThreshold; // 0xa4 Size: 0x4
	    float ConstB; // 0xa8 Size: 0x4
	    float ConstAEqualsB; // 0xac Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionIf");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionLightmapUVs : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionLightmapUVs");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionLightmassReplace : public UMaterialExpression
{
	public:
	    struct FExpressionInput Realtime; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput Lightmass; // 0x54 Size: 0xc
	    char UnknownData1[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionLightmassReplace");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionLightVector : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionLightVector");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionLinearInterpolate : public UMaterialExpression
{
	public:
	    struct FExpressionInput A; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput B; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    struct FExpressionInput Alpha; // 0x68 Size: 0xc
	    char UnknownData2[0x8]; // 0x74
	    float ConstA; // 0x7c Size: 0x4
	    float ConstB; // 0x80 Size: 0x4
	    float ConstAlpha; // 0x84 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionLinearInterpolate");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionLogarithm10 : public UMaterialExpression
{
	public:
	    struct FExpressionInput X; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionLogarithm10");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionLogarithm2 : public UMaterialExpression
{
	public:
	    struct FExpressionInput X; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionLogarithm2");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionMakeMaterialAttributes : public UMaterialExpression
{
	public:
	    struct FExpressionInput BaseColor; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput Metallic; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    struct FExpressionInput Specular; // 0x68 Size: 0xc
	    char UnknownData2[0x8]; // 0x74
	    struct FExpressionInput Roughness; // 0x7c Size: 0xc
	    char UnknownData3[0x8]; // 0x88
	    struct FExpressionInput EmissiveColor; // 0x90 Size: 0xc
	    char UnknownData4[0x8]; // 0x9c
	    struct FExpressionInput Opacity; // 0xa4 Size: 0xc
	    char UnknownData5[0x8]; // 0xb0
	    struct FExpressionInput OpacityMask; // 0xb8 Size: 0xc
	    char UnknownData6[0x8]; // 0xc4
	    struct FExpressionInput Normal; // 0xcc Size: 0xc
	    char UnknownData7[0x8]; // 0xd8
	    struct FExpressionInput WorldPositionOffset; // 0xe0 Size: 0xc
	    char UnknownData8[0x8]; // 0xec
	    struct FExpressionInput WorldDisplacement; // 0xf4 Size: 0xc
	    char UnknownData9[0x8]; // 0x100
	    struct FExpressionInput TessellationMultiplier; // 0x108 Size: 0xc
	    char UnknownData10[0x8]; // 0x114
	    struct FExpressionInput SubsurfaceColor; // 0x11c Size: 0xc
	    char UnknownData11[0x8]; // 0x128
	    struct FExpressionInput ClearCoat; // 0x130 Size: 0xc
	    char UnknownData12[0x8]; // 0x13c
	    struct FExpressionInput ClearCoatRoughness; // 0x144 Size: 0xc
	    char UnknownData13[0x8]; // 0x150
	    struct FExpressionInput AmbientOcclusion; // 0x158 Size: 0xc
	    char UnknownData14[0x8]; // 0x164
	    struct FExpressionInput Refraction; // 0x16c Size: 0xc
	    char UnknownData15[0x8]; // 0x178
	    struct FExpressionInput* CustomizedUVs; // 0x180 Size: 0xc
	    char UnknownData16[0x94]; // 0x18c
	    struct FExpressionInput PixelDepthOffset; // 0x220 Size: 0xc
	    char UnknownData17[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionMakeMaterialAttributes");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionMaterialAttributeLayers : public UMaterialExpression
{
	public:
	    FName ParameterName; // 0x40 Size: 0x8
	    struct FGuid ExpressionGUID; // 0x48 Size: 0x10
	    struct FMaterialAttributesInput Input; // 0x58 Size: 0x10
	    char UnknownData0[0x8]; // 0x68
	    struct FMaterialLayersFunctions DefaultLayers; // 0x70 Size: 0x40
	    TArray<class UMaterialExpressionMaterialFunctionCall*> LayerCallers; // 0xb0 Size: 0x10
	    int NumActiveLayerCallers; // 0xc0 Size: 0x4
	    char UnknownData1[0x4]; // 0xc4
	    TArray<class UMaterialExpressionMaterialFunctionCall*> BlendCallers; // 0xc8 Size: 0x10
	    int NumActiveBlendCallers; // 0xd8 Size: 0x4
	    bool bIsLayerGraphBuilt; // 0xdc Size: 0x1
	    char UnknownData2[0xb];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionMaterialAttributeLayers");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionMaterialFunctionCall : public UMaterialExpression
{
	public:
	    class UMaterialFunctionInterface* MaterialFunction; // 0x40 Size: 0x8
	    struct FMaterialParameterInfo FunctionParameterInfo; // 0x48 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionMaterialFunctionCall");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionMaterialLayerOutput : public UMaterialExpressionFunctionOutput
{
	public:
	    char UnknownData0[0x88];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionMaterialLayerOutput");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionMaterialProxyReplace : public UMaterialExpression
{
	public:
	    struct FExpressionInput Realtime; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput MaterialProxy; // 0x54 Size: 0xc
	    char UnknownData1[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionMaterialProxyReplace");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionMax : public UMaterialExpression
{
	public:
	    struct FExpressionInput A; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput B; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    float ConstA; // 0x68 Size: 0x4
	    float ConstB; // 0x6c Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionMax");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionMin : public UMaterialExpression
{
	public:
	    struct FExpressionInput A; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput B; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    float ConstA; // 0x68 Size: 0x4
	    float ConstB; // 0x6c Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionMin");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionMultiply : public UMaterialExpression
{
	public:
	    struct FExpressionInput A; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput B; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    float ConstA; // 0x68 Size: 0x4
	    float ConstB; // 0x6c Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionMultiply");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionNoise : public UMaterialExpression
{
	public:
	    struct FExpressionInput Position; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput FilterWidth; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    float Scale; // 0x68 Size: 0x4
	    int Quality; // 0x6c Size: 0x4
	    char NoiseFunction; // 0x70 Size: 0x1
	    bool bTurbulence; // 0x74 Size: 0x1
	    char UnknownData2[0x6]; // 0x72
	    int Levels; // 0x78 Size: 0x4
	    float OutputMin; // 0x7c Size: 0x4
	    float OutputMax; // 0x80 Size: 0x4
	    float LevelScale; // 0x84 Size: 0x4
	    bool bTiling; // 0x88 Size: 0x1
	    char UnknownData3[0x3]; // 0x89
	    uint32_t RepeatSize; // 0x8c Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionNoise");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionNormalize : public UMaterialExpression
{
	public:
	    struct FExpressionInput VectorInput; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionNormalize");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionObjectBounds : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionObjectBounds");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionObjectOrientation : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionObjectOrientation");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionObjectPositionWS : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionObjectPositionWS");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionObjectRadius : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionObjectRadius");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionOneMinus : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionOneMinus");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionPanner : public UMaterialExpression
{
	public:
	    struct FExpressionInput Coordinate; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput Time; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    struct FExpressionInput Speed; // 0x68 Size: 0xc
	    char UnknownData2[0x8]; // 0x74
	    float SpeedX; // 0x7c Size: 0x4
	    float SpeedY; // 0x80 Size: 0x4
	    uint32_t ConstCoordinate; // 0x84 Size: 0x4
	    bool bFractionalPart; // 0x88 Size: 0x1
	    char UnknownData3[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionPanner");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionParticleColor : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionParticleColor");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionParticleDirection : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionParticleDirection");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionParticleMacroUV : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionParticleMacroUV");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionParticleMotionBlurFade : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionParticleMotionBlurFade");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionParticlePositionWS : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionParticlePositionWS");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionParticleRadius : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionParticleRadius");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionParticleRandom : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionParticleRandom");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionParticleRelativeTime : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionParticleRelativeTime");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionParticleSize : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionParticleSize");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionParticleSpeed : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionParticleSpeed");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionParticleSubUV : public UMaterialExpressionTextureSample
{
	public:
	    bool bBlend; // 0xe0 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionParticleSubUV");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionPerInstanceFadeAmount : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionPerInstanceFadeAmount");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionPerInstanceRandom : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionPerInstanceRandom");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionPixelDepth : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionPixelDepth");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionPixelNormalWS : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionPixelNormalWS");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionPower : public UMaterialExpression
{
	public:
	    struct FExpressionInput Base; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput Exponent; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    float ConstExponent; // 0x68 Size: 0x4
	    char UnknownData2[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionPower");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionPrecomputedAOMask : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionPrecomputedAOMask");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionPreSkinnedNormal : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionPreSkinnedNormal");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionPreSkinnedPosition : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionPreSkinnedPosition");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionPreviousFrameSwitch : public UMaterialExpression
{
	public:
	    struct FExpressionInput CurrentFrame; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput PreviousFrame; // 0x54 Size: 0xc
	    char UnknownData1[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionPreviousFrameSwitch");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionQualitySwitch : public UMaterialExpression
{
	public:
	    struct FExpressionInput Default; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput* Inputs; // 0x54 Size: 0xc
	    char UnknownData1[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionQualitySwitch");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionReflectionVectorWS : public UMaterialExpression
{
	public:
	    struct FExpressionInput CustomWorldNormal; // 0x40 Size: 0xc
	    bool bNormalizeCustomWorldNormal; // 0x54 Size: 0x1
	    char UnknownData0[0xb];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionReflectionVectorWS");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionReroute : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionReroute");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionRotateAboutAxis : public UMaterialExpression
{
	public:
	    struct FExpressionInput NormalizedRotationAxis; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput RotationAngle; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    struct FExpressionInput PivotPoint; // 0x68 Size: 0xc
	    char UnknownData2[0x8]; // 0x74
	    struct FExpressionInput Position; // 0x7c Size: 0xc
	    char UnknownData3[0x8]; // 0x88
	    float Period; // 0x90 Size: 0x4
	    char UnknownData4[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionRotateAboutAxis");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionRotator : public UMaterialExpression
{
	public:
	    struct FExpressionInput Coordinate; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput Time; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    float CenterX; // 0x68 Size: 0x4
	    float CenterY; // 0x6c Size: 0x4
	    float Speed; // 0x70 Size: 0x4
	    uint32_t ConstCoordinate; // 0x74 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionRotator");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionRound : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionRound");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionSaturate : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionSaturate");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionSceneColor : public UMaterialExpression
{
	public:
	    char InputMode; // 0x40 Size: 0x1
	    char UnknownData0[0x3]; // 0x41
	    struct FExpressionInput Input; // 0x44 Size: 0xc
	    char UnknownData1[0x8]; // 0x50
	    struct FExpressionInput OffsetFraction; // 0x58 Size: 0xc
	    char UnknownData2[0x8]; // 0x64
	    struct FVector2D ConstInput; // 0x6c Size: 0x8
	    char UnknownData3[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionSceneColor");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionSceneDepth : public UMaterialExpression
{
	public:
	    char InputMode; // 0x40 Size: 0x1
	    char UnknownData0[0x3]; // 0x41
	    struct FExpressionInput Input; // 0x44 Size: 0xc
	    char UnknownData1[0x8]; // 0x50
	    struct FExpressionInput Coordinates; // 0x58 Size: 0xc
	    char UnknownData2[0x8]; // 0x64
	    struct FVector2D ConstInput; // 0x6c Size: 0x8
	    char UnknownData3[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionSceneDepth");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionSceneTexelSize : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionSceneTexelSize");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionSceneTexture : public UMaterialExpression
{
	public:
	    struct FExpressionInput Coordinates; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    char SceneTextureId; // 0x54 Size: 0x1
	    bool bFiltered; // 0x55 Size: 0x1
	    char UnknownData1[0x2];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionSceneTexture");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionScreenPosition : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionScreenPosition");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionSetMaterialAttributes : public UMaterialExpression
{
	public:
	    TArray<struct FExpressionInput> Inputs; // 0x40 Size: 0x10
	    TArray<struct FGuid> AttributeSetTypes; // 0x50 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionSetMaterialAttributes");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionShadingPathSwitch : public UMaterialExpression
{
	public:
	    struct FExpressionInput Default; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput* Inputs; // 0x54 Size: 0xc
	    char UnknownData1[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionShadingPathSwitch");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionSign : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionSign");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionSine : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    float Period; // 0x54 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionSine");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionSobol : public UMaterialExpression
{
	public:
	    struct FExpressionInput Cell; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput Index; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    struct FExpressionInput Seed; // 0x68 Size: 0xc
	    char UnknownData2[0x8]; // 0x74
	    uint32_t ConstIndex; // 0x7c Size: 0x4
	    struct FVector2D ConstSeed; // 0x80 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionSobol");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionSpeedTree : public UMaterialExpression
{
	public:
	    struct FExpressionInput GeometryInput; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput WindInput; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    struct FExpressionInput LODInput; // 0x68 Size: 0xc
	    char UnknownData2[0x8]; // 0x74
	    struct FExpressionInput ExtraBendWS; // 0x7c Size: 0xc
	    char UnknownData3[0x8]; // 0x88
	    char GeometryType; // 0x90 Size: 0x1
	    char WindType; // 0x91 Size: 0x1
	    char LODType; // 0x92 Size: 0x1
	    char UnknownData4[0x1]; // 0x93
	    float BillboardThreshold; // 0x94 Size: 0x4
	    bool bAccurateWindVelocities; // 0x98 Size: 0x1
	    char UnknownData5[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionSpeedTree");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionSphereMask : public UMaterialExpression
{
	public:
	    struct FExpressionInput A; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput B; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    struct FExpressionInput Radius; // 0x68 Size: 0xc
	    char UnknownData2[0x8]; // 0x74
	    struct FExpressionInput Hardness; // 0x7c Size: 0xc
	    char UnknownData3[0x8]; // 0x88
	    float AttenuationRadius; // 0x90 Size: 0x4
	    float HardnessPercent; // 0x94 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionSphereMask");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionSphericalParticleOpacity : public UMaterialExpression
{
	public:
	    struct FExpressionInput Density; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    float ConstantDensity; // 0x54 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionSphericalParticleOpacity");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionSquareRoot : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionSquareRoot");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionStaticBool : public UMaterialExpression
{
	public:
	    bool Value; // 0x40 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionStaticBool");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionStaticBoolParameter : public UMaterialExpressionParameter
{
	public:
	    bool DefaultValue; // 0x58 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionStaticBoolParameter");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionStaticComponentMaskParameter : public UMaterialExpressionParameter
{
	public:
	    struct FExpressionInput Input; // 0x58 Size: 0xc
	    bool DefaultR; // 0x6c Size: 0x1
	    bool DefaultG; // 0x6c Size: 0x1
	    bool DefaultB; // 0x6c Size: 0x1
	    bool DefaultA; // 0x6c Size: 0x1
	    char UnknownData0[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionStaticComponentMaskParameter");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionStaticSwitch : public UMaterialExpression
{
	public:
	    bool DefaultValue; // 0x40 Size: 0x1
	    char UnknownData0[0x3]; // 0x41
	    struct FExpressionInput A; // 0x44 Size: 0xc
	    char UnknownData1[0x8]; // 0x50
	    struct FExpressionInput B; // 0x58 Size: 0xc
	    char UnknownData2[0x8]; // 0x64
	    struct FExpressionInput Value; // 0x6c Size: 0xc
	    char UnknownData3[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionStaticSwitch");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionStaticSwitchParameter : public UMaterialExpressionStaticBoolParameter
{
	public:
	    struct FExpressionInput A; // 0x60 Size: 0xc
	    char UnknownData0[0x8]; // 0x6c
	    struct FExpressionInput B; // 0x74 Size: 0xc
	    char UnknownData1[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionStaticSwitchParameter");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionSubtract : public UMaterialExpression
{
	public:
	    struct FExpressionInput A; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput B; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    float ConstA; // 0x68 Size: 0x4
	    float ConstB; // 0x6c Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionSubtract");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionTangent : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    float Period; // 0x54 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionTangent");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionTangentOutput : public UMaterialExpressionCustomOutput
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionTangentOutput");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionTemporalSobol : public UMaterialExpression
{
	public:
	    struct FExpressionInput Index; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    struct FExpressionInput Seed; // 0x54 Size: 0xc
	    char UnknownData1[0x8]; // 0x60
	    uint32_t ConstIndex; // 0x68 Size: 0x4
	    struct FVector2D ConstSeed; // 0x6c Size: 0x8
	    char UnknownData2[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionTemporalSobol");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionTextureCoordinate : public UMaterialExpression
{
	public:
	    int CoordinateIndex; // 0x40 Size: 0x4
	    float UTiling; // 0x44 Size: 0x4
	    float VTiling; // 0x48 Size: 0x4
	    bool UnMirrorU; // 0x4c Size: 0x1
	    bool UnMirrorV; // 0x4c Size: 0x1
	    char UnknownData0[0x2];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionTextureCoordinate");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionTextureObject : public UMaterialExpressionTextureBase
{
	public:
	    char UnknownData0[0x50];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionTextureObject");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionTextureObjectParameter : public UMaterialExpressionTextureSampleParameter
{
	public:
	    char UnknownData0[0x100];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionTextureObjectParameter");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionTextureProperty : public UMaterialExpression
{
	public:
	    struct FExpressionInput TextureObject; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    char Property; // 0x54 Size: 0x1
	    char UnknownData1[0x3];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionTextureProperty");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionTextureSampleParameterCube : public UMaterialExpressionTextureSampleParameter
{
	public:
	    char UnknownData0[0x100];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionTextureSampleParameterCube");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionTextureSampleParameterSubUV : public UMaterialExpressionTextureSampleParameter2D
{
	public:
	    bool bBlend; // 0x100 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionTextureSampleParameterSubUV");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionTextureSampleParameterVolume : public UMaterialExpressionTextureSampleParameter
{
	public:
	    char UnknownData0[0x100];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionTextureSampleParameterVolume");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionTime : public UMaterialExpression
{
	public:
	    bool bIgnorePause; // 0x40 Size: 0x1
	    bool bOverride_Period; // 0x40 Size: 0x1
	    char UnknownData0[0x2]; // 0x42
	    float Period; // 0x44 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionTime");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionTransform : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    char TransformSourceType; // 0x54 Size: 0x1
	    char TransformType; // 0x55 Size: 0x1
	    char UnknownData1[0x2];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionTransform");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionTransformPosition : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    char TransformSourceType; // 0x54 Size: 0x1
	    char TransformType; // 0x55 Size: 0x1
	    char UnknownData1[0x2];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionTransformPosition");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionTruncate : public UMaterialExpression
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0xc];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionTruncate");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionTwoSidedSign : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionTwoSidedSign");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionVectorNoise : public UMaterialExpression
{
	public:
	    struct FExpressionInput Position; // 0x40 Size: 0xc
	    char UnknownData0[0x8]; // 0x4c
	    char NoiseFunction; // 0x54 Size: 0x1
	    char UnknownData1[0x3]; // 0x55
	    int Quality; // 0x58 Size: 0x4
	    bool bTiling; // 0x5c Size: 0x1
	    char UnknownData2[0x3]; // 0x5d
	    uint32_t TileSize; // 0x60 Size: 0x4
	    char UnknownData3[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionVectorNoise");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionVertexColor : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionVertexColor");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionVertexInterpolator : public UMaterialExpressionCustomOutput
{
	public:
	    struct FExpressionInput Input; // 0x40 Size: 0xc
	    char UnknownData0[0x14];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionVertexInterpolator");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionVertexNormalWS : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionVertexNormalWS");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionViewProperty : public UMaterialExpression
{
	public:
	    char Property; // 0x40 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionViewProperty");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionViewSize : public UMaterialExpression
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionViewSize");
			return (class UClass*)ptr;
		};

};

class UMaterialExpressionWorldPosition : public UMaterialExpression
{
	public:
	    char WorldPositionShaderOffset; // 0x40 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialExpressionWorldPosition");
			return (class UClass*)ptr;
		};

};

class UMaterialFunctionInterface : public UObject
{
	public:
	    struct FGuid StateId; // 0x28 Size: 0x10
	    char MaterialFunctionUsage; // 0x38 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialFunctionInterface");
			return (class UClass*)ptr;
		};

};

class UMaterialFunction : public UMaterialFunctionInterface
{
	public:
	    struct FString Description; // 0x40 Size: 0x10
	    bool bExposeToLibrary; // 0x50 Size: 0x1
	    bool bPrefixParameterNames; // 0x50 Size: 0x1
	    char UnknownData0[0x6]; // 0x52
	    TArray<class UMaterialExpression*> FunctionExpressions; // 0x58 Size: 0x10
	    bool bReentrantFlag; // 0x68 Size: 0x1
	    char UnknownData1[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialFunction");
			return (class UClass*)ptr;
		};

};

class UMaterialFunctionInstance : public UMaterialFunctionInterface
{
	public:
	    class UMaterialFunctionInterface* Parent; // 0x40 Size: 0x8
	    class UMaterialFunctionInterface* Base; // 0x48 Size: 0x8
	    TArray<struct FScalarParameterValue> ScalarParameterValues; // 0x50 Size: 0x10
	    TArray<struct FVectorParameterValue> VectorParameterValues; // 0x60 Size: 0x10
	    TArray<struct FTextureParameterValue> TextureParameterValues; // 0x70 Size: 0x10
	    TArray<struct FFontParameterValue> FontParameterValues; // 0x80 Size: 0x10
	    TArray<struct FStaticSwitchParameter> StaticSwitchParameterValues; // 0x90 Size: 0x10
	    TArray<struct FStaticComponentMaskParameter> StaticComponentMaskParameterValues; // 0xa0 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialFunctionInstance");
			return (class UClass*)ptr;
		};

};

class UMaterialFunctionMaterialLayer : public UMaterialFunction
{
	public:
	    char UnknownData0[0x70];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialFunctionMaterialLayer");
			return (class UClass*)ptr;
		};

};

class UMaterialFunctionMaterialLayerInstance : public UMaterialFunctionInstance
{
	public:
	    char UnknownData0[0xb0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialFunctionMaterialLayerInstance");
			return (class UClass*)ptr;
		};

};

class UMaterialFunctionMaterialLayerBlend : public UMaterialFunction
{
	public:
	    char UnknownData0[0x70];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialFunctionMaterialLayerBlend");
			return (class UClass*)ptr;
		};

};

class UMaterialFunctionMaterialLayerBlendInstance : public UMaterialFunctionInstance
{
	public:
	    char UnknownData0[0xb0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialFunctionMaterialLayerBlendInstance");
			return (class UClass*)ptr;
		};

};

class AMaterialInstanceActor : public AActor
{
	public:
	    TArray<class AActor*> TargetActors; // 0x330 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialInstanceActor");
			return (class UClass*)ptr;
		};

};

class UMaterialInstanceDynamic : public UMaterialInstance
{
	public:
	    void SetVectorParameterValue(FName ParameterName, struct FLinearColor Value); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void SetTextureParameterValue(FName ParameterName, class UTexture* Value); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetScalarParameterValue(FName ParameterName, float Value); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void K2_InterpolateMaterialInstanceParams(class UMaterialInstance* SourceA, class UMaterialInstance* SourceB, float Alpha); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    struct FLinearColor K2_GetVectorParameterValue(FName ParameterName); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    class UTexture* K2_GetTextureParameterValue(FName ParameterName); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    float K2_GetScalarParameterValue(FName ParameterName); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void K2_CopyMaterialInstanceParameters(class UMaterialInterface* Source, bool bQuickParametersOnly); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void CopyParameterOverrides(class UMaterialInstance* MaterialInstance); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void CopyInterpParameters(class UMaterialInstance* Source); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7db9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialInstanceDynamic");
			return (class UClass*)ptr;
		};

};

class UMaterialParameterCollection : public UObject
{
	public:
	    struct FGuid StateId; // 0x28 Size: 0x10
	    TArray<struct FCollectionScalarParameter> ScalarParameters; // 0x38 Size: 0x10
	    TArray<struct FCollectionVectorParameter> VectorParameters; // 0x48 Size: 0x10
	    char UnknownData0[0x10];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialParameterCollection");
			return (class UClass*)ptr;
		};

};

class UMaterialParameterCollectionInstance : public UObject
{
	public:
	    char UnknownData0[0x8];
	    class UMaterialParameterCollection* Collection; // 0x30 Size: 0x8
	    char UnknownData1[0xb8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MaterialParameterCollectionInstance");
			return (class UClass*)ptr;
		};

};

class AMatineeActor : public AActor
{
	public:
	    class UInterpData* MatineeData; // 0x330 Size: 0x8
	    FName MatineeControllerName; // 0x338 Size: 0x8
	    float PlayRate; // 0x340 Size: 0x4
	    bool bPlayOnLevelLoad; // 0x344 Size: 0x1
	    bool bForceStartPos; // 0x344 Size: 0x1
	    char UnknownData0[0x2]; // 0x346
	    float ForceStartPosition; // 0x348 Size: 0x4
	    bool bLooping; // 0x34c Size: 0x1
	    bool bRewindOnPlay; // 0x34c Size: 0x1
	    bool bNoResetOnRewind; // 0x34c Size: 0x1
	    bool bRewindIfAlreadyPlaying; // 0x34c Size: 0x1
	    bool bDisableRadioFilter; // 0x34c Size: 0x1
	    bool bClientSideOnly; // 0x34c Size: 0x1
	    bool bSkipUpdateIfNotVisible; // 0x34c Size: 0x1
	    bool bIsSkippable; // 0x34c Size: 0x1
	    char UnknownData1[0x4]; // 0x354
	    int PreferredSplitScreenNum; // 0x350 Size: 0x4
	    bool bDisableMovementInput; // 0x354 Size: 0x1
	    bool bDisableLookAtInput; // 0x354 Size: 0x1
	    bool bHidePlayer; // 0x354 Size: 0x1
	    bool bHideHud; // 0x354 Size: 0x1
	    TArray<struct FInterpGroupActorInfo> GroupActorInfos; // 0x358 Size: 0x10
	    bool bShouldShowGore; // 0x368 Size: 0x1
	    char UnknownData2[0x7]; // 0x369
	    TArray<class UInterpGroupInst*> GroupInst; // 0x370 Size: 0x10
	    TArray<struct FCameraCutInfo> CameraCuts; // 0x380 Size: 0x10
	    bool bIsPlaying; // 0x390 Size: 0x1
	    bool bReversePlayback; // 0x390 Size: 0x1
	    bool bPaused; // 0x390 Size: 0x1
	    bool bPendingStop; // 0x390 Size: 0x1
	    float InterpPosition; // 0x394 Size: 0x4
	    char UnknownData3[0x4]; // 0x398
	    char ReplicationForceIsPlaying; // 0x39c Size: 0x1
	    char UnknownData4[0x3]; // 0x39d
	    MulticastDelegateProperty OnPlay; // 0x3a0 Size: 0x10
	    MulticastDelegateProperty OnStop; // 0x3b0 Size: 0x10
	    MulticastDelegateProperty OnPause; // 0x3c0 Size: 0x10
	    char UnknownData5[0x3d0]; // 0x3d0
	    void Stop(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetPosition(float NewPosition, bool bJump); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetLoopingState(bool bNewLooping); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void Reverse(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void Play(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void Pause(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void EnableGroupByName(struct FString GroupName, bool bEnable); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void ChangePlaybackDirection(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x-7c09];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MatineeActor");
			return (class UClass*)ptr;
		};

};

class AMatineeActorCameraAnim : public AMatineeActor
{
	public:
	    class UCameraAnim* CameraAnim; // 0x3d8 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MatineeActorCameraAnim");
			return (class UClass*)ptr;
		};

};

class UMatineeAnimInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MatineeAnimInterface");
			return (class UClass*)ptr;
		};

};

class UMatineeInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MatineeInterface");
			return (class UClass*)ptr;
		};

};

class AMeshMergeCullingVolume : public AVolume
{
	public:
	    char UnknownData0[0x368];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MeshMergeCullingVolume");
			return (class UClass*)ptr;
		};

};

class UMeshSimplificationSettings : public UDeveloperSettings
{
	public:
	    FName MeshReductionModuleName; // 0x38 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MeshSimplificationSettings");
			return (class UClass*)ptr;
		};

};

class UMeshVertexPainterKismetLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void RemovePaintedVertices(class UStaticMeshComponent* StaticMeshComponent); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void PaintVerticesSingleColor(class UStaticMeshComponent* StaticMeshComponent, struct FLinearColor FillColor, bool bConvertToSRGB); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static void PaintVerticesLerpAlongAxis(class UStaticMeshComponent* StaticMeshComponent, struct FLinearColor StartColor, struct FLinearColor EndColor, EVertexPaintAxis Axis, bool bConvertToSRGB); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MeshVertexPainterKismetLibrary");
			return (class UClass*)ptr;
		};

};

class UMicroTransactionBase : public UPlatformInterfaceBase
{
	public:
	    TArray<struct FPurchaseInfo> AvailableProducts; // 0x38 Size: 0x10
	    struct FString LastError; // 0x48 Size: 0x10
	    struct FString LastErrorSolution; // 0x58 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MicroTransactionBase");
			return (class UClass*)ptr;
		};

};

class UModelComponent : public UPrimitiveComponent
{
	public:
	    char UnknownData0[0x18];
	    class UBodySetup* ModelBodySetup; // 0x588 Size: 0x8
	    char UnknownData1[0x20];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ModelComponent");
			return (class UClass*)ptr;
		};

};

class UMorphTarget : public UObject
{
	public:
	    class USkeletalMesh* BaseSkelMesh; // 0x28 Size: 0x8
	    char UnknownData0[0x10];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.MorphTarget");
			return (class UClass*)ptr;
		};

};

class UNavAgentInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.NavAgentInterface");
			return (class UClass*)ptr;
		};

};

class UNavCollisionBase : public UObject
{
	public:
	    bool bIsDynamicObstacle; // 0x28 Size: 0x1
	    char UnknownData0[0x47];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.NavCollisionBase");
			return (class UClass*)ptr;
		};

};

class UNavEdgeProviderInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.NavEdgeProviderInterface");
			return (class UClass*)ptr;
		};

};

class UNavigationDataChunk : public UObject
{
	public:
	    FName NavigationDataName; // 0x28 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.NavigationDataChunk");
			return (class UClass*)ptr;
		};

};

class UNavigationDataInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.NavigationDataInterface");
			return (class UClass*)ptr;
		};

};

class UNavigationSystem : public UObject
{
	public:
	    static void SimpleMoveToLocation(class AController* Controller, struct FVector Goal); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void SimpleMoveToActor(class AController* Controller, class AActor* Goal); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7fa9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.NavigationSystem");
			return (class UClass*)ptr;
		};

};

class UNullNavSysConfig : public UNavigationSystemConfig
{
	public:
	    char UnknownData0[0x48];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.NullNavSysConfig");
			return (class UClass*)ptr;
		};

};

class UNavPathObserverInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.NavPathObserverInterface");
			return (class UClass*)ptr;
		};

};

class UNavRelevantInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.NavRelevantInterface");
			return (class UClass*)ptr;
		};

};

class USimulatedClientNetConnection : public UNetConnection
{
	public:
	    char UnknownData0[0x1928];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SimulatedClientNetConnection");
			return (class UClass*)ptr;
		};

};

class UNetworkPredictionInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.NetworkPredictionInterface");
			return (class UClass*)ptr;
		};

};

class UNetworkSettings : public UDeveloperSettings
{
	public:
	    bool bVerifyPeer; // 0x38 Size: 0x1
	    bool bEnableMultiplayerWorldOriginRebasing; // 0x38 Size: 0x1
	    char UnknownData0[0x2]; // 0x3a
	    int MaxRepArraySize; // 0x3c Size: 0x4
	    int MaxRepArrayMemory; // 0x40 Size: 0x4
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.NetworkSettings");
			return (class UClass*)ptr;
		};

};

class UNodeMappingContainer : public UObject
{
	public:
	    __int64/*MapProperty*/ SourceItems; // 0x28 Size: 0x50
	    __int64/*MapProperty*/ TargetItems; // 0x78 Size: 0x50
	    __int64/*MapProperty*/ SourceToTarget; // 0xc8 Size: 0x50
	    struct TSoftObjectPtr<struct UObject*> SourceAsset; // 0x118 Size: 0x28
	    struct TSoftObjectPtr<struct UObject*> TargetAsset; // 0x140 Size: 0x28

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.NodeMappingContainer");
			return (class UClass*)ptr;
		};

};

class UNodeMappingProviderInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.NodeMappingProviderInterface");
			return (class UClass*)ptr;
		};

};

class ANote : public AActor
{
	public:
	    char UnknownData0[0x330];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Note");
			return (class UClass*)ptr;
		};

};

class UObjectLibrary : public UObject
{
	public:
	    class UObject* ObjectBaseClass; // 0x28 Size: 0x8
	    bool bHasBlueprintClasses; // 0x30 Size: 0x1
	    char UnknownData0[0x7]; // 0x31
	    TArray<class UObject*> Objects; // 0x38 Size: 0x10
	    TArray<TWeakObjectPtr<UObject*>> WeakObjects; // 0x48 Size: 0x10
	    bool bUseWeakReferences; // 0x58 Size: 0x1
	    bool bIsFullyLoaded; // 0x59 Size: 0x1
	    char UnknownData1[0x4e];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ObjectLibrary");
			return (class UClass*)ptr;
		};

};

class UObjectReferencer : public UObject
{
	public:
	    TArray<class UObject*> ReferencedObjects; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ObjectReferencer");
			return (class UClass*)ptr;
		};

};

class UPackageMapClient : public UPackageMap
{
	public:
	    char UnknownData0[0x388];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PackageMapClient");
			return (class UClass*)ptr;
		};

};

class APainCausingVolume : public APhysicsVolume
{
	public:
	    bool bPainCausing; // 0x378 Size: 0x1
	    char UnknownData0[0x3]; // 0x379
	    float DamagePerSec; // 0x37c Size: 0x4
	    class UDamageType* DamageType; // 0x380 Size: 0x8
	    float PainInterval; // 0x388 Size: 0x4
	    bool bEntryPain; // 0x38c Size: 0x1
	    bool BACKUP_bPainCausing; // 0x38c Size: 0x1
	    char UnknownData1[0x2]; // 0x38e
	    class AController* DamageInstigator; // 0x390 Size: 0x8
	    char UnknownData2[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PainCausingVolume");
			return (class UClass*)ptr;
		};

};

class UParticleEmitter : public UObject
{
	public:
	    FName EmitterName; // 0x28 Size: 0x8
	    int SubUVDataOffset; // 0x30 Size: 0x4
	    char EmitterRenderMode; // 0x34 Size: 0x1
	    EParticleSignificanceLevel SignificanceLevel; // 0x35 Size: 0x1
	    bool bUseLegacySpawningBehavior; // 0x37 Size: 0x1
	    bool ConvertedModules; // 0x37 Size: 0x1
	    bool bIsSoloing; // 0x37 Size: 0x1
	    bool bCookedOut; // 0x37 Size: 0x1
	    bool bDisabledLODsKeepEmitterAlive; // 0x37 Size: 0x1
	    bool bDisableWhenInsignficant; // 0x38 Size: 0x1
	    char UnknownData0[0x4]; // 0x3c
	    TArray<class UParticleLODLevel*> LODLevels; // 0x40 Size: 0x10
	    int PeakActiveParticles; // 0x50 Size: 0x4
	    int InitialAllocationCount; // 0x54 Size: 0x4
	    float QualityLevelSpawnRateScale; // 0x58 Size: 0x4
	    uint32_t DetailModeBitmask; // 0x5c Size: 0x4
	    char UnknownData1[0xf8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleEmitter");
			return (class UClass*)ptr;
		};

};

class AParticleEventManager : public AActor
{
	public:
	    char UnknownData0[0x330];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleEventManager");
			return (class UClass*)ptr;
		};

};

class UParticleLODLevel : public UObject
{
	public:
	    int Level; // 0x28 Size: 0x4
	    bool bEnabled; // 0x2c Size: 0x1
	    char UnknownData0[0x3]; // 0x2d
	    class UParticleModuleRequired* RequiredModule; // 0x30 Size: 0x8
	    TArray<class UParticleModule*> Modules; // 0x38 Size: 0x10
	    class UParticleModuleTypeDataBase* TypeDataModule; // 0x48 Size: 0x8
	    class UParticleModuleSpawn* SpawnModule; // 0x50 Size: 0x8
	    class UParticleModuleEventGenerator* EventGenerator; // 0x58 Size: 0x8
	    TArray<class UParticleModuleSpawnBase*> SpawningModules; // 0x60 Size: 0x10
	    TArray<class UParticleModule*> SpawnModules; // 0x70 Size: 0x10
	    TArray<class UParticleModule*> UpdateModules; // 0x80 Size: 0x10
	    TArray<class UParticleModuleOrbit*> OrbitModules; // 0x90 Size: 0x10
	    TArray<class UParticleModuleEventReceiverBase*> EventReceiverModules; // 0xa0 Size: 0x10
	    bool ConvertedModules; // 0xb0 Size: 0x1
	    char UnknownData1[0x3]; // 0xb1
	    int PeakActiveParticles; // 0xb4 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleLODLevel");
			return (class UClass*)ptr;
		};

};

class UParticleModule : public UObject
{
	public:
	    bool bSpawnModule; // 0x28 Size: 0x1
	    bool bUpdateModule; // 0x28 Size: 0x1
	    bool bFinalUpdateModule; // 0x28 Size: 0x1
	    bool bUpdateForGPUEmitter; // 0x28 Size: 0x1
	    bool bCurvesAsColor; // 0x28 Size: 0x1
	    bool b3DDrawMode; // 0x28 Size: 0x1
	    bool bSupported3DDrawMode; // 0x28 Size: 0x1
	    bool bEnabled; // 0x28 Size: 0x1
	    bool bEditable; // 0x29 Size: 0x1
	    bool LODDuplicate; // 0x29 Size: 0x1
	    bool bSupportsRandomSeed; // 0x29 Size: 0x1
	    bool bRequiresLoopingNotification; // 0x29 Size: 0x1
	    char UnknownData0[0x8]; // 0x34
	    char LODValidity; // 0x2c Size: 0x1
	    char UnknownData1[0x3];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModule");
			return (class UClass*)ptr;
		};

};

class UParticleModuleAccelerationBase : public UParticleModule
{
	public:
	    bool bAlwaysInWorldSpace; // 0x30 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleAccelerationBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleAcceleration : public UParticleModuleAccelerationBase
{
	public:
	    struct FRawDistributionVector Acceleration; // 0x38 Size: 0x50
	    bool bApplyOwnerScale; // 0x88 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleAcceleration");
			return (class UClass*)ptr;
		};

};

class UParticleModuleAccelerationConstant : public UParticleModuleAccelerationBase
{
	public:
	    struct FVector Acceleration; // 0x38 Size: 0xc
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleAccelerationConstant");
			return (class UClass*)ptr;
		};

};

class UParticleModuleAccelerationDrag : public UParticleModuleAccelerationBase
{
	public:
	    class UDistributionFloat* DragCoefficient; // 0x38 Size: 0x8
	    struct FRawDistributionFloat DragCoefficientRaw; // 0x40 Size: 0x38

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleAccelerationDrag");
			return (class UClass*)ptr;
		};

};

class UParticleModuleAccelerationDragScaleOverLife : public UParticleModuleAccelerationBase
{
	public:
	    class UDistributionFloat* DragScale; // 0x38 Size: 0x8
	    struct FRawDistributionFloat DragScaleRaw; // 0x40 Size: 0x38

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleAccelerationDragScaleOverLife");
			return (class UClass*)ptr;
		};

};

class UParticleModuleAccelerationOverLifetime : public UParticleModuleAccelerationBase
{
	public:
	    struct FRawDistributionVector AccelOverLife; // 0x38 Size: 0x50

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleAccelerationOverLifetime");
			return (class UClass*)ptr;
		};

};

class UParticleModuleAttractorBase : public UParticleModule
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleAttractorBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleAttractorLine : public UParticleModuleAttractorBase
{
	public:
	    struct FVector EndPoint0; // 0x30 Size: 0xc
	    struct FVector EndPoint1; // 0x3c Size: 0xc
	    struct FRawDistributionFloat Range; // 0x48 Size: 0x38
	    struct FRawDistributionFloat Strength; // 0x80 Size: 0x38

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleAttractorLine");
			return (class UClass*)ptr;
		};

};

class UParticleModuleAttractorParticle : public UParticleModuleAttractorBase
{
	public:
	    FName EmitterName; // 0x30 Size: 0x8
	    struct FRawDistributionFloat Range; // 0x38 Size: 0x38
	    bool bStrengthByDistance; // 0x70 Size: 0x1
	    char UnknownData0[0x7]; // 0x71
	    struct FRawDistributionFloat Strength; // 0x78 Size: 0x38
	    bool bAffectBaseVelocity; // 0xb0 Size: 0x1
	    char UnknownData1[0x3]; // 0xb1
	    char SelectionMethod; // 0xb4 Size: 0x1
	    bool bRenewSource; // 0xb8 Size: 0x1
	    bool bInheritSourceVel; // 0xb8 Size: 0x1
	    char UnknownData2[0x5]; // 0xb7
	    int LastSelIndex; // 0xbc Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleAttractorParticle");
			return (class UClass*)ptr;
		};

};

class UParticleModuleAttractorPoint : public UParticleModuleAttractorBase
{
	public:
	    struct FRawDistributionVector Position; // 0x30 Size: 0x50
	    struct FRawDistributionFloat Range; // 0x80 Size: 0x38
	    struct FRawDistributionFloat Strength; // 0xb8 Size: 0x38
	    bool StrengthByDistance; // 0xf0 Size: 0x1
	    bool bAffectBaseVelocity; // 0xf0 Size: 0x1
	    bool bOverrideVelocity; // 0xf0 Size: 0x1
	    bool bUseWorldSpacePosition; // 0xf0 Size: 0x1
	    bool Positive_X; // 0xf0 Size: 0x1
	    bool Positive_Y; // 0xf0 Size: 0x1
	    bool Positive_Z; // 0xf0 Size: 0x1
	    bool Negative_X; // 0xf0 Size: 0x1
	    bool Negative_Y; // 0xf1 Size: 0x1
	    bool Negative_Z; // 0xf1 Size: 0x1
	    char UnknownData0[0x-2];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleAttractorPoint");
			return (class UClass*)ptr;
		};

};

class UParticleModuleAttractorPointGravity : public UParticleModuleAttractorBase
{
	public:
	    struct FVector Position; // 0x30 Size: 0xc
	    float Radius; // 0x3c Size: 0x4
	    class UDistributionFloat* Strength; // 0x40 Size: 0x8
	    struct FRawDistributionFloat StrengthRaw; // 0x48 Size: 0x38

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleAttractorPointGravity");
			return (class UClass*)ptr;
		};

};

class UParticleModuleBeamBase : public UParticleModule
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleBeamBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleBeamModifier : public UParticleModuleBeamBase
{
	public:
	    char ModifierType; // 0x30 Size: 0x1
	    char UnknownData0[0x3]; // 0x31
	    struct FBeamModifierOptions PositionOptions; // 0x34 Size: 0x4
	    struct FRawDistributionVector Position; // 0x38 Size: 0x50
	    struct FBeamModifierOptions TangentOptions; // 0x88 Size: 0x4
	    char UnknownData1[0x4]; // 0x8c
	    struct FRawDistributionVector Tangent; // 0x90 Size: 0x50
	    bool bAbsoluteTangent; // 0xe0 Size: 0x1
	    char UnknownData2[0x3]; // 0xe1
	    struct FBeamModifierOptions StrengthOptions; // 0xe4 Size: 0x4
	    struct FRawDistributionFloat Strength; // 0xe8 Size: 0x38

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleBeamModifier");
			return (class UClass*)ptr;
		};

};

class UParticleModuleBeamNoise : public UParticleModuleBeamBase
{
	public:
	    bool bLowFreq_Enabled; // 0x30 Size: 0x1
	    char UnknownData0[0x3]; // 0x31
	    int Frequency; // 0x34 Size: 0x4
	    int Frequency_LowRange; // 0x38 Size: 0x4
	    char UnknownData1[0x4]; // 0x3c
	    struct FRawDistributionVector NoiseRange; // 0x40 Size: 0x50
	    struct FRawDistributionFloat NoiseRangeScale; // 0x90 Size: 0x38
	    bool bNRScaleEmitterTime; // 0xc8 Size: 0x1
	    char UnknownData2[0x7]; // 0xc9
	    struct FRawDistributionVector NoiseSpeed; // 0xd0 Size: 0x50
	    bool bSmooth; // 0x120 Size: 0x1
	    char UnknownData3[0x3]; // 0x121
	    float NoiseLockRadius; // 0x124 Size: 0x4
	    bool bNoiseLock; // 0x128 Size: 0x1
	    bool bOscillate; // 0x128 Size: 0x1
	    char UnknownData4[0x2]; // 0x12a
	    float NoiseLockTime; // 0x12c Size: 0x4
	    float NoiseTension; // 0x130 Size: 0x4
	    bool bUseNoiseTangents; // 0x134 Size: 0x1
	    char UnknownData5[0x3]; // 0x135
	    struct FRawDistributionFloat NoiseTangentStrength; // 0x138 Size: 0x38
	    int NoiseTessellation; // 0x170 Size: 0x4
	    bool bTargetNoise; // 0x174 Size: 0x1
	    char UnknownData6[0x3]; // 0x175
	    float FrequencyDistance; // 0x178 Size: 0x4
	    bool bApplyNoiseScale; // 0x17c Size: 0x1
	    char UnknownData7[0x3]; // 0x17d
	    struct FRawDistributionFloat NoiseScale; // 0x180 Size: 0x38

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleBeamNoise");
			return (class UClass*)ptr;
		};

};

class UParticleModuleBeamSource : public UParticleModuleBeamBase
{
	public:
	    char SourceMethod; // 0x30 Size: 0x1
	    char UnknownData0[0x3]; // 0x31
	    FName SourceName; // 0x34 Size: 0x8
	    bool bSourceAbsolute; // 0x3c Size: 0x1
	    char UnknownData1[0x3]; // 0x3d
	    struct FRawDistributionVector Source; // 0x40 Size: 0x50
	    bool bLockSource; // 0x90 Size: 0x1
	    char UnknownData2[0x3]; // 0x91
	    char SourceTangentMethod; // 0x94 Size: 0x1
	    char UnknownData3[0x3]; // 0x95
	    struct FRawDistributionVector SourceTangent; // 0x98 Size: 0x50
	    bool bLockSourceTangent; // 0xe8 Size: 0x1
	    char UnknownData4[0x7]; // 0xe9
	    struct FRawDistributionFloat SourceStrength; // 0xf0 Size: 0x38
	    bool bLockSourceStength; // 0x128 Size: 0x1
	    char UnknownData5[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleBeamSource");
			return (class UClass*)ptr;
		};

};

class UParticleModuleBeamTarget : public UParticleModuleBeamBase
{
	public:
	    char TargetMethod; // 0x30 Size: 0x1
	    char UnknownData0[0x3]; // 0x31
	    FName TargetName; // 0x34 Size: 0x8
	    char UnknownData1[0x4]; // 0x3c
	    struct FRawDistributionVector Target; // 0x40 Size: 0x50
	    bool bTargetAbsolute; // 0x90 Size: 0x1
	    bool bLockTarget; // 0x90 Size: 0x1
	    char UnknownData2[0x2]; // 0x92
	    char TargetTangentMethod; // 0x94 Size: 0x1
	    char UnknownData3[0x3]; // 0x95
	    struct FRawDistributionVector TargetTangent; // 0x98 Size: 0x50
	    bool bLockTargetTangent; // 0xe8 Size: 0x1
	    char UnknownData4[0x7]; // 0xe9
	    struct FRawDistributionFloat TargetStrength; // 0xf0 Size: 0x38
	    bool bLockTargetStength; // 0x128 Size: 0x1
	    char UnknownData5[0x3]; // 0x129
	    float LockRadius; // 0x12c Size: 0x4
	    char UnknownData6[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleBeamTarget");
			return (class UClass*)ptr;
		};

};

class UParticleModuleCameraBase : public UParticleModule
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleCameraBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleCameraOffset : public UParticleModuleCameraBase
{
	public:
	    struct FRawDistributionFloat CameraOffset; // 0x30 Size: 0x38
	    bool bSpawnTimeOnly; // 0x68 Size: 0x1
	    char UnknownData0[0x3]; // 0x69
	    char UpdateMethod; // 0x6c Size: 0x1
	    char UnknownData1[0x3];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleCameraOffset");
			return (class UClass*)ptr;
		};

};

class UParticleModuleCollisionBase : public UParticleModule
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleCollisionBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleCollision : public UParticleModuleCollisionBase
{
	public:
	    struct FRawDistributionVector DampingFactor; // 0x30 Size: 0x50
	    struct FRawDistributionVector DampingFactorRotation; // 0x80 Size: 0x50
	    struct FRawDistributionFloat MaxCollisions; // 0xd0 Size: 0x38
	    char CollisionCompletionOption; // 0x108 Size: 0x1
	    char UnknownData0[0x7]; // 0x109
	    TArray<char> CollisionTypes; // 0x110 Size: 0x10
	    bool bApplyPhysics; // 0x128 Size: 0x1
	    bool bIgnoreTriggerVolumes; // 0x128 Size: 0x1
	    char UnknownData1[0xe]; // 0x122
	    struct FRawDistributionFloat ParticleMass; // 0x130 Size: 0x38
	    float DirScalar; // 0x168 Size: 0x4
	    bool bPawnsDoNotDecrementCount; // 0x16c Size: 0x1
	    bool bOnlyVerticalNormalsDecrementCount; // 0x16c Size: 0x1
	    char UnknownData2[0x2]; // 0x16e
	    float VerticalFudgeFactor; // 0x170 Size: 0x4
	    char UnknownData3[0x4]; // 0x174
	    struct FRawDistributionFloat DelayAmount; // 0x178 Size: 0x38
	    bool bDropDetail; // 0x1b0 Size: 0x1
	    bool bCollideOnlyIfVisible; // 0x1b0 Size: 0x1
	    bool bIgnoreSourceActor; // 0x1b0 Size: 0x1
	    char UnknownData4[0x1]; // 0x1b3
	    float MaxCollisionDistance; // 0x1b4 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleCollision");
			return (class UClass*)ptr;
		};

};

class UParticleModuleCollisionGPU : public UParticleModuleCollisionBase
{
	public:
	    struct FRawDistributionFloat Resilience; // 0x30 Size: 0x38
	    struct FRawDistributionFloat ResilienceScaleOverLife; // 0x68 Size: 0x38
	    float Friction; // 0xa0 Size: 0x4
	    float RandomSpread; // 0xa4 Size: 0x4
	    float RandomDistribution; // 0xa8 Size: 0x4
	    float RadiusScale; // 0xac Size: 0x4
	    float RadiusBias; // 0xb0 Size: 0x4
	    char Response; // 0xb4 Size: 0x1
	    char CollisionMode; // 0xb5 Size: 0x1
	    char UnknownData0[0x2];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleCollisionGPU");
			return (class UClass*)ptr;
		};

};

class UParticleModuleColorBase : public UParticleModule
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleColorBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleColor : public UParticleModuleColorBase
{
	public:
	    struct FRawDistributionVector StartColor; // 0x30 Size: 0x50
	    struct FRawDistributionFloat StartAlpha; // 0x80 Size: 0x38
	    bool bClampAlpha; // 0xb8 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleColor");
			return (class UClass*)ptr;
		};

};

class UParticleModuleColor_Seeded : public UParticleModuleColor
{
	public:
	    struct FParticleRandomSeedInfo RandomSeedInfo; // 0xc0 Size: 0x20

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleColor_Seeded");
			return (class UClass*)ptr;
		};

};

class UParticleModuleColorOverLife : public UParticleModuleColorBase
{
	public:
	    struct FRawDistributionVector ColorOverLife; // 0x30 Size: 0x50
	    struct FRawDistributionFloat AlphaOverLife; // 0x80 Size: 0x38
	    bool bClampAlpha; // 0xb8 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleColorOverLife");
			return (class UClass*)ptr;
		};

};

class UParticleModuleColorScaleOverLife : public UParticleModuleColorBase
{
	public:
	    struct FRawDistributionVector ColorScaleOverLife; // 0x30 Size: 0x50
	    struct FRawDistributionFloat AlphaScaleOverLife; // 0x80 Size: 0x38
	    bool bEmitterTime; // 0xb8 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleColorScaleOverLife");
			return (class UClass*)ptr;
		};

};

class UParticleModuleEventBase : public UParticleModule
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleEventBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleEventGenerator : public UParticleModuleEventBase
{
	public:
	    TArray<struct FParticleEvent_GenerateInfo> Events; // 0x30 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleEventGenerator");
			return (class UClass*)ptr;
		};

};

class UParticleModuleEventReceiverBase : public UParticleModuleEventBase
{
	public:
	    char EventGeneratorType; // 0x30 Size: 0x1
	    char UnknownData0[0x3]; // 0x31
	    FName EventName; // 0x34 Size: 0x8
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleEventReceiverBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleEventReceiverKillParticles : public UParticleModuleEventReceiverBase
{
	public:
	    bool bStopSpawning; // 0x40 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleEventReceiverKillParticles");
			return (class UClass*)ptr;
		};

};

class UParticleModuleEventReceiverSpawn : public UParticleModuleEventReceiverBase
{
	public:
	    struct FRawDistributionFloat SpawnCount; // 0x40 Size: 0x38
	    bool bUseParticleTime; // 0x78 Size: 0x1
	    bool bUsePSysLocation; // 0x78 Size: 0x1
	    bool bInheritVelocity; // 0x78 Size: 0x1
	    char UnknownData0[0x5]; // 0x7b
	    struct FRawDistributionVector InheritVelocityScale; // 0x80 Size: 0x50
	    TArray<class UPhysicalMaterial*> PhysicalMaterials; // 0xd0 Size: 0x10
	    bool bBanPhysicalMaterials; // 0xe0 Size: 0x1
	    char UnknownData1[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleEventReceiverSpawn");
			return (class UClass*)ptr;
		};

};

class UParticleModuleEventSendToGame : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleEventSendToGame");
			return (class UClass*)ptr;
		};

};

class UParticleModuleKillBase : public UParticleModule
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleKillBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleKillBox : public UParticleModuleKillBase
{
	public:
	    struct FRawDistributionVector LowerLeftCorner; // 0x30 Size: 0x50
	    struct FRawDistributionVector UpperRightCorner; // 0x80 Size: 0x50
	    bool bAbsolute; // 0xd0 Size: 0x1
	    bool bKillInside; // 0xd0 Size: 0x1
	    bool bAxisAlignedAndFixedSize; // 0xd0 Size: 0x1
	    char UnknownData0[0x5];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleKillBox");
			return (class UClass*)ptr;
		};

};

class UParticleModuleKillHeight : public UParticleModuleKillBase
{
	public:
	    struct FRawDistributionFloat Height; // 0x30 Size: 0x38
	    bool bAbsolute; // 0x68 Size: 0x1
	    bool bFloor; // 0x68 Size: 0x1
	    bool bApplyPSysScale; // 0x68 Size: 0x1
	    char UnknownData0[0x5];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleKillHeight");
			return (class UClass*)ptr;
		};

};

class UParticleModuleLifetimeBase : public UParticleModule
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleLifetimeBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleLifetime : public UParticleModuleLifetimeBase
{
	public:
	    struct FRawDistributionFloat LifeTime; // 0x30 Size: 0x38

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleLifetime");
			return (class UClass*)ptr;
		};

};

class UParticleModuleLifetime_Seeded : public UParticleModuleLifetime
{
	public:
	    struct FParticleRandomSeedInfo RandomSeedInfo; // 0x68 Size: 0x20

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleLifetime_Seeded");
			return (class UClass*)ptr;
		};

};

class UParticleModuleLightBase : public UParticleModule
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleLightBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleLight : public UParticleModuleLightBase
{
	public:
	    bool bUseInverseSquaredFalloff; // 0x30 Size: 0x1
	    bool bAffectsTranslucency; // 0x31 Size: 0x1
	    bool bPreviewLightRadius; // 0x32 Size: 0x1
	    char UnknownData0[0x1]; // 0x33
	    float SpawnFraction; // 0x34 Size: 0x4
	    struct FRawDistributionVector ColorScaleOverLife; // 0x38 Size: 0x50
	    struct FRawDistributionFloat BrightnessOverLife; // 0x88 Size: 0x38
	    struct FRawDistributionFloat RadiusScale; // 0xc0 Size: 0x38
	    struct FRawDistributionFloat LightExponent; // 0xf8 Size: 0x38
	    struct FLightingChannels LightingChannels; // 0x130 Size: 0x1
	    char UnknownData1[0x3]; // 0x131
	    float VolumetricScatteringIntensity; // 0x134 Size: 0x4
	    bool bHighQualityLights; // 0x138 Size: 0x1
	    bool bShadowCastingLights; // 0x139 Size: 0x1
	    char UnknownData2[0x6];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleLight");
			return (class UClass*)ptr;
		};

};

class UParticleModuleLight_Seeded : public UParticleModuleLight
{
	public:
	    struct FParticleRandomSeedInfo RandomSeedInfo; // 0x140 Size: 0x20

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleLight_Seeded");
			return (class UClass*)ptr;
		};

};

class UParticleModuleLocationBase : public UParticleModule
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleLocationBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleLocation : public UParticleModuleLocationBase
{
	public:
	    struct FRawDistributionVector StartLocation; // 0x30 Size: 0x50
	    float DistributeOverNPoints; // 0x80 Size: 0x4
	    float DistributeThreshold; // 0x84 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleLocation");
			return (class UClass*)ptr;
		};

};

class UParticleModuleLocation_Seeded : public UParticleModuleLocation
{
	public:
	    struct FParticleRandomSeedInfo RandomSeedInfo; // 0x88 Size: 0x20

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleLocation_Seeded");
			return (class UClass*)ptr;
		};

};

class UParticleModuleLocationBoneSocket : public UParticleModuleLocationBase
{
	public:
	    char SourceType; // 0x30 Size: 0x1
	    char UnknownData0[0x3]; // 0x31
	    struct FVector UniversalOffset; // 0x34 Size: 0xc
	    TArray<struct FLocationBoneSocketInfo> SourceLocations; // 0x40 Size: 0x10
	    char SelectionMethod; // 0x50 Size: 0x1
	    bool bUpdatePositionEachFrame; // 0x54 Size: 0x1
	    bool bOrientMeshEmitters; // 0x54 Size: 0x1
	    bool bInheritBoneVelocity; // 0x54 Size: 0x1
	    char UnknownData1[0x4]; // 0x54
	    float InheritVelocityScale; // 0x58 Size: 0x4
	    FName SkelMeshActorParamName; // 0x5c Size: 0x8
	    int NumPreSelectedIndices; // 0x64 Size: 0x4
	    char UnknownData2[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleLocationBoneSocket");
			return (class UClass*)ptr;
		};

};

class UParticleModuleLocationDirect : public UParticleModuleLocationBase
{
	public:
	    struct FRawDistributionVector Location; // 0x30 Size: 0x50
	    struct FRawDistributionVector LocationOffset; // 0x80 Size: 0x50
	    struct FRawDistributionVector ScaleFactor; // 0xd0 Size: 0x50
	    struct FRawDistributionVector Direction; // 0x120 Size: 0x50

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleLocationDirect");
			return (class UClass*)ptr;
		};

};

class UParticleModuleLocationEmitter : public UParticleModuleLocationBase
{
	public:
	    FName EmitterName; // 0x30 Size: 0x8
	    char SelectionMethod; // 0x38 Size: 0x1
	    bool InheritSourceVelocity; // 0x3c Size: 0x1
	    char UnknownData0[0x6]; // 0x3a
	    float InheritSourceVelocityScale; // 0x40 Size: 0x4
	    bool bInheritSourceRotation; // 0x44 Size: 0x1
	    char UnknownData1[0x3]; // 0x45
	    float InheritSourceRotationScale; // 0x48 Size: 0x4
	    char UnknownData2[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleLocationEmitter");
			return (class UClass*)ptr;
		};

};

class UParticleModuleLocationEmitterDirect : public UParticleModuleLocationBase
{
	public:
	    FName EmitterName; // 0x30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleLocationEmitterDirect");
			return (class UClass*)ptr;
		};

};

class UParticleModuleLocationPrimitiveBase : public UParticleModuleLocationBase
{
	public:
	    bool Positive_X; // 0x30 Size: 0x1
	    bool Positive_Y; // 0x30 Size: 0x1
	    bool Positive_Z; // 0x30 Size: 0x1
	    bool Negative_X; // 0x30 Size: 0x1
	    bool Negative_Y; // 0x30 Size: 0x1
	    bool Negative_Z; // 0x30 Size: 0x1
	    bool SurfaceOnly; // 0x30 Size: 0x1
	    bool Velocity; // 0x30 Size: 0x1
	    struct FRawDistributionFloat VelocityScale; // 0x38 Size: 0x38
	    struct FRawDistributionVector StartLocation; // 0x70 Size: 0x50

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleLocationPrimitiveBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleLocationPrimitiveCylinder : public UParticleModuleLocationPrimitiveBase
{
	public:
	    bool RadialVelocity; // 0xc0 Size: 0x1
	    char UnknownData0[0x7]; // 0xc1
	    struct FRawDistributionFloat StartRadius; // 0xc8 Size: 0x38
	    struct FRawDistributionFloat StartHeight; // 0x100 Size: 0x38
	    char HeightAxis; // 0x138 Size: 0x1
	    char UnknownData1[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleLocationPrimitiveCylinder");
			return (class UClass*)ptr;
		};

};

class UParticleModuleLocationPrimitiveCylinder_Seeded : public UParticleModuleLocationPrimitiveCylinder
{
	public:
	    struct FParticleRandomSeedInfo RandomSeedInfo; // 0x140 Size: 0x20

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleLocationPrimitiveCylinder_Seeded");
			return (class UClass*)ptr;
		};

};

class UParticleModuleLocationPrimitiveSphere : public UParticleModuleLocationPrimitiveBase
{
	public:
	    struct FRawDistributionFloat StartRadius; // 0xc0 Size: 0x38

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleLocationPrimitiveSphere");
			return (class UClass*)ptr;
		};

};

class UParticleModuleLocationPrimitiveSphere_Seeded : public UParticleModuleLocationPrimitiveSphere
{
	public:
	    struct FParticleRandomSeedInfo RandomSeedInfo; // 0xf8 Size: 0x20

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleLocationPrimitiveSphere_Seeded");
			return (class UClass*)ptr;
		};

};

class UParticleModuleLocationPrimitiveTriangle : public UParticleModuleLocationBase
{
	public:
	    struct FRawDistributionVector StartOffset; // 0x30 Size: 0x50
	    struct FRawDistributionFloat Height; // 0x80 Size: 0x38
	    struct FRawDistributionFloat Angle; // 0xb8 Size: 0x38
	    struct FRawDistributionFloat Thickness; // 0xf0 Size: 0x38

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleLocationPrimitiveTriangle");
			return (class UClass*)ptr;
		};

};

class UParticleModuleLocationSkelVertSurface : public UParticleModuleLocationBase
{
	public:
	    char SourceType; // 0x30 Size: 0x1
	    char UnknownData0[0x3]; // 0x31
	    struct FVector UniversalOffset; // 0x34 Size: 0xc
	    bool bUpdatePositionEachFrame; // 0x40 Size: 0x1
	    bool bOrientMeshEmitters; // 0x40 Size: 0x1
	    bool bInheritBoneVelocity; // 0x40 Size: 0x1
	    char UnknownData1[0x1]; // 0x43
	    float InheritVelocityScale; // 0x44 Size: 0x4
	    FName SkelMeshActorParamName; // 0x48 Size: 0x8
	    TArray<FName> ValidAssociatedBones; // 0x50 Size: 0x10
	    bool bEnforceNormalCheck; // 0x60 Size: 0x1
	    char UnknownData2[0x3]; // 0x61
	    struct FVector NormalToCompare; // 0x64 Size: 0xc
	    float NormalCheckToleranceDegrees; // 0x70 Size: 0x4
	    float NormalCheckTolerance; // 0x74 Size: 0x4
	    TArray<int> ValidMaterialIndices; // 0x78 Size: 0x10
	    bool bInheritVertexColor; // 0x88 Size: 0x1
	    bool bInheritUV; // 0x88 Size: 0x1
	    char UnknownData3[0x2]; // 0x8a
	    uint32_t InheritUVChannel; // 0x8c Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleLocationSkelVertSurface");
			return (class UClass*)ptr;
		};

};

class UParticleModuleLocationWorldOffset : public UParticleModuleLocation
{
	public:
	    char UnknownData0[0x88];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleLocationWorldOffset");
			return (class UClass*)ptr;
		};

};

class UParticleModuleLocationWorldOffset_Seeded : public UParticleModuleLocationWorldOffset
{
	public:
	    struct FParticleRandomSeedInfo RandomSeedInfo; // 0x88 Size: 0x20

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleLocationWorldOffset_Seeded");
			return (class UClass*)ptr;
		};

};

class UParticleModuleMaterialBase : public UParticleModule
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleMaterialBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleMeshMaterial : public UParticleModuleMaterialBase
{
	public:
	    TArray<class UMaterialInterface*> MeshMaterials; // 0x30 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleMeshMaterial");
			return (class UClass*)ptr;
		};

};

class UParticleModuleRotationBase : public UParticleModule
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleRotationBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleMeshRotation : public UParticleModuleRotationBase
{
	public:
	    struct FRawDistributionVector StartRotation; // 0x30 Size: 0x50
	    bool bInheritParent; // 0x80 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleMeshRotation");
			return (class UClass*)ptr;
		};

};

class UParticleModuleMeshRotation_Seeded : public UParticleModuleMeshRotation
{
	public:
	    struct FParticleRandomSeedInfo RandomSeedInfo; // 0x88 Size: 0x20

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleMeshRotation_Seeded");
			return (class UClass*)ptr;
		};

};

class UParticleModuleRotationRateBase : public UParticleModule
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleRotationRateBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleMeshRotationRate : public UParticleModuleRotationRateBase
{
	public:
	    struct FRawDistributionVector StartRotationRate; // 0x30 Size: 0x50

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleMeshRotationRate");
			return (class UClass*)ptr;
		};

};

class UParticleModuleMeshRotationRate_Seeded : public UParticleModuleMeshRotationRate
{
	public:
	    struct FParticleRandomSeedInfo RandomSeedInfo; // 0x80 Size: 0x20

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleMeshRotationRate_Seeded");
			return (class UClass*)ptr;
		};

};

class UParticleModuleMeshRotationRateMultiplyLife : public UParticleModuleRotationRateBase
{
	public:
	    struct FRawDistributionVector LifeMultiplier; // 0x30 Size: 0x50

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleMeshRotationRateMultiplyLife");
			return (class UClass*)ptr;
		};

};

class UParticleModuleMeshRotationRateOverLife : public UParticleModuleRotationRateBase
{
	public:
	    struct FRawDistributionVector RotRate; // 0x30 Size: 0x50
	    bool bScaleRotRate; // 0x80 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleMeshRotationRateOverLife");
			return (class UClass*)ptr;
		};

};

class UParticleModuleOrbitBase : public UParticleModule
{
	public:
	    bool bUseEmitterTime; // 0x30 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleOrbitBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleOrbit : public UParticleModuleOrbitBase
{
	public:
	    char ChainMode; // 0x38 Size: 0x1
	    char UnknownData0[0x7]; // 0x39
	    struct FRawDistributionVector OffsetAmount; // 0x40 Size: 0x50
	    struct FOrbitOptions OffsetOptions; // 0x90 Size: 0x4
	    char UnknownData1[0x4]; // 0x94
	    struct FRawDistributionVector RotationAmount; // 0x98 Size: 0x50
	    struct FOrbitOptions RotationOptions; // 0xe8 Size: 0x4
	    char UnknownData2[0x4]; // 0xec
	    struct FRawDistributionVector RotationRateAmount; // 0xf0 Size: 0x50
	    struct FOrbitOptions RotationRateOptions; // 0x140 Size: 0x4
	    char UnknownData3[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleOrbit");
			return (class UClass*)ptr;
		};

};

class UParticleModuleOrientationBase : public UParticleModule
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleOrientationBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleOrientationAxisLock : public UParticleModuleOrientationBase
{
	public:
	    char LockAxisFlags; // 0x30 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleOrientationAxisLock");
			return (class UClass*)ptr;
		};

};

class UParticleModuleParameterBase : public UParticleModule
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleParameterBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleParameterDynamic : public UParticleModuleParameterBase
{
	public:
	    TArray<struct FEmitterDynamicParameter> DynamicParams; // 0x30 Size: 0x10
	    int UpdateFlags; // 0x40 Size: 0x4
	    bool bUsesVelocity; // 0x44 Size: 0x1
	    char UnknownData0[0x3];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleParameterDynamic");
			return (class UClass*)ptr;
		};

};

class UParticleModuleParameterDynamic_Seeded : public UParticleModuleParameterDynamic
{
	public:
	    struct FParticleRandomSeedInfo RandomSeedInfo; // 0x48 Size: 0x20

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleParameterDynamic_Seeded");
			return (class UClass*)ptr;
		};

};

class UParticleModulePivotOffset : public UParticleModuleLocationBase
{
	public:
	    struct FVector2D PivotOffset; // 0x30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModulePivotOffset");
			return (class UClass*)ptr;
		};

};

class UParticleModuleRequired : public UParticleModule
{
	public:
	    class UMaterialInterface* Material; // 0x30 Size: 0x8
	    struct FVector EmitterOrigin; // 0x38 Size: 0xc
	    struct FRotator EmitterRotation; // 0x44 Size: 0xc
	    char ScreenAlignment; // 0x50 Size: 0x1
	    char UnknownData0[0x3]; // 0x51
	    float MinFacingCameraBlendDistance; // 0x54 Size: 0x4
	    float MaxFacingCameraBlendDistance; // 0x58 Size: 0x4
	    bool bUseLocalSpace; // 0x5c Size: 0x1
	    bool bKillOnDeactivate; // 0x5c Size: 0x1
	    bool bKillOnCompleted; // 0x5c Size: 0x1
	    char UnknownData1[0x1]; // 0x5f
	    char SortMode; // 0x60 Size: 0x1
	    bool bUseLegacyEmitterTime; // 0x64 Size: 0x1
	    bool bRemoveHMDRoll; // 0x64 Size: 0x1
	    char UnknownData2[0x5]; // 0x63
	    float EmitterDuration; // 0x68 Size: 0x4
	    float EmitterDurationLow; // 0x6c Size: 0x4
	    bool bEmitterDurationUseRange; // 0x70 Size: 0x1
	    bool bDurationRecalcEachLoop; // 0x70 Size: 0x1
	    char UnknownData3[0x2]; // 0x72
	    int EmitterLoops; // 0x74 Size: 0x4
	    struct FRawDistributionFloat SpawnRate; // 0x78 Size: 0x38
	    char ParticleBurstMethod; // 0xb0 Size: 0x1
	    char UnknownData4[0x7]; // 0xb1
	    TArray<struct FParticleBurst> BurstList; // 0xb8 Size: 0x10
	    float EmitterDelay; // 0xc8 Size: 0x4
	    float EmitterDelayLow; // 0xcc Size: 0x4
	    bool bEmitterDelayUseRange; // 0xd0 Size: 0x1
	    bool bDelayFirstLoopOnly; // 0xd0 Size: 0x1
	    char UnknownData5[0x2]; // 0xd2
	    char InterpolationMethod; // 0xd4 Size: 0x1
	    char UnknownData6[0x3]; // 0xd5
	    int SubImages_Horizontal; // 0xd8 Size: 0x4
	    int SubImages_Vertical; // 0xdc Size: 0x4
	    bool bScaleUV; // 0xe0 Size: 0x1
	    char UnknownData7[0x3]; // 0xe1
	    float RandomImageTime; // 0xe4 Size: 0x4
	    int RandomImageChanges; // 0xe8 Size: 0x4
	    bool bOverrideSystemMacroUV; // 0xec Size: 0x1
	    char UnknownData8[0x3]; // 0xed
	    struct FVector MacroUVPosition; // 0xf0 Size: 0xc
	    float MacroUVRadius; // 0xfc Size: 0x4
	    bool bUseMaxDrawCount; // 0x100 Size: 0x1
	    char UnknownData9[0x3]; // 0x101
	    int MaxDrawCount; // 0x104 Size: 0x4
	    EParticleUVFlipMode UVFlippingMode; // 0x108 Size: 0x1
	    char UnknownData10[0x7]; // 0x109
	    class UTexture2D* CutoutTexture; // 0x110 Size: 0x8
	    char BoundingMode; // 0x118 Size: 0x1
	    char OpacitySourceMode; // 0x119 Size: 0x1
	    char UnknownData11[0x2]; // 0x11a
	    float AlphaThreshold; // 0x11c Size: 0x4
	    char EmitterNormalsMode; // 0x120 Size: 0x1
	    char UnknownData12[0x3]; // 0x121
	    struct FVector NormalsSphereCenter; // 0x124 Size: 0xc
	    struct FVector NormalsCylinderDirection; // 0x130 Size: 0xc
	    bool bOrbitModuleAffectsVelocityAlignment; // 0x13c Size: 0x1
	    char UnknownData13[0x3]; // 0x13d
	    TArray<FName> NamedMaterialOverrides; // 0x140 Size: 0x10
	    char UnknownData14[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleRequired");
			return (class UClass*)ptr;
		};

};

class UParticleModuleRotation : public UParticleModuleRotationBase
{
	public:
	    struct FRawDistributionFloat StartRotation; // 0x30 Size: 0x38

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleRotation");
			return (class UClass*)ptr;
		};

};

class UParticleModuleRotation_Seeded : public UParticleModuleRotation
{
	public:
	    struct FParticleRandomSeedInfo RandomSeedInfo; // 0x68 Size: 0x20

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleRotation_Seeded");
			return (class UClass*)ptr;
		};

};

class UParticleModuleRotationOverLifetime : public UParticleModuleRotationBase
{
	public:
	    struct FRawDistributionFloat RotationOverLife; // 0x30 Size: 0x38
	    bool Scale; // 0x68 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleRotationOverLifetime");
			return (class UClass*)ptr;
		};

};

class UParticleModuleRotationRate : public UParticleModuleRotationRateBase
{
	public:
	    struct FRawDistributionFloat StartRotationRate; // 0x30 Size: 0x38

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleRotationRate");
			return (class UClass*)ptr;
		};

};

class UParticleModuleRotationRate_Seeded : public UParticleModuleRotationRate
{
	public:
	    struct FParticleRandomSeedInfo RandomSeedInfo; // 0x68 Size: 0x20

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleRotationRate_Seeded");
			return (class UClass*)ptr;
		};

};

class UParticleModuleRotationRateMultiplyLife : public UParticleModuleRotationRateBase
{
	public:
	    struct FRawDistributionFloat LifeMultiplier; // 0x30 Size: 0x38

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleRotationRateMultiplyLife");
			return (class UClass*)ptr;
		};

};

class UParticleModuleSizeBase : public UParticleModule
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleSizeBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleSize : public UParticleModuleSizeBase
{
	public:
	    struct FRawDistributionVector StartSize; // 0x30 Size: 0x50

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleSize");
			return (class UClass*)ptr;
		};

};

class UParticleModuleSize_Seeded : public UParticleModuleSize
{
	public:
	    struct FParticleRandomSeedInfo RandomSeedInfo; // 0x80 Size: 0x20

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleSize_Seeded");
			return (class UClass*)ptr;
		};

};

class UParticleModuleSizeMultiplyLife : public UParticleModuleSizeBase
{
	public:
	    struct FRawDistributionVector LifeMultiplier; // 0x30 Size: 0x50
	    bool MultiplyX; // 0x80 Size: 0x1
	    bool MultiplyY; // 0x80 Size: 0x1
	    bool MultiplyZ; // 0x80 Size: 0x1
	    char UnknownData0[0x5];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleSizeMultiplyLife");
			return (class UClass*)ptr;
		};

};

class UParticleModuleSizeScale : public UParticleModuleSizeBase
{
	public:
	    struct FRawDistributionVector SizeScale; // 0x30 Size: 0x50
	    bool EnableX; // 0x80 Size: 0x1
	    bool EnableY; // 0x80 Size: 0x1
	    bool EnableZ; // 0x80 Size: 0x1
	    char UnknownData0[0x5];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleSizeScale");
			return (class UClass*)ptr;
		};

};

class UParticleModuleSizeScaleBySpeed : public UParticleModuleSizeBase
{
	public:
	    struct FVector2D SpeedScale; // 0x30 Size: 0x8
	    struct FVector2D MaxScale; // 0x38 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleSizeScaleBySpeed");
			return (class UClass*)ptr;
		};

};

class UParticleModuleSourceMovement : public UParticleModuleLocationBase
{
	public:
	    struct FRawDistributionVector SourceMovementScale; // 0x30 Size: 0x50

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleSourceMovement");
			return (class UClass*)ptr;
		};

};

class UParticleModuleSpawnBase : public UParticleModule
{
	public:
	    bool bProcessSpawnRate; // 0x30 Size: 0x1
	    bool bProcessBurstList; // 0x30 Size: 0x1
	    char UnknownData0[0x6];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleSpawnBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleSpawn : public UParticleModuleSpawnBase
{
	public:
	    struct FRawDistributionFloat Rate; // 0x38 Size: 0x38
	    struct FRawDistributionFloat RateScale; // 0x70 Size: 0x38
	    char ParticleBurstMethod; // 0xa8 Size: 0x1
	    char UnknownData0[0x7]; // 0xa9
	    TArray<struct FParticleBurst> BurstList; // 0xb0 Size: 0x10
	    struct FRawDistributionFloat BurstScale; // 0xc0 Size: 0x38
	    bool bApplyGlobalSpawnRateScale; // 0xf8 Size: 0x1
	    char UnknownData1[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleSpawn");
			return (class UClass*)ptr;
		};

};

class UParticleModuleSpawnPerUnit : public UParticleModuleSpawnBase
{
	public:
	    float UnitScalar; // 0x38 Size: 0x4
	    char UnknownData0[0x4]; // 0x3c
	    struct FRawDistributionFloat SpawnPerUnit; // 0x40 Size: 0x38
	    bool bIgnoreSpawnRateWhenMoving; // 0x78 Size: 0x1
	    char UnknownData1[0x3]; // 0x79
	    float MovementTolerance; // 0x7c Size: 0x4
	    float MaxFrameDistance; // 0x80 Size: 0x4
	    bool bIgnoreMovementAlongX; // 0x84 Size: 0x1
	    bool bIgnoreMovementAlongY; // 0x84 Size: 0x1
	    bool bIgnoreMovementAlongZ; // 0x84 Size: 0x1
	    char UnknownData2[0x1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleSpawnPerUnit");
			return (class UClass*)ptr;
		};

};

class UParticleModuleSubUVBase : public UParticleModule
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleSubUVBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleSubUV : public UParticleModuleSubUVBase
{
	public:
	    class USubUVAnimation* Animation; // 0x30 Size: 0x8
	    struct FRawDistributionFloat SubImageIndex; // 0x38 Size: 0x38
	    bool bUseRealTime; // 0x70 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleSubUV");
			return (class UClass*)ptr;
		};

};

class UParticleModuleSubUVMovie : public UParticleModuleSubUV
{
	public:
	    bool bUseEmitterTime; // 0x78 Size: 0x1
	    char UnknownData0[0x7]; // 0x79
	    struct FRawDistributionFloat FrameRate; // 0x80 Size: 0x38
	    int StartingFrame; // 0xb8 Size: 0x4
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleSubUVMovie");
			return (class UClass*)ptr;
		};

};

class UParticleModuleTrailBase : public UParticleModule
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleTrailBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleTrailSource : public UParticleModuleTrailBase
{
	public:
	    char SourceMethod; // 0x30 Size: 0x1
	    char UnknownData0[0x3]; // 0x31
	    FName SourceName; // 0x34 Size: 0x8
	    char UnknownData1[0x4]; // 0x3c
	    struct FRawDistributionFloat SourceStrength; // 0x40 Size: 0x38
	    bool bLockSourceStength; // 0x78 Size: 0x1
	    char UnknownData2[0x3]; // 0x79
	    int SourceOffsetCount; // 0x7c Size: 0x4
	    TArray<struct FVector> SourceOffsetDefaults; // 0x80 Size: 0x10
	    char SelectionMethod; // 0x90 Size: 0x1
	    bool bInheritRotation; // 0x94 Size: 0x1
	    char UnknownData3[0x6];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleTrailSource");
			return (class UClass*)ptr;
		};

};

class UParticleModuleTypeDataBase : public UParticleModule
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleTypeDataBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleTypeDataAnimTrail : public UParticleModuleTypeDataBase
{
	public:
	    bool bDeadTrailsOnDeactivate; // 0x30 Size: 0x1
	    bool bEnablePreviousTangentRecalculation; // 0x30 Size: 0x1
	    bool bTangentRecalculationEveryFrame; // 0x30 Size: 0x1
	    char UnknownData0[0x1]; // 0x33
	    float TilingDistance; // 0x34 Size: 0x4
	    float DistanceTessellationStepSize; // 0x38 Size: 0x4
	    float TangentTessellationStepSize; // 0x3c Size: 0x4
	    float WidthTessellationStepSize; // 0x40 Size: 0x4
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleTypeDataAnimTrail");
			return (class UClass*)ptr;
		};

};

class UParticleModuleTypeDataBeam2 : public UParticleModuleTypeDataBase
{
	public:
	    char BeamMethod; // 0x30 Size: 0x1
	    char UnknownData0[0x3]; // 0x31
	    int TextureTile; // 0x34 Size: 0x4
	    float TextureTileDistance; // 0x38 Size: 0x4
	    int Sheets; // 0x3c Size: 0x4
	    int MaxBeamCount; // 0x40 Size: 0x4
	    float Speed; // 0x44 Size: 0x4
	    int InterpolationPoints; // 0x48 Size: 0x4
	    bool bAlwaysOn; // 0x4c Size: 0x1
	    char UnknownData1[0x3]; // 0x4d
	    int UpVectorStepSize; // 0x50 Size: 0x4
	    FName BranchParentName; // 0x54 Size: 0x8
	    char UnknownData2[0x4]; // 0x5c
	    struct FRawDistributionFloat Distance; // 0x60 Size: 0x38
	    char TaperMethod; // 0x98 Size: 0x1
	    char UnknownData3[0x7]; // 0x99
	    struct FRawDistributionFloat TaperFactor; // 0xa0 Size: 0x38
	    struct FRawDistributionFloat TaperScale; // 0xd8 Size: 0x38
	    bool RenderGeometry; // 0x110 Size: 0x1
	    bool RenderDirectLine; // 0x110 Size: 0x1
	    bool RenderLines; // 0x110 Size: 0x1
	    bool RenderTessellation; // 0x110 Size: 0x1
	    char UnknownData4[0x54];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleTypeDataBeam2");
			return (class UClass*)ptr;
		};

};

class UParticleModuleTypeDataGpu : public UParticleModuleTypeDataBase
{
	public:
	    struct FGPUSpriteEmitterInfo EmitterInfo; // 0x30 Size: 0x2c0
	    struct FGPUSpriteResourceData ResourceData; // 0x2f0 Size: 0x160
	    float CameraMotionBlurAmount; // 0x450 Size: 0x4
	    bool bClearExistingParticlesOnInit; // 0x454 Size: 0x1
	    char UnknownData0[0xb];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleTypeDataGpu");
			return (class UClass*)ptr;
		};

};

class UParticleModuleTypeDataMesh : public UParticleModuleTypeDataBase
{
	public:
	    class UStaticMesh* Mesh; // 0x30 Size: 0x8
	    bool bUseStaticMeshLODs; // 0x38 Size: 0x1
	    char UnknownData0[0x3]; // 0x39
	    float LODSizeScale; // 0x3c Size: 0x4
	    bool CastShadows; // 0x40 Size: 0x1
	    bool DoCollisions; // 0x40 Size: 0x1
	    char UnknownData1[0x2]; // 0x42
	    char MeshAlignment; // 0x44 Size: 0x1
	    bool bOverrideMaterial; // 0x48 Size: 0x1
	    bool bOverrideDefaultMotionBlurSettings; // 0x48 Size: 0x1
	    bool bEnableMotionBlur; // 0x48 Size: 0x1
	    char UnknownData2[0x4]; // 0x48
	    float Pitch; // 0x4c Size: 0x4
	    float Roll; // 0x50 Size: 0x4
	    float Yaw; // 0x54 Size: 0x4
	    struct FRawDistributionVector RollPitchYawRange; // 0x58 Size: 0x50
	    char UnknownData3[0x8]; // 0xa8
	    char AxisLockOption; // 0xb0 Size: 0x1
	    bool bCameraFacing; // 0xb4 Size: 0x1
	    char UnknownData4[0x6]; // 0xb2
	    char CameraFacingUpAxisOption; // 0xb8 Size: 0x1
	    char CameraFacingOption; // 0xb9 Size: 0x1
	    bool bApplyParticleRotationAsSpin; // 0xbc Size: 0x1
	    bool bFaceCameraDirectionRatherThanPosition; // 0xbc Size: 0x1
	    bool bCollisionsConsiderPartilceSize; // 0xbc Size: 0x1
	    char UnknownData5[0x3];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleTypeDataMesh");
			return (class UClass*)ptr;
		};

};

class UParticleModuleTypeDataRibbon : public UParticleModuleTypeDataBase
{
	public:
	    int MaxTessellationBetweenParticles; // 0x30 Size: 0x4
	    int SheetsPerTrail; // 0x34 Size: 0x4
	    int MaxTrailCount; // 0x38 Size: 0x4
	    int MaxParticleInTrailCount; // 0x3c Size: 0x4
	    bool bDeadTrailsOnDeactivate; // 0x40 Size: 0x1
	    bool bDeadTrailsOnSourceLoss; // 0x40 Size: 0x1
	    bool bClipSourceSegement; // 0x40 Size: 0x1
	    bool bEnablePreviousTangentRecalculation; // 0x40 Size: 0x1
	    bool bTangentRecalculationEveryFrame; // 0x40 Size: 0x1
	    bool bSpawnInitialParticle; // 0x40 Size: 0x1
	    char UnknownData0[0x2]; // 0x46
	    char RenderAxis; // 0x44 Size: 0x1
	    char UnknownData1[0x3]; // 0x45
	    float TangentSpawningScalar; // 0x48 Size: 0x4
	    bool bRenderGeometry; // 0x4c Size: 0x1
	    bool bRenderSpawnPoints; // 0x4c Size: 0x1
	    bool bRenderTangents; // 0x4c Size: 0x1
	    bool bRenderTessellation; // 0x4c Size: 0x1
	    float TilingDistance; // 0x50 Size: 0x4
	    float DistanceTessellationStepSize; // 0x54 Size: 0x4
	    bool bEnableTangentDiffInterpScale; // 0x58 Size: 0x1
	    char UnknownData2[0x3]; // 0x59
	    float TangentTessellationScalar; // 0x5c Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleTypeDataRibbon");
			return (class UClass*)ptr;
		};

};

class UParticleModuleVectorFieldBase : public UParticleModule
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleVectorFieldBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleVectorFieldGlobal : public UParticleModuleVectorFieldBase
{
	public:
	    bool bOverrideGlobalVectorFieldTightness; // 0x30 Size: 0x1
	    char UnknownData0[0x3]; // 0x31
	    float GlobalVectorFieldScale; // 0x34 Size: 0x4
	    float GlobalVectorFieldTightness; // 0x38 Size: 0x4
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleVectorFieldGlobal");
			return (class UClass*)ptr;
		};

};

class UParticleModuleVectorFieldLocal : public UParticleModuleVectorFieldBase
{
	public:
	    class UVectorField* VectorField; // 0x30 Size: 0x8
	    struct FVector RelativeTranslation; // 0x38 Size: 0xc
	    struct FRotator RelativeRotation; // 0x44 Size: 0xc
	    struct FVector RelativeScale3D; // 0x50 Size: 0xc
	    float Intensity; // 0x5c Size: 0x4
	    float Tightness; // 0x60 Size: 0x4
	    bool bIgnoreComponentTransform; // 0x64 Size: 0x1
	    bool bTileX; // 0x64 Size: 0x1
	    bool bTileY; // 0x64 Size: 0x1
	    bool bTileZ; // 0x64 Size: 0x1
	    bool bUseFixDT; // 0x64 Size: 0x1
	    char UnknownData0[0x-1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleVectorFieldLocal");
			return (class UClass*)ptr;
		};

};

class UParticleModuleVectorFieldRotation : public UParticleModuleVectorFieldBase
{
	public:
	    struct FVector MinInitialRotation; // 0x30 Size: 0xc
	    struct FVector MaxInitialRotation; // 0x3c Size: 0xc

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleVectorFieldRotation");
			return (class UClass*)ptr;
		};

};

class UParticleModuleVectorFieldRotationRate : public UParticleModuleVectorFieldBase
{
	public:
	    struct FVector RotationRate; // 0x30 Size: 0xc
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleVectorFieldRotationRate");
			return (class UClass*)ptr;
		};

};

class UParticleModuleVectorFieldScale : public UParticleModuleVectorFieldBase
{
	public:
	    class UDistributionFloat* VectorFieldScale; // 0x30 Size: 0x8
	    struct FRawDistributionFloat VectorFieldScaleRaw; // 0x38 Size: 0x38

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleVectorFieldScale");
			return (class UClass*)ptr;
		};

};

class UParticleModuleVectorFieldScaleOverLife : public UParticleModuleVectorFieldBase
{
	public:
	    class UDistributionFloat* VectorFieldScaleOverLife; // 0x30 Size: 0x8
	    struct FRawDistributionFloat VectorFieldScaleOverLifeRaw; // 0x38 Size: 0x38

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleVectorFieldScaleOverLife");
			return (class UClass*)ptr;
		};

};

class UParticleModuleVelocityBase : public UParticleModule
{
	public:
	    bool bInWorldSpace; // 0x30 Size: 0x1
	    bool bApplyOwnerScale; // 0x30 Size: 0x1
	    char UnknownData0[0x6];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleVelocityBase");
			return (class UClass*)ptr;
		};

};

class UParticleModuleVelocity : public UParticleModuleVelocityBase
{
	public:
	    struct FRawDistributionVector StartVelocity; // 0x38 Size: 0x50
	    struct FRawDistributionFloat StartVelocityRadial; // 0x88 Size: 0x38

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleVelocity");
			return (class UClass*)ptr;
		};

};

class UParticleModuleVelocity_Seeded : public UParticleModuleVelocity
{
	public:
	    struct FParticleRandomSeedInfo RandomSeedInfo; // 0xc0 Size: 0x20

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleVelocity_Seeded");
			return (class UClass*)ptr;
		};

};

class UParticleModuleVelocityCone : public UParticleModuleVelocityBase
{
	public:
	    struct FRawDistributionFloat Angle; // 0x38 Size: 0x38
	    struct FRawDistributionFloat Velocity; // 0x70 Size: 0x38
	    struct FVector Direction; // 0xa8 Size: 0xc
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleVelocityCone");
			return (class UClass*)ptr;
		};

};

class UParticleModuleVelocityInheritParent : public UParticleModuleVelocityBase
{
	public:
	    struct FRawDistributionVector Scale; // 0x38 Size: 0x50

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleVelocityInheritParent");
			return (class UClass*)ptr;
		};

};

class UParticleModuleVelocityOverLifetime : public UParticleModuleVelocityBase
{
	public:
	    struct FRawDistributionVector VelOverLife; // 0x38 Size: 0x50
	    bool Absolute; // 0x88 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleModuleVelocityOverLifetime");
			return (class UClass*)ptr;
		};

};

class UParticleSpriteEmitter : public UParticleEmitter
{
	public:
	    char UnknownData0[0x158];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleSpriteEmitter");
			return (class UClass*)ptr;
		};

};

class UParticleSystem : public UObject
{
	public:
	    char SystemUpdateMode; // 0x28 Size: 0x1
	    char UnknownData0[0x3]; // 0x29
	    float UpdateTime_FPS; // 0x2c Size: 0x4
	    float UpdateTime_Delta; // 0x30 Size: 0x4
	    float WarmupTime; // 0x34 Size: 0x4
	    float WarmupTickRate; // 0x38 Size: 0x4
	    char UnknownData1[0x4]; // 0x3c
	    TArray<class UParticleEmitter*> Emitters; // 0x40 Size: 0x10
	    class UParticleSystemComponent* PreviewComponent; // 0x50 Size: 0x8
	    class UInterpCurveEdSetup* CurveEdSetup; // 0x58 Size: 0x8
	    bool bOrientZAxisTowardCamera; // 0x60 Size: 0x1
	    char UnknownData2[0x3]; // 0x61
	    float LODDistanceCheckTime; // 0x64 Size: 0x4
	    char LODMethod; // 0x68 Size: 0x1
	    char UnknownData3[0x7]; // 0x69
	    TArray<float> LODDistances; // 0x70 Size: 0x10
	    bool bRegenerateLODDuplicate; // 0x80 Size: 0x1
	    char UnknownData4[0x7]; // 0x81
	    TArray<struct FParticleSystemLOD> LODSettings; // 0x88 Size: 0x10
	    bool bUseFixedRelativeBoundingBox; // 0x98 Size: 0x1
	    char UnknownData5[0x3]; // 0x99
	    struct FBox FixedRelativeBoundingBox; // 0x9c Size: 0x1c
	    float SecondsBeforeInactive; // 0xb8 Size: 0x4
	    bool bShouldResetPeakCounts; // 0xbc Size: 0x1
	    bool bHasPhysics; // 0xbc Size: 0x1
	    bool bUseRealtimeThumbnail; // 0xbc Size: 0x1
	    bool ThumbnailImageOutOfDate; // 0xbc Size: 0x1
	    float Delay; // 0xc0 Size: 0x4
	    float DelayLow; // 0xc4 Size: 0x4
	    bool bUseDelayRange; // 0xc8 Size: 0x1
	    bool bAllowManagedTicking; // 0xc8 Size: 0x1
	    bool bAutoDeactivate; // 0xcc Size: 0x1
	    char UnknownData6[0x5]; // 0xcb
	    uint32_t MinTimeBetweenTicks; // 0xd0 Size: 0x4
	    EParticleSystemInsignificanceReaction InsignificantReaction; // 0xd4 Size: 0x1
	    char UnknownData7[0x3]; // 0xd5
	    float InsignificanceDelay; // 0xd8 Size: 0x4
	    EParticleSignificanceLevel MaxSignificanceLevel; // 0xdc Size: 0x1
	    char UnknownData8[0x3]; // 0xdd
	    uint32_t MaxPoolSize; // 0xe0 Size: 0x4
	    struct FVector MacroUVPosition; // 0xe4 Size: 0xc
	    float MacroUVRadius; // 0xf0 Size: 0x4
	    char OcclusionBoundsMethod; // 0xf4 Size: 0x1
	    char UnknownData9[0x3]; // 0xf5
	    struct FBox CustomOcclusionBounds; // 0xf8 Size: 0x1c
	    char UnknownData10[0x4]; // 0x114
	    TArray<struct FLODSoloTrack> SoloTracking; // 0x118 Size: 0x10
	    TArray<struct FNamedEmitterMaterial> NamedMaterialSlots; // 0x128 Size: 0x10
	    char UnknownData11[0x138]; // 0x138
	    bool ContainsEmitterType(class UObject* TypeData); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7ea1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleSystem");
			return (class UClass*)ptr;
		};

};

class UParticleSystemComponent : public UPrimitiveComponent
{
	public:
	    class UParticleSystem* Template; // 0x570 Size: 0x8
	    TArray<class UMaterialInterface*> EmitterMaterials; // 0x578 Size: 0x10
	    TArray<class USkeletalMeshComponent*> SkelMeshComponents; // 0x588 Size: 0x10
	    bool bResetOnDetach; // 0x599 Size: 0x1
	    bool bUpdateOnDedicatedServer; // 0x599 Size: 0x1
	    bool bAllowRecycling; // 0x599 Size: 0x1
	    bool bAutoManageAttachment; // 0x599 Size: 0x1
	    bool bWarmingUp; // 0x59a Size: 0x1
	    bool bOverrideLODMethod; // 0x59a Size: 0x1
	    bool bSkipUpdateDynamicDataDuringTick; // 0x59a Size: 0x1
	    char UnknownData0[0x2]; // 0x59f
	    char LODMethod; // 0x5a1 Size: 0x1
	    EParticleSignificanceLevel RequiredSignificance; // 0x5a2 Size: 0x1
	    char UnknownData1[0x5]; // 0x5a3
	    TArray<struct FParticleSysParam> InstanceParameters; // 0x5a8 Size: 0x10
	    MulticastDelegateProperty OnParticleSpawn; // 0x5b8 Size: 0x10
	    MulticastDelegateProperty OnParticleBurst; // 0x5c8 Size: 0x10
	    MulticastDelegateProperty OnParticleDeath; // 0x5d8 Size: 0x10
	    MulticastDelegateProperty OnParticleCollide; // 0x5e8 Size: 0x10
	    struct FVector OldPosition; // 0x5f8 Size: 0xc
	    struct FVector PartSysVelocity; // 0x604 Size: 0xc
	    float WarmupTime; // 0x610 Size: 0x4
	    float WarmupTickRate; // 0x614 Size: 0x4
	    char UnknownData2[0x4]; // 0x618
	    float SecondsBeforeInactive; // 0x61c Size: 0x4
	    char UnknownData3[0x4]; // 0x620
	    float MaxTimeBeforeForceUpdateTransform; // 0x624 Size: 0x4
	    char UnknownData4[0x20]; // 0x628
	    TArray<class UParticleSystemReplay*> ReplayClips; // 0x648 Size: 0x10
	    char UnknownData5[0x8]; // 0x658
	    float CustomTimeDilation; // 0x660 Size: 0x4
	    char UnknownData6[0x54]; // 0x664
	    TWeakObjectPtr<USceneComponent*> AutoAttachParent; // 0x6b8 Size: 0x8
	    FName AutoAttachSocketName; // 0x6c0 Size: 0x8
	    EAttachmentRule AutoAttachLocationRule; // 0x6c8 Size: 0x1
	    EAttachmentRule AutoAttachRotationRule; // 0x6c9 Size: 0x1
	    EAttachmentRule AutoAttachScaleRule; // 0x6ca Size: 0x1
	    char UnknownData7[0x2d]; // 0x6cb
	    MulticastDelegateProperty OnSystemFinished; // 0x6f8 Size: 0x10
	    char UnknownData8[0x708]; // 0x708
	    void SetVectorParameter(FName ParameterName, struct FVector Param); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetTrailSourceData(FName InFirstSocketName, FName InSecondSocketName, char InWidthMode, float InWidth); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetTemplate(class UParticleSystem* NewTemplate); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetMaterialParameter(FName ParameterName, class UMaterialInterface* Param); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetFloatParameter(FName ParameterName, float Param); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void SetEmitterEnable(FName EmitterName, bool bNewEnableState); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void SetColorParameter(FName ParameterName, struct FLinearColor Param); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void SetBeamTargetTangent(int EmitterIndex, struct FVector NewTangentPoint, int TargetIndex); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void SetBeamTargetStrength(int EmitterIndex, float NewTargetStrength, int TargetIndex); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void SetBeamTargetPoint(int EmitterIndex, struct FVector NewTargetPoint, int TargetIndex); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void SetBeamSourceTangent(int EmitterIndex, struct FVector NewTangentPoint, int SourceIndex); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void SetBeamSourceStrength(int EmitterIndex, float NewSourceStrength, int SourceIndex); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void SetBeamSourcePoint(int EmitterIndex, struct FVector NewSourcePoint, int SourceIndex); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void SetBeamEndPoint(int EmitterIndex, struct FVector NewEndPoint); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void SetAutoAttachParams(class USceneComponent* Parent, FName SocketName, char LocationType); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void SetAutoAttachmentParameters(class USceneComponent* Parent, FName SocketName, EAttachmentRule LocationRule, EAttachmentRule RotationRule, EAttachmentRule ScaleRule); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void SetActorParameter(FName ParameterName, class AActor* Param); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void ReleaseToPool(); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    int GetNumActiveParticles(); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    class UMaterialInterface* GetNamedMaterial(FName InName); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    bool GetBeamTargetTangent(int EmitterIndex, int TargetIndex, struct FVector OutTangentPoint); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    bool GetBeamTargetStrength(int EmitterIndex, int TargetIndex, float OutTargetStrength); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    bool GetBeamTargetPoint(int EmitterIndex, int TargetIndex, struct FVector OutTargetPoint); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    bool GetBeamSourceTangent(int EmitterIndex, int SourceIndex, struct FVector OutTangentPoint); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    bool GetBeamSourceStrength(int EmitterIndex, int SourceIndex, float OutSourceStrength); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    bool GetBeamSourcePoint(int EmitterIndex, int SourceIndex, struct FVector OutSourcePoint); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    bool GetBeamEndPoint(int EmitterIndex, struct FVector OutEndPoint); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    void GenerateParticleEvent(FName InEventName, float InEmitterTime, struct FVector InLocation, struct FVector InDirection, struct FVector InVelocity); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    void EndTrails(); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    class UMaterialInstanceDynamic* CreateNamedDynamicMaterialInstance(FName InName, class UMaterialInterface* SourceMaterial); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    void BeginTrails(FName InFirstSocketName, FName InSecondSocketName, char InWidthMode, float InWidth); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x-7811];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleSystemComponent");
			return (class UClass*)ptr;
		};

};

class UParticleSystemReplay : public UObject
{
	public:
	    int ClipIDNumber; // 0x28 Size: 0x4
	    char UnknownData0[0x14];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ParticleSystemReplay");
			return (class UClass*)ptr;
		};

};

class UPathFollowingAgentInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PathFollowingAgentInterface");
			return (class UClass*)ptr;
		};

};

class UPawnNoiseEmitterComponent : public UActorComponent
{
	public:
	    bool bAIPerceptionSystemCompatibilityMode; // 0xf8 Size: 0x1
	    char UnknownData0[0x3]; // 0xf9
	    struct FVector LastRemoteNoisePosition; // 0xfc Size: 0xc
	    float NoiseLifetime; // 0x108 Size: 0x4
	    float LastRemoteNoiseVolume; // 0x10c Size: 0x4
	    float LastRemoteNoiseTime; // 0x110 Size: 0x4
	    float LastLocalNoiseVolume; // 0x114 Size: 0x4
	    float LastLocalNoiseTime; // 0x118 Size: 0x4
	    char UnknownData1[0x11c]; // 0x11c
	    void MakeNoise(class AActor* NoiseMaker, float Loudness, struct FVector NoiseLocation); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7ec1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PawnNoiseEmitterComponent");
			return (class UClass*)ptr;
		};

};

class UPhysicalAnimationComponent : public UActorComponent
{
	public:
	    float StrengthMultiplyer; // 0xf8 Size: 0x4
	    char UnknownData0[0x4]; // 0xfc
	    class USkeletalMeshComponent* SkeletalMeshComponent; // 0x100 Size: 0x8
	    char UnknownData1[0x108]; // 0x108
	    void SetStrengthMultiplyer(float InStrengthMultiplyer); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetSkeletalMeshComponent(class USkeletalMeshComponent* InSkeletalMeshComponent); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    struct FTransform GetBodyTargetTransform(FName BodyName); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void ApplyPhysicalAnimationSettingsBelow(FName BodyName, struct FPhysicalAnimationData PhysicalAnimationData, bool bIncludeSelf); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ApplyPhysicalAnimationSettings(FName BodyName, struct FPhysicalAnimationData PhysicalAnimationData); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ApplyPhysicalAnimationProfileBelow(FName BodyName, FName ProfileName, bool bIncludeSelf, bool bClearNotFound); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7eb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PhysicalAnimationComponent");
			return (class UClass*)ptr;
		};

};

class UPhysicalMaterial : public UObject
{
	public:
	    float Friction; // 0x28 Size: 0x4
	    char FrictionCombineMode; // 0x2c Size: 0x1
	    bool bOverrideFrictionCombineMode; // 0x2d Size: 0x1
	    char UnknownData0[0x2]; // 0x2e
	    float Restitution; // 0x30 Size: 0x4
	    char RestitutionCombineMode; // 0x34 Size: 0x1
	    bool bOverrideRestitutionCombineMode; // 0x35 Size: 0x1
	    char UnknownData1[0x2]; // 0x36
	    float Density; // 0x38 Size: 0x4
	    float RaiseMassToPower; // 0x3c Size: 0x4
	    float DestructibleDamageThresholdScale; // 0x40 Size: 0x4
	    char UnknownData2[0x4]; // 0x44
	    class UPhysicalMaterialPropertyBase* PhysicalMaterialProperty; // 0x48 Size: 0x8
	    char SurfaceType; // 0x50 Size: 0x1
	    char UnknownData3[0x3]; // 0x51
	    float TireFrictionScale; // 0x54 Size: 0x4
	    TArray<struct FTireFrictionScalePair> TireFrictionScales; // 0x58 Size: 0x10
	    char UnknownData4[0x18];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PhysicalMaterial");
			return (class UClass*)ptr;
		};

};

class UPhysicalMaterialPropertyBase : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PhysicalMaterialPropertyBase");
			return (class UClass*)ptr;
		};

};

class UPhysicsAsset : public UObject
{
	public:
	    char UnknownData0[0x8];
	    TArray<int> BoundsBodies; // 0x30 Size: 0x10
	    TArray<class USkeletalBodySetup*> SkeletalBodySetups; // 0x40 Size: 0x10
	    TArray<class UPhysicsConstraintTemplate*> ConstraintSetup; // 0x50 Size: 0x10
	    bool bUseAsyncScene; // 0x60 Size: 0x1
	    bool bNotForDedicatedServer; // 0x60 Size: 0x1
	    char UnknownData1[0xa6]; // 0x62
	    class UThumbnailInfo* ThumbnailInfo; // 0x108 Size: 0x8
	    TArray<class UBodySetup*> BodySetup; // 0x110 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PhysicsAsset");
			return (class UClass*)ptr;
		};

};

class USkeletalBodySetup : public UBodySetup
{
	public:
	    bool bSkipScaleFromAnimation; // 0x280 Size: 0x1
	    char UnknownData0[0x7]; // 0x281
	    TArray<struct FPhysicalAnimationProfile> PhysicalAnimationData; // 0x288 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SkeletalBodySetup");
			return (class UClass*)ptr;
		};

};

class UPhysicsCollisionHandler : public UObject
{
	public:
	    float ImpactThreshold; // 0x28 Size: 0x4
	    float ImpactReFireDelay; // 0x2c Size: 0x4
	    class USoundBase* DefaultImpactSound; // 0x30 Size: 0x8
	    float LastImpactSoundTime; // 0x38 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PhysicsCollisionHandler");
			return (class UClass*)ptr;
		};

};

class ARigidBodyBase : public AActor
{
	public:
	    char UnknownData0[0x330];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.RigidBodyBase");
			return (class UClass*)ptr;
		};

};

class APhysicsConstraintActor : public ARigidBodyBase
{
	public:
	    class UPhysicsConstraintComponent* ConstraintComp; // 0x330 Size: 0x8
	    class AActor* ConstraintActor1; // 0x338 Size: 0x8
	    class AActor* ConstraintActor2; // 0x340 Size: 0x8
	    bool bDisableCollision; // 0x348 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PhysicsConstraintActor");
			return (class UClass*)ptr;
		};

};

class UPhysicsConstraintComponent : public USceneComponent
{
	public:
	    class AActor* ConstraintActor1; // 0x248 Size: 0x8
	    struct FConstrainComponentPropName ComponentName1; // 0x250 Size: 0x8
	    class AActor* ConstraintActor2; // 0x258 Size: 0x8
	    struct FConstrainComponentPropName ComponentName2; // 0x260 Size: 0x8
	    char UnknownData0[0x10]; // 0x268
	    class UPhysicsConstraintTemplate* ConstraintSetup; // 0x278 Size: 0x8
	    MulticastDelegateProperty OnConstraintBroken; // 0x280 Size: 0x10
	    struct FConstraintInstance ConstraintInstance; // 0x290 Size: 0x1b8
	    char UnknownData1[0x448]; // 0x448
	    void SetOrientationDriveTwistAndSwing(bool bEnableTwistDrive, bool bEnableSwingDrive); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetOrientationDriveSLERP(bool bEnableSLERP); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetLinearZLimit(char ConstraintType, float LimitSize); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetLinearYLimit(char ConstraintType, float LimitSize); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetLinearXLimit(char ConstraintType, float LimitSize); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetLinearVelocityTarget(struct FVector InVelTarget); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetLinearVelocityDrive(bool bEnableDriveX, bool bEnableDriveY, bool bEnableDriveZ); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetLinearPositionTarget(struct FVector InPosTarget); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetLinearPositionDrive(bool bEnableDriveX, bool bEnableDriveY, bool bEnableDriveZ); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetLinearDriveParams(float PositionStrength, float VelocityStrength, float InForceLimit); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetLinearBreakable(bool bLinearBreakable, float LinearBreakThreshold); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetDisableCollision(bool bDisableCollision); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void SetConstraintReferencePosition(char Frame, struct FVector RefPosition); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void SetConstraintReferenceOrientation(char Frame, struct FVector PriAxis, struct FVector SecAxis); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void SetConstraintReferenceFrame(char Frame, struct FTransform RefFrame); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void SetConstrainedComponents(class UPrimitiveComponent* Component1, FName BoneName1, class UPrimitiveComponent* Component2, FName BoneName2); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void SetAngularVelocityTarget(struct FVector InVelTarget); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void SetAngularVelocityDriveTwistAndSwing(bool bEnableTwistDrive, bool bEnableSwingDrive); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void SetAngularVelocityDriveSLERP(bool bEnableSLERP); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void SetAngularVelocityDrive(bool bEnableSwingDrive, bool bEnableTwistDrive); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void SetAngularTwistLimit(char ConstraintType, float TwistLimitAngle); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void SetAngularSwing2Limit(char MotionType, float Swing2LimitAngle); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void SetAngularSwing1Limit(char MotionType, float Swing1LimitAngle); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void SetAngularOrientationTarget(struct FRotator InPosTarget); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void SetAngularOrientationDrive(bool bEnableSwingDrive, bool bEnableTwistDrive); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void SetAngularDriveParams(float PositionStrength, float VelocityStrength, float InForceLimit); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    void SetAngularDriveMode(char DriveMode); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    void SetAngularBreakable(bool bAngularBreakable, float AngularBreakThreshold); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    bool IsBroken(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    float GetCurrentTwist(); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    float GetCurrentSwing2(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    float GetCurrentSwing1(); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    void GetConstraintForce(struct FVector OutLinearForce, struct FVector OutAngularForce); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    void BreakConstraint(); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x-7b91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PhysicsConstraintComponent");
			return (class UClass*)ptr;
		};

};

class UPhysicsConstraintTemplate : public UObject
{
	public:
	    struct FConstraintInstance DefaultInstance; // 0x28 Size: 0x1b8
	    TArray<struct FPhysicsConstraintProfileHandle> ProfileHandles; // 0x1e0 Size: 0x10
	    struct FConstraintProfileProperties DefaultProfile; // 0x1f0 Size: 0x104
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PhysicsConstraintTemplate");
			return (class UClass*)ptr;
		};

};

class UPhysicsHandleComponent : public UActorComponent
{
	public:
	    class UPrimitiveComponent* GrabbedComponent; // 0xf8 Size: 0x8
	    bool bSoftAngularConstraint; // 0x108 Size: 0x1
	    bool bSoftLinearConstraint; // 0x108 Size: 0x1
	    bool bInterpolateTarget; // 0x108 Size: 0x1
	    char UnknownData0[0x9]; // 0x103
	    float LinearDamping; // 0x10c Size: 0x4
	    float LinearStiffness; // 0x110 Size: 0x4
	    float AngularDamping; // 0x114 Size: 0x4
	    float AngularStiffness; // 0x118 Size: 0x4
	    char UnknownData1[0x64]; // 0x11c
	    float InterpolationSpeed; // 0x180 Size: 0x4
	    char UnknownData2[0x184]; // 0x184
	    void SetTargetRotation(struct FRotator NewRotation); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetTargetLocationAndRotation(struct FVector NewLocation, struct FRotator NewRotation); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetTargetLocation(struct FVector NewLocation); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetLinearStiffness(float NewLinearStiffness); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetLinearDamping(float NewLinearDamping); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetInterpolationSpeed(float NewInterpolationSpeed); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetAngularStiffness(float NewAngularStiffness); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetAngularDamping(float NewAngularDamping); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void ReleaseComponent(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void GrabComponentAtLocationWithRotation(class UPrimitiveComponent* Component, FName InBoneName, struct FVector Location, struct FRotator Rotation); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void GrabComponentAtLocation(class UPrimitiveComponent* Component, FName InBoneName, struct FVector GrabLocation); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void GrabComponent(class UPrimitiveComponent* Component, FName InBoneName, struct FVector GrabLocation, bool bConstrainRotation); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void GetTargetLocationAndRotation(struct FVector TargetLocation, struct FRotator TargetRotation); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    class UPrimitiveComponent* GetGrabbedComponent(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x-7e41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PhysicsHandleComponent");
			return (class UClass*)ptr;
		};

};

class UPhysicsSettings : public UDeveloperSettings
{
	public:
	    float DefaultGravityZ; // 0x38 Size: 0x4
	    float DefaultTerminalVelocity; // 0x3c Size: 0x4
	    float DefaultFluidFriction; // 0x40 Size: 0x4
	    int SimulateScratchMemorySize; // 0x44 Size: 0x4
	    int RagdollAggregateThreshold; // 0x48 Size: 0x4
	    float TriangleMeshTriangleMinAreaThreshold; // 0x4c Size: 0x4
	    bool bEnableAsyncScene; // 0x50 Size: 0x1
	    bool bEnableShapeSharing; // 0x51 Size: 0x1
	    bool bEnablePCM; // 0x52 Size: 0x1
	    bool bEnableStabilization; // 0x53 Size: 0x1
	    bool bWarnMissingLocks; // 0x54 Size: 0x1
	    bool bEnable2DPhysics; // 0x55 Size: 0x1
	    char UnknownData0[0x2]; // 0x56
	    struct FRigidBodyErrorCorrection PhysicErrorCorrection; // 0x58 Size: 0x34
	    char LockedAxis; // 0x8c Size: 0x1
	    char DefaultDegreesOfFreedom; // 0x8d Size: 0x1
	    char UnknownData1[0x2]; // 0x8e
	    float BounceThresholdVelocity; // 0x90 Size: 0x4
	    char FrictionCombineMode; // 0x94 Size: 0x1
	    char RestitutionCombineMode; // 0x95 Size: 0x1
	    char UnknownData2[0x2]; // 0x96
	    float MaxAngularVelocity; // 0x98 Size: 0x4
	    float MaxDepenetrationVelocity; // 0x9c Size: 0x4
	    float ContactOffsetMultiplier; // 0xa0 Size: 0x4
	    float MinContactOffset; // 0xa4 Size: 0x4
	    float MaxContactOffset; // 0xa8 Size: 0x4
	    bool bSimulateSkeletalMeshOnDedicatedServer; // 0xac Size: 0x1
	    char DefaultShapeComplexity; // 0xad Size: 0x1
	    bool bDefaultHasComplexCollision; // 0xae Size: 0x1
	    bool bSuppressFaceRemapTable; // 0xaf Size: 0x1
	    bool bSupportUVFromHitResults; // 0xb0 Size: 0x1
	    bool bDisableActiveActors; // 0xb1 Size: 0x1
	    bool bDisableKinematicStaticPairs; // 0xb2 Size: 0x1
	    bool bDisableKinematicKinematicPairs; // 0xb3 Size: 0x1
	    bool bDisableCCD; // 0xb4 Size: 0x1
	    bool bEnableEnhancedDeterminism; // 0xb5 Size: 0x1
	    char UnknownData3[0x2]; // 0xb6
	    float MaxPhysicsDeltaTime; // 0xb8 Size: 0x4
	    bool bSubstepping; // 0xbc Size: 0x1
	    bool bSubsteppingAsync; // 0xbd Size: 0x1
	    char UnknownData4[0x2]; // 0xbe
	    float MaxSubstepDeltaTime; // 0xc0 Size: 0x4
	    int MaxSubsteps; // 0xc4 Size: 0x4
	    float SyncSceneSmoothingFactor; // 0xc8 Size: 0x4
	    float AsyncSceneSmoothingFactor; // 0xcc Size: 0x4
	    float InitialAverageFrameRate; // 0xd0 Size: 0x4
	    int PhysXTreeRebuildRate; // 0xd4 Size: 0x4
	    TArray<struct FPhysicalSurfaceName> PhysicalSurfaces; // 0xd8 Size: 0x10
	    struct FBroadphaseSettings DefaultBroadphaseSettings; // 0xe8 Size: 0x24
	    char UnknownData5[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PhysicsSettings");
			return (class UClass*)ptr;
		};

};

class UPhysicsSpringComponent : public USceneComponent
{
	public:
	    float SpringStiffness; // 0x248 Size: 0x4
	    float SpringDamping; // 0x24c Size: 0x4
	    float SpringLengthAtRest; // 0x250 Size: 0x4
	    float SpringRadius; // 0x254 Size: 0x4
	    char SpringChannel; // 0x258 Size: 0x1
	    bool bIgnoreSelf; // 0x259 Size: 0x1
	    char UnknownData0[0x2]; // 0x25a
	    float SpringCompression; // 0x25c Size: 0x4
	    char UnknownData1[0x260]; // 0x260
	    struct FVector GetSpringRestingPoint(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    struct FVector GetSpringDirection(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    struct FVector GetSpringCurrentEndPoint(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    float GetNormalizedCompressionScalar(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7d71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PhysicsSpringComponent");
			return (class UClass*)ptr;
		};

};

class APhysicsThruster : public ARigidBodyBase
{
	public:
	    class UPhysicsThrusterComponent* ThrusterComponent; // 0x330 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PhysicsThruster");
			return (class UClass*)ptr;
		};

};

class UPhysicsThrusterComponent : public USceneComponent
{
	public:
	    float ThrustStrength; // 0x248 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PhysicsThrusterComponent");
			return (class UClass*)ptr;
		};

};

class ASceneCapture : public AActor
{
	public:
	    class UStaticMeshComponent* MeshComp; // 0x330 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SceneCapture");
			return (class UClass*)ptr;
		};

};

class APlanarReflection : public ASceneCapture
{
	public:
	    class UPlanarReflectionComponent* PlanarReflectionComponent; // 0x338 Size: 0x8
	    bool bShowPreviewPlane; // 0x340 Size: 0x1
	    char UnknownData0[0x341]; // 0x341
	    void OnInterpToggle(bool bEnable); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7c99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PlanarReflection");
			return (class UClass*)ptr;
		};

};

class USceneCaptureComponent : public USceneComponent
{
	public:
	    ESceneCapturePrimitiveRenderMode PrimitiveRenderMode; // 0x248 Size: 0x1
	    char UnknownData0[0x7]; // 0x249
	    TArray<TWeakObjectPtr<UPrimitiveComponent*>> HiddenComponents; // 0x250 Size: 0x10
	    TArray<class AActor*> HiddenActors; // 0x260 Size: 0x10
	    TArray<TWeakObjectPtr<UPrimitiveComponent*>> ShowOnlyComponents; // 0x270 Size: 0x10
	    TArray<class AActor*> ShowOnlyActors; // 0x280 Size: 0x10
	    bool bCaptureEveryFrame; // 0x290 Size: 0x1
	    bool bCaptureOnMovement; // 0x291 Size: 0x1
	    bool bAlwaysPersistRenderingState; // 0x292 Size: 0x1
	    char UnknownData1[0x1]; // 0x293
	    float LODDistanceFactor; // 0x294 Size: 0x4
	    float MaxViewDistanceOverride; // 0x298 Size: 0x4
	    int CaptureSortPriority; // 0x29c Size: 0x4
	    TArray<struct FEngineShowFlagsSetting> ShowFlagSettings; // 0x2a0 Size: 0x10
	    char UnknownData2[0x10]; // 0x2b0
	    struct FString ProfilingEventName; // 0x2c0 Size: 0x10
	    char UnknownData3[0x2d0]; // 0x2d0
	    void ShowOnlyComponent(class UPrimitiveComponent* InComponent); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void ShowOnlyActorComponents(class AActor* InActor); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetCaptureSortPriority(int NewCaptureSortPriority); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void RemoveShowOnlyComponent(class UPrimitiveComponent* InComponent); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void RemoveShowOnlyActorComponents(class AActor* InActor); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void HideComponent(class UPrimitiveComponent* InComponent); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void HideActorComponents(class AActor* InActor); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void ClearShowOnlyComponents(class UPrimitiveComponent* InComponent); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void ClearHiddenComponents(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7d01];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SceneCaptureComponent");
			return (class UClass*)ptr;
		};

};

class UPlanarReflectionComponent : public USceneCaptureComponent
{
	public:
	    class UBoxComponent* PreviewBox; // 0x2e0 Size: 0x8
	    float NormalDistortionStrength; // 0x2e8 Size: 0x4
	    float PrefilterRoughness; // 0x2ec Size: 0x4
	    float PrefilterRoughnessDistance; // 0x2f0 Size: 0x4
	    int ScreenPercentage; // 0x2f4 Size: 0x4
	    float ExtraFOV; // 0x2f8 Size: 0x4
	    float DistanceFromPlaneFadeStart; // 0x2fc Size: 0x4
	    float DistanceFromPlaneFadeEnd; // 0x300 Size: 0x4
	    float DistanceFromPlaneFadeoutStart; // 0x304 Size: 0x4
	    float DistanceFromPlaneFadeoutEnd; // 0x308 Size: 0x4
	    float AngleFromPlaneFadeStart; // 0x30c Size: 0x4
	    float AngleFromPlaneFadeEnd; // 0x310 Size: 0x4
	    bool bRenderSceneTwoSided; // 0x314 Size: 0x1
	    char UnknownData0[0xbb];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PlanarReflectionComponent");
			return (class UClass*)ptr;
		};

};

class APlaneReflectionCapture : public AReflectionCapture
{
	public:
	    char UnknownData0[0x338];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PlaneReflectionCapture");
			return (class UClass*)ptr;
		};

};

class UPlaneReflectionCaptureComponent : public UReflectionCaptureComponent
{
	public:
	    float InfluenceRadiusScale; // 0x2c0 Size: 0x4
	    char UnknownData0[0x4]; // 0x2c4
	    class UDrawSphereComponent* PreviewInfluenceRadius; // 0x2c8 Size: 0x8
	    class UBoxComponent* PreviewCaptureBox; // 0x2d0 Size: 0x8
	    char UnknownData1[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PlaneReflectionCaptureComponent");
			return (class UClass*)ptr;
		};

};

class UPlatformEventsComponent : public UActorComponent
{
	public:
	    MulticastDelegateProperty PlatformChangedToLaptopModeDelegate; // 0xf8 Size: 0x10
	    MulticastDelegateProperty PlatformChangedToTabletModeDelegate; // 0x108 Size: 0x10
	    char UnknownData0[0x118]; // 0x118
	    bool SupportsConvertibleLaptops(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    __int64/*DelegateFunction*/ PlatformEventDelegate__DelegateSignature; // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    bool IsInTabletMode(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    bool IsInLaptopMode(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7ec9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PlatformEventsComponent");
			return (class UClass*)ptr;
		};

};

class UPlatformInterfaceWebResponse : public UObject
{
	public:
	    struct FString OriginalURL; // 0x28 Size: 0x10
	    int ResponseCode; // 0x38 Size: 0x4
	    int Tag; // 0x3c Size: 0x4
	    struct FString StringResponse; // 0x40 Size: 0x10
	    TArray<char> BinaryResponse; // 0x50 Size: 0x10
	    char UnknownData0[0x60]; // 0x60
	    int GetNumHeaders(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    struct FString GetHeaderValue(struct FString HeaderName); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void GetHeader(int HeaderIndex, struct FString Header, struct FString Value); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7f31];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PlatformInterfaceWebResponse");
			return (class UClass*)ptr;
		};

};

class APlayerStartPIE : public APlayerStart
{
	public:
	    char UnknownData0[0x360];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PlayerStartPIE");
			return (class UClass*)ptr;
		};

};

class UPluginCommandlet : public UCommandlet
{
	public:
	    char UnknownData0[0xa0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PluginCommandlet");
			return (class UClass*)ptr;
		};

};

class APointLight : public ALight
{
	public:
	    class UPointLightComponent* PointLightComponent; // 0x340 Size: 0x8
	    char UnknownData0[0x348]; // 0x348
	    void SetRadius(float NewRadius); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetLightFalloffExponent(float NewLightFalloffExponent); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7c99];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PointLight");
			return (class UClass*)ptr;
		};

};

class UPointLightComponent : public ULocalLightComponent
{
	public:
	    bool bUseInverseSquaredFalloff; // 0x390 Size: 0x1
	    char UnknownData0[0x3]; // 0x391
	    float LightFalloffExponent; // 0x394 Size: 0x4
	    float SourceRadius; // 0x398 Size: 0x4
	    float SoftSourceRadius; // 0x39c Size: 0x4
	    float SourceLength; // 0x3a0 Size: 0x4
	    char UnknownData1[0x3a4]; // 0x3a4
	    void SetSourceRadius(float bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetSourceLength(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetSoftSourceRadius(float bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetLightFalloffExponent(float NewLightFalloffExponent); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7c31];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PointLightComponent");
			return (class UClass*)ptr;
		};

};

class UPolys : public UObject
{
	public:
	    char UnknownData0[0x38];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Polys");
			return (class UClass*)ptr;
		};

};

class UPoseableMeshComponent : public USkinnedMeshComponent
{
	public:
	    void SetBoneTransformByName(FName BoneName, struct FTransform InTransform, char BoneSpace); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void SetBoneScaleByName(FName BoneName, struct FVector InScale3D, char BoneSpace); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetBoneRotationByName(FName BoneName, struct FRotator InRotation, char BoneSpace); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetBoneLocationByName(FName BoneName, struct FVector InLocation, char BoneSpace); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void ResetBoneTransformByName(FName BoneName); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    struct FTransform GetBoneTransformByName(FName BoneName, char BoneSpace); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    struct FVector GetBoneScaleByName(FName BoneName, char BoneSpace); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    struct FRotator GetBoneRotationByName(FName BoneName, char BoneSpace); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    struct FVector GetBoneLocationByName(FName BoneName, char BoneSpace); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void CopyPoseFromSkeletalComponent(class USkeletalMeshComponent* InComponentToCopy); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7781];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PoseableMeshComponent");
			return (class UClass*)ptr;
		};

};

class UPoseAsset : public UAnimationAsset
{
	public:
	    struct FPoseDataContainer PoseContainer; // 0x80 Size: 0x90
	    bool bAdditivePose; // 0x110 Size: 0x1
	    char UnknownData0[0x3]; // 0x111
	    int BasePoseIndex; // 0x114 Size: 0x4
	    FName RetargetSource; // 0x118 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PoseAsset");
			return (class UClass*)ptr;
		};

};

class UPoseWatch : public UObject
{
	public:
	    class UEdGraphNode* Node; // 0x28 Size: 0x8
	    struct FColor PoseWatchColour; // 0x30 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PoseWatch");
			return (class UClass*)ptr;
		};

};

class UPostProcessComponent : public USceneComponent
{
	public:
	    struct FPostProcessSettings Settings; // 0x250 Size: 0x4e0
	    float Priority; // 0x730 Size: 0x4
	    float BlendRadius; // 0x734 Size: 0x4
	    float BlendWeight; // 0x738 Size: 0x4
	    bool bEnabled; // 0x73c Size: 0x1
	    bool bUnbound; // 0x73c Size: 0x1
	    char UnknownData0[0x73e]; // 0x73e
	    void AddOrUpdateBlendable(__int64/*InterfaceProperty*/ InBlendableObject, float InWeight); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-78a1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PostProcessComponent");
			return (class UClass*)ptr;
		};

};

class APostProcessVolume : public AVolume
{
	public:
	    char UnknownData0[0x8];
	    struct FPostProcessSettings Settings; // 0x370 Size: 0x4e0
	    float Priority; // 0x850 Size: 0x4
	    float BlendRadius; // 0x854 Size: 0x4
	    float BlendWeight; // 0x858 Size: 0x4
	    bool bEnabled; // 0x85c Size: 0x1
	    bool bUnbound; // 0x85c Size: 0x1
	    char UnknownData1[0x85e]; // 0x85e
	    void AddOrUpdateBlendable(__int64/*InterfaceProperty*/ InBlendableObject, float InWeight); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7781];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PostProcessVolume");
			return (class UClass*)ptr;
		};

};

class APrecomputedVisibilityOverrideVolume : public AVolume
{
	public:
	    TArray<class AActor*> OverrideVisibleActors; // 0x368 Size: 0x10
	    TArray<class AActor*> OverrideInvisibleActors; // 0x378 Size: 0x10
	    TArray<FName> OverrideInvisibleLevels; // 0x388 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PrecomputedVisibilityOverrideVolume");
			return (class UClass*)ptr;
		};

};

class APrecomputedVisibilityVolume : public AVolume
{
	public:
	    char UnknownData0[0x368];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PrecomputedVisibilityVolume");
			return (class UClass*)ptr;
		};

};

class UPreviewCollectionInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PreviewCollectionInterface");
			return (class UClass*)ptr;
		};

};

class UPreviewMeshCollection : public UDataAsset
{
	public:
	    char UnknownData0[0x8];
	    class USkeleton* Skeleton; // 0x38 Size: 0x8
	    TArray<struct FPreviewMeshCollectionEntry> SkeletalMeshes; // 0x40 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PreviewMeshCollection");
			return (class UClass*)ptr;
		};

};

class UPrimaryAssetLabel : public UPrimaryDataAsset
{
	public:
	    struct FPrimaryAssetRules Rules; // 0x30 Size: 0x10
	    bool bLabelAssetsInMyDirectory; // 0x40 Size: 0x1
	    bool bIsRuntimeLabel; // 0x40 Size: 0x1
	    char UnknownData0[0x6]; // 0x42
	    TArray<struct TSoftObjectPtr<struct UObject*>> ExplicitAssets; // 0x48 Size: 0x10
	    TArray<__int64/*SoftClassProperty*/> ExplicitBlueprints; // 0x58 Size: 0x10
	    struct FCollectionReference AssetCollection; // 0x68 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.PrimaryAssetLabel");
			return (class UClass*)ptr;
		};

};

class UProxyLODMeshSimplificationSettings : public UDeveloperSettings
{
	public:
	    FName ProxyLODMeshReductionModuleName; // 0x38 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ProxyLODMeshSimplificationSettings");
			return (class UClass*)ptr;
		};

};

class ARadialForceActor : public ARigidBodyBase
{
	public:
	    class URadialForceComponent* ForceComponent; // 0x330 Size: 0x8
	    char UnknownData0[0x338]; // 0x338
	    void ToggleForce(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void FireImpulse(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void EnableForce(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void DisableForce(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7ca9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.RadialForceActor");
			return (class UClass*)ptr;
		};

};

class URadialForceComponent : public USceneComponent
{
	public:
	    float Radius; // 0x248 Size: 0x4
	    char Falloff; // 0x24c Size: 0x1
	    char UnknownData0[0x3]; // 0x24d
	    float ImpulseStrength; // 0x250 Size: 0x4
	    bool bImpulseVelChange; // 0x254 Size: 0x1
	    bool bIgnoreOwningActor; // 0x254 Size: 0x1
	    char UnknownData1[0x2]; // 0x256
	    float ForceStrength; // 0x258 Size: 0x4
	    float DestructibleDamage; // 0x25c Size: 0x4
	    TArray<char> ObjectTypesToAffect; // 0x260 Size: 0x10
	    char UnknownData2[0x270]; // 0x270
	    void RemoveObjectTypeToAffect(char ObjectType); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void FireImpulse(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void AddObjectTypeToAffect(char ObjectType); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7d61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.RadialForceComponent");
			return (class UClass*)ptr;
		};

};

class ARectLight : public ALight
{
	public:
	    class URectLightComponent* RectLightComponent; // 0x340 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.RectLight");
			return (class UClass*)ptr;
		};

};

class URectLightComponent : public ULocalLightComponent
{
	public:
	    float SourceWidth; // 0x390 Size: 0x4
	    float SourceHeight; // 0x394 Size: 0x4
	    class UTexture* SourceTexture; // 0x398 Size: 0x8
	    char UnknownData0[0x3a0]; // 0x3a0
	    void SetSourceWidth(float bNewValue); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetSourceHeight(float NewValue); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7c41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.RectLightComponent");
			return (class UClass*)ptr;
		};

};

class URendererSettings : public UDeveloperSettings
{
	public:
	    bool bMobileHDR; // 0x38 Size: 0x1
	    bool bMobileDisableVertexFog; // 0x38 Size: 0x1
	    char UnknownData0[0x2]; // 0x3a
	    int MaxMobileCascades; // 0x3c Size: 0x4
	    char MobileMSAASampleCount; // 0x40 Size: 0x1
	    bool bMobileUseLegacyShadingModel; // 0x44 Size: 0x1
	    bool bMobileAllowDitheredLODTransition; // 0x44 Size: 0x1
	    bool bMobileAllowSoftwareOcclusionCulling; // 0x44 Size: 0x1
	    bool bDiscardUnusedQualityLevels; // 0x44 Size: 0x1
	    bool bOcclusionCulling; // 0x44 Size: 0x1
	    char UnknownData1[0x2]; // 0x46
	    float MinScreenRadiusForLights; // 0x48 Size: 0x4
	    float MinScreenRadiusForEarlyZPass; // 0x4c Size: 0x4
	    float MinScreenRadiusForCSMdepth; // 0x50 Size: 0x4
	    bool bPrecomputedVisibilityWarning; // 0x54 Size: 0x1
	    bool bTextureStreaming; // 0x54 Size: 0x1
	    bool bUseDXT5NormalMaps; // 0x54 Size: 0x1
	    bool bClearCoatEnableSecondNormal; // 0x54 Size: 0x1
	    int ReflectionCaptureResolution; // 0x58 Size: 0x4
	    bool ReflectionEnvironmentLightmapMixBasedOnRoughness; // 0x5c Size: 0x1
	    bool bForwardShading; // 0x5c Size: 0x1
	    bool bVertexFoggingForOpaque; // 0x5c Size: 0x1
	    bool bAllowStaticLighting; // 0x5c Size: 0x1
	    bool bUseNormalMapsForStaticLighting; // 0x5c Size: 0x1
	    bool bGenerateMeshDistanceFields; // 0x5c Size: 0x1
	    bool bEightBitMeshDistanceFields; // 0x5c Size: 0x1
	    bool bGenerateLandscapeGIData; // 0x5c Size: 0x1
	    bool bCompressMeshDistanceFields; // 0x5d Size: 0x1
	    char UnknownData2[0x5]; // 0x65
	    float TessellationAdaptivePixelsPerTriangle; // 0x60 Size: 0x4
	    bool bSeparateTranslucency; // 0x64 Size: 0x1
	    char UnknownData3[0x3]; // 0x65
	    char TranslucentSortPolicy; // 0x68 Size: 0x1
	    char UnknownData4[0x3]; // 0x69
	    struct FVector TranslucentSortAxis; // 0x6c Size: 0xc
	    char CustomDepthStencil; // 0x78 Size: 0x1
	    bool bCustomDepthTaaJitter; // 0x7c Size: 0x1
	    char UnknownData5[0x6]; // 0x7a
	    char bEnableAlphaChannelInPostProcessing; // 0x80 Size: 0x1
	    bool bUseNewAlgorithm; // 0x84 Size: 0x1
	    bool bDefaultFeatureBloom; // 0x84 Size: 0x1
	    bool bDefaultFeatureAmbientOcclusion; // 0x84 Size: 0x1
	    bool bDefaultFeatureAmbientOcclusionStaticFraction; // 0x84 Size: 0x1
	    bool bDefaultFeatureAutoExposure; // 0x84 Size: 0x1
	    char UnknownData6[0x2]; // 0x86
	    char DefaultFeatureAutoExposure; // 0x88 Size: 0x1
	    bool bExtendDefaultLuminanceRangeInAutoExposureSettings; // 0x8c Size: 0x1
	    bool bUsePreExposure; // 0x8c Size: 0x1
	    bool bDefaultFeatureMotionBlur; // 0x8c Size: 0x1
	    bool bDefaultFeatureLensFlare; // 0x8c Size: 0x1
	    bool bTemporalUpsampling; // 0x8c Size: 0x1
	    char UnknownData7[0x2]; // 0x8e
	    char DefaultFeatureAntiAliasing; // 0x90 Size: 0x1
	    ELightUnits DefaultLightUnits; // 0x91 Size: 0x1
	    char DefaultBackBufferPixelFormat; // 0x92 Size: 0x1
	    bool bRenderUnbuiltPreviewShadowsInGame; // 0x94 Size: 0x1
	    bool bStencilForLODDither; // 0x94 Size: 0x1
	    char UnknownData8[0x3]; // 0x95
	    char EarlyZPass; // 0x98 Size: 0x1
	    bool bEarlyZPassMovable; // 0x9c Size: 0x1
	    bool bEarlyZPassOnlyMaterialMasking; // 0x9c Size: 0x1
	    bool bDBuffer; // 0x9c Size: 0x1
	    char UnknownData9[0x4]; // 0x9c
	    char ClearSceneMethod; // 0xa0 Size: 0x1
	    bool bBasePassOutputsVelocity; // 0xa4 Size: 0x1
	    bool bSelectiveBasePassOutputs; // 0xa4 Size: 0x1
	    bool bDefaultParticleCutouts; // 0xa4 Size: 0x1
	    char UnknownData10[0x4]; // 0xa4
	    int GPUSimulationTextureSizeX; // 0xa8 Size: 0x4
	    int GPUSimulationTextureSizeY; // 0xac Size: 0x4
	    bool bGlobalClipPlane; // 0xb0 Size: 0x1
	    char UnknownData11[0x3]; // 0xb1
	    char GBufferFormat; // 0xb4 Size: 0x1
	    bool bUseGPUMorphTargets; // 0xb8 Size: 0x1
	    bool bNvidiaAftermathEnabled; // 0xb8 Size: 0x1
	    bool bInstancedStereo; // 0xb8 Size: 0x1
	    bool bMultiView; // 0xb8 Size: 0x1
	    bool bMobileMultiView; // 0xb8 Size: 0x1
	    bool bMobileMultiViewDirect; // 0xb8 Size: 0x1
	    bool bMonoscopicFarField; // 0xb8 Size: 0x1
	    bool bRoundRobinOcclusion; // 0xb8 Size: 0x1
	    bool bODSCapture; // 0xb9 Size: 0x1
	    char UnknownData12[0x2]; // 0xbe
	    float WireframeCullThreshold; // 0xbc Size: 0x4
	    bool bSupportStationarySkylight; // 0xc0 Size: 0x1
	    bool bSupportLowQualityLightmaps; // 0xc0 Size: 0x1
	    bool bSupportPointLightWholeSceneShadows; // 0xc0 Size: 0x1
	    bool bSupportAtmosphericFog; // 0xc0 Size: 0x1
	    bool bSupportSkinCacheShaders; // 0xc0 Size: 0x1
	    bool bMobileEnableStaticAndCSMShadowReceivers; // 0xc0 Size: 0x1
	    bool bMobileEnableMovableLightCSMShaderCulling; // 0xc0 Size: 0x1
	    bool bMobileAllowDistanceFieldShadows; // 0xc0 Size: 0x1
	    bool bMobileAllowMovableDirectionalLights; // 0xc1 Size: 0x1
	    char UnknownData13[0x5]; // 0xc9
	    uint32_t MobileNumDynamicPointLights; // 0xc4 Size: 0x4
	    bool bMobileDynamicPointLightsUseStaticBranch; // 0xc8 Size: 0x1
	    char UnknownData14[0x3]; // 0xc9
	    float SkinCacheSceneMemoryLimitInMB; // 0xcc Size: 0x4
	    bool bGPUSkinLimit2BoneInfluences; // 0xd0 Size: 0x1
	    bool bSupportDepthOnlyIndexBuffers; // 0xd0 Size: 0x1
	    bool bSupportReversedIndexBuffers; // 0xd0 Size: 0x1
	    bool bSupportMaterialLayers; // 0xd0 Size: 0x1
	    char UnknownData15[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.RendererSettings");
			return (class UClass*)ptr;
		};

};

class URendererOverrideSettings : public UDeveloperSettings
{
	public:
	    bool bSupportAllShaderPermutations; // 0x38 Size: 0x1
	    bool bForceRecomputeTangents; // 0x38 Size: 0x1
	    char UnknownData0[0x6];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.RendererOverrideSettings");
			return (class UClass*)ptr;
		};

};

class UReporterBase : public UObject
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ReporterBase");
			return (class UClass*)ptr;
		};

};

class UReporterGraph : public UReporterBase
{
	public:
	    char UnknownData0[0xa8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ReporterGraph");
			return (class UClass*)ptr;
		};

};

class UReverbEffect : public UObject
{
	public:
	    float Density; // 0x28 Size: 0x4
	    float Diffusion; // 0x2c Size: 0x4
	    float Gain; // 0x30 Size: 0x4
	    float GainHF; // 0x34 Size: 0x4
	    float DecayTime; // 0x38 Size: 0x4
	    float DecayHFRatio; // 0x3c Size: 0x4
	    float ReflectionsGain; // 0x40 Size: 0x4
	    float ReflectionsDelay; // 0x44 Size: 0x4
	    float LateGain; // 0x48 Size: 0x4
	    float LateDelay; // 0x4c Size: 0x4
	    float AirAbsorptionGainHF; // 0x50 Size: 0x4
	    float RoomRolloffFactor; // 0x54 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ReverbEffect");
			return (class UClass*)ptr;
		};

};

class URig : public UObject
{
	public:
	    char UnknownData0[0x8];
	    TArray<struct FTransformBase> TransformBases; // 0x30 Size: 0x10
	    TArray<struct FNode> Nodes; // 0x40 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Rig");
			return (class UClass*)ptr;
		};

};

class URotatingMovementComponent : public UMovementComponent
{
	public:
	    struct FRotator RotationRate; // 0x138 Size: 0xc
	    struct FVector PivotTranslation; // 0x144 Size: 0xc
	    bool bRotationInLocalSpace; // 0x150 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.RotatingMovementComponent");
			return (class UClass*)ptr;
		};

};

class URVOAvoidanceInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.RVOAvoidanceInterface");
			return (class UClass*)ptr;
		};

};

class USaveGame : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SaveGame");
			return (class UClass*)ptr;
		};

};

class UScene : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Scene");
			return (class UClass*)ptr;
		};

};

class ASceneCapture2D : public ASceneCapture
{
	public:
	    class USceneCaptureComponent2D* CaptureComponent2D; // 0x338 Size: 0x8
	    char UnknownData0[0x340]; // 0x340
	    void OnInterpToggle(bool bEnable); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7ca1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SceneCapture2D");
			return (class UClass*)ptr;
		};

};

class USceneCaptureComponent2D : public USceneCaptureComponent
{
	public:
	    char ProjectionType; // 0x2e0 Size: 0x1
	    char UnknownData0[0x3]; // 0x2e1
	    float FOVAngle; // 0x2e4 Size: 0x4
	    float OrthoWidth; // 0x2e8 Size: 0x4
	    char UnknownData1[0x4]; // 0x2ec
	    class UTextureRenderTarget2D* TextureTarget; // 0x2f0 Size: 0x8
	    char CaptureSource; // 0x2f8 Size: 0x1
	    char CompositeMode; // 0x2f9 Size: 0x1
	    char UnknownData2[0x6]; // 0x2fa
	    struct FPostProcessSettings PostProcessSettings; // 0x300 Size: 0x4e0
	    float PostProcessBlendWeight; // 0x7e0 Size: 0x4
	    bool bUseCustomProjectionMatrix; // 0x7e4 Size: 0x1
	    char UnknownData3[0xb]; // 0x7e5
	    struct FMatrix CustomProjectionMatrix; // 0x7f0 Size: 0x40
	    bool bEnableClipPlane; // 0x830 Size: 0x1
	    char UnknownData4[0x3]; // 0x831
	    struct FVector ClipPlaneBase; // 0x834 Size: 0xc
	    struct FVector ClipPlaneNormal; // 0x840 Size: 0xc
	    bool bCameraCutThisFrame; // 0x84c Size: 0x1
	    char UnknownData5[0x84d]; // 0x84d
	    void CaptureScene(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void AddOrUpdateBlendable(__int64/*InterfaceProperty*/ InBlendableObject, float InWeight); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x-7791];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SceneCaptureComponent2D");
			return (class UClass*)ptr;
		};

};

class USceneCaptureComponentCube : public USceneCaptureComponent
{
	public:
	    class UTextureRenderTargetCube* TextureTarget; // 0x2e0 Size: 0x8
	    class UTextureRenderTargetCube* TextureTargetLeft; // 0x2e8 Size: 0x8
	    class UTextureRenderTargetCube* TextureTargetRight; // 0x2f0 Size: 0x8
	    class UTextureRenderTarget2D* TextureTargetODS; // 0x2f8 Size: 0x8
	    float IPD; // 0x300 Size: 0x4
	    char UnknownData0[0x304]; // 0x304
	    void CaptureScene(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7cd1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SceneCaptureComponentCube");
			return (class UClass*)ptr;
		};

};

class ASceneCaptureCube : public ASceneCapture
{
	public:
	    class USceneCaptureComponentCube* CaptureComponentCube; // 0x338 Size: 0x8
	    char UnknownData0[0x340]; // 0x340
	    void OnInterpToggle(bool bEnable); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7ca1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SceneCaptureCube");
			return (class UClass*)ptr;
		};

};

class USCS_Node : public UObject
{
	public:
	    class UObject* ComponentClass; // 0x28 Size: 0x8
	    class UActorComponent* ComponentTemplate; // 0x30 Size: 0x8
	    struct FBlueprintCookedComponentInstancingData CookedComponentInstancingData; // 0x38 Size: 0x50
	    FName AttachToName; // 0x88 Size: 0x8
	    FName ParentComponentOrVariableName; // 0x90 Size: 0x8
	    FName ParentComponentOwnerClassName; // 0x98 Size: 0x8
	    bool bIsParentComponentNative; // 0xa0 Size: 0x1
	    char UnknownData0[0x7]; // 0xa1
	    TArray<class USCS_Node*> ChildNodes; // 0xa8 Size: 0x10
	    TArray<struct FBPVariableMetaDataEntry> MetaDataArray; // 0xb8 Size: 0x10
	    struct FGuid VariableGuid; // 0xc8 Size: 0x10
	    FName InternalVariableName; // 0xd8 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SCS_Node");
			return (class UClass*)ptr;
		};

};

class USelection : public UObject
{
	public:
	    char UnknownData0[0xa0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Selection");
			return (class UClass*)ptr;
		};

};

class AServerStatReplicator : public AInfo
{
	public:
	    bool bUpdateStatNet; // 0x330 Size: 0x1
	    bool bOverwriteClientStats; // 0x331 Size: 0x1
	    char UnknownData0[0x2]; // 0x332
	    uint32_t Channels; // 0x334 Size: 0x4
	    uint32_t InRate; // 0x338 Size: 0x4
	    uint32_t OutRate; // 0x33c Size: 0x4
	    uint32_t OutSaturation; // 0x340 Size: 0x4
	    uint32_t MaxPacketOverhead; // 0x344 Size: 0x4
	    uint32_t InRateClientMax; // 0x348 Size: 0x4
	    uint32_t InRateClientMin; // 0x34c Size: 0x4
	    uint32_t InRateClientAvg; // 0x350 Size: 0x4
	    uint32_t InPacketsClientMax; // 0x354 Size: 0x4
	    uint32_t InPacketsClientMin; // 0x358 Size: 0x4
	    uint32_t InPacketsClientAvg; // 0x35c Size: 0x4
	    uint32_t OutRateClientMax; // 0x360 Size: 0x4
	    uint32_t OutRateClientMin; // 0x364 Size: 0x4
	    uint32_t OutRateClientAvg; // 0x368 Size: 0x4
	    uint32_t OutPacketsClientMax; // 0x36c Size: 0x4
	    uint32_t OutPacketsClientMin; // 0x370 Size: 0x4
	    uint32_t OutPacketsClientAvg; // 0x374 Size: 0x4
	    uint32_t NetNumClients; // 0x378 Size: 0x4
	    uint32_t InPackets; // 0x37c Size: 0x4
	    uint32_t OutPackets; // 0x380 Size: 0x4
	    uint32_t InBunches; // 0x384 Size: 0x4
	    uint32_t OutBunches; // 0x388 Size: 0x4
	    uint32_t OutLoss; // 0x38c Size: 0x4
	    uint32_t InLoss; // 0x390 Size: 0x4
	    uint32_t VoiceBytesSent; // 0x394 Size: 0x4
	    uint32_t VoiceBytesRecv; // 0x398 Size: 0x4
	    uint32_t VoicePacketsSent; // 0x39c Size: 0x4
	    uint32_t VoicePacketsRecv; // 0x3a0 Size: 0x4
	    uint32_t PercentInVoice; // 0x3a4 Size: 0x4
	    uint32_t PercentOutVoice; // 0x3a8 Size: 0x4
	    uint32_t NumActorChannels; // 0x3ac Size: 0x4
	    uint32_t NumConsideredActors; // 0x3b0 Size: 0x4
	    uint32_t PrioritizedActors; // 0x3b4 Size: 0x4
	    uint32_t NumRelevantActors; // 0x3b8 Size: 0x4
	    uint32_t NumRelevantDeletedActors; // 0x3bc Size: 0x4
	    uint32_t NumReplicatedActorAttempts; // 0x3c0 Size: 0x4
	    uint32_t NumReplicatedActors; // 0x3c4 Size: 0x4
	    uint32_t NumActors; // 0x3c8 Size: 0x4
	    uint32_t NumNetActors; // 0x3cc Size: 0x4
	    uint32_t NumDormantActors; // 0x3d0 Size: 0x4
	    uint32_t NumInitiallyDormantActors; // 0x3d4 Size: 0x4
	    uint32_t NumNetGUIDsAckd; // 0x3d8 Size: 0x4
	    uint32_t NumNetGUIDsPending; // 0x3dc Size: 0x4
	    uint32_t NumNetGUIDsUnAckd; // 0x3e0 Size: 0x4
	    uint32_t ObjPathBytes; // 0x3e4 Size: 0x4
	    uint32_t NetGUIDOutRate; // 0x3e8 Size: 0x4
	    uint32_t NetGUIDInRate; // 0x3ec Size: 0x4
	    uint32_t NetSaturated; // 0x3f0 Size: 0x4
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ServerStatReplicator");
			return (class UClass*)ptr;
		};

};

class UShadowMapTexture2D : public UTexture2D
{
	public:
	    char ShadowmapFlags; // 0xf0 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ShadowMapTexture2D");
			return (class UClass*)ptr;
		};

};

class USimpleConstructionScript : public UObject
{
	public:
	    TArray<class USCS_Node*> RootNodes; // 0x28 Size: 0x10
	    TArray<class USCS_Node*> AllNodes; // 0x38 Size: 0x10
	    class USCS_Node* DefaultSceneRootNode; // 0x48 Size: 0x8
	    char UnknownData0[0x50];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SimpleConstructionScript");
			return (class UClass*)ptr;
		};

};

class USkeletalMesh : public UObject
{
	public:
	    char UnknownData0[0x20];
	    class USkeleton* Skeleton; // 0x48 Size: 0x8
	    struct FBoxSphereBounds ImportedBounds; // 0x50 Size: 0x1c
	    struct FBoxSphereBounds ExtendedBounds; // 0x6c Size: 0x1c
	    struct FVector PositiveBoundsExtension; // 0x88 Size: 0xc
	    struct FVector NegativeBoundsExtension; // 0x94 Size: 0xc
	    TArray<struct FSkeletalMaterial> Materials; // 0xa0 Size: 0x10
	    TArray<struct FBoneMirrorInfo> SkelMirrorTable; // 0xb0 Size: 0x10
	    TArray<struct FSkeletalMeshLODInfo> LODInfo; // 0xc0 Size: 0x10
	    char UnknownData1[0x50]; // 0xd0
	    struct FPerPlatformInt MinLOD; // 0x120 Size: 0x4
	    char SkelMirrorAxis; // 0x124 Size: 0x1
	    char SkelMirrorFlipAxis; // 0x125 Size: 0x1
	    bool bUseFullPrecisionUVs; // 0x126 Size: 0x1
	    bool bUseHighPrecisionTangentBasis; // 0x126 Size: 0x1
	    bool bHasBeenSimplified; // 0x126 Size: 0x1
	    bool bHasVertexColors; // 0x126 Size: 0x1
	    bool bEnablePerPolyCollision; // 0x126 Size: 0x1
	    char UnknownData2[0x3]; // 0x12b
	    class UBodySetup* BodySetup; // 0x128 Size: 0x8
	    class UPhysicsAsset* PhysicsAsset; // 0x130 Size: 0x8
	    class UPhysicsAsset* ShadowPhysicsAsset; // 0x138 Size: 0x8
	    TArray<class UNodeMappingContainer*> NodeMappingData; // 0x140 Size: 0x10
	    TArray<class UMorphTarget*> MorphTargets; // 0x150 Size: 0x10
	    char UnknownData3[0x178]; // 0x160
	    class UAnimInstance* PostProcessAnimBlueprint; // 0x2d8 Size: 0x8
	    TArray<class UClothingAssetBase*> MeshClothingAssets; // 0x2e0 Size: 0x10
	    struct FSkeletalMeshSamplingInfo SamplingInfo; // 0x2f0 Size: 0x30
	    TArray<class UAssetUserData*> AssetUserData; // 0x320 Size: 0x10
	    TArray<class USkeletalMeshSocket*> Sockets; // 0x330 Size: 0x10
	    char UnknownData4[0x340]; // 0x340
	    void SetLODSettings(class USkeletalMeshLODSettings* InLODSettings); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    int NumSockets(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool IsSectionUsingCloth(int InSectionIndex, bool bCheckCorrespondingSections); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    class USkeletalMeshSocket* GetSocketByIndex(int Index); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    class UNodeMappingContainer* GetNodeMappingContainer(class UBlueprint* SourceAsset); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    struct FBoxSphereBounds GetImportedBounds(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    struct FBoxSphereBounds GetBounds(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    class USkeletalMeshSocket* FindSocketInfo(FName InSocketName, struct FTransform OutTransform, int OutBoneIndex, int OutIndex); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    class USkeletalMeshSocket* FindSocketAndIndex(FName InSocketName, int OutIndex); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    class USkeletalMeshSocket* FindSocket(FName InSocketName); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x-7c91];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SkeletalMesh");
			return (class UClass*)ptr;
		};

};

class USkeletalMeshLODSettings : public UDataAsset
{
	public:
	    struct FPerPlatformInt MinLOD; // 0x30 Size: 0x4
	    char UnknownData0[0x4]; // 0x34
	    TArray<struct FSkeletalMeshLODGroupSettings> LODGroups; // 0x38 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SkeletalMeshLODSettings");
			return (class UClass*)ptr;
		};

};

class USkeletalMeshSimplificationSettings : public UDeveloperSettings
{
	public:
	    FName SkeletalMeshReductionModuleName; // 0x38 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SkeletalMeshSimplificationSettings");
			return (class UClass*)ptr;
		};

};

class USkeletalMeshSocket : public UObject
{
	public:
	    FName SocketName; // 0x28 Size: 0x8
	    FName BoneName; // 0x30 Size: 0x8
	    struct FVector RelativeLocation; // 0x38 Size: 0xc
	    struct FRotator RelativeRotation; // 0x44 Size: 0xc
	    struct FVector RelativeScale; // 0x50 Size: 0xc
	    bool bForceAlwaysAnimated; // 0x5c Size: 0x1
	    char UnknownData0[0x5d]; // 0x5d
	    void InitializeSocketFromLocation(class USkeletalMeshComponent* SkelComp, struct FVector WorldLocation, struct FVector WorldNormal); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    struct FVector GetSocketLocation(class USkeletalMeshComponent* SkelComp); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SkeletalMeshSocket");
			return (class UClass*)ptr;
		};

};

class ASkyLight : public AInfo
{
	public:
	    class USkyLightComponent* LightComponent; // 0x330 Size: 0x8
	    bool bEnabled; // 0x338 Size: 0x1
	    char UnknownData0[0x339]; // 0x339
	    void OnRep_bEnabled(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7ca1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SkyLight");
			return (class UClass*)ptr;
		};

};

class USkyLightComponent : public ULightComponentBase
{
	public:
	    char SourceType; // 0x270 Size: 0x1
	    char UnknownData0[0x7]; // 0x271
	    class UTextureCube* Cubemap; // 0x278 Size: 0x8
	    float SourceCubemapAngle; // 0x280 Size: 0x4
	    int CubemapResolution; // 0x284 Size: 0x4
	    float SkyDistanceThreshold; // 0x288 Size: 0x4
	    bool bCaptureEmissiveOnly; // 0x28c Size: 0x1
	    bool bLowerHemisphereIsBlack; // 0x28d Size: 0x1
	    char UnknownData1[0x2]; // 0x28e
	    struct FLinearColor LowerHemisphereColor; // 0x290 Size: 0x10
	    float OcclusionMaxDistance; // 0x2a0 Size: 0x4
	    float Contrast; // 0x2a4 Size: 0x4
	    float OcclusionExponent; // 0x2a8 Size: 0x4
	    float MinOcclusion; // 0x2ac Size: 0x4
	    struct FColor OcclusionTint; // 0x2b0 Size: 0x4
	    char OcclusionCombineMode; // 0x2b4 Size: 0x1
	    char UnknownData2[0xa3]; // 0x2b5
	    class UTextureCube* BlendDestinationCubemap; // 0x358 Size: 0x8
	    char UnknownData3[0x360]; // 0x360
	    void SetVolumetricScatteringIntensity(float NewIntensity); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetOcclusionTint(struct FColor InTint); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetOcclusionExponent(float InOcclusionExponent); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetOcclusionContrast(float InOcclusionContrast); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetMinOcclusion(float InMinOcclusion); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetLowerHemisphereColor(struct FLinearColor InLowerHemisphereColor); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetLightColor(struct FLinearColor NewLightColor); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetIntensity(float NewIntensity); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetIndirectLightingIntensity(float NewIntensity); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetCubemapBlend(class UTextureCube* SourceCubemap, class UTextureCube* DestinationCubemap, float InBlendFraction); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void SetCubemap(class UTextureCube* NewCubemap); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void RecaptureSky(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x-7bb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SkyLightComponent");
			return (class UClass*)ptr;
		};

};

class USlateBrushAsset : public UObject
{
	public:
	    struct FSlateBrush Brush; // 0x28 Size: 0x88

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SlateBrushAsset");
			return (class UClass*)ptr;
		};

};

class USlateTextureAtlasInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SlateTextureAtlasInterface");
			return (class UClass*)ptr;
		};

};

class USmokeTestCommandlet : public UCommandlet
{
	public:
	    char UnknownData0[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SmokeTestCommandlet");
			return (class UClass*)ptr;
		};

};

class USoundAttenuation : public UObject
{
	public:
	    struct FSoundAttenuationSettings Attenuation; // 0x28 Size: 0x2e8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundAttenuation");
			return (class UClass*)ptr;
		};

};

class USoundClass : public UObject
{
	public:
	    struct FSoundClassProperties Properties; // 0x28 Size: 0x2c
	    char UnknownData0[0x4]; // 0x54
	    TArray<class USoundClass*> ChildClasses; // 0x58 Size: 0x10
	    TArray<struct FPassiveSoundMixModifier> PassiveSoundMixModifiers; // 0x68 Size: 0x10
	    class USoundClass* ParentClass; // 0x78 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundClass");
			return (class UClass*)ptr;
		};

};

class USoundConcurrency : public UObject
{
	public:
	    struct FSoundConcurrencySettings Concurrency; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundConcurrency");
			return (class UClass*)ptr;
		};

};

class USoundCue : public USoundBase
{
	public:
	    bool bOverrideAttenuation; // 0xa8 Size: 0x1
	    bool bExcludeFromRandomNodeBranchCulling; // 0xa8 Size: 0x1
	    char UnknownData0[0x6]; // 0xaa
	    class USoundNode* FirstNode; // 0xb0 Size: 0x8
	    float VolumeMultiplier; // 0xb8 Size: 0x4
	    float PitchMultiplier; // 0xbc Size: 0x4
	    struct FSoundAttenuationSettings AttenuationOverrides; // 0xc0 Size: 0x2e8
	    float SubtitlePriority; // 0x3a8 Size: 0x4
	    char UnknownData1[0x14];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundCue");
			return (class UClass*)ptr;
		};

};

class USoundEffectSourcePreset : public USoundEffectPreset
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundEffectSourcePreset");
			return (class UClass*)ptr;
		};

};

class USoundEffectSourcePresetChain : public UObject
{
	public:
	    TArray<struct FSourceEffectChainEntry> Chain; // 0x28 Size: 0x10
	    bool bPlayEffectChainTails; // 0x38 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundEffectSourcePresetChain");
			return (class UClass*)ptr;
		};

};

class USoundGroups : public UObject
{
	public:
	    TArray<struct FSoundGroup> SoundGroupProfiles; // 0x28 Size: 0x10
	    char UnknownData0[0x50];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundGroups");
			return (class UClass*)ptr;
		};

};

class USoundMix : public UObject
{
	public:
	    bool bApplyEQ; // 0x28 Size: 0x1
	    char UnknownData0[0x3]; // 0x29
	    float EQPriority; // 0x2c Size: 0x4
	    struct FAudioEQEffect EQSettings; // 0x30 Size: 0x38
	    TArray<struct FSoundClassAdjuster> SoundClassEffects; // 0x68 Size: 0x10
	    float InitialDelay; // 0x78 Size: 0x4
	    float FadeInTime; // 0x7c Size: 0x4
	    float Duration; // 0x80 Size: 0x4
	    float FadeOutTime; // 0x84 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundMix");
			return (class UClass*)ptr;
		};

};

class USoundNode : public UObject
{
	public:
	    TArray<class USoundNode*> ChildNodes; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNode");
			return (class UClass*)ptr;
		};

};

class USoundNodeAssetReferencer : public USoundNode
{
	public:
	    char UnknownData0[0x38];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNodeAssetReferencer");
			return (class UClass*)ptr;
		};

};

class USoundNodeAttenuation : public USoundNode
{
	public:
	    class USoundAttenuation* AttenuationSettings; // 0x38 Size: 0x8
	    struct FSoundAttenuationSettings AttenuationOverrides; // 0x40 Size: 0x2e8
	    bool bOverrideAttenuation; // 0x328 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNodeAttenuation");
			return (class UClass*)ptr;
		};

};

class USoundNodeBranch : public USoundNode
{
	public:
	    FName BoolParameterName; // 0x38 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNodeBranch");
			return (class UClass*)ptr;
		};

};

class USoundNodeConcatenator : public USoundNode
{
	public:
	    TArray<float> InputVolume; // 0x38 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNodeConcatenator");
			return (class UClass*)ptr;
		};

};

class USoundNodeDelay : public USoundNode
{
	public:
	    float DelayMin; // 0x38 Size: 0x4
	    float DelayMax; // 0x3c Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNodeDelay");
			return (class UClass*)ptr;
		};

};

class USoundNodeDialoguePlayer : public USoundNode
{
	public:
	    struct FDialogueWaveParameter DialogueWaveParameter; // 0x38 Size: 0x20
	    bool bLooping; // 0x58 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNodeDialoguePlayer");
			return (class UClass*)ptr;
		};

};

class USoundNodeDistanceCrossFade : public USoundNode
{
	public:
	    TArray<struct FDistanceDatum> CrossFadeInput; // 0x38 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNodeDistanceCrossFade");
			return (class UClass*)ptr;
		};

};

class USoundNodeDoppler : public USoundNode
{
	public:
	    float DopplerIntensity; // 0x38 Size: 0x4
	    bool bUseSmoothing; // 0x3c Size: 0x1
	    char UnknownData0[0x3]; // 0x3d
	    float SmoothingInterpSpeed; // 0x40 Size: 0x4
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNodeDoppler");
			return (class UClass*)ptr;
		};

};

class USoundNodeEnveloper : public USoundNode
{
	public:
	    float LoopStart; // 0x38 Size: 0x4
	    float LoopEnd; // 0x3c Size: 0x4
	    float DurationAfterLoop; // 0x40 Size: 0x4
	    int LoopCount; // 0x44 Size: 0x4
	    bool bLoopIndefinitely; // 0x48 Size: 0x1
	    bool bLoop; // 0x48 Size: 0x1
	    char UnknownData0[0x6]; // 0x4a
	    class UDistributionFloatConstantCurve* VolumeInterpCurve; // 0x50 Size: 0x8
	    class UDistributionFloatConstantCurve* PitchInterpCurve; // 0x58 Size: 0x8
	    struct FRuntimeFloatCurve VolumeCurve; // 0x60 Size: 0x88
	    struct FRuntimeFloatCurve PitchCurve; // 0xe8 Size: 0x88
	    float PitchMin; // 0x170 Size: 0x4
	    float PitchMax; // 0x174 Size: 0x4
	    float VolumeMin; // 0x178 Size: 0x4
	    float VolumeMax; // 0x17c Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNodeEnveloper");
			return (class UClass*)ptr;
		};

};

class USoundNodeGroupControl : public USoundNode
{
	public:
	    TArray<int> GroupSizes; // 0x38 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNodeGroupControl");
			return (class UClass*)ptr;
		};

};

class USoundNodeLooping : public USoundNode
{
	public:
	    int LoopCount; // 0x38 Size: 0x4
	    bool bLoopIndefinitely; // 0x3c Size: 0x1
	    char UnknownData0[0x3];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNodeLooping");
			return (class UClass*)ptr;
		};

};

class USoundNodeMature : public USoundNode
{
	public:
	    char UnknownData0[0x38];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNodeMature");
			return (class UClass*)ptr;
		};

};

class USoundNodeMixer : public USoundNode
{
	public:
	    TArray<float> InputVolume; // 0x38 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNodeMixer");
			return (class UClass*)ptr;
		};

};

class USoundNodeModulator : public USoundNode
{
	public:
	    float PitchMin; // 0x38 Size: 0x4
	    float PitchMax; // 0x3c Size: 0x4
	    float VolumeMin; // 0x40 Size: 0x4
	    float VolumeMax; // 0x44 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNodeModulator");
			return (class UClass*)ptr;
		};

};

class USoundNodeModulatorContinuous : public USoundNode
{
	public:
	    struct FModulatorContinuousParams PitchModulationParams; // 0x38 Size: 0x20
	    struct FModulatorContinuousParams VolumeModulationParams; // 0x58 Size: 0x20

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNodeModulatorContinuous");
			return (class UClass*)ptr;
		};

};

class USoundNodeOscillator : public USoundNode
{
	public:
	    bool bModulateVolume; // 0x38 Size: 0x1
	    bool bModulatePitch; // 0x38 Size: 0x1
	    char UnknownData0[0x2]; // 0x3a
	    float AmplitudeMin; // 0x3c Size: 0x4
	    float AmplitudeMax; // 0x40 Size: 0x4
	    float FrequencyMin; // 0x44 Size: 0x4
	    float FrequencyMax; // 0x48 Size: 0x4
	    float OffsetMin; // 0x4c Size: 0x4
	    float OffsetMax; // 0x50 Size: 0x4
	    float CenterMin; // 0x54 Size: 0x4
	    float CenterMax; // 0x58 Size: 0x4
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNodeOscillator");
			return (class UClass*)ptr;
		};

};

class USoundNodeParamCrossFade : public USoundNodeDistanceCrossFade
{
	public:
	    FName ParamName; // 0x48 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNodeParamCrossFade");
			return (class UClass*)ptr;
		};

};

class USoundNodeQualityLevel : public USoundNode
{
	public:
	    char UnknownData0[0x38];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNodeQualityLevel");
			return (class UClass*)ptr;
		};

};

class USoundNodeRandom : public USoundNode
{
	public:
	    TArray<float> Weights; // 0x38 Size: 0x10
	    int PreselectAtLevelLoad; // 0x48 Size: 0x4
	    bool bShouldExcludeFromBranchCulling; // 0x4c Size: 0x1
	    bool bSoundCueExcludedFromBranchCulling; // 0x4c Size: 0x1
	    bool bRandomizeWithoutReplacement; // 0x50 Size: 0x1
	    char UnknownData0[0x9]; // 0x4f
	    TArray<bool> HasBeenUsed; // 0x58 Size: 0x10
	    int NumRandomUsed; // 0x68 Size: 0x4
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNodeRandom");
			return (class UClass*)ptr;
		};

};

class USoundNodeSoundClass : public USoundNode
{
	public:
	    class USoundClass* SoundClassOverride; // 0x38 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNodeSoundClass");
			return (class UClass*)ptr;
		};

};

class USoundNodeSwitch : public USoundNode
{
	public:
	    FName IntParameterName; // 0x38 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNodeSwitch");
			return (class UClass*)ptr;
		};

};

class USoundNodeWaveParam : public USoundNode
{
	public:
	    FName WaveParameterName; // 0x38 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNodeWaveParam");
			return (class UClass*)ptr;
		};

};

class USoundNodeWavePlayer : public USoundNodeAssetReferencer
{
	public:
	    struct TSoftObjectPtr<struct USoundWave*> SoundWaveAssetPtr; // 0x38 Size: 0x28
	    class USoundWave* SoundWave; // 0x60 Size: 0x8
	    bool bLooping; // 0x68 Size: 0x1
	    char UnknownData0[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundNodeWavePlayer");
			return (class UClass*)ptr;
		};

};

class USoundSourceBus : public USoundWave
{
	public:
	    ESourceBusChannels SourceBusChannels; // 0x208 Size: 0x1
	    char UnknownData0[0x3]; // 0x209
	    float SourceBusDuration; // 0x20c Size: 0x4
	    bool bAutoDeactivateWhenSilent; // 0x210 Size: 0x1
	    char UnknownData1[0xf];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundSourceBus");
			return (class UClass*)ptr;
		};

};

class USoundSubmix : public UObject
{
	public:
	    TArray<class USoundSubmix*> ChildSubmixes; // 0x28 Size: 0x10
	    class USoundSubmix* ParentSubmix; // 0x38 Size: 0x8
	    ESubmixChannelFormat ChannelFormat; // 0x40 Size: 0x1
	    char UnknownData0[0x7]; // 0x41
	    TArray<class USoundEffectSubmixPreset*> SubmixEffectChain; // 0x48 Size: 0x10
	    class UAmbisonicsSubmixSettingsBase* AmbisonicsPluginSettings; // 0x58 Size: 0x8
	    int EnvelopeFollowerAttackTime; // 0x60 Size: 0x4
	    int EnvelopeFollowerReleaseTime; // 0x64 Size: 0x4
	    MulticastDelegateProperty OnSubmixRecordedFileDone; // 0x68 Size: 0x10
	    char UnknownData1[0x78]; // 0x78
	    void StopRecordingOutput(class UObject* WorldContextObject, EAudioRecordingExportType ExportType, struct FString Name, struct FString Path, class USoundWave* ExistingSoundWaveToOverwrite); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void StopEnvelopeFollowing(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void StartRecordingOutput(class UObject* WorldContextObject, float ExpectedDuration); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void StartEnvelopeFollowing(class UObject* WorldContextObject); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void AddEnvelopeFollowerDelegate(class UObject* WorldContextObject, __int64/*DelegateProperty*/ OnSubmixEnvelopeBP); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7f61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SoundSubmix");
			return (class UClass*)ptr;
		};

};

class ASphereReflectionCapture : public AReflectionCapture
{
	public:
	    class UDrawSphereComponent* DrawCaptureRadius; // 0x338 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SphereReflectionCapture");
			return (class UClass*)ptr;
		};

};

class USphereReflectionCaptureComponent : public UReflectionCaptureComponent
{
	public:
	    float InfluenceRadius; // 0x2c0 Size: 0x4
	    float CaptureDistanceScale; // 0x2c4 Size: 0x4
	    class UDrawSphereComponent* PreviewInfluenceRadius; // 0x2c8 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SphereReflectionCaptureComponent");
			return (class UClass*)ptr;
		};

};

class ASplineMeshActor : public AActor
{
	public:
	    class USplineMeshComponent* SplineMeshComponent; // 0x330 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SplineMeshActor");
			return (class UClass*)ptr;
		};

};

class USplineMeshComponent : public UStaticMeshComponent
{
	public:
	    struct FSplineMeshParams SplineParams; // 0x610 Size: 0x58
	    struct FVector SplineUpDir; // 0x668 Size: 0xc
	    bool bAllowSplineEditingPerInstance; // 0x674 Size: 0x1
	    bool bSmoothInterpRollScale; // 0x674 Size: 0x1
	    char UnknownData0[0x2]; // 0x676
	    char ForwardAxis; // 0x678 Size: 0x1
	    char UnknownData1[0x3]; // 0x679
	    float SplineBoundaryMin; // 0x67c Size: 0x4
	    float SplineBoundaryMax; // 0x680 Size: 0x4
	    char UnknownData2[0x4]; // 0x684
	    class UBodySetup* BodySetup; // 0x688 Size: 0x8
	    struct FGuid CachedMeshBodySetupGuid; // 0x690 Size: 0x10
	    bool bMeshDirty; // 0x6a0 Size: 0x1
	    char UnknownData3[0x6a1]; // 0x6a1
	    void UpdateMesh(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetStartTangent(struct FVector StartTangent, bool bUpdateMesh); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetStartScale(struct FVector2D StartScale, bool bUpdateMesh); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetStartRoll(float StartRoll, bool bUpdateMesh); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetStartPosition(struct FVector StartPos, bool bUpdateMesh); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetStartOffset(struct FVector2D StartOffset, bool bUpdateMesh); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetStartAndEnd(struct FVector StartPos, struct FVector StartTangent, struct FVector EndPos, struct FVector EndTangent, bool bUpdateMesh); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetSplineUpDir(struct FVector InSplineUpDir, bool bUpdateMesh); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetForwardAxis(char InForwardAxis, bool bUpdateMesh); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetEndTangent(struct FVector EndTangent, bool bUpdateMesh); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void SetEndScale(struct FVector2D EndScale, bool bUpdateMesh); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void SetEndRoll(float EndRoll, bool bUpdateMesh); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void SetEndPosition(struct FVector EndPos, bool bUpdateMesh); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void SetEndOffset(struct FVector2D EndOffset, bool bUpdateMesh); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void SetBoundaryMin(float InBoundaryMin, bool bUpdateMesh); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void SetBoundaryMax(float InBoundaryMax, bool bUpdateMesh); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    struct FVector GetStartTangent(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    struct FVector2D GetStartScale(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    float GetStartRoll(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    struct FVector GetStartPosition(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    struct FVector2D GetStartOffset(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    struct FVector GetSplineUpDir(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    char GetForwardAxis(); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    struct FVector GetEndTangent(); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    struct FVector2D GetEndScale(); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    float GetEndRoll(); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    struct FVector GetEndPosition(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    struct FVector2D GetEndOffset(); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    float GetBoundaryMin(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    float GetBoundaryMax(); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x-7931];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SplineMeshComponent");
			return (class UClass*)ptr;
		};

};

class USpotLightComponent : public UPointLightComponent
{
	public:
	    float InnerConeAngle; // 0x3a8 Size: 0x4
	    float OuterConeAngle; // 0x3ac Size: 0x4
	    float LightShaftConeAngle; // 0x3b0 Size: 0x4
	    char UnknownData0[0x3b4]; // 0x3b4
	    void SetOuterConeAngle(float NewOuterConeAngle); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetInnerConeAngle(float NewInnerConeAngle); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7c21];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SpotLightComponent");
			return (class UClass*)ptr;
		};

};

class USpringArmComponent : public USceneComponent
{
	public:
	    float TargetArmLength; // 0x248 Size: 0x4
	    struct FVector SocketOffset; // 0x24c Size: 0xc
	    struct FVector TargetOffset; // 0x258 Size: 0xc
	    float ProbeSize; // 0x264 Size: 0x4
	    char ProbeChannel; // 0x268 Size: 0x1
	    bool bDoCollisionTest; // 0x26c Size: 0x1
	    bool bUsePawnControlRotation; // 0x26c Size: 0x1
	    bool bInheritPitch; // 0x26c Size: 0x1
	    bool bInheritYaw; // 0x26c Size: 0x1
	    bool bInheritRoll; // 0x26c Size: 0x1
	    bool bEnableCameraLag; // 0x26c Size: 0x1
	    bool bEnableCameraRotationLag; // 0x26c Size: 0x1
	    bool bUseCameraLagSubstepping; // 0x26c Size: 0x1
	    bool bDrawDebugLagMarkers; // 0x26d Size: 0x1
	    char UnknownData0[0x2]; // 0x272
	    float CameraLagSpeed; // 0x270 Size: 0x4
	    float CameraRotationLagSpeed; // 0x274 Size: 0x4
	    float CameraLagMaxTimeStep; // 0x278 Size: 0x4
	    float CameraLagMaxDistance; // 0x27c Size: 0x4
	    char UnknownData1[0x280]; // 0x280
	    bool IsCollisionFixApplied(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    struct FVector GetUnfixedCameraPosition(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    struct FRotator GetTargetRotation(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7d11];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SpringArmComponent");
			return (class UClass*)ptr;
		};

};

class UStaticMeshDescriptions : public UObject
{
	public:
	    char UnknownData0[0x38];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.StaticMeshDescriptions");
			return (class UClass*)ptr;
		};

};

class UStaticMesh : public UObject
{
	public:
	    char UnknownData0[0x20];
	    struct FPerPlatformInt MinLOD; // 0x48 Size: 0x4
	    float LpvBiasMultiplier; // 0x4c Size: 0x4
	    TArray<struct FStaticMaterial> StaticMaterials; // 0x50 Size: 0x10
	    float LightmapUVDensity; // 0x60 Size: 0x4
	    int LightMapResolution; // 0x64 Size: 0x4
	    int LightMapCoordinateIndex; // 0x68 Size: 0x4
	    float DistanceFieldSelfShadowBias; // 0x6c Size: 0x4
	    class UBodySetup* BodySetup; // 0x70 Size: 0x8
	    int LODForCollision; // 0x78 Size: 0x4
	    bool bGenerateMeshDistanceField; // 0x7c Size: 0x1
	    bool bStripComplexCollisionForConsole; // 0x7c Size: 0x1
	    bool bHasNavigationData; // 0x7c Size: 0x1
	    bool bSupportUniformlyDistributedSampling; // 0x7c Size: 0x1
	    bool bAllowCPUAccess; // 0x7c Size: 0x1
	    char UnknownData1[0x1f]; // 0x81
	    TArray<class UStaticMeshSocket*> Sockets; // 0xa0 Size: 0x10
	    char UnknownData2[0x10]; // 0xb0
	    struct FVector PositiveBoundsExtension; // 0xc0 Size: 0xc
	    struct FVector NegativeBoundsExtension; // 0xcc Size: 0xc
	    struct FBoxSphereBounds ExtendedBounds; // 0xd8 Size: 0x1c
	    int ElementToIgnoreForTexFactor; // 0xf4 Size: 0x4
	    TArray<class UAssetUserData*> AssetUserData; // 0xf8 Size: 0x10
	    class UObject* EditableMesh; // 0x108 Size: 0x8
	    class UNavCollisionBase* NavCollision; // 0x110 Size: 0x8
	    char UnknownData3[0x118]; // 0x118
	    int GetNumSections(int InLOD); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    int GetNumLODs(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    int GetMaterialIndex(FName MaterialSlotName); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    class UMaterialInterface* GetMaterial(int MaterialIndex); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    struct FBoxSphereBounds GetBounds(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    struct FBox GetBoundingBox(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7ec9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.StaticMesh");
			return (class UClass*)ptr;
		};

};

class UStaticMeshSocket : public UObject
{
	public:
	    FName SocketName; // 0x28 Size: 0x8
	    struct FVector RelativeLocation; // 0x30 Size: 0xc
	    struct FRotator RelativeRotation; // 0x3c Size: 0xc
	    struct FVector RelativeScale; // 0x48 Size: 0xc
	    char UnknownData0[0x4]; // 0x54
	    struct FString Tag; // 0x58 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.StaticMeshSocket");
			return (class UClass*)ptr;
		};

};

class UStereoLayerComponent : public USceneComponent
{
	public:
	    bool bLiveTexture; // 0x248 Size: 0x1
	    bool bSupportsDepth; // 0x248 Size: 0x1
	    bool bNoAlphaChannel; // 0x248 Size: 0x1
	    char UnknownData0[0x5]; // 0x24b
	    class UTexture* Texture; // 0x250 Size: 0x8
	    class UTexture* LeftTexture; // 0x258 Size: 0x8
	    bool bQuadPreserveTextureRatio; // 0x260 Size: 0x1
	    char UnknownData1[0x3]; // 0x261
	    struct FVector2D QuadSize; // 0x264 Size: 0x8
	    struct FBox2D UVRect; // 0x26c Size: 0x14
	    float CylinderRadius; // 0x280 Size: 0x4
	    float CylinderOverlayArc; // 0x284 Size: 0x4
	    int CylinderHeight; // 0x288 Size: 0x4
	    char StereoLayerType; // 0x28c Size: 0x1
	    char StereoLayerShape; // 0x28d Size: 0x1
	    char UnknownData2[0x2]; // 0x28e
	    int Priority; // 0x290 Size: 0x4
	    char UnknownData3[0x294]; // 0x294
	    void SetUVRect(struct FBox2D InUVRect); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetTexture(class UTexture* InTexture); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetQuadSize(struct FVector2D InQuadSize); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetPriority(int InPriority); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void MarkTextureForUpdate(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    struct FBox2D GetUVRect(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    class UTexture* GetTexture(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    struct FVector2D GetQuadSize(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    int GetPriority(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x-7d01];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.StereoLayerComponent");
			return (class UClass*)ptr;
		};

};

class UStereoLayerFunctionLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void ShowSplashScreen(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void SetSplashScreen(class UTexture* Texture, struct FVector2D Scale, struct FVector2D Offset, bool bShowLoadingMovie, bool bShowOnSet); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static void HideSplashScreen(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static void EnableAutoLoadingSplashScreen(bool InAutoShowEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.StereoLayerFunctionLibrary");
			return (class UClass*)ptr;
		};

};

class UStringTable : public UObject
{
	public:
	    char UnknownData0[0x40];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.StringTable");
			return (class UClass*)ptr;
		};

};

class USubsurfaceProfile : public UObject
{
	public:
	    struct FSubsurfaceProfileStruct Settings; // 0x28 Size: 0x50

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SubsurfaceProfile");
			return (class UClass*)ptr;
		};

};

class USubsystemBlueprintLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static class ULocalPlayerSubsystem* GetLocalPlayerSubSystemFromPlayerController(class APlayerController* PlayerController, class ULocalPlayerSubsystem* Class); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static class ULocalPlayerSubsystem* GetLocalPlayerSubsystem(class UObject* ContextObject, class ULocalPlayerSubsystem* Class); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static class UGameInstanceSubsystem* GetGameInstanceSubsystem(class UObject* ContextObject, class UGameInstanceSubsystem* Class); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SubsystemBlueprintLibrary");
			return (class UClass*)ptr;
		};

};

class USubUVAnimation : public UObject
{
	public:
	    class UTexture2D* SubUVTexture; // 0x28 Size: 0x8
	    int SubImages_Horizontal; // 0x30 Size: 0x4
	    int SubImages_Vertical; // 0x34 Size: 0x4
	    char BoundingMode; // 0x38 Size: 0x1
	    char OpacitySourceMode; // 0x39 Size: 0x1
	    char UnknownData0[0x2]; // 0x3a
	    float AlphaThreshold; // 0x3c Size: 0x4
	    char UnknownData1[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SubUVAnimation");
			return (class UClass*)ptr;
		};

};

class UTimecodeProvider : public UObject
{
	public:
	    struct FTimecode GetTimecode(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    ETimecodeProviderSynchronizationState GetSynchronizationState(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    struct FFrameRate GetFrameRate(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.TimecodeProvider");
			return (class UClass*)ptr;
		};

};

class USystemTimeTimecodeProvider : public UTimecodeProvider
{
	public:
	    struct FFrameRate FrameRate; // 0x28 Size: 0x8
	    char UnknownData0[0x30]; // 0x30
	    void SetFrameRate(struct FFrameRate InFrameRate); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7fa9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.SystemTimeTimecodeProvider");
			return (class UClass*)ptr;
		};

};

class ATargetPoint : public AActor
{
	public:
	    char UnknownData0[0x330];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.TargetPoint");
			return (class UClass*)ptr;
		};

};

class UTextPropertyTestObject : public UObject
{
	public:
	    struct FText DefaultedText; // 0x28 Size: 0x18
	    struct FText UndefaultedText; // 0x40 Size: 0x18
	    struct FText TransientText; // 0x58 Size: 0x18

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.TextPropertyTestObject");
			return (class UClass*)ptr;
		};

};

class ATextRenderActor : public AActor
{
	public:
	    class UTextRenderComponent* TextRender; // 0x330 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.TextRenderActor");
			return (class UClass*)ptr;
		};

};

class UTextRenderComponent : public UPrimitiveComponent
{
	public:
	    struct FText Text; // 0x570 Size: 0x18
	    class UMaterialInterface* TextMaterial; // 0x588 Size: 0x8
	    class UFont* Font; // 0x590 Size: 0x8
	    char HorizontalAlignment; // 0x598 Size: 0x1
	    char VerticalAlignment; // 0x599 Size: 0x1
	    char UnknownData0[0x2]; // 0x59a
	    struct FColor TextRenderColor; // 0x59c Size: 0x4
	    float XScale; // 0x5a0 Size: 0x4
	    float YScale; // 0x5a4 Size: 0x4
	    float WorldSize; // 0x5a8 Size: 0x4
	    float InvDefaultSize; // 0x5ac Size: 0x4
	    float HorizSpacingAdjust; // 0x5b0 Size: 0x4
	    float VertSpacingAdjust; // 0x5b4 Size: 0x4
	    bool bAlwaysRenderAsText; // 0x5b8 Size: 0x1
	    char UnknownData1[0x5b9]; // 0x5b9
	    void SetYScale(float Value); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetXScale(float Value); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetWorldSize(float Value); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetVertSpacingAdjust(float Value); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetVerticalAlignment(char Value); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetTextRenderColor(struct FColor Value); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetTextMaterial(class UMaterialInterface* Material); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetText(struct FString Value); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetHorizSpacingAdjust(float Value); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetHorizontalAlignment(char Value); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetFont(class UFont* Value); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void K2_SetText(struct FText Value); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    struct FVector GetTextWorldSize(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    struct FVector GetTextLocalSize(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x-7a21];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.TextRenderComponent");
			return (class UClass*)ptr;
		};

};

class UTexture2DDynamic : public UTexture
{
	public:
	    char UnknownData0[0x8];
	    char Format; // 0xc0 Size: 0x1
	    char UnknownData1[0xf];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Texture2DDynamic");
			return (class UClass*)ptr;
		};

};

class UTextureCube : public UTexture
{
	public:
	    char UnknownData0[0x110];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.TextureCube");
			return (class UClass*)ptr;
		};

};

class UTextureLightProfile : public UTexture2D
{
	public:
	    float Brightness; // 0xf0 Size: 0x4
	    float TextureMultiplier; // 0xf4 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.TextureLightProfile");
			return (class UClass*)ptr;
		};

};

class UTextureRenderTargetCube : public UTextureRenderTarget
{
	public:
	    int SizeX; // 0xc0 Size: 0x4
	    struct FLinearColor ClearColor; // 0xc4 Size: 0x10
	    char OverrideFormat; // 0xd4 Size: 0x1
	    bool bHDR; // 0xd5 Size: 0x1
	    bool bForceLinearGamma; // 0xd5 Size: 0x1
	    char UnknownData0[0x1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.TextureRenderTargetCube");
			return (class UClass*)ptr;
		};

};

class UThumbnailInfo : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.ThumbnailInfo");
			return (class UClass*)ptr;
		};

};

class UTimelineComponent : public UActorComponent
{
	public:
	    struct FTimeline TheTimeline; // 0xf8 Size: 0x98
	    bool bIgnoreTimeDilation; // 0x190 Size: 0x1
	    char UnknownData0[0x191]; // 0x191
	    void Stop(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetVectorCurve(class UCurveVector* NewVectorCurve, FName VectorTrackName); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetTimelineLengthMode(char NewLengthMode); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetTimelineLength(float NewLength); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetPlayRate(float NewRate); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetPlaybackPosition(float NewPosition, bool bFireEvents, bool bFireUpdate); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetNewTime(float NewTime); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetLooping(bool bNewLooping); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetLinearColorCurve(class UCurveLinearColor* NewLinearColorCurve, FName LinearColorTrackName); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetIgnoreTimeDilation(bool bNewIgnoreTimeDilation); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetFloatCurve(class UCurveFloat* NewFloatCurve, FName FloatTrackName); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void ReverseFromEnd(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void Reverse(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void PlayFromStart(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void Play(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void OnRep_Timeline(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    bool IsReversing(); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    bool IsPlaying(); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    bool IsLooping(); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    float GetTimelineLength(); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    float GetPlayRate(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    float GetPlaybackPosition(); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    bool GetIgnoreTimeDilation(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x-7e49];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.TimelineComponent");
			return (class UClass*)ptr;
		};

};

class UTimelineTemplate : public UObject
{
	public:
	    float TimelineLength; // 0x28 Size: 0x4
	    char LengthMode; // 0x2c Size: 0x1
	    bool bAutoPlay; // 0x2d Size: 0x1
	    bool bLoop; // 0x2d Size: 0x1
	    bool bReplicated; // 0x2d Size: 0x1
	    bool bValidatedAsWired; // 0x2d Size: 0x1
	    bool bIgnoreTimeDilation; // 0x2d Size: 0x1
	    char UnknownData0[0x2]; // 0x32
	    TArray<struct FTTEventTrack> EventTracks; // 0x30 Size: 0x10
	    TArray<struct FTTFloatTrack> FloatTracks; // 0x40 Size: 0x10
	    TArray<struct FTTVectorTrack> VectorTracks; // 0x50 Size: 0x10
	    TArray<struct FTTLinearColorTrack> LinearColorTracks; // 0x60 Size: 0x10
	    TArray<struct FBPVariableMetaDataEntry> MetaDataArray; // 0x70 Size: 0x10
	    struct FGuid TimelineGuid; // 0x80 Size: 0x10
	    FName VariableName; // 0x90 Size: 0x8
	    FName DirectionPropertyName; // 0x98 Size: 0x8
	    FName UpdateFunctionName; // 0xa0 Size: 0x8
	    FName FinishedFunctionName; // 0xa8 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.TimelineTemplate");
			return (class UClass*)ptr;
		};

};

class UTireType : public UDataAsset
{
	public:
	    float FrictionScale; // 0x30 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.TireType");
			return (class UClass*)ptr;
		};

};

class UTouchInterface : public UObject
{
	public:
	    TArray<struct FTouchInputControl> Controls; // 0x28 Size: 0x10
	    float ActiveOpacity; // 0x38 Size: 0x4
	    float InactiveOpacity; // 0x3c Size: 0x4
	    float TimeUntilDeactive; // 0x40 Size: 0x4
	    float TimeUntilReset; // 0x44 Size: 0x4
	    float ActivationDelay; // 0x48 Size: 0x4
	    bool bPreventRecenter; // 0x4c Size: 0x1
	    char UnknownData0[0x3]; // 0x4d
	    float StartupDelay; // 0x50 Size: 0x4
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.TouchInterface");
			return (class UClass*)ptr;
		};

};

class ATriggerBase : public AActor
{
	public:
	    class UShapeComponent* CollisionComponent; // 0x330 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.TriggerBase");
			return (class UClass*)ptr;
		};

};

class ATriggerBox : public ATriggerBase
{
	public:
	    char UnknownData0[0x338];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.TriggerBox");
			return (class UClass*)ptr;
		};

};

class ATriggerCapsule : public ATriggerBase
{
	public:
	    char UnknownData0[0x338];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.TriggerCapsule");
			return (class UClass*)ptr;
		};

};

class ATriggerSphere : public ATriggerBase
{
	public:
	    char UnknownData0[0x338];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.TriggerSphere");
			return (class UClass*)ptr;
		};

};

class ATriggerVolume : public AVolume
{
	public:
	    char UnknownData0[0x368];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.TriggerVolume");
			return (class UClass*)ptr;
		};

};

class UTwitterIntegrationBase : public UPlatformInterfaceBase
{
	public:
	    bool TwitterRequest(struct FString URL, TArray<struct FString> ParamKeysAndValues, char RequestMethod, int AccountIndex); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    bool ShowTweetUI(struct FString InitialMessage, struct FString URL, struct FString Picture); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void Init(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    int GetNumAccounts(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    struct FString GetAccountName(int AccountIndex); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    bool CanShowTweetUI(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool AuthorizeAccounts(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7fa9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.TwitterIntegrationBase");
			return (class UClass*)ptr;
		};

};

class UUserDefinedEnum : public UEnum
{
	public:
	    __int64/*MapProperty*/ DisplayNameMap; // 0x60 Size: 0x50

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.UserDefinedEnum");
			return (class UClass*)ptr;
		};

};

class UUserDefinedStruct : public UScriptStruct
{
	public:
	    char Status; // 0xa8 Size: 0x1
	    char UnknownData0[0x3]; // 0xa9
	    struct FGuid Guid; // 0xac Size: 0x10
	    char UnknownData1[0x34];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.UserDefinedStruct");
			return (class UClass*)ptr;
		};

};

class UUserInterfaceSettings : public UDeveloperSettings
{
	public:
	    ERenderFocusRule RenderFocusRule; // 0x38 Size: 0x1
	    char UnknownData0[0x7]; // 0x39
	    __int64/*MapProperty*/ HardwareCursors; // 0x40 Size: 0x50
	    __int64/*MapProperty*/ SoftwareCursors; // 0x90 Size: 0x50
	    struct FSoftClassPath DefaultCursor; // 0xe0 Size: 0x18
	    struct FSoftClassPath TextEditBeamCursor; // 0xf8 Size: 0x18
	    struct FSoftClassPath CrosshairsCursor; // 0x110 Size: 0x18
	    struct FSoftClassPath HandCursor; // 0x128 Size: 0x18
	    struct FSoftClassPath GrabHandCursor; // 0x140 Size: 0x18
	    struct FSoftClassPath GrabHandClosedCursor; // 0x158 Size: 0x18
	    struct FSoftClassPath SlashedCircleCursor; // 0x170 Size: 0x18
	    float ApplicationScale; // 0x188 Size: 0x4
	    EUIScalingRule UIScaleRule; // 0x18c Size: 0x1
	    char UnknownData1[0x3]; // 0x18d
	    struct FSoftClassPath CustomScalingRuleClass; // 0x190 Size: 0x18
	    struct FRuntimeFloatCurve UIScaleCurve; // 0x1a8 Size: 0x88
	    bool bAllowHighDPIInGameMode; // 0x230 Size: 0x1
	    bool bLoadWidgetsOnDedicatedServer; // 0x231 Size: 0x1
	    char UnknownData2[0x6]; // 0x232
	    TArray<class UObject*> CursorClasses; // 0x238 Size: 0x10
	    class UObject* CustomScalingRuleClassInstance; // 0x248 Size: 0x8
	    class UDPICustomScalingRule* CustomScalingRule; // 0x250 Size: 0x8
	    char UnknownData3[0x10];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.UserInterfaceSettings");
			return (class UClass*)ptr;
		};

};

class UVectorField : public UObject
{
	public:
	    struct FBox Bounds; // 0x28 Size: 0x1c
	    float Intensity; // 0x44 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.VectorField");
			return (class UClass*)ptr;
		};

};

class UVectorFieldAnimated : public UVectorField
{
	public:
	    class UTexture2D* Texture; // 0x48 Size: 0x8
	    char ConstructionOp; // 0x50 Size: 0x1
	    char UnknownData0[0x3]; // 0x51
	    int VolumeSizeX; // 0x54 Size: 0x4
	    int VolumeSizeY; // 0x58 Size: 0x4
	    int VolumeSizeZ; // 0x5c Size: 0x4
	    int SubImagesX; // 0x60 Size: 0x4
	    int SubImagesY; // 0x64 Size: 0x4
	    int FrameCount; // 0x68 Size: 0x4
	    float FramesPerSecond; // 0x6c Size: 0x4
	    bool bLoop; // 0x70 Size: 0x1
	    char UnknownData1[0x7]; // 0x71
	    class UVectorFieldStatic* NoiseField; // 0x78 Size: 0x8
	    float NoiseScale; // 0x80 Size: 0x4
	    float NoiseMax; // 0x84 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.VectorFieldAnimated");
			return (class UClass*)ptr;
		};

};

class UVectorFieldComponent : public UPrimitiveComponent
{
	public:
	    class UVectorField* VectorField; // 0x570 Size: 0x8
	    float Intensity; // 0x578 Size: 0x4
	    float Tightness; // 0x57c Size: 0x4
	    bool bPreviewVectorField; // 0x580 Size: 0x1
	    char UnknownData0[0x581]; // 0x581
	    void SetIntensity(float NewIntensity); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7a41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.VectorFieldComponent");
			return (class UClass*)ptr;
		};

};

class UVectorFieldStatic : public UVectorField
{
	public:
	    int SizeX; // 0x48 Size: 0x4
	    int SizeY; // 0x4c Size: 0x4
	    int SizeZ; // 0x50 Size: 0x4
	    char UnknownData0[0x7c];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.VectorFieldStatic");
			return (class UClass*)ptr;
		};

};

class AVectorFieldVolume : public AActor
{
	public:
	    class UVectorFieldComponent* VectorFieldComponent; // 0x330 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.VectorFieldVolume");
			return (class UClass*)ptr;
		};

};

class UVirtualTexture : public UObject
{
	public:
	    class UVirtualTextureSpace* Space; // 0x28 Size: 0x8
	    bool Rebuild; // 0x30 Size: 0x1
	    char UnknownData0[0x27];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.VirtualTexture");
			return (class UClass*)ptr;
		};

};

class ULightMapVirtualTexture : public UVirtualTexture
{
	public:
	    int LayerFlags; // 0x58 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LightMapVirtualTexture");
			return (class UClass*)ptr;
		};

};

class UVirtualTextureSpace : public UObject
{
	public:
	    TArray<struct FVirtualTextureLayer> Layers; // 0x28 Size: 0x10
	    int TileSize; // 0x38 Size: 0x4
	    int BorderWidth; // 0x3c Size: 0x4
	    int Size; // 0x40 Size: 0x4
	    int Dimensions; // 0x44 Size: 0x4
	    char Format; // 0x48 Size: 0x1
	    char UnknownData0[0x3]; // 0x49
	    int PoolSize; // 0x4c Size: 0x4
	    char UnknownData1[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.VirtualTextureSpace");
			return (class UClass*)ptr;
		};

};

class ULightMapVirtualTextureSpace : public UVirtualTextureSpace
{
	public:
	    char UnknownData0[0x78];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.LightMapVirtualTextureSpace");
			return (class UClass*)ptr;
		};

};

class UVisualLoggerAutomationTests : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.VisualLoggerAutomationTests");
			return (class UClass*)ptr;
		};

};

class UVisualLoggerDebugSnapshotInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.VisualLoggerDebugSnapshotInterface");
			return (class UClass*)ptr;
		};

};

class UVisualLoggerKismetLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void RedirectVislog(class UObject* SourceOwner, class UObject* DestinationOwner); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void LogText(class UObject* WorldContextObject, struct FString Text, FName LogCategory, bool bAddToMessageLog); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static void LogSegment(class UObject* WorldContextObject, struct FVector SegmentStart, struct FVector SegmentEnd, struct FString Text, struct FLinearColor ObjectColor, float Thickness, FName CategoryName, bool bAddToMessageLog); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static void LogLocation(class UObject* WorldContextObject, struct FVector Location, struct FString Text, struct FLinearColor ObjectColor, float Radius, FName LogCategory, bool bAddToMessageLog); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static void LogBox(class UObject* WorldContextObject, struct FBox BoxShape, struct FString Text, struct FLinearColor ObjectColor, FName LogCategory, bool bAddToMessageLog); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static void EnableRecording(bool bEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.VisualLoggerKismetLibrary");
			return (class UClass*)ptr;
		};

};

class UVOIPTalker : public UActorComponent
{
	public:
	    struct FVoiceSettings Settings; // 0xf8 Size: 0x18
	    char UnknownData0[0x110]; // 0x110
	    void RegisterWithPlayerState(class APlayerState* OwningState); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    float GetVoiceLevel(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static class UVOIPTalker* CreateTalkerForPlayer(class APlayerState* OwningState); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void BPOnTalkingEnd(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void BPOnTalkingBegin(class UAudioComponent* AudioComponent); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7eb1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.VOIPTalker");
			return (class UClass*)ptr;
		};

};

class UVOIPStatics : public UBlueprintFunctionLibrary
{
	public:
	    static void SetMicThreshold(float InThreshold); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.VOIPStatics");
			return (class UClass*)ptr;
		};

};

class UVolumeTexture : public UTexture
{
	public:
	    char UnknownData0[0x110];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.VolumeTexture");
			return (class UClass*)ptr;
		};

};

class AVolumetricLightmapDensityVolume : public AVolume
{
	public:
	    struct FInt32Interval AllowedMipLevelRange; // 0x368 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.VolumetricLightmapDensityVolume");
			return (class UClass*)ptr;
		};

};

class AWindDirectionalSource : public AInfo
{
	public:
	    class UWindDirectionalSourceComponent* Component; // 0x330 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.WindDirectionalSource");
			return (class UClass*)ptr;
		};

};

class UWindDirectionalSourceComponent : public USceneComponent
{
	public:
	    float Strength; // 0x248 Size: 0x4
	    float Speed; // 0x24c Size: 0x4
	    float MinGustAmount; // 0x250 Size: 0x4
	    float MaxGustAmount; // 0x254 Size: 0x4
	    float Radius; // 0x258 Size: 0x4
	    bool bPointWind; // 0x25c Size: 0x1
	    char UnknownData0[0x25d]; // 0x25d
	    void SetWindType(EWindSourceType InNewType); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetStrength(float InNewStrength); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetSpeed(float InNewSpeed); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetRadius(float InNewRadius); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetMinimumGustAmount(float InNewMinGust); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetMaximumGustAmount(float InNewMaxGust); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7d71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.WindDirectionalSourceComponent");
			return (class UClass*)ptr;
		};

};

class UWorldComposition : public UObject
{
	public:
	    char UnknownData0[0x20];
	    TArray<class ULevelStreaming*> TilesStreaming; // 0x48 Size: 0x10
	    double TilesStreamingTimeThreshold; // 0x58 Size: 0x8
	    bool bLoadAllTilesDuringCinematic; // 0x60 Size: 0x1
	    bool bRebaseOriginIn3DSpace; // 0x61 Size: 0x1
	    char UnknownData1[0x2]; // 0x62
	    float RebaseOriginDistance; // 0x64 Size: 0x4

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.WorldComposition");
			return (class UClass*)ptr;
		};

};

class UHierarchicalLODSetup : public UObject
{
	public:
	    TArray<struct FHierarchicalSimplification> HierarchicalLODSetup; // 0x28 Size: 0x10
	    struct TSoftObjectPtr<struct UMaterialInterface*> OverrideBaseMaterial; // 0x38 Size: 0x28

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.HierarchicalLODSetup");
			return (class UClass*)ptr;
		};

};

class UDefault__AnimBlueprintGeneratedClass
{
	public:

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Engine.Default__AnimBlueprintGeneratedClass");
			return (class UClass*)ptr;
		};

};


}