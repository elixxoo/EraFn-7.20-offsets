#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FOnLevelSequencePlayerCameraCutEvent__DelegateSignature
{
	public:
	    class UCameraComponent* CameraComponent; // 0x0 Size: 0x8

};

struct FBoundActorProxy
{
	public:
	    char UnknownData0[0x1];

};

struct FLevelSequenceBindingReferences
{
	public:
	    __int64/*MapProperty*/ BindingIdToReferences; // 0x0 Size: 0x50
	    __int64/*SetProperty*/ AnimSequenceInstances; // 0x50 Size: 0x50

};

struct FLevelSequenceBindingReference
{
	public:
	    struct FString PackageName; // 0x0 Size: 0x10
	    struct FSoftObjectPath ExternalObjectPath; // 0x10 Size: 0x18
	    struct FString ObjectPath; // 0x28 Size: 0x10

};

struct FLevelSequenceObjectReferenceMap
{
	public:
	    char UnknownData0[0x50];

};

struct FLevelSequenceLegacyObjectReference
{
	public:
	    char UnknownData0[0x20];

};

struct FLevelSequenceObject
{
	public:
	    TLazyObjectPtr<UObject*> ObjectOrOwner; // 0x0 Size: 0x1c
	    char UnknownData0[0x4]; // 0x1c
	    struct FString ComponentName; // 0x20 Size: 0x10
	    TWeakObjectPtr<UObject*> CachedComponent; // 0x30 Size: 0x8

};

struct FLevelSequenceSnapshotSettings
{
	public:
	    char ZeroPadAmount; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    struct FFrameRate FrameRate; // 0x4 Size: 0x8

};

struct FLevelSequencePlayerSnapshot
{
	public:
	    struct FString MasterName; // 0x0 Size: 0x10
	    struct FQualifiedFrameTime MasterTime; // 0x10 Size: 0x10
	    struct FQualifiedFrameTime SourceTime; // 0x20 Size: 0x10
	    struct FString CurrentShotName; // 0x30 Size: 0x10
	    struct FQualifiedFrameTime CurrentShotLocalTime; // 0x40 Size: 0x10
	    struct FQualifiedFrameTime CurrentShotSourceTime; // 0x50 Size: 0x10
	    struct FString SourceTimecode; // 0x60 Size: 0x10
	    class UCameraComponent* CameraComponent; // 0x70 Size: 0x8
	    struct FLevelSequenceSnapshotSettings Settings; // 0x78 Size: 0xc
	    struct FMovieSceneSequenceID ShotID; // 0x84 Size: 0x4

};


}