#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FInstancePointDamageSignature__DelegateSignature
{
	public:
	    int InstanceIndex; // 0x0 Size: 0x4
	    float Damage; // 0x4 Size: 0x4
	    class AController* InstigatedBy; // 0x8 Size: 0x8
	    struct FVector HitLocation; // 0x10 Size: 0xc
	    struct FVector ShotFromDirection; // 0x1c Size: 0xc
	    class UDamageType* DamageType; // 0x28 Size: 0x8
	    class AActor* DamageCauser; // 0x30 Size: 0x8

};



enum class EFoliageScaling : uint8_t
{
    Uniform = 0,
    Free = 1,
    LockXY = 2,
    LockXZ = 3,
    LockYZ = 4,
    EFoliageScaling_MAX = 5
};

enum class EVertexColorMaskChannel : uint8_t
{
    Red = 0,
    Green = 1,
    Blue = 2,
    Alpha = 3,
    MAX_None = 4,
    EVertexColorMaskChannel_MAX = 5
};

enum class FoliageVertexColorMask : uint8_t
{
    FOLIAGEVERTEXCOLORMASK_Disabled = 0,
    FOLIAGEVERTEXCOLORMASK_Red = 1,
    FOLIAGEVERTEXCOLORMASK_Green = 2,
    FOLIAGEVERTEXCOLORMASK_Blue = 3,
    FOLIAGEVERTEXCOLORMASK_Alpha = 4,
    FOLIAGEVERTEXCOLORMASK_MAX = 5
};

enum class ESimulationQuery : uint8_t
{
    CollisionOverlap = 1,
    ShadeOverlap = 2,
    AnyOverlap = 3,
    ESimulationQuery_MAX = 4
};

enum class ESimulationOverlap : uint8_t
{
    CollisionOverlap = 0,
    ShadeOverlap = 1,
    None = 2,
    ESimulationOverlap_MAX = 3
};struct FFoliageVertexColorChannelMask
{
	public:
	    bool UseMask; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float MaskThreshold; // 0x4 Size: 0x4
	    bool InvertMask; // 0x8 Size: 0x1
	    char UnknownData1[0x3];

};

struct FFoliageTypeObject
{
	public:
	    class UObject* FoliageTypeObject; // 0x0 Size: 0x8
	    class UFoliageType_InstancedStaticMesh* TypeInstance; // 0x8 Size: 0x8
	    bool bIsAsset; // 0x10 Size: 0x1
	    char UnknownData0[0x7]; // 0x11
	    class UFoliageType_InstancedStaticMesh* Type; // 0x18 Size: 0x8

};

struct FProceduralFoliageInstance
{
	public:
	    struct FVector Location; // 0x0 Size: 0xc
	    char UnknownData0[0x4]; // 0xc
	    struct FQuat Rotation; // 0x10 Size: 0x10
	    struct FVector Normal; // 0x20 Size: 0xc
	    float Age; // 0x2c Size: 0x4
	    float Scale; // 0x30 Size: 0x4
	    char UnknownData1[0x4]; // 0x34
	    class UFoliageType_InstancedStaticMesh* Type; // 0x38 Size: 0x8
	    char UnknownData2[0x20];

};


}