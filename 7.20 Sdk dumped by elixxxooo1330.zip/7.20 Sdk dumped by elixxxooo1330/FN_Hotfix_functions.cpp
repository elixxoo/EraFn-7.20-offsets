#include "../SDK.hpp"

void UOnlineHotfixManager::StartHotfixProcess()
{
    static auto fn = UObject::FindObject("/Script/Hotfix.OnlineHotfixManager:StartHotfixProcess");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

