#pragma once

#include "../SDK.hpp"

namespace SDK {


class UMovieSceneSignedObject : public UObject
{
	public:
	    struct FGuid Signature; // 0x28 Size: 0x10
	    char UnknownData0[0x18];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieScene.MovieSceneSignedObject");
			return (class UClass*)ptr;
		};

};

class UMovieSceneTrack : public UMovieSceneSignedObject
{
	public:
	    struct FMovieSceneTrackEvalOptions EvalOptions; // 0x50 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieScene.MovieSceneTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneSequence : public UMovieSceneSignedObject
{
	public:
	    struct FMovieSceneEvaluationTemplate PrecompiledEvaluationTemplate; // 0x50 Size: 0x2f0
	    EMovieSceneCompletionMode DefaultCompletionMode; // 0x340 Size: 0x1
	    bool bParentContextsAreSignificant; // 0x341 Size: 0x1
	    char UnknownData0[0x6];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieScene.MovieSceneSequence");
			return (class UClass*)ptr;
		};

};

class UMovieSceneSection : public UMovieSceneSignedObject
{
	public:
	    struct FMovieSceneSectionEvalOptions EvalOptions; // 0x50 Size: 0x2
	    char UnknownData0[0x6]; // 0x52
	    struct FMovieSceneEasingSettings Easing; // 0x58 Size: 0x38
	    struct FMovieSceneFrameRange SectionRange; // 0x90 Size: 0x10
	    struct FFrameNumber PreRollFrames; // 0xa0 Size: 0x4
	    struct FFrameNumber PostRollFrames; // 0xa4 Size: 0x4
	    int RowIndex; // 0xa8 Size: 0x4
	    int OverlapPriority; // 0xac Size: 0x4
	    bool bIsActive; // 0xb0 Size: 0x1
	    bool bIsLocked; // 0xb0 Size: 0x1
	    char UnknownData1[0x2]; // 0xb2
	    float StartTime; // 0xb4 Size: 0x4
	    float EndTime; // 0xb8 Size: 0x4
	    float PrerollTime; // 0xbc Size: 0x4
	    float PostrollTime; // 0xc0 Size: 0x4
	    bool bIsInfinite; // 0xc4 Size: 0x1
	    bool bSupportsInfiniteRange; // 0xc8 Size: 0x1
	    char UnknownData2[0x3]; // 0xc6
	    struct FOptionalMovieSceneBlendType BlendType; // 0xc9 Size: 0x2
	    char UnknownData3[0x15];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieScene.MovieSceneSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneSubSection : public UMovieSceneSection
{
	public:
	    struct FMovieSceneSectionParameters Parameters; // 0xe0 Size: 0x18
	    float StartOffset; // 0xf8 Size: 0x4
	    float TimeScale; // 0xfc Size: 0x4
	    float PrerollTime; // 0x100 Size: 0x4
	    char UnknownData0[0x4]; // 0x104
	    class UMovieSceneSequence* SubSequence; // 0x108 Size: 0x8
	    TLazyObjectPtr<AActor*> ActorToRecord; // 0x110 Size: 0x1c
	    char UnknownData1[0x4]; // 0x12c
	    struct FString TargetSequenceName; // 0x130 Size: 0x10
	    struct FDirectoryPath TargetPathToRecordTo; // 0x140 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieScene.MovieSceneSubSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneNameableTrack : public UMovieSceneTrack
{
	public:
	    char UnknownData0[0x58];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieScene.MovieSceneNameableTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneSubTrack : public UMovieSceneNameableTrack
{
	public:
	    TArray<class UMovieSceneSection*> Sections; // 0x58 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieScene.MovieSceneSubTrack");
			return (class UClass*)ptr;
		};

};

class UMovieScenePlaybackClient : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieScene.MovieScenePlaybackClient");
			return (class UClass*)ptr;
		};

};

class UMovieScene : public UMovieSceneSignedObject
{
	public:
	    TArray<struct FMovieSceneSpawnable> Spawnables; // 0x50 Size: 0x10
	    TArray<struct FMovieScenePossessable> Possessables; // 0x60 Size: 0x10
	    TArray<struct FMovieSceneBinding> ObjectBindings; // 0x70 Size: 0x10
	    TArray<class UMovieSceneTrack*> MasterTracks; // 0x80 Size: 0x10
	    class UMovieSceneTrack* CameraCutTrack; // 0x90 Size: 0x8
	    struct FMovieSceneFrameRange SelectionRange; // 0x98 Size: 0x10
	    struct FMovieSceneFrameRange PlaybackRange; // 0xa8 Size: 0x10
	    struct FFrameRate TickResolution; // 0xb8 Size: 0x8
	    struct FFrameRate DisplayRate; // 0xc0 Size: 0x8
	    EMovieSceneEvaluationType EvaluationType; // 0xc8 Size: 0x1
	    EUpdateClockSource ClockSource; // 0xc9 Size: 0x1
	    char UnknownData0[0x6];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieScene.MovieScene");
			return (class UClass*)ptr;
		};

};

class UMovieSceneBindingOverrides : public UObject
{
	public:
	    TArray<struct FMovieSceneBindingOverrideData> BindingData; // 0x28 Size: 0x10
	    char UnknownData0[0x58];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieScene.MovieSceneBindingOverrides");
			return (class UClass*)ptr;
		};

};

class UMovieSceneBindingOwnerInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieScene.MovieSceneBindingOwnerInterface");
			return (class UClass*)ptr;
		};

};

class UMovieSceneBuiltInEasingFunction : public UObject
{
	public:
	    char UnknownData0[0x8];
	    EMovieSceneBuiltInEasing Type; // 0x30 Size: 0x1
	    char UnknownData1[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieScene.MovieSceneBuiltInEasingFunction");
			return (class UClass*)ptr;
		};

};

class UMovieSceneEasingExternalCurve : public UObject
{
	public:
	    char UnknownData0[0x8];
	    class UCurveFloat* Curve; // 0x30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieScene.MovieSceneEasingExternalCurve");
			return (class UClass*)ptr;
		};

};

class UMovieSceneEasingFunction : public UInterface
{
	public:
	    float OnEvaluate(float Interp); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieScene.MovieSceneEasingFunction");
			return (class UClass*)ptr;
		};

};

class UMovieSceneFolder : public UObject
{
	public:
	    FName FolderName; // 0x28 Size: 0x8
	    TArray<class UMovieSceneFolder*> ChildFolders; // 0x30 Size: 0x10
	    TArray<class UMovieSceneTrack*> ChildMasterTracks; // 0x40 Size: 0x10
	    TArray<struct FString> ChildObjectBindingStrings; // 0x50 Size: 0x10
	    char UnknownData0[0x10];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieScene.MovieSceneFolder");
			return (class UClass*)ptr;
		};

};

class UMovieSceneKeyProxy : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieScene.MovieSceneKeyProxy");
			return (class UClass*)ptr;
		};

};

class UMovieSceneSequencePlayer : public UObject
{
	public:
	    char UnknownData0[0x348];
	    MulticastDelegateProperty OnPlay; // 0x370 Size: 0x10
	    MulticastDelegateProperty OnPlayReverse; // 0x380 Size: 0x10
	    MulticastDelegateProperty OnStop; // 0x390 Size: 0x10
	    MulticastDelegateProperty OnPause; // 0x3a0 Size: 0x10
	    MulticastDelegateProperty OnFinished; // 0x3b0 Size: 0x10
	    char Status; // 0x3c0 Size: 0x1
	    bool bReversePlayback; // 0x3c4 Size: 0x1
	    char UnknownData1[0x6]; // 0x3c2
	    class UMovieSceneSequence* Sequence; // 0x3c8 Size: 0x8
	    struct FFrameNumber StartTime; // 0x3d0 Size: 0x4
	    int DurationFrames; // 0x3d4 Size: 0x4
	    int CurrentNumLoops; // 0x3d8 Size: 0x4
	    char UnknownData2[0x14]; // 0x3dc
	    struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // 0x3f0 Size: 0x10
	    struct FMovieSceneRootEvaluationTemplateInstance RootTemplateInstance; // 0x400 Size: 0x300
	    char UnknownData3[0x68]; // 0x700
	    struct FMovieSceneSequenceReplProperties NetSyncProps; // 0x768 Size: 0x10
	    __int64/*InterfaceProperty*/ PlaybackClient; // 0x778 Size: 0x10
	    char UnknownData4[0x788]; // 0x788
	    void StopAtCurrentTime(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void Stop(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetTimeRange(float StartTime, float Duration); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetPlayRate(float PlayRate); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetPlaybackRange(float NewStartTime, float NewEndTime); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetPlaybackPosition(float NewPlaybackPosition); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetFrameRate(struct FFrameRate FrameRate); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetFrameRange(int StartFrame, int Duration); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetDisableCameraCuts(bool bInDisableCameraCuts); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void ScrubToSeconds(float TimeInSeconds); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void ScrubToFrame(struct FFrameTime NewPosition); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void Scrub(); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void RPC_OnStopEvent(struct FFrameTime StoppedTime); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void RPC_ExplicitServerUpdateEvent(EUpdatePositionMethod Method, struct FFrameTime RelevantTime); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void PlayToSeconds(float TimeInSeconds); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void PlayToFrame(struct FFrameTime NewPosition); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void PlayReverse(); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void PlayLooping(int NumLoops); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void Play(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void Pause(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    void JumpToSeconds(float TimeInSeconds); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    void JumpToPosition(float NewPlaybackPosition); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    void JumpToFrame(struct FFrameTime NewPosition); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    bool IsReversed(); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    bool IsPlaying(); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    bool IsPaused(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    void GoToEndAndStop(); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    struct FQualifiedFrameTime GetStartTime(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    float GetPlayRate(); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    float GetPlaybackStart(); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    float GetPlaybackPosition(); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    float GetPlaybackEnd(); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x7fe1]; // 0x7fe1
	    TArray<struct FMovieSceneObjectBindingID> GetObjectBindings(class UObject* InObject); // 0x0 Size: 0x7fe1
	    char UnknownData37[0x7fe1]; // 0x7fe1
	    float GetLength(); // 0x0 Size: 0x7fe1
	    char UnknownData38[0x7fe1]; // 0x7fe1
	    struct FFrameRate GetFrameRate(); // 0x0 Size: 0x7fe1
	    char UnknownData39[0x7fe1]; // 0x7fe1
	    int GetFrameDuration(); // 0x0 Size: 0x7fe1
	    char UnknownData40[0x7fe1]; // 0x7fe1
	    struct FQualifiedFrameTime GetEndTime(); // 0x0 Size: 0x7fe1
	    char UnknownData41[0x7fe1]; // 0x7fe1
	    struct FQualifiedFrameTime GetDuration(); // 0x0 Size: 0x7fe1
	    char UnknownData42[0x7fe1]; // 0x7fe1
	    bool GetDisableCameraCuts(); // 0x0 Size: 0x7fe1
	    char UnknownData43[0x7fe1]; // 0x7fe1
	    struct FQualifiedFrameTime GetCurrentTime(); // 0x0 Size: 0x7fe1
	    char UnknownData44[0x7fe1]; // 0x7fe1
	    TArray<class UObject*> GetBoundObjects(struct FMovieSceneObjectBindingID ObjectBinding); // 0x0 Size: 0x7fe1
	    char UnknownData45[0x7fe1]; // 0x7fe1
	    void ChangePlaybackDirection(); // 0x0 Size: 0x7fe1
	    char UnknownData46[0x-7821];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieScene.MovieSceneSequencePlayer");
			return (class UClass*)ptr;
		};

};

class UTestMovieSceneTrack : public UMovieSceneTrack
{
	public:
	    bool bHighPassFilter; // 0x58 Size: 0x1
	    char UnknownData0[0x7]; // 0x59
	    TArray<class UMovieSceneSection*> SectionArray; // 0x60 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieScene.TestMovieSceneTrack");
			return (class UClass*)ptr;
		};

};

class UTestMovieSceneSection : public UMovieSceneSection
{
	public:
	    char UnknownData0[0xe0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieScene.TestMovieSceneSection");
			return (class UClass*)ptr;
		};

};

class UTestMovieSceneSequence : public UMovieSceneSequence
{
	public:
	    class UMovieScene* MovieScene; // 0x348 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieScene.TestMovieSceneSequence");
			return (class UClass*)ptr;
		};

};


}