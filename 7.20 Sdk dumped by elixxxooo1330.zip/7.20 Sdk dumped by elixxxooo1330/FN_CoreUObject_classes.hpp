#pragma once

#include "../SDK.hpp"

namespace SDK {



class UObject {
	public:
		static uintptr_t* FindObject(std::string ClassName) {
			// TODO: Class
			return _StaticFindObject(0, 0, std::wstring(ClassName.begin(), ClassName.end()).c_str(), false);
		}
};
class UInterface : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.Interface");
			return (class UClass*)ptr;
		};

};

class UPackage : public UObject
{
	public:
	    char UnknownData0[0x90];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.Package");
			return (class UClass*)ptr;
		};

};

class UField : public UObject
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.Field");
			return (class UClass*)ptr;
		};

};

class UStruct : public UField
{
	public:
	    char UnknownData0[0x98];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.Struct");
			return (class UClass*)ptr;
		};

};

class UClass : public UStruct
{
	public:
	    char UnknownData0[0x208];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.Class");
			return (class UClass*)ptr;
		};

};

class UGCObjectReferencer : public UObject
{
	public:
	    char UnknownData0[0x60];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.GCObjectReferencer");
			return (class UClass*)ptr;
		};

};

class UTextBuffer : public UObject
{
	public:
	    char UnknownData0[0x50];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.TextBuffer");
			return (class UClass*)ptr;
		};

};

class UScriptStruct : public UStruct
{
	public:
	    char UnknownData0[0xa8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.ScriptStruct");
			return (class UClass*)ptr;
		};

};

class UFunction : public UStruct
{
	public:
	    char UnknownData0[0xc8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.Function");
			return (class UClass*)ptr;
		};

};

class UDelegateFunction : public UFunction
{
	public:
	    char UnknownData0[0xc8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.DelegateFunction");
			return (class UClass*)ptr;
		};

};

class UDynamicClass : public UClass
{
	public:
	    char UnknownData0[0x270];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.DynamicClass");
			return (class UClass*)ptr;
		};

};

class UPackageMap : public UObject
{
	public:
	    char UnknownData0[0xe0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.PackageMap");
			return (class UClass*)ptr;
		};

};

class UEnum : public UField
{
	public:
	    char UnknownData0[0x60];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.Enum");
			return (class UClass*)ptr;
		};

};

class UProperty : public UField
{
	public:
	    char UnknownData0[0x70];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.Property");
			return (class UClass*)ptr;
		};

};

class UEnumProperty : public UProperty
{
	public:
	    char UnknownData0[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.EnumProperty");
			return (class UClass*)ptr;
		};

};

class ULinkerPlaceholderClass : public UClass
{
	public:
	    char UnknownData0[0x3c0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.LinkerPlaceholderClass");
			return (class UClass*)ptr;
		};

};

class ULinkerPlaceholderExportObject : public UObject
{
	public:
	    char UnknownData0[0xf0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.LinkerPlaceholderExportObject");
			return (class UClass*)ptr;
		};

};

class ULinkerPlaceholderFunction : public UFunction
{
	public:
	    char UnknownData0[0x280];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.LinkerPlaceholderFunction");
			return (class UClass*)ptr;
		};

};

class UMetaData : public UObject
{
	public:
	    char UnknownData0[0xc8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.MetaData");
			return (class UClass*)ptr;
		};

};

class UObjectRedirector : public UObject
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.ObjectRedirector");
			return (class UClass*)ptr;
		};

};

class UArrayProperty : public UProperty
{
	public:
	    char UnknownData0[0x78];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.ArrayProperty");
			return (class UClass*)ptr;
		};

};

class UObjectPropertyBase : public UProperty
{
	public:
	    char UnknownData0[0x78];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.ObjectPropertyBase");
			return (class UClass*)ptr;
		};

};

class UBoolProperty : public UProperty
{
	public:
	    char UnknownData0[0x78];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.BoolProperty");
			return (class UClass*)ptr;
		};

};

class UNumericProperty : public UProperty
{
	public:
	    char UnknownData0[0x70];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.NumericProperty");
			return (class UClass*)ptr;
		};

};

class UByteProperty : public UNumericProperty
{
	public:
	    char UnknownData0[0x78];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.ByteProperty");
			return (class UClass*)ptr;
		};

};

class UObjectProperty : public UObjectPropertyBase
{
	public:
	    char UnknownData0[0x78];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.ObjectProperty");
			return (class UClass*)ptr;
		};

};

class UClassProperty : public UObjectProperty
{
	public:
	    char UnknownData0[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.ClassProperty");
			return (class UClass*)ptr;
		};

};

class UDelegateProperty : public UProperty
{
	public:
	    char UnknownData0[0x78];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.DelegateProperty");
			return (class UClass*)ptr;
		};

};

class UDoubleProperty : public UNumericProperty
{
	public:
	    char UnknownData0[0x70];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.DoubleProperty");
			return (class UClass*)ptr;
		};

};

class UFloatProperty : public UNumericProperty
{
	public:
	    char UnknownData0[0x70];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.FloatProperty");
			return (class UClass*)ptr;
		};

};

class UIntProperty : public UNumericProperty
{
	public:
	    char UnknownData0[0x70];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.IntProperty");
			return (class UClass*)ptr;
		};

};

class UInt16Property : public UNumericProperty
{
	public:
	    char UnknownData0[0x70];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.Int16Property");
			return (class UClass*)ptr;
		};

};

class UInt64Property : public UNumericProperty
{
	public:
	    char UnknownData0[0x70];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.Int64Property");
			return (class UClass*)ptr;
		};

};

class UInt8Property : public UNumericProperty
{
	public:
	    char UnknownData0[0x70];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.Int8Property");
			return (class UClass*)ptr;
		};

};

class UInterfaceProperty : public UProperty
{
	public:
	    char UnknownData0[0x78];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.InterfaceProperty");
			return (class UClass*)ptr;
		};

};

class ULazyObjectProperty : public UObjectPropertyBase
{
	public:
	    char UnknownData0[0x78];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.LazyObjectProperty");
			return (class UClass*)ptr;
		};

};

class UMapProperty : public UProperty
{
	public:
	    char UnknownData0[0xa8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.MapProperty");
			return (class UClass*)ptr;
		};

};

class UMulticastDelegateProperty : public UProperty
{
	public:
	    char UnknownData0[0x78];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.MulticastDelegateProperty");
			return (class UClass*)ptr;
		};

};

class UNameProperty : public UProperty
{
	public:
	    char UnknownData0[0x70];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.NameProperty");
			return (class UClass*)ptr;
		};

};

class USetProperty : public UProperty
{
	public:
	    char UnknownData0[0x98];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.SetProperty");
			return (class UClass*)ptr;
		};

};

class USoftObjectProperty : public UObjectPropertyBase
{
	public:
	    char UnknownData0[0x78];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.SoftObjectProperty");
			return (class UClass*)ptr;
		};

};

class USoftClassProperty : public USoftObjectProperty
{
	public:
	    char UnknownData0[0x80];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.SoftClassProperty");
			return (class UClass*)ptr;
		};

};

class UStrProperty : public UProperty
{
	public:
	    char UnknownData0[0x70];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.StrProperty");
			return (class UClass*)ptr;
		};

};

class UStructProperty : public UProperty
{
	public:
	    char UnknownData0[0x78];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.StructProperty");
			return (class UClass*)ptr;
		};

};

class UUInt16Property : public UNumericProperty
{
	public:
	    char UnknownData0[0x70];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.UInt16Property");
			return (class UClass*)ptr;
		};

};

class UUInt32Property : public UNumericProperty
{
	public:
	    char UnknownData0[0x70];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.UInt32Property");
			return (class UClass*)ptr;
		};

};

class UUInt64Property : public UNumericProperty
{
	public:
	    char UnknownData0[0x70];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.UInt64Property");
			return (class UClass*)ptr;
		};

};

class UWeakObjectProperty : public UObjectPropertyBase
{
	public:
	    char UnknownData0[0x78];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.WeakObjectProperty");
			return (class UClass*)ptr;
		};

};

class UTextProperty : public UProperty
{
	public:
	    char UnknownData0[0x70];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.TextProperty");
			return (class UClass*)ptr;
		};

};

class UDefault__Class
{
	public:

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.Default__Class");
			return (class UClass*)ptr;
		};

};

class UDefault__DynamicClass
{
	public:

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.Default__DynamicClass");
			return (class UClass*)ptr;
		};

};

class UDefault__LinkerPlaceholderClass
{
	public:

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/CoreUObject.Default__LinkerPlaceholderClass");
			return (class UClass*)ptr;
		};

};


}