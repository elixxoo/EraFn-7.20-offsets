#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FPredictionKey
{
	public:
	    int16_t Current; // 0x0 Size: 0x2
	    int16_t Base; // 0x2 Size: 0x2
	    char UnknownData0[0x4]; // 0x4
	    class UPackageMap* PredictiveConnection; // 0x8 Size: 0x8
	    bool bIsStale; // 0x10 Size: 0x1
	    bool bIsServerInitiated; // 0x11 Size: 0x1
	    char UnknownData1[0x6];

};

struct FGameplayEffectContextHandle
{
	public:
	    char UnknownData0[0x18];

};

struct FGameplayAbilitySpecHandle
{
	public:
	    int Handle; // 0x0 Size: 0x4

};



enum class EGameplayEffectGrantedAbilityRemovePolicy : uint8_t
{
    CancelAbilityImmediately = 0,
    RemoveAbilityOnEnd = 1,
    DoNothing = 2,
    EGameplayEffectGrantedAbilityRemovePolicy_MAX = 3
};struct FScalableFloat
{
	public:
	    float Value; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    struct FCurveTableRowHandle Curve; // 0x8 Size: 0x10
	    char UnknownData1[0x8];

};

struct FGameplayAbilitySpecDef
{
	public:
	    class UGameplayAbility* Ability; // 0x0 Size: 0x8
	    struct FScalableFloat LevelScalableFloat; // 0x8 Size: 0x20
	    int InputID; // 0x28 Size: 0x4
	    EGameplayEffectGrantedAbilityRemovePolicy RemovalPolicy; // 0x2c Size: 0x1
	    char UnknownData0[0x3]; // 0x2d
	    class UObject* SourceObject; // 0x30 Size: 0x8
	    char UnknownData1[0x50]; // 0x38
	    struct FGameplayAbilitySpecHandle AssignedHandle; // 0x88 Size: 0x4
	    char UnknownData2[0x4];

};

struct FModifierSpec
{
	public:
	    float EvaluatedMagnitude; // 0x0 Size: 0x4

};



enum class EGameplayEffectAttributeCaptureSource : uint8_t
{
    Source = 0,
    Target = 1,
    EGameplayEffectAttributeCaptureSource_MAX = 2
};struct FGameplayAttribute
{
	public:
	    struct FString AttributeName; // 0x0 Size: 0x10
	    class UProperty* Attribute; // 0x10 Size: 0x8
	    class UStruct* AttributeOwner; // 0x18 Size: 0x8

};

struct FGameplayEffectAttributeCaptureDefinition
{
	public:
	    struct FGameplayAttribute AttributeToCapture; // 0x0 Size: 0x20
	    EGameplayEffectAttributeCaptureSource AttributeSource; // 0x20 Size: 0x1
	    bool bSnapshot; // 0x21 Size: 0x1
	    char UnknownData0[0x6];

};

struct FGameplayEffectAttributeCaptureSpec
{
	public:
	    struct FGameplayEffectAttributeCaptureDefinition BackingDefinition; // 0x0 Size: 0x28
	    char UnknownData0[0x10];

};

struct FGameplayEffectModifiedAttribute
{
	public:
	    struct FGameplayAttribute Attribute; // 0x0 Size: 0x20
	    float TotalMagnitude; // 0x20 Size: 0x4
	    char UnknownData0[0x4];

};

struct FApplyRootMotionConstantForceDelegate__DelegateSignature
{
	public:

};

struct FApplyRootMotionJumpForceDelegate__DelegateSignature
{
	public:

};

struct FApplyRootMotionMoveToActorForceDelegate__DelegateSignature
{
	public:
	    bool DestinationReached; // 0x0 Size: 0x1
	    bool TimedOut; // 0x1 Size: 0x1
	    char UnknownData0[0x2]; // 0x2
	    struct FVector FinalTargetLocation; // 0x4 Size: 0xc

};

struct FApplyRootMotionMoveToForceDelegate__DelegateSignature
{
	public:

};

struct FApplyRootMotionRadialForceDelegate__DelegateSignature
{
	public:

};

struct FMoveToLocationDelegate__DelegateSignature
{
	public:

};

struct FNetworkSyncDelegate__DelegateSignature
{
	public:

};

struct FMontageWaitSimpleDelegate__DelegateSignature
{
	public:

};

struct FRepeatedActionDelegate__DelegateSignature
{
	public:
	    int ActionNumber; // 0x0 Size: 0x4

};

struct FSpawnActorDelegate__DelegateSignature
{
	public:
	    class AActor* SpawnedActor; // 0x0 Size: 0x8

};

struct FAbilityStateDelegate__DelegateSignature
{
	public:

};

struct FVisualizeTargetingDelegate__DelegateSignature
{
	public:

};

struct FWaitAbilityActivateDelegate__DelegateSignature
{
	public:
	    class UGameplayAbility* ActivatedAbility; // 0x0 Size: 0x8

};

struct FWaitAbilityCommitDelegate__DelegateSignature
{
	public:
	    class UGameplayAbility* ActivatedAbility; // 0x0 Size: 0x8

};

struct FWaitAttributeChangeDelegate__DelegateSignature
{
	public:

};

struct FWaitAttributeChangeRatioThresholdDelegate__DelegateSignature
{
	public:
	    bool bMatchesComparison; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float CurrentRatio; // 0x4 Size: 0x4

};

struct FWaitAttributeChangeThresholdDelegate__DelegateSignature
{
	public:
	    bool bMatchesComparison; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float CurrentValue; // 0x4 Size: 0x4

};

struct FWaitCancelDelegate__DelegateSignature
{
	public:

};

struct FWaitConfirmCancelDelegate__DelegateSignature
{
	public:

};

struct FWaitDelayDelegate__DelegateSignature
{
	public:

};

struct FActiveGameplayEffectHandle
{
	public:
	    int Handle; // 0x0 Size: 0x4
	    bool bPassedFiltersAndWasExecuted; // 0x4 Size: 0x1
	    char UnknownData0[0x3];

};

struct FGameplayEffectSpecHandle
{
	public:
	    char UnknownData0[0x10];

};

struct FGameplayEffectAppliedSelfDelegate__DelegateSignature
{
	public:
	    class AActor* Source; // 0x0 Size: 0x8
	    struct FGameplayEffectSpecHandle SpecHandle; // 0x8 Size: 0x10
	    struct FActiveGameplayEffectHandle ActiveHandle; // 0x18 Size: 0x8

};

struct FGameplayEffectAppliedTargetDelegate__DelegateSignature
{
	public:
	    class AActor* Target; // 0x0 Size: 0x8
	    struct FGameplayEffectSpecHandle SpecHandle; // 0x8 Size: 0x10
	    struct FActiveGameplayEffectHandle ActiveHandle; // 0x18 Size: 0x8

};

struct FGameplayEffectBlockedDelegate__DelegateSignature
{
	public:
	    struct FGameplayEffectSpecHandle BlockedSpec; // 0x0 Size: 0x10
	    struct FActiveGameplayEffectHandle ImmunityGameplayEffectHandle; // 0x10 Size: 0x8

};

struct FGameplayEffectRemovalInfo
{
	public:
	    bool bPrematureRemoval; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    int StackCount; // 0x4 Size: 0x4
	    struct FGameplayEffectContextHandle EffectContext; // 0x8 Size: 0x18

};

struct FWaitGameplayEffectRemovedDelegate__DelegateSignature
{
	public:
	    struct FGameplayEffectRemovalInfo GameplayEffectRemovalInfo; // 0x0 Size: 0x20

};

struct FWaitGameplayEffectStackChangeDelegate__DelegateSignature
{
	public:
	    struct FActiveGameplayEffectHandle Handle; // 0x0 Size: 0x8
	    int NewCount; // 0x8 Size: 0x4
	    int OldCount; // 0xc Size: 0x4

};

struct FGameplayAbilityTargetDataHandle
{
	public:
	    char UnknownData0[0x20];

};

struct FWaitGameplayTagDelegate__DelegateSignature
{
	public:

};

struct FInputPressDelegate__DelegateSignature
{
	public:
	    float TimeWaited; // 0x0 Size: 0x4

};

struct FInputReleaseDelegate__DelegateSignature
{
	public:
	    float TimeHeld; // 0x0 Size: 0x4

};

struct FMovementModeChangedDelegate__DelegateSignature
{
	public:
	    char NewMovementMode; // 0x0 Size: 0x1

};

struct FWaitOverlapDelegate__DelegateSignature
{
	public:
	    struct FGameplayAbilityTargetDataHandle TargetData; // 0x0 Size: 0x20

};

struct FWaitTargetDataDelegate__DelegateSignature
{
	public:
	    struct FGameplayAbilityTargetDataHandle Data; // 0x0 Size: 0x20

};

struct FWaitVelocityChangeDelegate__DelegateSignature
{
	public:

};

struct FGameplayAbilityActivationInfo
{
	public:
	    char ActivationMode; // 0x0 Size: 0x1
	    bool bCanBeEndedByOtherInstance; // 0x1 Size: 0x1
	    char UnknownData0[0x6]; // 0x2
	    struct FPredictionKey PredictionKeyWhenActivated; // 0x8 Size: 0x18

};



enum class EGameplayAbilityActivationMode : uint8_t
{
    Authority = 0,
    NonAuthority = 1,
    Predicting = 2,
    Confirmed = 3,
    Rejected = 4,
    EGameplayAbilityActivationMode_MAX = 5
};

enum class EAbilityGenericReplicatedEvent : uint8_t
{
    GenericConfirm = 0,
    GenericCancel = 1,
    InputPressed = 2,
    InputReleased = 3,
    GenericSignalFromClient = 4,
    GenericSignalFromServer = 5,
    GameCustom1 = 6,
    GameCustom2 = 7,
    GameCustom3 = 8,
    GameCustom4 = 9,
    GameCustom5 = 10,
    GameCustom6 = 11,
    MAX = 12
};struct FServerAbilityRPCBatch
{
	public:
	    struct FGameplayAbilitySpecHandle AbilitySpecHandle; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    struct FPredictionKey PredictionKey; // 0x8 Size: 0x18
	    struct FGameplayAbilityTargetDataHandle TargetData; // 0x20 Size: 0x20
	    bool InputPressed; // 0x40 Size: 0x1
	    bool Ended; // 0x41 Size: 0x1
	    bool Started; // 0x42 Size: 0x1
	    char UnknownData1[0x5];

};

struct FReplicatedPredictionKeyItem : public FFastArraySerializerItem
{
	public:
	    char UnknownData0[0x4];
	    struct FPredictionKey PredictionKey; // 0x10 Size: 0x18

};

struct FMinimalReplicationTagCountMap
{
	public:
	    class UAbilitySystemComponent* Owner; // 0x50 Size: 0x8
	    char UnknownData0[0x8];

};

struct FGameplayAbilityLocalAnimMontage
{
	public:
	    class UAnimMontage* AnimMontage; // 0x0 Size: 0x8
	    bool PlayBit; // 0x8 Size: 0x1
	    char UnknownData0[0x7]; // 0x9
	    struct FPredictionKey PredictionKey; // 0x10 Size: 0x18
	    class UGameplayAbility* AnimatingAbility; // 0x28 Size: 0x8

};

struct FGameplayAbilityRepAnimMontage
{
	public:
	    class UAnimMontage* AnimMontage; // 0x0 Size: 0x8
	    float PlayRate; // 0x8 Size: 0x4
	    float Position; // 0xc Size: 0x4
	    float BlendTime; // 0x10 Size: 0x4
	    char NextSectionID; // 0x14 Size: 0x1
	    bool IsStopped; // 0x15 Size: 0x1
	    bool ForcePlayBit; // 0x15 Size: 0x1
	    bool SkipPositionCorrection; // 0x15 Size: 0x1
	    bool bSkipPlayRate; // 0x15 Size: 0x1
	    Yea, we fucked up; // 0x0
	    struct FPredictionKey PredictionKey; // 0x18 Size: 0x18

};

struct FAttributeDefaults
{
	public:
	    class UAttributeSet* Attributes; // 0x0 Size: 0x8
	    class UDataTable* DefaultStartingTable; // 0x8 Size: 0x8

};



enum class EGameplayEffectReplicationMode : uint8_t
{
    Minimal = 0,
    Mixed = 1,
    Full = 2,
    EGameplayEffectReplicationMode_MAX = 3
};

enum class EAbilityTaskWaitState : uint8_t
{
    WaitingOnGame = 1,
    WaitingOnUser = 2,
    WaitingOnAvatar = 4,
    EAbilityTaskWaitState_MAX = 5
};

enum class ERootMotionMoveToActorTargetOffsetType : uint8_t
{
    AlignFromTargetToSource = 0,
    AlignToTargetForward = 1,
    AlignToWorldSpace = 2,
    ERootMotionMoveToActorTargetOffsetType_MAX = 3
};

enum class EAbilityTaskNetSyncType : uint8_t
{
    BothWait = 0,
    OnlyServerWait = 1,
    OnlyClientWait = 2,
    EAbilityTaskNetSyncType_MAX = 3
};

enum class EWaitAttributeChangeComparison : uint8_t
{
    None = 0,
    GreaterThan = 1,
    LessThan = 2,
    GreaterThanOrEqualTo = 3,
    LessThanOrEqualTo = 4,
    NotEqualTo = 5,
    ExactlyEqualTo = 6,
    MAX = 7
};

enum class EGameplayAbilityInputBinds : uint8_t
{
    Ability1 = 0,
    Ability2 = 1,
    Ability3 = 2,
    Ability4 = 3,
    Ability5 = 4,
    Ability6 = 5,
    Ability7 = 6,
    Ability8 = 7,
    Ability9 = 8,
    EGameplayAbilityInputBinds_MAX = 9
};

enum class ETargetDataFilterSelf : uint8_t
{
    TDFS_Any = 0,
    TDFS_NoSelf = 1,
    TDFS_NoOthers = 2,
    TDFS_MAX = 3
};

enum class EGameplayAbilityTargetingLocationType : uint8_t
{
    LiteralTransform = 0,
    ActorTransform = 1,
    SocketTransform = 2,
    EGameplayAbilityTargetingLocationType_MAX = 3
};

enum class EGameplayTargetingConfirmation : uint8_t
{
    Instant = 0,
    UserConfirmed = 1,
    Custom = 2,
    CustomMulti = 3,
    EGameplayTargetingConfirmation_MAX = 4
};

enum class EGameplayAbilityTriggerSource : uint8_t
{
    GameplayEvent = 0,
    OwnedTagAdded = 1,
    OwnedTagPresent = 2,
    EGameplayAbilityTriggerSource_MAX = 3
};

enum class EGameplayAbilityReplicationPolicy : uint8_t
{
    ReplicateNo = 0,
    ReplicateYes = 1,
    EGameplayAbilityReplicationPolicy_MAX = 2
};

enum class EGameplayAbilityNetExecutionPolicy : uint8_t
{
    LocalPredicted = 0,
    LocalOnly = 1,
    ServerInitiated = 2,
    ServerOnly = 3,
    EGameplayAbilityNetExecutionPolicy_MAX = 4
};

enum class EGameplayAbilityInstancingPolicy : uint8_t
{
    NonInstanced = 0,
    InstancedPerActor = 1,
    InstancedPerExecution = 2,
    EGameplayAbilityInstancingPolicy_MAX = 3
};

enum class EGameplayCuePayloadType : uint8_t
{
    EffectContext = 0,
    CueParameters = 1,
    FromSpec = 2,
    EGameplayCuePayloadType_MAX = 3
};

enum class EGameplayEffectStackingExpirationPolicy : uint8_t
{
    ClearEntireStack = 0,
    RemoveSingleStackAndRefreshDuration = 1,
    RefreshDuration = 2,
    EGameplayEffectStackingExpirationPolicy_MAX = 3
};

enum class EGameplayEffectStackingPeriodPolicy : uint8_t
{
    ResetOnSuccessfulApplication = 0,
    NeverReset = 1,
    EGameplayEffectStackingPeriodPolicy_MAX = 2
};

enum class EGameplayEffectStackingDurationPolicy : uint8_t
{
    RefreshOnSuccessfulApplication = 0,
    NeverRefresh = 1,
    EGameplayEffectStackingDurationPolicy_MAX = 2
};

enum class EGameplayEffectDurationType : uint8_t
{
    Instant = 0,
    Infinite = 1,
    HasDuration = 2,
    EGameplayEffectDurationType_MAX = 3
};

enum class EAttributeBasedFloatCalculationType : uint8_t
{
    AttributeMagnitude = 0,
    AttributeBaseValue = 1,
    AttributeBonusMagnitude = 2,
    AttributeMagnitudeEvaluatedUpToChannel = 3,
    EAttributeBasedFloatCalculationType_MAX = 4
};

enum class EGameplayEffectMagnitudeCalculation : uint8_t
{
    ScalableFloat = 0,
    AttributeBased = 1,
    CustomCalculationClass = 2,
    SetByCaller = 3,
    EGameplayEffectMagnitudeCalculation_MAX = 4
};

enum class EGameplayTagEventType : uint8_t
{
    NewOrRemoved = 0,
    AnyCountChange = 1,
    EGameplayTagEventType_MAX = 2
};

enum class EGameplayCueEvent : uint8_t
{
    OnActive = 0,
    WhileActive = 1,
    Executed = 2,
    Removed = 3,
    EGameplayCueEvent_MAX = 4
};

enum class EGameplayEffectStackingType : uint8_t
{
    None = 0,
    AggregateBySource = 1,
    AggregateByTarget = 2,
    EGameplayEffectStackingType_MAX = 3
};

enum class EGameplayModOp : uint8_t
{
    Additive = 0,
    Multiplicitive = 1,
    Division = 2,
    Override = 3,
    Max = 4
};

enum class EGameplayModEvaluationChannel : uint8_t
{
    Channel0 = 0,
    Channel1 = 1,
    Channel2 = 2,
    Channel3 = 3,
    Channel4 = 4,
    Channel5 = 5,
    Channel6 = 6,
    Channel7 = 7,
    Channel8 = 8,
    Channel9 = 9,
    Channel_MAX = 10,
    EGameplayModEvaluationChannel_MAX = 11
};struct FAttributeMetaData : public FTableRowBase
{
	public:
	    float BaseValue; // 0x8 Size: 0x4
	    float MinValue; // 0xc Size: 0x4
	    float MaxValue; // 0x10 Size: 0x4
	    char UnknownData0[0x4]; // 0x14
	    struct FString DerivedAttributeInfo; // 0x18 Size: 0x10
	    bool bCanStack; // 0x28 Size: 0x1
	    char UnknownData1[0x7];

};

struct FGameplayAttributeData
{
	public:
	    float BaseValue; // 0x8 Size: 0x4
	    float CurrentValue; // 0xc Size: 0x4

};

struct FAbilityTriggerData
{
	public:
	    struct FGameplayTag TriggerTag; // 0x0 Size: 0x8
	    char TriggerSource; // 0x8 Size: 0x1
	    char UnknownData0[0x3];

};

struct FGameplayAbilityBindInfo
{
	public:
	    char Command; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class UGameplayAbility* GameplayAbilityClass; // 0x8 Size: 0x8

};

struct FGameplayTargetDataFilterHandle
{
	public:
	    char UnknownData0[0x10];

};

struct FGameplayTargetDataFilter
{
	public:
	    class AActor* SelfActor; // 0x8 Size: 0x8
	    char SelfFilter; // 0x10 Size: 0x1
	    char UnknownData0[0x7]; // 0x11
	    class AActor* RequiredActorClass; // 0x18 Size: 0x8
	    bool bReverseFilter; // 0x20 Size: 0x1
	    char UnknownData1[0x7];

};

struct FGameplayAbilityTargetData
{
	public:
	    char UnknownData0[0x8];

};

struct FGameplayAbilityTargetData_SingleTargetHit : public FGameplayAbilityTargetData
{
	public:
	    struct FHitResult HitResult; // 0x8 Size: 0x88

};

struct FGameplayAbilityTargetingLocationInfo
{
	public:
	    char LocationType; // 0x10 Size: 0x1
	    char UnknownData0[0xf]; // 0x11
	    struct FTransform LiteralTransform; // 0x20 Size: 0x30
	    class AActor* SourceActor; // 0x50 Size: 0x8
	    class UMeshComponent* SourceComponent; // 0x58 Size: 0x8
	    class UGameplayAbility* SourceAbility; // 0x60 Size: 0x8
	    FName SourceSocketName; // 0x68 Size: 0x8

};

struct FGameplayAbilityTargetData_LocationInfo : public FGameplayAbilityTargetData
{
	public:
	    char UnknownData0[0x8];
	    struct FGameplayAbilityTargetingLocationInfo SourceLocation; // 0x10 Size: 0x70
	    struct FGameplayAbilityTargetingLocationInfo TargetLocation; // 0x80 Size: 0x70

};

struct FGameplayAbilitySpecHandleAndPredictionKey
{
	public:
	    struct FGameplayAbilitySpecHandle AbilityHandle; // 0x0 Size: 0x4
	    int PredictionKeyAtCreation; // 0x4 Size: 0x4

};

struct FAbilityTaskDebugMessage
{
	public:
	    class UGameplayTask* FromTask; // 0x0 Size: 0x8
	    struct FString MESSAGE; // 0x8 Size: 0x10

};

struct FAbilityEndedData
{
	public:
	    class UGameplayAbility* AbilityThatEnded; // 0x0 Size: 0x8
	    struct FGameplayAbilitySpecHandle AbilitySpecHandle; // 0x8 Size: 0x4
	    bool bReplicateEndAbility; // 0xc Size: 0x1
	    bool bWasCancelled; // 0xd Size: 0x1
	    char UnknownData0[0x2];

};

struct FGameplayAbilityActorInfo
{
	public:
	    TWeakObjectPtr<AActor*> OwnerActor; // 0x8 Size: 0x8
	    TWeakObjectPtr<AActor*> AvatarActor; // 0x10 Size: 0x8
	    TWeakObjectPtr<APlayerController*> PlayerController; // 0x18 Size: 0x8
	    TWeakObjectPtr<UAbilitySystemComponent*> AbilitySystemComponent; // 0x20 Size: 0x8
	    TWeakObjectPtr<USkeletalMeshComponent*> SkeletalMeshComponent; // 0x28 Size: 0x8
	    TWeakObjectPtr<UAnimInstance*> AnimInstance; // 0x30 Size: 0x8
	    TWeakObjectPtr<UMovementComponent*> MovementComponent; // 0x38 Size: 0x8

};

struct FWorldReticleParameters
{
	public:
	    struct FVector AOEScale; // 0x0 Size: 0xc

};

struct FMinimalGameplayCueReplicationProxy
{
	public:
	    class UAbilitySystemComponent* Owner; // 0x1b0 Size: 0x8
	    char UnknownData0[0x8];

};

struct FGameplayCueTag
{
	public:
	    struct FGameplayTag GameplayCueTag; // 0x0 Size: 0x8

};

struct FGameplayCueNotifyData
{
	public:
	    struct FGameplayTag GameplayCueTag; // 0x0 Size: 0x8
	    struct FSoftObjectPath GameplayCueNotifyObj; // 0x8 Size: 0x18
	    class UObject* LoadedGameplayCueClass; // 0x20 Size: 0x8
	    char UnknownData0[0x8];

};

struct FGameplayCueTranslatorNodeIndex
{
	public:
	    int Index; // 0x0 Size: 0x4

};

struct FGameplayCueTranslationLink
{
	public:
	    class UGameplayCueTranslator* RulesCDO; // 0x0 Size: 0x8
	    char UnknownData0[0x10];

};

struct FActiveGameplayEffectQuery
{
	public:
	    char UnknownData0[0x70];

};

struct FGameplayModEvaluationChannelSettings
{
	public:
	    EGameplayModEvaluationChannel Channel; // 0x0 Size: 0x1

};

struct FSetByCallerFloat
{
	public:
	    FName DataName; // 0x0 Size: 0x8
	    struct FGameplayTag DataTag; // 0x8 Size: 0x8

};

struct FCustomCalculationBasedFloat
{
	public:
	    class UGameplayModMagnitudeCalculation* CalculationClassMagnitude; // 0x0 Size: 0x8
	    struct FScalableFloat Coefficient; // 0x8 Size: 0x20
	    struct FScalableFloat PreMultiplyAdditiveValue; // 0x28 Size: 0x20
	    struct FScalableFloat PostMultiplyAdditiveValue; // 0x48 Size: 0x20
	    struct FCurveTableRowHandle FinalLookupCurve; // 0x68 Size: 0x10

};

struct FGameplayModifierEvaluatedData
{
	public:
	    struct FGameplayAttribute Attribute; // 0x0 Size: 0x20
	    char ModifierOp; // 0x20 Size: 0x1
	    char UnknownData0[0x3]; // 0x21
	    float Magnitude; // 0x24 Size: 0x4
	    struct FActiveGameplayEffectHandle Handle; // 0x28 Size: 0x8
	    bool IsValid; // 0x30 Size: 0x1
	    char UnknownData1[0x7];

};

struct FGameplayEffectCustomExecutionParameters
{
	public:
	    char UnknownData0[0xa8];

};


}