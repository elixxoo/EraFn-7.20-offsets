#include "../SDK.hpp"

void UTimeSynthComponent::StopSoundsOnVolumeGroupWithFadeOverride(class UTimeSynthVolumeGroup* InVolumeGroup, ETimeSynthEventClipQuantization EventQuantization, struct FTimeSynthTimeDef FadeTime)
{
	struct {
            class UTimeSynthVolumeGroup* InVolumeGroup;
            ETimeSynthEventClipQuantization EventQuantization;
            struct FTimeSynthTimeDef FadeTime;
	} params{ InVolumeGroup, EventQuantization, FadeTime };

    static auto fn = UObject::FindObject("/Script/TimeSynth.TimeSynthComponent:StopSoundsOnVolumeGroupWithFadeOverride");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTimeSynthComponent::StopSoundsOnVolumeGroup(class UTimeSynthVolumeGroup* InVolumeGroup, ETimeSynthEventClipQuantization EventQuantization)
{
	struct {
            class UTimeSynthVolumeGroup* InVolumeGroup;
            ETimeSynthEventClipQuantization EventQuantization;
	} params{ InVolumeGroup, EventQuantization };

    static auto fn = UObject::FindObject("/Script/TimeSynth.TimeSynthComponent:StopSoundsOnVolumeGroup");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTimeSynthComponent::StopClipWithFadeOverride(struct FTimeSynthClipHandle InClipHandle, ETimeSynthEventClipQuantization EventQuantization, struct FTimeSynthTimeDef FadeTime)
{
	struct {
            struct FTimeSynthClipHandle InClipHandle;
            ETimeSynthEventClipQuantization EventQuantization;
            struct FTimeSynthTimeDef FadeTime;
	} params{ InClipHandle, EventQuantization, FadeTime };

    static auto fn = UObject::FindObject("/Script/TimeSynth.TimeSynthComponent:StopClipWithFadeOverride");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTimeSynthComponent::StopClip(struct FTimeSynthClipHandle InClipHandle, ETimeSynthEventClipQuantization EventQuantization)
{
	struct {
            struct FTimeSynthClipHandle InClipHandle;
            ETimeSynthEventClipQuantization EventQuantization;
	} params{ InClipHandle, EventQuantization };

    static auto fn = UObject::FindObject("/Script/TimeSynth.TimeSynthComponent:StopClip");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTimeSynthComponent::SetVolumeGroup(class UTimeSynthVolumeGroup* InVolumeGroup, float VolumeDb, float FadeTimeSec)
{
	struct {
            class UTimeSynthVolumeGroup* InVolumeGroup;
            float VolumeDb;
            float FadeTimeSec;
	} params{ InVolumeGroup, VolumeDb, FadeTimeSec };

    static auto fn = UObject::FindObject("/Script/TimeSynth.TimeSynthComponent:SetVolumeGroup");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTimeSynthComponent::SetSeed(int InSeed)
{
	struct {
            int InSeed;
	} params{ InSeed };

    static auto fn = UObject::FindObject("/Script/TimeSynth.TimeSynthComponent:SetSeed");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTimeSynthComponent::SetQuantizationSettings(struct FTimeSynthQuantizationSettings InQuantizationSettings)
{
	struct {
            struct FTimeSynthQuantizationSettings InQuantizationSettings;
	} params{ InQuantizationSettings };

    static auto fn = UObject::FindObject("/Script/TimeSynth.TimeSynthComponent:SetQuantizationSettings");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTimeSynthComponent::SetFilterSettings(ETimeSynthFilter Filter, struct FTimeSynthFilterSettings InSettings)
{
	struct {
            ETimeSynthFilter Filter;
            struct FTimeSynthFilterSettings InSettings;
	} params{ Filter, InSettings };

    static auto fn = UObject::FindObject("/Script/TimeSynth.TimeSynthComponent:SetFilterSettings");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTimeSynthComponent::SetFilterEnabled(ETimeSynthFilter Filter, bool bIsEnabled)
{
	struct {
            ETimeSynthFilter Filter;
            bool bIsEnabled;
	} params{ Filter, bIsEnabled };

    static auto fn = UObject::FindObject("/Script/TimeSynth.TimeSynthComponent:SetFilterEnabled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTimeSynthComponent::SetFFTSize(ETimeSynthFFTSize InFFTSize)
{
	struct {
            ETimeSynthFFTSize InFFTSize;
	} params{ InFFTSize };

    static auto fn = UObject::FindObject("/Script/TimeSynth.TimeSynthComponent:SetFFTSize");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTimeSynthComponent::SetEnvelopeFollowerSettings(struct FTimeSynthEnvelopeFollowerSettings InSettings)
{
	struct {
            struct FTimeSynthEnvelopeFollowerSettings InSettings;
	} params{ InSettings };

    static auto fn = UObject::FindObject("/Script/TimeSynth.TimeSynthComponent:SetEnvelopeFollowerSettings");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTimeSynthComponent::SetEnvelopeFollowerEnabled(bool bInIsEnabled)
{
	struct {
            bool bInIsEnabled;
	} params{ bInIsEnabled };

    static auto fn = UObject::FindObject("/Script/TimeSynth.TimeSynthComponent:SetEnvelopeFollowerEnabled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTimeSynthComponent::SetBPM(float BeatsPerMinute)
{
	struct {
            float BeatsPerMinute;
	} params{ BeatsPerMinute };

    static auto fn = UObject::FindObject("/Script/TimeSynth.TimeSynthComponent:SetBPM");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTimeSynthComponent::ResetSeed()
{
    static auto fn = UObject::FindObject("/Script/TimeSynth.TimeSynthComponent:ResetSeed");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


struct FTimeSynthClipHandle UTimeSynthComponent::PlayClip(class UTimeSynthClip* InClip, class UTimeSynthVolumeGroup* InVolumeGroup)
{
	struct {
            class UTimeSynthClip* InClip;
            class UTimeSynthVolumeGroup* InVolumeGroup;
            struct FTimeSynthClipHandle ReturnValue;
	} params{ InClip, InVolumeGroup };

    static auto fn = UObject::FindObject("/Script/TimeSynth.TimeSynthComponent:PlayClip");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


TArray<struct FTimeSynthSpectralData> UTimeSynthComponent::GetSpectralData()
{
	struct {
            TArray<struct FTimeSynthSpectralData> ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/TimeSynth.TimeSynthComponent:GetSpectralData");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UTimeSynthComponent::GetEnvelopeFollowerValue()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/TimeSynth.TimeSynthComponent:GetEnvelopeFollowerValue");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


int UTimeSynthComponent::GetBPM()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/TimeSynth.TimeSynthComponent:GetBPM");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UTimeSynthComponent::AddQuantizationEventDelegate(ETimeSynthEventQuantization QuantizationType, __int64/*DelegateProperty*/ OnQuantizationEvent)
{
	struct {
            ETimeSynthEventQuantization QuantizationType;
            __int64/*DelegateProperty*/ OnQuantizationEvent;
	} params{ QuantizationType, OnQuantizationEvent };

    static auto fn = UObject::FindObject("/Script/TimeSynth.TimeSynthComponent:AddQuantizationEventDelegate");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

