#pragma once

#include "../SDK.hpp"

namespace SDK {


class USidecarSys : public UObject
{
	public:
	    __int64/*MapProperty*/ FileInfoMap; // 0x28 Size: 0x50
	    struct FString DssDownloadUrl; // 0x78 Size: 0x10
	    struct FString DssCheckoutUrl; // 0x88 Size: 0x10
	    struct FString DssUploadUrl; // 0x98 Size: 0x10
	    struct FString DssRestoreUrl; // 0xa8 Size: 0x10
	    struct FString DssCheckinUrl; // 0xb8 Size: 0x10
	    char UnknownData0[0x10];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/SidecarSys.SidecarSys");
			return (class UClass*)ptr;
		};

};


}