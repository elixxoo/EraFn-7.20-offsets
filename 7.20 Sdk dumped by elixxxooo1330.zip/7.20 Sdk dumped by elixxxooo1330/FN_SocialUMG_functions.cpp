#include "../SDK.hpp"

void USocialChatContainer::SendCurrentMessage()
{
    static auto fn = UObject::FindObject("/Script/SocialUMG.SocialChatContainer:SendCurrentMessage");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void USocialChatContainer::OnChatOpenChanged(bool bShouldBeOpen)
{
	struct {
            bool bShouldBeOpen;
	} params{ bShouldBeOpen };

    static auto fn = UObject::FindObject("/Script/SocialUMG.SocialChatContainer:OnChatOpenChanged");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USocialChatContainer::HandleRightTabPressed()
{
    static auto fn = UObject::FindObject("/Script/SocialUMG.SocialChatContainer:HandleRightTabPressed");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void USocialChatContainer::HandleLeftTabPressed()
{
    static auto fn = UObject::FindObject("/Script/SocialUMG.SocialChatContainer:HandleLeftTabPressed");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void USocialChatContainer::FocusEditableText()
{
    static auto fn = UObject::FindObject("/Script/SocialUMG.SocialChatContainer:FocusEditableText");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void USocialChatContainer::DynamicHandleMessageTextCommitted(struct FText MessageText, char CommitMethod)
{
	struct {
            struct FText MessageText;
            char CommitMethod;
	} params{ MessageText, CommitMethod };

    static auto fn = UObject::FindObject("/Script/SocialUMG.SocialChatContainer:DynamicHandleMessageTextCommitted");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void USocialChatMessageEntry::OnMessageSet()
{
    static auto fn = UObject::FindObject("/Script/SocialUMG.SocialChatMessageEntry:OnMessageSet");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


bool USocialChatMessageEntry::CanInteract()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/SocialUMG.SocialChatMessageEntry:CanInteract");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void USocialInteractionButton::OnInteractionSet()
{
    static auto fn = UObject::FindObject("/Script/SocialUMG.SocialInteractionButton:OnInteractionSet");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


bool USocialInteractionButton::IsPlatformOnlyFriend()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/SocialUMG.SocialInteractionButton:IsPlatformOnlyFriend");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


FName USocialInteractionButton::GetInteractionName()
{
	struct {
            FName ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/SocialUMG.SocialInteractionButton:GetInteractionName");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void USocialInteractionMenu::OnToggleConfirmation(bool bIsVisible)
{
	struct {
            bool bIsVisible;
	} params{ bIsVisible };

    static auto fn = UObject::FindObject("/Script/SocialUMG.SocialInteractionMenu:OnToggleConfirmation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USocialInteractionMenu::OnSocialContextSet()
{
    static auto fn = UObject::FindObject("/Script/SocialUMG.SocialInteractionMenu:OnSocialContextSet");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


class UWidget* USocialInteractionMenu::GetFirstEntryToCenter()
{
	struct {
            class UWidget* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/SocialUMG.SocialInteractionMenu:GetFirstEntryToCenter");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

class UWidget* USocialListEntry::HandleGetMenuContent()
{
	struct {
            class UWidget* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/SocialUMG.SocialListEntry:HandleGetMenuContent");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void USocialUserListEntry::OnUserPresenceChanged(EOnlineStatus OnlineStatus)
{
	struct {
            EOnlineStatus OnlineStatus;
	} params{ OnlineStatus };

    static auto fn = UObject::FindObject("/Script/SocialUMG.SocialUserListEntry:OnUserPresenceChanged");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

