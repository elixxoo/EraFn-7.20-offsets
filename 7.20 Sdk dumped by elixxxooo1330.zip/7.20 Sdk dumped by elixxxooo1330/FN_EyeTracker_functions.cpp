#include "../SDK.hpp"

static void UEyeTrackerFunctionLibrary::SetEyeTrackedPlayer(class APlayerController* PlayerController)
{
	struct {
            class APlayerController* PlayerController;            void ReturnValue;
	} params{ PlayerController };

    static auto fn = UObject::FindObject("/Script/EyeTracker.EyeTrackerFunctionLibrary:SetEyeTrackedPlayer");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UEyeTrackerFunctionLibrary::IsStereoGazeDataAvailable()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/EyeTracker.EyeTrackerFunctionLibrary:IsStereoGazeDataAvailable");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static bool UEyeTrackerFunctionLibrary::IsEyeTrackerConnected()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/EyeTracker.EyeTrackerFunctionLibrary:IsEyeTrackerConnected");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


static bool UEyeTrackerFunctionLibrary::GetStereoGazeData(struct FEyeTrackerStereoGazeData OutGazeData)
{
	struct {
            struct FEyeTrackerStereoGazeData OutGazeData;
            bool ReturnValue;
	} params{ OutGazeData };

    static auto fn = UObject::FindObject("/Script/EyeTracker.EyeTrackerFunctionLibrary:GetStereoGazeData");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UEyeTrackerFunctionLibrary::GetGazeData(struct FEyeTrackerGazeData OutGazeData)
{
	struct {
            struct FEyeTrackerGazeData OutGazeData;
            bool ReturnValue;
	} params{ OutGazeData };

    static auto fn = UObject::FindObject("/Script/EyeTracker.EyeTrackerFunctionLibrary:GetGazeData");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

