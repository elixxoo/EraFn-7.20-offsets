#include "../SDK.hpp"

static bool UAndroidPermissionFunctionLibrary::CheckPermission(struct FString Permission)
{
	struct {
            struct FString Permission;
            bool ReturnValue;
	} params{ Permission };

    static auto fn = UObject::FindObject("/Script/AndroidPermission.AndroidPermissionFunctionLibrary:CheckPermission");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UAndroidPermissionCallbackProxy* UAndroidPermissionFunctionLibrary::AcquirePermissions(TArray<struct FString> Permissions)
{
	struct {
            TArray<struct FString> Permissions;
            class UAndroidPermissionCallbackProxy* ReturnValue;
	} params{ Permissions };

    static auto fn = UObject::FindObject("/Script/AndroidPermission.AndroidPermissionFunctionLibrary:AcquirePermissions");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

