#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FJsonObjectWrapper
{
	public:
	    struct FString JsonString; // 0x0 Size: 0x10
	    char UnknownData0[0x10];

};


}