#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FConnectionAlwaysRelevantNodePair
{
	public:
	    class UNetConnection* NetConnection; // 0x0 Size: 0x8
	    class UReplicationGraphNode_AlwaysRelevant_ForConnection* Node; // 0x8 Size: 0x8

};

struct FTearOffActorInfo
{
	public:
	    class AActor* Actor; // 0x8 Size: 0x8
	    char UnknownData0[0x8];

};


}