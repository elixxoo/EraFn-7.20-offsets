#include "../SDK.hpp"

void UNavigationSystemV1::UnregisterNavigationInvoker(class AActor* Invoker)
{
	struct {
            class AActor* Invoker;
	} params{ Invoker };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationSystemV1:UnregisterNavigationInvoker");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


static void UNavigationSystemV1::SimpleMoveToLocation(class AController* Controller, struct FVector Goal)
{
	struct {
            class AController* Controller;
            struct FVector Goal;            void ReturnValue;
	} params{ Controller, Goal };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationSystemV1:SimpleMoveToLocation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static void UNavigationSystemV1::SimpleMoveToActor(class AController* Controller, class AActor* Goal)
{
	struct {
            class AController* Controller;
            class AActor* Goal;            void ReturnValue;
	} params{ Controller, Goal };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationSystemV1:SimpleMoveToActor");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UNavigationSystemV1::SetMaxSimultaneousTileGenerationJobsCount(int MaxNumberOfJobs)
{
	struct {
            int MaxNumberOfJobs;
	} params{ MaxNumberOfJobs };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationSystemV1:SetMaxSimultaneousTileGenerationJobsCount");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNavigationSystemV1::SetGeometryGatheringMode(ENavDataGatheringModeConfig NewMode)
{
	struct {
            ENavDataGatheringModeConfig NewMode;
	} params{ NewMode };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationSystemV1:SetGeometryGatheringMode");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNavigationSystemV1::ResetMaxSimultaneousTileGenerationJobsCount()
{
    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationSystemV1:ResetMaxSimultaneousTileGenerationJobsCount");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}


void UNavigationSystemV1::RegisterNavigationInvoker(class AActor* Invoker, float TileGenerationRadius, float TileRemovalRadius)
{
	struct {
            class AActor* Invoker;
            float TileGenerationRadius;
            float TileRemovalRadius;
	} params{ Invoker, TileGenerationRadius, TileRemovalRadius };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationSystemV1:RegisterNavigationInvoker");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


static struct FVector UNavigationSystemV1::ProjectPointToNavigation(class UObject* WorldContextObject, struct FVector Point, class ANavigationData* NavData, class UNavigationQueryFilter* FilterClass, struct FVector QueryExtent)
{
	struct {
            class UObject* WorldContextObject;
            struct FVector Point;
            class ANavigationData* NavData;
            class UNavigationQueryFilter* FilterClass;
            struct FVector QueryExtent;
            struct FVector ReturnValue;
	} params{ WorldContextObject, Point, NavData, FilterClass, QueryExtent };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationSystemV1:ProjectPointToNavigation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


void UNavigationSystemV1::OnNavigationBoundsUpdated(class ANavMeshBoundsVolume* NavVolume)
{
	struct {
            class ANavMeshBoundsVolume* NavVolume;
	} params{ NavVolume };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationSystemV1:OnNavigationBoundsUpdated");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


static bool UNavigationSystemV1::NavigationRaycast(class UObject* WorldContextObject, struct FVector RayStart, struct FVector RayEnd, struct FVector HitLocation, class UNavigationQueryFilter* FilterClass, class AController* Querier)
{
	struct {
            class UObject* WorldContextObject;
            struct FVector RayStart;
            struct FVector RayEnd;
            struct FVector HitLocation;
            class UNavigationQueryFilter* FilterClass;
            class AController* Querier;
            bool ReturnValue;
	} params{ WorldContextObject, RayStart, RayEnd, HitLocation, FilterClass, Querier };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationSystemV1:NavigationRaycast");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UNavigationSystemV1::K2_ProjectPointToNavigation(class UObject* WorldContextObject, struct FVector Point, struct FVector ProjectedLocation, class ANavigationData* NavData, class UNavigationQueryFilter* FilterClass, struct FVector QueryExtent)
{
	struct {
            class UObject* WorldContextObject;
            struct FVector Point;
            struct FVector ProjectedLocation;
            class ANavigationData* NavData;
            class UNavigationQueryFilter* FilterClass;
            struct FVector QueryExtent;
            bool ReturnValue;
	} params{ WorldContextObject, Point, ProjectedLocation, NavData, FilterClass, QueryExtent };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationSystemV1:K2_ProjectPointToNavigation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UNavigationSystemV1::K2_GetRandomReachablePointInRadius(class UObject* WorldContextObject, struct FVector Origin, struct FVector RandomLocation, float Radius, class ANavigationData* NavData, class UNavigationQueryFilter* FilterClass)
{
	struct {
            class UObject* WorldContextObject;
            struct FVector Origin;
            struct FVector RandomLocation;
            float Radius;
            class ANavigationData* NavData;
            class UNavigationQueryFilter* FilterClass;
            bool ReturnValue;
	} params{ WorldContextObject, Origin, RandomLocation, Radius, NavData, FilterClass };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationSystemV1:K2_GetRandomReachablePointInRadius");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UNavigationSystemV1::K2_GetRandomPointInNavigableRadius(class UObject* WorldContextObject, struct FVector Origin, struct FVector RandomLocation, float Radius, class ANavigationData* NavData, class UNavigationQueryFilter* FilterClass)
{
	struct {
            class UObject* WorldContextObject;
            struct FVector Origin;
            struct FVector RandomLocation;
            float Radius;
            class ANavigationData* NavData;
            class UNavigationQueryFilter* FilterClass;
            bool ReturnValue;
	} params{ WorldContextObject, Origin, RandomLocation, Radius, NavData, FilterClass };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationSystemV1:K2_GetRandomPointInNavigableRadius");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UNavigationSystemV1::IsNavigationBeingBuiltOrLocked(class UObject* WorldContextObject)
{
	struct {
            class UObject* WorldContextObject;
            bool ReturnValue;
	} params{ WorldContextObject };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationSystemV1:IsNavigationBeingBuiltOrLocked");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static bool UNavigationSystemV1::IsNavigationBeingBuilt(class UObject* WorldContextObject)
{
	struct {
            class UObject* WorldContextObject;
            bool ReturnValue;
	} params{ WorldContextObject };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationSystemV1:IsNavigationBeingBuilt");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FVector UNavigationSystemV1::GetRandomReachablePointInRadius(class UObject* WorldContextObject, struct FVector Origin, float Radius, class ANavigationData* NavData, class UNavigationQueryFilter* FilterClass)
{
	struct {
            class UObject* WorldContextObject;
            struct FVector Origin;
            float Radius;
            class ANavigationData* NavData;
            class UNavigationQueryFilter* FilterClass;
            struct FVector ReturnValue;
	} params{ WorldContextObject, Origin, Radius, NavData, FilterClass };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationSystemV1:GetRandomReachablePointInRadius");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static struct FVector UNavigationSystemV1::GetRandomPointInNavigableRadius(class UObject* WorldContextObject, struct FVector Origin, float Radius, class ANavigationData* NavData, class UNavigationQueryFilter* FilterClass)
{
	struct {
            class UObject* WorldContextObject;
            struct FVector Origin;
            float Radius;
            class ANavigationData* NavData;
            class UNavigationQueryFilter* FilterClass;
            struct FVector ReturnValue;
	} params{ WorldContextObject, Origin, Radius, NavData, FilterClass };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationSystemV1:GetRandomPointInNavigableRadius");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static char UNavigationSystemV1::GetPathLength(class UObject* WorldContextObject, struct FVector PathStart, struct FVector PathEnd, float PathLength, class ANavigationData* NavData, class UNavigationQueryFilter* FilterClass)
{
	struct {
            class UObject* WorldContextObject;
            struct FVector PathStart;
            struct FVector PathEnd;
            float PathLength;
            class ANavigationData* NavData;
            class UNavigationQueryFilter* FilterClass;
            char ReturnValue;
	} params{ WorldContextObject, PathStart, PathEnd, PathLength, NavData, FilterClass };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationSystemV1:GetPathLength");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static char UNavigationSystemV1::GetPathCost(class UObject* WorldContextObject, struct FVector PathStart, struct FVector PathEnd, float PathCost, class ANavigationData* NavData, class UNavigationQueryFilter* FilterClass)
{
	struct {
            class UObject* WorldContextObject;
            struct FVector PathStart;
            struct FVector PathEnd;
            float PathCost;
            class ANavigationData* NavData;
            class UNavigationQueryFilter* FilterClass;
            char ReturnValue;
	} params{ WorldContextObject, PathStart, PathEnd, PathCost, NavData, FilterClass };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationSystemV1:GetPathCost");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UNavigationSystemV1* UNavigationSystemV1::GetNavigationSystem(class UObject* WorldContextObject)
{
	struct {
            class UObject* WorldContextObject;
            class UNavigationSystemV1* ReturnValue;
	} params{ WorldContextObject };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationSystemV1:GetNavigationSystem");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UNavigationPath* UNavigationSystemV1::FindPathToLocationSynchronously(class UObject* WorldContextObject, struct FVector PathStart, struct FVector PathEnd, class AActor* PathfindingContext, class UNavigationQueryFilter* FilterClass)
{
	struct {
            class UObject* WorldContextObject;
            struct FVector PathStart;
            struct FVector PathEnd;
            class AActor* PathfindingContext;
            class UNavigationQueryFilter* FilterClass;
            class UNavigationPath* ReturnValue;
	} params{ WorldContextObject, PathStart, PathEnd, PathfindingContext, FilterClass };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationSystemV1:FindPathToLocationSynchronously");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}


static class UNavigationPath* UNavigationSystemV1::FindPathToActorSynchronously(class UObject* WorldContextObject, struct FVector PathStart, class AActor* GoalActor, float TetherDistance, class AActor* PathfindingContext, class UNavigationQueryFilter* FilterClass)
{
	struct {
            class UObject* WorldContextObject;
            struct FVector PathStart;
            class AActor* GoalActor;
            float TetherDistance;
            class AActor* PathfindingContext;
            class UNavigationQueryFilter* FilterClass;
            class UNavigationPath* ReturnValue;
	} params{ WorldContextObject, PathStart, GoalActor, TetherDistance, PathfindingContext, FilterClass };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationSystemV1:FindPathToActorSynchronously");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

void UNavRelevantComponent::SetNavigationRelevancy(bool bRelevant)
{
	struct {
            bool bRelevant;
	} params{ bRelevant };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavRelevantComponent:SetNavigationRelevancy");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

bool UNavigationPath::IsValid()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationPath:IsValid");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UNavigationPath::IsStringPulled()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationPath:IsStringPulled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool UNavigationPath::IsPartial()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationPath:IsPartial");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UNavigationPath::GetPathLength()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationPath:GetPathLength");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UNavigationPath::GetPathCost()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationPath:GetPathCost");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


struct FString UNavigationPath::GetDebugString()
{
	struct {
            struct FString ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationPath:GetDebugString");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


void UNavigationPath::EnableRecalculationOnInvalidation(char DoRecalculation)
{
	struct {
            char DoRecalculation;
	} params{ DoRecalculation };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationPath:EnableRecalculationOnInvalidation");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UNavigationPath::EnableDebugDrawing(bool bShouldDrawDebugData, struct FLinearColor PathColor)
{
	struct {
            bool bShouldDrawDebugData;
            struct FLinearColor PathColor;
	} params{ bShouldDrawDebugData, PathColor };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavigationPath:EnableDebugDrawing");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void UNavModifierComponent::SetAreaClass(class UNavArea* NewAreaClass)
{
	struct {
            class UNavArea* NewAreaClass;
	} params{ NewAreaClass };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavModifierComponent:SetAreaClass");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

void ANavModifierVolume::SetAreaClass(class UNavArea* NewAreaClass)
{
	struct {
            class UNavArea* NewAreaClass;
	} params{ NewAreaClass };

    static auto fn = UObject::FindObject("/Script/NavigationSystem.NavModifierVolume:SetAreaClass");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

