#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class MovieScene3DPathSection_Axis : uint8_t
{
    X = 0,
    Y = 1,
    Z = 2,
    NEG_X = 3,
    NEG_Y = 4,
    NEG_Z = 5,
    MovieScene3DPathSection_MAX = 6
};

enum class EFireEventsAtPosition : uint8_t
{
    AtStartOfEvaluation = 0,
    AtEndOfEvaluation = 1,
    AfterSpawn = 2,
    EFireEventsAtPosition_MAX = 3
};

enum class ELevelVisibility : uint8_t
{
    Visible = 0,
    Hidden = 1,
    ELevelVisibility_MAX = 2
};

enum class EParticleKey : uint8_t
{
    Activate = 0,
    Deactivate = 1,
    Trigger = 2,
    EParticleKey_MAX = 3
};struct FMovieScene3DAttachSectionTemplate : public FMovieSceneEvalTemplate
{
	public:
	    struct FMovieSceneObjectBindingID AttachBindingID; // 0x20 Size: 0x18
	    FName AttachSocketName; // 0x38 Size: 0x8
	    FName AttachComponentName; // 0x40 Size: 0x8
	    EAttachmentRule AttachmentLocationRule; // 0x48 Size: 0x1
	    EAttachmentRule AttachmentRotationRule; // 0x49 Size: 0x1
	    EAttachmentRule AttachmentScaleRule; // 0x4a Size: 0x1
	    EDetachmentRule DetachmentLocationRule; // 0x4b Size: 0x1
	    EDetachmentRule DetachmentRotationRule; // 0x4c Size: 0x1
	    EDetachmentRule DetachmentScaleRule; // 0x4d Size: 0x1
	    char UnknownData0[0x2];

};

struct FMovieSceneTransformMask
{
	public:
	    uint32_t Mask; // 0x0 Size: 0x4

};

struct FMovieScene3DTransformKeyStruct : public FMovieSceneKeyStruct
{
	public:
	    struct FVector Location; // 0x8 Size: 0xc
	    struct FRotator Rotation; // 0x14 Size: 0xc
	    struct FVector Scale; // 0x20 Size: 0xc
	    struct FFrameNumber Time; // 0x2c Size: 0x4
	    char UnknownData0[0x18];

};

struct FMovieScene3DScaleKeyStruct : public FMovieSceneKeyStruct
{
	public:
	    struct FVector Scale; // 0x8 Size: 0xc
	    struct FFrameNumber Time; // 0x14 Size: 0x4
	    char UnknownData0[0x18];

};

struct FMovieScene3DRotationKeyStruct : public FMovieSceneKeyStruct
{
	public:
	    struct FRotator Rotation; // 0x8 Size: 0xc
	    struct FFrameNumber Time; // 0x14 Size: 0x4
	    char UnknownData0[0x18];

};

struct FMovieScene3DLocationKeyStruct : public FMovieSceneKeyStruct
{
	public:
	    struct FVector Location; // 0x8 Size: 0xc
	    struct FFrameNumber Time; // 0x14 Size: 0x4
	    char UnknownData0[0x18];

};

struct FMovieSceneActorReferenceKey
{
	public:
	    struct FMovieSceneObjectBindingID Object; // 0x0 Size: 0x18

};

struct FMovieSceneCameraAnimSectionData
{
	public:
	    class UCameraAnim* CameraAnim; // 0x0 Size: 0x8
	    float PlayRate; // 0x8 Size: 0x4
	    float PlayScale; // 0xc Size: 0x4
	    float BlendInTime; // 0x10 Size: 0x4
	    float BlendOutTime; // 0x14 Size: 0x4
	    bool bLooping; // 0x18 Size: 0x1
	    char UnknownData0[0x7];

};

struct FMovieSceneAdditiveCameraAnimationTemplate : public FMovieSceneEvalTemplate
{
	public:
	    char UnknownData0[0x20];

};

struct FMovieSceneCameraShakeSectionData
{
	public:
	    class UCameraShake* ShakeClass; // 0x0 Size: 0x8
	    float PlayScale; // 0x8 Size: 0x4
	    char PlaySpace; // 0xc Size: 0x1
	    char UnknownData0[0x3]; // 0xd
	    struct FRotator UserDefinedPlaySpace; // 0x10 Size: 0xc
	    char UnknownData1[0x4];

};

struct FMovieSceneCameraShakeSectionTemplate : public FMovieSceneAdditiveCameraAnimationTemplate
{
	public:
	    struct FMovieSceneCameraShakeSectionData SourceData; // 0x20 Size: 0x20
	    struct FFrameNumber SectionStartTime; // 0x40 Size: 0x4
	    char UnknownData0[0x4];

};

struct FMovieSceneCameraAnimSectionTemplate : public FMovieSceneAdditiveCameraAnimationTemplate
{
	public:
	    struct FMovieSceneCameraAnimSectionData SourceData; // 0x20 Size: 0x20
	    struct FFrameNumber SectionStartTime; // 0x40 Size: 0x4
	    char UnknownData0[0x4];

};

struct FMovieSceneCameraCutSectionTemplate : public FMovieSceneEvalTemplate
{
	public:
	    struct FMovieSceneObjectBindingID CameraBindingID; // 0x20 Size: 0x18
	    char UnknownData0[0x8]; // 0x38
	    struct FTransform CutTransform; // 0x40 Size: 0x30
	    bool bHasCutTransform; // 0x70 Size: 0x1
	    char UnknownData1[0xf];

};

struct FMovieSceneColorKeyStruct : public FMovieSceneKeyStruct
{
	public:
	    struct FLinearColor Color; // 0x8 Size: 0x10
	    struct FFrameNumber Time; // 0x18 Size: 0x4
	    char UnknownData0[0x1c];

};

struct FMovieSceneEvent
{
	public:
	    FName FunctionName; // 0x0 Size: 0x8

};

struct FMovieSceneEventParameters
{
	public:
	    char UnknownData0[0x28];

};

struct FEventPayload
{
	public:
	    FName EventName; // 0x0 Size: 0x8
	    struct FMovieSceneEventParameters Parameters; // 0x8 Size: 0x28

};

struct FMovieSceneEventRepeaterTemplate : public FMovieSceneEventTemplateBase
{
	public:
	    FName EventToTrigger; // 0x38 Size: 0x8

};

struct FMovieSceneMaterialParameterCollectionTemplate : public FMovieSceneParameterSectionTemplate
{
	public:
	    class UMaterialParameterCollection* MPC; // 0x50 Size: 0x8

};

struct FMovieSceneComponentMaterialSectionTemplate : public FMovieSceneParameterSectionTemplate
{
	public:
	    int MaterialIndex; // 0x50 Size: 0x4
	    char UnknownData0[0x4];

};

struct FMovieSceneParticleParameterSectionTemplate : public FMovieSceneParameterSectionTemplate
{
	public:
	    char UnknownData0[0x50];

};

struct FMovieSceneParticleChannel : public FMovieSceneByteChannel
{
	public:
	    char UnknownData0[0x98];

};

struct FMovieSceneParticleSectionTemplate : public FMovieSceneEvalTemplate
{
	public:
	    struct FMovieSceneParticleChannel ParticleKeys; // 0x20 Size: 0x98

};

struct FMovieSceneSkeletalAnimationSectionTemplateParameters : public FMovieSceneSkeletalAnimationParams
{
	public:
	    struct FFrameNumber SectionStartTime; // 0xc8 Size: 0x4
	    struct FFrameNumber SectionEndTime; // 0xcc Size: 0x4

};

struct FMovieSceneSkeletalAnimationSectionTemplate : public FMovieSceneEvalTemplate
{
	public:
	    struct FMovieSceneSkeletalAnimationSectionTemplateParameters Params; // 0x20 Size: 0xd0

};

struct FMovieSceneVectorKeyStructBase : public FMovieSceneKeyStruct
{
	public:
	    struct FFrameNumber Time; // 0x8 Size: 0x4
	    char UnknownData0[0x1c];

};

struct FMovieSceneVector4KeyStruct : public FMovieSceneVectorKeyStructBase
{
	public:
	    char UnknownData0[0x8];
	    struct FVector4 Vector; // 0x30 Size: 0x10

};

struct FMovieSceneVectorKeyStruct : public FMovieSceneVectorKeyStructBase
{
	public:
	    struct FVector Vector; // 0x28 Size: 0xc
	    char UnknownData0[0x4];

};

struct FMovieSceneVector2DKeyStruct : public FMovieSceneVectorKeyStructBase
{
	public:
	    struct FVector2D Vector; // 0x28 Size: 0x8

};

struct FMovieSceneVisibilitySectionTemplate : public FMovieSceneBoolPropertySectionTemplate
{
	public:
	    char UnknownData0[0xd8];

};


}