#pragma once

#include "../SDK.hpp"

namespace SDK {


class UClientPilotComponent : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ClientPilot.ClientPilotComponent");
			return (class UClass*)ptr;
		};

};

class UClientPilotBlackboard : public UObject
{
	public:
	    char UnknownData0[0x78];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ClientPilot.ClientPilotBlackboard");
			return (class UClass*)ptr;
		};

};

class UClientPilotBlackboardManager : public UObject
{
	public:
	    class UClientPilotBlackboard* PilotBlackboard; // 0x28 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ClientPilot.ClientPilotBlackboardManager");
			return (class UClass*)ptr;
		};

};


}