#pragma once

#include "../SDK.hpp"

namespace SDK {


class UBorder_ShellUberBG_C : public UCommonBorderStyle
{
	public:
	    char UnknownData0[0xb0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Game/UI/Foundation/Border/Border_ShellUberBG.Border_ShellUberBG_C");
			return (class UClass*)ptr;
		};

};

