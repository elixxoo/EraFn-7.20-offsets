#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FDefault__Struct
{
	public:

};

struct FDefault__Function
{
	public:

};

struct FDefault__DelegateFunction
{
	public:

};

struct FJoinabilitySettings
{
	public:
	    FName SessionName; // 0x0 Size: 0x8
	    bool bPublicSearchable; // 0x8 Size: 0x1
	    bool bAllowInvites; // 0x9 Size: 0x1
	    bool bJoinViaPresence; // 0xa Size: 0x1
	    bool bJoinViaPresenceFriendsOnly; // 0xb Size: 0x1
	    int MaxPlayers; // 0xc Size: 0x4
	    int MaxPartySize; // 0x10 Size: 0x4

};

struct FDefault__ScriptStruct
{
	public:

};

struct FUniqueNetIdWrapper
{
	public:
	    char UnknownData0[0x1];

};

struct FGuid
{
	public:
	    int A; // 0x0 Size: 0x4
	    int B; // 0x4 Size: 0x4
	    int C; // 0x8 Size: 0x4
	    int D; // 0xc Size: 0x4

};

struct FVector
{
	public:
	    float X; // 0x0 Size: 0x4
	    float Y; // 0x4 Size: 0x4
	    float Z; // 0x8 Size: 0x4

};

struct FVector4
{
	public:
	    float X; // 0x0 Size: 0x4
	    float Y; // 0x4 Size: 0x4
	    float Z; // 0x8 Size: 0x4
	    float W; // 0xc Size: 0x4

};

struct FVector2D
{
	public:
	    float X; // 0x0 Size: 0x4
	    float Y; // 0x4 Size: 0x4

};

struct FTwoVectors
{
	public:
	    struct FVector v1; // 0x0 Size: 0xc
	    struct FVector v2; // 0xc Size: 0xc

};

struct FPlane : public FVector
{
	public:
	    float W; // 0xc Size: 0x4

};

struct FRotator
{
	public:
	    float Pitch; // 0x0 Size: 0x4
	    float Yaw; // 0x4 Size: 0x4
	    float Roll; // 0x8 Size: 0x4

};

struct FQuat
{
	public:
	    float X; // 0x0 Size: 0x4
	    float Y; // 0x4 Size: 0x4
	    float Z; // 0x8 Size: 0x4
	    float W; // 0xc Size: 0x4

};

struct FPackedNormal
{
	public:
	    char X; // 0x0 Size: 0x1
	    char Y; // 0x1 Size: 0x1
	    char Z; // 0x2 Size: 0x1
	    char W; // 0x3 Size: 0x1

};

struct FPackedRGB10A2N
{
	public:
	    int Packed; // 0x0 Size: 0x4

};

struct FPackedRGBA16N
{
	public:
	    int XY; // 0x0 Size: 0x4
	    int ZW; // 0x4 Size: 0x4

};

struct FIntPoint
{
	public:
	    int X; // 0x0 Size: 0x4
	    int Y; // 0x4 Size: 0x4

};

struct FIntVector
{
	public:
	    int X; // 0x0 Size: 0x4
	    int Y; // 0x4 Size: 0x4
	    int Z; // 0x8 Size: 0x4

};

struct FColor
{
	public:
	    char B; // 0x0 Size: 0x1
	    char G; // 0x1 Size: 0x1
	    char R; // 0x2 Size: 0x1
	    char A; // 0x3 Size: 0x1

};

struct FLinearColor
{
	public:
	    float R; // 0x0 Size: 0x4
	    float G; // 0x4 Size: 0x4
	    float B; // 0x8 Size: 0x4
	    float A; // 0xc Size: 0x4

};

struct FBox
{
	public:
	    struct FVector Min; // 0x0 Size: 0xc
	    struct FVector Max; // 0xc Size: 0xc
	    char IsValid; // 0x18 Size: 0x1
	    char UnknownData0[0x3];

};

struct FBox2D
{
	public:
	    struct FVector2D Min; // 0x0 Size: 0x8
	    struct FVector2D Max; // 0x8 Size: 0x8
	    char bIsValid; // 0x10 Size: 0x1
	    char UnknownData0[0x3];

};

struct FBoxSphereBounds
{
	public:
	    struct FVector Origin; // 0x0 Size: 0xc
	    struct FVector BoxExtent; // 0xc Size: 0xc
	    float SphereRadius; // 0x18 Size: 0x4

};

struct FOrientedBox
{
	public:
	    struct FVector Center; // 0x0 Size: 0xc
	    struct FVector AxisX; // 0xc Size: 0xc
	    struct FVector AxisY; // 0x18 Size: 0xc
	    struct FVector AxisZ; // 0x24 Size: 0xc
	    float ExtentX; // 0x30 Size: 0x4
	    float ExtentY; // 0x34 Size: 0x4
	    float ExtentZ; // 0x38 Size: 0x4

};

struct FMatrix
{
	public:
	    struct FPlane XPlane; // 0x0 Size: 0x10
	    struct FPlane YPlane; // 0x10 Size: 0x10
	    struct FPlane ZPlane; // 0x20 Size: 0x10
	    struct FPlane WPlane; // 0x30 Size: 0x10

};

struct FInterpCurvePointFloat
{
	public:
	    float InVal; // 0x0 Size: 0x4
	    float OutVal; // 0x4 Size: 0x4
	    float ArriveTangent; // 0x8 Size: 0x4
	    float LeaveTangent; // 0xc Size: 0x4
	    char InterpMode; // 0x10 Size: 0x1
	    char UnknownData0[0x3];

};



enum class EInterpCurveMode : uint8_t
{
    CIM_Linear = 0,
    CIM_CurveAuto = 1,
    CIM_Constant = 2,
    CIM_CurveUser = 3,
    CIM_CurveBreak = 4,
    CIM_CurveAutoClamped = 5,
    CIM_MAX = 6
};struct FInterpCurvePointVector2D
{
	public:
	    float InVal; // 0x0 Size: 0x4
	    struct FVector2D OutVal; // 0x4 Size: 0x8
	    struct FVector2D ArriveTangent; // 0xc Size: 0x8
	    struct FVector2D LeaveTangent; // 0x14 Size: 0x8
	    char InterpMode; // 0x1c Size: 0x1
	    char UnknownData0[0x3];

};

struct FInterpCurvePointVector
{
	public:
	    float InVal; // 0x0 Size: 0x4
	    struct FVector OutVal; // 0x4 Size: 0xc
	    struct FVector ArriveTangent; // 0x10 Size: 0xc
	    struct FVector LeaveTangent; // 0x1c Size: 0xc
	    char InterpMode; // 0x28 Size: 0x1
	    char UnknownData0[0x3];

};

struct FInterpCurvePointQuat
{
	public:
	    float InVal; // 0x0 Size: 0x4
	    char UnknownData0[0xc]; // 0x4
	    struct FQuat OutVal; // 0x10 Size: 0x10
	    struct FQuat ArriveTangent; // 0x20 Size: 0x10
	    struct FQuat LeaveTangent; // 0x30 Size: 0x10
	    char InterpMode; // 0x40 Size: 0x1
	    char UnknownData1[0xf];

};

struct FInterpCurvePointTwoVectors
{
	public:
	    float InVal; // 0x0 Size: 0x4
	    struct FTwoVectors OutVal; // 0x4 Size: 0x18
	    struct FTwoVectors ArriveTangent; // 0x1c Size: 0x18
	    struct FTwoVectors LeaveTangent; // 0x34 Size: 0x18
	    char InterpMode; // 0x4c Size: 0x1
	    char UnknownData0[0x3];

};

struct FInterpCurvePointLinearColor
{
	public:
	    float InVal; // 0x0 Size: 0x4
	    struct FLinearColor OutVal; // 0x4 Size: 0x10
	    struct FLinearColor ArriveTangent; // 0x14 Size: 0x10
	    struct FLinearColor LeaveTangent; // 0x24 Size: 0x10
	    char InterpMode; // 0x34 Size: 0x1
	    char UnknownData0[0x3];

};

struct FTransform
{
	public:
	    struct FQuat Rotation; // 0x0 Size: 0x10
	    struct FVector Translation; // 0x10 Size: 0xc
	    char UnknownData0[0x4]; // 0x1c
	    struct FVector Scale3D; // 0x20 Size: 0xc
	    char UnknownData1[0x4];

};

struct FRandomStream
{
	public:
	    int InitialSeed; // 0x0 Size: 0x4
	    int Seed; // 0x4 Size: 0x4

};

struct FDateTime
{
	public:
	    char UnknownData0[0x8];

};

struct FFrameNumber
{
	public:
	    int Value; // 0x0 Size: 0x4

};

struct FFrameRate
{
	public:
	    int Numerator; // 0x0 Size: 0x4
	    int Denominator; // 0x4 Size: 0x4

};

struct FFrameTime
{
	public:
	    struct FFrameNumber FrameNumber; // 0x0 Size: 0x4
	    float SubFrame; // 0x4 Size: 0x4

};

struct FQualifiedFrameTime
{
	public:
	    struct FFrameTime Time; // 0x0 Size: 0x8
	    struct FFrameRate Rate; // 0x8 Size: 0x8

};

struct FTimecode
{
	public:
	    int Hours; // 0x0 Size: 0x4
	    int Minutes; // 0x4 Size: 0x4
	    int Seconds; // 0x8 Size: 0x4
	    int Frames; // 0xc Size: 0x4
	    bool bDropFrameFormat; // 0x10 Size: 0x1
	    char UnknownData0[0x3];

};

struct FTimespan
{
	public:
	    char UnknownData0[0x8];

};

struct FSoftObjectPath
{
	public:
	    FName AssetPathName; // 0x0 Size: 0x8
	    struct FString SubPathString; // 0x8 Size: 0x10

};

struct FSoftClassPath : public FSoftObjectPath
{
	public:
	    char UnknownData0[0x18];

};

struct FPrimaryAssetType
{
	public:
	    FName Name; // 0x0 Size: 0x8

};

struct FPrimaryAssetId
{
	public:
	    struct FPrimaryAssetType PrimaryAssetType; // 0x0 Size: 0x8
	    FName PrimaryAssetName; // 0x8 Size: 0x8

};

struct FFallbackStruct
{
	public:
	    char UnknownData0[0x1];

};

struct FFloatRangeBound
{
	public:
	    char Type; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float Value; // 0x4 Size: 0x4

};



enum class ERangeBoundTypes : uint8_t
{
    Exclusive = 0,
    Inclusive = 1,
    Open = 2,
    ERangeBoundTypes_MAX = 3
};struct FFloatRange
{
	public:
	    struct FFloatRangeBound LowerBound; // 0x0 Size: 0x8
	    struct FFloatRangeBound UpperBound; // 0x8 Size: 0x8

};

struct FInt32RangeBound
{
	public:
	    char Type; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    int Value; // 0x4 Size: 0x4

};

struct FInt32Range
{
	public:
	    struct FInt32RangeBound LowerBound; // 0x0 Size: 0x8
	    struct FInt32RangeBound UpperBound; // 0x8 Size: 0x8

};

struct FFloatInterval
{
	public:
	    float Min; // 0x0 Size: 0x4
	    float Max; // 0x4 Size: 0x4

};

struct FInt32Interval
{
	public:
	    int Min; // 0x0 Size: 0x4
	    int Max; // 0x4 Size: 0x4

};



enum class ELocalizedTextSourceCategory : uint8_t
{
    Game = 0,
    Engine = 1,
    Editor = 2,
    ELocalizedTextSourceCategory_MAX = 3
};struct FPolyglotTextData
{
	public:
	    ELocalizedTextSourceCategory Category; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FString NativeCulture; // 0x8 Size: 0x10
	    struct FString Namespace; // 0x18 Size: 0x10
	    struct FString Key; // 0x28 Size: 0x10
	    struct FString NativeString; // 0x38 Size: 0x10
	    __int64/*MapProperty*/ LocalizedStrings; // 0x48 Size: 0x50
	    bool bIsMinimalPatch; // 0x98 Size: 0x1
	    char UnknownData1[0x7]; // 0x99
	    struct FText CachedText; // 0xa0 Size: 0x18

};



enum class EAutomationEventType : uint8_t
{
    Info = 0,
    Warning = 1,
    Error = 2,
    EAutomationEventType_MAX = 3
};struct FAutomationEvent
{
	public:
	    EAutomationEventType Type; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FString MESSAGE; // 0x8 Size: 0x10
	    struct FString Context; // 0x18 Size: 0x10
	    struct FGuid Artifact; // 0x28 Size: 0x10

};

struct FAutomationExecutionEntry
{
	public:
	    struct FAutomationEvent Event; // 0x0 Size: 0x38
	    struct FString Filename; // 0x38 Size: 0x10
	    int LineNumber; // 0x48 Size: 0x4
	    char UnknownData0[0x4]; // 0x4c
	    struct FDateTime Timestamp; // 0x50 Size: 0x8

};



enum class EMouseCursor : uint8_t
{
    None = 0,
    Default = 1,
    TextEditBeam = 2,
    ResizeLeftRight = 3,
    ResizeUpDown = 4,
    ResizeSouthEast = 5,
    ResizeSouthWest = 6,
    CardinalCross = 7,
    Crosshairs = 8,
    Hand = 9,
    GrabHand = 10,
    GrabHandClosed = 11,
    SlashedCircle = 12,
    EyeDropper = 13,
    EMouseCursor_MAX = 14
};

enum class ELifetimeCondition : uint8_t
{
    COND_None = 0,
    COND_InitialOnly = 1,
    COND_OwnerOnly = 2,
    COND_SkipOwner = 3,
    COND_SimulatedOnly = 4,
    COND_AutonomousOnly = 5,
    COND_SimulatedOrPhysics = 6,
    COND_InitialOrOwner = 7,
    COND_Custom = 8,
    COND_ReplayOrOwner = 9,
    COND_ReplayOnly = 10,
    COND_SimulatedOnlyNoReplay = 11,
    COND_SimulatedOrPhysicsNoReplay = 12,
    COND_SkipReplay = 13,
    COND_Max = 14
};

enum class EUnit : uint8_t
{
    Micrometers = 0,
    Millimeters = 1,
    Centimeters = 2,
    Meters = 3,
    Kilometers = 4,
    Inches = 5,
    Feet = 6,
    Yards = 7,
    Miles = 8,
    Lightyears = 9,
    Degrees = 10,
    Radians = 11,
    MetersPerSecond = 12,
    KilometersPerHour = 13,
    MilesPerHour = 14,
    Celsius = 15,
    Farenheit = 16,
    Kelvin = 17,
    Micrograms = 18,
    Milligrams = 19,
    Grams = 20,
    Kilograms = 21,
    MetricTons = 22,
    Ounces = 23,
    Pounds = 24,
    Stones = 25,
    Newtons = 26,
    PoundsForce = 27,
    KilogramsForce = 28,
    Hertz = 29,
    Kilohertz = 30,
    Megahertz = 31,
    Gigahertz = 32,
    RevolutionsPerMinute = 33,
    Bytes = 34,
    Kilobytes = 35,
    Megabytes = 36,
    Gigabytes = 37,
    Terabytes = 38,
    Lumens = 39,
    Milliseconds = 43,
    Seconds = 44,
    Minutes = 45,
    Hours = 46,
    Days = 47,
    Months = 48,
    Years = 49,
    Multiplier = 52,
    Percentage = 51,
    Unspecified = 53,
    EUnit_MAX = 54
};

enum class EPixelFormat : uint8_t
{
    PF_Unknown = 0,
    PF_A32B32G32R32F = 1,
    PF_B8G8R8A8 = 2,
    PF_G8 = 3,
    PF_G16 = 4,
    PF_DXT1 = 5,
    PF_DXT3 = 6,
    PF_DXT5 = 7,
    PF_UYVY = 8,
    PF_FloatRGB = 9,
    PF_FloatRGBA = 10,
    PF_DepthStencil = 11,
    PF_ShadowDepth = 12,
    PF_R32_FLOAT = 13,
    PF_G16R16 = 14,
    PF_G16R16F = 15,
    PF_G16R16F_FILTER = 16,
    PF_G32R32F = 17,
    PF_A2B10G10R10 = 18,
    PF_A16B16G16R16 = 19,
    PF_D24 = 20,
    PF_R16F = 21,
    PF_R16F_FILTER = 22,
    PF_BC5 = 23,
    PF_V8U8 = 24,
    PF_A1 = 25,
    PF_FloatR11G11B10 = 26,
    PF_A8 = 27,
    PF_R32_UINT = 28,
    PF_R32_SINT = 29,
    PF_PVRTC2 = 30,
    PF_PVRTC4 = 31,
    PF_R16_UINT = 32,
    PF_R16_SINT = 33,
    PF_R16G16B16A16_UINT = 34,
    PF_R16G16B16A16_SINT = 35,
    PF_R5G6B5_UNORM = 36,
    PF_R8G8B8A8 = 37,
    PF_A8R8G8B8 = 38,
    PF_BC4 = 39,
    PF_R8G8 = 40,
    PF_ATC_RGB = 41,
    PF_ATC_RGBA_E = 42,
    PF_ATC_RGBA_I = 43,
    PF_X24_G8 = 44,
    PF_ETC1 = 45,
    PF_ETC2_RGB = 46,
    PF_ETC2_RGBA = 47,
    PF_R32G32B32A32_UINT = 48,
    PF_R16G16_UINT = 49,
    PF_ASTC_4x4 = 50,
    PF_ASTC_6x6 = 51,
    PF_ASTC_8x8 = 52,
    PF_ASTC_10x10 = 53,
    PF_ASTC_12x12 = 54,
    PF_BC6H = 55,
    PF_BC7 = 56,
    PF_R8_UINT = 57,
    PF_L8 = 58,
    PF_XGXR8 = 59,
    PF_R8G8B8A8_UINT = 60,
    PF_R8G8B8A8_SNORM = 61,
    PF_R16G16B16A16_UNORM = 62,
    PF_R16G16B16A16_SNORM = 63,
    PF_MAX = 67
};

enum class EAxis : uint8_t
{
    None = 0,
    X = 1,
    Y = 2,
    Z = 3,
    EAxis_MAX = 4
};

enum class ELogTimes : uint8_t
{
    None = 0,
    UTC = 1,
    SinceGStartTime = 2,
    Local = 3,
    ELogTimes_MAX = 4
};

enum class ESearchDir : uint8_t
{
    FromStart = 0,
    FromEnd = 1,
    ESearchDir_MAX = 2
};

enum class ESearchCase : uint8_t
{
    CaseSensitive = 0,
    IgnoreCase = 1,
    ESearchCase_MAX = 2
};struct FDefault__LinkerPlaceholderFunction
{
	public:

};


}