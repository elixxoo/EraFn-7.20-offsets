#pragma once

#include "../SDK.hpp"

namespace SDK {


class UOnlineHotfixManager : public UObject
{
	public:
	    char UnknownData0[0x1c8];
	    struct FString OssName; // 0x1f0 Size: 0x10
	    struct FString HotfixManagerClassName; // 0x200 Size: 0x10
	    struct FString DebugPrefix; // 0x210 Size: 0x10
	    TArray<class UObject*> AssetsHotfixedFromIniFiles; // 0x220 Size: 0x10
	    char UnknownData1[0x230]; // 0x230
	    void StartHotfixProcess(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7db1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Hotfix.OnlineHotfixManager");
			return (class UClass*)ptr;
		};

};

class UUpdateManager : public UObject
{
	public:
	    char UnknownData0[0x60];
	    float HotfixCheckCompleteDelay; // 0x88 Size: 0x4
	    float UpdateCheckCompleteDelay; // 0x8c Size: 0x4
	    float HotfixAvailabilityCheckCompleteDelay; // 0x90 Size: 0x4
	    float UpdateCheckAvailabilityCompleteDelay; // 0x94 Size: 0x4
	    bool bCheckPlatformOSSForUpdate; // 0x98 Size: 0x1
	    bool bCheckOSSForUpdate; // 0x99 Size: 0x1
	    char UnknownData1[0x2]; // 0x9a
	    int AppSuspendedUpdateCheckTimeSeconds; // 0x9c Size: 0x4
	    bool bPlatformEnvironmentDetected; // 0xa8 Size: 0x1
	    bool bInitialUpdateFinished; // 0xa9 Size: 0x1
	    bool bCheckHotfixAvailabilityOnly; // 0xaa Size: 0x1
	    char UnknownData2[0x8]; // 0xa3
	    EUpdateState CurrentUpdateState; // 0xab Size: 0x1
	    int WorstNumFilesPendingLoadViewed; // 0xac Size: 0x4
	    EPatchCheckResult LastPatchCheckResult; // 0xb0 Size: 0x1
	    EHotfixResult LastHotfixResult; // 0xb1 Size: 0x1
	    char UnknownData3[0x2e]; // 0xb2
	    struct FDateTime* LastUpdateCheck; // 0xe0 Size: 0x8
	    char UnknownData4[0x8]; // 0xe8
	    EUpdateCompletionStatus LastCompletionResult; // 0xf0 Size: 0x1
	    char UnknownData5[0x17]; // 0xf1
	    class UEnum* UpdateStateEnum; // 0x108 Size: 0x8
	    class UEnum* UpdateCompletionEnum; // 0x110 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Hotfix.UpdateManager");
			return (class UClass*)ptr;
		};

};


}