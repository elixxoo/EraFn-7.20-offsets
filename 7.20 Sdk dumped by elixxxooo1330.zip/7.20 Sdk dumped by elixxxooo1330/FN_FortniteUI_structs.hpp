#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FOnHitPointStatChanged__DelegateSignature
{
	public:
	    float HitPointStat; // 0x0 Size: 0x4

};

struct FOnBigHitPointStatChanged__DelegateSignature
{
	public:
	    struct FText HitPointText; // 0x0 Size: 0x18
	    float HealthPercent; // 0x18 Size: 0x4
	    char UnknownData0[0x4];

};

struct FOnFocusedBuildingAttachedTrapChanged__DelegateSignature
{
	public:
	    class ABuildingTrap* BuildingAttachedTrap; // 0x0 Size: 0x8

};

struct FOnBuildingTrapDurabilityChanged__DelegateSignature
{
	public:
	    float CurrentDurability; // 0x0 Size: 0x4
	    float MaxDurability; // 0x4 Size: 0x4

};

struct FOnInteractionCostChanged__DelegateSignature
{
	public:
	    int InteractionCost; // 0x0 Size: 0x4

};



enum class EFortHitPointModificationReason : uint8_t
{
    Invalid = 0,
    InitalSet = 1,
    AutoRegen = 2,
    ItemRegen = 3,
    DamageOverTime = 4,
    DamageReceived = 5,
    EFortHitPointModificationReason_MAX = 6
};struct FOnHitPointsModified__DelegateSignature
{
	public:
	    float HitPointValue; // 0x0 Size: 0x4
	    EFortHitPointModificationReason ModificationReason; // 0x4 Size: 0x1
	    char UnknownData0[0x3];

};

struct FOnPlayerSpawned__DelegateSignature
{
	public:

};

struct FOnPlayerRevived__DelegateSignature
{
	public:

};

struct FOnPlayerKillsChanged__DelegateSignature
{
	public:

};

struct FOnPlayerAIKillsChanged__DelegateSignature
{
	public:

};

struct FOnPlayerPlaceChanged__DelegateSignature
{
	public:

};

struct FOnCursorModeChangingDelegate__DelegateSignature
{
	public:
	    bool bCursorModeEnabled; // 0x0 Size: 0x1

};

struct FOnCursorModeChangedDelegate__DelegateSignature
{
	public:
	    bool bCursorModeEnabled; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    FName ActionName; // 0x4 Size: 0x8
	    char UnknownData1[0x4]; // 0xc
	    class UUserWidget* CursorModeContentWidget; // 0x10 Size: 0x8

};

struct FOnGameViewportActivationChangedDelegate__DelegateSignature
{
	public:
	    bool bHasFocus; // 0x0 Size: 0x1

};

struct FOnMgmtMenuTabChangeRequestedDelegate__DelegateSignature
{
	public:
	    FName TabName; // 0x0 Size: 0x8

};

struct FOnIndicatorModeChangedDelegate__DelegateSignature
{
	public:
	    bool bIndicatorsEnabled; // 0x0 Size: 0x1

};

struct FOnContextualReticleChangedDelegate__DelegateSignature
{
	public:

};

struct FOnPlayerTargetingChangedDelegate__DelegateSignature
{
	public:
	    bool bIsTargeting; // 0x0 Size: 0x1

};

struct FOnScoreStatChanged__DelegateSignature
{
	public:
	    int StatDelta; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    struct FText StatName; // 0x8 Size: 0x18
	    char StatType; // 0x20 Size: 0x1
	    EStatCategory StatCategory; // 0x21 Size: 0x1
	    char UnknownData1[0x6];

};

struct FOnScoreChanged__DelegateSignature
{
	public:
	    int NewTotalScore; // 0x0 Size: 0x4

};

struct FOnBuildingFocused__DelegateSignature
{
	public:
	    class ABuildingActor* FocusedBuilding; // 0x0 Size: 0x8

};

struct FOnActorFocusedForCreative__DelegateSignature
{
	public:
	    class AActor* FocusedActor; // 0x0 Size: 0x8

};

struct FOnVehicleFocused__DelegateSignature
{
	public:
	    class AFortAthenaVehicle* FocusedVehicle; // 0x0 Size: 0x8

};



enum class EFortBuildingInteraction : uint8_t
{
    None = 0,
    Build = 1,
    Repair = 2,
    Upgrade = 3,
    Edit = 4,
    BeingModified = 5,
    ConfirmEdit = 6,
    Creative = 7,
    EFortBuildingInteraction_MAX = 8
};

enum class EFortBuildingHealthDisplayRule : uint8_t
{
    Never = 0,
    Allowed = 1,
    Always = 2,
    EFortBuildingHealthDisplayRule_MAX = 3
};struct FFortFocusedBuildingInfo
{
	public:
	    bool bIsInteractable; // 0x0 Size: 0x1
	    bool bCanBePlayerEdited; // 0x1 Size: 0x1
	    char UnknownData0[0x2]; // 0x2
	    struct FVector IndicatorRelativeLocation; // 0x4 Size: 0xc
	    EFortBuildingHealthDisplayRule HealthDisplayRule; // 0x10 Size: 0x1
	    char UnknownData1[0x3]; // 0x11
	    float MaxHealth; // 0x14 Size: 0x4
	    bool bIsAnyTrapAttached; // 0x18 Size: 0x1
	    bool bIsTrapAttachedFacingPlayer; // 0x19 Size: 0x1
	    bool bIsPreviewTrapAttached; // 0x1a Size: 0x1
	    char UnknownData2[0x1]; // 0x1b
	    float AttachedTrapMaxDurability; // 0x1c Size: 0x4
	    int CurrentLevel; // 0x20 Size: 0x4
	    EFortBuildingInteraction InteractionType; // 0x24 Size: 0x1
	    char UnknownData3[0x3]; // 0x25
	    int InteractionCost; // 0x28 Size: 0x4
	    int UpgradeBonus; // 0x2c Size: 0x4
	    char BuildingMaterial; // 0x30 Size: 0x1
	    bool bIsHostile; // 0x31 Size: 0x1
	    char UnknownData4[0x6]; // 0x32
	    struct FText ContextualText; // 0x38 Size: 0x18

};

struct FOnFocusedBuildingStateChanged__DelegateSignature
{
	public:
	    struct FFortFocusedBuildingInfo FocusedBuildingInfo; // 0x0 Size: 0x50

};

struct FOnCanInteract__DelegateSignature
{
	public:
	    class UFortInteractContextInfo* ContextInfo; // 0x0 Size: 0x8

};

struct FOnInteractUpdated__DelegateSignature
{
	public:
	    class UFortInteractContextInfo* ContextInfo; // 0x0 Size: 0x8

};

struct FHUDBasicDelegate__DelegateSignature
{
	public:

};

struct FOnItemCollectorChanged__DelegateSignature
{
	public:
	    class ABuildingItemCollectorActor* ItemCollector; // 0x0 Size: 0x8

};

struct FOnTotalQuantumChanged__DelegateSignature
{
	public:
	    int PrevTotalQuantum; // 0x0 Size: 0x4
	    int CurrentTotalQuantum; // 0x4 Size: 0x4

};

struct FOnAllFOBCoresAdded__DelegateSignature
{
	public:
	    char Team; // 0x0 Size: 0x1

};

struct FOnToggleScoreboardDelegate__DelegateSignature
{
	public:
	    bool bEnabled; // 0x0 Size: 0x1

};

struct FOnWaveCombatStart__DelegateSignature
{
	public:
	    struct FText LevelText; // 0x0 Size: 0x18
	    int Level; // 0x18 Size: 0x4
	    char UnknownData0[0x4]; // 0x1c
	    struct FText WaveText; // 0x20 Size: 0x18
	    int WaveNum; // 0x38 Size: 0x4
	    char UnknownData1[0x4];

};

struct FOnHordeTierCompleteDelegate__DelegateSignature
{
	public:
	    EFortCompletionResult Result; // 0x0 Size: 0x1

};

struct FOnNumSurvivorsRescuedUpdate__DelegateSignature
{
	public:
	    int NumSurvivorsRescued; // 0x0 Size: 0x4

};

struct FOnEarnedBadgesChanged__DelegateSignature
{
	public:

};

struct FOnFocusedMissionChanged__DelegateSignature
{
	public:
	    class AFortMission* FocusedMission; // 0x0 Size: 0x8

};

struct FOnDamagedResourceBuilding__DelegateSignature
{
	public:
	    class ABuildingSMActor* BuildingSMActor; // 0x0 Size: 0x8
	    class UFortItem* PotentialWorldItem; // 0x8 Size: 0x8
	    bool bDestroyed; // 0x10 Size: 0x1
	    bool bJustHitWeakspot; // 0x11 Size: 0x1
	    char UnknownData0[0x6];

};

struct FOnPointOfInterestAdded__DelegateSignature
{
	public:
	    class AActor* PointOfInterest; // 0x0 Size: 0x8
	    struct FText DisplayText; // 0x8 Size: 0x18
	    class UTexture2D* DisplayImage; // 0x20 Size: 0x8

};

struct FOnPointOfInterestRemoved__DelegateSignature
{
	public:
	    class AActor* PointOfInterest; // 0x0 Size: 0x8

};

struct FOnDebugHUDObjectiveHeightChanged__DelegateSignature
{
	public:
	    bool bIsDebugging; // 0x0 Size: 0x1

};

struct FOnHighlightsCountChanged__DelegateSignature
{
	public:
	    int NumHighlights; // 0x0 Size: 0x4

};

struct FOnHUDResetToDefaults__DelegateSignature
{
	public:

};

struct FFortHUDState
{
	public:
	    bool bInBuildMode; // 0x0 Size: 0x1
	    bool bInCombatMode; // 0x1 Size: 0x1
	    bool bInEditMode; // 0x2 Size: 0x1
	    bool bInCreativeMode; // 0x3 Size: 0x1
	    bool bIsParachuteOpen; // 0x4 Size: 0x1
	    bool bIsFreeFalling; // 0x5 Size: 0x1
	    bool bInLockedBus; // 0x6 Size: 0x1
	    bool bInUnlockedBus; // 0x7 Size: 0x1
	    bool bOnTargeting; // 0x8 Size: 0x1
	    bool bOnUsingScopeTargeting; // 0x9 Size: 0x1
	    bool bOnCanTarget; // 0xa Size: 0x1
	    bool bOnCanUseScopeTargeting; // 0xb Size: 0x1
	    bool bOnCanUseSecondaryAbility; // 0xc Size: 0x1
	    bool bCanOpenChute; // 0xd Size: 0x1
	    bool bCrouching; // 0xe Size: 0x1
	    bool bDBNO; // 0xf Size: 0x1
	    bool bIsControllingRCPawn; // 0x10 Size: 0x1
	    bool bIsInVehicle; // 0x11 Size: 0x1
	    bool bIsDrivingVehicle; // 0x12 Size: 0x1
	    bool bCanSwapSeats; // 0x13 Size: 0x1

};

struct FOnHUDStateRefreshed__DelegateSignature
{
	public:
	    struct FFortHUDState NewHUDState; // 0x0 Size: 0x14

};

struct FOnBuildModeChanged__DelegateSignature
{
	public:
	    bool bEntering; // 0x0 Size: 0x1

};

struct FOnPersonalVehicleModeChange__DelegateSignature
{
	public:
	    bool bEnteredVehicle; // 0x0 Size: 0x1

};

struct FOnVehicleStateChanged__DelegateSignature
{
	public:
	    class AFortPlayerPawn* PlayerPawn; // 0x0 Size: 0x8
	    class AFortAthenaVehicle* NewVehicle; // 0x8 Size: 0x8
	    class AFortAthenaVehicle* OldVehicle; // 0x10 Size: 0x8

};

struct FOnUIResetRequired__DelegateSignature
{
	public:

};

struct FOnSettingsApplied__DelegateSignature
{
	public:

};

struct FOnShouldTriggerCooldownUpdate__DelegateSignature
{
	public:

};

struct FOnItemViewRefreshed__DelegateSignature
{
	public:

};

struct FRecruitHeroWidgetFinishedDelegate__DelegateSignature
{
	public:
	    class UFortHero* NewHero; // 0x0 Size: 0x8

};

struct FSlottingPreviewChangedDelegate__DelegateSignature
{
	public:

};

struct FOnEarlyGameFinished__DelegateSignature
{
	public:

};

struct FFortItemFilterDefinition
{
	public:
	    char UnknownData0[0x50];

};

struct FFortItemSorterDefinition
{
	public:
	    char UnknownData0[0x40];

};

struct FFortTabButtonLabelInfo
{
	public:
	    struct FText DisplayName; // 0x0 Size: 0x18
	    struct FSlateBrush IconBrush; // 0x18 Size: 0x88

};

struct FFortTabListRegistrationInfo
{
	public:
	    FName TabNameID; // 0x0 Size: 0x8
	    bool bHidden; // 0x8 Size: 0x1
	    bool bAllowedInZone; // 0x9 Size: 0x1
	    char UnknownData0[0x6]; // 0xa
	    struct FFortTabButtonLabelInfo TabLabelInfo; // 0x10 Size: 0xa0
	    class UCommonButton* TabButtonType; // 0xb0 Size: 0x8
	    class UCommonUserWidget* TabContentType; // 0xb8 Size: 0x8
	    class UWidget* CreatedTabContentWidget; // 0xc0 Size: 0x8

};

struct FFortUIStatStyle
{
	public:
	    struct FText Name; // 0x0 Size: 0x18
	    struct FText HighestText; // 0x18 Size: 0x18
	    struct FSlateBrush Icon; // 0x30 Size: 0x88
	    ECommonNumericType NumericType; // 0xb8 Size: 0x1
	    char UnknownData0[0x3]; // 0xb9
	    float MinimalNotableValue; // 0xbc Size: 0x4

};

struct FSettingValueChanged__DelegateSignature
{
	public:

};



enum class EFortUIState : uint8_t
{
    Invalid = 0,
    Login = 1,
    JoinServer = 2,
    SubgameSelect = 3,
    FrontEnd = 4,
    PvE_PostGame = 5,
    PvP_PostGame = 6,
    InGame = 7,
    Cinematic = 8,
    Athena = 9,
    AthenaSpectator = 10,
    Replay = 11,
    AthenaReplay = 12,
    MAX = 13
};struct FFortErrorInfo
{
	public:
	    struct FText Operation; // 0x0 Size: 0x18
	    struct FText ErrorMessage; // 0x18 Size: 0x18
	    struct FString ErrorCode; // 0x30 Size: 0x10
	    EFortErrorSeverity ErrorSeverity; // 0x40 Size: 0x1
	    char UnknownData0[0x7]; // 0x41
	    struct FText ContinueButtonText; // 0x48 Size: 0x18
	    char UnknownData1[0x10];

};

struct FFortCheckForStwMfaRewardCompleteDelegate__DelegateSignature
{
	public:

};

struct FCreateWidgetAsyncDelegate__DelegateSignature
{
	public:
	    class UUserWidget* UserWidget; // 0x0 Size: 0x8

};

struct FBannerAssetLoadComplete__DelegateSignature
{
	public:
	    class UObject* LoadedAsset; // 0x0 Size: 0x8
	    class UMaterialInstanceDynamic* MIDRef; // 0x8 Size: 0x8
	    FName BannerColorName; // 0x10 Size: 0x8

};

struct FFortLoadCurrentSubgameProfilesCompleteDelegate__DelegateSignature
{
	public:

};

struct FFortAdvancedLatentConfirmationDialogResultDelegate_NUI__DelegateSignature
{
	public:
	    EFortDialogResult Result; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    FName ResultName; // 0x4 Size: 0x8
	    bool bWaitingForLatentActionCompletion; // 0xc Size: 0x1
	    char UnknownData1[0x3]; // 0xd
	    struct FFortDialogExternalLatentActionHandle WaitingDialogHandle; // 0x10 Size: 0x4

};

struct FFortConfirmationResultDelegate_NUI__DelegateSignature
{
	public:
	    EFortDialogResult Result; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    FName ResultName; // 0x4 Size: 0x8

};

struct FChallengeBundleChangedDelegate__DelegateSignature
{
	public:

};

struct FFortAthenaItemManagementInventoryFilterTabLabelInfo : public FFortTabButtonLabelInfo
{
	public:
	    FName FilterTabNameId; // 0xa0 Size: 0x8
	    bool bAllowEmptySlotItem; // 0xa8 Size: 0x1
	    char UnknownData0[0x7]; // 0xa9
	    struct FText EmptyFilterDisplay; // 0xb0 Size: 0x18

};



enum class EFortStoreState : uint8_t
{
    Error = 0,
    Closed = 1,
    CardPackStore = 2,
    CurrencyStore = 3,
    WebPayment = 4,
    PurchaseOpen = 5,
    PackOpen = 6,
    CardEnter = 7,
    CardBackReveal = 8,
    CardFlip = 9,
    CardFrontReveal = 10,
    CardExit = 11,
    SummaryAdd = 12,
    PackDestroy = 13,
    Summary = 14,
    PresentChoice = 15,
    ChoiceMade = 16,
    SummaryAddTransition = 17,
    MAX_None = 18,
    EFortStoreState_MAX = 19
};struct FStoreStateChangedDelegate__DelegateSignature
{
	public:
	    EFortStoreState NewStoreState; // 0x0 Size: 0x1

};

struct FStoreCardPackOffersChanged__DelegateSignature
{
	public:

};

struct FStorePurchaseCompleted__DelegateSignature
{
	public:

};



enum class EInputPriority : uint8_t
{
    Normal = 0,
    Menu = 1,
    Chat = 2,
    Modal = 3,
    Confirmation = 4,
    Error = 5,
    HUD = 6,
    EInputPriority_MAX = 7
};

enum class ESpectatorPlayerListSortMethod : uint8_t
{
    SquadId = 0,
    PlayerName = 1,
    Eliminations = 2,
    State = 3,
    Count = 4,
    ESpectatorPlayerListSortMethod_MAX = 5
};struct FOnCollectionBookPageSelected__DelegateSignature
{
	public:
	    class UFortCollectionBookPage* SelectedPage; // 0x0 Size: 0x8

};

struct FOnCollectionBookPageClicked__DelegateSignature
{
	public:
	    class UFortCollectionBookPage* ClickedPage; // 0x0 Size: 0x8

};

struct FOnBookPageSelected__DelegateSignature
{
	public:
	    class UFortCollectionBookPage* SelectedPage; // 0x0 Size: 0x8

};

struct FOnBookPageClicked__DelegateSignature
{
	public:
	    class UFortCollectionBookPage* ClickedPage; // 0x0 Size: 0x8

};

struct FOnBookSectionClicked__DelegateSignature
{
	public:
	    class UFortCollectionBookSection* ClickedSection; // 0x0 Size: 0x8

};



enum class EFortItemCardSize : uint8_t
{
    XXS = 0,
    XS = 1,
    S = 2,
    M = 3,
    L = 4,
    XL = 5,
    XXL = 6,
    EFortItemCardSize_MAX = 7
};struct FOnSectionCloseRequest__DelegateSignature
{
	public:

};

struct FOnPreviewXPChange__DelegateSignature
{
	public:
	    int XPChange; // 0x0 Size: 0x4

};



enum class EFortCollectionBookPopupButtonType : uint8_t
{
    SelectItem = 0,
    Preview = 1,
    Purchase = 2,
    Unslot = 3,
    Back = 4,
    EFortCollectionBookPopupButtonType_MAX = 5
};

enum class ECollectionBookSectionNavTarget : uint8_t
{
    SlotSelect = 0,
    SlotPicker = 1,
    ECollectionBookSectionNavTarget_MAX = 2
};struct FCollectionBookButtonItemUpdatedDelegate__DelegateSignature
{
	public:

};

struct FAttributeChangedDelegate__DelegateSignature
{
	public:

};

struct FSeasonTabVariantPreviewInfoChanged__DelegateSignature
{
	public:

};

struct FTheaterTileClickedDelegate__DelegateSignature
{
	public:

};

struct FTheaterTileDoubleClickedDelegate__DelegateSignature
{
	public:

};

struct FTheaterTileFocusedDelegate__DelegateSignature
{
	public:

};

struct FBuildResultDelegate__DelegateSignature
{
	public:
	    bool Result; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FString BuildingTemplateId; // 0x8 Size: 0x10

};

struct FRecruitHeroDelegate__DelegateSignature
{
	public:
	    class UFortHeroType* RecruitedHeroType; // 0x0 Size: 0x8

};

struct FTheaterPinClickedDelegate__DelegateSignature
{
	public:
	    struct FString TheaterId; // 0x0 Size: 0x10

};

struct FSetPreviewedSceneTheaterDelegate__DelegateSignature
{
	public:
	    struct FString TheaterId; // 0x0 Size: 0x10

};

struct FTheaterSelectedDelegate__DelegateSignature
{
	public:
	    struct FString TheaterId; // 0x0 Size: 0x10

};

struct FTheaterDataChangedDelegate__DelegateSignature
{
	public:

};

struct FLobbyBackgroundChangedDelegate__DelegateSignature
{
	public:

};

struct FAthenaPlaylistChangedDelegate__DelegateSignature
{
	public:

};

struct FLobbyEmptyPlayerClickedDelegate__DelegateSignature
{
	public:
	    int PlayerIndex; // 0x0 Size: 0x4

};

struct FLobbyPlayerGadgetsClickedDelegate__DelegateSignature
{
	public:
	    int PlayerIndex; // 0x0 Size: 0x4

};

struct FLobbyPlayerPadHoveredDelegate__DelegateSignature
{
	public:
	    int PlayerIndex; // 0x0 Size: 0x4

};

struct FLobbyPlayerPadUnhoveredDelegate__DelegateSignature
{
	public:
	    int PlayerIndex; // 0x0 Size: 0x4

};

struct FLobbyPlayerHoveredDelegate__DelegateSignature
{
	public:
	    int PlayerIndex; // 0x0 Size: 0x4

};

struct FLobbyPlayerUnhoveredDelegate__DelegateSignature
{
	public:
	    int PlayerIndex; // 0x0 Size: 0x4

};

struct FLobbyPlayerSelectedDelegate__DelegateSignature
{
	public:
	    int PlayerIndex; // 0x0 Size: 0x4

};

struct FLobbyPlayerUnselectedDelegate__DelegateSignature
{
	public:
	    int PlayerIndex; // 0x0 Size: 0x4

};

struct FLobbyPlayerPartySuggestionAccept__DelegateSignature
{
	public:
	    int PlayerIndex; // 0x0 Size: 0x4

};

struct FOnCameraChangedDelegate__DelegateSignature
{
	public:
	    EFrontEndCamera NewCamera; // 0x0 Size: 0x1
	    EFrontEndCamera OldCamera; // 0x1 Size: 0x1

};

struct FOnMainTabSelectedDelegate__DelegateSignature
{
	public:
	    FName TabName; // 0x0 Size: 0x8

};

struct FPlayerLoginDelegate__DelegateSignature
{
	public:

};



enum class EFortFrontEndFeatureStateReason : uint8_t
{
    Default = 0,
    NoHeroes = 1,
    Tutorial = 2,
    BROnly = 3,
    NoPlayerController = 4,
    UnexpectedFeature = 5,
    Invalid = 6,
    EFortFrontEndFeatureStateReason_MAX = 7
};

enum class EFortFrontEndFeatureState : uint8_t
{
    Enabled = 0,
    Disabled = 1,
    Hidden = 2,
    Invalid = 3,
    EFortFrontEndFeatureState_MAX = 4
};

enum class EFortFrontEndFeature : uint8_t
{
    ShowHomeBase = 0,
    ShowHeroList = 1,
    ShowVault = 2,
    ShowStore = 3,
    PlayZone = 4,
    ShowDailyRewards = 5,
    ShowHeroSelect = 6,
    RecruitHero = 7,
    ShowHomeBaseOverview = 8,
    MAX_None = 9,
    EFortFrontEndFeature_MAX = 10
};struct FFrontEndFeatureStateChangedDelegate__DelegateSignature
{
	public:
	    EFortFrontEndFeature ChangedFeature; // 0x0 Size: 0x1
	    EFortFrontEndFeatureState NewState; // 0x1 Size: 0x1
	    EFortFrontEndFeatureStateReason Reason; // 0x2 Size: 0x1

};

struct FFrontEndFeatureStateChangedListener__DelegateSignature
{
	public:
	    EFortFrontEndFeature ChangedFeature; // 0x0 Size: 0x1
	    EFortFrontEndFeatureState NewState; // 0x1 Size: 0x1
	    EFortFrontEndFeatureStateReason Reason; // 0x2 Size: 0x1

};

struct FFrontendMiniLobbyTimerShowDelegate__DelegateSignature
{
	public:
	    bool bShow; // 0x0 Size: 0x1

};

struct FOpenPVPLobbyEvent__DelegateSignature
{
	public:

};

struct FVaultItemViewed__DelegateSignature
{
	public:
	    class UFortItem* Item; // 0x0 Size: 0x8

};

struct FOnLobbyPlayersStoppedTalkingDelegate__DelegateSignature
{
	public:

};

struct FOnSocialImportClosedDelegate__DelegateSignature
{
	public:

};

struct FOnRadialPickerStatusChanged__DelegateSignature
{
	public:
	    bool Opened; // 0x0 Size: 0x1

};

struct FOnShowPickerDelegate__DelegateSignature
{
	public:
	    EFortPickerMode Mode; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    int InitialOption; // 0x4 Size: 0x4
	    bool bIgnoreFirstAccept; // 0x8 Size: 0x1
	    char UnknownData1[0x3];

};

struct FOnPickerCommandDelegate__DelegateSignature
{
	public:

};

struct FOnPickerOptionSelectionMovedDelegate__DelegateSignature
{
	public:
	    int OptionDirection; // 0x0 Size: 0x4

};

struct FOnPickerOptionChosenDelegate__DelegateSignature
{
	public:
	    int PickerOption; // 0x0 Size: 0x4

};



enum class EFortUIFeatureStateReason : uint8_t
{
    Default = 0,
    Tutorial = 1,
    ContentInstall = 2,
    AccountRestrictions = 3,
    Platform = 4,
    SeasonOrEventNotActive = 5,
    NoPlayerController = 6,
    UnexpectedFeature = 7,
    Invalid = 8,
    EFortUIFeatureStateReason_MAX = 9
};

enum class EFortUIFeatureState : uint8_t
{
    Enabled = 0,
    Disabled = 1,
    Hidden = 2,
    Invalid = 3,
    EFortUIFeatureState_MAX = 4
};

enum class EFortUIFeature : uint8_t
{
    ShowHome = 0,
    ShowPlay = 1,
    ShowCommand = 2,
    ShowHeros = 3,
    ShowSquads = 4,
    ShowArmory = 5,
    ShowLocker = 6,
    ShowSkillTree = 7,
    ShowStore = 8,
    ShowQuests = 9,
    ShowMainStore = 10,
    ShowContextHelpMenu = 11,
    ShowCampaign = 12,
    ShowActiveBoost = 13,
    ShowJournal = 14,
    ShowPartyBar = 15,
    ShowChatWindow = 16,
    ShowFriendsMenu = 17,
    ShowObjectives = 18,
    ShowRatingIconsInTopbar = 19,
    ShowAntiAddictionMessage = 20,
    ShowMinorShutdownMessage = 21,
    ShowHealthWarningScreen = 22,
    ShowSimplifiedHUD = 23,
    LargeHeaderFooterButtons = 24,
    ShowAthenaFavoriting = 25,
    ShowAthenaItemRandomization = 26,
    ShowAthenaChallenges = 27,
    ShowBattlePass = 28,
    ShowBattlePassFAQ = 29,
    ShowReplays = 30,
    ShowProfileStatsUI = 31,
    ShowAthenaItemShop = 32,
    ShowShowdown = 33,
    ShowAccountBoosts = 34,
    ShowCustomerSupport = 35,
    ShowGlobalChat = 36,
    ShowEULA = 37,
    ShowEndOfZoneCinematic = 38,
    ShowOnboardingCinematics = 39,
    ShowFounderBannerIcons = 40,
    ShowCurrentRegionInLobby = 41,
    EnableFoundersDailyRewards = 42,
    EnableTwitchIntegration = 43,
    EnableMatchmakingRegionSetting = 44,
    EnableLanguageSetting = 45,
    EnableFriendCodeSetting = 46,
    EnableEarlyAccessLoadingScreenBanner = 47,
    EnableAlterationModifications = 48,
    EnableSchematicRarityUpgrade = 49,
    EnableMissionActivationVote = 50,
    EnableLtmRetrieveTheData = 51,
    EnableUpgradesVideos = 52,
    Max_None = 53,
    EFortUIFeature_MAX = 54
};struct FUIFeatureStateChangedDelegate__DelegateSignature
{
	public:
	    EFortUIFeature ChangedFeature; // 0x0 Size: 0x1
	    EFortUIFeatureState NewState; // 0x1 Size: 0x1
	    EFortUIFeatureStateReason StateReason; // 0x2 Size: 0x1

};

struct FUIFeatureStateChangedListener__DelegateSignature
{
	public:
	    EFortUIFeature ChangedFeature; // 0x0 Size: 0x1
	    EFortUIFeatureState NewState; // 0x1 Size: 0x1
	    EFortUIFeatureStateReason StateReason; // 0x2 Size: 0x1

};

struct FOnTeamPowerChanged__DelegateSignature
{
	public:
	    int TeamPower; // 0x0 Size: 0x4
	    int PersonalPower; // 0x4 Size: 0x4

};

struct FOnKeybindsChangedDelegate__DelegateSignature
{
	public:

};

struct FOnScoreReportChanged__DelegateSignature
{
	public:

};

struct FOnContextHelpItemsChanged__DelegateSignature
{
	public:

};

struct FOnItemReceivedNotificationShown__DelegateSignature
{
	public:
	    bool IsActive; // 0x0 Size: 0x1

};

struct FConsoleAccountPickerResult__DelegateSignature
{
	public:
	    int ControllerIndex; // 0x0 Size: 0x4
	    bool bUserSwitched; // 0x4 Size: 0x1
	    char UnknownData0[0x3];

};

struct FOnSubGameChanged__DelegateSignature
{
	public:
	    ESubGame SubGame; // 0x0 Size: 0x1

};

struct FFortGlobalUIContextGenericChange__DelegateSignature
{
	public:
	    class UObject* Source; // 0x0 Size: 0x8

};



enum class EFlagStatus : uint8_t
{
    FlagPresent = 0,
    FlagNotPresent = 1,
    EFlagStatus_MAX = 2
};struct FFortLastMissionInfo
{
	public:
	    struct FText TheaterName; // 0x0 Size: 0x18
	    struct FText MissionName; // 0x18 Size: 0x18
	    struct FText Difficulty; // 0x30 Size: 0x18

};

struct FFortBackendVersion
{
	public:
	    bool bIsValid; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FString App; // 0x8 Size: 0x10
	    struct FString ModuleName; // 0x18 Size: 0x10
	    struct FString Branch; // 0x28 Size: 0x10
	    struct FString BuildDate; // 0x38 Size: 0x10
	    struct FString ServerDate; // 0x48 Size: 0x10
	    struct FString Build; // 0x58 Size: 0x10
	    struct FString Changelist; // 0x68 Size: 0x10
	    struct FString OverridePropertiesVersion; // 0x78 Size: 0x10
	    struct FString Version; // 0x88 Size: 0x10

};



enum class EFortInputMode : uint8_t
{
    Frontend = 0,
    InGame = 1,
    InGameCursor = 2,
    EFortInputMode_MAX = 3
};

enum class EFortUrlType : uint8_t
{
    NormalWebLink = 0,
    AccountCreationLink = 1,
    HelpLink = 2,
    EULALink = 3,
    EFortUrlType_MAX = 4
};struct FFortUIFeatureStruct
{
	public:
	    EFortUIFeatureState CurrentState; // 0x0 Size: 0x1
	    EFortUIFeatureState ForcedState; // 0x1 Size: 0x1
	    EFortUIFeatureStateReason ForcedStateReason; // 0x2 Size: 0x1
	    char UnknownData0[0x5]; // 0x3
	    MulticastDelegateProperty ChangeDelegate; // 0x8 Size: 0x10

};

struct FPlayerDataChangedDelegate__DelegateSignature
{
	public:

};

struct FMcpSaveRequestResponse__DelegateSignature
{
	public:
	    bool bSuccess; // 0x0 Size: 0x1

};

struct FOnItemPickedUp__DelegateSignature
{
	public:
	    class UFortWorldItem* NewItem; // 0x0 Size: 0x8
	    int Count; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FQuickbarFocusChangedDelegate__DelegateSignature
{
	public:
	    EFortQuickBars QuickbarIndex; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    int Slot; // 0x4 Size: 0x4

};

struct FOnQuickbarFullUpdate__DelegateSignature
{
	public:
	    EFortQuickBars QuickbarIndex; // 0x0 Size: 0x1

};

struct FOnPinnedSchematicsChangedDelegate__DelegateSignature
{
	public:

};

struct FItemsChanged__DelegateSignature
{
	public:

};

struct FOnSchematicsLockedChanged__DelegateSignature
{
	public:

};

struct FOnCraftItemStarted__DelegateSignature
{
	public:

};

struct FOnCraftItemFailed__DelegateSignature
{
	public:
	    EFortCraftFailCause FailureCause; // 0x0 Size: 0x1

};

struct FOnSchematicUnlocked__DelegateSignature
{
	public:
	    class UFortSchematicItem* Schematic; // 0x0 Size: 0x8

};

struct FItemDefinitionChangedDelegate__DelegateSignature
{
	public:
	    class UFortItem* Item; // 0x0 Size: 0x8
	    class UFortItemDefinition* ItemDefinition; // 0x8 Size: 0x8

};

struct FItemDefinitionChangedListener__DelegateSignature
{
	public:
	    class UFortItem* Item; // 0x0 Size: 0x8
	    class UFortItemDefinition* ItemDefinition; // 0x8 Size: 0x8

};

struct FOnVaultItemLimitStateChanged__DelegateSignature
{
	public:

};



enum class EItemDisassembleRestrictionReason : uint8_t
{
    InnatelyCannotDisassemble = 0,
    ItemWasGifted = 1,
    EItemDisassembleRestrictionReason_MAX = 2
};

enum class EItemRecyclingRestrictionReason : uint8_t
{
    InnatelyUnrecyclable = 0,
    IsSlottedGroundOperative = 1,
    MissingCatalyst = 2,
    ItemOutOnExpedition = 3,
    InUseByCrafting = 4,
    EItemRecyclingRestrictionReason_MAX = 5
};struct FFortItemListFilter
{
	public:
	    struct FString SearchText; // 0x0 Size: 0x10
	    EFortInventoryFilter FilterType; // 0x10 Size: 0x1
	    bool bInStorageVault; // 0x11 Size: 0x1
	    bool bIncludeVaultOverflow; // 0x12 Size: 0x1
	    char UnknownData0[0x5];

};



enum class EItemRecyclingWarning : uint8_t
{
    HighLevel = 0,
    HighRarity = 1,
    HighTier = 2,
    CanSlotInCollectionBook = 3,
    EItemRecyclingWarning_MAX = 4
};

enum class EConversionControlKeyRequest : uint8_t
{
    AllKeys = 0,
    NonConsumableKeys = 1,
    ConsumableKeys = 2,
    EConversionControlKeyRequest_MAX = 3
};

enum class EVaultItemLimitStatus : uint8_t
{
    WellBelowCapacity = 0,
    NearCapacity = 1,
    AtCapacity = 2,
    OverCapacity = 3,
    EVaultItemLimitStatus_MAX = 4
};struct FWindowModeChanged__DelegateSignature
{
	public:
	    bool IsWindowedFullscreen; // 0x0 Size: 0x1

};

struct FFortTutorialDelegate__DelegateSignature
{
	public:

};

struct FUpdateTutorialAnnouncementDelegate__DelegateSignature
{
	public:
	    struct FFortClientAnnouncementData_Tutorial TutorialData; // 0x0 Size: 0x138
	    bool bShow; // 0x138 Size: 0x1
	    char UnknownData0[0x7];

};

struct FOnPropertyMenuStateChange__DelegateSignature
{
	public:
	    bool bNewlyOpen; // 0x0 Size: 0x1

};

struct FOnHUDLayoutModeChange__DelegateSignature
{
	public:
	    bool bShowCombat; // 0x0 Size: 0x1
	    bool bShowBuild; // 0x1 Size: 0x1
	    bool bShowEdit; // 0x2 Size: 0x1
	    bool bShowCreative; // 0x3 Size: 0x1

};

struct FOnWidgetSelected__DelegateSignature
{
	public:
	    class UHUDLayoutToolPlacementWidget* SelectedWidget; // 0x0 Size: 0x8

};

struct FOnCloseLayoutTool__DelegateSignature
{
	public:

};

struct FOnOpenLayoutTool__DelegateSignature
{
	public:

};

struct FOnRecenterPressed__DelegateSignature
{
	public:

};

struct FOnLayoutDirtyUpdated__DelegateSignature
{
	public:

};

struct FOnNewViewOffsetLerp__DelegateSignature
{
	public:
	    struct FVector2D NewOffset; // 0x0 Size: 0x8

};

struct FOnViewOffsetUpdated__DelegateSignature
{
	public:
	    struct FVector2D NewOffset; // 0x0 Size: 0x8

};

struct FOnOpenCloseFireModePanel__DelegateSignature
{
	public:
	    bool bNewlyOpen; // 0x0 Size: 0x1

};

struct FOnFireModeChange__DelegateSignature
{
	public:
	    EFireModeType NewFireMode; // 0x0 Size: 0x1

};

struct FOnCreativeIslandCodeConfirmed__DelegateSignature
{
	public:
	    class UFortCreativeIslandLink* IslandLink; // 0x0 Size: 0x8

};

struct FFortGlobalActionDetailsDataSourceOnChangeDelegate__DelegateSignature
{
	public:
	    class UObject* Source; // 0x0 Size: 0x8

};

struct FFortTimespanDataSourceOnChangeDelegate__DelegateSignature
{
	public:
	    class UObject* Source; // 0x0 Size: 0x8

};

struct FOnExpeditionListViewRefreshed__DelegateSignature
{
	public:

};

struct FOnExpeditionListItemSelected__DelegateSignature
{
	public:
	    class UFortExpeditionItem* Item; // 0x0 Size: 0x8

};

struct FOnAllExpeditionsCollected__DelegateSignature
{
	public:

};

struct FSetUIStateDelegate__DelegateSignature
{
	public:

};

struct FFortEnabledStateChanged__DelegateSignature
{
	public:
	    class UFortBaseButton* Button; // 0x0 Size: 0x8
	    bool Enabled; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FFortSelectedStateChanged__DelegateSignature
{
	public:
	    class UFortBaseButton* Button; // 0x0 Size: 0x8
	    bool Selected; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FFortBaseButtonClicked__DelegateSignature
{
	public:
	    class UFortBaseButton* Button; // 0x0 Size: 0x8

};

struct FOnChatEnteredDelegate__DelegateSignature
{
	public:
	    bool bEnteringChat; // 0x0 Size: 0x1

};

struct FOnUserListChangedDelegate__DelegateSignature
{
	public:
	    bool bOpen; // 0x0 Size: 0x1

};

struct FLoadItemsComplete__DelegateSignature
{
	public:

};

struct FOnSizeEstimateChanged__DelegateSignature
{
	public:
	    class UObject* ChangedElement; // 0x0 Size: 0x8

};



enum class EFortItemCooldownType : uint8_t
{
    None = 0,
    AmmoRegeneration = 1,
    ItemActivation = 2,
    WeaponReloading = 3,
    Death = 4,
    AthenaWeaponFireCooldown = 5,
    EFortItemCooldownType_MAX = 6
};struct FOnCooldownBookend__DelegateSignature
{
	public:
	    EFortItemCooldownType CooldownType; // 0x0 Size: 0x1

};

struct FFortStateStyle
{
	public:
	    struct FFortMultiSizeBrush Brush; // 0x0 Size: 0x330
	    struct FLinearColor PrimaryColor; // 0x330 Size: 0x10
	    struct FLinearColor SecondaryColor; // 0x340 Size: 0x10

};



enum class EFortTutorialGlowType : uint8_t
{
    None = 0,
    Look = 1,
    Click = 2,
    EFortTutorialGlowType_MAX = 3
};

enum class EFortBangSize : uint8_t
{
    XXS = 0,
    XS = 1,
    S = 2,
    M = 3,
    L = 4,
    XL = 5,
    EFortBangSize_MAX = 6
};struct FOnCloseLegacyWidget__DelegateSignature
{
	public:

};

struct FOnMediaWidgetMediaOpened__DelegateSignature
{
	public:

};

struct FFortCountingFinished__DelegateSignature
{
	public:
	    class UFortNumericTextBlock* NumericTextBlock; // 0x0 Size: 0x8

};

struct FOnMessageItemDisplayStateChange__DelegateSignature
{
	public:
	    class UFortUIMessageItemWidget* MessageItem; // 0x0 Size: 0x8

};

struct FOnMessageAvailable__DelegateSignature
{
	public:

};

struct FUINavigationData
{
	public:
	    struct FText DisplayName; // 0x0 Size: 0x18
	    class UObject* ObjectData; // 0x18 Size: 0x8
	    FName IdData; // 0x20 Size: 0x8
	    int IntData; // 0x28 Size: 0x4
	    char UnknownData0[0x4];

};

struct FUINavigateGlobalDelegate__DelegateSignature
{
	public:
	    struct FUINavigationData Data; // 0x0 Size: 0x30

};

struct FUINavigateDelegate__DelegateSignature
{
	public:
	    struct FUINavigationData Data; // 0x0 Size: 0x30

};

struct FFortTabNavigateRequest__DelegateSignature
{
	public:
	    EFrontEndCamera State; // 0x0 Size: 0x1

};

struct FFortNodePageNavigateRequest__DelegateSignature
{
	public:
	    FName PageId; // 0x0 Size: 0x8
	    FName NodeId; // 0x8 Size: 0x8

};

struct FFortVaultTabNavigateRequest__DelegateSignature
{
	public:
	    EFortInventoryFilter VaultTab; // 0x0 Size: 0x1

};

struct FFortSquadSlotNavigateRequest__DelegateSignature
{
	public:
	    FName SquadId; // 0x0 Size: 0x8
	    int SquadSlotIndex; // 0x8 Size: 0x4

};

struct FFortVaultItemNavigateRequest__DelegateSignature
{
	public:
	    class UFortAccountItem* Item; // 0x0 Size: 0x8

};

struct FFortItemEvolutionNavigateRequest__DelegateSignature
{
	public:
	    class UFortAccountItem* Item; // 0x0 Size: 0x8

};

struct FFortQuestItemNavigateRequest__DelegateSignature
{
	public:
	    class UFortQuestItem* QuestItem; // 0x0 Size: 0x8

};

struct FFortFeatureNavigateOp__DelegateSignature
{
	public:
	    EFortUIFeature Feature; // 0x0 Size: 0x1

};

struct FFortPopContentStackOp__DelegateSignature
{
	public:

};

struct FFortSquadOp__DelegateSignature
{
	public:
	    FName SquadId; // 0x0 Size: 0x8
	    int SquadSlotIndex; // 0x8 Size: 0x4

};

struct FFortItemManagementScreenOp__DelegateSignature
{
	public:
	    EFortFrontendInventoryFilter Filter; // 0x0 Size: 0x1

};

struct FFortQuestItemOp__DelegateSignature
{
	public:
	    class UFortQuestItem* QuestItem; // 0x0 Size: 0x8

};

struct FFortExpeditionsOp__DelegateSignature
{
	public:

};

struct FFortCollectionBookOp__DelegateSignature
{
	public:

};



enum class EViewerNavigationDirection : uint8_t
{
    Previous = 0,
    Next = 1,
    EViewerNavigationDirection_MAX = 2
};struct FOnMapViewerRequestNavigation__DelegateSignature
{
	public:
	    EViewerNavigationDirection NavigationDirection; // 0x0 Size: 0x1

};

struct FOnMapViewerRequestCurrentQuestNavigation__DelegateSignature
{
	public:

};

struct FSocialImportPanelClosedDelegate__DelegateSignature
{
	public:

};

struct FMissionSelectNavigationDelegate__DelegateSignature
{
	public:
	    EUINavigation NavigationDirection; // 0x0 Size: 0x1

};

struct FOnRewardWidgetTransitionDelegate__DelegateSignature
{
	public:

};

struct FOnExpeditionMcpErrorDelegate__DelegateSignature
{
	public:

};

struct FOnTabSettingChanged__DelegateSignature
{
	public:

};

struct FOnTabActivated__DelegateSignature
{
	public:

};

struct FOnTabDeactivated__DelegateSignature
{
	public:

};

struct FRequestOpenCardPackDelegate__DelegateSignature
{
	public:
	    int PackIndex; // 0x0 Size: 0x4

};

struct FOnContextMenuOpenChangedEvent__DelegateSignature
{
	public:
	    bool bIsOpen; // 0x0 Size: 0x1

};

struct FGridSortKey
{
	public:
	    float Number; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    struct FString String; // 0x8 Size: 0x10

};

struct FGetSortKeyFor__DelegateSignature
{
	public:
	    class UObject* Data; // 0x0 Size: 0x8
	    struct FGridSortKey ReturnValue; // 0x8 Size: 0x18

};

struct FGridPickerTileEvent__DelegateSignature
{
	public:
	    class UObject* Data; // 0x0 Size: 0x8
	    class UFortGridPickerTile* Tile; // 0x8 Size: 0x8

};



enum class EGridSortKind : uint8_t
{
    None = 0,
    ByNumber = 1,
    ByString = 2,
    ByNumberThenString = 3,
    ByStringThenNumber = 4,
    EGridSortKind_MAX = 5
};struct FOnFortSwipeEvent__DelegateSignature
{
	public:

};

struct FOnItemToRepresentChanged__DelegateSignature
{
	public:
	    class UFortItem* NewItemToRepresent; // 0x0 Size: 0x8

};

struct FFortReceivedItemLootInfo
{
	public:
	    class UFortItemDefinition* ItemDef; // 0x0 Size: 0x8
	    int Quantity; // 0x8 Size: 0x4
	    char UnknownData0[0x4]; // 0xc
	    struct FString TemplateId; // 0x10 Size: 0x10
	    class UFortItem* GeneratedItemInstance; // 0x20 Size: 0x8

};

struct FOnMediaPlayerEndReached__DelegateSignature
{
	public:

};

struct FOnMissionTrackerListVisibilityChanged__DelegateSignature
{
	public:

};

struct FOnMissionEntryVisibilityChanged__DelegateSignature
{
	public:

};

struct FOnMissionSubEntryVisibilityChanged__DelegateSignature
{
	public:

};

struct FOnFortNotificationAvailable__DelegateSignature
{
	public:

};

struct FOnPrivacyChanged__DelegateSignature
{
	public:
	    EPartyType PrivacyType; // 0x0 Size: 0x1
	    bool bAllowFriendsOfFriends; // 0x1 Size: 0x1

};

struct FObjectiveFinishedDisplaying__DelegateSignature
{
	public:
	    class UFortQuestObjectiveEntry* QuestObjective; // 0x0 Size: 0x8

};

struct FOnHUDQuestFinalObjectiveHidden__DelegateSignature
{
	public:
	    class UFortQuestItem* QuestItem; // 0x0 Size: 0x8

};

struct FOnHUDQuestObjectiveCompleted__DelegateSignature
{
	public:
	    class UFortQuestObjectiveInfo* QuestObjective; // 0x0 Size: 0x8

};

struct FFinishedDisplayingQuests__DelegateSignature
{
	public:
	    class UFortQuestUpdateEntry* QuestEntry; // 0x0 Size: 0x8

};

struct FItemWidgetCreated__DelegateSignature
{
	public:
	    class UWidget* Widget; // 0x0 Size: 0x8
	    class UFortItem* Item; // 0x8 Size: 0x8

};



enum class ESquadSlotSortType : uint8_t
{
    ByRating = 0,
    ByLevel = 1,
    ByRarity = 2,
    ByBonus = 3,
    ByMatch = 4,
    ESquadSlotSortType_MAX = 5
};struct FOnRequestSquadSlotAction__DelegateSignature
{
	public:
	    int SquadSlotIndex; // 0x0 Size: 0x4

};

struct FPopulatePrerollOffersCallback__DelegateSignature
{
	public:
	    bool bSuccess; // 0x0 Size: 0x1

};

struct FOnRedeemCodeFlowComplete__DelegateSignature
{
	public:

};

struct FOnVariantChangedEvent__DelegateSignature
{
	public:
	    struct FGameplayTag VariantChannel; // 0x0 Size: 0x8
	    struct FGameplayTag VariantTag; // 0x8 Size: 0x8
	    bool IsOwned; // 0x10 Size: 0x1
	    char UnknownData0[0x3];

};



enum class EEquippedWeaponDisplay : uint8_t
{
    None = 0,
    Resource = 1,
    Magazine = 2,
    Utility = 3,
    EEquippedWeaponDisplay_MAX = 4
};

enum class EAthenaEventMatchInfoSortMethod : uint8_t
{
    Eliminations = 0,
    Place = 1,
    Count = 2,
    EAthenaEventMatchInfoSortMethod_MAX = 3
};

enum class EAthenaPlayerActionAlert : uint8_t
{
    PlayerDown = 0,
    PlayerKill = 1,
    EnteredStorm = 2,
    EAthenaPlayerActionAlert_MAX = 3
};

enum class EFortAthenaPlaylist : uint8_t
{
    AthenaSolo = 0,
    AthenaDuo = 1,
    AthenaSquad = 2,
    EFortAthenaPlaylist_MAX = 3
};

enum class EHealthBarType : uint8_t
{
    Health = 0,
    Shield = 1,
    Stamina = 2,
    VehicleHealth = 3,
    EHealthBarType_MAX = 4
};

enum class ERespawnUIState : uint8_t
{
    Hidden = 0,
    ShowRespawnEnabled = 1,
    ShowRespawnDisabled = 2,
    ERespawnUIState_MAX = 3
};

enum class ESpectatorMapPlayerListState : uint8_t
{
    Default = 0,
    Irrelevant = 1,
    Eliminated = 2,
    ESpectatorMapPlayerListState_MAX = 3
};

enum class EAthenaSpectatorNameplateDistanceState : uint8_t
{
    Near = 0,
    MidDistance = 1,
    FurtherThanMaxDistance = 2,
    EAthenaSpectatorNameplateDistanceState_MAX = 3
};

enum class EStormSurgeThresholdType : uint8_t
{
    None = 0,
    Above = 1,
    Below = 2,
    Equal = 3,
    EStormSurgeThresholdType_MAX = 4
};

enum class EComboSlotType : uint8_t
{
    Primary = 0,
    Secondary = 1,
    Combo = 2,
    COUNT = 3,
    EComboSlotType_MAX = 4
};

enum class EBacchusSignalQuality : uint8_t
{
    None = 0,
    Low = 1,
    Medium = 2,
    High = 3,
    EBacchusSignalQuality_MAX = 4
};

enum class EAthenaNewsStyle : uint8_t
{
    None = 0,
    SpecialEvent = 1,
    EAthenaNewsStyle_MAX = 2
};

enum class ESubGameFilter : uint8_t
{
    All = 0,
    SaveTheWorld = 1,
    BattleRoyale = 2,
    ESubGameFilter_MAX = 3
};

enum class ESurvivalObjectiveIconState : uint8_t
{
    None = 0,
    Spawned = 1,
    Destroyed = 2,
    ESurvivalObjectiveIconState_MAX = 3
};

enum class EDiscoCaptureUIState : uint8_t
{
    None = 0,
    Hidden = 1,
    Dance = 2,
    Capturing = 3,
    Contested = 4,
    EDiscoCaptureUIState_MAX = 5
};

enum class EDiscoScoreProgressTypes : uint8_t
{
    None = 0,
    ProgressSoundMild = 1,
    ProgressSoundMedium = 2,
    ProgressSoundStrong = 3,
    CountdownSoundNormal = 4,
    CountdownSoundStrong = 5,
    EDiscoScoreProgressTypes_MAX = 6
};

enum class EDiscoCaptureProgressState : uint8_t
{
    None = 0,
    AllyProgress = 1,
    EnemyProgress = 2,
    EDiscoCaptureProgressState_MAX = 3
};

enum class EDiscoCaptureIconState : uint8_t
{
    None = 0,
    Hidden = 1,
    Neutral = 2,
    AllyCaptured = 3,
    EnemyCaptured = 4,
    EDiscoCaptureIconState_MAX = 5
};

enum class EPlayerReportingStep : uint8_t
{
    ReportingPlayer = 0,
    ReportingReason = 1,
    AdditionalInfo = 2,
    EPlayerReportingStep_MAX = 3
};

enum class EFortAlterationOptionType : uint8_t
{
    Upgrade = 0,
    Replacement = 1,
    Max_NONE = 2,
    EFortAlterationOptionType_MAX = 3
};

enum class EFortAlterationWidgetState : uint8_t
{
    Normal = 0,
    Upgrade = 1,
    Evolution = 2,
    EFortAlterationWidgetState_MAX = 3
};

enum class EFillDisableReason : uint8_t
{
    Enabled = 0,
    FillDisabledOnPlaylist = 1,
    NotPartyLeader = 2,
    AlreadyMatchmaking = 3,
    PartyTooSmall = 4,
    PartyTooBig = 5,
    InactiveTournament = 6,
    CreativeModeWarning = 7,
    EFillDisableReason_MAX = 8
};

enum class EServerAccessSetting : uint8_t
{
    Invalid = 0,
    FriendsOfCurrentPlayers = 1,
    LeaderInviteOnly = 2,
    EServerAccessSetting_MAX = 3
};

enum class ESpectatorQueueType : uint8_t
{
    Invalid = 0,
    Player = 1,
    Spectator = 2,
    ESpectatorQueueType_MAX = 3
};

enum class ESquadFillSetting : uint8_t
{
    Invalid = 0,
    Fill = 1,
    NoFill = 2,
    ESquadFillSetting_MAX = 3
};

enum class ECollectionBookRewardStatus : uint8_t
{
    Unknown = 0,
    Available = 1,
    Claimed = 2,
    ECollectionBookRewardStatus_MAX = 3
};

enum class ECollectionBookPrimaryNavTarget : uint8_t
{
    Overview = 0,
    SectionTileView = 1,
    ECollectionBookPrimaryNavTarget_MAX = 2
};

enum class EFortCreativeIslandLinkCategory : uint8_t
{
    Default = 0,
    Favorite = 1,
    Published = 2,
    Recent = 3,
    EFortCreativeIslandLinkCategory_MAX = 4
};

enum class EFortCreativeIslandLinkValidationResult : uint8_t
{
    Unknown = 0,
    Success = 1,
    IslandNotFound = 2,
    InvalidKeyTooShort = 3,
    InvalidKeyTooLong = 4,
    InvalidKeyCharacters = 5,
    EFortCreativeIslandLinkValidationResult_MAX = 6
};

enum class EFortCreativeServerPrivacySetting : uint8_t
{
    Unknown = 0,
    Private = 1,
    Public = 2,
    EFortCreativeServerPrivacySetting_MAX = 3
};

enum class EFortDefenderSlotType : uint8_t
{
    Invalid = 0,
    Defender = 1,
    Weapon = 2,
    EFortDefenderSlotType_MAX = 3
};

enum class EDynamicEntryPatternDirection : uint8_t
{
    FirstToLast = 0,
    LastToFirst = 1,
    EDynamicEntryPatternDirection_MAX = 2
};

enum class EFortExpeditionListSort : uint8_t
{
    ByRating = 0,
    ByDuration = 1,
    ByName = 2,
    EFortExpeditionListSort_MAX = 3
};

enum class EShareButtonType : uint8_t
{
    IOS = 0,
    Android = 1,
    Generic = 2,
    EShareButtonType_MAX = 3
};

enum class EFrontEndRewardType : uint8_t
{
    Mission = 0,
    Quest = 1,
    EpicNewQuest = 2,
    Expedition = 3,
    CollectionBook = 4,
    MissionAlert = 5,
    DifficultyIncrease = 6,
    GiftBox = 7,
    ItemCache = 8,
    EFrontEndRewardType_MAX = 9
};

enum class EFortUIGameFeedbackType : uint8_t
{
    Bug = 0,
    Comment = 1,
    Player = 2,
    Content = 3,
    EFortUIGameFeedbackType_MAX = 4
};

enum class ESelectionState : uint8_t
{
    Unselected = 0,
    Selected = 1,
    CannotGift = 2,
    ESelectionState_MAX = 3
};

enum class ENameStatus : uint8_t
{
    Valid = 0,
    TooShort = 1,
    TooLong = 2,
    ContainsInvalidCharacter = 3,
    ENameStatus_MAX = 4
};

enum class EFortSupportPerkWidgetState : uint8_t
{
    Normal = 0,
    Upgrade = 1,
    Evolution = 2,
    EFortSupportPerkWidgetState_MAX = 3
};

enum class ECenterPopupMessageStateEnum : uint8_t
{
    NotVisible = 0,
    WaitingForMatchDelayCountDown = 1,
    WaitingForOutpostOwner = 2,
    WaitingForPlayers = 3,
    ECenterPopupMessageStateEnum_MAX = 4
};

enum class EBuildingFocusType : uint8_t
{
    Contextual = 0,
    Interactable = 1,
    Normal = 2,
    Count = 3,
    EBuildingFocusType_MAX = 4
};

enum class EFortItemCountStyle : uint8_t
{
    StackCount = 0,
    OverrideCount = 1,
    StackCountOverOverride = 2,
    EFortItemCountStyle_MAX = 3
};

enum class EFortItemInspectionMode : uint8_t
{
    Overview = 0,
    Details = 1,
    View = 2,
    Evolution = 3,
    Upgrade = 4,
    UpgradeRarity = 5,
    EFortItemInspectionMode_MAX = 6
};

enum class EFortItemManagementMode : uint8_t
{
    Details = 0,
    Comparison = 1,
    Mulch = 2,
    EFortItemManagementMode_MAX = 3
};

enum class EFortKeybindForcedHoldStatus : uint8_t
{
    NoForcedHold = 0,
    ForcedHold = 1,
    NeverShowHold = 2,
    EFortKeybindForcedHoldStatus_MAX = 3
};

enum class EFortLegacySlateWidget : uint8_t
{
    None = 0,
    Minimap = 1,
    MAX = 2
};

enum class ELocalUserOnlineStatus : uint8_t
{
    Online = 0,
    Offline = 1,
    Away = 2,
    ExtendedAway = 3,
    DoNotDisturb = 4,
    Chat = 5,
    ELocalUserOnlineStatus_MAX = 6
};

enum class UFortMatchmakingKnobsDataSource : uint8_t
{
    Playlist = 0,
    Mutator = 1,
    GameMode = 2,
    Permissions = 3,
    UFortMatchmakingKnobsDataSource_MAX = 4
};

enum class EFortMaterialProgressBarSectionOverflowBehavior : uint8_t
{
    PreserveValues = 0,
    ReverseCollapse = 1,
    EFortMaterialProgressBarSectionOverflowBehavior_MAX = 2
};

enum class EFortMaterialProgressBarSectionColorNumber : uint8_t
{
    Color1 = 0,
    Color2 = 1,
    EFortMaterialProgressBarSectionColorNumber_MAX = 2
};

enum class EFortMaterialProgressBarSection : uint8_t
{
    Primary = 0,
    Secondary = 1,
    Tertiary = 2,
    Negative = 3,
    MAX_PROGRESS_BAR_SECTIONS = 4,
    EFortMaterialProgressBarSection_MAX = 5
};

enum class EFortMissionActivationWidgetState : uint8_t
{
    Default = 0,
    StartObjective = 1,
    IncreaseDifficulty = 2,
    Invalid = 3,
    EFortMissionActivationWidgetState_MAX = 4
};

enum class EFortFortMobileShareButtonOS : uint8_t
{
    Android = 0,
    iOS = 1,
    EFortFortMobileShareButtonOS_MAX = 2
};

enum class EModalContainerSlot : uint8_t
{
    Top = 0,
    Middle = 1,
    Bottom = 2,
    Background = 3,
    Max = 4
};

enum class EFortMtxStoreOfferType : uint8_t
{
    FoundersPack = 0,
    CurrencyPack = 1,
    Unknown = 2,
    Max_None = 3,
    EFortMtxStoreOfferType_MAX = 4
};

enum class ESettingTab : uint8_t
{
    None = 0,
    Video = 1,
    Game = 2,
    Brightness = 3,
    Audio = 4,
    Accessibility = 5,
    Input = 6,
    Controller = 7,
    Account = 8,
    CreativeWorld = 9,
    CreativePlayer = 10,
    ESettingTab_MAX = 11
};

enum class ESettingValueType : uint8_t
{
    None = 0,
    Rotator = 1,
    Slider = 2,
    ESettingValueType_MAX = 3
};

enum class ESettingType : uint8_t
{
    None = 0,
    Header = 1,
    WindowMode = 2,
    DisplayResolution = 3,
    FrameRateLimit = 4,
    VideoQuality = 5,
    ThreeDResolution = 6,
    ViewDistance = 7,
    Shadows = 8,
    AntiAliasing = 9,
    Textures = 10,
    Effects = 11,
    PostProcessing = 12,
    VSync = 13,
    MotionBlur = 14,
    ShowGrass = 15,
    MobileFPSType = 16,
    ShowFPS = 17,
    AllowLowPower = 18,
    AllowVideoPlayback = 19,
    AllowDynamicResolution = 20,
    RegionHeader = 21,
    Language = 22,
    Region = 23,
    MouseSensitivityYaw = 24,
    MouseSensitivityPitch = 25,
    MouseSensitivityMultiplierForAircraft = 26,
    TouchDragSensitivity = 27,
    ControllerLookSensitivityYaw = 28,
    ControllerLookSensitivityPitch = 29,
    MouseTargetingMultiplier = 30,
    MouseScopedMultiplier = 31,
    GamepadTargetingMultiplier = 32,
    GamepadScopedMultiplier = 33,
    GamepadBuildingMultiplier = 34,
    TouchDragTargetingSensitivity = 35,
    TouchDragScopedSensitivity = 36,
    TouchVerticalSensitivity = 37,
    InvertPitch = 38,
    InvertYaw = 39,
    InvertPitchForMotion = 40,
    InvertPitchForAircraftPrimary = 41,
    InvertPitchForAircraftSecondary = 42,
    InvertYawForMotion = 43,
    GyroEnabled = 44,
    GyroYawAxis = 45,
    GyroSensitivity = 46,
    GyroTargetingSensitivity = 47,
    GyroScopedSensitivity = 48,
    GyroHarvestingToolSensitivity = 49,
    SafeZone = 50,
    StreamerMode = 51,
    HiddenMatchmakingDelay = 52,
    HUDScale = 53,
    ShowViewerCount = 54,
    FirstPersonCamera = 55,
    PeripheralLighting = 56,
    ShowGlobalChat = 57,
    ConsoleUnlockedFPS = 58,
    ToggleSprint = 59,
    SprintByDefault = 60,
    SprintCancelsReload = 61,
    TapInteract = 62,
    ToggleTargeting = 63,
    AutoEquipBetterItems = 64,
    EquipFirstBuildingPieceWhenSwappingQuickbars = 65,
    EquipFirstBuildingPieceWhenSwappingQuickbarsAthena = 66,
    AimAssist = 67,
    EditModeAimAssist = 68,
    TurboBuild = 69,
    CreativeTurboDelete = 70,
    AutoChangeMaterial = 71,
    GamepadAutoRun = 72,
    CrossplayPreference = 73,
    UseTapToShoot = 74,
    AutoOpenDoors = 75,
    AutoPickupWeapons = 76,
    AutoPickupWeaponsConsolePC = 77,
    AutoSortConsumablesToRight = 78,
    EnableTryBuildOnFocus = 79,
    EditButtonHoldTime = 80,
    ShowHeadAccessories = 81,
    ShowBackpack = 82,
    ForceFeedback = 83,
    ReplayRecording = 84,
    ReplayRecordingLargeTeams = 85,
    ReplayRecordingCreativeMode = 86,
    UsePowerSavingMode = 87,
    ShadowPlayHighlights = 88,
    GammaValue = 89,
    MusicVolume = 90,
    SoundFXVolume = 91,
    DialogVolume = 92,
    VoiceChatVolume = 93,
    CinematicsVolume = 94,
    Subtitles = 95,
    Quality = 96,
    VoiceChat = 97,
    PushToTalk = 98,
    ProximityVoiceChat = 99,
    VoiceChatInputDevice = 100,
    VoiceChatOutputDevice = 101,
    AllowBackgroundAudio = 102,
    ColorBlindMode = 103,
    ColorBlindStrength = 104,
    IgnoreGamepadInput = 105,
    VisualizeSoundEffects = 106,
    VisualizeSoundEffectsHeader = 107,
    ESettingType_MAX = 108
};

enum class EFortPerksWidgetState : uint8_t
{
    Normal = 0,
    Upgrade = 1,
    Evolution = 2,
    EFortPerksWidgetState_MAX = 3
};

enum class ESaveProfileForBanners : uint8_t
{
    SaveTheWorld = 0,
    BattleRoyale = 1,
    ESaveProfileForBanners_MAX = 2
};

enum class EItemRefundability : uint8_t
{
    NotRefundable = 0,
    Refundable = 1,
    AlreadyRefunded = 2,
    EItemRefundability_MAX = 3
};

enum class EPurchaseReturnStep : uint8_t
{
    ItemSelection = 0,
    ReasonSelection = 1,
    FinalSubmission = 2,
    EPurchaseReturnStep_MAX = 3
};

enum class EQuestMapScreenMode : uint8_t
{
    MainCampaign = 0,
    Event = 1,
    EQuestMapScreenMode_MAX = 2
};

enum class ERedeemCodeFailureReason : uint8_t
{
    InvalidCode = 0,
    CodeAlreadyUsed = 1,
    AlreadyHasAccess = 2,
    FailedToGetItem = 3,
    Unknown = 4,
    ERedeemCodeFailureReason_MAX = 5
};

enum class EFortRewardItemType : uint8_t
{
    RewardedBadges = 0,
    MissedBadges = 1,
    RewardedItems = 2,
    RewardedAccountItems = 3,
    EFortRewardItemType_MAX = 4
};

enum class EFortShowdownPinState : uint8_t
{
    None = 0,
    Locked = 1,
    Unlocked = 2,
    EFortShowdownPinState_MAX = 3
};

enum class EFortShowdownEventState : uint8_t
{
    Unknown = 0,
    FutureTBD = 1,
    FutureScheduled = 2,
    FutureNext = 3,
    LiveParticipating = 4,
    LiveNotParticipating = 5,
    CompletedParticipated = 6,
    CompletedNotPartipated = 7,
    Cancelled = 8,
    EFortShowdownEventState_MAX = 9
};

enum class EFortShowdownMatchType : uint8_t
{
    Unknown = 0,
    Solo = 1,
    Duos = 2,
    Squads = 3,
    EFortShowdownMatchType_MAX = 4
};

enum class EFortDateTimeStyle : uint8_t
{
    Default = 0,
    Short = 1,
    Medium = 2,
    Long = 3,
    Full = 4,
    EFortDateTimeStyle_MAX = 5
};

enum class ESocialImportPanelType : uint8_t
{
    Athena = 0,
    SaveTheWorld = 1,
    ESocialImportPanelType_MAX = 2
};

enum class EFriendLinkShareButtonType : uint8_t
{
    IOS = 0,
    Android = 1,
    Generic = 2,
    EFriendLinkShareButtonType_MAX = 3
};

enum class EFortSquadSlottingRestrictionReason : uint8_t
{
    ItemIsInInventoryOverflow = 0,
    MandatorySlotWouldBeEmptied = 1,
    ItemIsOnActiveExpedition = 2,
    HeroRequiresMissingGameplayTag = 3,
    EFortSquadSlottingRestrictionReason_MAX = 4
};

enum class EPauseType : uint8_t
{
    NoPause = 0,
    Rare = 1,
    New = 2,
    NewAndRare = 3,
    EPauseType_MAX = 4
};

enum class ECardPackPurchaseError : uint8_t
{
    PendingServerConfirmation = 0,
    CannotAffordItem = 1,
    NoneLeft = 2,
    PurchaseAlreadyPending = 3,
    NoConnection = 4,
    ECardPackPurchaseError_MAX = 5
};

enum class EFortStoreTransition : uint8_t
{
    X = 0,
    EFortStoreTransition_MAX = 1
};

enum class EFortSubgameSelectOption : uint8_t
{
    Campaign = 0,
    Athena = 1,
    Creative = 2,
    Invalid = 3,
    Count = 3,
    EFortSubgameSelectOption_MAX = 4
};

enum class EFortUISurvivorSquadMatchType : uint8_t
{
    Multi = 0,
    Single = 1,
    Summary = 2,
    Max_None = 3,
    EFortUISurvivorSquadMatchType_MAX = 4
};

enum class ETouchState : uint8_t
{
    None = 0,
    WaitingForStart = 1,
    Started = 2,
    Active = 3,
    COUNT = 4,
    ETouchState_MAX = 5
};

enum class EFortControlType : uint8_t
{
    None = 0,
    CameraAndMovement = 1,
    Picking = 2,
    COUNT = 3,
    EFortControlType_MAX = 4
};

enum class EFortTouchControlRegion : uint8_t
{
    MovePlayer = 0,
    RotateCamera = 1,
    NoRegion = 2,
    COUNT = 3,
    EFortTouchControlRegion_MAX = 4
};

enum class EFortReturnToFrontendBehavior : uint8_t
{
    NotSpecified = 0,
    HomeScreen = 1,
    MapScreen = 2,
    MapScreenWithAutoLaunch = 3,
    MapScreenWithMinimalAutoLaunch = 4,
    EFortReturnToFrontendBehavior_MAX = 5
};

enum class EFortUINavigationOp : uint8_t
{
    PopContentStack = 0,
    FeatureSwitch = 1,
    NavigateToSkillTree = 2,
    NavigateToSquadSlot = 3,
    NavigateToQuest = 4,
    NavigateToItemManagement = 5,
    NavigateToExpeditions = 6,
    NavigateToCollectionBook = 7,
    None = 8,
    EFortUINavigationOp_MAX = 9
};

enum class EFortLoginAccountType : uint8_t
{
    None = 0,
    EpicAccount = 1,
    Facebook = 2,
    Google = 3,
    PSN = 4,
    XBLive = 5,
    Erebus = 6,
    EFortLoginAccountType_MAX = 7
};

enum class EPlayerReportReasons : uint8_t
{
    None = 0,
    Communication = 1,
    Offensive = 2,
    AFK = 3,
    IgnoringObjective = 4,
    Harassment = 5,
    Exploiting = 6,
    TradeScam = 7,
    CommunicationsAbuse = 8,
    OffensiveName = 9,
    TeamingUpWithEnemies = 10,
    InappropriateContent = 11,
    ExploitingOrHacking = 12,
    EPlayerReportReasons_MAX = 13
};

enum class EFortComparisonType : uint8_t
{
    None = 0,
    HigherValue = 1,
    LowerValue = 2,
    Upgrade = 3,
    EFortComparisonType_MAX = 4
};

enum class EFortClampState : uint8_t
{
    NoClamp = 0,
    MinClamp = 1,
    MaxClamp = 2,
    EFortClampState_MAX = 3
};

enum class EFortBuffState : uint8_t
{
    NoChange = 0,
    Better = 1,
    Worse = 2,
    EFortBuffState_MAX = 3
};

enum class EFortStatValueDisplayType : uint8_t
{
    BasicPaired = 0,
    BasicSingle = 1,
    Unique = 2,
    ElementalFire = 3,
    ElementalIce = 4,
    ElementalElectric = 5,
    EFortStatValueDisplayType_MAX = 6
};

enum class EFortAnimSpeed : uint8_t
{
    Instant = 0,
    Fast = 1,
    Normal = 2,
    EFortAnimSpeed_MAX = 3
};

enum class EFortSocialPanelTab : uint8_t
{
    PartyInvitations = 0,
    Friends = 1,
    RecentPlayers = 2,
    Max = 3
};

enum class EFortSocialPanelType : uint8_t
{
    Join = 0,
    Invite = 1,
    Max = 2
};

enum class EModalContainerSize : uint8_t
{
    ExtraSmall = 0,
    Small = 1,
    Medium = 2,
    Large = 3,
    Max = 4
};

enum class ENotificationType : uint8_t
{
    Basic = 0,
    Friends = 1,
    ENotificationType_MAX = 2
};

enum class ENotificationResult : uint8_t
{
    Confirmed = 0,
    Declined = 1,
    Unknown = 2,
    ENotificationResult_MAX = 3
};

enum class EFortInventoryContext : uint8_t
{
    Game = 0,
    Lobby = 1,
    FrontEnd = 2,
    Pickup = 3,
    EFortInventoryContext_MAX = 4
};

enum class EFortToastType : uint8_t
{
    Default = 0,
    Subdued = 1,
    Impactful = 2,
    EFortToastType_MAX = 3
};

enum class EUpgradeInfoImageSize : uint8_t
{
    Small = 0,
    Large = 1,
    EUpgradeInfoImageSize_MAX = 2
};

enum class EHeistExitCraftIconState : uint8_t
{
    None = 0,
    Incoming = 1,
    Spawned = 2,
    Exited = 3,
    EHeistExitCraftIconState_MAX = 4
};

enum class EHeistBlingIconState : uint8_t
{
    None = 0,
    SupplyDrop = 1,
    PickupItem = 2,
    CarriedEnemy = 3,
    CarriedAlly = 4,
    EHeistBlingIconState_MAX = 5
};

enum class EHeistExitCraftUIState : uint8_t
{
    None = 0,
    OnTheWay = 1,
    Incoming = 2,
    Arrived = 3,
    EHeistExitCraftUIState_MAX = 4
};

enum class EMatchmakingInputSource : uint8_t
{
    Local = 0,
    Remote = 1,
    Pool = 2,
    EMatchmakingInputSource_MAX = 3
};

enum class EMinigameCaptureObjectiveIconState : uint8_t
{
    NotCaptured = 0,
    Captured = 1,
    EMinigameCaptureObjectiveIconState_MAX = 2
};

enum class ETDMScoreProgressTypes : uint8_t
{
    None = 0,
    ProgressSoundMild = 1,
    ProgressSoundMedium = 2,
    ProgressSoundStrong = 3,
    CountdownSoundNormal = 4,
    CountdownSoundStrong = 5,
    ETDMScoreProgressTypes_MAX = 6
};struct FLeaderboardFilter
{
	public:
	    class UDataTable* LeaderboardDisplayData; // 0x8 Size: 0x8
	    char UnknownData0[0x20];

};

struct FAthenaPlaylistLeaderboardData
{
	public:
	    FName StatId; // 0x0 Size: 0x8
	    struct FText StatDisplayName; // 0x8 Size: 0x18
	    struct FText TabDisplayName; // 0x20 Size: 0x18
	    struct FString BaseGameplayTag; // 0x38 Size: 0x10
	    bool bIsGlobal; // 0x48 Size: 0x1
	    char UnknownData0[0x7];

};

struct FStatGroupData
{
	public:
	    struct FText GroupName; // 0x0 Size: 0x18
	    struct FSlateBrush Group; // 0x18 Size: 0x88
	    float Value; // 0xa0 Size: 0x4
	    float ChartValue; // 0xa4 Size: 0x4
	    float ChartOrigionalValue; // 0xa8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FAthenaReplayBrowserMatchStats
{
	public:
	    int Hits; // 0x0 Size: 0x4
	    int Headshots; // 0x4 Size: 0x4
	    int Revives; // 0x8 Size: 0x4
	    int DamageTaken; // 0xc Size: 0x4
	    int DamagePlayers; // 0x10 Size: 0x4
	    int DamageStructures; // 0x14 Size: 0x4
	    int ChestsOpened; // 0x18 Size: 0x4
	    int Distance; // 0x1c Size: 0x4
	    int MaterialsGathered; // 0x20 Size: 0x4
	    int MaterialsUsed; // 0x24 Size: 0x4

};

struct FAthenaReplayBrowserRowData
{
	public:
	    struct FString Name; // 0x0 Size: 0x10
	    struct FDateTime Date; // 0x10 Size: 0x8
	    int Version; // 0x18 Size: 0x4
	    float Size; // 0x1c Size: 0x4
	    struct FString Mode; // 0x20 Size: 0x10
	    float Length; // 0x30 Size: 0x4
	    int Rank; // 0x34 Size: 0x4
	    int NumPlayers; // 0x38 Size: 0x4
	    int Kills; // 0x3c Size: 0x4
	    int Views; // 0x40 Size: 0x4
	    int Assists; // 0x44 Size: 0x4
	    int Accuracy; // 0x48 Size: 0x4
	    bool bIsOld; // 0x4c Size: 0x1
	    char UnknownData0[0x3]; // 0x4d
	    struct FAthenaReplayBrowserMatchStats MatchStats; // 0x50 Size: 0x28
	    bool bIsSaved; // 0x78 Size: 0x1
	    bool bIsCorrupt; // 0x79 Size: 0x1
	    bool bIsFeatured; // 0x7a Size: 0x1
	    char UnknownData1[0x15];

};

struct FAthenaTeamCountSlotData
{
	public:
	    struct FText TeamNameText; // 0x0 Size: 0x18
	    struct FText TeamCountText; // 0x18 Size: 0x18
	    bool bIsMyTeam; // 0x30 Size: 0x1
	    char UnknownData0[0x7];

};

struct FBackgroundColors
{
	public:
	    struct FLinearColor Color_0; // 0x0 Size: 0x10
	    struct FLinearColor Color_1; // 0x10 Size: 0x10
	    struct FLinearColor GridColor; // 0x20 Size: 0x10

};

struct FBarrierObjectState
{
	public:
	    class AAthenaBarrierObjective* ObjectiveActor; // 0x0 Size: 0x8
	    char TeamNum; // 0x8 Size: 0x1
	    EBarrierFoodTeam FoodTeam; // 0x9 Size: 0x1
	    EBarrierObjectiveDamageState DamageState; // 0xa Size: 0x1
	    char UnknownData0[0x5];

};

struct FAthenaBossHealthData
{
	public:
	    bool bVisible; // 0x0 Size: 0x1
	    bool bShowShields; // 0x1 Size: 0x1
	    char UnknownData0[0x6]; // 0x2
	    struct FText Name; // 0x8 Size: 0x18
	    int Health; // 0x20 Size: 0x4
	    int HealthMax; // 0x24 Size: 0x4
	    int Shields; // 0x28 Size: 0x4
	    int ShieldsMax; // 0x2c Size: 0x4

};

struct FAthenaNews
{
	public:
	    char UnknownData0[0x28];

};

struct FAthenaNewsEntry
{
	public:
	    char UnknownData0[0x48];

};

struct FAthenaLatestPlaylistData
{
	public:
	    char UnknownData0[0x80];

};

struct FAthenaPlaylistEntry
{
	public:
	    struct FString PlaylistName; // 0x0 Size: 0x10
	    struct FString DisplayName; // 0x10 Size: 0x10
	    struct FString DisplaySubName; // 0x20 Size: 0x10
	    struct FString Description; // 0x30 Size: 0x10
	    struct FString Violator; // 0x40 Size: 0x10
	    struct FString Image; // 0x50 Size: 0x10
	    int CropOffset; // 0x60 Size: 0x4
	    EFortMatchmakingTileStyle SpecialBorderId; // 0x64 Size: 0x1
	    bool bShowRevealAnimation; // 0x65 Size: 0x1
	    char UnknownData0[0x2];

};

struct FShowdownLatestTournamentData
{
	public:
	    char UnknownData0[0x50];

};

struct FShowdownTournamentEntry
{
	public:
	    struct FString TournamentDisplayId; // 0x0 Size: 0x10
	    struct FString TitleLine1; // 0x10 Size: 0x10
	    struct FString TitleLine2; // 0x20 Size: 0x10
	    struct FString ScheduleInfo; // 0x30 Size: 0x10
	    struct FString PosterFrontImage; // 0x40 Size: 0x10
	    struct FString PosterBackImage; // 0x50 Size: 0x10
	    struct FString FlavorDescription; // 0x60 Size: 0x10
	    struct FString DetailsDescription; // 0x70 Size: 0x10
	    struct FString ShortFormatTitle; // 0x80 Size: 0x10
	    struct FString LongFormatTitle; // 0x90 Size: 0x10
	    int PinScoreRequirement; // 0xa0 Size: 0x4
	    char UnknownData0[0x4]; // 0xa4
	    struct FString PinEarnedText; // 0xa8 Size: 0x10
	    struct FString BaseColor; // 0xb8 Size: 0x10
	    struct FString PrimaryColor; // 0xc8 Size: 0x10
	    struct FString SecondaryColor; // 0xd8 Size: 0x10
	    struct FString HighlightColor; // 0xe8 Size: 0x10
	    struct FString TitleColor; // 0xf8 Size: 0x10
	    struct FString ShadowColor; // 0x108 Size: 0x10
	    struct FString BackgroundLeftColor; // 0x118 Size: 0x10
	    struct FString BackgroundRightColor; // 0x128 Size: 0x10
	    struct FString BackgroundTextColor; // 0x138 Size: 0x10
	    struct FString PosterFadeColor; // 0x148 Size: 0x10
	    struct FString PlaylistTileImage; // 0x158 Size: 0x10
	    struct FString LoadingScreenImage; // 0x168 Size: 0x10

};

struct FCreativeAdData
{
	public:
	    struct FString Header; // 0x0 Size: 0x10
	    struct FString Sub_Header; // 0x10 Size: 0x10
	    struct FString Description; // 0x20 Size: 0x10
	    struct FString Creator_Name; // 0x30 Size: 0x10
	    struct FString Island_Code; // 0x40 Size: 0x10
	    EFortCreativeAdType Ad_Type; // 0x50 Size: 0x1
	    EFortCreativeAdColorPreset Ad_Color_Preset; // 0x51 Size: 0x1
	    char UnknownData0[0x6]; // 0x52
	    struct FString Image; // 0x58 Size: 0x10

};

struct FKoreanCafeData
{
	public:
	    struct FGameplayTag Korean_Cafe; // 0x0 Size: 0x8
	    struct FText Korean_Cafe_Header; // 0x8 Size: 0x18
	    struct FText Korean_Cafe_Description; // 0x20 Size: 0x18

};

struct FShowdownTournamentData
{
	public:
	    struct FString Tournament_Display_Id; // 0x0 Size: 0x10
	    struct FText Title_Line_1; // 0x10 Size: 0x18
	    struct FText Title_Line_2; // 0x28 Size: 0x18
	    struct FText Schedule_Info; // 0x40 Size: 0x18
	    struct FString Poster_Front_Image; // 0x58 Size: 0x10
	    struct FString Poster_Back_Image; // 0x68 Size: 0x10
	    struct FText Flavor_Description; // 0x78 Size: 0x18
	    struct FText Details_Description; // 0x90 Size: 0x18
	    struct FText Short_Format_Title; // 0xa8 Size: 0x18
	    struct FText Long_Format_Title; // 0xc0 Size: 0x18
	    int Pin_Score_Requirement; // 0xd8 Size: 0x4
	    char UnknownData0[0x4]; // 0xdc
	    struct FText Pin_Earned_Text; // 0xe0 Size: 0x18
	    struct FLinearColor Base_Color; // 0xf8 Size: 0x10
	    struct FLinearColor Primary_Color; // 0x108 Size: 0x10
	    struct FLinearColor Secondary_Color; // 0x118 Size: 0x10
	    struct FLinearColor Highlight_Color; // 0x128 Size: 0x10
	    struct FLinearColor Title_Color; // 0x138 Size: 0x10
	    struct FLinearColor Shadow_Color; // 0x148 Size: 0x10
	    struct FLinearColor Background_Left_Color; // 0x158 Size: 0x10
	    struct FLinearColor Background_Right_Color; // 0x168 Size: 0x10
	    struct FLinearColor Background_Text_Color; // 0x178 Size: 0x10
	    struct FLinearColor Poster_Fade_Color; // 0x188 Size: 0x10
	    struct FString Playlist_Tile_Image; // 0x198 Size: 0x10
	    struct FString Loading_Screen_Image; // 0x1a8 Size: 0x10

};

struct FAthenaNewsData
{
	public:
	    struct FText Title; // 0x0 Size: 0x18
	    struct FText Body; // 0x18 Size: 0x18
	    struct FString Image; // 0x30 Size: 0x10
	    struct FString _type; // 0x40 Size: 0x10
	    struct FText AdSpace; // 0x50 Size: 0x18
	    bool SpotLight; // 0x68 Size: 0x1
	    bool Hidden; // 0x69 Size: 0x1
	    char UnknownData0[0x2]; // 0x6a
	    ESubGameFilter SubGameFilter; // 0x6c Size: 0x4

};

struct FAthenaNewsPlatformData
{
	public:
	    struct FString Platform; // 0x0 Size: 0x10
	    struct FAthenaNewsData MESSAGE; // 0x10 Size: 0x70
	    struct FString _type; // 0x80 Size: 0x10

};

struct FSurvivalObjectiveIconData
{
	public:
	    int IconIndex; // 0x0 Size: 0x4
	    ESurvivalObjectiveIconState IconState; // 0x4 Size: 0x1
	    ESurvivalObjectiveIconState PrevIconState; // 0x5 Size: 0x1
	    char UnknownData0[0x2]; // 0x6
	    FName SpecialActorID; // 0x8 Size: 0x8

};

struct FDiscoCaptureUIData
{
	public:
	    EDiscoCaptureUIState CurrDisplayState; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class AAthenaCapturePoint* CapturePoint; // 0x8 Size: 0x8
	    class AFortPlayerPawnAthena* CurrPawn; // 0x10 Size: 0x8
	    class UMaterialInstanceDynamic* CurrMID; // 0x18 Size: 0x8
	    float FillAmount; // 0x20 Size: 0x4
	    char UnknownData1[0x4]; // 0x24
	    struct FText DisplayText; // 0x28 Size: 0x18

};

struct FDiscoTeamScoreData
{
	public:
	    struct FText CurrScoreText; // 0x0 Size: 0x18
	    float CurrScorePercent; // 0x18 Size: 0x4
	    int CurrScore; // 0x1c Size: 0x4

};

struct FDiscoCaptureIconData
{
	public:
	    EDiscoCaptureIconState CurrIconState; // 0x0 Size: 0x1
	    EDiscoCaptureProgressState CurrProgressState; // 0x1 Size: 0x1
	    char UnknownData0[0x2]; // 0x2
	    float CurrCapturePercent; // 0x4 Size: 0x4
	    class AAthenaCapturePoint* CapturePoint; // 0x8 Size: 0x8

};

struct FFortCreativeItemListCategoryData : public FTableRowBase
{
	public:
	    ECreativeItemCategory Category; // 0x8 Size: 0x1
	    EFortItemCardSize CardSize; // 0x9 Size: 0x1
	    bool bCollapseCardBorderPad; // 0xa Size: 0x1
	    char UnknownData0[0x5];

};

struct FOptionsReleaseInfo
{
	public:
	    ESettingType SettingType; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    int ReleaseVersion; // 0x4 Size: 0x4

};

struct FFortCreativeServerDisplayOption : public FTableRowBase
{
	public:
	    class UTexture* Image; // 0x8 Size: 0x8
	    struct FLinearColor Color; // 0x10 Size: 0x10

};

struct FFortDailyRewardsItemData
{
	public:
	    class UFortItem* RewardItem; // 0x0 Size: 0x8
	    int RewardDay; // 0x8 Size: 0x4
	    bool IsCurrentReward; // 0xc Size: 0x1
	    bool IsClaimed; // 0xd Size: 0x1
	    char UnknownData0[0x2];

};

struct FExpeditionTabInfo
{
	public:
	    FName TabNameID; // 0x0 Size: 0x8
	    struct FFortTabButtonLabelInfo TabLabelInfo; // 0x8 Size: 0xa0

};

struct FFortFrontEndFeatureStruct
{
	public:
	    EFortFrontEndFeatureState CurrentState; // 0x0 Size: 0x1
	    EFortFrontEndFeatureState ForcedState; // 0x1 Size: 0x1
	    EFortFrontEndFeatureStateReason ForcedStateReason; // 0x2 Size: 0x1
	    char UnknownData0[0x5]; // 0x3
	    MulticastDelegateProperty ChangeDelegate; // 0x8 Size: 0x10

};

struct FUnlockableVariantPreviewInfo
{
	public:
	    bool bIsValid; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    int SetNumber; // 0x4 Size: 0x4
	    int SetCount; // 0x8 Size: 0x4
	    char UnknownData1[0x4]; // 0xc
	    struct FText UnlockCondition; // 0x10 Size: 0x18

};

struct FFortMissionRewardInfo
{
	public:
	    struct FSlateBrush Icon; // 0x0 Size: 0x88
	    struct FText DisplayName; // 0x88 Size: 0x18
	    class UFortItem* Item; // 0xa0 Size: 0x8
	    bool bIsMissionAlertReward; // 0xa8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FAttributeRequirement
{
	public:
	    struct FText Name; // 0x0 Size: 0x18
	    int Level; // 0x18 Size: 0x4
	    bool bRequirementsMet; // 0x1c Size: 0x1
	    char UnknownData0[0x3];

};

struct FGiftingErrorText
{
	public:
	    EOfferPurchaseError GiftingError; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FText ErrorTitle; // 0x8 Size: 0x18
	    struct FText ErrorDesc; // 0x20 Size: 0x18

};

struct FFortHeroLoadoutHeroPickerTabConfiguration
{
	public:
	    struct FFortItemFilterDefinition Filter; // 0x0 Size: 0x50
	    struct FFortItemSorterDefinition Sorter; // 0x50 Size: 0x40

};

struct FHeroStat
{
	public:
	    struct FText DisplayName; // 0x0 Size: 0x18
	    float Value; // 0x18 Size: 0x4
	    bool bIsCategory; // 0x1c Size: 0x1
	    char UnknownData0[0x3];

};

struct FEmptyHeroSlot
{
	public:
	    class UFortHeroType* Type; // 0x0 Size: 0x8
	    int NumAvailable; // 0x8 Size: 0x4
	    bool bHasMale; // 0xc Size: 0x1
	    bool bHasFemale; // 0xd Size: 0x1
	    char UnknownData0[0x2];

};

struct FHeroUIData
{
	public:
	    class UFortHero* Hero; // 0x0 Size: 0x8
	    bool bIsSelected; // 0x8 Size: 0x1
	    char UnknownData0[0x3]; // 0x9
	    int XPRequirementForCurrentLevel; // 0xc Size: 0x4
	    int XPRequirementForNextLevel; // 0x10 Size: 0x4
	    int RequiredXPToLevelUp; // 0x14 Size: 0x4
	    bool bIsMaxHeroLevel; // 0x18 Size: 0x1
	    char UnknownData1[0x7];

};

struct FFortHeroNamesData : public FTableRowBase
{
	public:
	    struct FString FirstName; // 0x8 Size: 0x10
	    struct FString NickName; // 0x18 Size: 0x10
	    struct FString LastName; // 0x28 Size: 0x10

};

struct FFortItemDelta
{
	public:
	    class UFortItemDefinition* ItemDefinition; // 0x0 Size: 0x8
	    int BaseAmount; // 0x8 Size: 0x4
	    int DeltaAmount; // 0xc Size: 0x4

};

struct FFortBasicMissionInfo
{
	public:
	    struct FText MissionName; // 0x0 Size: 0x18
	    struct FFortMultiSizeBrush MissionIcons; // 0x18 Size: 0x330
	    struct FText TheaterName; // 0x348 Size: 0x18
	    struct FText DifficultyName; // 0x360 Size: 0x18
	    class UMediaSource* EndOfMissionMediaSource; // 0x378 Size: 0x8
	    bool bSkipEndOfMissionVideo; // 0x380 Size: 0x1
	    bool bIsGroupContent; // 0x381 Size: 0x1
	    char UnknownData0[0x6];

};

struct FFortKillerVisualInfo
{
	public:
	    struct FSlateBrush KillerBrush; // 0x0 Size: 0x88
	    struct FText KillerName; // 0x88 Size: 0x18

};

struct FFortActionBeingUnbound
{
	public:
	    FName ActionName; // 0x0 Size: 0x8
	    int InputIndex; // 0x8 Size: 0x4

};

struct FItemDefinitionChangedStruct
{
	public:
	    MulticastDelegateProperty ChangeDelegate; // 0x0 Size: 0x10

};

struct FFortItemCard_StackCountBlock_Configuration
{
	public:
	    bool bShowShorthandStackCount; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    __int64/*SoftClassProperty*/ TextStyle; // 0x8 Size: 0x28

};

struct FFortItemCard_XXS_ItemInstance_Configuration
{
	public:
	    struct FFortItemCard_StackCountBlock_Configuration StackCountBlock; // 0x0 Size: 0x30

};

struct FFortItemCard_XS_TransformKey_Configuration
{
	public:
	    struct FMargin BackgroundPadding; // 0x0 Size: 0x10
	    struct FFortItemCard_StackCountBlock_Configuration StackCountBlock; // 0x10 Size: 0x30
	    struct FVector2D TransformKeyIconSize; // 0x40 Size: 0x8

};

struct FFortItemCard_DurabilityMeter_Configuration
{
	public:
	    float MeterThickness; // 0x0 Size: 0x4
	    struct FMargin MeterPadding; // 0x4 Size: 0x10

};

struct FFortItemCard_PowerRatingBlock_Configuration
{
	public:
	    struct FMargin CustomRatingInternalPadding; // 0x8 Size: 0x10
	    struct FVector2D CustomRatingIconSize; // 0x18 Size: 0x8
	    __int64/*SoftClassProperty*/ CustomRatingTextStyle; // 0x20 Size: 0x28
	    struct FVector2D ComparisonIndicatorSize; // 0x48 Size: 0x8

};

struct FFortItemCard_PowerRatingBlock_ItemInstance_Configuration : public FFortItemCard_PowerRatingBlock_Configuration
{
	public:
	    struct FSlateBrush PowerRatingIconBrush; // 0x50 Size: 0x88
	    __int64/*SoftClassProperty*/ PowerRatingTextStyle; // 0xd8 Size: 0x28

};

struct FFortItemCard_XS_ItemInstance_Configuration
{
	public:
	    struct FMargin BackgroundPadding; // 0x0 Size: 0x10
	    struct FMargin PowerRatingBlockPadding; // 0x10 Size: 0x10
	    struct FFortItemCard_PowerRatingBlock_ItemInstance_Configuration PowerRatingBlock; // 0x20 Size: 0x100
	    struct FVector2D BookmarkImageSize; // 0x120 Size: 0x8
	    struct FMargin TraitBoxPadding; // 0x128 Size: 0x10
	    struct FVector2D FirstTraitSize; // 0x138 Size: 0x8
	    struct FFortItemCard_StackCountBlock_Configuration StackCountBlock; // 0x140 Size: 0x30
	    struct FFortItemCard_DurabilityMeter_Configuration DurabilityMeter; // 0x170 Size: 0x14
	    char UnknownData0[0x4];

};

struct FFortItemCard_DetailAreaBorder_Configuration
{
	public:
	    float MinimumHeight; // 0x0 Size: 0x4
	    struct FMargin Padding; // 0x4 Size: 0x10

};

struct FFortItemCard_XS_PersonnelAndSchematics_Configuration
{
	public:
	    struct FMargin BackgroundPadding; // 0x0 Size: 0x10
	    struct FVector2D BookmarkImageSize; // 0x10 Size: 0x8
	    struct FFortItemCard_DetailAreaBorder_Configuration DetailAreaBorder; // 0x18 Size: 0x14
	    struct FVector2D AvailableUpgradeIconSize; // 0x2c Size: 0x8

};

struct FFortItemCard_S_TransformKey_Configuration
{
	public:
	    struct FMargin BackgroundPadding; // 0x0 Size: 0x10
	    struct FFortItemCard_StackCountBlock_Configuration StackCountBlock; // 0x10 Size: 0x30
	    struct FVector2D TransformKeyIconSize; // 0x40 Size: 0x8

};

struct FFortItemCard_TierMeter_Configuration
{
	public:
	    struct FVector2D PipSize; // 0x0 Size: 0x8
	    float InterPipPadding; // 0x8 Size: 0x4

};

struct FFortItemCard_S_ItemInstance_Configuration
{
	public:
	    struct FMargin BackgroundPadding; // 0x0 Size: 0x10
	    struct FMargin PowerRatingBlockPadding; // 0x10 Size: 0x10
	    struct FFortItemCard_PowerRatingBlock_ItemInstance_Configuration PowerRatingBlock; // 0x20 Size: 0x100
	    struct FVector2D BookmarkImageSize; // 0x120 Size: 0x8
	    struct FFortItemCard_StackCountBlock_Configuration StackCountBlock; // 0x128 Size: 0x30
	    struct FMargin TraitBoxPadding; // 0x158 Size: 0x10
	    struct FVector2D FirstTraitSize; // 0x168 Size: 0x8
	    struct FMargin TierMeterPadding; // 0x170 Size: 0x10
	    struct FFortItemCard_TierMeter_Configuration TierMeter; // 0x180 Size: 0xc
	    struct FFortItemCard_DurabilityMeter_Configuration DurabilityMeter; // 0x18c Size: 0x14

};

struct FFortItemCard_LevelMeter_Configuration
{
	public:
	    float MeterThickness; // 0x0 Size: 0x4
	    struct FMargin MeterPadding; // 0x4 Size: 0x10

};

struct FFortItemCard_DefenderWeaponTypeIcon_Configuration
{
	public:
	    struct FVector2D IconConstraints; // 0x0 Size: 0x8

};

struct FFortItemCard_NameplateBorder_Configuration
{
	public:
	    struct FMargin Padding; // 0x0 Size: 0x10
	    struct FSlateBrush Brush; // 0x10 Size: 0x88

};

struct FFortItemCard_PowerRatingBlock_PersonnelAndSchematics_Configuration : public FFortItemCard_PowerRatingBlock_Configuration
{
	public:
	    struct FSlateBrush PersonnelPowerRatingIconBrush; // 0x50 Size: 0x88
	    __int64/*SoftClassProperty*/ PersonnelPowerRatingTextStyle; // 0xd8 Size: 0x28
	    struct FSlateBrush SchematicPowerRatingIconBrush; // 0x100 Size: 0x88
	    __int64/*SoftClassProperty*/ SchematicPowerRatingTextStyle; // 0x188 Size: 0x28

};

struct FFortItemCard_S_PersonnelAndSchematics_Configuration
{
	public:
	    struct FMargin BackgroundPadding; // 0x0 Size: 0x10
	    struct FFortItemCard_PowerRatingBlock_PersonnelAndSchematics_Configuration PowerRatingBlock; // 0x10 Size: 0x1b0
	    struct FVector2D BookmarkImageSize; // 0x1c0 Size: 0x8
	    struct FFortItemCard_NameplateBorder_Configuration Nameplate; // 0x1c8 Size: 0x98
	    struct FVector2D ClassIconSize; // 0x260 Size: 0x8
	    struct FVector2D LeadSurvivorTypeIconSize; // 0x268 Size: 0x8
	    struct FVector2D FirstIconSlotSize; // 0x270 Size: 0x8
	    float PaddingBetweenIconSlots; // 0x278 Size: 0x4
	    struct FVector2D SecondIconSlotSize; // 0x27c Size: 0x8
	    struct FFortItemCard_DefenderWeaponTypeIcon_Configuration DefenderWeaponTypeIcon; // 0x284 Size: 0x8
	    struct FFortItemCard_DetailAreaBorder_Configuration DetailAreaBorder; // 0x28c Size: 0x14
	    struct FFortItemCard_LevelMeter_Configuration LevelMeter; // 0x2a0 Size: 0x14
	    float TierMeterLeftPadding; // 0x2b4 Size: 0x4
	    struct FFortItemCard_TierMeter_Configuration TierMeter; // 0x2b8 Size: 0xc
	    char UnknownData0[0x4];

};

struct FFortItemCard_M_TransformKey_Configuration
{
	public:
	    struct FMargin BackgroundPadding; // 0x0 Size: 0x10
	    struct FFortItemCard_StackCountBlock_Configuration StackCountBlock; // 0x10 Size: 0x30
	    struct FVector2D TransformKeyIconSize; // 0x40 Size: 0x8

};

struct FFortItemCard_M_ItemInstance_Configuration
{
	public:
	    struct FMargin BackgroundPadding; // 0x0 Size: 0x10
	    struct FMargin PowerRatingBlockPadding; // 0x10 Size: 0x10
	    struct FFortItemCard_PowerRatingBlock_ItemInstance_Configuration PowerRatingBlock; // 0x20 Size: 0x100
	    struct FVector2D BookmarkImageSize; // 0x120 Size: 0x8
	    struct FFortItemCard_StackCountBlock_Configuration StackCountBlock; // 0x128 Size: 0x30
	    struct FMargin TraitBoxPadding; // 0x158 Size: 0x10
	    struct FVector2D FirstTraitSize; // 0x168 Size: 0x8
	    float PaddingBetweenTraitIcons; // 0x170 Size: 0x4
	    struct FVector2D SecondTraitSize; // 0x174 Size: 0x8
	    struct FMargin TierMeterPadding; // 0x17c Size: 0x10
	    struct FFortItemCard_TierMeter_Configuration TierMeter; // 0x18c Size: 0xc
	    struct FFortItemCard_DurabilityMeter_Configuration DurabilityMeter; // 0x198 Size: 0x14
	    char UnknownData0[0x4];

};

struct FFortItemCard_M_PersonnelAndSchematics_Configuration
{
	public:
	    struct FMargin BackgroundPadding; // 0x0 Size: 0x10
	    struct FFortItemCard_PowerRatingBlock_PersonnelAndSchematics_Configuration PowerRatingBlock; // 0x10 Size: 0x1b0
	    struct FVector2D BookmarkImageSize; // 0x1c0 Size: 0x8
	    struct FFortItemCard_NameplateBorder_Configuration Nameplate; // 0x1c8 Size: 0x98
	    struct FVector2D ClassIconSize; // 0x260 Size: 0x8
	    struct FVector2D LeadSurvivorTypeIconSize; // 0x268 Size: 0x8
	    struct FVector2D FirstIconSlotSize; // 0x270 Size: 0x8
	    float PaddingBetweenIconSlots; // 0x278 Size: 0x4
	    struct FVector2D SecondIconSlotSize; // 0x27c Size: 0x8
	    struct FFortItemCard_DefenderWeaponTypeIcon_Configuration DefenderWeaponTypeIcon; // 0x284 Size: 0x8
	    struct FFortItemCard_DetailAreaBorder_Configuration DetailAreaBorder; // 0x28c Size: 0x14
	    struct FFortItemCard_LevelMeter_Configuration LevelMeter; // 0x2a0 Size: 0x14
	    float TierMeterLeftPadding; // 0x2b4 Size: 0x4
	    struct FFortItemCard_TierMeter_Configuration TierMeter; // 0x2b8 Size: 0xc
	    char UnknownData0[0x4];

};

struct FFortItemCard_L_TransformKey_Configuration
{
	public:
	    struct FMargin BackgroundPadding; // 0x0 Size: 0x10
	    struct FFortItemCard_StackCountBlock_Configuration StackCountBlock; // 0x10 Size: 0x30
	    struct FVector2D TransformKeyIconSize; // 0x40 Size: 0x8

};

struct FFortItemCard_L_ItemInstance_Configuration
{
	public:
	    struct FMargin BackgroundPadding; // 0x0 Size: 0x10
	    struct FMargin PowerRatingBlockPadding; // 0x10 Size: 0x10
	    struct FFortItemCard_PowerRatingBlock_ItemInstance_Configuration PowerRatingBlock; // 0x20 Size: 0x100
	    struct FVector2D BookmarkImageSize; // 0x120 Size: 0x8
	    struct FFortItemCard_StackCountBlock_Configuration StackCountBlock; // 0x128 Size: 0x30
	    struct FMargin TraitBoxPadding; // 0x158 Size: 0x10
	    struct FVector2D FirstTraitSize; // 0x168 Size: 0x8
	    float PaddingBetweenTraitIcons; // 0x170 Size: 0x4
	    struct FVector2D SecondTraitSize; // 0x174 Size: 0x8
	    struct FMargin TierMeterPadding; // 0x17c Size: 0x10
	    struct FFortItemCard_TierMeter_Configuration TierMeter; // 0x18c Size: 0xc
	    struct FFortItemCard_DurabilityMeter_Configuration DurabilityMeter; // 0x198 Size: 0x14
	    char UnknownData0[0x4];

};

struct FFortItemCard_L_PersonnelAndSchematics_Configuration
{
	public:
	    struct FMargin BackgroundPadding; // 0x0 Size: 0x10
	    struct FFortItemCard_PowerRatingBlock_PersonnelAndSchematics_Configuration PowerRatingBlock; // 0x10 Size: 0x1b0
	    struct FVector2D BookmarkImageSize; // 0x1c0 Size: 0x8
	    struct FFortItemCard_NameplateBorder_Configuration Nameplate; // 0x1c8 Size: 0x98
	    struct FVector2D ClassIconSize; // 0x260 Size: 0x8
	    struct FVector2D LeadSurvivorTypeIconSize; // 0x268 Size: 0x8
	    struct FVector2D FirstIconSlotSize; // 0x270 Size: 0x8
	    float PaddingBetweenIconSlots; // 0x278 Size: 0x4
	    struct FVector2D SecondIconSlotSize; // 0x27c Size: 0x8
	    struct FFortItemCard_DefenderWeaponTypeIcon_Configuration DefenderWeaponTypeIcon; // 0x284 Size: 0x8
	    struct FFortItemCard_DetailAreaBorder_Configuration DetailAreaBorder; // 0x28c Size: 0x14
	    struct FFortItemCard_LevelMeter_Configuration LevelMeter; // 0x2a0 Size: 0x14
	    float TierMeterLeftPadding; // 0x2b4 Size: 0x4
	    struct FFortItemCard_TierMeter_Configuration TierMeter; // 0x2b8 Size: 0xc
	    char UnknownData0[0x4];

};

struct FFortItemCard_XL_TransformKey_Configuration
{
	public:
	    struct FMargin BackgroundPadding; // 0x0 Size: 0x10
	    struct FFortItemCard_StackCountBlock_Configuration StackCountBlock; // 0x10 Size: 0x30
	    struct FVector2D TransformKeyIconSize; // 0x40 Size: 0x8

};

struct FFortItemCard_XL_ItemInstance_Configuration
{
	public:
	    struct FMargin BackgroundPadding; // 0x0 Size: 0x10
	    struct FMargin PowerRatingBlockPadding; // 0x10 Size: 0x10
	    struct FFortItemCard_PowerRatingBlock_ItemInstance_Configuration PowerRatingBlock; // 0x20 Size: 0x100
	    struct FVector2D BookmarkImageSize; // 0x120 Size: 0x8
	    struct FFortItemCard_StackCountBlock_Configuration StackCountBlock; // 0x128 Size: 0x30
	    struct FMargin TraitBoxPadding; // 0x158 Size: 0x10
	    struct FVector2D FirstTraitSize; // 0x168 Size: 0x8
	    float PaddingBetweenTraitIcons; // 0x170 Size: 0x4
	    struct FVector2D SecondTraitSize; // 0x174 Size: 0x8
	    struct FMargin TierMeterPadding; // 0x17c Size: 0x10
	    struct FFortItemCard_TierMeter_Configuration TierMeter; // 0x18c Size: 0xc
	    struct FFortItemCard_DurabilityMeter_Configuration DurabilityMeter; // 0x198 Size: 0x14
	    char UnknownData0[0x4];

};

struct FFortItemCard_XL_PersonnelAndSchematics_Configuration
{
	public:
	    struct FMargin BackgroundPadding; // 0x0 Size: 0x10
	    struct FFortItemCard_PowerRatingBlock_PersonnelAndSchematics_Configuration PowerRatingBlock; // 0x10 Size: 0x1b0
	    struct FVector2D BookmarkImageSize; // 0x1c0 Size: 0x8
	    struct FFortItemCard_NameplateBorder_Configuration Nameplate; // 0x1c8 Size: 0x98
	    __int64/*SoftClassProperty*/ ItemNameTextStyle; // 0x260 Size: 0x28
	    struct FVector2D LeadSurvivorTypeIconSize; // 0x288 Size: 0x8
	    struct FVector2D FirstIconSlotSize; // 0x290 Size: 0x8
	    float PaddingBetweenIconSlots; // 0x298 Size: 0x4
	    struct FVector2D SecondIconSlotSize; // 0x29c Size: 0x8
	    struct FFortItemCard_DefenderWeaponTypeIcon_Configuration DefenderWeaponTypeIcon; // 0x2a4 Size: 0x8
	    struct FFortItemCard_DetailAreaBorder_Configuration DetailAreaBorder; // 0x2ac Size: 0x14
	    float RarityNameTextLeftPadding; // 0x2c0 Size: 0x4
	    char UnknownData0[0x4]; // 0x2c4
	    __int64/*SoftClassProperty*/ RarityNameTextStyle; // 0x2c8 Size: 0x28
	    float ClassIconImageLeftPadding; // 0x2f0 Size: 0x4
	    struct FVector2D ClassIconSize; // 0x2f4 Size: 0x8
	    float PaddingBetweenClassIconAndName; // 0x2fc Size: 0x4
	    __int64/*SoftClassProperty*/ ClassNameTextStyle; // 0x300 Size: 0x28
	    float TierMeterLeftPadding; // 0x328 Size: 0x4
	    struct FFortItemCard_TierMeter_Configuration TierMeter; // 0x32c Size: 0xc
	    struct FMargin IconSlotOverNameplatePadding; // 0x338 Size: 0x10
	    struct FVector2D IconSlotOverNameplateSize; // 0x348 Size: 0x8

};

struct FFortRefundDescriptionsData : public FTableRowBase
{
	public:
	    struct FString SearchString; // 0x8 Size: 0x10
	    struct FString TargetReleaseVersion; // 0x18 Size: 0x10
	    struct FText RefundDescriptionText; // 0x28 Size: 0x18

};

struct FFortItemManagementInventoryFilterTabLabelInfo : public FFortTabButtonLabelInfo
{
	public:
	    FName FilterTabNameId; // 0xa0 Size: 0x8

};

struct FFortItemEntryPreviewData
{
	public:
	    int Quantity; // 0x0 Size: 0x4
	    EFortItemInspectionMode InspectMode; // 0x4 Size: 0x1
	    char UnknownData0[0x3];

};

struct FMeasuredText
{
	public:
	    char UnknownData0[0x28];

};

struct FOfferGroup
{
	public:
	    struct FString Name; // 0x0 Size: 0x10
	    int MaxNumberToShow; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortMaterialProgressBarSectionStyle
{
	public:
	    bool bGradientBar; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    FName BarParamName; // 0x4 Size: 0x8
	    FName BarColorOneParamName; // 0xc Size: 0x8
	    FName BarColorTwoParamName; // 0x14 Size: 0x8
	    struct FLinearColor BarColorOne; // 0x1c Size: 0x10
	    struct FLinearColor BarColorTwo; // 0x2c Size: 0x10

};

struct FFortMaterialProgressBarSectionInfo
{
	public:
	    struct FFortMaterialProgressBarSectionStyle SectionStyle; // 0x0 Size: 0x3c
	    float Percent; // 0x3c Size: 0x4

};

struct FFortModalContainerSizeEntry
{
	public:
	    float AbsoluteWidth; // 0x0 Size: 0x4
	    float TopPercent; // 0x4 Size: 0x4
	    float MiddlePercent; // 0x8 Size: 0x4
	    float BottomPercent; // 0xc Size: 0x4
	    float VerticalPadding; // 0x10 Size: 0x4
	    float HorizontalPadding; // 0x14 Size: 0x4
	    float ContentPadding; // 0x18 Size: 0x4

};

struct FFortMtxGradient
{
	public:
	    struct FLinearColor Start; // 0x0 Size: 0x10
	    struct FLinearColor Stop; // 0x10 Size: 0x10

};

struct FFortMtxDetailsAttribute
{
	public:
	    struct FText Name; // 0x0 Size: 0x18
	    struct FText Value; // 0x18 Size: 0x18

};

struct FSliderSettings
{
	public:
	    int MinIntegralDigits; // 0x0 Size: 0x4
	    int MaxIntegralDigits; // 0x4 Size: 0x4
	    int MinFractionalDigits; // 0x8 Size: 0x4
	    int MaxFractionalDigits; // 0xc Size: 0x4
	    float MinSensitivityValue; // 0x10 Size: 0x4
	    float MaxSensitivityValue; // 0x14 Size: 0x4
	    float StepSize; // 0x18 Size: 0x4
	    char RoundingMode; // 0x1c Size: 0x1
	    char UnknownData0[0x3];

};

struct FPlatformOverrides
{
	public:
	    bool DisplayOnPlatform; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FText PlatformDisplayText; // 0x8 Size: 0x18
	    struct FText PlatformHoverText; // 0x20 Size: 0x18

};

struct FFortUIPerkTier
{
	public:
	    class UFortHeroSpecialization* HeroSpecialization; // 0x0 Size: 0x8
	    char Tier; // 0x8 Size: 0x1
	    char UnknownData0[0x7]; // 0x9
	    class UFortHero* CurrentHero; // 0x10 Size: 0x8
	    bool bIsUpgrade; // 0x18 Size: 0x1
	    bool bIsEvolution; // 0x19 Size: 0x1
	    char UnknownData1[0x6];

};

struct FRadialOptionData
{
	public:
	    struct FText Label; // 0x0 Size: 0x18
	    struct FSlateBrush Brush; // 0x18 Size: 0x88
	    struct TSoftObjectPtr<struct UTexture2D*> SoftIcon; // 0xa0 Size: 0x28

};

struct FSquadQuickChatOptionData : public FRadialOptionData
{
	public:
	    struct FAthenaQuickChatActiveEntry ChatEntry; // 0xc8 Size: 0x14
	    bool bEnabled; // 0xdc Size: 0x1
	    char UnknownData0[0x3];

};

struct FItemDefOptionData : public FRadialOptionData
{
	public:
	    class UObject* ItemDef; // 0xc8 Size: 0x8

};

struct FEmoteOptionData : public FRadialOptionData
{
	public:
	    FName EmoteCommand; // 0xc8 Size: 0x8

};

struct FMapNoteOptionData : public FRadialOptionData
{
	public:
	    struct FText MapNoteText; // 0xc8 Size: 0x18

};

struct FSquadChatOptionData : public FRadialOptionData
{
	public:
	    struct FText ChatText; // 0xc8 Size: 0x18

};

struct FChatOptionData : public FRadialOptionData
{
	public:
	    struct FText ChatText; // 0xc8 Size: 0x18

};

struct FItemCategoryOptionData : public FRadialOptionData
{
	public:
	    struct FString TemplatePrefix; // 0xc8 Size: 0x10
	    char BuildingAttachmentType; // 0xd8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FBuildingOptionData : public FRadialOptionData
{
	public:
	    struct FString ClassSuffix; // 0xc8 Size: 0x10
	    bool ClassMirrored; // 0xd8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FBuildingCategoryOptionData : public FRadialOptionData
{
	public:
	    char BuildingType; // 0xc8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FPlatformSupportDesc
{
	public:
	    struct FText DisableDesc; // 0x0 Size: 0x18
	    EFortLoginAccountType AccountType; // 0x18 Size: 0x1
	    char UnknownData0[0x7];

};

struct FFortRichTextStyleData : public FTableRowBase
{
	public:
	    struct FTextBlockStyle TextStyle; // 0x8 Size: 0x1e0
	    bool bHyperlinkStyle; // 0x1e8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FFortTournamentDisplayInfo : public FTableRowBase
{
	public:
	    struct FText TitleLine1; // 0x8 Size: 0x18
	    struct FText TitleLine2; // 0x20 Size: 0x18
	    struct FText ScheduleInfo; // 0x38 Size: 0x18
	    struct FText FlavorDescription; // 0x50 Size: 0x18
	    struct FText DetailsDescription; // 0x68 Size: 0x18
	    struct FText ShortFormatTitle; // 0x80 Size: 0x18
	    struct FText LongFormatTitle; // 0x98 Size: 0x18
	    int PinScoreRequirement; // 0xb0 Size: 0x4
	    char UnknownData0[0x4]; // 0xb4
	    struct FText PinEarnedText; // 0xb8 Size: 0x18
	    struct FLinearColor BaseColor; // 0xd0 Size: 0x10
	    struct FLinearColor PrimaryColor; // 0xe0 Size: 0x10
	    struct FLinearColor SecondaryColor; // 0xf0 Size: 0x10
	    struct FLinearColor HighlightColor; // 0x100 Size: 0x10
	    struct FLinearColor TitleColor; // 0x110 Size: 0x10
	    struct FLinearColor ShadowColor; // 0x120 Size: 0x10
	    struct FLinearColor BackgroundLeftColor; // 0x130 Size: 0x10
	    struct FLinearColor BackgroundRightColor; // 0x140 Size: 0x10
	    struct FLinearColor BackgroundTextColor; // 0x150 Size: 0x10
	    struct FLinearColor PosterFadeColor; // 0x160 Size: 0x10

};

struct FFortShowdownScoringRuleDisplayInfo : public FTableRowBase
{
	public:
	    struct FText Description; // 0x8 Size: 0x18
	    struct TSoftObjectPtr<struct UTexture2D*> Icon; // 0x20 Size: 0x28

};

struct FFortShowdownScoringRuleInfo : public FTableRowBase
{
	public:
	    FName DisplayInfoId; // 0x8 Size: 0x8
	    int PointValue; // 0x10 Size: 0x4
	    int ScoreRequirement; // 0x14 Size: 0x4

};

struct FFortShowdownEventBestResultsSummary
{
	public:
	    int TotalScore; // 0x0 Size: 0x4
	    int MatchesPlayed; // 0x4 Size: 0x4
	    int NumVictoryRoyales; // 0x8 Size: 0x4
	    int PlacementPoints; // 0xc Size: 0x4
	    int EliminationPoints; // 0x10 Size: 0x4

};

struct FPlatformPrefixIcon
{
	public:
	    struct FString Platform; // 0x0 Size: 0x10
	    class UTexture2D* PrefixIcon; // 0x10 Size: 0x8

};

struct FPotentialSpectatorTarget
{
	public:
	    int Rank; // 0x0 Size: 0x4
	    TWeakObjectPtr<AFortPlayerStateAthena*> PlayerState; // 0x4 Size: 0x8
	    bool bCurrentViewTarget; // 0xc Size: 0x1
	    char UnknownData0[0x3];

};

struct FFortLandingPageDefenderSummaryInfo
{
	public:
	    FName SquadId; // 0x0 Size: 0x8
	    struct FText TheaterDisplayName; // 0x8 Size: 0x18
	    struct FString TheaterUniqueId; // 0x20 Size: 0x10

};

struct FFortAttributeModifierAccumulation
{
	public:
	    struct FGameplayTag GameplayTag; // 0x0 Size: 0x8
	    struct FGameplayAttribute Attribute; // 0x8 Size: 0x20
	    char ModifierOp; // 0x28 Size: 0x1
	    char UnknownData0[0x3]; // 0x29
	    float Magnitude; // 0x2c Size: 0x4

};

struct FOpenedCardPack
{
	public:
	    class UFortCardPackItemDefinition* CardPackDefinition; // 0x0 Size: 0x8
	    int DisplayLevel; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FCard
{
	public:
	    int QuantityReceived; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    class UFortItem* Item; // 0x8 Size: 0x8
	    EPauseType PauseType; // 0x10 Size: 0x1
	    char UnknownData1[0x7];

};

struct FFortToastDisplayInfo
{
	public:
	    struct FText Header; // 0x0 Size: 0x18
	    struct FText Body; // 0x18 Size: 0x18
	    struct TSoftObjectPtr<struct UTexture2D*> Image; // 0x30 Size: 0x28
	    EFortToastType Type; // 0x58 Size: 0x1
	    char UnknownData0[0x7];

};

struct FStoreCallout
{
	public:
	    struct FFortToastDisplayInfo ToastDisplayInfo; // 0x0 Size: 0x60
	    struct FText ItemName; // 0x60 Size: 0x18

};

struct FBundledItemInfo
{
	public:
	    struct FString TemplateId; // 0x0 Size: 0x10
	    int Quantity; // 0x10 Size: 0x4
	    bool bOwned; // 0x14 Size: 0x1
	    char UnknownData0[0x3];

};

struct FFortSurvivorSquadSlottingFeedbackData
{
	public:
	    bool HadLeaderMatch; // 0x0 Size: 0x1
	    bool HasLeaderMatch; // 0x1 Size: 0x1
	    char UnknownData0[0x6]; // 0x2
	    __int64/*MapProperty*/ PreviousSetBonusCounts; // 0x8 Size: 0x50
	    __int64/*MapProperty*/ CurrentSetBonusCounts; // 0x58 Size: 0x50
	    int PreviousPersonalityMatchCount; // 0xa8 Size: 0x4
	    int CurrentPersonalityMatchCount; // 0xac Size: 0x4

};

struct FFortSurvivorSquadSelectorButtonPersonalityMatches
{
	public:
	    int NumPersonalityMatches; // 0x0 Size: 0x4
	    int TotalNonLeaderSquadMembers; // 0x4 Size: 0x4
	    bool HavePersonalityIcons; // 0x8 Size: 0x1
	    char UnknownData0[0x7]; // 0x9
	    struct FFortMultiSizeBrush PersonalityIcons; // 0x10 Size: 0x330

};

struct FFortSurvivorSquadSelectorButtonSummaryStats
{
	public:
	    FName SquadId; // 0x0 Size: 0x8
	    struct FGameplayAttribute FortAttribute; // 0x8 Size: 0x20
	    float FortAttributeValue; // 0x28 Size: 0x4
	    char UnknownData0[0x4]; // 0x2c
	    struct FGameplayAttribute FortTeamAttribute; // 0x30 Size: 0x20
	    float TeamFortAttributeValue; // 0x50 Size: 0x4
	    float SquadPowerValue; // 0x54 Size: 0x4
	    struct FText FortAttributeName; // 0x58 Size: 0x18

};

struct FFortUISurvivorSquadStatMatch
{
	public:
	    struct FFortMultiSizeBrush Icons; // 0x0 Size: 0x330
	    struct FText MagnitudeText; // 0x330 Size: 0x18
	    struct FText AttributeDisplayName; // 0x348 Size: 0x18
	    int NumMembersMeetingCriteria; // 0x360 Size: 0x4
	    int NumMembersRequired; // 0x364 Size: 0x4
	    EFortUISurvivorSquadMatchType MatchType; // 0x368 Size: 0x1
	    EFortBuffState PreviewEffect; // 0x369 Size: 0x1
	    char UnknownData0[0x6];

};

struct FFortSwipeDetector
{
	public:
	    struct FVector2D SwipeThreshold; // 0x0 Size: 0x8
	    char UnknownData0[0x68];

};

struct FTouchMove
{
	public:
	    char UnknownData0[0xc];

};

struct FFortUINavigationOperation
{
	public:
	    EFortUINavigationOp Operation; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    FName SquadId; // 0x4 Size: 0x8
	    int SquadSlotIndex; // 0xc Size: 0x4
	    FName PageId; // 0x10 Size: 0x8
	    FName NodeId; // 0x18 Size: 0x8
	    class UFortItem* Item; // 0x20 Size: 0x8
	    EFortUIFeature Feature; // 0x28 Size: 0x1
	    EFortFrontendInventoryFilter ItemManagementFilter; // 0x29 Size: 0x1
	    char UnknownData1[0x6];

};

struct FUINavigationEntry
{
	public:
	    struct FUINavigationData Data; // 0x0 Size: 0x30
	    __int64/*DelegateProperty*/ NavigateToDelegate; // 0x30 Size: 0x10
	    __int64/*DelegateProperty*/ NavigateFromDelegate; // 0x40 Size: 0x10

};

struct FFortUIPickerTrapSortScores
{
	public:
	    float UniqueTrapBonus; // 0x0 Size: 0x4
	    float SlottedBonus; // 0x4 Size: 0x4
	    float FavoriteBonus; // 0x8 Size: 0x4
	    float PinnedBonus; // 0xc Size: 0x4
	    float MaxTrackedTrapBonusTime; // 0x10 Size: 0x4
	    float TrackedTrapBonusMultiplier; // 0x14 Size: 0x4

};

struct FFortUIXpInfo
{
	public:
	    int InitialLevel; // 0x0 Size: 0x4
	    int InitialDisplayXp; // 0x4 Size: 0x4
	    struct FFortExperienceDelta ChangeInXp; // 0x8 Size: 0x24

};

struct FContentPushState
{
	public:
	    bool bHideHeader; // 0x0 Size: 0x1
	    bool bHideFooter; // 0x1 Size: 0x1
	    bool bHideChatWidget; // 0x2 Size: 0x1

};

struct FFortUIStyleWindowButtons
{
	public:
	    struct FButtonStyle Close; // 0x0 Size: 0x278
	    struct FButtonStyle Minimize; // 0x278 Size: 0x278
	    struct FButtonStyle Maximize; // 0x4f0 Size: 0x278
	    struct FButtonStyle Restore; // 0x768 Size: 0x278

};

struct FFortUIStyleDefinition
{
	public:
	    struct FFortUIStyleWindowButtons WindowButtons; // 0x0 Size: 0x9e0

};

struct FFortSquadIconData : public FTableRowBase
{
	public:
	    struct FFortMultiSizeBrush Brush; // 0x8 Size: 0x330

};

struct FFortDisplayAttribute
{
	public:
	    struct FGameplayAttribute Attribute; // 0x0 Size: 0x20
	    struct FText Label; // 0x20 Size: 0x18
	    struct FText Value; // 0x38 Size: 0x18
	    struct FText HoverText; // 0x50 Size: 0x18
	    float NumericValue; // 0x68 Size: 0x4
	    EFortStatValueDisplayType DisplayType; // 0x6c Size: 0x1
	    EFortBuffState BuffState; // 0x6d Size: 0x1
	    EFortClampState ClampState; // 0x6e Size: 0x1
	    EFortComparisonType ComparisonType; // 0x6f Size: 0x1

};

struct FFortDisplayModifier
{
	public:
	    struct FText Label; // 0x0 Size: 0x18
	    struct FText Value; // 0x18 Size: 0x18
	    EFortStatValueDisplayType DisplayType; // 0x30 Size: 0x1
	    EFortBuffState BuffState; // 0x31 Size: 0x1
	    char UnknownData0[0x6];

};

struct FHomebaseNodeDisplayData : public FTableRowBase
{
	public:
	    struct FText Title; // 0x8 Size: 0x18
	    struct FText Description; // 0x20 Size: 0x18
	    struct TSoftObjectPtr<struct UTexture2D*> LargePreviewImage; // 0x38 Size: 0x28
	    struct TSoftObjectPtr<struct UTexture2D*> SmallPreviewImage; // 0x60 Size: 0x28
	    class UMediaSource* PreviewVideoMediaSource; // 0x88 Size: 0x8

};

struct FFortVideoInfo
{
	public:
	    FName ID; // 0x0 Size: 0x8
	    class UTexture2D* PreviewImage; // 0x8 Size: 0x8
	    class UMediaSource* VideoSource; // 0x10 Size: 0x8
	    class ULocalizedOverlays* SubtitleOverlays; // 0x18 Size: 0x8
	    bool bIsQuestDrivenVideo; // 0x20 Size: 0x1
	    char UnknownData0[0x3]; // 0x21
	    struct FPrimaryAssetId RequiredActiveQuest; // 0x24 Size: 0x10
	    struct FPrimaryAssetId RequiredCompletedQuest; // 0x34 Size: 0x10
	    char UnknownData1[0x4]; // 0x44
	    struct FDataTableRowHandle EventMovieQuestObjective; // 0x48 Size: 0x10

};

struct FHeistExitCraftIconData
{
	public:
	    int IconIndex; // 0x0 Size: 0x4
	    EHeistExitCraftIconState IconState; // 0x4 Size: 0x1
	    EHeistExitCraftIconState PrevIconState; // 0x5 Size: 0x1
	    char UnknownData0[0x2]; // 0x6
	    int SecondsUntilIncoming; // 0x8 Size: 0x4
	    bool bTeamHasBling; // 0xc Size: 0x1
	    char UnknownData1[0x3];

};

struct FHeistBlingIconData
{
	public:
	    int IconIndex; // 0x0 Size: 0x4
	    EHeistBlingIconState IconState; // 0x4 Size: 0x1
	    EHeistBlingIconState PrevIconState; // 0x5 Size: 0x1
	    char UnknownData0[0x2];

};

struct FPanZoomFingerState
{
	public:
	    char UnknownData0[0x10];

};

struct FTDMTeamScoreData
{
	public:
	    struct FText CurrScoreText; // 0x0 Size: 0x18
	    float CurrScorePercent; // 0x18 Size: 0x4
	    int CurrScore; // 0x1c Size: 0x4

};


}