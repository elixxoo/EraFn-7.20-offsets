#include "../SDK.hpp"

void UClothingSimulationInteractorNv::SetAnimDriveSpringStiffness(float InStiffness)
{
	struct {
            float InStiffness;
	} params{ InStiffness };

    static auto fn = UObject::FindObject("/Script/ClothingSystemRuntime.ClothingSimulationInteractorNv:SetAnimDriveSpringStiffness");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UClothingSimulationInteractorNv::SetAnimDriveDamperStiffness(float InStiffness)
{
	struct {
            float InStiffness;
	} params{ InStiffness };

    static auto fn = UObject::FindObject("/Script/ClothingSystemRuntime.ClothingSimulationInteractorNv:SetAnimDriveDamperStiffness");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UClothingSimulationInteractorNv::EnableGravityOverride(struct FVector InVector)
{
	struct {
            struct FVector InVector;
	} params{ InVector };

    static auto fn = UObject::FindObject("/Script/ClothingSystemRuntime.ClothingSimulationInteractorNv:EnableGravityOverride");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UClothingSimulationInteractorNv::DisableGravityOverride()
{
    static auto fn = UObject::FindObject("/Script/ClothingSystemRuntime.ClothingSimulationInteractorNv:DisableGravityOverride");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);
}

