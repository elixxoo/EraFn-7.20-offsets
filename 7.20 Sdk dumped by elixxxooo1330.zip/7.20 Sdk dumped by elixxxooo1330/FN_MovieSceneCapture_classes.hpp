#pragma once

#include "../SDK.hpp"

namespace SDK {


class UMovieSceneCaptureProtocolBase : public UObject
{
	public:
	    char UnknownData0[0x28];
	    EMovieSceneCaptureProtocolState State; // 0x50 Size: 0x1
	    bool bFrameRequested; // 0x51 Size: 0x1
	    char UnknownData1[0x52]; // 0x52
	    bool IsCapturing(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    EMovieSceneCaptureProtocolState GetState(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7f89];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneCapture.MovieSceneCaptureProtocolBase");
			return (class UClass*)ptr;
		};

};

class UMovieSceneAudioCaptureProtocolBase : public UMovieSceneCaptureProtocolBase
{
	public:
	    char UnknownData0[0x58];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneCapture.MovieSceneAudioCaptureProtocolBase");
			return (class UClass*)ptr;
		};

};

class UNullAudioCaptureProtocol : public UMovieSceneAudioCaptureProtocolBase
{
	public:
	    char UnknownData0[0x58];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneCapture.NullAudioCaptureProtocol");
			return (class UClass*)ptr;
		};

};

class UMasterAudioSubmixCaptureProtocol : public UMovieSceneAudioCaptureProtocolBase
{
	public:
	    struct FString Filename; // 0x58 Size: 0x10
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneCapture.MasterAudioSubmixCaptureProtocol");
			return (class UClass*)ptr;
		};

};

class UMovieSceneImageCaptureProtocolBase : public UMovieSceneCaptureProtocolBase
{
	public:
	    char UnknownData0[0x58];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneCapture.MovieSceneImageCaptureProtocolBase");
			return (class UClass*)ptr;
		};

};

class UCompositionGraphCaptureProtocol : public UMovieSceneImageCaptureProtocolBase
{
	public:
	    struct FCompositionGraphCapturePasses IncludeRenderPasses; // 0x58 Size: 0x10
	    bool bCaptureFramesInHDR; // 0x68 Size: 0x1
	    char UnknownData0[0x3]; // 0x69
	    int HDRCompressionQuality; // 0x6c Size: 0x4
	    char CaptureGamut; // 0x70 Size: 0x1
	    char UnknownData1[0x7]; // 0x71
	    struct FSoftObjectPath PostProcessingMaterial; // 0x78 Size: 0x18
	    bool bDisableScreenPercentage; // 0x90 Size: 0x1
	    char UnknownData2[0x7]; // 0x91
	    class UMaterialInterface* PostProcessingMaterialPtr; // 0x98 Size: 0x8
	    char UnknownData3[0x20];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneCapture.CompositionGraphCaptureProtocol");
			return (class UClass*)ptr;
		};

};

class UFrameGrabberProtocol : public UMovieSceneImageCaptureProtocolBase
{
	public:
	    char UnknownData0[0x68];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneCapture.FrameGrabberProtocol");
			return (class UClass*)ptr;
		};

};

class UImageSequenceProtocol : public UFrameGrabberProtocol
{
	public:
	    char UnknownData0[0xd8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneCapture.ImageSequenceProtocol");
			return (class UClass*)ptr;
		};

};

class UCompressedImageSequenceProtocol : public UImageSequenceProtocol
{
	public:
	    int CompressionQuality; // 0xd8 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneCapture.CompressedImageSequenceProtocol");
			return (class UClass*)ptr;
		};

};

class UImageSequenceProtocol_BMP : public UImageSequenceProtocol
{
	public:
	    char UnknownData0[0xd8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneCapture.ImageSequenceProtocol_BMP");
			return (class UClass*)ptr;
		};

};

class UImageSequenceProtocol_PNG : public UCompressedImageSequenceProtocol
{
	public:
	    char UnknownData0[0xe0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneCapture.ImageSequenceProtocol_PNG");
			return (class UClass*)ptr;
		};

};

class UImageSequenceProtocol_JPG : public UCompressedImageSequenceProtocol
{
	public:
	    char UnknownData0[0xe0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneCapture.ImageSequenceProtocol_JPG");
			return (class UClass*)ptr;
		};

};

class UImageSequenceProtocol_EXR : public UImageSequenceProtocol
{
	public:
	    bool bCompressed; // 0xd8 Size: 0x1
	    char CaptureGamut; // 0xd9 Size: 0x1
	    char UnknownData0[0xe];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneCapture.ImageSequenceProtocol_EXR");
			return (class UClass*)ptr;
		};

};

class UMovieSceneCaptureInterface : public UInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneCapture.MovieSceneCaptureInterface");
			return (class UClass*)ptr;
		};

};

class UMovieSceneCapture : public UObject
{
	public:
	    char UnknownData0[0x10];
	    struct FSoftClassPath ImageCaptureProtocolType; // 0x38 Size: 0x18
	    struct FSoftClassPath AudioCaptureProtocolType; // 0x50 Size: 0x18
	    class UMovieSceneImageCaptureProtocolBase* ImageCaptureProtocol; // 0x68 Size: 0x8
	    class UMovieSceneAudioCaptureProtocolBase* AudioCaptureProtocol; // 0x70 Size: 0x8
	    struct FMovieSceneCaptureSettings Settings; // 0x78 Size: 0x50
	    bool bUseSeparateProcess; // 0xc8 Size: 0x1
	    bool bCloseEditorWhenCaptureStarts; // 0xc9 Size: 0x1
	    char UnknownData1[0x6]; // 0xca
	    struct FString AdditionalCommandLineArguments; // 0xd0 Size: 0x10
	    struct FString InheritedCommandLineArguments; // 0xe0 Size: 0x10
	    char UnknownData2[0xf0]; // 0xf0
	    void SetImageCaptureProtocolType(class UMovieSceneCaptureProtocolBase* ProtocolType); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetAudioCaptureProtocolType(class UMovieSceneCaptureProtocolBase* ProtocolType); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    class UMovieSceneCaptureProtocolBase* GetImageCaptureProtocol(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    class UMovieSceneCaptureProtocolBase* GetAudioCaptureProtocol(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7df1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneCapture.MovieSceneCapture");
			return (class UClass*)ptr;
		};

};

class ULevelCapture : public UMovieSceneCapture
{
	public:
	    bool bAutoStartCapture; // 0x1f0 Size: 0x1
	    char UnknownData0[0xb]; // 0x1f1
	    struct FGuid PrerequisiteActorId; // 0x1fc Size: 0x10
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneCapture.LevelCapture");
			return (class UClass*)ptr;
		};

};

class UMovieSceneCaptureEnvironment : public UObject
{
	public:
	    static bool IsCaptureInProgress(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static int GetCaptureFrameNumber(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static float GetCaptureElapsedTime(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static class UMovieSceneImageCaptureProtocolBase* FindImageCaptureProtocol(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static class UMovieSceneAudioCaptureProtocolBase* FindAudioCaptureProtocol(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneCapture.MovieSceneCaptureEnvironment");
			return (class UClass*)ptr;
		};

};

class UUserDefinedCaptureProtocol : public UMovieSceneImageCaptureProtocolBase
{
	public:
	    class UWorld* World; // 0x58 Size: 0x8
	    char UnknownData0[0x60]; // 0x60
	    void StopCapturingFinalPixels(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void StartCapturingFinalPixels(FName StreamName); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void ResolveBuffer(class UTexture* Buffer, FName BufferName, __int64/*DelegateProperty*/ Handler); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void PushBufferToStream(class UTexture* Buffer, FName StreamName); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void OnWarmUp(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void OnTick(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void OnStartCapture(); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    bool OnSetup(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void OnPreTick(); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void OnPauseCapture(); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void OnFinalize(); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void OnCaptureFrame(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    bool OnCanFinalize(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void OnBeginFinalize(); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    struct FFrameMetrics GetCurrentFrameMetrics(); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    struct FString GenerateFilename(struct FFrameMetrics InFrameMetrics); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void BindToStream(FName StreamName, __int64/*DelegateProperty*/ Handler); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x-7f01];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneCapture.UserDefinedCaptureProtocol");
			return (class UClass*)ptr;
		};

};

class UUserDefinedImageCaptureProtocol : public UUserDefinedCaptureProtocol
{
	public:
	    EDesiredImageFormat Format; // 0xe0 Size: 0x1
	    bool bEnableCompression; // 0xe1 Size: 0x1
	    char UnknownData0[0x2]; // 0xe2
	    int CompressionQuality; // 0xe4 Size: 0x4
	    char UnknownData1[0xe8]; // 0xe8
	    void WriteImageToDisk(struct FCapturedPixels PixelData, FName StreamName, struct FFrameMetrics FrameMetrics, bool bCopyImageData); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    struct FString GenerateFilenameForCurrentFrame(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    struct FString GenerateFilenameForBuffer(class UTexture* Buffer, FName StreamName); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7ef9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneCapture.UserDefinedImageCaptureProtocol");
			return (class UClass*)ptr;
		};

};

class UVideoCaptureProtocol : public UFrameGrabberProtocol
{
	public:
	    bool bUseCompression; // 0x68 Size: 0x1
	    char UnknownData0[0x3]; // 0x69
	    float CompressionQuality; // 0x6c Size: 0x4
	    struct FString VideoCodec; // 0x70 Size: 0x10
	    char UnknownData1[0x10];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MovieSceneCapture.VideoCaptureProtocol");
			return (class UClass*)ptr;
		};

};


}