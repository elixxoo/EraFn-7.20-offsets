#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FOnMediaPlayerMediaEvent__DelegateSignature
{
	public:

};

struct FOnMediaPlayerMediaOpened__DelegateSignature
{
	public:
	    struct FString OpenedUrl; // 0x0 Size: 0x10

};

struct FOnMediaPlayerMediaOpenFailed__DelegateSignature
{
	public:
	    struct FString FailedUrl; // 0x0 Size: 0x10

};



enum class EMediaWebcamCaptureDeviceFilter : uint8_t
{
    DepthSensor = 1,
    Front = 2,
    Rear = 4,
    Unknown = 8,
    EMediaWebcamCaptureDeviceFilter_MAX = 9
};

enum class EMediaVideoCaptureDeviceFilter : uint8_t
{
    Card = 1,
    Software = 2,
    Unknown = 4,
    Webcam = 8,
    EMediaVideoCaptureDeviceFilter_MAX = 9
};

enum class EMediaAudioCaptureDeviceFilter : uint8_t
{
    Card = 1,
    Microphone = 2,
    Software = 4,
    Unknown = 8,
    EMediaAudioCaptureDeviceFilter_MAX = 9
};

enum class EMediaPlayerTrack : uint8_t
{
    Audio = 0,
    Caption = 1,
    Metadata = 2,
    Script = 3,
    Subtitle = 4,
    Text = 5,
    Video = 6,
    EMediaPlayerTrack_MAX = 7
};

enum class EMediaSoundComponentFFTSize : uint8_t
{
    Min_64 = 0,
    Small_256 = 1,
    Medium_512 = 2,
    Large_1024 = 3,
    EMediaSoundComponentFFTSize_MAX = 4
};

enum class EMediaSoundChannels : uint8_t
{
    Mono = 0,
    Stereo = 1,
    Surround = 2,
    EMediaSoundChannels_MAX = 3
};struct FMediaCaptureDevice
{
	public:
	    struct FText DisplayName; // 0x0 Size: 0x18
	    struct FString URL; // 0x18 Size: 0x10

};

struct FMediaSoundComponentSpectralData
{
	public:
	    float FrequencyHz; // 0x0 Size: 0x4
	    float Magnitude; // 0x4 Size: 0x4

};


}