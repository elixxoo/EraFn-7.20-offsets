#include "../SDK.hpp"

static class USubsystem* UBlueprintContextLibrary::GetContext(class UObject* ContextObject, class USubsystem* Class)
{
	struct {
            class UObject* ContextObject;
            class USubsystem* Class;
            class USubsystem* ReturnValue;
	} params{ ContextObject, Class };

    static auto fn = UObject::FindObject("/Script/BlueprintContext.BlueprintContextLibrary:GetContext");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);

    return params.ReturnValue; 
}

