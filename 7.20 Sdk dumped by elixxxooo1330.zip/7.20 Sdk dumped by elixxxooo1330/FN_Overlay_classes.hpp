#pragma once

#include "../SDK.hpp"

namespace SDK {


class UOverlays : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Overlay.Overlays");
			return (class UClass*)ptr;
		};

};

class UBasicOverlays : public UOverlays
{
	public:
	    TArray<struct FOverlayItem> Overlays; // 0x28 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Overlay.BasicOverlays");
			return (class UClass*)ptr;
		};

};

class ULocalizedOverlays : public UOverlays
{
	public:
	    class UBasicOverlays* DefaultOverlays; // 0x28 Size: 0x8
	    __int64/*MapProperty*/ LocaleToOverlaysMap; // 0x30 Size: 0x50

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Overlay.LocalizedOverlays");
			return (class UClass*)ptr;
		};

};


}