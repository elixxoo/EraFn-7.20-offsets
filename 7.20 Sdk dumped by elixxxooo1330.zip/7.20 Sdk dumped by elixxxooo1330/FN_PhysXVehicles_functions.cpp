#include "../SDK.hpp"

void UWheeledVehicleMovementComponent::SetUseAutoGears(bool bUseAuto)
{
	struct {
            bool bUseAuto;
	} params{ bUseAuto };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent:SetUseAutoGears");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWheeledVehicleMovementComponent::SetThrottleInput(float Throttle)
{
	struct {
            float Throttle;
	} params{ Throttle };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent:SetThrottleInput");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWheeledVehicleMovementComponent::SetTargetGear(int GearNum, bool bImmediate)
{
	struct {
            int GearNum;
            bool bImmediate;
	} params{ GearNum, bImmediate };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent:SetTargetGear");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWheeledVehicleMovementComponent::SetSteeringInput(float Steering)
{
	struct {
            float Steering;
	} params{ Steering };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent:SetSteeringInput");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWheeledVehicleMovementComponent::SetHandbrakeInput(bool bNewHandbrake)
{
	struct {
            bool bNewHandbrake;
	} params{ bNewHandbrake };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent:SetHandbrakeInput");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWheeledVehicleMovementComponent::SetGroupsToIgnoreMask(struct FNavAvoidanceMask GroupMask)
{
	struct {
            struct FNavAvoidanceMask GroupMask;
	} params{ GroupMask };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent:SetGroupsToIgnoreMask");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWheeledVehicleMovementComponent::SetGroupsToIgnore(int GroupFlags)
{
	struct {
            int GroupFlags;
	} params{ GroupFlags };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent:SetGroupsToIgnore");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWheeledVehicleMovementComponent::SetGroupsToAvoidMask(struct FNavAvoidanceMask GroupMask)
{
	struct {
            struct FNavAvoidanceMask GroupMask;
	} params{ GroupMask };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent:SetGroupsToAvoidMask");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWheeledVehicleMovementComponent::SetGroupsToAvoid(int GroupFlags)
{
	struct {
            int GroupFlags;
	} params{ GroupFlags };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent:SetGroupsToAvoid");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWheeledVehicleMovementComponent::SetGearUp(bool bNewGearUp)
{
	struct {
            bool bNewGearUp;
	} params{ bNewGearUp };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent:SetGearUp");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWheeledVehicleMovementComponent::SetGearDown(bool bNewGearDown)
{
	struct {
            bool bNewGearDown;
	} params{ bNewGearDown };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent:SetGearDown");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWheeledVehicleMovementComponent::SetBrakeInput(float Brake)
{
	struct {
            float Brake;
	} params{ Brake };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent:SetBrakeInput");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWheeledVehicleMovementComponent::SetAvoidanceGroupMask(struct FNavAvoidanceMask GroupMask)
{
	struct {
            struct FNavAvoidanceMask GroupMask;
	} params{ GroupMask };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent:SetAvoidanceGroupMask");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWheeledVehicleMovementComponent::SetAvoidanceGroup(int GroupFlags)
{
	struct {
            int GroupFlags;
	} params{ GroupFlags };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent:SetAvoidanceGroup");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWheeledVehicleMovementComponent::SetAvoidanceEnabled(bool bEnable)
{
	struct {
            bool bEnable;
	} params{ bEnable };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent:SetAvoidanceEnabled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UWheeledVehicleMovementComponent::ServerUpdateState(float InSteeringInput, float InThrottleInput, float InBrakeInput, float InHandbrakeInput, int CurrentGear)
{
	struct {
            float InSteeringInput;
            float InThrottleInput;
            float InBrakeInput;
            float InHandbrakeInput;
            int CurrentGear;
	} params{ InSteeringInput, InThrottleInput, InBrakeInput, InHandbrakeInput, CurrentGear };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent:ServerUpdateState");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool UWheeledVehicleMovementComponent::GetUseAutoGears()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent:GetUseAutoGears");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


int UWheeledVehicleMovementComponent::GetTargetGear()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent:GetTargetGear");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UWheeledVehicleMovementComponent::GetForwardSpeed()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent:GetForwardSpeed");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UWheeledVehicleMovementComponent::GetEngineRotationSpeed()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent:GetEngineRotationSpeed");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UWheeledVehicleMovementComponent::GetEngineMaxRotationSpeed()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent:GetEngineMaxRotationSpeed");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


int UWheeledVehicleMovementComponent::GetCurrentGear()
{
	struct {
            int ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.WheeledVehicleMovementComponent:GetCurrentGear");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void USimpleWheeledVehicleMovementComponent::SetSteerAngle(float SteerAngle, int WheelIndex)
{
	struct {
            float SteerAngle;
            int WheelIndex;
	} params{ SteerAngle, WheelIndex };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.SimpleWheeledVehicleMovementComponent:SetSteerAngle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USimpleWheeledVehicleMovementComponent::SetDriveTorque(float DriveTorque, int WheelIndex)
{
	struct {
            float DriveTorque;
            int WheelIndex;
	} params{ DriveTorque, WheelIndex };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.SimpleWheeledVehicleMovementComponent:SetDriveTorque");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void USimpleWheeledVehicleMovementComponent::SetBrakeTorque(float BrakeTorque, int WheelIndex)
{
	struct {
            float BrakeTorque;
            int WheelIndex;
	} params{ BrakeTorque, WheelIndex };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.SimpleWheeledVehicleMovementComponent:SetBrakeTorque");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

class AWheeledVehicle* UVehicleAnimInstance::GetVehicle()
{
	struct {
            class AWheeledVehicle* ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.VehicleAnimInstance:GetVehicle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

bool UVehicleWheel::IsInAir()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.VehicleWheel:IsInAir");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UVehicleWheel::GetSuspensionOffset()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.VehicleWheel:GetSuspensionOffset");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UVehicleWheel::GetSteerAngle()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.VehicleWheel:GetSteerAngle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


float UVehicleWheel::GetRotationAngle()
{
	struct {
            float ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/PhysXVehicles.VehicleWheel:GetRotationAngle");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

