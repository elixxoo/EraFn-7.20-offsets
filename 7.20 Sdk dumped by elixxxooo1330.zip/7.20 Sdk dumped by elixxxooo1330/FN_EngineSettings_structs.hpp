#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class ESubLevelStripMode : uint8_t
{
    ExactClass = 0,
    IsChildOf = 1,
    ESubLevelStripMode_MAX = 2
};

enum class EFourPlayerSplitScreenType : uint8_t
{
    Grid = 0,
    Vertical = 1,
    EFourPlayerSplitScreenType_MAX = 2
};

enum class EThreePlayerSplitScreenType : uint8_t
{
    FavorTop = 0,
    FavorBottom = 1,
    Vertical = 2,
    EThreePlayerSplitScreenType_MAX = 3
};

enum class ETwoPlayerSplitScreenType : uint8_t
{
    Horizontal = 0,
    Vertical = 1,
    ETwoPlayerSplitScreenType_MAX = 2
};struct FAutoCompleteCommand
{
	public:
	    struct FString Command; // 0x0 Size: 0x10
	    struct FString Desc; // 0x10 Size: 0x10
	    char UnknownData0[0x8];

};

struct FSubLevelStrippingInfo
{
	public:
	    struct FSoftClassPath ClassToStrip; // 0x0 Size: 0x18
	    ESubLevelStripMode StripMode; // 0x18 Size: 0x1
	    char UnknownData0[0x7];

};

struct FGameModeName
{
	public:
	    struct FString Name; // 0x0 Size: 0x10
	    struct FSoftClassPath GameMode; // 0x10 Size: 0x18

};


}