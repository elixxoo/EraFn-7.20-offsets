#include "../SDK.hpp"

void UMcpProfile::UnlockProfileForWrite(struct FString Code, struct FDedicatedServerUrlContext Context)
{
	struct {
            struct FString Code;
            struct FDedicatedServerUrlContext Context;
	} params{ Code, Context };

    static auto fn = UObject::FindObject("/Script/McpProfileSys.McpProfile:UnlockProfileForWrite");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMcpProfile::QueryPublicProfile(struct FBaseUrlContext Context)
{
	struct {
            struct FBaseUrlContext Context;
	} params{ Context };

    static auto fn = UObject::FindObject("/Script/McpProfileSys.McpProfile:QueryPublicProfile");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMcpProfile::QueryProfile(struct FBaseUrlContext Context)
{
	struct {
            struct FBaseUrlContext Context;
	} params{ Context };

    static auto fn = UObject::FindObject("/Script/McpProfileSys.McpProfile:QueryProfile");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMcpProfile::LockProfileForWrite(struct FString Code, int Timeout, struct FDedicatedServerUrlContext Context)
{
	struct {
            struct FString Code;
            int Timeout;
            struct FDedicatedServerUrlContext Context;
	} params{ Code, Timeout, Context };

    static auto fn = UObject::FindObject("/Script/McpProfileSys.McpProfile:LockProfileForWrite");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMcpProfile::DeleteProfile(struct FClientUrlContext Context)
{
	struct {
            struct FClientUrlContext Context;
	} params{ Context };

    static auto fn = UObject::FindObject("/Script/McpProfileSys.McpProfile:DeleteProfile");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UMcpProfile::DeleteAllProfiles(struct FClientUrlContext Context)
{
	struct {
            struct FClientUrlContext Context;
	} params{ Context };

    static auto fn = UObject::FindObject("/Script/McpProfileSys.McpProfile:DeleteAllProfiles");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

