#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FOnTimeHitCallback__DelegateSignature
{
	public:

};

struct FCommitAccountCostsDelegate__DelegateSignature
{
	public:

};

struct FDirectedMovementDelegate__DelegateSignature
{
	public:

};

struct FFortOnCameraFrameTargetSettingsChangedDelegate__DelegateSignature
{
	public:
	    __int64/*InterfaceProperty*/ Object; // 0x0 Size: 0x10

};

struct FFortOnItemDefinitionCountChangedDelegate__DelegateSignature
{
	public:
	    class UFortItemDefinition* Definition; // 0x0 Size: 0x8
	    int Delta; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortOnItemChangedDelegate__DelegateSignature
{
	public:
	    bool bItemChanged; // 0x0 Size: 0x1
	    bool bAmmoChanged; // 0x1 Size: 0x1
	    bool bIngredientsChanged; // 0x2 Size: 0x1

};

struct FFortOnItemDestroyedDelegate__DelegateSignature
{
	public:

};

struct FPickupOnPickup__DelegateSignature
{
	public:
	    class AFortPickup* SelfActor; // 0x0 Size: 0x8
	    class AFortPawn* InteractingPawn; // 0x8 Size: 0x8
	    class UFortWorldItemDefinition* WorldItemDefinition; // 0x10 Size: 0x8
	    struct FVector PickupLocation; // 0x18 Size: 0xc
	    char UnknownData0[0x4];

};

struct FOnSpectatorsChanged__DelegateSignature
{
	public:
	    int Num; // 0x0 Size: 0x4

};

struct FOnSpectatorCountChanged__DelegateSignature
{
	public:
	    int SpectatorCount; // 0x0 Size: 0x4

};

struct FOnSpectatingTargetChanged__DelegateSignature
{
	public:
	    class AFortPlayerStateZone* SpectatingTarget; // 0x0 Size: 0x8

};

struct FOnAccumulatedItemsChanged__DelegateSignature
{
	public:

};

struct FOnCurrentPawnChanged__DelegateSignature
{
	public:

};

struct FPawnDamagedSignature__DelegateSignature
{
	public:
	    class AActor* DamagedActor; // 0x0 Size: 0x8
	    float Damage; // 0x8 Size: 0x4
	    char UnknownData0[0x4]; // 0xc
	    class AController* InstigatedBy; // 0x10 Size: 0x8
	    class AActor* DamageCauser; // 0x18 Size: 0x8
	    struct FVector HitLocation; // 0x20 Size: 0xc
	    char UnknownData1[0x4]; // 0x2c
	    class UPrimitiveComponent* FHitComponent; // 0x30 Size: 0x8
	    FName BoneName; // 0x38 Size: 0x8
	    struct FVector Momentum; // 0x40 Size: 0xc
	    char UnknownData2[0x4];

};

struct FPawnDeathEffectsSignature__DelegateSignature
{
	public:
	    class AActor* DeadActor; // 0x0 Size: 0x8
	    float Damage; // 0x8 Size: 0x4
	    char UnknownData0[0x4]; // 0xc
	    class AFortPawn* InstigatedBy; // 0x10 Size: 0x8
	    struct FVector HitLocation; // 0x18 Size: 0xc
	    char UnknownData1[0x4]; // 0x24
	    class AActor* DamageCauser; // 0x28 Size: 0x8

};

struct FPawnLandedSignature__DelegateSignature
{
	public:
	    struct FHitResult Hit; // 0x0 Size: 0x88

};

struct FFortPawnEquippedWeaponSignature__DelegateSignature
{
	public:
	    class AFortWeapon* NewWeapon; // 0x0 Size: 0x8
	    class AFortWeapon* PrevWeapon; // 0x8 Size: 0x8

};

struct FFortPawnUnEquippedWeaponSignature__DelegateSignature
{
	public:

};

struct FPawnUpdatedDecisionWindowStackSignature__DelegateSignature
{
	public:

};

struct FPawnHealthChanged__DelegateSignature
{
	public:

};

struct FOnStormShieldComponentCreated__DelegateSignature
{
	public:
	    class UFortStormShieldComponent* StormShieldComponent; // 0x0 Size: 0x8

};

struct FOnHolsteredEvent__DelegateSignature
{
	public:

};

struct FOnUnholsteredEvent__DelegateSignature
{
	public:

};

struct FMoveAIDelegate__DelegateSignature
{
	public:

};

struct FAnimWaitSimpleDelegate__DelegateSignature
{
	public:

};

struct FWaitTargetSelectionDelegate__DelegateSignature
{
	public:
	    struct FGameplayAbilityTargetDataHandle TargetData; // 0x0 Size: 0x20
	    struct FGameplayTag ApplicationTag; // 0x20 Size: 0x8

};

struct FSetNextMontageSectionSimpleDelegate__DelegateSignature
{
	public:

};

struct FMoveToLocationDelegate__DelegateSignature
{
	public:

};

struct FOnAnimBPReady__DelegateSignature
{
	public:

};

struct FAsyncTaskResult
{
	public:
	    bool bSucceeded; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FString ErrorCode; // 0x8 Size: 0x10
	    struct FText ErrorMessage; // 0x18 Size: 0x18

};

struct FAsyncTaskCallbackDelegate__DelegateSignature
{
	public:
	    struct FAsyncTaskResult Result; // 0x0 Size: 0x30

};

struct FBuildingActorOnInteract__DelegateSignature
{
	public:
	    class ABuildingActor* SelfActor; // 0x0 Size: 0x8
	    class AFortPawn* InteractingPawn; // 0x8 Size: 0x8

};

struct FActorHealthChanged__DelegateSignature
{
	public:
	    class AActor* Actor; // 0x0 Size: 0x8
	    float NewHealth; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FBuildingDamagedSignature__DelegateSignature
{
	public:
	    class AActor* DamagedActor; // 0x0 Size: 0x8
	    float Damage; // 0x8 Size: 0x4
	    char UnknownData0[0x4]; // 0xc
	    class AController* InstigatedBy; // 0x10 Size: 0x8
	    class AActor* DamageCauser; // 0x18 Size: 0x8
	    struct FVector HitLocation; // 0x20 Size: 0xc
	    char UnknownData1[0x4]; // 0x2c
	    class UPrimitiveComponent* FHitComponent; // 0x30 Size: 0x8
	    FName BoneName; // 0x38 Size: 0x8
	    struct FVector Momentum; // 0x40 Size: 0xc
	    char UnknownData2[0x4];

};

struct FBuildingHealthChanged__DelegateSignature
{
	public:

};

struct FEditPieceDelegate__DelegateSignature
{
	public:
	    class ABuildingSMActor* BuildingActor; // 0x0 Size: 0x8

};

struct FRepairStartedDelegate__DelegateSignature
{
	public:
	    class AFortPlayerController* PlayerController; // 0x0 Size: 0x8

};

struct FTrapAttachedDelegate__DelegateSignature
{
	public:
	    class ABuildingTrap* Trap; // 0x0 Size: 0x8
	    bool bDetached; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FRepairFinishedDelegate__DelegateSignature
{
	public:

};

struct FOnConstructionComplete__DelegateSignature
{
	public:
	    class ABuildingSMActor* BuildingSMActor; // 0x0 Size: 0x8

};

struct FBuildingReplacementDestruction__DelegateSignature
{
	public:
	    char ReplacementType; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class ABuildingSMActor* NewBuildingActor; // 0x8 Size: 0x8

};



enum class EBuildingReplacementType : uint8_t
{
    BRT_None = 0,
    BRT_Edited = 1,
    BRT_Upgrade = 2,
    BRT_MAX = 3
};struct FFortAIInteraction__DelegateSignature
{
	public:
	    class AFortAIPawn* AI; // 0x0 Size: 0x8
	    class AFortPlayerController* InteractingPlayerController; // 0x8 Size: 0x8

};

struct FFortDBNO__DelegateSignature
{
	public:
	    class AFortAIPawn* DownedAI; // 0x0 Size: 0x8
	    class AController* DownedInstigator; // 0x8 Size: 0x8

};

struct FFortCrowdOverlap__DelegateSignature
{
	public:
	    class AFortPawn* OtherPawn; // 0x0 Size: 0x8

};

struct FFortAIInventoryUpdated__DelegateSignature
{
	public:

};



enum class EFortAIDirectorEvent : uint8_t
{
    PlayerAIEnemies = 0,
    PlayerTakeDamage = 1,
    PlayerHealth = 2,
    PlayerDeath = 3,
    PlayerLookAtAIEnemy = 4,
    PlayerDamageAIEnemy = 5,
    PlayerKillAIEnemy = 6,
    PlayerHealingPotential = 7,
    PlayerAmmoLight = 8,
    PlayerAmmoMedium = 9,
    PlayerAmmoHeavy = 10,
    PlayerAmmoShells = 11,
    PlayerAmmoEnergy = 12,
    PlayerAINear = 13,
    PlayerMovement = 14,
    ObjectiveTakeDamage = 15,
    ObjectiveHealth = 16,
    ObjectiveDestroyed = 17,
    TrapFired = 18,
    TrapDamagedAIEnemy = 19,
    ObjectivePathCost = 20,
    PlayerPathCost = 21,
    ObjectiveNearbyBuildingDamaged = 22,
    Max_None = 23,
    EFortAIDirectorEvent_MAX = 24
};struct FFortAIDirectorEvent
{
	public:
	    EFortAIDirectorEvent Event; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class UObject* EventSource; // 0x8 Size: 0x8
	    class UObject* EventTarget; // 0x10 Size: 0x8
	    float EventValue; // 0x18 Size: 0x4
	    char UnknownData1[0x4];

};

struct FOnAIDirectorEventFired__DelegateSignature
{
	public:
	    struct FFortAIDirectorEvent Event; // 0x0 Size: 0x20

};

struct FOnEncounterAllEnemiesKilled__DelegateSignature
{
	public:
	    class UFortAIEncounterInfo* Encounter; // 0x0 Size: 0x8

};

struct FOnEncounterRampStarted__DelegateSignature
{
	public:
	    class UFortAIEncounterInfo* Encounter; // 0x0 Size: 0x8

};

struct FOnEncounterPeakStarted__DelegateSignature
{
	public:
	    class UFortAIEncounterInfo* Encounter; // 0x0 Size: 0x8

};

struct FOnEncounterFadeStarted__DelegateSignature
{
	public:
	    class UFortAIEncounterInfo* Encounter; // 0x0 Size: 0x8

};

struct FOnEncounterRestStarted__DelegateSignature
{
	public:
	    class UFortAIEncounterInfo* Encounter; // 0x0 Size: 0x8

};

struct FOnEncounterCombatParticipation__DelegateSignature
{
	public:
	    class UFortAIEncounterInfo* Encounter; // 0x0 Size: 0x8

};

struct FOnEncounterSpawnDirectionsChosen__DelegateSignature
{
	public:
	    class UFortAIEncounterInfo* Encounter; // 0x0 Size: 0x8

};

struct FOnEncounterOptionsChanged__DelegateSignature
{
	public:
	    class UFortAIEncounterInfo* Encounter; // 0x0 Size: 0x8

};

struct FOnEncounterPawnDied__DelegateSignature
{
	public:
	    class UFortAIEncounterInfo* Encounter; // 0x0 Size: 0x8
	    class AFortAIPawn* DeadPawn; // 0x8 Size: 0x8

};

struct FOnEncounterEnemySpawned__DelegateSignature
{
	public:
	    class UFortAIEncounterInfo* Encounter; // 0x0 Size: 0x8
	    class AFortAIPawn* SpawnedEnemy; // 0x8 Size: 0x8

};

struct FOnEncounterCompleted__DelegateSignature
{
	public:
	    class UFortAIEncounterInfo* Encounter; // 0x0 Size: 0x8
	    bool bSuccessfullyCompleted; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FOnEncounterAllBurstEnemiesSpawned__DelegateSignature
{
	public:
	    class UFortAIEncounterInfo* Encounter; // 0x0 Size: 0x8

};

struct FOnBuildingRiftSpawnedAISignature__DelegateSignature
{
	public:

};

struct FOnTwoPointSolverFailed__DelegateSignature
{
	public:

};

struct FOnTwoPointSolverFinished__DelegateSignature
{
	public:
	    struct FVector PointA; // 0x0 Size: 0xc
	    struct FVector PointB; // 0xc Size: 0xc

};

struct FOnEventStartedSignature__DelegateSignature
{
	public:
	    int NuberOfWaves; // 0x0 Size: 0x4
	    float EventDuration; // 0x4 Size: 0x4
	    float WarmupDuration; // 0x8 Size: 0x4

};

struct FOnWarmupEndedSignature__DelegateSignature
{
	public:
	    float EncounterDuration; // 0x0 Size: 0x4

};

struct FOnEncounterTimeoutSignature__DelegateSignature
{
	public:
	    int AliveEnemies; // 0x0 Size: 0x4

};

struct FOnEventEndedSignature__DelegateSignature
{
	public:

};

struct FOnOnEventStoppedSignature__DelegateSignature
{
	public:

};

struct FOnAllEnemiesKilledSignature__DelegateSignature
{
	public:
	    float WarmupDuration; // 0x0 Size: 0x4

};

struct FOnDefenseStateChangedSignature__DelegateSignature
{
	public:
	    char NewDefenseState; // 0x0 Size: 0x1

};



enum class EKeepDefenseState : uint8_t
{
    Inactive = 0,
    Warmup = 1,
    Defense = 2,
    LastAlive = 3,
    Max = 4
};struct FOnEncounterStarted__DelegateSignature
{
	public:
	    class UFortAIEncounterInfo* StartedEncounter; // 0x0 Size: 0x8

};

struct FOnEncounterEnded__DelegateSignature
{
	public:
	    class UFortAIEncounterInfo* StoppedEncounter; // 0x0 Size: 0x8

};

struct FOnNewClientAnnouncementOnClientDelegate__DelegateSignature
{
	public:
	    class AFortClientAnnouncement* NewAnnouncement; // 0x0 Size: 0x8

};

struct FDayNightPhaseChangeSignature__DelegateSignature
{
	public:
	    char CurrentDayPhase; // 0x0 Size: 0x1
	    char PreviousDayPhase; // 0x1 Size: 0x1
	    bool bAtCreation; // 0x2 Size: 0x1

};



enum class EFortDayPhase : uint8_t
{
    Morning = 0,
    Day = 1,
    Evening = 2,
    Night = 3,
    NumPhases = 4,
    EFortDayPhase_MAX = 5
};struct FOnMusicVoiceEvent__DelegateSignature
{
	public:
	    class UFortMusicVoice* Voice; // 0x0 Size: 0x8

};

struct FCharacterPartChanged__DelegateSignature
{
	public:
	    char PartType; // 0x0 Size: 0x1

};



enum class EFortCustomPartType : uint8_t
{
    Head = 0,
    Body = 1,
    Hat = 2,
    Backpack = 3,
    Charm = 4,
    Face = 5,
    NumTypes = 6,
    EFortCustomPartType_MAX = 7
};struct FOnBeginSkydivingEvent__DelegateSignature
{
	public:

};

struct FOnEndSkydivingEvent__DelegateSignature
{
	public:

};

struct FOnFinishedCharacterCustomization__DelegateSignature
{
	public:
	    class AFortPlayerPawn* Pawn; // 0x0 Size: 0x8

};

struct FOnBallooningGravityCeilingChanged__DelegateSignature
{
	public:
	    int RelationToCeiling; // 0x0 Size: 0x4

};

struct FOnStartedInteractSearch__DelegateSignature
{
	public:

};

struct FOnEndedInteractSearch__DelegateSignature
{
	public:

};

struct FFortNotificationClearedDelegate__DelegateSignature
{
	public:

};

struct FPurchasedItemInfo
{
	public:
	    class UFortItem* Item; // 0x0 Size: 0x8
	    int Quantity; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FOnRealMoneyPurchaseComplete__DelegateSignature
{
	public:
	    bool bSuccess; // 0x0 Size: 0x1

};

struct FOnRealMoneyPurchaseCompleteMulti__DelegateSignature
{
	public:
	    bool bSuccess; // 0x0 Size: 0x1

};

struct FOnGiftBoxRemoved__DelegateSignature
{
	public:
	    bool bSuccess; // 0x0 Size: 0x1

};

struct FOnLoginFlowWidgetDismissed__DelegateSignature
{
	public:

};

struct FOnLoginFlowWidgetDisplay__DelegateSignature
{
	public:
	    class UWidget* WebWidget; // 0x0 Size: 0x8

};

struct FOnEpicPurchasingWidgetDismissed__DelegateSignature
{
	public:

};

struct FOnEpicPurchasingWidgetDisplay__DelegateSignature
{
	public:
	    class UWidget* WebWidget; // 0x0 Size: 0x8
	    struct FString OfferId; // 0x8 Size: 0x10

};

struct FOnBanAcknowledged__DelegateSignature
{
	public:
	    bool bSuccess; // 0x0 Size: 0x1

};

struct FOnAffilateNameSetAcknowledged__DelegateSignature
{
	public:
	    bool bSuccess; // 0x0 Size: 0x1

};

struct FOnCheckAffiliateNameComplete__DelegateSignature
{
	public:
	    bool bSuccess; // 0x0 Size: 0x1
	    bool bWasValidAffiliateName; // 0x1 Size: 0x1
	    char UnknownData0[0x6]; // 0x2
	    struct FString AffilateNameChecked; // 0x8 Size: 0x10

};

struct FAthenaLevelInfo
{
	public:
	    int AccountLevel; // 0x0 Size: 0x4
	    int Level; // 0x4 Size: 0x4
	    int MaxLevel; // 0x8 Size: 0x4
	    int LevelXp; // 0xc Size: 0x4
	    int LevelXpForLevel; // 0x10 Size: 0x4
	    int BookLevel; // 0x14 Size: 0x4
	    int BookMaxLevel; // 0x18 Size: 0x4
	    int BookLevelXp; // 0x1c Size: 0x4
	    int BookLevelXpForLevel; // 0x20 Size: 0x4

};

struct FFortPublicAccountInfo
{
	public:
	    int Level; // 0x0 Size: 0x4
	    int MaxLevel; // 0x4 Size: 0x4
	    int LevelXp; // 0x8 Size: 0x4
	    int LevelXpForLevel; // 0xc Size: 0x4
	    struct FAthenaLevelInfo BattleRoyaleLevel; // 0x10 Size: 0x24

};

struct FFortPrivateAccountInfo : public FFortPublicAccountInfo
{
	public:
	    int MtxBalance; // 0x34 Size: 0x4

};

struct FLocalAccountInfoChangedDelegate__DelegateSignature
{
	public:
	    struct FFortPrivateAccountInfo NewInfo; // 0x0 Size: 0x38

};

struct FCurrentlyViewedAccountInfoChangedDelegate__DelegateSignature
{
	public:
	    struct FFortPublicAccountInfo NewInfo; // 0x0 Size: 0x34

};

struct FHeroesChangedDelegate__DelegateSignature
{
	public:

};

struct FXpBoostChangeDelegate__DelegateSignature
{
	public:
	    int BoostAmount; // 0x0 Size: 0x4

};

struct FFounderChangeDelegate__DelegateSignature
{
	public:

};

struct FDailyRewardScheduleTokenDelegate__DelegateSignature
{
	public:

};

struct FFortItemInstanceQuantityPair
{
	public:
	    class UFortItem* Item; // 0x0 Size: 0x8
	    char InventoryType; // 0x8 Size: 0x1
	    char UnknownData0[0x3]; // 0x9
	    int Quantity; // 0xc Size: 0x4

};



enum class EFortInventoryType : uint8_t
{
    World = 0,
    Account = 1,
    Outpost = 2,
    MAX = 3
};struct FFortMissionRewardsOpenFailed__DelegateSignature
{
	public:

};

struct FFortDifficultyIncreaseRewardsClaimFailed__DelegateSignature
{
	public:

};

struct FFortItemCacheRewardsClaimFailed__DelegateSignature
{
	public:

};

struct FFortTransmogFailedDelegate__DelegateSignature
{
	public:
	    struct FText ErrorMessage; // 0x0 Size: 0x18

};

struct FOnLiveStreamingQuestWindowStarts__DelegateSignature
{
	public:
	    float Seconds; // 0x0 Size: 0x4

};

struct FOnLiveStreamingQuestWindowEnds__DelegateSignature
{
	public:

};

struct FMcpPrivacySettings
{
	public:
	    bool OptOutOfPublicLeaderboards; // 0x0 Size: 0x1
	    bool OptOutOfFriendsLeaderboards; // 0x1 Size: 0x1

};

struct FOnReadPrivacySettingsComplete__DelegateSignature
{
	public:
	    bool bSuccess; // 0x0 Size: 0x1
	    struct FMcpPrivacySettings Settings; // 0x1 Size: 0x2

};

struct FOnUpdatePrivacySettingsComplete__DelegateSignature
{
	public:
	    bool bSuccess; // 0x0 Size: 0x1

};



enum class EOfferPurchaseError : uint8_t
{
    NoError = 0,
    PendingServerConfirmation = 1,
    CannotAffordItem = 2,
    InvalidOfferID = 3,
    InvalidPriceIndex = 4,
    NoneLeft = 5,
    PurchaseAlreadyPending = 6,
    NoConnection = 7,
    AccountNotEligible = 8,
    CannotGiftItem = 9,
    MFANotEnabled = 10,
    EOfferPurchaseError_MAX = 11
};

enum class EFortAlteration : uint8_t
{
    AttributeSlot = 0,
    GameplaySlot = 1,
    ComplexCosmeticSlot = 2,
    UserPickedCosmeticSlot = 3,
    ColorSlot = 4,
    HeroSpecializationTier1Slot = 5,
    HeroSpecializationTier2Slot = 6,
    HeroSpecializationTier3Slot = 7,
    HeroSpecializationTier4Slot = 8,
    HeroSpecializationTier5Slot = 9,
    EFortAlteration_MAX = 10
};

enum class EPlayerBanReasons : uint8_t
{
    Teaming = 0,
    Afk_Leeching = 1,
    Harassment = 2,
    TradeScamming = 3,
    Exploiting = 4,
    EPlayerBanReasons_MAX = 5
};struct FFortCampaignLoadout
{
	public:
	    class UFortPersonalVehicleItem* PersonalVehicle; // 0x0 Size: 0x8

};

struct FFriendCode
{
	public:
	    struct FString Code; // 0x0 Size: 0x10
	    struct FString CodeType; // 0x10 Size: 0x10

};

struct FFortHomeBaseInfo
{
	public:
	    struct FString BannerIconId; // 0x0 Size: 0x10
	    struct FString BannerColorId; // 0x10 Size: 0x10
	    struct FText Name; // 0x20 Size: 0x18
	    bool ValidData; // 0x38 Size: 0x1
	    char UnknownData0[0x7];

};

struct FCosmeticVariantInfo
{
	public:
	    struct FGameplayTag VariantChannelTag; // 0x0 Size: 0x8
	    struct FGameplayTag ActiveVariantTag; // 0x8 Size: 0x8

};



enum class EFortItemType : uint8_t
{
    WorldItem = 0,
    Ammo = 1,
    Badge = 2,
    BackpackPickup = 3,
    BuildingPiece = 4,
    CharacterPart = 5,
    Consumable = 6,
    Deco = 7,
    EditTool = 8,
    Ingredient = 9,
    ItemCache = 10,
    Food = 11,
    Gadget = 12,
    AthenaGadget = 13,
    HomebaseGadget = 14,
    HeroAbility = 15,
    MissionItem = 16,
    Trap = 17,
    Weapon = 18,
    WeaponMelee = 19,
    WeaponRanged = 20,
    WeaponHarvest = 21,
    WorldResource = 22,
    AccountItem = 23,
    AccountResource = 24,
    CollectedResource = 25,
    Alteration = 26,
    CardPack = 27,
    CharacterCosmetic = 28,
    Currency = 29,
    Hero = 30,
    Schematic = 31,
    Worker = 32,
    Token = 33,
    DailyRewardScheduleToken = 34,
    CodeToken = 35,
    Stat = 36,
    Buff = 37,
    BuffCredit = 38,
    Quest = 39,
    ChallengeBundle = 40,
    ChallengeBundleSchedule = 41,
    GameplayModifier = 42,
    Outpost = 43,
    HomebaseNode = 44,
    Defender = 45,
    ConversionControl = 46,
    DeployableBaseCloudSave = 47,
    ConsumableAccountItem = 48,
    Quota = 49,
    Expedition = 50,
    HomebaseBannerIcon = 51,
    HomebaseBannerColor = 52,
    AthenaSkyDiveContrail = 53,
    PersonalVehicle = 54,
    AthenaGlider = 55,
    AthenaPickaxe = 56,
    AthenaHat = 57,
    AthenaBackpack = 58,
    AthenaCharacter = 59,
    AthenaDance = 60,
    AthenaConsumableEmote = 61,
    AthenaLoadingScreen = 62,
    AthenaBattleBus = 63,
    AthenaVehicleCosmetic = 64,
    AthenaItemWrap = 65,
    AthenaCallingCard = 66,
    AthenaMapMarker = 67,
    AthenaMusicPack = 68,
    AthenaPetCosmetic = 69,
    AthenaVictoryPose = 70,
    AthenaSeasonTreasure = 71,
    AthenaSeason = 72,
    EventDescription = 73,
    MatchAward = 74,
    AthenaEventToken = 75,
    EventPurchaseTracker = 76,
    CosmeticVariantToken = 77,
    Stamp = 78,
    CampaignHeroLoadout = 79,
    Playset = 80,
    PrerollData = 81,
    CreativePlot = 82,
    SpecialItem = 83,
    Emote = 84,
    Stack = 85,
    CollectionBookPage = 86,
    BGAConsumableWrapper = 87,
    GiftBox = 88,
    Profile = 89,
    Max_None = 90,
    EFortItemType_MAX = 91
};struct FFriendCodeLocString
{
	public:
	    struct FString Lang; // 0x0 Size: 0x10
	    struct FString Text; // 0x10 Size: 0x10

};



enum class EFortTeam : uint8_t
{
    HumanCampaign = 0,
    Monster = 1,
    HumanPvP_Team1 = 2,
    HumanPvP_Team2 = 3,
    HumanPvP_Team3 = 4,
    HumanPvP_Team4 = 5,
    HumanPvP_Team5 = 6,
    HumanPvP_Team6 = 7,
    HumanPvP_Team7 = 8,
    HumanPvP_Team8 = 9,
    HumanPvP_Team9 = 10,
    HumanPvP_Team10 = 11,
    HumanPvP_Team11 = 12,
    HumanPvP_Team12 = 13,
    HumanPvP_Team13 = 14,
    HumanPvP_Team14 = 15,
    HumanPvP_Team15 = 16,
    HumanPvP_Team16 = 17,
    HumanPvP_Team17 = 18,
    HumanPvP_Team18 = 19,
    HumanPvP_Team19 = 20,
    HumanPvP_Team20 = 21,
    HumanPvP_Team21 = 22,
    HumanPvP_Team22 = 23,
    HumanPvP_Team23 = 24,
    HumanPvP_Team24 = 25,
    HumanPvP_Team25 = 26,
    HumanPvP_Team26 = 27,
    HumanPvP_Team27 = 28,
    HumanPvP_Team28 = 29,
    HumanPvP_Team29 = 30,
    HumanPvP_Team30 = 31,
    HumanPvP_Team31 = 32,
    HumanPvP_Team32 = 33,
    HumanPvP_Team33 = 34,
    HumanPvP_Team34 = 35,
    HumanPvP_Team35 = 36,
    HumanPvP_Team36 = 37,
    HumanPvP_Team37 = 38,
    HumanPvP_Team38 = 39,
    HumanPvP_Team39 = 40,
    HumanPvP_Team40 = 41,
    HumanPvP_Team41 = 42,
    HumanPvP_Team42 = 43,
    HumanPvP_Team43 = 44,
    HumanPvP_Team44 = 45,
    HumanPvP_Team45 = 46,
    HumanPvP_Team46 = 47,
    HumanPvP_Team47 = 48,
    HumanPvP_Team48 = 49,
    HumanPvP_Team49 = 50,
    HumanPvP_Team50 = 51,
    HumanPvP_Team51 = 52,
    HumanPvP_Team52 = 53,
    HumanPvP_Team53 = 54,
    HumanPvP_Team54 = 55,
    HumanPvP_Team55 = 56,
    HumanPvP_Team56 = 57,
    HumanPvP_Team57 = 58,
    HumanPvP_Team58 = 59,
    HumanPvP_Team59 = 60,
    HumanPvP_Team60 = 61,
    HumanPvP_Team61 = 62,
    HumanPvP_Team62 = 63,
    HumanPvP_Team63 = 64,
    HumanPvP_Team64 = 65,
    HumanPvP_Team65 = 66,
    HumanPvP_Team66 = 67,
    HumanPvP_Team67 = 68,
    HumanPvP_Team68 = 69,
    HumanPvP_Team69 = 70,
    HumanPvP_Team70 = 71,
    HumanPvP_Team71 = 72,
    HumanPvP_Team72 = 73,
    HumanPvP_Team73 = 74,
    HumanPvP_Team74 = 75,
    HumanPvP_Team75 = 76,
    HumanPvP_Team76 = 77,
    HumanPvP_Team77 = 78,
    HumanPvP_Team78 = 79,
    HumanPvP_Team79 = 80,
    HumanPvP_Team80 = 81,
    HumanPvP_Team81 = 82,
    HumanPvP_Team82 = 83,
    HumanPvP_Team83 = 84,
    HumanPvP_Team84 = 85,
    HumanPvP_Team85 = 86,
    HumanPvP_Team86 = 87,
    HumanPvP_Team87 = 88,
    HumanPvP_Team88 = 89,
    HumanPvP_Team89 = 90,
    HumanPvP_Team90 = 91,
    HumanPvP_Team91 = 92,
    HumanPvP_Team92 = 93,
    HumanPvP_Team93 = 94,
    HumanPvP_Team94 = 95,
    HumanPvP_Team95 = 96,
    HumanPvP_Team96 = 97,
    HumanPvP_Team97 = 98,
    HumanPvP_Team98 = 99,
    HumanPvP_Team99 = 100,
    HumanPvP_Team100 = 101,
    HumanPvP_Team101 = 102,
    Spectator = 103,
    MAX = 104
};struct FFortUINotificationClearedDelegate__DelegateSignature
{
	public:
	    class UFortUINotification* ClearedNotification; // 0x0 Size: 0x8

};

struct FOnMapFullyExplored__DelegateSignature
{
	public:
	    char Team; // 0x0 Size: 0x1

};

struct FOnMapExplorationThresholdReached__DelegateSignature
{
	public:
	    int ThresholdIndex; // 0x0 Size: 0x4
	    char Team; // 0x4 Size: 0x1
	    char UnknownData0[0x3];

};

struct FOnOccupantIdChanged__DelegateSignature
{
	public:
	    class ADeployableBasePlot* Plot; // 0x0 Size: 0x8

};

struct FOnDeployableBaseCoreCreated__DelegateSignature
{
	public:
	    class ADeployableBasePlot* Plot; // 0x0 Size: 0x8
	    class ADeployableBaseCore* Core; // 0x8 Size: 0x8

};

struct FOnDeployableBaseCoreDestroyed__DelegateSignature
{
	public:
	    class ADeployableBasePlot* Plot; // 0x0 Size: 0x8
	    class ADeployableBaseCore* Core; // 0x8 Size: 0x8

};

struct FOnDeployableBasePlotSpacesChanged__DelegateSignature
{
	public:

};

struct FOnVisibilityChanged__DelegateSignature
{
	public:
	    class AActor* Actor; // 0x0 Size: 0x8
	    char TeamObserving; // 0x8 Size: 0x1
	    bool bVisible; // 0x9 Size: 0x1
	    char UnknownData0[0x6];

};

struct FOnQuestsUpdated__DelegateSignature
{
	public:

};

struct FOnQuestSeen__DelegateSignature
{
	public:
	    class UFortQuestItem* Quest; // 0x0 Size: 0x8

};

struct FOnDailyQuestRerolled__DelegateSignature
{
	public:
	    class UFortQuestItem* NewQuest; // 0x0 Size: 0x8

};

struct FOnPinnedQuestsUpdated__DelegateSignature
{
	public:

};

struct FOnDisplayDynamicQuestUpdate__DelegateSignature
{
	public:
	    class UFortQuestObjectiveInfo* QuestObjective; // 0x0 Size: 0x8
	    bool bDisplayStatusUpdate; // 0x8 Size: 0x1
	    bool bDisplayAnnouncementUpdate; // 0x9 Size: 0x1
	    char UnknownData0[0x6];

};



enum class EAthenaTravelLogPlayerType : uint8_t
{
    Self = 0,
    Ally = 1,
    Enemy = 2,
    Invalid = 3,
    EAthenaTravelLogPlayerType_MAX = 4
};

enum class EAthenaTravelEventType : uint8_t
{
    GroundMove = 0,
    AirMove = 1,
    BattleBusJump = 2,
    LaunchJump = 3,
    Landed = 4,
    OpenChest = 5,
    OpenAmmo = 6,
    GotAssist = 7,
    GotKnockdown = 8,
    GotKill = 9,
    PlayerDowned = 10,
    PlayerDied = 11,
    Won = 12,
    DealtDamage = 13,
    Healed = 14,
    Count = 15,
    EAthenaTravelEventType_MAX = 16
};struct FAthenaTravelLogEntry
{
	public:
	    float Time; // 0x0 Size: 0x4
	    struct FVector Position; // 0x4 Size: 0xc
	    EAthenaTravelEventType Type; // 0x10 Size: 0x1
	    char UnknownData0[0x3]; // 0x11
	    FName InstigatorName; // 0x14 Size: 0x8
	    EAthenaTravelLogPlayerType InstigatorPlayerType; // 0x1c Size: 0x1
	    char UnknownData1[0x3]; // 0x1d
	    FName ReceiverName; // 0x20 Size: 0x8
	    EAthenaTravelLogPlayerType ReceiverPlayerType; // 0x28 Size: 0x1
	    char UnknownData2[0x3]; // 0x29
	    float Value; // 0x2c Size: 0x4

};

struct FOnTravelLogUpdated__DelegateSignature
{
	public:
	    struct FAthenaTravelLogEntry NewEntry; // 0x0 Size: 0x30

};

struct FAthenaMatchLootReward
{
	public:
	    struct FString TemplateId; // 0x0 Size: 0x10
	    int Amount; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FAthenaMatchXpReward
{
	public:
	    struct FText Text; // 0x0 Size: 0x18
	    int Amount; // 0x18 Size: 0x4
	    char UnknownData0[0x4];

};



enum class ERewardSource : uint8_t
{
    Invalid = 0,
    MinutesPlayed = 1,
    FirstKill = 2,
    TeamKills = 3,
    FirstRevive = 4,
    AdditionalRevives = 5,
    Placement = 6,
    Medals = 7,
    FirstWin = 8,
    SeasonLevelUp = 9,
    BookLevelUp = 10,
    MAX_COUNT = 11,
    ERewardSource_MAX = 12
};

enum class EAthenaMatchXpMultiplierSource : uint8_t
{
    Invalid = 0,
    BattlePassSelf = 1,
    BattlePassFriends = 2,
    CosmeticSet = 3,
    AntiAddictionPenalty = 4,
    BonusXpEvent = 5,
    MAX_COUNT = 6,
    EAthenaMatchXpMultiplierSource_MAX = 7
};struct FAthenaMatchXpMultiplierGroup
{
	public:
	    EAthenaMatchXpMultiplierSource Source; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    int Amount; // 0x4 Size: 0x4

};

struct FAthenaMatchTeamStats
{
	public:
	    int Place; // 0x0 Size: 0x4
	    int TotalPlayers; // 0x4 Size: 0x4

};

struct FAthenaWeaponStats
{
	public:
	    struct FString WeaponId; // 0x0 Size: 0x10
	    int Stats; // 0x10 Size: 0x4
	    char UnknownData0[0x34];

};

struct FFortQuestObjectiveCompletion
{
	public:
	    struct FString StatName; // 0x0 Size: 0x10
	    int Count; // 0x10 Size: 0x4
	    char UnknownData0[0x14];

};

struct FAccountIdAndScore
{
	public:
	    struct FString AccountId; // 0x0 Size: 0x10
	    int TotalScore; // 0x10 Size: 0x4
	    bool bCriticalMatchBonus; // 0x14 Size: 0x1
	    char UnknownData0[0x3];

};

struct FFortCloudSaveRecordInfo
{
	public:
	    int RecordIndex; // 0x0 Size: 0x4
	    int ArchiveNumber; // 0x4 Size: 0x4
	    struct FString RecordFilename; // 0x8 Size: 0x10

};

struct FFortPlacedBuilding
{
	public:
	    struct FString BuildingTag; // 0x0 Size: 0x10
	    struct FString PlacedTag; // 0x10 Size: 0x10

};

struct FFortQuestEarnedBadgeData
{
	public:
	    struct FString TemplateId; // 0x0 Size: 0x10
	    int Count; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};



enum class ECampaignCustomizationCategory : uint8_t
{
    None = 0,
    PersonalVehicle = 1,
    ECampaignCustomizationCategory_MAX = 2
};struct FFortPersistentGameplayStatValue
{
	public:
	    struct FString StatName; // 0x0 Size: 0x10
	    int StatValue; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FVolumePerformanceMetrics
{
	public:
	    int PerformanceValue; // 0x0 Size: 0x4
	    int PerformanceMaxValue; // 0x4 Size: 0x4
	    int PreviewDeltaValue; // 0x8 Size: 0x4

};

struct FOnVolumePerformanceMetricsUpdated__DelegateSignature
{
	public:
	    struct FVolumePerformanceMetrics VolumePerformanceMetrics; // 0x0 Size: 0xc

};

struct FOnActorEnterExitVolume__DelegateSignature
{
	public:
	    class AActor* Actor; // 0x0 Size: 0x8
	    class AFortVolume* Volume; // 0x8 Size: 0x8

};



enum class EVolumeState : uint8_t
{
    Uninitialized = 0,
    ReadOnly = 1,
    Initializing = 2,
    Ready = 3,
    EVolumeState_MAX = 4
};struct FOnVolumeStateChanged__DelegateSignature
{
	public:
	    EVolumeState NewState; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class AFortVolume* Volume; // 0x8 Size: 0x8

};

struct FOnAttributeSourcesReceived__DelegateSignature
{
	public:
	    struct FGameplayAttribute Attribute; // 0x0 Size: 0x20

};

struct FOnNotifyInputFiltered__DelegateSignature
{
	public:
	    ECommonInputType AttemptedInputType; // 0x0 Size: 0x1

};

struct FOnPlayerPawnPossessed__DelegateSignature
{
	public:
	    class APawn* PossessedPawn; // 0x0 Size: 0x8

};

struct FOnChosenSignature__DelegateSignature
{
	public:
	    int ChosenIndex; // 0x0 Size: 0x4
	    int MenuIdentifier; // 0x4 Size: 0x4

};

struct FOnReadyCheckCompleteBP__DelegateSignature
{
	public:
	    bool Result; // 0x0 Size: 0x1

};

struct FOnRegainedFocus__DelegateSignature
{
	public:

};

struct FOnSetFirstPersonCamera__DelegateSignature
{
	public:
	    bool bFirstPersonCameraEnabled; // 0x0 Size: 0x1

};

struct FOnToggleFullscreenMap__DelegateSignature
{
	public:
	    bool bFullscreenMapVisible; // 0x0 Size: 0x1

};

struct FOnMcpProfilesInitialized__DelegateSignature
{
	public:

};

struct FOnInputActionHoldStarted__DelegateSignature
{
	public:
	    FName InputActionName; // 0x0 Size: 0x8
	    float Duration; // 0x8 Size: 0x4

};

struct FOnInputActionHoldStopped__DelegateSignature
{
	public:
	    FName InputActionName; // 0x0 Size: 0x8
	    bool bCompletedSuccessfully; // 0x8 Size: 0x1
	    char UnknownData0[0x3];

};

struct FOnPlayerEnteredBuildMode__DelegateSignature
{
	public:
	    bool bEnteredBuildMode; // 0x0 Size: 0x1

};

struct FOnAutoRunEnabled__DelegateSignature
{
	public:
	    bool bAutoRunEnabled; // 0x0 Size: 0x1

};

struct FOnEnterVehicleDriver__DelegateSignature
{
	public:

};

struct FOnEnterVehiclePassenger__DelegateSignature
{
	public:

};

struct FOnExitVehicle__DelegateSignature
{
	public:

};

struct FOnOpenVoteDialog__DelegateSignature
{
	public:

};

struct FOnDBNOStateChangedEvent__DelegateSignature
{
	public:
	    bool bIsDBNO; // 0x0 Size: 0x1

};

struct FOnFootstepEvent__DelegateSignature
{
	public:

};

struct FOnInteractionFailedCallback__DelegateSignature
{
	public:
	    class AFortPlayerPawnAthena* FortPlayerPawnAthena; // 0x0 Size: 0x8

};

struct FOnFortPlayerDied__DelegateSignature
{
	public:
	    class AFortPlayerPawnAthena* FortPlayerPawnAthena; // 0x0 Size: 0x8

};

struct FOnPlayerStartDBNO__DelegateSignature
{
	public:

};

struct FOnLocalAmmoChanged__DelegateSignature
{
	public:
	    int LocalCount; // 0x0 Size: 0x4
	    int LocalRemaining; // 0x4 Size: 0x4

};

struct FOnRateOfFireChanged__DelegateSignature
{
	public:
	    float NewRateOfFire; // 0x0 Size: 0x4

};

struct FOnReticleColorChanged__DelegateSignature
{
	public:

};

struct FVehicleHealthChanged__DelegateSignature
{
	public:

};

struct FOnSurfaceTypeVehicleIsOnChanged__DelegateSignature
{
	public:
	    char SurfaceTypeVehicleIsOn; // 0x0 Size: 0x1

};

struct FActivationStateChange__DelegateSignature
{
	public:

};

struct FOnMountedTurretFired__DelegateSignature
{
	public:
	    int ShotsRemaining; // 0x0 Size: 0x4

};

struct FFortAllClientsReady__DelegateSignature
{
	public:

};

struct FAnnouncementConversationDelegate__DelegateSignature
{
	public:

};



enum class EAthenaScoringEvent : uint8_t
{
    None = 0,
    Elimination = 1,
    ChestOpened = 2,
    AmmoCanOpened = 3,
    SupplyDropOpened = 4,
    SupplyLlamaOpened = 5,
    ForagedItemConsumed = 6,
    SurvivalInMinutes = 7,
    CollectedCoinBronze = 8,
    CollectedCoinSilver = 9,
    CollectedCoinGold = 10,
    AIKilled = 11,
    EAthenaScoringEvent_MAX = 12
};struct FOnPointsAddedToScore__DelegateSignature
{
	public:
	    int NewPoints; // 0x0 Size: 0x4
	    EAthenaScoringEvent ScoreType; // 0x4 Size: 0x1
	    char UnknownData0[0x3];

};

struct FOnTeamScoreChanged__DelegateSignature
{
	public:
	    int NewScore; // 0x0 Size: 0x4

};

struct FOnTeamPlacementChanged__DelegateSignature
{
	public:
	    int NewPlacement; // 0x0 Size: 0x4

};

struct FOnPlaceChanged__DelegateSignature
{
	public:
	    int NewPlace; // 0x0 Size: 0x4

};

struct FOnTeamAverageDamageChanged__DelegateSignature
{
	public:
	    float NewAverageDamage; // 0x0 Size: 0x4

};

struct FOnStormShieldCreated__DelegateSignature
{
	public:
	    class AFortMissionStormShield* Shield; // 0x0 Size: 0x8

};

struct FOnNumSurvivorsRescuedChanged__DelegateSignature
{
	public:
	    int NumSurvivorsRescued; // 0x0 Size: 0x4

};

struct FOnScoreTotalsChanged__DelegateSignature
{
	public:

};



enum class EFortVoteStatus : uint8_t
{
    Begin = 0,
    Update = 1,
    End = 2,
    BeginLockout = 3,
    EndLockout = 4,
    EFortVoteStatus_MAX = 5
};

enum class EFortVoteType : uint8_t
{
    SurvivalVote = 0,
    DifficultyIncrease = 1,
    MissionActivation = 2,
    ContinueOrExtract = 3,
    EFortVoteType_MAX = 4
};struct FOnHandleMatchLevelChanged__DelegateSignature
{
	public:
	    int MatchLevel; // 0x0 Size: 0x4

};

struct FOnFinalizationFOBTimerExpired__DelegateSignature
{
	public:

};

struct FOnGhostModeChanged__DelegateSignature
{
	public:
	    bool bEnteredGhostMode; // 0x0 Size: 0x1

};

struct FOnBalloonMovementChanged__DelegateSignature
{
	public:
	    bool bUsingBalloonMovement; // 0x0 Size: 0x1

};

struct FOnWorldInventoryChanged__DelegateSignature
{
	public:
	    bool bIsAllowedToFly; // 0x0 Size: 0x1

};

struct FOnCreativeFlyChanged__DelegateSignature
{
	public:
	    bool bFlying; // 0x0 Size: 0x1

};

struct FOnSkyDivingStateChange__DelegateSignature
{
	public:

};

struct FOnVehicleSeatTransitionTargetIndexChange__DelegateSignature
{
	public:
	    int SeatIndex; // 0x0 Size: 0x4

};



enum class EFortQuickBars : uint8_t
{
    Primary = 0,
    Secondary = 1,
    Max_None = 2,
    EFortQuickBars_MAX = 3
};

enum class EAthenaCustomizationCategory : uint8_t
{
    None = 0,
    Glider = 1,
    Pickaxe = 2,
    Hat = 3,
    Backpack = 4,
    Character = 5,
    LoadingScreen = 6,
    BattleBus = 7,
    VehicleDecoration = 8,
    CallingCard = 9,
    MapMarker = 10,
    Dance = 11,
    ConsumableEmote = 12,
    VictoryPose = 13,
    SkyDiveContrail = 14,
    MusicPack = 15,
    ItemWrap = 16,
    PetSkin = 17,
    MAX = 18
};

enum class EStatCategory : uint8_t
{
    Combat = 0,
    Building = 1,
    Utility = 2,
    Max_None = 3,
    EStatCategory_MAX = 4
};struct FChoiceDataEntry
{
	public:
	    struct FText ButtonText; // 0x0 Size: 0x18
	    struct FText ButtonDescription; // 0x18 Size: 0x18
	    struct FText ConfirmText; // 0x30 Size: 0x18
	    bool bEnabled; // 0x48 Size: 0x1
	    bool bRequireConfirmation; // 0x49 Size: 0x1
	    bool bCloseAfterSelection; // 0x4a Size: 0x1
	    char UnknownData0[0x5];

};

struct FAttributeModifierInfo
{
	public:
	    class UGameplayEffect* InstantGEs; // 0x8 Size: 0x8
	    char UnknownData0[0x10];

};



enum class EFortResourceType : uint8_t
{
    Wood = 0,
    Stone = 1,
    Metal = 2,
    Permanite = 3,
    None = 4,
    EFortResourceType_MAX = 5
};struct FBuildingWeakSpotData
{
	public:
	    TWeakObjectPtr<ABuildingSMActor*> ParentBuilding; // 0x0 Size: 0x8
	    struct FVector_NetQuantizeNormal Normal; // 0x8 Size: 0xc
	    struct FVector_NetQuantize10 Position; // 0x14 Size: 0xc
	    char UnknownData0[0x18];

};



enum class ERichPresenceStateChange : uint8_t
{
    AutoUpdate = 0,
    Idle = 1,
    Active = 2,
    Busy = 3,
    NotBusy = 4,
    ERichPresenceStateChange_MAX = 5
};

enum class ESubGame : uint8_t
{
    Campaign = 0,
    Athena = 1,
    Invalid = 2,
    Count = 2,
    ESubGame_MAX = 3
};

enum class ELockOnState : uint8_t
{
    NoTarget = 0,
    TargetAcquired = 1,
    LockingOnToTarget = 2,
    TargetLockedOn = 3,
    Cooldown = 4,
    COUNT = 5,
    ELockOnState_MAX = 6
};struct FFortRequirementsInfo
{
	public:
	    int CommanderLevel; // 0x0 Size: 0x4
	    int PersonalPowerRating; // 0x4 Size: 0x4
	    int MaxPersonalPowerRating; // 0x8 Size: 0x4
	    int PartyPowerRating; // 0xc Size: 0x4
	    int MaxPartyPowerRating; // 0x10 Size: 0x4
	    char UnknownData0[0x4]; // 0x14
	    class UFortQuestItemDefinition* ActiveQuestDefinition; // 0x18 Size: 0x8
	    class UFortQuestItemDefinition* QuestDefinition; // 0x20 Size: 0x8
	    struct FDataTableRowHandle ObjectiveStatHandle; // 0x28 Size: 0x10
	    class UFortQuestItemDefinition* UncompletedQuestDefinition; // 0x38 Size: 0x8
	    class UFortItemDefinition* ItemDefinition; // 0x40 Size: 0x8
	    struct FString EventFlag; // 0x48 Size: 0x10

};



enum class EStatMod : uint8_t
{
    Delta = 0,
    Set = 1,
    Maximum = 2,
    EStatMod_MAX = 3
};

enum class EFortDamageZone : uint8_t
{
    Light = 0,
    Normal = 1,
    Critical = 2,
    Vulnerability = 3,
    Max = 4
};

enum class TInteractionType : uint8_t
{
    IT_NoInteraction = 0,
    IT_Simple = 1,
    IT_LongPress = 2,
    IT_BuildingEdit = 3,
    IT_BuildingImprovement = 4,
    IT_TrapPlacement = 5,
    IT_MAX = 6
};

enum class EFortItemTier : uint8_t
{
    No_Tier = 0,
    I = 1,
    II = 2,
    III = 3,
    IV = 4,
    V = 5,
    VI = 6,
    VII = 7,
    VIII = 8,
    IX = 9,
    X = 10,
    NumItemTierValues = 11,
    EFortItemTier_MAX = 12
};struct FBuildingClassData
{
	public:
	    class ABuildingActor* BuildingClass; // 0x0 Size: 0x8
	    int PreviousBuildingLevel; // 0x8 Size: 0x4
	    int UpgradeLevel; // 0xc Size: 0x4

};



enum class EFortItemEntryState : uint8_t
{
    NoneState = 0,
    NewItemCount = 1,
    ShouldShowItemToast = 2,
    DurabilityInitialized = 3,
    DoNotShowSpawnParticles = 4,
    FromRecoveredBackpack = 5,
    FromGift = 6,
    PendingUpgradeCriteriaProgress = 7,
    OwnerBuildingHandle = 8,
    FromDroppedPickup = 9,
    JustCrafted = 10,
    CraftAndSlotTarget = 11,
    GenericAttributeValueSet = 12,
    EFortItemEntryState_MAX = 13
};

enum class EFortRequestedGameplayAction : uint8_t
{
    ContinuePlaying = 0,
    StartPlaying = 1,
    StopPlaying = 2,
    EnterZone = 3,
    LeaveZone = 4,
    ReturnToMainMenu = 5,
    QuitGame = 6,
    Invalid = 7,
    EFortRequestedGameplayAction_MAX = 8
};struct FFortItemEntryStateValue
{
	public:
	    int IntValue; // 0x0 Size: 0x4
	    FName NameValue; // 0x4 Size: 0x8
	    char StateType; // 0xc Size: 0x1
	    char UnknownData0[0x3];

};



enum class EFortGameplayState : uint8_t
{
    NormalGameplay = 0,
    WaitingToStart = 1,
    EndOfZone = 2,
    EnteringZone = 3,
    LeavingZone = 4,
    Invalid = 5,
    EFortGameplayState_MAX = 6
};

enum class EFortCombatEvents : uint8_t
{
    HuskFollowing = 0,
    SmasherFollowing = 1,
    TrollFollowing = 2,
    FlingerFollowing = 3,
    TakerFollowing = 4,
    HuskCombatNearby = 5,
    SmasherCombatNearby = 6,
    TrollCombatNearby = 7,
    FlingerCombatNearby = 8,
    TakerCombatNearby = 9,
    PlayerTakeDamage = 10,
    PlayerHealth = 11,
    PlayerLookAtEnemy = 12,
    PlayerDamageEnemy = 13,
    PlayerKilledEnemy = 14,
    AtlasTakeDamage = 15,
    AtlasHealth = 16,
    AtlasDestroyed = 17,
    TrapFiring = 18,
    BuildingTakeDamage = 19,
    FoodHealingPotential = 20,
    PlayerAmmo = 21,
    EnemiesNear = 22,
    PlayerMovement = 23,
    BuildingDamagedNearObjective = 24,
    TrapDamageEnemy = 25,
    ObjectivePathCost = 26,
    PlayerPathCost = 27,
    Max_None = 28,
    EFortCombatEvents_MAX = 29
};struct FFortCombatManagerEvent
{
	public:
	    float EventValue; // 0x0 Size: 0x4
	    char Event; // 0x4 Size: 0x1
	    char UnknownData0[0x3];

};



enum class EBuildingHighlightType : uint8_t
{
    Primary = 0,
    Interact = 1,
    WillBeDestroyed = 2,
    Quest = 3,
    MAX_None = 4,
    EBuildingHighlightType_MAX = 5
};struct FLockOnInfo
{
	public:
	    ELockOnState State; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    TWeakObjectPtr<AFortWeapon*> Weapon; // 0x4 Size: 0x8
	    TWeakObjectPtr<AActor*> LockOnTarget; // 0xc Size: 0x8
	    struct FRotator CamRotAtTargetAcquisiton; // 0x14 Size: 0xc
	    struct FVector2D LockOnCoords; // 0x20 Size: 0x8
	    float TargetAcquisitionTime; // 0x28 Size: 0x4
	    float TargetLockOnTime; // 0x2c Size: 0x4
	    float TargetOutOfSightTime; // 0x30 Size: 0x4
	    float CooldownStartTime; // 0x34 Size: 0x4

};



enum class EFortJumpStaminaCost : uint8_t
{
    None = 0,
    Trigger = 1,
    SprintTrigger = 2,
    SprintAir = 3,
    EFortJumpStaminaCost_MAX = 4
};

enum class EFortPCTutorialCompletedState : uint8_t
{
    Unknown = 0,
    Incomplete = 1,
    Complete = 2,
    EFortPCTutorialCompletedState_MAX = 3
};struct FFortUpdatedObjectiveStat
{
	public:
	    class UFortQuestItemDefinition* Quest; // 0x0 Size: 0x8
	    FName BackendName; // 0x8 Size: 0x8
	    int StatValue; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};



enum class EFortCompletionResult : uint8_t
{
    Win = 0,
    Loss = 1,
    Draw = 2,
    Undefined = 3,
    EFortCompletionResult_MAX = 4
};struct FFortGiftingInfo
{
	public:
	    struct FString PlayerName; // 0x0 Size: 0x10
	    class UFortHeroType* HeroType; // 0x10 Size: 0x8
	    char UnknownData0[0x10];

};



enum class EFortRewardActivityType : uint8_t
{
    General = 0,
    MissionPrimary = 1,
    MissionSecondary = 2,
    AccountLevelUp = 3,
    Max_None = 4,
    EFortRewardActivityType_MAX = 5
};

enum class EFortElementalDamageType : uint8_t
{
    None = 0,
    Fire = 1,
    Ice = 2,
    Lightning = 3,
    Energy = 4,
    MAX = 5
};

enum class EFortDamageNumberType : uint8_t
{
    None = 0,
    Pawn = 1,
    Building = 2,
    Player = 3,
    Shield = 4,
    Score = 5,
    DBNO = 6,
    EFortDamageNumberType_MAX = 7
};struct FLastBuildableState
{
	public:
	    class UBuildingEditModeMetadata* LastBuildableMetaData; // 0x0 Size: 0x8
	    bool LastBuildableMirrored; // 0x8 Size: 0x1
	    char UnknownData0[0x3]; // 0x9
	    int LastBuildableRotationIterations; // 0xc Size: 0x4

};



enum class EFortResourceLevel : uint8_t
{
    First = 0,
    Second = 1,
    Third = 2,
    Fourth = 3,
    Fifth = 4,
    Sixth = 5,
    NumLevels = 6,
    Invalid = 7,
    EFortResourceLevel_MAX = 8
};

enum class EFortCostInfoTypes : uint8_t
{
    Placement = 0,
    Repair = 1,
    Conversion = 2,
    Ability = 3,
    None = 4,
    EFortCostInfoTypes_MAX = 5
};

enum class EFortBuildPreviewMarkerOptionalAdjustment : uint8_t
{
    None = 0,
    FreeWallPieceOnTop = 1,
    FreeWallPieceOnBottom = 2,
    EFortBuildPreviewMarkerOptionalAdjustment_MAX = 3
};struct FVehicleTrickInfo
{
	public:
	    float LastOnGroundTime; // 0x0 Size: 0x4
	    bool bInAirTrick; // 0x4 Size: 0x1
	    bool bCreditTrick; // 0x5 Size: 0x1
	    bool bTrickDeactivated; // 0x6 Size: 0x1
	    bool bStuckLanding; // 0x7 Size: 0x1
	    int TrickScore; // 0x8 Size: 0x4
	    char UnknownData0[0x90]; // 0xc
	    int TrickAxisCount; // 0x9c Size: 0x4
	    bool bDoingRotationTrick; // 0xb8 Size: 0x1
	    char UnknownData1[0x1b]; // 0xa1
	    float AirControlsAlpha; // 0xbc Size: 0x4
	    float AirDistance; // 0xc0 Size: 0x4
	    float AirDistanceSqrd; // 0xc4 Size: 0x4
	    float AirTime; // 0xc8 Size: 0x4
	    float AirHeight; // 0xcc Size: 0x4
	    float TimeAtLaunch; // 0xd0 Size: 0x4
	    struct FVector LocationAtLaunch; // 0xd4 Size: 0xc
	    struct FVector ForwardVectorAtLaunch; // 0xe0 Size: 0xc
	    struct FVector UpVectorAtLaunch; // 0xec Size: 0xc
	    struct FVector FlatForwardVectorAtLaunch; // 0xf8 Size: 0xc
	    struct FVector PrevForwardVec; // 0x104 Size: 0xc
	    struct FVector PrevRightVec; // 0x110 Size: 0xc
	    struct FVector PrevUpVec; // 0x11c Size: 0xc
	    int PeterPanCount; // 0x128 Size: 0x4
	    int StoopingSquirrelCount; // 0x12c Size: 0x4
	    bool bDidPeterPan; // 0x130 Size: 0x1
	    bool bDidStoopingSquirrel; // 0x130 Size: 0x1
	    char UnknownData2[0x16];

};

struct FGhostModeRepData
{
	public:
	    bool bInGhostMode; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class UFortWorldItemDefinition* GhostModeItemDef; // 0x8 Size: 0x8
	    int PreviousFocusedSlot; // 0x10 Size: 0x4
	    float TimeExitedGhostMode; // 0x14 Size: 0x4

};



enum class EFortIsFinalXpUpdate : uint8_t
{
    Uninitialized = 0,
    NotFinal = 1,
    Final = 2,
    EFortIsFinalXpUpdate_MAX = 3
};struct FFortExperienceDelta
{
	public:
	    int Level; // 0x0 Size: 0x4
	    int Xp; // 0x4 Size: 0x4
	    int BaseXPEarned; // 0x8 Size: 0x4
	    int BonusXPEarned; // 0xc Size: 0x4
	    int BoostXPEarned; // 0x10 Size: 0x4
	    int BoostXPMissed; // 0x14 Size: 0x4
	    int RestXPEarned; // 0x18 Size: 0x4
	    int GroupBoostXPEarned; // 0x1c Size: 0x4
	    EFortIsFinalXpUpdate IsFinalXpUpdate; // 0x20 Size: 0x1
	    char UnknownData0[0x3];

};

struct FReplicatedStatValues
{
	public:
	    int StatValue; // 0x0 Size: 0x4
	    int ScoreValue; // 0x4 Size: 0x4

};



enum class EFortVoteArbitratorType : uint8_t
{
    Invalid = 0,
    Majority = 1,
    Unanimous = 2,
    EFortVoteArbitratorType_MAX = 3
};struct FFortVoteConfig
{
	public:
	    int NumVoteOptions; // 0x0 Size: 0x4
	    float VoteDuration; // 0x4 Size: 0x4
	    float FailedVoteLockOutDuration; // 0x8 Size: 0x4
	    int MaxVotesAllowedPerPlayer; // 0xc Size: 0x4
	    EFortVoteArbitratorType VoteArbitratorType; // 0x10 Size: 0x1
	    char UnknownData0[0x3];

};



enum class EAthenaGamePhase : uint8_t
{
    None = 0,
    Setup = 1,
    Warmup = 2,
    Aircraft = 3,
    SafeZones = 4,
    EndGame = 5,
    Count = 6,
    EAthenaGamePhase_MAX = 7
};struct FOnGamePhaseChanged__DelegateSignature
{
	public:
	    EAthenaGamePhase GamePhase; // 0x0 Size: 0x1

};



enum class EAthenaGamePhaseStep : uint8_t
{
    None = 0,
    Setup = 1,
    Warmup = 2,
    GetReady = 3,
    BusLocked = 4,
    BusFlying = 5,
    StormForming = 6,
    StormHolding = 7,
    StormShrinking = 8,
    Countdown = 9,
    FinalCountdown = 10,
    EndGame = 11,
    Count = 12,
    EAthenaGamePhaseStep_MAX = 13
};struct FOnGamePhaseStepChanged__DelegateSignature
{
	public:
	    EAthenaGamePhaseStep GamePhaseStep; // 0x0 Size: 0x1

};



enum class EAthenaStormCapState : uint8_t
{
    None = 0,
    Clear = 1,
    Warning = 2,
    Damaging = 3,
    EAthenaStormCapState_MAX = 4
};struct FOnStormCapStateChanged__DelegateSignature
{
	public:
	    EAthenaStormCapState StormCapState; // 0x0 Size: 0x1

};

struct FOnKillFeedUpdated__DelegateSignature
{
	public:

};

struct FOnAllWinnersAnnounced__DelegateSignature
{
	public:

};

struct FOnWinnerAnnounced__DelegateSignature
{
	public:
	    struct FString WinnerPlayerName; // 0x0 Size: 0x10

};

struct FOnWinningTeamAnnounced__DelegateSignature
{
	public:
	    int WinningTeam; // 0x0 Size: 0x4

};

struct FOnWinningScoreAnnounced__DelegateSignature
{
	public:
	    int WinningScore; // 0x0 Size: 0x4

};

struct FOnPlayersLeftChanged__DelegateSignature
{
	public:
	    int NumPlayersLeft; // 0x0 Size: 0x4

};

struct FOnTeamsLeftChanged__DelegateSignature
{
	public:
	    int NumTeamsLeft; // 0x0 Size: 0x4

};

struct FOnStormProgressStopped__DelegateSignature
{
	public:
	    bool StormStopped; // 0x0 Size: 0x1

};

struct FOnFinalCountdownTick__DelegateSignature
{
	public:
	    int SecondsRemaining; // 0x0 Size: 0x4

};

struct FOnFinalCountdownStarted__DelegateSignature
{
	public:
	    int SecondsRemaining; // 0x0 Size: 0x4

};

struct FOnFinalCountdownFinished__DelegateSignature
{
	public:

};

struct FOnCountdownTick__DelegateSignature
{
	public:
	    int SecondsRemaining; // 0x0 Size: 0x4

};

struct FOnCountdownStarted__DelegateSignature
{
	public:
	    int SecondsRemaining; // 0x0 Size: 0x4

};

struct FOnCountdownFinished__DelegateSignature
{
	public:

};

struct FOnCurrentHighScoreUpdated__DelegateSignature
{
	public:

};



enum class EAthenaGameMsgType : uint8_t
{
    None = 0,
    DefaultIntro = 1,
    DefaultMessage = 2,
    DefaultCriticalMessage = 3,
    CommIntro = 4,
    CommMessage = 5,
    CommCriticalMessage = 6,
    CornerIntro = 7,
    CornerMessage = 8,
    CornerCriticalMessage = 9,
    RespawnTurningOffWarning = 10,
    RespawnOffWarning = 11,
    EAthenaGameMsgType_MAX = 12
};struct FAthenaGameMessageData
{
	public:
	    EAthenaGameMsgType MsgType; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FText MsgText; // 0x8 Size: 0x18
	    class USoundCue* MsgSound; // 0x20 Size: 0x8
	    float MsgDelay; // 0x28 Size: 0x4
	    bool bIsTeamBased; // 0x2c Size: 0x1
	    char UnknownData1[0x3]; // 0x2d
	    int TeamIndex; // 0x30 Size: 0x4
	    float DisplayTime; // 0x34 Size: 0x4

};

struct FOnGameModeMessageRequest__DelegateSignature
{
	public:
	    struct FAthenaGameMessageData MsgData; // 0x0 Size: 0x38

};

struct FOnMutatorGenericIntegerUpdated__DelegateSignature
{
	public:
	    int GenericIntegerIndex; // 0x0 Size: 0x4
	    int NewIntegerValue; // 0x4 Size: 0x4

};

struct FOnMutatorGameplayEvent__DelegateSignature
{
	public:
	    int EventId; // 0x0 Size: 0x4
	    int EventParam1; // 0x4 Size: 0x4
	    int EventParam2; // 0x8 Size: 0x4
	    int EventParam3; // 0xc Size: 0x4

};

struct FOnPlayerJoinedLeftCreativeIsland__DelegateSignature
{
	public:

};

struct FOnClientVolumeManagerReplicated__DelegateSignature
{
	public:

};

struct FTeamChangeRequest
{
	public:
	    class AFortPlayerController* RequestingController; // 0x0 Size: 0x8
	    char DesiredTeam; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FOnTimeHitInfo
{
	public:
	    __int64/*DelegateProperty*/ TimeCallback; // 0x0 Size: 0x10
	    char UnknownData0[0x20];

};



enum class EWaveRules : uint8_t
{
    KillAllEnemies = 0,
    Timed = 1,
    KillPoints = 2,
    EWaveRules_MAX = 3
};struct FTieredWaveSetData
{
	public:
	    int EDOIdx; // 0x0 Size: 0x4
	    float BreatherBetweenWaves; // 0x4 Size: 0x4
	    EWaveRules WaveRules; // 0x8 Size: 0x1
	    char UnknownData0[0x3]; // 0x9
	    float WaveLengthMod; // 0xc Size: 0x4
	    float NumKillsMod; // 0x10 Size: 0x4
	    float KillPointsMod; // 0x14 Size: 0x4
	    float DifficultyAddMod; // 0x18 Size: 0x4
	    bool bDeferTemporaryModifiers; // 0x1c Size: 0x1
	    char UnknownData1[0x3]; // 0x1d
	    __int64/*SoftClassProperty*/ OverrideSpawnPointsMultiplier; // 0x20 Size: 0x28
	    __int64/*SoftClassProperty*/ OverrideSpawnPointsCurve; // 0x48 Size: 0x28
	    __int64/*SoftClassProperty*/ OverrideSpawnProgression; // 0x70 Size: 0x28
	    __int64/*SoftClassProperty*/ OverrideUtilitiesAdjustment; // 0x98 Size: 0x28
	    __int64/*SoftClassProperty*/ OverrideUtilitiesFree; // 0xc0 Size: 0x28
	    __int64/*SoftClassProperty*/ OverrideUtilitiesLocked; // 0xe8 Size: 0x28
	    __int64/*SoftClassProperty*/ OverrideDistance; // 0x110 Size: 0x28
	    __int64/*SoftClassProperty*/ OverrideDirectionNumber; // 0x138 Size: 0x28
	    __int64/*SoftClassProperty*/ OverrideModifierTags; // 0x160 Size: 0x28
	    __int64/*SoftClassProperty*/ OverrideTimedModifierTags; // 0x188 Size: 0x28

};

struct FActiveGameplayModifierHandle
{
	public:
	    int Handle; // 0x0 Size: 0x4

};

struct FFortItemQuantityPair
{
	public:
	    struct FPrimaryAssetId ItemPrimaryAssetId; // 0x0 Size: 0x10
	    struct TSoftObjectPtr<struct UFortItemDefinition*> ItemDefinition; // 0x10 Size: 0x28
	    int Quantity; // 0x38 Size: 0x4
	    char UnknownData0[0x4];

};

struct FReplicatedMontageIndexPair
{
	public:
	    class UAnimMontage* Montage; // 0x0 Size: 0x8
	    int Index; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};



enum class EAthenaAerialPhase : uint8_t
{
    None = 0,
    BusCantExit = 1,
    BusCanExit = 2,
    Skydiving = 3,
    Parachuting = 4,
    EAthenaAerialPhase_MAX = 5
};struct FMeshNetworkStatus
{
	public:
	    bool bEnabled; // 0x0 Size: 0x1
	    bool bConnectedToRoot; // 0x1 Size: 0x1
	    EMeshNetworkNodeType GameServerNodeType; // 0x2 Size: 0x1

};

struct FGameplayMutatorObjectData : public FFastArraySerializerItem
{
	public:
	    char UnknownData0[0x4];
	    class UObject* TheObject; // 0x10 Size: 0x8
	    int ObjectId; // 0x18 Size: 0x4
	    int ObjectValue1; // 0x1c Size: 0x4
	    int ObjectValue2; // 0x20 Size: 0x4
	    char UnknownData1[0x4];

};

struct FGameplayMutatorEventData
{
	public:
	    int EventId; // 0x0 Size: 0x4
	    int EventParam1; // 0x4 Size: 0x4
	    int EventParam2; // 0x8 Size: 0x4
	    int EventParam3; // 0xc Size: 0x4

};



enum class ESafeZoneStartUp : uint8_t
{
    UseDefaultGameBehavior = 0,
    StartsWithWarmUp = 1,
    StartsWithAirCraft = 2,
    ESafeZoneStartUp_MAX = 3
};struct FPropertyOverride : public FFastArraySerializerItem
{
	public:
	    char UnknownData0[0x4];
	    struct FString PropertyScope; // 0x10 Size: 0x10
	    struct FString PropertyName; // 0x20 Size: 0x10
	    struct FString PropertyData; // 0x30 Size: 0x10

};



enum class EFriendlyFireType : uint8_t
{
    Off = 0,
    On = 1,
    EFriendlyFireType_MAX = 2
};

enum class EAirCraftBehavior : uint8_t
{
    Default = 0,
    OpposingAirCraftForEachTeam = 1,
    FlyTowardFirstCircleCenter = 2,
    EAirCraftBehavior_MAX = 3
};struct FAircraftFlightInfo
{
	public:
	    struct FVector_NetQuantize100 FlightStartLocation; // 0x0 Size: 0xc
	    struct FRotator FlightStartRotation; // 0xc Size: 0xc
	    float FlightSpeed; // 0x18 Size: 0x4
	    float TimeTillFlightEnd; // 0x1c Size: 0x4
	    float TimeTillDropStart; // 0x20 Size: 0x4
	    float TimeTillDropEnd; // 0x24 Size: 0x4

};

struct FFortWinnerPlayerData
{
	public:
	    int PlayerID; // 0x0 Size: 0x4

};

struct FPlayerStartupControllerCreated__DelegateSignature
{
	public:

};

struct FPlayerStartupControllerRegistered__DelegateSignature
{
	public:

};

struct FAllInCountdownInitiated__DelegateSignature
{
	public:

};

struct FPlayerStartupControllerDestroyed__DelegateSignature
{
	public:

};

struct FPlayerStartupControllerReset__DelegateSignature
{
	public:

};

struct FOnHandleMatchHasStarted__DelegateSignature
{
	public:

};



enum class EFortReportDayPhase : uint8_t
{
    Dawn = 0,
    Dusk = 1,
    ZoneFinished = 2,
    PlayerLogout = 3,
    EFortReportDayPhase_MAX = 4
};struct FOnHandleZonePeriodicReport__DelegateSignature
{
	public:
	    EFortReportDayPhase ReportEventType; // 0x0 Size: 0x1

};

struct FOnAircraftStateChange__DelegateSignature
{
	public:

};

struct FOnShowFPSChange__DelegateSignature
{
	public:
	    bool bShowFPS; // 0x0 Size: 0x1

};

struct FOnTalkingPlayersChanged__DelegateSignature
{
	public:

};

struct FOnSpectatorStreaming__DelegateSignature
{
	public:
	    bool bSpectatorStreaming; // 0x0 Size: 0x1

};

struct FOnInGameLoadScreenChanged__DelegateSignature
{
	public:
	    bool bEnableLoadScreen; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FText HUDReasonText; // 0x8 Size: 0x18

};

struct FOnViewTargetKillsChanged__DelegateSignature
{
	public:
	    int NewKills; // 0x0 Size: 0x4

};

struct FOnInGameMatchmakingComplete__DelegateSignature
{
	public:
	    bool bSuccess; // 0x0 Size: 0x1

};

struct FOnItemDroppedDueToOverflow__DelegateSignature
{
	public:
	    class UFortWorldItem* ItemDropped; // 0x0 Size: 0x8

};

struct FOnPlayerPawnEvent__DelegateSignature
{
	public:
	    class AFortPlayerPawn* PlayerPawn; // 0x0 Size: 0x8

};

struct FOnCreativePermissionsChanged__DelegateSignature
{
	public:

};

struct FOnCreativePlotLinkedVolumeChanged__DelegateSignature
{
	public:
	    class AFortVolume* Volume; // 0x0 Size: 0x8

};

struct FNotifySafeZoneChanges__DelegateSignature
{
	public:

};

struct FCumulativeFrameTimeWithoutSleepLimits
{
	public:
	    double FrameTimeWithoutSleep; // 0x0 Size: 0x8
	    double MaxCumulativeFrameTimeAboveThreshold; // 0x8 Size: 0x8
	    double MaxNumberOfFramesAboveThreshold; // 0x10 Size: 0x8

};

struct FItemAndCount
{
	public:
	    int Count; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    class UFortItemDefinition* Item; // 0x8 Size: 0x8

};

struct FAthenaVehicleOverride
{
	public:
	    __int64/*SoftClassProperty*/ DefaultVehicleClass; // 0x0 Size: 0x28
	    __int64/*SoftClassProperty*/ OverrideVehicleClass; // 0x28 Size: 0x28

};

struct FExitCraftSpawnData
{
	public:
	    class UFortAthenaExitCraftInfo* ExitCraftInfo; // 0x0 Size: 0x8

};



enum class EForceKickAfterDeathMode : uint8_t
{
    Disabled = 0,
    KickAll = 1,
    KickPrivate = 2,
    EForceKickAfterDeathMode_MAX = 3
};struct FGCSettingsOverride
{
	public:
	    FName PlaylistName; // 0x0 Size: 0x8
	    bool bEnableGCOnServerDuringMatch; // 0x8 Size: 0x1
	    char UnknownData0[0x3]; // 0x9
	    float GCFrequency; // 0xc Size: 0x4

};

struct FTimeOfDayOverride
{
	public:
	    FName PlaylistName; // 0x0 Size: 0x8
	    float TimeOfDay; // 0x8 Size: 0x4
	    float TimeOfDaySpeed; // 0xc Size: 0x4

};



enum class ECapturePointState : uint8_t
{
    Idle = 0,
    Capturing = 1,
    Contested = 2,
    Resetting = 3,
    Captured = 4,
    Reset = 5,
    ECapturePointState_MAX = 6
};struct FOnCaptureStateChanged__DelegateSignature
{
	public:
	    ECapturePointState CaptureState; // 0x0 Size: 0x1

};

struct FOnTeamOwningCapturePointChanged__DelegateSignature
{
	public:
	    char OldTeam; // 0x0 Size: 0x1
	    char NewTeam; // 0x1 Size: 0x1

};

struct FOnCaptureLock__DelegateSignature
{
	public:
	    class AAthenaCapturePoint* CapturePoint; // 0x0 Size: 0x8
	    char LockTeam; // 0x8 Size: 0x1
	    bool bIsNewLock; // 0x9 Size: 0x1
	    char UnknownData0[0x6];

};

struct FOnCaptureLockBroken__DelegateSignature
{
	public:
	    class AAthenaCapturePoint* CapturePoint; // 0x0 Size: 0x8
	    char LockTeam; // 0x8 Size: 0x1
	    char BreakTeam; // 0x9 Size: 0x1
	    char UnknownData0[0x6];

};



enum class EPropertyOverrideTargetType : uint8_t
{
    None = 0,
    Default = 1,
    ImmutableTarget = 2,
    EPropertyOverrideTargetType_MAX = 3
};struct FPropertyOverrideMk2 : public FFastArraySerializerItem
{
	public:
	    char UnknownData0[0x4];
	    struct FString PropertyScope; // 0x10 Size: 0x10
	    struct FString PropertyName; // 0x20 Size: 0x10
	    struct FString PropertyData; // 0x30 Size: 0x10
	    struct FString DefaultPropertyData; // 0x40 Size: 0x10
	    char UnknownData1[0x8];

};

struct FReplayPauseStateChanged__DelegateSignature
{
	public:
	    bool bPaused; // 0x0 Size: 0x1

};

struct FReplayTimeChanged__DelegateSignature
{
	public:
	    float TimeNow; // 0x0 Size: 0x4

};

struct FReplayTimelineRangeChanged__DelegateSignature
{
	public:
	    float StartTime; // 0x0 Size: 0x4
	    float EndTime; // 0x4 Size: 0x4

};

struct FReplayPlaybackMultiplierChanged__DelegateSignature
{
	public:
	    float NewMultiplier; // 0x0 Size: 0x4

};



enum class EHudVisibilityState : uint8_t
{
    FullyVisible = 0,
    FullyHidden = 1,
    GameOnly = 2,
    ReplayOnly = 3,
    MAX = 4
};struct FReplayHudVisibilityChanged__DelegateSignature
{
	public:
	    EHudVisibilityState IsVisible; // 0x0 Size: 0x1

};

struct FToggleReplayViewSettings__DelegateSignature
{
	public:

};

struct FToggleReplayPlayerList__DelegateSignature
{
	public:

};

struct FReplayLevelStreamingChanged__DelegateSignature
{
	public:
	    bool bStreaming; // 0x0 Size: 0x1

};

struct FReplayTimelineFocusChanged__DelegateSignature
{
	public:
	    bool bIsTimelineFocus; // 0x0 Size: 0x1

};



enum class EFortReplayEventType : uint8_t
{
    Elimination = 0,
    Eliminated = 1,
    DBNO = 2,
    UserPlaced = 3,
    MAX = 4
};struct FReplayTimelineMarkerAdded__DelegateSignature
{
	public:
	    EFortReplayEventType EventType; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float TimeRatio; // 0x4 Size: 0x4
	    int MarkerIdx; // 0x8 Size: 0x4

};

struct FReplayTimelineMarkersCleared__DelegateSignature
{
	public:

};

struct FFortReplayFXState
{
	public:
	    bool IsHighQualityFX; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    int DefaultParticleLODBias; // 0x4 Size: 0x4
	    int DefaultDepthOfFieldQuality; // 0x8 Size: 0x4
	    int OverrideParticleLODBias; // 0xc Size: 0x4
	    int OverrideDepthOfFieldQuality; // 0x10 Size: 0x4

};

struct FReplayFXStateChange__DelegateSignature
{
	public:
	    struct FFortReplayFXState FXState; // 0x0 Size: 0x14

};

struct FReplayScrubComplete__DelegateSignature
{
	public:

};

struct FNoParamDelegate__DelegateSignature
{
	public:

};

struct FOnCurrentShotChanged__DelegateSignature
{
	public:
	    int ShotIndex; // 0x0 Size: 0x4

};

struct FOnFollowedPlayerChanged__DelegateSignature
{
	public:
	    class AFortPlayerControllerSpectating* SpectatorPC; // 0x0 Size: 0x8
	    class AFortPlayerState* NewFollowedPlayer; // 0x8 Size: 0x8

};



enum class ESpectatorCameraType : uint8_t
{
    ThirdPerson = 0,
    DroneFree = 1,
    Gameplay = 2,
    Arena = 3,
    Free = 4,
    ReverseShot = 5,
    FollowShot = 6,
    DroneFollow = 7,
    DroneAttach = 8,
    Projectile = 9,
    DroneAutoFrame = 10,
    MAX = 11
};struct FOnCameraTypeChanged__DelegateSignature
{
	public:
	    class AFortPlayerControllerSpectating* SpectatorPC; // 0x0 Size: 0x8
	    ESpectatorCameraType NewCameraType; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FOnPlayerBecameRelevant__DelegateSignature
{
	public:
	    class AFortPlayerState* NewlyRelevantPlayer; // 0x0 Size: 0x8

};

struct FOnPlayerBecameIrrelevant__DelegateSignature
{
	public:
	    class AFortPlayerState* NewlyIrrelevantPlayer; // 0x0 Size: 0x8

};

struct FOnPlayerDied__DelegateSignature
{
	public:
	    class AFortPlayerState* NewlyDeadPlayer; // 0x0 Size: 0x8

};

struct FSpectatorDelegate__DelegateSignature
{
	public:

};

struct FOnShowNotification__DelegateSignature
{
	public:
	    struct FText NotificationText; // 0x0 Size: 0x18

};

struct FOnNameplatesEnabledChanged__DelegateSignature
{
	public:
	    bool bNameplatesEnabled; // 0x0 Size: 0x1

};

struct FOnNameplatesViewDistanceChanged__DelegateSignature
{
	public:
	    float NewDistance; // 0x0 Size: 0x4

};

struct FPlayerStateAthenaDelegate__DelegateSignature
{
	public:
	    class AFortPlayerStateAthena* FPSA; // 0x0 Size: 0x8

};

struct FOnCapturePointStateChanged__DelegateSignature
{
	public:
	    char CaptureState; // 0x0 Size: 0x1

};



enum class ECaptureState : uint8_t
{
    CS_Idle = 0,
    CS_Capturing = 1,
    CS_Contested = 2,
    CS_Resetting = 3,
    CS_Captured = 4,
    CS_Reset = 5,
    CS_MAX = 6
};struct FOnTeamOwningPointChanged__DelegateSignature
{
	public:
	    char OldTeam; // 0x0 Size: 0x1
	    char NewTeam; // 0x1 Size: 0x1

};



enum class EFOBIOStatus : uint8_t
{
    Saving = 0,
    Loading = 1,
    Free = 2,
    EFOBIOStatus_MAX = 3
};struct FOnBuildingFOBConfigActorIOOperationComplete__DelegateSignature
{
	public:
	    EFOBIOStatus IOOperation; // 0x0 Size: 0x1
	    bool bSuccess; // 0x1 Size: 0x1
	    char UnknownData0[0x6]; // 0x2
	    class UFortFOBCoreDecoItemDefinition* SelectedCoreDef; // 0x8 Size: 0x8

};

struct FOnFOBCoreDamaged__DelegateSignature
{
	public:
	    class ABuildingFOBCoreActor* Core; // 0x0 Size: 0x8
	    float DamageTaken; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FOnFOBCoreOutOfHealth__DelegateSignature
{
	public:
	    class ABuildingFOBCoreActor* Core; // 0x0 Size: 0x8

};

struct FOnFOBCoreTargetableChanged__DelegateSignature
{
	public:
	    class ABuildingFOBCoreActor* Core; // 0x0 Size: 0x8
	    bool bTargetable; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FOnFOBCoreVulnerableChanged__DelegateSignature
{
	public:
	    class ABuildingFOBCoreActor* Core; // 0x0 Size: 0x8
	    bool bVulnerable; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FItemCollectorHandleManualOutput__DelegateSignature
{
	public:
	    class AFortPlayerController* InteractingController; // 0x0 Size: 0x8
	    class UFortWorldItemDefinition* InputItem; // 0x8 Size: 0x8

};

struct FOnLayoutSatisfied__DelegateSignature
{
	public:
	    class ABuildingLayoutRequirement* LayoutRequirement; // 0x0 Size: 0x8
	    class ABuildingSMActor* SatisfyingBuildingSMActor; // 0x8 Size: 0x8

};

struct FDefenderPawnOrItemSet__DelegateSignature
{
	public:

};

struct FSimpleDynamicMulticastDelegate__DelegateSignature
{
	public:

};

struct FOnPlayspaceEditModeChanged__DelegateSignature
{
	public:
	    bool bInEditMode; // 0x0 Size: 0x1

};

struct FOnMinigameComponentStateChanged__DelegateSignature
{
	public:
	    class UFortMinigameLogicComponent* MinigameComponent; // 0x0 Size: 0x8

};

struct FOnResetMinigameComponent__DelegateSignature
{
	public:
	    class UFortMinigameLogicComponent* MinigameComponent; // 0x0 Size: 0x8

};

struct FBuildingTurretTargetChanged__DelegateSignature
{
	public:
	    class AActor* NewTarget; // 0x0 Size: 0x8

};

struct FOnConnected__DelegateSignature
{
	public:
	    class ABuildingSMActor* NewlyConnectedActor; // 0x0 Size: 0x8

};

struct FOnDisconnected__DelegateSignature
{
	public:
	    class ABuildingSMActor* NewlyDisconnectedActor; // 0x0 Size: 0x8

};

struct FOnPowered__DelegateSignature
{
	public:

};

struct FOnUnpowered__DelegateSignature
{
	public:

};

struct FOnClientEnterVolume__DelegateSignature
{
	public:
	    class APlayerState* Client; // 0x0 Size: 0x8
	    class AFortVolume* Volume; // 0x8 Size: 0x8

};

struct FOnClientExitVolume__DelegateSignature
{
	public:
	    class APlayerState* Client; // 0x0 Size: 0x8
	    class AFortVolume* Volume; // 0x8 Size: 0x8

};

struct FOnClientStartExitingVolume__DelegateSignature
{
	public:
	    class APlayerState* Client; // 0x0 Size: 0x8
	    class AFortVolume* Volume; // 0x8 Size: 0x8

};

struct FOnClientStopExitingVolume__DelegateSignature
{
	public:
	    class APlayerState* Client; // 0x0 Size: 0x8
	    class AFortVolume* Volume; // 0x8 Size: 0x8

};

struct FFortCollectionBookSlottedItemOperationCompleteDelegate__DelegateSignature
{
	public:
	    class UFortAccountItem* ItemSlotted; // 0x0 Size: 0x8
	    FName SlotId; // 0x8 Size: 0x8

};

struct FFortHiddenRewardQuantityPair
{
	public:
	    FName TemplateId; // 0x0 Size: 0x8
	    int Quantity; // 0x8 Size: 0x4

};



enum class ECollectionBookRewardType : uint8_t
{
    Uninitialized = 0,
    Book = 1,
    Page = 2,
    Section = 3,
    ECollectionBookRewardType_MAX = 4
};struct FFortCollectionBookUnslottedItemOperationCompleteDelegate__DelegateSignature
{
	public:
	    class UFortAccountItem* UnslottedItem; // 0x0 Size: 0x8
	    class UFortAccountItem* OldItem; // 0x8 Size: 0x8
	    FName SlotId; // 0x10 Size: 0x8

};

struct FFortCollectionBookResearchItemOperationCompleteDelegate__DelegateSignature
{
	public:
	    class UFortAccountItem* NewItem; // 0x0 Size: 0x8
	    struct FString TemplateId; // 0x8 Size: 0x10

};

struct FFortConversationDelegate__DelegateSignature
{
	public:

};

struct FActiveMusicPackChangedDelegate__DelegateSignature
{
	public:
	    class UAthenaMusicPackItemDefinition* NewMusicPack; // 0x0 Size: 0x8

};

struct FAnyPropertyChangedDelegate__DelegateSignature
{
	public:

};

struct FFortAbandonSessionCompleteDelegate__DelegateSignature
{
	public:

};

struct FFortRejoinSessionCompleteDelegate__DelegateSignature
{
	public:

};

struct FOnPlaysetGrenadeTarget__DelegateSignature
{
	public:

};

struct FOnDuplicateBuildingActor__DelegateSignature
{
	public:

};

struct FOnMoveToolCopyGrabOrDuplicate__DelegateSignature
{
	public:

};

struct FOnMoveToolRotateClockwise__DelegateSignature
{
	public:

};

struct FOnMoveToolRotateCounterclockwise__DelegateSignature
{
	public:

};

struct FOnMoveToolSwitchAxis__DelegateSignature
{
	public:

};

struct FOnMoveToolMirror__DelegateSignature
{
	public:

};

struct FOnMoveToolPushPull__DelegateSignature
{
	public:

};

struct FOnMoveToolDropToFloor__DelegateSignature
{
	public:

};

struct FOnMoveToolExit__DelegateSignature
{
	public:

};

struct FOnMoveToolDelete__DelegateSignature
{
	public:

};

struct FOnMoveToolChangePrecisionLevel__DelegateSignature
{
	public:

};

struct FOnPlaysetPreviewPlace__DelegateSignature
{
	public:

};

struct FOnLinkedVolumeSet__DelegateSignature
{
	public:
	    class AFortVolume* PreviousVolume; // 0x0 Size: 0x8
	    class AFortVolume* NewVolume; // 0x8 Size: 0x8

};

struct FOnDeployableBasePlotsSpawned__DelegateSignature
{
	public:

};

struct FOnLocalPlayerEntersDeployablePlot__DelegateSignature
{
	public:
	    class AFortPlayerPawn* PlayerPawn; // 0x0 Size: 0x8
	    class ADeployableBasePlot* Plot; // 0x8 Size: 0x8

};

struct FOnLocalPlayerLeavesDeployablePlot__DelegateSignature
{
	public:
	    class AFortPlayerPawn* PlayerPawn; // 0x0 Size: 0x8
	    class ADeployableBasePlot* Plot; // 0x8 Size: 0x8

};

struct FOnLocalDeployablePlotInventoryChanged__DelegateSignature
{
	public:
	    class ADeployableBasePlot* Plot; // 0x0 Size: 0x8

};

struct FOnPlayerLoginToFOB__DelegateSignature
{
	public:
	    class AFortPlayerController* PlayerController; // 0x0 Size: 0x8

};

struct FOnDeployableBaseManagerCreated__DelegateSignature
{
	public:

};

struct FOnBuildingDestroyed__DelegateSignature
{
	public:
	    class ABuildingSMActor* Building; // 0x0 Size: 0x8

};

struct FOnScalabilityChanged__DelegateSignature
{
	public:

};

struct FOnAllowVideoPlaybackChanged__DelegateSignature
{
	public:
	    bool bAllowed; // 0x0 Size: 0x1

};

struct FWorkerPreviewStateChanged__DelegateSignature
{
	public:

};

struct FHomebaseInventoryUpdated__DelegateSignature
{
	public:

};

struct FHomebaseMaximumItemLevelChanged__DelegateSignature
{
	public:

};

struct FHomebaseItemUpgradePointsChanged__DelegateSignature
{
	public:

};

struct FItemSlottingPreviewInfoChanged__DelegateSignature
{
	public:

};

struct FSquadSlotMarkedAsSeen__DelegateSignature
{
	public:

};

struct FOnSavingStateChanged__DelegateSignature
{
	public:
	    bool SaveActive; // 0x0 Size: 0x1

};



enum class EBackupSaveState : uint8_t
{
    Ready = 0,
    InProgress = 1,
    OnCooldown = 2,
    EBackupSaveState_MAX = 3
};struct FOnBackupSaveStateChanged__DelegateSignature
{
	public:
	    EBackupSaveState SaveState; // 0x0 Size: 0x1

};

struct FOnBackupRestoreStateChanged__DelegateSignature
{
	public:
	    EBackupSaveState SaveState; // 0x0 Size: 0x1

};

struct FOnDateChanged__DelegateSignature
{
	public:
	    struct FDateTime DateValue; // 0x0 Size: 0x8

};

struct FOnUnloadComplete__DelegateSignature
{
	public:

};

struct FOnHasBeenFoundDelSignature__DelegateSignature
{
	public:
	    class AFortPlayerController* PlayerController; // 0x0 Size: 0x8

};

struct FOnMissionTimerComponentUpdated__DelegateSignature
{
	public:
	    class UFortMissionTimerComponent* TimerComponent; // 0x0 Size: 0x8

};



enum class EFortPrototypingStatus : uint8_t
{
    Unknown = 0,
    Disabled = 1,
    Enabled = 2,
    EFortPrototypingStatus_MAX = 3
};struct FOnCornerstoneDamaged__DelegateSignature
{
	public:
	    class AFortPvPBaseCornerstone* Cornerstone; // 0x0 Size: 0x8
	    float DamageTaken; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FOnCornerstoneOutOfHealth__DelegateSignature
{
	public:
	    class AFortPvPBaseCornerstone* Cornerstone; // 0x0 Size: 0x8

};

struct FAbilitySystemActorChanged__DelegateSignature
{
	public:

};

struct FOnStormShieldStatusChanged__DelegateSignature
{
	public:
	    bool bInStorm; // 0x0 Size: 0x1

};

struct FOnHandleTeamXPChanged__DelegateSignature
{
	public:
	    char Team; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    int MatchLevel; // 0x4 Size: 0x4
	    int TeamXP; // 0x8 Size: 0x4
	    int NextLevelXP; // 0xc Size: 0x4

};

struct FOnHandleTeamLevelChanged__DelegateSignature
{
	public:
	    char Team; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    int MatchLevel; // 0x4 Size: 0x4
	    int TeamXP; // 0x8 Size: 0x4
	    int NextLevelXP; // 0xc Size: 0x4

};

struct FOnFOBCoresLoaded__DelegateSignature
{
	public:
	    char Team; // 0x0 Size: 0x1

};

struct FOnFOBCoresDestroyed__DelegateSignature
{
	public:
	    char Team; // 0x0 Size: 0x1

};

struct FClickedPartyPlayerDelegate__DelegateSignature
{
	public:
	    int PlayerIndex; // 0x0 Size: 0x4

};

struct FOnPrefabForCurrentlyDisplayedItemChanged__DelegateSignature
{
	public:
	    class AActor* NewPrefab; // 0x0 Size: 0x8
	    class UFortItem* NewItem; // 0x8 Size: 0x8

};

struct FOnTextFiltered__DelegateSignature
{
	public:
	    bool bSuccess; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FString SanitizedMsg; // 0x8 Size: 0x10

};

struct FSimpleMinigameDelegate__DelegateSignature
{
	public:

};



enum class EFortMinigameState : uint8_t
{
    PreGame = 0,
    Warmup = 1,
    InProgress = 2,
    PostGameEnd = 3,
    PostGameAbandon = 4,
    EFortMinigameState_MAX = 5
};struct FOnStateChanged__DelegateSignature
{
	public:
	    EFortMinigameState MinigameState; // 0x0 Size: 0x1

};

struct FOnPlayerChanged__DelegateSignature
{
	public:
	    class APlayerState* PlayerState; // 0x0 Size: 0x8

};

struct FPlayerProgressDelegate__DelegateSignature
{
	public:
	    class APlayerState* PlayerState; // 0x0 Size: 0x8
	    class UFortMinigameProgressComponent* Progress; // 0x8 Size: 0x8

};

struct FMinigameScoresUpdatedDelegate__DelegateSignature
{
	public:
	    class AFortMinigameScoreRegistry* ScoreRegistry; // 0x0 Size: 0x8

};

struct FOnUpdateUI__DelegateSignature
{
	public:
	    class AFortMissionState* MissionState; // 0x0 Size: 0x8

};



enum class EFortObjectiveStatus : uint8_t
{
    Created = 0,
    InProgress = 1,
    Succeeded = 2,
    Failed = 3,
    NeutralCompletion = 4,
    Max_None = 5,
    EFortObjectiveStatus_MAX = 6
};struct FOnObjectiveStatusChanged__DelegateSignature
{
	public:
	    class AFortObjectiveBase* Objective; // 0x0 Size: 0x8
	    EFortObjectiveStatus NewStatus; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FOnObjectiveIsVisibleChanged__DelegateSignature
{
	public:
	    class AFortObjectiveBase* Objective; // 0x0 Size: 0x8
	    bool bNewVisibility; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};



enum class EFortMissionVisibilityOverride : uint8_t
{
    Visible = 0,
    Invisible = 1,
    Max_None = 2,
    EFortMissionVisibilityOverride_MAX = 3
};struct FOnObjectiveIsVisibilityOverrideChanged__DelegateSignature
{
	public:
	    class AFortObjectiveBase* Objective; // 0x0 Size: 0x8
	    EFortMissionVisibilityOverride NewVisibilityOverride; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FOnObjectivesUpdated__DelegateSignature
{
	public:

};

struct FOnMissionInfoSet__DelegateSignature
{
	public:

};

struct FOnMissionsUpdated__DelegateSignature
{
	public:

};

struct FOnShowSecondaryMissionHeadersChanged__DelegateSignature
{
	public:

};

struct FOnStormShieldReachedTargetRadius__DelegateSignature
{
	public:
	    float Radius; // 0x0 Size: 0x4

};

struct FOnStormShieldReachedTargetLocation__DelegateSignature
{
	public:
	    struct FVector Location; // 0x0 Size: 0xc

};

struct FFortOutOfTrack__DelegateSignature
{
	public:

};

struct FFortLostTrack__DelegateSignature
{
	public:

};

struct FOnReadiedUpStatusChanged__DelegateSignature
{
	public:
	    bool bReadiedUp; // 0x0 Size: 0x1

};

struct FOnMatchmakingStartedDelegate__DelegateSignature
{
	public:

};



enum class EMatchmakingCompleteResult : uint8_t
{
    NotStarted = 0,
    UpdateNeeded = 1,
    OutpostNotFound = 2,
    Cancelled = 3,
    NoResults = 4,
    Failure = 5,
    CreateFailure = 6,
    Success = 7,
    EMatchmakingCompleteResult_MAX = 8
};struct FOnMatchmakingCompletedDelegate__DelegateSignature
{
	public:
	    EMatchmakingCompleteResult Result; // 0x0 Size: 0x1

};

struct FOnMatchmakingStateChangeDelegate__DelegateSignature
{
	public:
	    char OldState; // 0x0 Size: 0x1
	    char NewState; // 0x1 Size: 0x1

};



enum class EMatchmakingState : uint8_t
{
    NotMatchmaking = 0,
    CancelingMatchmaking = 1,
    ReleasingLock = 2,
    AcquiringLock = 3,
    LockAcquistionFailure = 4,
    FindingEmptyServer = 5,
    FindingExistingSession = 6,
    TestingEmptyServers = 7,
    TestingExistingSessions = 8,
    JoiningExistingSession = 9,
    NoMatchesAvailable = 10,
    CleaningUpExisting = 11,
    HandlingFailure = 12,
    JoinSuccess = 13,
    EMatchmakingState_MAX = 14
};struct FOnMatchmakingFlowChangeDelegate__DelegateSignature
{
	public:
	    bool bIsActive; // 0x0 Size: 0x1

};

struct FOnLobbyConnectionStartedDelegate__DelegateSignature
{
	public:

};

struct FOnLobbyConnectionAttemptFailedDelegate__DelegateSignature
{
	public:

};

struct FOnLobbyWaitingForPlayersDelegate__DelegateSignature
{
	public:

};

struct FOnLobbyWaitingForPlayersTimeUpdateDelegate__DelegateSignature
{
	public:

};

struct FOnLobbyStartedDelegate__DelegateSignature
{
	public:

};

struct FOnLobbyDisconnected__DelegateSignature
{
	public:

};

struct FOnLobbyConnectingToGame__DelegateSignature
{
	public:

};

struct FOnLobbyTimeUpdatedDelegate__DelegateSignature
{
	public:
	    int CurrentTime; // 0x0 Size: 0x4

};

struct FOnLobbyTimeExpiredDelegate__DelegateSignature
{
	public:

};

struct FOnReadyUpStatusChangedDelegate__DelegateSignature
{
	public:
	    bool bReadyStatus; // 0x0 Size: 0x1

};

struct FOnWorldRecordLoadedChangedDelegate__DelegateSignature
{
	public:
	    bool NewWorldRecordLoaded; // 0x0 Size: 0x1

};

struct FOnOutpostDiscoveryFailure__DelegateSignature
{
	public:

};

struct FOnRejoinCheckCompletedDelegate__DelegateSignature
{
	public:
	    ERejoinStatus RejoinStatus; // 0x0 Size: 0x1

};



enum class EAthenaPartyMemberReadyType : uint8_t
{
    Ready = 0,
    NotReady = 1,
    Playing = 2,
    WatchingReplay = 3,
    EAthenaPartyMemberReadyType_MAX = 4
};

enum class EFortFriendRequestStatus : uint8_t
{
    None = 0,
    Accepted = 1,
    PendingReceived = 2,
    PendingSent = 3,
    EFortFriendRequestStatus_MAX = 4
};

enum class EFortPartyMemberLocation : uint8_t
{
    PreLobby = 0,
    ConnectingToLobby = 1,
    Lobby = 2,
    JoiningGame = 3,
    ProcessingRejoin = 4,
    InGame = 5,
    WatchingReplay = 6,
    ReturningToFrontEnd = 7,
    EFortPartyMemberLocation_MAX = 8
};

enum class EFortPartyState : uint8_t
{
    Undetermined = 0,
    WorldView = 1,
    TheaterView = 2,
    Matchmaking = 3,
    PostMatchmaking = 4,
    ReturningToFrontEnd = 5,
    BattleRoyaleView = 6,
    BattleRoyalePreloading = 7,
    BattleRoyaleMatchmaking = 8,
    BattleRoyalePostMatchmaking = 9,
    EFortPartyState_MAX = 10
};

enum class EFortPartyMemberDisplayState : uint8_t
{
    Open = 0,
    Connecting = 1,
    Connected = 2,
    Max = 3
};

enum class EFortRuntimeOptionTabState : uint8_t
{
    Default = 0,
    Disabled = 1,
    Hidden = 2,
    EFortRuntimeOptionTabState_MAX = 3
};struct FRuntimeOptionTabStateInfo
{
	public:
	    FName TabName; // 0x0 Size: 0x8
	    EFortRuntimeOptionTabState TabState; // 0x8 Size: 0x1
	    char UnknownData0[0x3];

};

struct FRuntimeOptionLocalizableStringEntry
{
	public:
	    struct FString Culture; // 0x0 Size: 0x10
	    struct FString Text; // 0x10 Size: 0x10

};

struct FRuntimeOptionReviewPromptCriteria
{
	public:
	    int MinutesPlayed; // 0x0 Size: 0x4
	    int GamesPlayed; // 0x4 Size: 0x4
	    int BestResult; // 0x8 Size: 0x4
	    int KillCount; // 0xc Size: 0x4
	    bool RequireAll; // 0x10 Size: 0x1
	    char UnknownData0[0x3];

};

struct FOnBuildingLevelChanged__DelegateSignature
{
	public:
	    class UFortOutpostItemDefinition* OutpostBuilding; // 0x0 Size: 0x8

};

struct FOnItemsNeedRefresh__DelegateSignature
{
	public:

};

struct FOnGooContentNeedRefresh__DelegateSignature
{
	public:

};

struct FOnCraftingTableActivationBonusChanged__DelegateSignature
{
	public:

};



enum class EFortSpectatorBlendType : uint8_t
{
    None = 0,
    Orbit = 1,
    Default = 2,
    EFortSpectatorBlendType_MAX = 3
};struct FSavedPlayerSpectatorCameraData
{
	public:
	    __int64/*MapProperty*/ PlayerToCameraStateMap; // 0x0 Size: 0x50

};

struct FSpectatorOwnedCameraComponentRecord
{
	public:
	    __int64/*MapProperty*/ ViewTargetToComponentMap; // 0x0 Size: 0x50

};

struct FOnItemFabricated__DelegateSignature
{
	public:

};

struct FClientAcknowledgedPlayetsetDataReceivedDelegate__DelegateSignature
{
	public:

};

struct FOnIsSpectatorTargetChanged__DelegateSignature
{
	public:

};

struct FOnKillsChanged__DelegateSignature
{
	public:

};

struct FFortTrackGraphChanged__DelegateSignature
{
	public:

};

struct FFortChoiceUiSuccessDelegate__DelegateSignature
{
	public:
	    int ChosenItem; // 0x0 Size: 0x4

};

struct FFortChoiceUiFailureDelegate__DelegateSignature
{
	public:

};

struct FOnAccepted__DelegateSignature
{
	public:

};



enum class EFortDialogFeedbackType : uint8_t
{
    FriendRequestSent = 0,
    FriendRequestReceived = 1,
    FriendRequestAccepted = 2,
    Default = 3,
    EFortDialogFeedbackType_MAX = 4
};struct FFortDialogDescription
{
	public:
	    struct FSlateBrush Icon; // 0x0 Size: 0x88
	    struct FText MessageHeader; // 0x88 Size: 0x18
	    struct FText MessageBody; // 0xa0 Size: 0x18
	    struct FText AcceptButtonText; // 0xb8 Size: 0x18
	    struct FText IgnoreButtonText; // 0xd0 Size: 0x18
	    struct FText DismissButtonText; // 0xe8 Size: 0x18
	    float DisplayTime; // 0x100 Size: 0x4
	    char UnknownData0[0x4]; // 0x104
	    class UUserWidget* AdditionalContent; // 0x108 Size: 0x8
	    EFortDialogFeedbackType FeedBackType; // 0x110 Size: 0x1
	    bool Dismissable; // 0x111 Size: 0x1
	    char UnknownData1[0x6]; // 0x112
	    class UFortNotificationHandler* NotificationHandler; // 0x118 Size: 0x8
	    char UnknownData2[0x10];

};

struct FGetHealthPercent__DelegateSignature
{
	public:
	    float ReturnValue; // 0x0 Size: 0x4

};

struct FOnProjectileSpawned__DelegateSignature
{
	public:

};

struct FOnMoveToolInteractionStarted__DelegateSignature
{
	public:
	    class UObjectInteractionBehavior* InteractionMode; // 0x0 Size: 0x8

};

struct FOnMoveToolInteractionStopped__DelegateSignature
{
	public:

};

struct FOnMoveToolRotationAxisChanged__DelegateSignature
{
	public:
	    char RotationAxisIndex; // 0x0 Size: 0x1

};

struct FOnMoveToolDropToFloorChanged__DelegateSignature
{
	public:
	    bool bDropToFloorOn; // 0x0 Size: 0x1

};

struct FOnMoveToolLineOfSightBlockingChanged__DelegateSignature
{
	public:
	    bool bIgnoreLineOfSightBlockers; // 0x0 Size: 0x1

};

struct FOnMoveToolPrecisionChanged__DelegateSignature
{
	public:
	    bool bPrecisionOn; // 0x0 Size: 0x1
	    char GridSnapIndex; // 0x1 Size: 0x1

};



enum class EDualWeaponHand : uint8_t
{
    LEFT = 0,
    RIGHT = 1,
    MAX = 2
};struct FOnHandFired__DelegateSignature
{
	public:
	    EDualWeaponHand Hand; // 0x0 Size: 0x1
	    bool bPersistantFire; // 0x1 Size: 0x1

};



enum class EFortEncounterDirection : uint8_t
{
    North = 0,
    NorthEast = 1,
    East = 2,
    SouthEast = 3,
    South = 4,
    SouthWest = 5,
    West = 6,
    NorthWest = 7,
    Max_None = 8,
    EFortEncounterDirection_MAX = 9
};struct FAuthorityMatchReadyAsyncDelegate__DelegateSignature
{
	public:

};

struct FGameStateReadyAsyncDelegate__DelegateSignature
{
	public:
	    class AGameStateBase* GameState; // 0x0 Size: 0x8

};

struct FFortStatManagerTag : public FGameplayTag
{
	public:
	    char UnknownData0[0x8];

};

struct FUpdateCheckDelegate__DelegateSignature
{
	public:

};

struct FFortEnsureClientQuestLoginDelegate__DelegateSignature
{
	public:

};

struct FFortSendQuestStatEventDelegate__DelegateSignature
{
	public:

};



enum class EAIHotSpotAssignmentFilter : uint8_t
{
    All = 0,
    WithSlots = 1,
    WaitingList = 2,
    EAIHotSpotAssignmentFilter_MAX = 3
};

enum class EAIHotSpotSlotFilter : uint8_t
{
    All = 0,
    AvailableOnly = 1,
    UnavailableOnly = 2,
    EAIHotSpotSlotFilter_MAX = 3
};

enum class EAIHotSpotSlot : uint8_t
{
    Free = 0,
    Claimed = 1,
    Occupied = 2,
    Blocked = 3,
    Disabled = 4,
    EAIHotSpotSlot_MAX = 5
};

enum class EBoundingBoxSlotDirectionCalculation : uint8_t
{
    Auto = 0,
    FaceWall = 1,
    FaceAwayFromWall = 2,
    FaceCenter = 3,
    EBoundingBoxSlotDirectionCalculation_MAX = 4
};

enum class EBarrierFlagState : uint8_t
{
    FlagUp = 0,
    FlagDown = 1,
    EBarrierFlagState_MAX = 2
};

enum class EBarrierState : uint8_t
{
    BarrierUp = 0,
    BarrierComingDown = 1,
    BarrierDown = 2,
    EBarrierState_MAX = 3
};

enum class EAthenaBroadcastKillFeedEntryType : uint8_t
{
    Elimination = 0,
    DBNO = 1,
    Storm = 2,
    FallDamage = 3,
    Explosion = 4,
    EAthenaBroadcastKillFeedEntryType_MAX = 5
};

enum class ECapturePointUnlockRules : uint8_t
{
    Reset = 0,
    MaintainState = 1,
    ResetDeactivate = 2,
    ECapturePointUnlockRules_MAX = 3
};

enum class EContentionRuleType : uint8_t
{
    MajorityWins = 0,
    OneTeamOnlyWins = 1,
    EContentionRuleType_MAX = 2
};

enum class EEventTokenType : uint8_t
{
    Invite = 0,
    Creation = 1,
    EEventTokenType_MAX = 2
};

enum class EItemWrapMaterialType : uint8_t
{
    WeaponWrap = 0,
    VehicleWrap_Opaque = 1,
    VehicleWrap_Masked = 2,
    EItemWrapMaterialType_MAX = 3
};

enum class EAthenaQuickChatFilteringType : uint8_t
{
    AlwaysVisible = 0,
    ActiveMaterial = 1,
    FacingPickup = 2,
    ActiveHotbarItem = 3,
    ActiveHotbarItemAmmo = 4,
    FacingPickupOrActiveHotbarItem = 5,
    NoWeaponEquippedRequiringAmmo = 6,
    WeaponEquippedOfAmmoType = 7,
    EAthenaQuickChatFilteringType_MAX = 8
};

enum class EAthenaSeasonRewardTrack : uint8_t
{
    Invalid = 0,
    SeasonProgressionTrack = 1,
    CompendiumFreeTrack = 2,
    CompendiumPaidTrack = 3,
    EAthenaSeasonRewardTrack_MAX = 4
};

enum class EAthenaRewardItemType : uint8_t
{
    Normal = 0,
    HiddenReward = 1,
    NonExportedFakeReward = 2,
    EAthenaRewardItemType_MAX = 3
};

enum class EAthenaChallengeTabVisibility : uint8_t
{
    Hide = 0,
    ShowAlways = 1,
    EAthenaChallengeTabVisibility_MAX = 2
};

enum class EAthenaSeasonShopVisibility : uint8_t
{
    Hide = 0,
    ShowIfOffersAvailable = 1,
    ShowAlways = 2,
    EAthenaSeasonShopVisibility_MAX = 3
};

enum class EFortVehicleDecoType : uint8_t
{
    Unknown = 0,
    Flag = 1,
    HoodOrnament = 2,
    Wings = 3,
    EFortVehicleDecoType_MAX = 4
};

enum class EAutoFrameMode : uint8_t
{
    Off = 0,
    ManualOverride = 1,
    AutoFrame = 2,
    EAutoFrameMode_MAX = 3
};

enum class EBacchusHUDStateType : uint8_t
{
    DoNothing = 0,
    Hide = 1,
    Show = 2,
    FallbackToDefault = 3,
    EBacchusHUDStateType_MAX = 4
};

enum class EAbilitySystemComponentCreationPolicy : uint8_t
{
    Never = 0,
    Lazy = 1,
    Always = 2,
    EAbilitySystemComponentCreationPolicy_MAX = 3
};

enum class EAttributeInitLevelSource : uint8_t
{
    WorldDifficulty = 0,
    PlayerBuildingSkill = 1,
    AthenaPlaylist = 2,
    EAttributeInitLevelSource_MAX = 3
};

enum class EDynamicBuildingPlacementType : uint8_t
{
    CountsTowardsBounds = 0,
    DestroyIfColliding = 1,
    DestroyAnythingThatCollides = 2,
    EDynamicBuildingPlacementType_MAX = 3
};

enum class EUnlockRules : uint8_t
{
    UR_Reset = 0,
    UR_MaintainState = 1,
    UR_ResetDeactivate = 2,
    UR_MAX = 3
};

enum class EContentionRules : uint8_t
{
    CR_MajorityWins = 0,
    CR_OneTeamOnlyWins = 1,
    CR_MAX = 2
};

enum class EBinaryToggleValues : uint8_t
{
    BTV_Active = 0,
    BTV_Inactive = 1,
    BTV_Either = 2,
    BTV_MAX = 3
};

enum class EAuxIndicatorStates : uint8_t
{
    AIS_GuidingArrow = 0,
    AIS_ConfirmedArrow = 1,
    AIS_Inactive = 2,
    AIS_Active = 3,
    AIS_MAX = 4
};

enum class EFOBFileHeaderStatus : uint8_t
{
    NoExistingFile = 0,
    HasExistingFile = 1,
    UnableToDetermine = 2,
    EFOBFileHeaderStatus_MAX = 3
};

enum class EFOBInitStatus : uint8_t
{
    Successful = 0,
    Failure_CloudStorageDisabled = 1,
    Failure_PreviouslyInitialized = 2,
    Failure_DataOwner = 3,
    Failure_CloudStorageError = 4,
    Failure_MissingFileName = 5,
    Failure_Generic = 6,
    EFOBInitStatus_MAX = 7
};

enum class EFOBMode : uint8_t
{
    Uninitialized = 0,
    Creation = 1,
    Deployment = 2,
    EFOBMode_MAX = 3
};

enum class EDynamicFoundationType : uint8_t
{
    Static = 0,
    StartEnabled_Stationary = 1,
    StartEnabled_Dynamic = 2,
    StartDisabled = 3,
    EDynamicFoundationType_MAX = 4
};

enum class EBuildingFoundationType : uint8_t
{
    BFT_3x3 = 0,
    BFT_5x5 = 1,
    BFT_5x10 = 2,
    BFT_None = 3,
    BFT_MAX = 4
};

enum class EFortItemCollectorTrackingType : uint8_t
{
    Player = 0,
    Team = 1,
    EFortItemCollectorTrackingType_MAX = 2
};

enum class EFortItemCollectorBehavior : uint8_t
{
    FirstToGoal = 0,
    FreeForAll = 1,
    EFortItemCollectorBehavior_MAX = 2
};

enum class EFortItemCollectorState : uint8_t
{
    CanInteract = 0,
    Active = 1,
    Inactive = 2,
    Captured = 3,
    Invalid = 4,
    EFortItemCollectorState_MAX = 5
};

enum class ELayoutRequirementStatus : uint8_t
{
    Inactive_Invisible = 0,
    Active_Invisible = 1,
    Active_Visible = 2,
    ELayoutRequirementStatus_MAX = 3
};

enum class ERiftCosmeticState : uint8_t
{
    None = 0,
    Intro = 1,
    Idle = 2,
    RampUp = 3,
    ShouldDie = 4,
    ERiftCosmeticState_MAX = 5
};

enum class EFortRiftSlotStatus : uint8_t
{
    Reserved = 0,
    Occupied = 1,
    Max_None = 2,
    EFortRiftSlotStatus_MAX = 3
};

enum class EBuildingNavObstacleType : uint8_t
{
    UnwalkableAll = 0,
    UnwalkableHuskOnly = 1,
    SmashWhenLowHeight = 2,
    SmashOnlyLowHeight = 3,
    SmashSmasherOnly = 4,
    SmashAll = 5,
    EBuildingNavObstacleType_MAX = 6
};

enum class EFortDamageVisualsState : uint8_t
{
    UnDamaged = 0,
    DamagedAndAnimating = 1,
    DamagedAndStatic = 2,
    EFortDamageVisualsState_MAX = 3
};

enum class EStructuralSupportCheck : uint8_t
{
    Stable = 0,
    Unstable = 1,
    Max_None = 2,
    EStructuralSupportCheck_MAX = 3
};

enum class EPlacementType : uint8_t
{
    Free = 0,
    Grid = 1,
    None = 2,
    EPlacementType_MAX = 3
};

enum class EBuildingAttachmentSide : uint8_t
{
    Front = 0,
    Back = 1,
    Any = 2,
    EBuildingAttachmentSide_MAX = 3
};

enum class EBuildingAttachmentSlot : uint8_t
{
    SLOT_Floor = 0,
    SLOT_Wall = 1,
    SLOT_Ceiling = 2,
    SLOT_None = 3,
    SLOT_MAX = 4
};

enum class EBuildingAnim : uint8_t
{
    EBA_None = 0,
    EBA_Building = 1,
    EBA_Breaking = 2,
    EBA_Destruction = 3,
    EBA_Placement = 4,
    EBA_DynamicLOD = 5,
    EBA_DynamicShrink = 6,
    EBA_MAX = 7
};

enum class EStructuralFloorPosition : uint8_t
{
    Top = 0,
    Bottom = 1,
    EStructuralFloorPosition_MAX = 2
};

enum class EStructuralWallPosition : uint8_t
{
    Left = 0,
    Right = 1,
    Front = 2,
    Back = 3,
    EStructuralWallPosition_MAX = 4
};

enum class EFortDefenderInteractionError : uint8_t
{
    None = 0,
    Obstructed = 1,
    NoEditPermission = 2,
    UsedByAnotherPlayer = 3,
    EFortDefenderInteractionError_MAX = 4
};

enum class EFortBounceType : uint8_t
{
    Hit = 0,
    Interact = 1,
    EditPlaced = 2,
    EFortBounceType_MAX = 3
};

enum class EFortConnectivityCubeFace : uint8_t
{
    Front = 0,
    Left = 1,
    Back = 2,
    Right = 3,
    Upper = 4,
    Lower = 5,
    MAX = 6
};

enum class EFortDecoPlacementQueryResults : uint8_t
{
    CanAdd = 0,
    ExistingTrap = 1,
    ExistingObject = 2,
    Obstructed = 3,
    NoLocation = 4,
    WrongType = 5,
    WrongShape = 6,
    BeingModified = 7,
    WrongTeam = 8,
    BlueprintFailure = 9,
    AbilityFailure = 10,
    RequiresPlayerBuildableActor = 11,
    NoEditPermission = 12,
    WrongZone = 13,
    EFortDecoPlacementQueryResults_MAX = 14
};

enum class EFortStructuralGridQueryResults : uint8_t
{
    CanAdd = 0,
    ExistingActor = 1,
    Obstructed = 2,
    NoStructuralSupport = 3,
    InvalidActor = 4,
    ReachedLimit = 5,
    NoEditPermission = 6,
    PatternNotPermittedByLayoutRequirement = 7,
    ResourceTypeNotPermittedByLayoutRequirement = 8,
    BuildingAtRequirementsDisabled = 9,
    BuildingOtherThanRequirementsDisabled = 10,
    EFortStructuralGridQueryResults_MAX = 11
};

enum class EFortBuildingInitializationReason : uint8_t
{
    StaticallyPlaced = 0,
    Spawned = 1,
    Replaced = 2,
    LoadedFromSave = 3,
    DynamicBuilderPlaced = 4,
    PlacementTool = 5,
    TrapTool = 6,
    None = 7,
    EFortBuildingInitializationReason_MAX = 8
};

enum class EFortBuildingPersistentState : uint8_t
{
    Default = 0,
    New = 1,
    Constructed = 2,
    Destroyed = 3,
    Searched = 4,
    None = 5,
    EFortBuildingPersistentState_MAX = 6
};

enum class EFortBuildingState : uint8_t
{
    Placement = 0,
    EditMode = 1,
    None = 2,
    EFortBuildingState_MAX = 3
};

enum class EFortTextureDataSlot : uint8_t
{
    Primary = 0,
    Secondary = 1,
    Tertiary = 2,
    Fourth = 3,
    NumSlots = 4,
    EFortTextureDataSlot_MAX = 5
};

enum class EFortTextureDataType : uint8_t
{
    Any = 0,
    OuterWall = 1,
    InnerWall = 2,
    Corner = 3,
    Floor = 4,
    Ceiling = 5,
    Trim = 6,
    Roof = 7,
    Pillar = 8,
    Shingle = 9,
    None = 10,
    EFortTextureDataType_MAX = 11
};

enum class EBuildingAttachmentType : uint8_t
{
    ATTACH_Floor = 0,
    ATTACH_Wall = 1,
    ATTACH_Ceiling = 2,
    ATTACH_Corner = 3,
    ATTACH_All = 4,
    ATTACH_WallThenFloor = 5,
    ATTACH_FloorAndStairs = 6,
    ATTACH_CeilingAndStairs = 7,
    ATTACH_None = 8,
    ATTACH_MAX = 9
};

enum class EFortBuildingType : uint8_t
{
    Wall = 0,
    Floor = 1,
    Corner = 2,
    Deco = 3,
    Prop = 4,
    Stairs = 5,
    Roof = 6,
    Pillar = 7,
    SpawnedItem = 8,
    Container = 9,
    Trap = 10,
    GenericCenterCellActor = 11,
    None = 12,
    EFortBuildingType_MAX = 13
};

enum class EAccessoryColorName : uint8_t
{
    EAccessoryColorName_AccessoryColor1 = 0,
    EAccessoryColorName_AccessoryColor2 = 1,
    EAccessoryColorName_AccessoryColor3 = 2,
    EAccessoryColorName_NumTypes = 3,
    EAccessoryColorName_MAX = 4
};

enum class ECustomHatType : uint8_t
{
    ECustomHatType_None = 0,
    ECustomHatType_Cap = 1,
    ECustomHatType_Helmet = 2,
    ECustomHatType_Mask = 3,
    ECustomHatType_Hat = 4,
    ECustomHatType_HeadReplacement = 5,
    ECustomHatType_MAX = 6
};

enum class EClothingColorName : uint8_t
{
    EClothingColorName_AccessoryColor1 = 0,
    EClothingColorName_AccessoryColor2 = 1,
    EClothingColorName_NumTypes = 2,
    EClothingColorName_MAX = 3
};

enum class EColorSwatchType : uint8_t
{
    EColorSwatchType_Skin = 0,
    EColorSwatchType_Hair = 1,
    EColorSwatchType_BodyAccessory = 2,
    EColorSwatchType_Accessory = 3,
    EColorSwatchType_NumTypes = 4,
    EColorSwatchType_MAX = 5
};

enum class ECharacterColorSwatchType : uint8_t
{
    ECharacterColorSwatchType_Skin = 0,
    ECharacterColorSwatchType_Hair = 1,
    ECharacterColorSwatchType_NumTypes = 2,
    ECharacterColorSwatchType_MAX = 3
};

enum class EDeployableBaseConstructionStatus : uint8_t
{
    Constructing = 0,
    Destroying = 1,
    Finished = 2,
    EDeployableBaseConstructionStatus_MAX = 3
};

enum class EDeployableBaseBuildingState : uint8_t
{
    Empty = 0,
    Built = 1,
    Unoccupied = 2,
    WaitingToBuild = 3,
    Building = 4,
    WaitingToDestroy = 5,
    Destroying = 6,
    WaitingToReset = 7,
    Resetting = 8,
    EDeployableBaseBuildingState_MAX = 9
};

enum class EDeployableBaseBoxType : uint8_t
{
    BuildSpace = 0,
    SaveSpace = 1,
    PlotSpace = 2,
    NumSpaceTypes = 3,
    EDeployableBaseBoxType_MAX = 4
};

enum class EFortSharedAnimationState : uint8_t
{
    Anim_Walk = 0,
    Anim_Run = 1,
    Anim_Turn = 2,
    Anim_Attack = 3,
    Anim_Death = 4,
    Anim_Knockback = 5,
    Anim_FullBodyHit = 6,
    Anim_Pushed = 7,
    Anim_Dance = 8,
    Anim_Idle = 9,
    Anim_RangedAttack = 10,
    Anim_MAX = 11
};

enum class EFortStatDisplayType : uint8_t
{
    Category = 0,
    Buff = 1,
    Debuff = 2,
    Neutral = 3,
    DoNotDisplay = 4,
    EFortStatDisplayType_MAX = 5
};

enum class EFortAbilityTargetSelectionUsage : uint8_t
{
    BothTargetingAndCanHit = 0,
    OnlyTargeting = 1,
    OnlyCanHit = 2,
    EFortAbilityTargetSelectionUsage_MAX = 3
};

enum class EFortDirectedMovementSpace : uint8_t
{
    WorldSpace = 0,
    ActorLocRelative = 1,
    ActorLocRotRelative = 2,
    CameraRelative = 3,
    EFortDirectedMovementSpace_MAX = 4
};

enum class EFortAbilityTargetDataPolicy : uint8_t
{
    ReplicateToServer = 0,
    SimulateOnServer = 1,
    EFortAbilityTargetDataPolicy_MAX = 2
};

enum class EFortProximityBasedGEApplicationType : uint8_t
{
    ApplyOnProximityPulse = 0,
    ApplyOnProximityTouch = 1,
    ApplyOnlyDuringProximityTouch = 2,
    EFortProximityBasedGEApplicationType_MAX = 3
};

enum class EFortDeliveryInfoBuildingActorSpecification : uint8_t
{
    All = 0,
    PlayerBuildable = 1,
    NonPlayerBuildable = 2,
    EFortDeliveryInfoBuildingActorSpecification_MAX = 3
};

enum class EDespawnAIType : uint8_t
{
    Relevancy = 0,
    Distance = 1,
    EDespawnAIType_MAX = 2
};

enum class EFortEncounterUtilityDesire : uint8_t
{
    Low = 0,
    Medium = 1,
    High = 2,
    VeryHigh = 3,
    Max_None = 4,
    EFortEncounterUtilityDesire_MAX = 5
};

enum class EFortAIDirectorFactorContribution : uint8_t
{
    Direct = 0,
    Inverse = 1,
    EFortAIDirectorFactorContribution_MAX = 2
};

enum class EFortAIDirectorEventContribution : uint8_t
{
    Increment = 0,
    Set = 1,
    EFortAIDirectorEventContribution_MAX = 2
};

enum class EFortAIWaveProgressSection : uint8_t
{
    SectionOne = 0,
    SectionTwo = 1,
    Max_None = 2,
    EFortAIWaveProgressSection_MAX = 3
};

enum class EFortEncounterState : uint8_t
{
    Uninitialized = 0,
    InitializingProperties = 1,
    InitializingRiftManager = 2,
    AwaitingActivation = 3,
    Active = 4,
    ReplacingRifts = 5,
    Max_None = 6,
    EFortEncounterState_MAX = 7
};

enum class EFortEncounterPacingState : uint8_t
{
    Ramp = 0,
    Peak = 1,
    Fade = 2,
    Rest = 3,
    Max_None = 4,
    EFortEncounterPacingState_MAX = 5
};

enum class EFortEncounterSequenceResult : uint8_t
{
    Success = 0,
    FailedEncounterInProgress = 1,
    Failed = 2,
    EFortEncounterSequenceResult_MAX = 3
};

enum class EAssignmentCreationResult : uint8_t
{
    AssignmentNotFoundOrCreated = 0,
    AssignmentCreated = 1,
    AssignmentFound = 2,
    EAssignmentCreationResult_MAX = 3
};

enum class ETagGoalScoringCategory : uint8_t
{
    Ignore = 0,
    HighInterest = 1,
    NumCategories = 2,
    ETagGoalScoringCategory_MAX = 3
};

enum class EFortAIPawnGender : uint8_t
{
    FAPG_Default = 0,
    FAPG_Female = 1,
    FAPG_Male = 2,
    FAPG_MAX = 3
};

enum class EFortAILevelRatingDisplayType : uint8_t
{
    DisplayRatingBasedOnDifficulty = 0,
    DisplayAIDifficultyAsRating = 1,
    DontDisplayRating = 2,
    EFortAILevelRatingDisplayType_MAX = 3
};

enum class EFortressAIType : uint8_t
{
    FAT_Dormant = 0,
    FAT_Cleaner = 1,
    FAT_DayWanderer = 2,
    FAT_NightWanderer = 3,
    FAT_DebugOnly = 4,
    FAT_Encounter = 5,
    FAT_MAX = 6
};

enum class ECorePerceptionTypes : uint8_t
{
    Sight = 0,
    Hearing = 1,
    Damage = 2,
    Touch = 3,
    Team = 4,
    Prediction = 5,
    MAX = 6
};

enum class ENavigationObstacleOverride : uint8_t
{
    UseMeshSettings = 0,
    ForceEnabled = 1,
    ForceDisabled = 2,
    ENavigationObstacleOverride_MAX = 3
};

enum class EFortPartialPathUsage : uint8_t
{
    Always = 0,
    OnlyGoalsOnDestructible = 1,
    Never = 2,
    EFortPartialPathUsage_MAX = 3
};

enum class EHotspotTypeConfigMode : uint8_t
{
    AlwaysAdd = 0,
    WhenNotDefined = 1,
    WhenNotValid = 2,
    EHotspotTypeConfigMode_MAX = 3
};

enum class EFortHotSpotPreview : uint8_t
{
    None = 0,
    Smashing = 1,
    Shooting = 2,
    EFortHotSpotPreview_MAX = 3
};

enum class EFortHotSpotDirection : uint8_t
{
    PositiveX = 0,
    NegativeX = 1,
    PositiveY = 2,
    NegativeY = 3,
    PositiveZ = 4,
    NegativeZ = 5,
    Any = 6,
    EFortHotSpotDirection_MAX = 7
};

enum class EFortHotSpotSlot : uint8_t
{
    Melee = 0,
    MeleeHuge = 1,
    Ranged = 2,
    None = 3,
    EFortHotSpotSlot_MAX = 4
};

enum class EBuildingFloorRailing : uint8_t
{
    None = 0,
    Balcony = 1,
    EBuildingFloorRailing_MAX = 2
};

enum class EBuildingStairsRailing : uint8_t
{
    None = 0,
    Partial = 1,
    Full = 2,
    EBuildingStairsRailing_MAX = 3
};

enum class EBuildingWallArea : uint8_t
{
    Regular = 0,
    Flat = 1,
    Special = 2,
    EBuildingWallArea_MAX = 3
};

enum class EAssignmentType : uint8_t
{
    Invalid = 0,
    Encounter = 1,
    World = 2,
    Enemy = 3,
    NumAssignmentTypes = 4,
    EAssignmentType_MAX = 5
};

enum class EFortAILODLevel : uint8_t
{
    Invalid = 0,
    Lowest = 1,
    Lower = 2,
    BelowNormal = 3,
    Normal = 4,
    AboveNormal = 5,
    MAX = 6
};

enum class ESkydivingDirection : uint8_t
{
    Center = 0,
    Right = 1,
    Left = 2,
    Forward = 3,
    Back = 4,
    ESkydivingDirection_MAX = 5
};

enum class ESourceSelectionMode : uint8_t
{
    MaxDifference = 0,
    ESourceSelectionMode_MAX = 1
};

enum class ESpeedWarpingAxisMode : uint8_t
{
    IKFootRootLocalX = 0,
    IKFootRootLocalY = 1,
    IKFootRootLocalZ = 2,
    WorldSpaceVectorInput = 3,
    ComponentSpaceVectorInput = 4,
    ActorSpaceVectorInput = 5,
    ESpeedWarpingAxisMode_MAX = 6
};

enum class EMontageInterrupt : uint8_t
{
    Any = 0,
    RootMotionOnly = 1,
    None = 2,
    EMontageInterrupt_MAX = 3
};

enum class EDeimosAnimState : uint8_t
{
    Idle = 0,
    Running = 1,
    Attack = 2,
    Dance = 3,
    Dying = 4,
    Died = 5,
    FullBodyHitReact = 6,
    AdditiveHitReact = 7,
    ActiveIdle = 8,
    Falling = 9,
    Frozen = 10,
    RangedAttack = 11,
    EDeimosAnimState_MAX = 12
};

enum class EFortCardinalDirection : uint8_t
{
    North = 0,
    East = 1,
    South = 2,
    West = 3,
    EFortCardinalDirection_MAX = 4
};

enum class EPlaneDirection : uint8_t
{
    Center = 0,
    Right = 1,
    Left = 2,
    Up = 3,
    Down = 4,
    EPlaneDirection_MAX = 5
};

enum class EDoghouseControlMode : uint8_t
{
    GroundControls = 0,
    AirControls = 1,
    MaxCount = 2,
    EDoghouseControlMode_MAX = 3
};

enum class EFreelookMode : uint8_t
{
    None = 0,
    Mouse = 1,
    Analog = 2,
    EFreelookMode_MAX = 3
};

enum class EAileronRollDirection : uint8_t
{
    None = 0,
    Right = 1,
    Left = 2,
    EAileronRollDirection_MAX = 3
};

enum class EExitCraftState : uint8_t
{
    None = 0,
    Spawned = 1,
    Landed = 2,
    SpawnBalloon = 3,
    GettingIntoPosition = 4,
    GettingIntoPosition_Simple = 5,
    WaitingForPawns = 6,
    Exiting = 7,
    EExitCraftState_MAX = 8
};

enum class EFortExitRequirements : uint8_t
{
    AnyPlayer = 0,
    WholeSquad = 1,
    EFortExitRequirements_MAX = 2
};

enum class EFortMutatorReturnValue : uint8_t
{
    Ignore = 0,
    Override = 1,
    OverrideReturn = 2,
    EFortMutatorReturnValue_MAX = 3
};

enum class EBarrierObjectiveDamageState : uint8_t
{
    Health_75 = 0,
    Health_50 = 1,
    Health_25 = 2,
    Health_10 = 3,
    Health_5 = 4,
    Health_4 = 5,
    Health_3 = 6,
    Health_2 = 7,
    Health_1 = 8,
    MAX = 9
};

enum class EBarrierFoodTeam : uint8_t
{
    Burger = 0,
    Tomato = 1,
    MAX = 2
};

enum class EDBNOMutatorType : uint8_t
{
    Default = 0,
    On = 1,
    Off = 2,
    EDBNOMutatorType_MAX = 3
};

enum class EControlPointState : uint8_t
{
    None = 0,
    Disabled = 1,
    Enabled = 2,
    EControlPointState_MAX = 3
};

enum class EAthenaMutatorEvaluators : uint8_t
{
    NoOverride = 0,
    ForceOverride = 1,
    Add = 2,
    Multiply = 3,
    EAthenaMutatorEvaluators_MAX = 4
};

enum class EHeistExitCraftState : uint8_t
{
    None = 0,
    Incoming = 1,
    Spawned = 2,
    Exited = 3,
    EHeistExitCraftState_MAX = 4
};

enum class EAthenaInventorySpawnOverride : uint8_t
{
    NoOverride = 0,
    Always = 1,
    IntialSpawn = 2,
    EAthenaInventorySpawnOverride_MAX = 3
};

enum class EAthenaLootDropOverride : uint8_t
{
    NoOverride = 0,
    ForceDrop = 1,
    ForceKeep = 2,
    EAthenaLootDropOverride_MAX = 3
};

enum class ERespawnRequirements : uint8_t
{
    RespawnOnly = 0,
    NoRespawnOnly = 1,
    Both = 2,
    ERespawnRequirements_MAX = 3
};

enum class EIndicatorDisplayMode : uint8_t
{
    Default = 0,
    Always = 1,
    Never = 2,
    EIndicatorDisplayMode_MAX = 3
};

enum class EAthenaTimeOfDayOverride : uint8_t
{
    NoOverride = 0,
    ForceDay = 1,
    ForceNight = 2,
    Custom = 3,
    EAthenaTimeOfDayOverride_MAX = 4
};

enum class ECoastState : uint8_t
{
    Idle = 0,
    Mount = 1,
    Coasting = 2,
    Pedaling = 3,
    PreDismount = 4,
    Dismount = 5,
    EndCoast = 6,
    ECoastState_MAX = 7
};

enum class EVehicleSessionEndReason : uint8_t
{
    Invalid = 0,
    NoPassengers = 1,
    EVehicleSessionEndReason_MAX = 2
};

enum class EVehicleMovementMode : uint8_t
{
    OnGround = 0,
    InAir = 1,
    WipeOut = 2,
    MaxCount = 3,
    EVehicleMovementMode_MAX = 4
};

enum class EAthenaVehicleSeats : uint8_t
{
    Driver = 0,
    Passenger1 = 1,
    Passenger2 = 2,
    Passenger3 = 3,
    Passenger4 = 4,
    Passenger5 = 5,
    MaxCount = 6,
    EAthenaVehicleSeats_MAX = 7
};

enum class EBounceCompressionState : uint8_t
{
    None = 0,
    Crouching = 1,
    Crouched = 2,
    Jumping = 3,
    Recoiling = 4,
    EBounceCompressionState_MAX = 5
};

enum class ENaturalSlideState : uint8_t
{
    None = 0,
    Entering = 1,
    InProgress = 2,
    Exiting = 3,
    ENaturalSlideState_MAX = 4
};

enum class EPowerSlideState : uint8_t
{
    None = 0,
    Entering = 1,
    InProgress = 2,
    Exiting = 3,
    EPowerSlideState_MAX = 4
};

enum class EFortFuelGadgetVisualType : uint8_t
{
    FuelMeter = 0,
    ChargeText = 1,
    Invalid = 2,
    EFortFuelGadgetVisualType_MAX = 3
};

enum class EFortAttributeDisplay : uint8_t
{
    BasicInt = 0,
    NegativeImpliesInfiniteInt = 1,
    BasicFloat = 2,
    NegativeImpliesInfiniteFloat = 3,
    BasicString = 4,
    NormalizedPercentage = 5,
    StringArray = 6,
    SlateBrush = 7,
    DoNotDisplay = 8,
    None_Max = 9,
    EFortAttributeDisplay_MAX = 10
};

enum class EBannerUsageContext : uint8_t
{
    Unknown = 0,
    BannerIcon = 1,
    PhysicalBanner = 2,
    Spray = 3,
    EBannerUsageContext_MAX = 4
};

enum class ETargetDistanceComparisonType : uint8_t
{
    TwoDimensions = 0,
    ThreeDimensions = 1,
    CollisionHalfHeightMultiplier = 2,
    ETargetDistanceComparisonType_MAX = 3
};

enum class EFortBuildingSoundType : uint8_t
{
    Construction = 0,
    GenericDestruction = 1,
    PlayerBuiltDestruction = 2,
    None = 3,
    EFortBuildingSoundType_MAX = 4
};

enum class EFortUICameraFrameTargetBoundingBehavior : uint8_t
{
    NoBounds = 0,
    AllBounds = 1,
    TopBoundOnly = 2,
    EFortUICameraFrameTargetBoundingBehavior_MAX = 3
};

enum class ECameraOrigin : uint8_t
{
    ViewTargetTransform = 0,
    BoneTransform = 1,
    ECameraOrigin_MAX = 2
};

enum class EChallengeBundleVisualStyle : uint8_t
{
    Normal = 0,
    BattlePassFree = 1,
    BattlePassPaid = 2,
    FreePassWeekly = 3,
    BattlePassWeekly = 4,
    FNBirthday = 5,
    FNTomatoStyle = 6,
    FNSkullTrooperStyle = 7,
    Fortnitemares = 8,
    FNHeist = 9,
    KoreaPCB_Neowiz = 10,
    FoodFight = 11,
    FourteenDays = 12,
    EChallengeBundleVisualStyle_MAX = 13
};

enum class EChallengeBundleQuestVisualStyle : uint8_t
{
    Free = 0,
    Premium = 1,
    FNBirthday = 2,
    FNTomatoStyle = 3,
    FNHeist = 4,
    FNSkullTrooperStyle = 5,
    Fortnitemares = 6,
    KoreaPCB_Neowiz = 7,
    FoodFight = 8,
    FourteenDays = 9,
    EChallengeBundleQuestVisualStyle_MAX = 10
};

enum class EChallengeBundleQuestUnlockType : uint8_t
{
    GrantWithBundle = 0,
    RequiresBattlePass = 1,
    DaysFromEventStart = 2,
    EChallengeBundleQuestUnlockType_MAX = 3
};

enum class EChallengeScheduleUnlockType : uint8_t
{
    Manually = 0,
    OnScheduleGranted = 1,
    DaysSinceEventStart = 2,
    EChallengeScheduleUnlockType_MAX = 3
};

enum class EFortCharacterCosmetic : uint8_t
{
    Head = 0,
    Texture = 1,
    Color = 2,
    Trinket = 3,
    Face = 4,
    Gadget = 5,
    Body = 6,
    ClassFlair = 7,
    Max_Invalid = 8,
    EFortCharacterCosmetic_MAX = 9
};

enum class EFortCustomMovement : uint8_t
{
    Default = 0,
    Driving = 1,
    Passenger = 2,
    Parachuting = 3,
    Skydiving = 4,
    Hover = 5,
    RemoteControl_Flying = 6,
    Ziplining = 7,
    Ballooning = 8,
    EFortCustomMovement_MAX = 9
};

enum class EChatRoomJoinHelperState : uint8_t
{
    Ready = 0,
    AttemptingJoin = 1,
    Joined = 2,
    AttemptingLeave = 3,
    EChatRoomJoinHelperState_MAX = 4
};

enum class EFortAnnouncementDisplayPreference : uint8_t
{
    Default_HUD = 0,
    QuestIntroduction = 1,
    QuestJournal = 2,
    EFortAnnouncementDisplayPreference_MAX = 3
};

enum class EFortAnnouncementChannel : uint8_t
{
    Primary = 0,
    Conversation = 1,
    Tutorial = 2,
    Max_None = 3,
    EFortAnnouncementChannel_MAX = 4
};

enum class EFortAnnouncementDelivery : uint8_t
{
    Created = 0,
    Received = 1,
    Ignored = 2,
    Active = 3,
    Stopped = 4,
    Max_None = 5,
    EFortAnnouncementDelivery_MAX = 6
};

enum class EAndroidAppStoreTypes : uint8_t
{
    Unset = 0,
    Epic = 1,
    Samsung = 2,
    EAndroidAppStoreTypes_MAX = 3
};

enum class EColorBlindMode : uint8_t
{
    Off = 0,
    Deuteranope = 1,
    Protanope = 2,
    Tritanope = 3,
    EColorBlindMode_MAX = 4
};

enum class ECloudFileState : uint8_t
{
    Unitialized = 0,
    Saving = 1,
    Loading = 2,
    Idle = 3,
    ECloudFileState_MAX = 4
};

enum class ECodeTokenPlatform : uint8_t
{
    PC = 0,
    PS4 = 1,
    XBOX = 2,
    ECodeTokenPlatform_MAX = 3
};

enum class EFortCollectionBookState : uint8_t
{
    Active = 0,
    Completed = 1,
    Claimed = 2,
    EFortCollectionBookState_MAX = 3
};

enum class EFortPIDValueGraphElements : uint8_t
{
    Proportional = 0,
    Integral = 1,
    Max_None = 2,
    EFortPIDValueGraphElements_MAX = 3
};

enum class EFortIntensityGraphElements : uint8_t
{
    ActualIntensity = 0,
    DesiredIntensity = 1,
    Max_None = 2,
    EFortIntensityGraphElements_MAX = 3
};

enum class EFortContributionGraphElements : uint8_t
{
    ProportionalLine = 0,
    IntegralLine = 1,
    TotalLine = 2,
    PendingLine = 3,
    ActionLine = 4,
    Max_None = 5,
    EFortContributionGraphElements_MAX = 6
};

enum class EFortFactorContributionType : uint8_t
{
    CurrentValue_Direct = 0,
    CurrentValue_Inverse = 1,
    AverageValue_Direct = 2,
    AverageValue_Inverse = 3,
    EFortFactorContributionType_MAX = 4
};

enum class EFortAIDirectorFactor : uint8_t
{
    PlayerDamageThreat = 0,
    ObjectiveDamageThreat = 1,
    ObjectivePathCost = 2,
    PlayerPathCost = 3,
    PlayerMovement = 4,
    TrapsEffective = 5,
    PlayerWander = 6,
    NearbyEnemyPresence = 7,
    OffensiveResources = 8,
    DefensiveResources = 9,
    Boredom = 10,
    ArtilleryVulnerability = 11,
    Max_None = 12,
    EFortAIDirectorFactor_MAX = 13
};

enum class EFortCombatFactors : uint8_t
{
    PlayerDamageThreat = 0,
    ObjectiveDamageThreat = 1,
    ObjectivePathCost = 2,
    PlayerPathCost = 3,
    PlayerMovement = 4,
    TrapsEffective = 5,
    PlayerWander = 6,
    NearbyEnemyPresence = 7,
    OffensiveResources = 8,
    DefensiveResources = 9,
    Boredom = 10,
    ArtilleryVulnerability = 11,
    Max_None = 12,
    EFortCombatFactors_MAX = 13
};

enum class EFortAIDirectorEventParticipant : uint8_t
{
    Target = 0,
    Source = 1,
    Either = 2,
    Max_None = 3,
    EFortAIDirectorEventParticipant_MAX = 4
};

enum class EFortCombatThresholds : uint8_t
{
    Low = 0,
    Medium = 1,
    High = 2,
    Extreme = 3,
    Max_None = 4,
    EFortCombatThresholds_MAX = 5
};

enum class EFortBaseWeaponDamage : uint8_t
{
    Combat = 0,
    Environmental = 1,
    EFortBaseWeaponDamage_MAX = 2
};

enum class EFortWeaponCoreAnimation : uint8_t
{
    Melee = 0,
    Pistol = 1,
    Shotgun = 2,
    PaperBlueprint = 3,
    Rifle = 4,
    MeleeOneHand = 5,
    MachinePistol = 6,
    RocketLauncher = 7,
    GrenadeLauncher = 8,
    GoingCommando = 9,
    AssaultRifle = 10,
    TacticalShotgun = 11,
    SniperRifle = 12,
    TrapPlacement = 13,
    ShoulderLauncher = 14,
    AbilityDecoTool = 15,
    Crossbow = 16,
    C4 = 17,
    RemoteControl = 18,
    DualWield = 19,
    AR_BullPup = 20,
    AR_ForwardGrip = 21,
    MedPackPaddles = 22,
    SMG_P90 = 23,
    AR_DrumGun = 24,
    Consumable_Small = 25,
    Consumable_Large = 26,
    Balloon = 27,
    MountedTurret = 28,
    CreativeTool = 29,
    MAX = 30
};

enum class EFortReloadFXState : uint8_t
{
    ReloadStart = 0,
    ReloadCartridge = 1,
    ReloadEnd = 2,
    Max_None = 3,
    EFortReloadFXState_MAX = 4
};

enum class EFortWeaponSoundChannel : uint8_t
{
    NormalA = 0,
    NormalB = 1,
    LowAmmo = 2,
    Degraded = 3,
    Max_None = 4,
    EFortWeaponSoundChannel_MAX = 5
};

enum class EFortWeaponSoundState : uint8_t
{
    Normal = 0,
    LowAmmo = 1,
    Degraded = 2,
    Max_None = 3,
    EFortWeaponSoundState_MAX = 4
};

enum class EFortMontageInputType : uint8_t
{
    WindowClickOrHold = 0,
    WindowHoldOnly = 1,
    InstantClick = 2,
    EFortMontageInputType_MAX = 3
};

enum class EFortAbilityTargetingSource : uint8_t
{
    Camera = 0,
    PawnForward = 1,
    PawnTowardsFocus = 2,
    WeaponForward = 3,
    WeaponTowardsFocus = 4,
    Custom = 5,
    Max_None = 6,
    EFortAbilityTargetingSource_MAX = 7
};

enum class EFortAmmoType : uint8_t
{
    Pistol = 0,
    Shotgun = 1,
    Assault = 2,
    Sniper = 3,
    Energy = 4,
    EFortAmmoType_MAX = 5
};

enum class EFortEncryptionStatus : uint8_t
{
    ENCRYPTED = 0,
    RELEASED = 1,
    EFortEncryptionStatus_MAX = 2
};

enum class EFortSentenceAudioPreference : uint8_t
{
    AudioAsset = 0,
    FeedbackBank = 1,
    EFortSentenceAudioPreference_MAX = 2
};

enum class ECreativePortalManagerValidityResult : uint8_t
{
    Valid = 0,
    Invalid = 1,
    ECreativePortalManagerValidityResult_MAX = 2
};

enum class ERealEstateOffsetType : uint8_t
{
    CustomOffsetFromCorner = 0,
    Center = 1,
    ERealEstateOffsetType_MAX = 2
};

enum class ETimespanAsTextFormat : uint8_t
{
    DaysHoursMinutesSeconds = 0,
    Colons = 1,
    Approximate = 2,
    ETimespanAsTextFormat_MAX = 3
};

enum class EFortDefenderSubtype : uint8_t
{
    AssaultRifle = 0,
    Pistol = 1,
    Melee = 2,
    Sniper = 3,
    Shotgun = 4,
    Invalid = 5,
    EFortDefenderSubtype_MAX = 6
};

enum class EHordeTierStartStatus : uint8_t
{
    ReadyToStart = 0,
    WaitingForPlayer = 1,
    WaitingForDBM = 2,
    GenericNotReadyToStart = 3,
    EHordeTierStartStatus_MAX = 4
};

enum class EHordeWaveStingerType : uint8_t
{
    WaveSuccess = 0,
    WaveFailure = 1,
    WaveIncoming = 2,
    WaveStarted = 3,
    EHordeWaveStingerType_MAX = 4
};

enum class EQueueActionType : uint8_t
{
    Plot = 0,
    ZoneCleanup = 1,
    EnvironmentActorRestoration = 2,
    EQueueActionType_MAX = 3
};

enum class EAthenaPIEStartupMode : uint8_t
{
    UseDefaults = 0,
    Warmup = 1,
    WarmupPaused = 2,
    Aircraft = 3,
    AircraftPaused = 4,
    Gameplay = 5,
    EAthenaPIEStartupMode_MAX = 6
};

enum class FDynamicBuildOrder : uint8_t
{
    X = 0,
    Y = 1,
    Z = 2,
    None = 3,
    FDynamicBuildOrder_MAX = 4
};

enum class EFortFeedbackBroadcastFilter : uint8_t
{
    FFBF_Speaker = 0,
    FFBF_SpeakerTeam = 1,
    FFBF_SpeakerAdressee = 2,
    FFBF_HumanPvP_Team1 = 3,
    FFBF_HumanPvP_Team2 = 4,
    FFBF_None_Max = 5,
    FFBF_MAX = 6
};

enum class EFortFeedbackSelectionMethod : uint8_t
{
    FFSM_Instigator = 0,
    FFSM_Recipient = 1,
    FFSM_TeamWitness = 2,
    FFSM_EnemyWitness = 3,
    FFSM_Random = 4,
    FFSM_Priority_IRTE = 5,
    FFSM_AllPawns = 6,
    FFSM_Announcer = 7,
    FFSM_MAX = 8
};

enum class EFortFeedbackAddressee : uint8_t
{
    FFA_Instigator = 0,
    FFA_Recipient = 1,
    FFA_All = 2,
    FFA_MAX = 3
};

enum class EFortFeedbackContext : uint8_t
{
    FFC_Instigator = 0,
    FFC_Recipient = 1,
    FFC_TeamWitness = 2,
    FFC_EnemyWitness = 3,
    FFC_AllPawns = 4,
    FFC_Announcer = 5,
    FFC_None_Max = 6,
    FFC_MAX = 7
};

enum class EFortFootstepPosition : uint8_t
{
    Parallel = 0,
    Above = 1,
    Below = 2,
    AboveOrBelowAndVisible = 3,
    Max_None = 4,
    EFortFootstepPosition_MAX = 5
};

enum class EFortFootstepSurfaceType : uint8_t
{
    Default = 0,
    Wood = 1,
    Stone = 2,
    Metal = 3,
    Water = 4,
    Snow = 5,
    Ice = 6,
    Max_None = 7,
    EFortFootstepSurfaceType_MAX = 8
};

enum class EFortFootstepAudioType : uint8_t
{
    Crouch = 0,
    CrouchSprint = 1,
    Walk = 2,
    Sprint = 3,
    Jump = 4,
    Land = 5,
    LandHard = 6,
    Max_None = 7,
    EFortFootstepAudioType_MAX = 8
};

enum class ESubGameAccessReason : uint8_t
{
    NoAccess = 0,
    OpenAccess = 1,
    TokenItemAccess = 2,
    XboxHomeSharingAccess = 3,
    XboxServiceOutageAccess = 4,
    LimitedAccess = 5,
    ESubGameAccessReason_MAX = 6
};

enum class EPartyFeedbackType : uint8_t
{
    PartyInProgressPlayerJoined = 0,
    PartyInProgressPlayerLeft = 1,
    Default = 2,
    EPartyFeedbackType_MAX = 3
};

enum class EFriendFeedbackType : uint8_t
{
    FriendRequestSent = 0,
    FriendRequestReceived = 1,
    FriendRequestAccepted = 2,
    Default = 3,
    EFriendFeedbackType_MAX = 4
};

enum class EClampType : uint8_t
{
    Minimum = 0,
    Maximum = 1,
    EClampType_MAX = 2
};

enum class EDynamicSoundOverride : uint8_t
{
    Cue = 0,
    Wave = 1,
    EDynamicSoundOverride_MAX = 2
};

enum class EPlayerQueueType : uint8_t
{
    Player = 0,
    Spectator = 1,
    Broadcaster = 2,
    EPlayerQueueType_MAX = 3
};

enum class EPlaylistAdvertisementType : uint8_t
{
    None = 0,
    New = 1,
    Updated = 2,
    EPlaylistAdvertisementType_MAX = 3
};

enum class EFortInputFilterLevel : uint8_t
{
    None = 0,
    Touch = 1,
    Gamepad = 2,
    Mouse = 3,
    EFortInputFilterLevel_MAX = 4
};

enum class EEventTournamentType : uint8_t
{
    Online = 0,
    Onsite = 1,
    Unknown = 2,
    EEventTournamentType_MAX = 3
};

enum class EAircraftLaunchReason : uint8_t
{
    StdTimerAllPlayers = 0,
    EarlyTimerAllPlayers = 1,
    StdTimerMostPlayers = 2,
    EarlyTimerMostPlayers = 3,
    StdTimerFewPlayers = 4,
    EAircraftLaunchReason_MAX = 5
};

enum class EFortAbilityCostSource : uint8_t
{
    Stamina = 0,
    Durability = 1,
    AmmoMagazine = 2,
    AmmoPrimary = 3,
    Item = 4,
    EFortAbilityCostSource_MAX = 5
};

enum class EFortGameplayAbilityActivation : uint8_t
{
    Passive = 0,
    Triggered = 1,
    Active = 2,
    EFortGameplayAbilityActivation_MAX = 3
};

enum class EFortAIWeaponUsage : uint8_t
{
    NoWeaponUsage = 0,
    UsesRangedWeapon = 1,
    UsesMeleeWeapon = 2,
    EFortAIWeaponUsage_MAX = 3
};

enum class EFortGameplayAbilityMontageSectionToPlay : uint8_t
{
    FirstSection = 0,
    RandomSection = 1,
    TestedRandomSection = 2,
    EFortGameplayAbilityMontageSectionToPlay_MAX = 3
};

enum class EJumpBoostPackState : uint8_t
{
    Idle = 0,
    Boost = 1,
    Hovering = 2,
    Falling = 3,
    None = 4,
    EJumpBoostPackState_MAX = 5
};

enum class EMedicPackState : uint8_t
{
    Idle = 0,
    Active = 1,
    None = 2,
    EMedicPackState_MAX = 3
};

enum class EFortGameplayCueSourceCondition : uint8_t
{
    AnySource = 0,
    LocalPlayerSource = 1,
    NonLocalPlayerSource = 2,
    EFortGameplayCueSourceCondition_MAX = 3
};

enum class EFortGameplayCueAttachType : uint8_t
{
    AttachToTarget = 0,
    DoNotAttach = 1,
    EFortGameplayCueAttachType_MAX = 2
};

enum class EPvPGameEndReasons : uint8_t
{
    PVPGER_TeamScoreLimit = 0,
    PVPGER_LastManStanding = 1,
    PVPGER_TimeExpired = 2,
    PVPGER_MissionCompletion = 3,
    PVPGER_MAX = 4
};

enum class EFortServerGameMode : uint8_t
{
    Idle = 0,
    LobbyPvE = 1,
    LobbyPvP = 2,
    ZonePvP = 3,
    ZonePvE = 4,
    EFortServerGameMode_MAX = 5
};

enum class EFortBanHammerNotificationAction : uint8_t
{
    BanAndKick = 0,
    Kick = 1,
    EFortBanHammerNotificationAction_MAX = 2
};

enum class ETeamChatRoomState : uint8_t
{
    NotCreated = 0,
    Creating = 1,
    Created = 2,
    Timeout = 3,
    ETeamChatRoomState_MAX = 4
};

enum class EFortScalabilityMode : uint8_t
{
    LowPower = 0,
    Frontend = 1,
    EFortScalabilityMode_MAX = 2
};

enum class ESavedAccountType : uint8_t
{
    None = 0,
    Facebook = 1,
    Google = 2,
    Epic = 3,
    Device = 4,
    Headless = 5,
    Refresh = 6,
    ESavedAccountType_MAX = 7
};

enum class EFortMobileFPSMode : uint8_t
{
    Mode_20Fps = 0,
    Mode_30Fps = 1,
    Mode_60Fps = 2,
    Mode_MAX = 3
};

enum class EFortConsoleFPSMode : uint8_t
{
    Mode_30Fps = 0,
    Mode_30Fps_Unlocked = 1,
    Mode_60Fps = 2,
    Mode_MAX = 3
};

enum class EFortGiftWrapType : uint8_t
{
    System = 0,
    UserFree = 1,
    UserUnlock = 2,
    UserConsumable = 3,
    Message = 4,
    EFortGiftWrapType_MAX = 5
};

enum class EFortGlobalAction : uint8_t
{
    TrapConfirm = 0,
    TrapPicker = 1,
    BuildConfirm = 2,
    PerformBuildingEditInteraction = 3,
    PerformBuildingImprovementInteraction = 4,
    SwitchQuickBar = 5,
    Use = 6,
    Reload = 7,
    InventoryOrChatHold = 8,
    GamepadChangeMaterialOrHarvestHold = 9,
    GamepadNextWeaponOrHarvestHold = 10,
    ChangeMaterial = 11,
    Fire = 12,
    RotatePrimitiveClockwise = 13,
    Gadget1 = 14,
    Gadget2 = 15,
    Ability1 = 16,
    Ability2 = 17,
    Ability3 = 18,
    ToggleFullScreenMap = 19,
    ToggleInventory = 20,
    Jump = 21,
    Crouch = 22,
    VehicleExit = 23,
    ShoppingCartCoast = 24,
    VehicleJump = 25,
    GolfCartEBrake = 26,
    VehicleChangeSeat = 27,
    GolfCartForward = 28,
    GolfCartReverse = 29,
    GolfCartHonk = 30,
    Count = 31,
    EFortGlobalAction_MAX = 32
};

enum class EChunkInstallState : uint8_t
{
    NotInstalled = 0,
    Pending = 1,
    Installed = 2,
    Unknown = 3,
    EChunkInstallState_MAX = 4
};

enum class EFortAccountLinkingUIConfig : uint8_t
{
    Disabled = 0,
    Default = 1,
    ExternalViewerOnly = 2,
    FullExternal = 3,
    EFortAccountLinkingUIConfig_MAX = 4
};

enum class EFortHelpContentLocation : uint8_t
{
    Top = 0,
    Bottom = 1,
    Max = 2
};

enum class EFortHelpItemType : uint8_t
{
    Header = 0,
    Entry = 1,
    Max = 2
};

enum class ESpecializationType : uint8_t
{
    Tier1 = 0,
    Tier2 = 1,
    Tier3 = 2,
    Tier4 = 3,
    NumTiers = 4,
    ESpecializationType_MAX = 5
};

enum class EFortHeroLoadoutPerkType : uint8_t
{
    Commander = 0,
    Leader = 1,
    Standard = 2,
    EFortHeroLoadoutPerkType_MAX = 3
};

enum class EFortSupportBonusType : uint8_t
{
    Normal = 0,
    Tactical = 1,
    Max_None = 2,
    EFortSupportBonusType_MAX = 3
};

enum class EFortHexTileAdjacency : uint8_t
{
    North = 0,
    NorthEast = 1,
    SouthEast = 2,
    South = 3,
    SouthWest = 4,
    NorthWest = 5,
    Max_None = 6,
    EFortHexTileAdjacency_MAX = 7
};

enum class ESquadSlotType : uint8_t
{
    HeroSquadPrimary = 0,
    HeroSquadSupport = 1,
    HeroSquadTactical = 2,
    HeroSquadMissionDefender = 3,
    SurvivorSquadLeadSurvivor = 4,
    SurvivorSquadSurvivor = 5,
    DefenderSquadMember = 6,
    ExpeditionSquadMember = 7,
    ESquadSlotType_MAX = 8
};

enum class EFortHomebaseSquadSlotType : uint8_t
{
    GroundSlot = 0,
    SupportSlot = 1,
    TacticalSlot = 2,
    Max_None = 3,
    EFortHomebaseSquadSlotType_MAX = 4
};

enum class EFortHomebaseSquadType : uint8_t
{
    AttributeSquad = 0,
    CombatSquad = 1,
    DefenderSquad = 2,
    ExpeditionSquad = 3,
    Max_None = 4,
    EFortHomebaseSquadType_MAX = 5
};

enum class EHomebaseNodeType : uint8_t
{
    Gadget = 0,
    Utility = 1,
    Hidden = 2,
    EHomebaseNodeType_MAX = 3
};

enum class EFortHuskAnimType : uint8_t
{
    Basic = 0,
    Dwarf = 1,
    BlasterBig = 2,
    Weak = 3,
    TinyHead = 4,
    Beehive = 5,
    Husky = 6,
    Sploder = 7,
    Zapper = 8,
    EFortHuskAnimType_MAX = 9
};

enum class EFortInputGameMode : uint8_t
{
    SaveTheWorld = 0,
    Athena = 1,
    EFortInputGameMode_MAX = 2
};

enum class EFortIntensityCurveSequenceType : uint8_t
{
    Sequence = 0,
    Loop = 1,
    Random = 2,
    Max_None = 3,
    EFortIntensityCurveSequenceType_MAX = 4
};

enum class EItemEvolutionRestrictionReason : uint8_t
{
    NoEvolutions = 0,
    BelowMaximumLevel = 1,
    VaultOverflow = 2,
    MissingCatalyst = 3,
    MissingCosts = 4,
    NoRarityUpgrade = 5,
    InUseByCrafting = 6,
    EItemEvolutionRestrictionReason_MAX = 7
};

enum class EItemUpgradeRestrictionReason : uint8_t
{
    NoAdditionalLevels = 0,
    MaximumLevelAchieved = 1,
    VaultOverflow = 2,
    EItemUpgradeRestrictionReason_MAX = 3
};

enum class EFortTemplateAccess : uint8_t
{
    Normal = 0,
    Trusted = 1,
    Private = 2,
    EFortTemplateAccess_MAX = 3
};

enum class EItemProfileType : uint8_t
{
    Common = 0,
    Campaign = 1,
    Athena = 2,
    EItemProfileType_MAX = 3
};

enum class EFortKickReason : uint8_t
{
    NotKicked = 0,
    GenericKick = 1,
    WasBanned = 2,
    EncryptionRequired = 3,
    CrossPlayRestriction = 4,
    ClientIdRestriction = 5,
    EFortKickReason_MAX = 6
};

enum class ELobbyMissionGeneratorDetailsRequirement : uint8_t
{
    Unknown = 0,
    NotRequired = 1,
    Required = 2,
    ELobbyMissionGeneratorDetailsRequirement_MAX = 3
};

enum class ELootQuotaLevel : uint8_t
{
    Unlimited = 0,
    Level1 = 1,
    Level2 = 2,
    Level3 = 3,
    Level4 = 4,
    Level5 = 5,
    Level6 = 6,
    Level7 = 7,
    Level8 = 8,
    Level9 = 9,
    Level10 = 10,
    Level11 = 11,
    Level12 = 12,
    Level13 = 13,
    Level14 = 14,
    Level15 = 15,
    Level16 = 16,
    Level17 = 17,
    NumLevels = 18,
    ELootQuotaLevel_MAX = 19
};

enum class EFortMatchmakingType : uint8_t
{
    Gathering = 0,
    CriticalMission = 1,
    QuickPlay = 2,
    Session = 3,
    EFortMatchmakingType_MAX = 4
};

enum class EFortSessionHelperJoinResult : uint8_t
{
    NoResult = 0,
    ReservationSuccess = 1,
    ReservationFailure_PartyLimitReached = 2,
    ReservationFailure_IncorrectPlayerCount = 3,
    ReservationFailure_RequestTimedOut = 4,
    ReservationFailure_ReservationNotFound = 5,
    ReservationFailure_ReservationDenied = 6,
    ReservationFailure_ReservationDenied_Banned = 7,
    ReservationFailure_ReservationRequestCanceled = 8,
    ReservationFailure_ReservationInvalid = 9,
    ReservationFailure_BadSessionId = 10,
    ReservationFailure_ReservationDenied_ContainsExistingPlayers = 11,
    ReservationFailure_GeneralError = 12,
    ReservationFailure_NoSubsystem = 13,
    ReservationFailure_NoIdentity = 14,
    ReservationFailure_InvalidSession = 15,
    ReservationFailure_InvalidUser = 16,
    ReservationFailure_EncryptionKey = 17,
    ReservationFailure_RefreshAuth = 18,
    ReservationFailure_AlreadyJoiningDuringReserve = 19,
    ReservationFailure_AlreadyJoiningDuringSkip = 20,
    JoinSessionSuccess = 21,
    JoinSessionFailure_SessionIsFull = 22,
    JoinSessionFailure_SessionDoesNotExist = 23,
    JoinSessionFailure_CouldNotRetrieveAddress = 24,
    JoinSessionFailure_AlreadyInSession = 25,
    JoinSessionFailure_UnknownError = 26,
    JoinSessionFailure_InvalidSession = 27,
    JoinSessionFailure_InvalidSearchResultIndex = 28,
    JoinSessionFailure_AlreadyJoiningDuringJoin = 29,
    SearchPassFailure_NoSessionHelper = 30,
    SearchPassFailure_InvalidUser = 31,
    SearchPassFailure_NoIdentity = 32,
    SearchPassFailure_InvalidSearchResult = 33,
    SearchPassFailure_InvalidSearchResultIndex = 34,
    JoinSessionCanceled = 35,
    EFortSessionHelperJoinResult_MAX = 36
};

enum class EFortMatchmakingPool : uint8_t
{
    Any = 0,
    Desktop = 1,
    PS4 = 2,
    XboxOne = 3,
    Mobile = 4,
    Test = 5,
    Switch = 6,
    All = 7,
    EFortMatchmakingPool_MAX = 8
};

enum class EFortMatchmakingPrivacyConfiguration : uint8_t
{
    UserPartyConfigured = 0,
    ForcePrivate = 1,
    ForcePublic = 2,
    EFortMatchmakingPrivacyConfiguration_MAX = 3
};

enum class EMatchmakingFlags : uint8_t
{
    None = 0,
    CreateNewOnly = 1,
    NoReservation = 2,
    Private = 4,
    UseWorldDataOwner = 8,
    EMatchmakingFlags_MAX = 9
};

enum class EMatchmakingStartLocation : uint8_t
{
    Lobby = 0,
    Game = 1,
    CreateNew = 2,
    FindSingle = 3,
    EMatchmakingStartLocation_MAX = 4
};

enum class EMatchmakingCancelReasonV2 : uint8_t
{
    Explicit = 0,
    JoinedParty = 1,
    LeftParty = 2,
    PartyMemberJoined = 3,
    PartyMemberLeft = 4,
    PartyMemberCanceled = 5,
    PlayReplay = 6,
    UIDestroyed = 7,
    PCDestroyed = 8,
    AppBackgrounded = 9,
    HotfixOutdated = 10,
    TournamentOver = 11,
    NotInParty = 12,
    CrossplayBlocked = 13,
    TournamentCrossplayBlocked = 14,
    Unknown = 15,
    EMatchmakingCancelReasonV2_MAX = 16
};

enum class EMatchmakingErrorV2 : uint8_t
{
    Success = 0,
    Canceled = 1,
    NeedUpdate = 2,
    VersionMismatch = 3,
    NotLoggedIn = 4,
    NoIdentityInterface = 5,
    NoSessionInterface = 6,
    AlreadyInSession = 7,
    FindSessionFailure = 8,
    FailedToQueryEncryptionKey = 9,
    FailedToRefreshAuthToken = 10,
    FailedToCleanupSession = 11,
    FailedToJoinSession = 12,
    FailedToTravelToSession = 13,
    Unauthorized = 14,
    BannedFromAthena = 15,
    BannedFromAthenaForExploit = 16,
    BannedFromAthenaForTeaming = 17,
    BannedFromAthenaForTeamKilling = 18,
    InvalidCustomMatchKey = 19,
    FailedToContactGameServices = 20,
    FailedToConnectToMMS = 21,
    MMSCommunicationIssue = 22,
    ServiceReturnedError = 23,
    PlaylistNoLongerAvailable = 24,
    CrossplayUnsetWithInputDevicePoolShift = 25,
    CrossplayNeededForTournamentMatch = 26,
    MatchmakingDisabled = 27,
    UnknownError = 28,
    EMatchmakingErrorV2_MAX = 29
};

enum class EAthenaFilterDisplayType : uint8_t
{
    UseCategoryName = 0,
    ShowFilterString = 1,
    EAthenaFilterDisplayType_MAX = 2
};

enum class ESocialImportPanelPlatform : uint8_t
{
    Facebook = 0,
    VK = 1,
    Steam = 2,
    Xbox = 3,
    Playstation = 4,
    Switch = 5,
    ESocialImportPanelPlatform_MAX = 6
};

enum class EFortCreativePlotPermission : uint8_t
{
    Private = 0,
    Public = 1,
    EFortCreativePlotPermission_MAX = 2
};

enum class ETwitchViewerStatusType : uint8_t
{
    TwitchViewerStatus_Unknown = 0,
    TwitchViewerStatus_Nonsubscriber = 1,
    TwitchViewerStatus_Subscriber = 2,
    TwitchViewerStatus_Broadcaster = 3,
    TwitchViewerStatus_Max = 4
};

enum class EMegaStormState : uint8_t
{
    GatheringActorList = 0,
    DamagingActors = 1,
    EMegaStormState_MAX = 2
};

enum class EFortMinigameWarmupType : uint8_t
{
    Stasis = 0,
    Respawn = 1,
    EFortMinigameWarmupType_MAX = 2
};

enum class EFortMinigameExec : uint8_t
{
    Yes = 0,
    No = 1,
    EFortMinigameExec_MAX = 2
};

enum class EFortMinigamePostGameSpawnLocationSetting : uint8_t
{
    IslandStart = 0,
    PreGameLocation = 1,
    EFortMinigamePostGameSpawnLocationSetting_MAX = 2
};

enum class EFortMinigamePlayerSpawnLocationSetting : uint8_t
{
    SpawnPads = 0,
    Air = 1,
    EFortMinigamePlayerSpawnLocationSetting_MAX = 2
};

enum class EMinigameCaptureObjectiveState : uint8_t
{
    NotCaptured = 0,
    Captured = 1,
    EMinigameCaptureObjectiveState_MAX = 2
};

enum class EMinigameScoreType : uint8_t
{
    Time = 0,
    PointTotal = 1,
    EMinigameScoreType_MAX = 2
};

enum class EFortMinigameStatOperation : uint8_t
{
    Equal = 0,
    Less = 1,
    Greater = 2,
    LessOrEqual = 3,
    GreaterOrEqual = 4,
    EFortMinigameStatOperation_MAX = 5
};

enum class EFortMinigameStatScope : uint8_t
{
    Group = 0,
    Team = 1,
    Player = 2,
    EFortMinigameStatScope_MAX = 3
};

enum class EFortMiniMapIconRotation : uint8_t
{
    EFMMIR_None = 0,
    EFMMIR_Absolute = 1,
    EFMMIR_Relative = 2,
    EFMMIR_MAX = 3
};

enum class EFortMiniMapContext : uint8_t
{
    EFMC_MiniMap = 0,
    EFMC_FullScreenMap = 1,
    EFMC_MAX = 2
};

enum class EFortMiniMapHeight : uint8_t
{
    EFMH_Equal = 0,
    EFMH_Below = 1,
    EFMH_Above = 2,
    EFMH_MAX = 3
};

enum class EFortCheatMissionGenType : uint8_t
{
    NewGeneration = 0,
    OldGeneration = 1,
    Max_None = 2,
    EFortCheatMissionGenType_MAX = 3
};

enum class EFortOptionGenerationResult : uint8_t
{
    NoOptionsGenerated = 0,
    NewOptionsGenerated = 1,
    ExistingOptionsGenerated = 2,
    EFortOptionGenerationResult_MAX = 3
};

enum class EPollActorsInVolumeTypes : uint8_t
{
    DesignerPlacedOnly = 0,
    PlayerBuiltOnly = 1,
    All = 2,
    EPollActorsInVolumeTypes_MAX = 3
};

enum class EMissionReplyTypes : uint8_t
{
    Handled = 0,
    NotHandled = 1,
    EMissionReplyTypes_MAX = 2
};

enum class EMissionStormShieldState : uint8_t
{
    IDLE = 0,
    GROWING = 1,
    SHRINKING = 2,
    MAX = 3
};

enum class ETimerOverrideSetting : uint8_t
{
    DefaultBehavior = 0,
    ForceShow = 1,
    ForceHide = 2,
    ShowAtEnd = 3,
    ETimerOverrideSetting_MAX = 4
};

enum class EFortMtxPlatform : uint8_t
{
    Epic = 0,
    PSN = 1,
    Live = 2,
    Shared = 3,
    EpicPC = 4,
    EpicPCKorea = 5,
    IOSAppStore = 6,
    EpicAndroid = 7,
    Nintendo = 8,
    WeGame = 9,
    Samsung = 10,
    EFortMtxPlatform_MAX = 11
};

enum class EFortMusicSectionType : uint8_t
{
    Intro = 0,
    Loop = 1,
    Outro = 2,
    Max_None = 3,
    EFortMusicSectionType_MAX = 4
};

enum class EFortMusicSectionStopBehavior : uint8_t
{
    Crossfade = 0,
    AllowFadeOut = 1,
    EFortMusicSectionStopBehavior_MAX = 2
};

enum class EFortMusicCombatIntensity : uint8_t
{
    Low = 0,
    Medium = 1,
    High = 2,
    VeryHigh = 3,
    Max_None = 4,
    EFortMusicCombatIntensity_MAX = 5
};

enum class EMusicChannel : uint8_t
{
    VoiceA = 0,
    VoiceB = 1,
    Max_None = 2,
    EMusicChannel_MAX = 3
};

enum class EMusicFadeStyles : uint8_t
{
    CrossFade = 0,
    FadeOutThenIn = 1,
    Max_None = 2,
    EMusicFadeStyles_MAX = 3
};

enum class EFortAreaFlag : uint8_t
{
    Default = 0,
    Obstacle = 1,
    Smashable = 2,
    Unwalkable = 3,
    Interactable = 4,
    EFortAreaFlag_MAX = 5
};

enum class EFortNavLinkPattern : uint8_t
{
    Floor = 0,
    Stairs = 1,
    Roof = 2,
    Manual = 3,
    EFortNavLinkPattern_MAX = 4
};

enum class EFortNamedNavmesh : uint8_t
{
    Husk = 0,
    Smasher = 1,
    MAX = 2
};

enum class EPathUndermineEvent : uint8_t
{
    Predicted = 0,
    Started = 1,
    Finished = 2,
    EPathUndermineEvent_MAX = 3
};

enum class EPathObstacleAction : uint8_t
{
    Melee = 0,
    Ignore = 1,
    AbortMoveAsFailed = 2,
    FinishMoveAsSucceeded = 3,
    EPathObstacleAction_MAX = 4
};

enum class EWardAffectType : uint8_t
{
    AffectsBothStartAndEndPoints = 0,
    AffectsOnlyStartPoints = 1,
    AffectsOnlyEndPoints = 2,
    EWardAffectType_MAX = 3
};

enum class EFortControlRecoveryBehavior : uint8_t
{
    DefaultControl = 0,
    LimitedControl = 1,
    ChainControl = 2,
    EFortControlRecoveryBehavior_MAX = 3
};

enum class EFortPawnPushSize : uint8_t
{
    FFPS_Normal = 0,
    FPPS_Player = 1,
    FPPS_Large = 2,
    FPPS_SuperLarge = 3,
    EFortPawnPushSize_MAX = 4
};

enum class EFortAnnouncerTeamVocalChords : uint8_t
{
    Team1 = 0,
    Team2 = 1,
    Max_None = 2,
    EFortAnnouncerTeamVocalChords_MAX = 3
};

enum class EFortBadMatchTeamSize : uint8_t
{
    Unspecified = 0,
    SmallTeam = 1,
    LargeTeam = 2,
    EFortBadMatchTeamSize_MAX = 3
};

enum class EFortBadMatchTriggerOperation : uint8_t
{
    LessThan = 0,
    LessThanOrEqual = 1,
    Equal = 2,
    GreaterThan = 3,
    GreaterThanOrEqual = 4,
    EFortBadMatchTriggerOperation_MAX = 5
};

enum class EFortRewardType : uint8_t
{
    Default = 0,
    Missed = 1,
    Max_None = 2,
    EFortRewardType_MAX = 3
};

enum class EFortReplicatedStat : uint8_t
{
    MonsterKills = 0,
    MonsterDamagePoints = 1,
    PlayerKills = 2,
    WoodGathered = 3,
    StoneGathered = 4,
    MetalGathered = 5,
    Deaths = 6,
    BuildingsBuilt = 7,
    BuildingsBuilt_Wood = 8,
    BuildingsBuilt_Stone = 9,
    BuildingsBuilt_Metal = 10,
    BuildingsUpgraded_Wood2 = 11,
    BuildingsUpgraded_Wood3 = 12,
    BuildingsUpgraded_Stone2 = 13,
    BuildingsUpgraded_Stone3 = 14,
    BuildingsUpgraded_Metal2 = 15,
    BuildingsUpgraded_Metal3 = 16,
    BuildingsDestroyed = 17,
    Repair_Wood = 18,
    Repair_Stone = 19,
    Repair_Metal = 20,
    FlagsCaptured = 21,
    FlagsReturned = 22,
    ContainersLooted = 23,
    CraftingPoints = 24,
    TrapPlacementPoints = 25,
    TrapActivationPoints = 26,
    TotalScore = 27,
    OldTotalScore = 28,
    CombatScore = 29,
    BuildingScore = 30,
    UtilityScore = 31,
    BadgesScore = 32,
    None = 33,
    MAX = 34
};

enum class EFortReplenishmentType : uint8_t
{
    Restricted = 0,
    ClampMin = 1,
    Add = 2,
    Ability = 3,
    EFortReplenishmentType_MAX = 4
};

enum class EFortPickupTossState : uint8_t
{
    NotTossed = 0,
    InProgress = 1,
    AtRest = 2,
    EFortPickupTossState_MAX = 3
};

enum class EFortPickupSpawnSource : uint8_t
{
    Unset = 0,
    PlayerElimination = 1,
    Chest = 2,
    SupplyDrop = 3,
    AmmoBox = 4,
    EFortPickupSpawnSource_MAX = 5
};

enum class EFortPickupSourceTypeFlag : uint8_t
{
    Other = 0,
    Player = 1,
    Destruction = 2,
    Container = 4,
    AI = 8,
    Tossed = 16,
    FloorLoot = 32,
    EFortPickupSourceTypeFlag_MAX = 33
};

enum class EFortPlayerAnimBodyType : uint8_t
{
    Small = 0,
    Medium = 1,
    Large = 2,
    EFortPlayerAnimBodyType_MAX = 3
};

enum class EQuickbarSlots : uint8_t
{
    HarvestingTool = 0,
    Weapon1 = 1,
    Weapon2 = 2,
    Weapon3 = 3,
    Gadget1 = 4,
    Gadget2 = 5,
    Ability1 = 6,
    Ability2 = 7,
    Ability3 = 8,
    EQuickbarSlots_MAX = 9
};

enum class EFortPickerToDisplay : uint8_t
{
    TrapPicker = 0,
    WeaponPicker = 1,
    SocialPicker = 2,
    ChatPicker = 3,
    NotePicker = 4,
    EmotePicker = 5,
    SquadQuickChatPicker = 6,
    EFortPickerToDisplay_MAX = 7
};

enum class EMapZoomingMode : uint8_t
{
    None = 0,
    ZoomingIn = 1,
    ZoomingOut = 2,
    EMapZoomingMode_MAX = 3
};

enum class ECameraStateRestoreReason : uint8_t
{
    Unknown = 0,
    ChangedFollowTarget = 1,
    ChangedCameraType = 2,
    InvokedHotKey = 3,
    Scrubbed = 4,
    Restored = 5,
    MAX = 6
};

enum class EFollow : uint8_t
{
    NextTeammate = 0,
    PreviousTeammate = 1,
    SpecialActor = 2,
    EFollow_MAX = 3
};

enum class EFortMotionYawAxis : uint8_t
{
    Yaw = 0,
    Roll = 1,
    EFortMotionYawAxis_MAX = 2
};

enum class EFortInputActionGroup : uint8_t
{
    AllModes = 0,
    Combat = 1,
    Building = 2,
    Movement = 3,
    Edit = 4,
    Death = 5,
    Cinematic = 6,
    Picker = 7,
    Other = 8,
    Vehicle = 9,
    ShoppingCart = 10,
    GolfCart = 11,
    QuadCrasher = 12,
    Biplane = 13,
    Jackal = 14,
    Hamsterball = 15,
    Spectating = 16,
    FullscreenMap = 17,
    CreativeMoveToolEquipped = 18,
    CreativeMoveObjectsFreely = 19,
    CreativeMoveBuildingsOnGrid = 20,
    CreativeFlying = 21,
    CombatAndBuilding = 22,
    EFortInputActionGroup_MAX = 23
};

enum class EFortInputActionType : uint8_t
{
    Press = 0,
    Click = 1,
    Hold = 2,
    Release = 3,
    EFortInputActionType_MAX = 4
};

enum class EFortInputDevice : uint8_t
{
    Mouse = 0,
    Keyboard = 1,
    Gamepad = 2,
    Touch = 3,
    EFortInputDevice_MAX = 4
};

enum class EItemInteractionStatus : uint8_t
{
    Interrupted = 0,
    Completed = 1,
    TimedOut = 2,
    EItemInteractionStatus_MAX = 3
};

enum class EItemInteractionType : uint8_t
{
    Search = 0,
    LockOnSearch = 1,
    None = 2,
    EItemInteractionType_MAX = 3
};

enum class EFortPawnStasisMode : uint8_t
{
    None = 0,
    NoMovement = 1,
    NoMovementOrTurning = 2,
    NoMovementOrFalling = 3,
    EFortPawnStasisMode_MAX = 4
};

enum class EBackpackType : uint8_t
{
    Jetpack = 0,
    Medic = 1,
    StormTracker = 2,
    Glider = 3,
    EBackpackType_MAX = 4
};

enum class ETrustedPlatformType : uint8_t
{
    Unknown = 0,
    Untrusted = 1,
    PS4 = 2,
    XboxOne = 3,
    Switch = 4,
    ETrustedPlatformType_MAX = 5
};

enum class ETeamMemberState : uint8_t
{
    None = 0,
    FIRST_CHAT_MESSAGE = 1,
    NeedAmmoHeavy = 1,
    NeedAmmoLight = 2,
    NeedAmmoMedium = 3,
    NeedAmmoShells = 4,
    NeedAmmoRocket = 5,
    ChatBubble = 6,
    EnemySpotted = 7,
    NeedBandages = 8,
    NeedMaterials = 9,
    NeedShields = 10,
    NeedWeapon = 11,
    LAST_CHAT_MESSAGE = 11,
    MAX = 12
};

enum class EFortPawnState : uint8_t
{
    Default = 0,
    InCombat = 1,
    DBNO = 2,
    IsReviving = 4,
    BeingRevived = 8,
    Dead = 16,
    EFortPawnState_MAX = 17
};

enum class EVehicleTrickType : uint8_t
{
    None = 0,
    RollIncrement = 1,
    ReverseRollIncrement = 2,
    YawIncrement = 3,
    ReverseYawIncrement = 4,
    PitchIncrement = 5,
    ReversePitchIncrement = 6,
    HeightIncrement = 7,
    DistanceIncrement = 8,
    AirTimeIncrement = 9,
    ShoppingCart_Flying = 10,
    ShoppingCart_Stooping = 11,
    StartedLanding = 12,
    FailedLanding = 13,
    Cancelled = 14,
    StuckLanding = 15,
    Count = 16,
    EVehicleTrickType_MAX = 17
};

enum class EVehicleTrickAxis : uint8_t
{
    X = 0,
    XNeg = 1,
    Y = 2,
    YNeg = 3,
    Z = 4,
    ZNeg = 5,
    Count = 6,
    EVehicleTrickAxis_MAX = 7
};

enum class EDBNOType : uint8_t
{
    On = 0,
    Off = 1,
    NotWhenRespawning = 2,
    EDBNOType_MAX = 3
};

enum class ERewardPlacementBonusType : uint8_t
{
    Solo = 0,
    Duo = 1,
    Squad = 2,
    LargeTeam = 3,
    None = 4,
    TwoTeam = 5,
    MediumTeam = 6,
    QuickSolo = 7,
    QuickDuo = 8,
    QuickSquad = 9,
    QuickLargeTeam = 10,
    QuickTwoTeam = 11,
    QuickMediumTeam = 12,
    SinglePlacement = 13,
    ERewardPlacementBonusType_MAX = 14
};

enum class ERewardTimePlayedType : uint8_t
{
    Default = 0,
    NoReward = 1,
    FlatValue = 2,
    ERewardTimePlayedType_MAX = 3
};

enum class EPlaylistUIExtensionSlot : uint8_t
{
    Primary = 0,
    TopRightCorner = 1,
    GameInfoBox = 2,
    EPlaylistUIExtensionSlot_MAX = 3
};

enum class EAthenaVictoryUIType : uint8_t
{
    Default = 0,
    Heist = 1,
    LTM = 2,
    Domination = 3,
    EAthenaVictoryUIType_MAX = 4
};

enum class EAthenaWinCondition : uint8_t
{
    LastManStanding = 0,
    LastManStandingIncludingAllies = 1,
    TimedTeamFinalFight = 2,
    FirstToGoalScore = 3,
    TimedLastMenStanding = 4,
    MutatorControlled = 5,
    MutatorControlledGoalScore = 6,
    EAthenaWinCondition_MAX = 7
};

enum class EAthenaRespawnLocation : uint8_t
{
    LastDeath = 0,
    CreativePlayerStart = 1,
    EAthenaRespawnLocation_MAX = 2
};

enum class EAthenaRespawnType : uint8_t
{
    None = 0,
    InfiniteRespawn = 1,
    InfiniteRespawnExceptStorm = 2,
    EAthenaRespawnType_MAX = 3
};

enum class EPlaysetOffsetType : uint8_t
{
    CustomOffsetFromCorner = 0,
    Center = 1,
    EPlaysetOffsetType_MAX = 2
};

enum class EProfileGoState : uint8_t
{
    None = 0,
    SettlingLocation = 1,
    RunningCommands = 2,
    CompletedScenario = 3,
    Summary = 4,
    Completed = 5,
    EProfileGoState_MAX = 6
};

enum class EFortPointsFromNavGraphGoalPathDistanceFilterOperator : uint8_t
{
    AllGoalsInRange = 0,
    AnyGoalInRange = 1,
    EFortPointsFromNavGraphGoalPathDistanceFilterOperator_MAX = 2
};

enum class EFortTestGoalActorDot : uint8_t
{
    Dot3D = 0,
    Dot2D = 1,
    EFortTestGoalActorDot_MAX = 2
};

enum class EDistanceMode : uint8_t
{
    DistItemToContext = 0,
    DistItemGoalActorToContext = 1,
    DistItemToItemGoalActor = 2,
    EDistanceMode_MAX = 3
};

enum class ECountAIAssignedToType : uint8_t
{
    Goal = 0,
    Actor = 1,
    Assignment = 2,
    ECountAIAssignedToType_MAX = 3
};

enum class ETwoPointSolverRotationA : uint8_t
{
    PointAToQuerier = 0,
    QuerierToPointA = 1,
    PointAToQuerierWithRandomOffset = 2,
    QuerierToPointAWithRandomOffset = 3,
    Custom = 4,
    ETwoPointSolverRotationA_MAX = 5
};

enum class EObjectiveStatusUpdateType : uint8_t
{
    Always = 0,
    OnPercent = 1,
    OnComplete = 2,
    Never = 3,
    EObjectiveStatusUpdateType_MAX = 4
};

enum class EFortQuestRewardType : uint8_t
{
    BasicRewards = 0,
    BasicPlusSingleChoice = 1,
    EFortQuestRewardType_MAX = 2
};

enum class EQuestVisualStyle : uint8_t
{
    Normal = 0,
    Hard = 1,
    EQuestVisualStyle_MAX = 2
};

enum class EFortQuestType : uint8_t
{
    Task = 0,
    Optional = 1,
    DailyQuest = 2,
    TransientQuest = 3,
    SurvivorQuest = 4,
    Achievement = 5,
    Onboarding = 6,
    StreamBroadcaster = 7,
    StreamViewer = 8,
    StreamSubscriber = 9,
    Athena = 10,
    AthenaDailyQuest = 11,
    AthenaEvent = 12,
    AthenaChallengeBundleQuest = 13,
    All = 14,
    EFortQuestType_MAX = 15
};

enum class ECosmeticType : uint8_t
{
    Image = 0,
    Widget = 1,
    ECosmeticType_MAX = 2
};

enum class EFortQuestMapNodeLabelPosition : uint8_t
{
    Top = 0,
    Bottom = 1,
    EFortQuestMapNodeLabelPosition_MAX = 2
};

enum class EFortQuestMapNodeType : uint8_t
{
    MandatoryQuest = 0,
    SideQuest = 1,
    EFortQuestMapNodeType_MAX = 2
};

enum class EFortQuestObjectiveItemEvent : uint8_t
{
    Craft = 0,
    Collect = 1,
    Acquire = 2,
    Consume = 3,
    OpenCardPack = 4,
    PurchaseCardPack = 5,
    Convert = 6,
    Upgrade = 7,
    UpgradeRarity = 8,
    QuestComplete = 9,
    AssignWorker = 10,
    LevelUpCollectionBook = 11,
    LevelUpAthenaSeason = 12,
    LevelUpBattlePass = 13,
    GainAthenaSeasonXp = 14,
    HasItem = 15,
    HasAccumulatedItem = 16,
    SlotInCollection = 17,
    AlterationRespec = 18,
    AlterationUpgrade = 19,
    HasCompletedQuest = 20,
    HasAssignedWorker = 21,
    HasUpgraded = 22,
    HasConverted = 23,
    HasUpgradedRarity = 24,
    HasLeveledUpCollectionBook = 25,
    HasLeveledUpAthenaSeason = 26,
    HasLeveledUpBattlePass = 27,
    HasGainedAthenaSeasonXp = 28,
    MinigameTime = 29,
    Max_None = 30,
    EFortQuestObjectiveItemEvent_MAX = 31
};

enum class EFortQuestObjectiveStatEvent : uint8_t
{
    Kill = 0,
    TeamKill = 1,
    KillContribution = 2,
    Damage = 3,
    Visit = 4,
    Land = 5,
    Emote = 6,
    Spray = 7,
    Toy = 8,
    Build = 9,
    BuildingEdit = 10,
    BuildingRepair = 11,
    BuildingUpgrade = 12,
    PlaceTrap = 13,
    Complete = 14,
    Craft = 15,
    Collect = 16,
    Win = 17,
    Interact = 18,
    TeamInteract = 19,
    Destroy = 20,
    Ability = 21,
    WaveComplete = 22,
    Custom = 23,
    ComplexCustom = 24,
    Client = 25,
    AthenaRank = 26,
    AthenaOutlive = 27,
    RevivePlayer = 28,
    Heal = 29,
    EarnVehicleTrickPoints = 30,
    VehicleAirTime = 31,
    TimeElapsed = 32,
    NumGameplayEvents = 33,
    Acquire = 34,
    Consume = 35,
    OpenCardPack = 36,
    PurchaseCardPack = 37,
    Convert = 38,
    Upgrade = 39,
    UpgradeRarity = 40,
    QuestComplete = 41,
    AssignWorker = 42,
    CollectExpedition = 43,
    CollectSuccessfulExpedition = 44,
    LevelUpCollectionBook = 45,
    LevelUpAthenaSeason = 46,
    LevelUpBattlePass = 47,
    GainAthenaSeasonXp = 48,
    HasItem = 49,
    HasAccumulatedItem = 50,
    SlotInCollection = 51,
    AlterationRespec = 52,
    AlterationUpgrade = 53,
    HasCompletedQuest = 54,
    HasAssignedWorker = 55,
    HasUpgraded = 56,
    HasConverted = 57,
    HasUpgradedRarity = 58,
    HasLeveledUpCollectionBook = 59,
    HasLeveledUpAthenaSeason = 60,
    HasLeveledUpBattlePass = 61,
    HasGainedAthenaSeasonXp = 62,
    MinigameDynamicEvent = 63,
    MinigameComplete = 64,
    MinigameDeath = 65,
    MinigameAssist = 66,
    Max_None = 67,
    EFortQuestObjectiveStatEvent_MAX = 68
};

enum class EFortChallengeBundleInfoLockedReasonCode : uint8_t
{
    Unlocked = 0,
    NoKnownUnlockMethod = 1,
    PurchaseTheBattlePass = 2,
    ReachSpecificTier = 3,
    TimeLeftBeforeUnlock = 4,
    EFortChallengeBundleInfoLockedReasonCode_MAX = 5
};

enum class EFortQuestState : uint8_t
{
    Inactive = 0,
    Active = 1,
    Completed = 2,
    Claimed = 3,
    EFortQuestState_MAX = 4
};

enum class ERegisteredPlayerUnregistrationStatus : uint8_t
{
    Registered = 0,
    UnregistrationStarting = 1,
    UnregistrationWaitingForInitialLock = 2,
    UnregistrationWaitingForScoreSave = 3,
    UnregistrationWaitingForFinalSave = 4,
    UnregistrationWaitingForProfileUnlock = 5,
    UnregistrationComplete = 6,
    ERegisteredPlayerUnregistrationStatus_MAX = 7
};

enum class EEventMatchScreen : uint8_t
{
    None = 0,
    ActivePlayerGrid = 1,
    EliminatedPlayerGrid = 2,
    MatchStatus = 3,
    Scoreboard = 4,
    EEventMatchScreen_MAX = 5
};

enum class EDroneFollowMode : uint8_t
{
    None = 0,
    ForceFacingLocation = 1,
    ForceFacingFollowedPlayer = 2,
    TetherToFollowedPlayer = 3,
    MAX = 4
};

enum class EClassRepNodeMapping : uint8_t
{
    NotRouted = 0,
    RelevantAllConnections = 1,
    Spatialize_Static = 2,
    Spatialize_Dynamic = 3,
    Spatialize_Dormancy = 4,
    EClassRepNodeMapping_MAX = 5
};

enum class EFortSafeZoneState : uint8_t
{
    None = 0,
    Starting = 1,
    Holding = 2,
    Shrinking = 3,
    EFortSafeZoneState_MAX = 4
};

enum class EFortUIScoreType : uint8_t
{
    Combat = 0,
    Building = 1,
    Utility = 2,
    Badges = 3,
    Bonus = 4,
    Total = 5,
    Max_None = 6,
    EFortUIScoreType_MAX = 7
};

enum class EFortScriptedActionEnvironment : uint8_t
{
    FrontEnd = 0,
    GameServer = 1,
    GameClient = 2,
    Max_None = 3,
    EFortScriptedActionEnvironment_MAX = 4
};

enum class EFortScriptedActionSource : uint8_t
{
    Quest = 0,
    Token = 1,
    Manual = 2,
    Max_None = 3,
    EFortScriptedActionSource_MAX = 4
};

enum class EServerManifestOutputFormat : uint8_t
{
    FlatFile = 0,
    Json = 1,
    HTTP = 2,
    EServerManifestOutputFormat_MAX = 3
};

enum class EServerManifestCommandType : uint8_t
{
    Move = 0,
    Copy = 1,
    Unknown = 2,
    EServerManifestCommandType_MAX = 3
};

enum class EFortSessionHelperJoinState : uint8_t
{
    NotJoining = 0,
    RequestingReservation = 1,
    FailedReservation = 2,
    WaitingOnGame = 3,
    AttemptingJoin = 4,
    JoiningSession = 5,
    FailedJoin = 6,
    CanceledJoin = 7,
    EFortSessionHelperJoinState_MAX = 8
};

enum class EFortSoundIndicatorTypes : uint8_t
{
    Generic = 0,
    FootStep = 1,
    Gunshot = 2,
    Chest = 3,
    Glider = 4,
    Plane = 5,
    COUNT = 6,
    EFortSoundIndicatorTypes_MAX = 7
};

enum class EFortSpawnActorTime : uint8_t
{
    PostPlaylistLoad = 0,
    StartOfStormHoldTime = 1,
    EFortSpawnActorTime_MAX = 2
};

enum class EFortEventConditionType : uint8_t
{
    EFEC_StatCompare = 0,
    EFEC_CanCraft = 1,
    EFEC_MAX = 2
};

enum class EFortCompare : uint8_t
{
    EFC_LessThan = 0,
    EFC_LessThanOrEqual = 1,
    EFC_GreaterThan = 2,
    EFC_GreaterThanOrEqual = 3,
    EFC_Equals = 4,
    EFC_MAX = 5
};

enum class EFortEventRepeat : uint8_t
{
    EFER_Inactive = 0,
    EFER_Always = 1,
    EFER_OncePerPlayer = 2,
    EFER_OncePerCampaign = 3,
    EFER_OncePerMap = 4,
    EFER_MAX = 5
};

enum class EFortStatType : uint8_t
{
    Fortitude = 0,
    Offense = 1,
    Resistance = 2,
    Technology = 3,
    Fortitude_Team = 4,
    Offense_Team = 5,
    Resistance_Team = 6,
    Technology_Team = 7,
    Invalid = 8,
    EFortStatType_MAX = 9
};

enum class ESupplyDropItemTrackType : uint8_t
{
    SpecialActors = 0,
    ESupplyDropItemTrackType_MAX = 1
};

enum class ESupplyDropSpawnType : uint8_t
{
    SafeZoneDriven = 0,
    ItemDeliveryManagement = 1,
    ESupplyDropSpawnType_MAX = 2
};

enum class EFortAutoTestState : uint8_t
{
    InitialLoad = 0,
    Login = 1,
    FrontendLoad = 2,
    FrontendPvELoad = 3,
    FrontendPvETest = 4,
    PvEMatchmaking = 5,
    ZoneLoad = 6,
    ZoneTest = 7,
    Finished = 8,
    MAX = 9
};

enum class EReplaySmokeTestStep : uint8_t
{
    Setup = 0,
    TogglePause = 1,
    StepForward = 2,
    StepBackward = 3,
    StepToEnd = 4,
    StepToBeginning = 5,
    SpeedUpPlayback = 6,
    SlowDownPlayback = 7,
    ToggleHideTimeline = 8,
    IterateCameraModes = 9,
    TogglePlayerOutlines = 10,
    ToggleNamePlates = 11,
    ToggleReplayRegion = 12,
    ZoomIn = 13,
    ZoomOut = 14,
    ToggleAutoFollowThirdPerson = 15,
    IncreaseExposure = 16,
    DecreaseExposure = 17,
    SetAutoExposure = 18,
    IncreaseAperture = 19,
    DecreaseAperture = 20,
    IncreaseFocalLength = 21,
    DecreaseFocalLength = 22,
    IncreaseFocusDistance = 23,
    DecreaseFocusDistance = 24,
    SetAutoFocus = 25,
    ToggleDamageEffects = 26,
    ToggleHideUI = 27,
    ToggleMap = 28,
    Reset = 29,
    MAX = 30
};

enum class EFortTheaterType : uint8_t
{
    Standard = 0,
    Elder = 1,
    PvP = 2,
    PvP2 = 3,
    Tutorial = 4,
    TutorialGate = 5,
    Max_None = 6,
    EFortTheaterType_MAX = 7
};

enum class EFortTheaterMapTileType : uint8_t
{
    Normal = 0,
    CriticalMission = 1,
    AlwaysActive = 2,
    Outpost = 3,
    NonMission = 4,
    PvPFOB = 5,
    EFortTheaterMapTileType_MAX = 6
};

enum class EFortMapNavigationDirection : uint8_t
{
    North = 0,
    NorthEast = 1,
    East = 2,
    SouthEast = 3,
    South = 4,
    SouthWest = 5,
    West = 6,
    NorthWest = 7,
    Invalid = 8,
    EFortMapNavigationDirection_MAX = 9
};

enum class EFortMissionQuestValidityResult : uint8_t
{
    Invalid = 0,
    InvalidNotPlayable = 1,
    ValidLinked = 2,
    ValidObjectiveCondition = 3,
    ValidFallback = 4,
    EFortMissionQuestValidityResult_MAX = 5
};

enum class ECollectionSelectionMethod : uint8_t
{
    TierAsIndex = 0,
    TierAsIndexOverflowToLastValid = 1,
    Modulo = 2,
    Random = 3,
    None = 4,
    ECollectionSelectionMethod_MAX = 5
};

enum class EMessageFeedSubject : uint8_t
{
    ToyOwner = 0,
    OtherPlayerInteractingWithToy = 1,
    EMessageFeedSubject_MAX = 2
};

enum class EMessageFeedRelationshipFilter : uint8_t
{
    Anyone = 0,
    SquadAndTeamMembers = 1,
    SquadMembersOnly = 2,
    SelfOnly = 3,
    EMessageFeedRelationshipFilter_MAX = 4
};

enum class ETrackVerticality : uint8_t
{
    Floor = 0,
    Ramp = 1,
    GradualRamp = 2,
    Max_None = 3,
    ETrackVerticality_MAX = 4
};

enum class ETrackIncline : uint8_t
{
    NoNeighbor = 0,
    Flat = 1,
    Up = 2,
    Down = 3,
    GradualUp = 4,
    GradualDown = 5,
    Max_None = 6,
    ETrackIncline_MAX = 7
};

enum class ETrackPieceType : uint8_t
{
    None = 0,
    Straight = 1,
    Turn = 2,
    TShape = 3,
    Cross = 4,
    Max_None = 5,
    ETrackPieceType_MAX = 6
};

enum class ETrackDirection : uint8_t
{
    YNegative = 0,
    XPositive = 1,
    YPositive = 2,
    XNegative = 3,
    Max_None = 4,
    ETrackDirection_MAX = 5
};

enum class EFortCreativeAdColorPreset : uint8_t
{
    Default = 0,
    Emphasized = 1,
    Common = 2,
    Uncommon = 3,
    Rare = 4,
    Epic = 5,
    Legendary = 6,
    EFortCreativeAdColorPreset_MAX = 7
};

enum class EFortCreativeAdType : uint8_t
{
    Default = 0,
    Playset = 1,
    Toy = 2,
    Game = 3,
    Island = 4,
    Knob = 5,
    EFortCreativeAdType_MAX = 6
};

enum class EFortLobbyType : uint8_t
{
    Default = 0,
    Tournament = 1,
    Creative = 2,
    EFortLobbyType_MAX = 3
};

enum class EFortMatchmakingViolatorStyle : uint8_t
{
    None = 0,
    Basic = 1,
    HighStakes = 2,
    Showdown = 3,
    EFortMatchmakingViolatorStyle_MAX = 4
};

enum class EFortMatchmakingTileStyle : uint8_t
{
    None = 0,
    Special = 1,
    HighStakes = 2,
    Showdown = 3,
    EFortMatchmakingTileStyle_MAX = 4
};

enum class EFortErrorSeverity : uint8_t
{
    Unspecified = 0,
    Silent = 1,
    Passive = 2,
    Blocking = 3,
    SevereBlocking = 4,
    EFortErrorSeverity_MAX = 5
};

enum class EFortPickerMode : uint8_t
{
    BuildingCategory = 0,
    TrapCategory = 1,
    WeaponCategory = 2,
    SocialCategory = 3,
    Building = 4,
    Trap = 5,
    TrapRadial = 6,
    Weapon = 7,
    Social = 8,
    DirectPickEmote = 9,
    DirectPickSpray = 10,
    SquadQuickChat = 11,
    WeaponsSlotted = 12,
    EFortPickerMode_MAX = 13
};

enum class EPTTState : uint8_t
{
    Enabled = 0,
    MicDisabled = 1,
    AllSoundDisabled = 2,
    EPTTState_MAX = 3
};

enum class EFortPlayerRole : uint8_t
{
    Player = 0,
    LiveSpectator = 1,
    ReplaySpectator = 2,
    EFortPlayerRole_MAX = 3
};

enum class EMobileInteractionIconTypes : uint8_t
{
    Interact = 0,
    Swap = 1,
    Revive = 2,
    Blocked = 3,
    MAX = 4
};

enum class EAthenaPickerType : uint8_t
{
    EditMode = 0,
    Interact = 1,
    MAX = 2
};

enum class EFortGliderType : uint8_t
{
    Glider = 0,
    Umbrella = 1,
    EFortGliderType_MAX = 2
};

enum class EItemTileViewDisplayType : uint8_t
{
    World = 0,
    Outpost = 1,
    Account = 2,
    DeployableBase = 3,
    Max = 4
};

enum class EOutpostBuildings : uint8_t
{
    StormShield = 0,
    CraftingTable = 1,
    Fabricator = 2,
    HarvestingOptimizer = 3,
    StorageVault = 4,
    POST = 5,
    EOutpostBuildings_MAX = 6
};

enum class EFortClientAnnouncementQueueType : uint8_t
{
    Toasts = 0,
    Stickies = 1,
    Max = 2
};

enum class EFortNotificationQueueType : uint8_t
{
    Toasts = 0,
    Stickies = 1,
    Messages = 2,
    Max = 3
};

enum class EFortDialogResult : uint8_t
{
    Confirmed = 0,
    Declined = 1,
    Ignored = 2,
    Killed = 3,
    TimedOut = 4,
    Unknown = 5,
    EFortDialogResult_MAX = 6
};

enum class ETutorialType : uint8_t
{
    None = 0,
    Callout = 1,
    GuardScreen = 2,
    WidgetIntro = 3,
    Highlight = 4,
    ETutorialType_MAX = 5
};

enum class EFortBangType : uint8_t
{
    Invalid = 0,
    Custom = 1,
    PlayTab = 2,
    HeroesTab = 3,
    VaultTab = 4,
    StoreTab = 5,
    FriendsButton = 6,
    PartyInviteButton = 7,
    SubGameAccessChanged = 8,
    DailyRewardsButton = 9,
    QuestsButton = 10,
    CompletedExpeditions = 11,
    MainMenu = 12,
    HelpMenu = 13,
    VaultSchematics = 14,
    VaultLeadSurvivors = 15,
    VaultSurvivors = 16,
    VaultHeroes = 17,
    VaultDefenders = 18,
    VaultResources = 19,
    VaultMelee = 20,
    VaultRanged = 21,
    VaultConsumables = 22,
    VaultIngredients = 23,
    VaultTraps = 24,
    CosmeticsTab = 25,
    CosmeticsOutfit = 26,
    CosmeticGlider = 27,
    CosmeticContrail = 28,
    CosmeticBattleBus = 29,
    CosmeticVehicle = 30,
    CosmeticItemWrap = 31,
    CosmeticCallingCard = 32,
    CosmeticMapMarker = 33,
    CosmeticMusicPack = 34,
    CosmeticPetSkin = 35,
    CosmeticLoadingScreen = 36,
    CosmeticBackpack = 37,
    CosmeticHat = 38,
    CosmeticPickaxe = 39,
    CosmeticDance = 40,
    AthenaDirectedAcquisitionTab = 41,
    PlayerBanners = 42,
    STWCommand = 43,
    STWCommand_Heroes = 44,
    STWCommand_Heroes_Manage = 45,
    STWCommand_Heroes_HeroLoadout = 46,
    STWCommand_Heroes_Defenders = 47,
    STWCommand_Heroes_Expeditions = 48,
    STWCommand_Survivors = 49,
    STWCommand_Survivors_Manage = 50,
    STWCommand_Survivors_Squads = 51,
    STWCommand_Upgrades = 52,
    STWCommand_Research = 53,
    STWCommand_AccountXP = 54,
    STWArmory = 55,
    STWArmory_Schematics = 56,
    STWArmory_Backpack = 57,
    STWArmory_Storage = 58,
    STWArmory_CollectionBook = 59,
    STWArmory_Transform = 60,
    STWArmory_Resources = 61,
    EFortBangType_MAX = 62
};

enum class EFortEventNameType : uint8_t
{
    Mission = 0,
    Client = 1,
    EFortEventNameType_MAX = 2
};

enum class EFortCraftFailCause : uint8_t
{
    Unknown = 0,
    NotEnoughResources = 1,
    InventoryFull = 2,
    InsufficientTeamLevel = 3,
    CraftingQueueFull = 4,
    CurrentlyLocked = 5,
    OverflowSchematic = 6,
    EFortCraftFailCause_MAX = 7
};

enum class EKeepContainerType : uint8_t
{
    Base = 0,
    Storeroom = 1,
    FirstAid = 2,
    Armory = 3,
    Workshop = 4,
    AmmoStash = 5,
    Max = 6
};

enum class EFortIndicatorState : uint8_t
{
    Hidden = 0,
    OnlyFriendsVisible = 1,
    Visible = 2,
    EFortIndicatorState_MAX = 3
};

enum class EReadyCheckState : uint8_t
{
    CheckStarted = 0,
    Ready = 1,
    NotReady = 2,
    EReadyCheckState_MAX = 3
};

enum class EFortTeamAffiliation : uint8_t
{
    Friendly = 0,
    Neutral = 1,
    Hostile = 2,
    EFortTeamAffiliation_MAX = 3
};

enum class EFortAIUtility : uint8_t
{
    KillPlayersMelee = 0,
    KillPlayersRanged = 1,
    KillPlayersArtillery = 2,
    DestroyBuildingsMelee = 3,
    DestroyBuildingsRanged = 4,
    DestroyBuildingsArtillery = 5,
    DestroyTraps = 6,
    Tank = 7,
    Infiltrate = 8,
    Mob = 9,
    Support = 10,
    Kiting = 11,
    AreaOfDenial = 12,
    DisableTraps = 13,
    Dormant = 14,
    Assassin = 15,
    MAX = 16
};

enum class EFortTileEdgeType : uint8_t
{
    Undefined = 0,
    Outer_1 = 1,
    Transition_2 = 2,
    Inner_3 = 3,
    Border_4 = 4,
    BorderTransitionSingle_5 = 5,
    BorderTransitionDouble_6 = 6,
    MAX = 7
};

enum class EFortMovementUrgency : uint8_t
{
    None = 0,
    Low = 1,
    Medium = 2,
    High = 3,
    NumLevels = 4,
    EFortMovementUrgency_MAX = 5
};

enum class EFortMovementStyle : uint8_t
{
    Running = 0,
    Walking = 1,
    Charging = 2,
    Sprinting = 3,
    PersonalVehicle = 4,
    Flying = 5,
    EFortMovementStyle_MAX = 6
};

enum class EFortWeaponReloadType : uint8_t
{
    ReloadWholeClip = 0,
    ReloadIndividualBullets = 1,
    ReloadBasedOnAmmoCostPerFire = 2,
    ReloadBasedOnCartridgePerFire = 3,
    EFortWeaponReloadType_MAX = 4
};

enum class EFortWeaponTriggerType : uint8_t
{
    OnPress = 0,
    Automatic = 1,
    OnRelease = 2,
    OnPressAndRelease = 3,
    EFortWeaponTriggerType_MAX = 4
};

enum class EFortDayPhasePrio : uint8_t
{
    Default = 0,
    DailySummary = 1,
    EFortDayPhasePrio_MAX = 2
};

enum class EFortCustomBodyType : uint8_t
{
    Small = 1,
    Medium = 2,
    MediumAndSmall = 3,
    Large = 4,
    LargeAndSmall = 5,
    LargeAndMedium = 6,
    All = 7,
    Deprecated = 8,
    EFortCustomBodyType_MAX = 9
};

enum class EFortDisplayGender : uint8_t
{
    Unknown = 0,
    Male = 1,
    Female = 2,
    NumTypes = 3,
    EFortDisplayGender_MAX = 4
};

enum class EFortCustomGender : uint8_t
{
    Invalid = 0,
    Male = 1,
    Female = 2,
    Both = 3,
    EFortCustomGender_MAX = 4
};

enum class EFortPvPGameResult : uint8_t
{
    Win = 0,
    Loss = 1,
    Draw = 2,
    EFortPvPGameResult_MAX = 3
};

enum class EFortQuality : uint8_t
{
    Common = 0,
    Uncommon = 1,
    Rare = 2,
    NumQualityValues = 3,
    EFortQuality_MAX = 4
};

enum class EFortRarity : uint8_t
{
    Handmade = 0,
    Ordinary = 1,
    Sturdy = 2,
    Quality = 3,
    Fine = 4,
    Elegant = 5,
    Masterwork = 6,
    Epic = 7,
    Badass = 8,
    Legendary = 9,
    NumRarityValues = 10,
    EFortRarity_MAX = 11
};

enum class EFortTargetSelectionFilter : uint8_t
{
    Damageable = 0,
    Everything = 1,
    Pawns = 2,
    Buildings = 3,
    Walls = 4,
    Traps = 5,
    Players = 6,
    AIPawns = 7,
    Instigator = 8,
    WeakSpots = 9,
    World = 10,
    Max = 11
};

enum class EFortWeaponType : uint8_t
{
    None = 0,
    RangedAny = 1,
    Pistol = 2,
    Shotgun = 3,
    Rifle = 4,
    SMG = 5,
    Sniper = 6,
    GrenadeLauncher = 7,
    RocketLauncher = 8,
    Bow = 9,
    Minigun = 10,
    LMG = 11,
    MeleeAny = 12,
    MAX = 13
};

enum class EFortTargetSelectionTestType : uint8_t
{
    Overlap = 0,
    Swept = 1,
    Ballistic = 2,
    EFortTargetSelectionTestType_MAX = 3
};

enum class EFortTargetSelectionShape : uint8_t
{
    Sphere = 0,
    Cone = 1,
    Box = 2,
    Capsule = 3,
    Line = 4,
    Cylinder = 5,
    Custom = 6,
    CustomOnSource = 7,
    EFortTargetSelectionShape_MAX = 8
};

enum class EFortBrushSize : uint8_t
{
    VeryVerySmall = 0,
    VerySmall = 1,
    Small = 2,
    Medium = 3,
    Large = 4,
    VeryLarge = 5,
    EFortBrushSize_MAX = 6
};

enum class ESpecialActorStatType : uint8_t
{
    NumEliminationsNearby = 0,
    TimeInWorld = 1,
    PickupNumSpawns = 2,
    PickupNumDespawns = 3,
    PickupNumDropped = 4,
    PickupNumTaken = 5,
    PlayerWon = 6,
    PlayerNumEliminations = 7,
    PlayerNum = 8,
    TotalStats = 9,
    ESpecialActorStatType_MAX = 10
};

enum class EEndOfMatchReason : uint8_t
{
    LastManStanding = 0,
    ScoreReached = 1,
    TimeRanOut = 2,
    WinEventOccurred = 3,
    AllLoggedOut = 4,
    AllEliminated = 5,
    EEndOfMatchReason_MAX = 6
};

enum class EFortItemViewRotationMode : uint8_t
{
    None = 0,
    BoundsPivot = 1,
    World = 2,
    Relative = 3,
    EFortItemViewRotationMode_MAX = 4
};

enum class EFortInventoryCustomFilter : uint8_t
{
    Mythic = 0,
    Legendary = 1,
    Epic = 2,
    Rare = 3,
    Uncommon = 4,
    Common = 5,
    EFortInventoryCustomFilter_MAX = 6
};

enum class EInventoryContentSortType : uint8_t
{
    ByName = 0,
    ByRating = 1,
    ByLevel = 2,
    ByCategory = 3,
    ByRarity = 4,
    ByLocation = 5,
    ByPersonality = 6,
    ByBonus = 7,
    BySubtype = 8,
    EInventoryContentSortType_MAX = 9
};

enum class EFortFrontendInventoryFilter : uint8_t
{
    Schematics = 0,
    WorldItems = 1,
    WorldItemsInGame = 2,
    WorldItemsStorage = 3,
    WorldItemsTransfer = 4,
    ConsumablesAndAccountResources = 5,
    Heroes = 6,
    Defenders = 7,
    Survivors = 8,
    AthenaCharacter = 9,
    AthenaBackpack = 10,
    AthenaPickaxe = 11,
    AthenaGliders = 12,
    AthenaContrails = 13,
    AthenaEmotes = 14,
    AthenaItemWraps = 15,
    AthenaLoadingScreens = 16,
    AthenaLobbyMusic = 17,
    Invisible = 18,
    Max_None = 19,
    EFortFrontendInventoryFilter_MAX = 20
};

enum class EFortInventoryFilter : uint8_t
{
    WeaponMelee = 0,
    WeaponRanged = 1,
    Ammo = 2,
    Traps = 3,
    Consumables = 4,
    Ingredients = 5,
    Gadget = 6,
    Decorations = 7,
    Badges = 8,
    Heroes = 9,
    LeadSurvivors = 10,
    Survivors = 11,
    Defenders = 12,
    Resources = 13,
    ConversionControl = 14,
    AthenaCosmetics = 15,
    Playset = 16,
    CreativePlot = 17,
    Workers = 18,
    Invisible = 19,
    Max_None = 20,
    EFortInventoryFilter_MAX = 21
};

enum class EFortItemCategoryOrdinal : uint8_t
{
    Primary = 0,
    Secondary = 1,
    Tertiary = 2,
    EFortItemCategoryOrdinal_MAX = 3
};

enum class ESubGameMatchmakingStatus : uint8_t
{
    Disabled = 0,
    Enabled = 1,
    ESubGameMatchmakingStatus_MAX = 2
};

enum class ESubGameAccessStatus : uint8_t
{
    Disabled = 0,
    LimitedAccess = 1,
    OpenAccess = 2,
    ESubGameAccessStatus_MAX = 3
};

enum class EDeathCause : uint8_t
{
    OutsideSafeZone = 0,
    FallDamage = 1,
    Pistol = 2,
    Shotgun = 3,
    Rifle = 4,
    SMG = 5,
    Sniper = 6,
    SniperNoScope = 7,
    Melee = 8,
    InfinityBlade = 9,
    Grenade = 10,
    C4 = 11,
    GrenadeLauncher = 12,
    RocketLauncher = 13,
    Minigun = 14,
    Bow = 15,
    Trap = 16,
    DBNOTimeout = 17,
    Banhammer = 18,
    RemovedFromGame = 19,
    MassiveMelee = 20,
    MassiveDiveBomb = 21,
    MassiveRanged = 22,
    Vehicle = 23,
    LMG = 24,
    GasGrenade = 25,
    InstantEnvironmental = 26,
    Turret = 27,
    Cube = 28,
    Balloon = 29,
    StormSurge = 30,
    BasicFiend = 31,
    EliteFiend = 32,
    RangedFiend = 33,
    BasicBrute = 34,
    EliteBrute = 35,
    MegaBrute = 36,
    LoggedOut = 37,
    TeamSwitchSuicide = 38,
    WonMatch = 39,
    Unspecified = 40,
    EDeathCause_MAX = 41
};

enum class EFortUIFriendNotificationType : uint8_t
{
    Default = 0,
    FriendRequest = 1,
    PartyInvite = 2,
    AutoImportFriendSuggestion = 3,
    EFortUIFriendNotificationType_MAX = 4
};

enum class EFortNotificationPriority : uint8_t
{
    Vote = 0,
    Friend = 1,
    BoostedXP = 2,
    TwitchHigh = 3,
    GeneralSendNotification = 4,
    TwitchLow = 10,
    Max = 11
};

enum class EFortNotificationType : uint8_t
{
    Default = 0,
    Power = 1,
    HealthWarning = 2,
    Error = 3,
    Max = 4
};

enum class EFortContextualReticleTypes : uint8_t
{
    FCR_GenericFailure = 0,
    FCR_Upgrade = 1,
    FCR_Repair = 2,
    FCR_Locked = 3,
    FCR_Placement = 4,
    FCR_Edit = 5,
    FCR_NoTarget = 6,
    FCR_InProgress = 7,
    FCR_None = 8,
    FCR_MAX = 9
};

enum class EFortUserCloudRequestResult : uint8_t
{
    Success = 0,
    Failure_CloudStorageDisabled = 1,
    Failure_CloudStorageError = 2,
    Failure_FileNotFoundInUserFileList = 3,
    Failure_SavingNotAllowedForSpecifiedUser = 4,
    EFortUserCloudRequestResult_MAX = 5
};

enum class EFortUserCloudRequestType : uint8_t
{
    LoadCloudFile = 0,
    SaveCloudFile = 1,
    EFortUserCloudRequestType_MAX = 2
};

enum class EVehicleAudioTriggerDir : uint8_t
{
    Forward = 0,
    Backward = 1,
    EVehicleAudioTriggerDir_MAX = 2
};

enum class EVehicleAudioInterpolationType : uint8_t
{
    None = 0,
    CustomCurve = 1,
    Linear = 2,
    EVehicleAudioInterpolationType_MAX = 3
};

enum class EFortVisibilityBehavior : uint8_t
{
    Proximity = 0,
    OnceSeenAlwaysSeen = 1,
    AlwaysSeen = 2,
    Invalid = 3,
    EFortVisibilityBehavior_MAX = 4
};

enum class ECreativeItemCategory : uint8_t
{
    Prefabs = 0,
    Devices = 1,
    Weapons = 2,
    Consumables = 3,
    ECreativeItemCategory_MAX = 4
};

enum class EVolumeValidityResult : uint8_t
{
    Valid = 0,
    Invalid = 1,
    EVolumeValidityResult_MAX = 2
};

enum class EFortReloadMontageSection : uint8_t
{
    Intro = 0,
    Loop = 1,
    Outro = 2,
    EFortReloadMontageSection_MAX = 3
};

enum class EFortDisplayTier : uint8_t
{
    Invalid = 0,
    Handmade = 1,
    Copper = 2,
    Silver = 3,
    Malachite = 4,
    Obsidian = 5,
    Brightcore = 6,
    Spectrolite = 7,
    Shadowshard = 8,
    Sunbeam = 9,
    Moonglow = 10,
    EFortDisplayTier_MAX = 11
};

enum class EFortWeaponOverheatState : uint8_t
{
    None = 0,
    Heating = 1,
    Cooling = 2,
    Overheated = 3,
    EFortWeaponOverheatState_MAX = 4
};

enum class EWorldItemDropBehavior : uint8_t
{
    DropAsPickup = 0,
    DestroyOnDrop = 1,
    DropAsPickupDestroyOnEmpty = 2,
    EWorldItemDropBehavior_MAX = 3
};

enum class EFortWorldManagerState : uint8_t
{
    WMS_Created = 0,
    WMS_QueryingWorld = 1,
    WMS_WorldQueryComplete = 2,
    WMS_CreatingNewWorld = 3,
    WMS_LoadingExistingWorld = 4,
    WMS_Running = 5,
    WMS_Failed = 6,
    WMS_MAX = 7
};

enum class EFortLevelStreamingState : uint8_t
{
    LSS_Unloaded = 0,
    LSS_Loaded = 1,
    LSS_UnconditionalFoundationsUpdated = 2,
    LSS_AllFoundationsUpdated = 3,
    LSS_NewActorsCreatedButNotUpdated = 4,
    LSS_AllUpdated = 5,
    LSS_Ready = 6,
    LSS_MAX = 7
};

enum class EFortQueuedActionUserStatus : uint8_t
{
    Succeeded = 0,
    Failed = 1,
    WaitingForCloudRequest = 2,
    WaitingForProfileSave = 3,
    EFortQueuedActionUserStatus_MAX = 4
};

enum class EFortWorldRecordState : uint8_t
{
    StartProcessing = 0,
    WaitingForResponse = 1,
    RetrievingTheaterInformation = 2,
    RetrievingZoneInformation = 3,
    LoadingWorldRecord = 4,
    LoadingZoneRecord = 5,
    SavingZoneRecord = 6,
    SavingPlayerProfiles = 7,
    SavingPlayerDeployableBases = 8,
    Succeeded = 9,
    Failed = 10,
    Max_None = 11,
    EFortWorldRecordState_MAX = 12
};

enum class EFortWorldRecordAction : uint8_t
{
    LoadWorldOnly = 0,
    SaveWorldOnly = 1,
    SaveZoneAndWorld = 2,
    LoadZoneAndWorld = 3,
    SaveDeployableBasesAndWorld = 4,
    Max_None = 5,
    EFortWorldRecordAction_MAX = 6
};

enum class EDeployableBaseUseType : uint8_t
{
    Neighborhood = 0,
    PvECombat = 1,
    EDeployableBaseUseType_MAX = 2
};

enum class EFortZoneType : uint8_t
{
    PVE = 0,
    PVP = 1,
    Keep = 2,
    SingleZone = 3,
    Max_None = 4,
    EFortZoneType_MAX = 5
};

enum class EFrontEndCamera : uint8_t
{
    Invalid = 0,
    Command = 1,
    Command_Hero = 2,
    Cosmetics = 3,
    Expeditions = 4,
    FrontendDefault = 5,
    Heroes = 6,
    HeroSelect = 7,
    HeroLoadout = 8,
    Home = 9,
    HomeBase = 10,
    Login = 11,
    Manage1 = 12,
    Manage2 = 13,
    Manage3 = 14,
    Manage4 = 15,
    MissionControl = 16,
    Party = 17,
    Play = 18,
    Research = 19,
    SkillTrees = 20,
    SmallCosmetics = 21,
    SpecialEvent = 22,
    Store = 23,
    StoreItemInspect = 24,
    StwFrontendDefault = 25,
    SurvivorSquadBuilding1 = 26,
    SurvivorSquadBuilding2 = 27,
    SurvivorSquadBuilding3 = 28,
    SurvivorSquadBuilding4 = 29,
    TutorialPhaseOne = 30,
    TutorialPhaseTwo = 31,
    TutorialPhaseThree = 32,
    Upgrades = 33,
    Vault = 34,
    WorldMap = 35,
    LobbyCentered = 36,
    EFrontEndCamera_MAX = 37
};

enum class EDroneFacingLocationMode : uint8_t
{
    NotFacingLocation = 0,
    FindingPoint = 1,
    TrackingPoint = 2,
    EDroneFacingLocationMode_MAX = 3
};

enum class EFireModeType : uint8_t
{
    Unset = 0,
    TapToShoot = 1,
    FireButton = 2,
    AutoFire = 3,
    ForceTouch = 4,
    Custom = 5,
    MAX = 6
};

enum class ELayoutPropertyType : uint8_t
{
    PropertyType_Float = 0,
    PropertyType_Integer = 1,
    PropertyType_Bool = 2,
    PropertyType_Rotator = 3,
    PropertyType_MAX = 4
};

enum class ELayoutDataType : uint8_t
{
    Custom = 0,
    DefaultToolLayout = 1,
    DefaultGameLayout = 2,
    MAX = 3
};

enum class EFortEncounterSpawnLimitType : uint8_t
{
    NoLimit = 0,
    NumPawnsLimit = 1,
    SpawnPointLimit = 2,
    UserDefined = 3,
    MAX = 4
};

enum class EFortEncounterUtilitiesMode : uint8_t
{
    LockedOnly = 0,
    LockedAndFree = 1,
    EFortEncounterUtilitiesMode_MAX = 2
};

enum class EFortEncounterSpawnLocationManagementMode : uint8_t
{
    Spawn = 0,
    Search = 1,
    EFortEncounterSpawnLocationManagementMode_MAX = 2
};

enum class EFortEncounterSpawnLocationPlacementMode : uint8_t
{
    Directional = 0,
    Ring = 1,
    Volume = 2,
    Custom = 3,
    Max_None = 4,
    EFortEncounterSpawnLocationPlacementMode_MAX = 5
};

enum class EFortEncounterPacingMode : uint8_t
{
    SpawnPointsPercentageCurve = 0,
    IntensityCurve = 1,
    Burst = 2,
    EFortEncounterPacingMode_MAX = 3
};

enum class EFortMissionAudibility : uint8_t
{
    UseVisibility = 0,
    Audible = 1,
    Inaudible = 2,
    EFortMissionAudibility_MAX = 3
};

enum class EFortMissionType : uint8_t
{
    Primary = 0,
    Secondary = 1,
    Max_None = 2,
    EFortMissionType_MAX = 3
};

enum class EFortObjectiveRequirement : uint8_t
{
    Optional = 0,
    Required = 1,
    RequiredButCanFail = 2,
    EFortObjectiveRequirement_MAX = 3
};

enum class EFortMissionStatus : uint8_t
{
    Created = 0,
    InProgress = 1,
    Succeeded = 2,
    Failed = 3,
    NeutralCompletion = 4,
    Quit = 5,
    Max_None = 6,
    EFortMissionStatus_MAX = 7
};

enum class EMissionGenerationCategory : uint8_t
{
    Primary = 0,
    Secondary = 1,
    Tertiary = 2,
    Survivor = 3,
    Max_None = 4,
    EMissionGenerationCategory_MAX = 5
};

enum class EPlayerNameFlags : uint8_t
{
    None = 0,
    Killer = 1,
    Teammate = 2,
    Spectating = 4,
    EPlayerNameFlags_MAX = 5
};

enum class EStatRecordingPeriod : uint8_t
{
    Minute = 0,
    AthenaSafeZonePhase = 1,
    Life = 2,
    Map = 3,
    Campaign = 4,
    Persistent = 5,
    Max = 6
};

enum class EFortStrategicBuildingLevelCriteriaDisplayRepresentation : uint8_t
{
    Integer = 0,
    Float = 1,
    EFortStrategicBuildingLevelCriteriaDisplayRepresentation_MAX = 2
};

enum class EFortStrategicBuildingCategory : uint8_t
{
    Defensive = 0,
    Offensive = 1,
    Utility = 2,
    EFortStrategicBuildingCategory_MAX = 3
};

enum class EFortThreatDeactivationType : uint8_t
{
    Off = 0,
    Dormant = 1,
    EFortThreatDeactivationType_MAX = 2
};

enum class EWrapPreviewGridLockerMode : uint8_t
{
    IgnoreLockerConfiguration = 0,
    SupportedWeaponsOnly = 1,
    UnsupportedWeaponsOnly = 2,
    EWrapPreviewGridLockerMode_MAX = 3
};struct FFortMultiSizeBrush
{
	public:
	    struct FSlateBrush Brush_XXS; // 0x0 Size: 0x88
	    struct FSlateBrush Brush_XS; // 0x88 Size: 0x88
	    struct FSlateBrush Brush_S; // 0x110 Size: 0x88
	    struct FSlateBrush Brush_M; // 0x198 Size: 0x88
	    struct FSlateBrush Brush_L; // 0x220 Size: 0x88
	    struct FSlateBrush Brush_XL; // 0x2a8 Size: 0x88

};

struct FFortItemViewSettings
{
	public:
	    bool UsesPlacementActor; // 0x0 Size: 0x1
	    bool UsesFixedCamera; // 0x1 Size: 0x1
	    bool SupportsZooming; // 0x2 Size: 0x1
	    char UnknownData0[0x1]; // 0x3
	    float DefaultZoomLevel; // 0x4 Size: 0x4
	    struct FFloatRange ZoomRange; // 0x8 Size: 0x10
	    EFortItemViewRotationMode RotationMode; // 0x18 Size: 0x1
	    char UnknownData1[0x3]; // 0x19
	    struct FRotator CameraRotationOffset; // 0x1c Size: 0xc

};

struct FConfirmationDialogAction
{
	public:
	    struct FText DisplayName; // 0x0 Size: 0x18
	    struct FText HoverText; // 0x18 Size: 0x18
	    FName ResultName; // 0x30 Size: 0x8
	    struct FSlateBrush Icon; // 0x38 Size: 0x88
	    FName ActionName; // 0xc0 Size: 0x8

};

struct FFortDialogExternalLatentActionHandle
{
	public:
	    int Handle; // 0x0 Size: 0x4

};

struct FSpecialActorSingleStatData
{
	public:
	    ESpecialActorStatType StatType; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float Value; // 0x4 Size: 0x4
	    float StatLogicValue; // 0x8 Size: 0x4

};

struct FFortBroadcastInfoPerPlayer
{
	public:
	    class AFortPlayerStateAthena* PlayerState; // 0x0 Size: 0x8
	    int ResourceCount; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortGlobalActionDetails
{
	public:
	    FName ActionName; // 0x0 Size: 0x8
	    bool HoldStatus; // 0x8 Size: 0x1
	    char UnknownData0[0x3];

};

struct FFortGlobalActionDetailsFunctionContext
{
	public:
	    ECommonInputType OverrideInputType; // 0x0 Size: 0x1

};

struct FFortInputActionDetails
{
	public:
	    EFortInputActionType InputActionType; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FKey ActionKey; // 0x8 Size: 0x18

};

struct FGameSummaryInfo
{
	public:
	    struct FString GameSessionId; // 0x0 Size: 0x10
	    bool Completed; // 0x10 Size: 0x1
	    char UnknownData0[0x7];

};

struct FHeroSpecializationAttributeRequirement
{
	public:
	    struct FGameplayAttribute Attribute; // 0x0 Size: 0x20
	    float MinimumValue; // 0x20 Size: 0x4
	    char UnknownData0[0x4];

};

struct FTransmogSacrifice : public FTableRowBase
{
	public:
	    int TransmogSacrificePoints; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortClientAnnouncementData
{
	public:
	    char UnknownData0[0x1];

};

struct FFortClientAnnouncementData_Basic : public FFortClientAnnouncementData
{
	public:
	    struct FSlateBrush Icon; // 0x0 Size: 0x88
	    struct FText TitleText; // 0x88 Size: 0x18
	    struct FText DetailText; // 0xa0 Size: 0x18
	    struct FText GamepadDetailText; // 0xb8 Size: 0x18
	    int Priority; // 0xd0 Size: 0x4
	    char UnknownData0[0x4]; // 0xd4
	    float DisplayTime; // 0xd8 Size: 0x4
	    char UnknownData1[0x4]; // 0xdc
	    class USoundBase* OnStartSound; // 0xe0 Size: 0x8

};

struct FFortClientAnnouncementData_Tutorial : public FFortClientAnnouncementData_Basic
{
	public:
	    float AutoContinueDelay; // 0xe8 Size: 0x4
	    char UnknownData0[0x4]; // 0xec
	    struct FText NameText; // 0xf0 Size: 0x18
	    struct FText SystemText; // 0x108 Size: 0x18
	    bool bButtonEnabled; // 0x120 Size: 0x1
	    bool bLightboxEnabled; // 0x121 Size: 0x1
	    bool bLightboxDisableInputOnly; // 0x122 Size: 0x1
	    char UnknownData1[0x1]; // 0x123
	    struct FMargin Padding; // 0x124 Size: 0x10
	    char VAlign; // 0x134 Size: 0x1
	    char HAlign; // 0x135 Size: 0x1
	    char UnknownData2[0x2];

};

struct FHomebaseSquadAttributeBonus
{
	public:
	    struct FGameplayAttribute AttributeGranted; // 0x0 Size: 0x20
	    struct FCurveTableRowHandle BonusCurve; // 0x20 Size: 0x10

};

struct FFortClientObservedStat : public FFastArraySerializerItem
{
	public:
	    FName StatName; // 0xc Size: 0x8
	    int StatValue; // 0x14 Size: 0x4
	    char UnknownData0[0x8];

};

struct FAIHotSpotSlotConfig
{
	public:
	    struct FVector Offset; // 0x0 Size: 0xc
	    struct FVector Direction; // 0xc Size: 0xc
	    EFortHotSpotSlot SlotType; // 0x18 Size: 0x1
	    char UnknownData0[0x3];

};

struct FAIHotSpotSlotInfo
{
	public:
	    class AAIHotSpot* HotSpot; // 0x0 Size: 0x8
	    int SlotIndex; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FDroppingAgentData
{
	public:
	    class AAthenaAIController* AIController; // 0x0 Size: 0x8
	    class ABuildingActor* MovementBase; // 0x8 Size: 0x8
	    char UnknownData0[0x8];

};

struct FBarrierFlagDisplayData
{
	public:
	    class UStaticMesh* HeadMesh; // 0x0 Size: 0x8
	    struct FSlateBrush MiniMap_EnabledBrush; // 0x8 Size: 0x88
	    struct FSlateBrush MiniMap_DisabledBrush; // 0x90 Size: 0x88
	    struct FSlateBrush Compass_EnabledBrush; // 0x118 Size: 0x88
	    struct FSlateBrush Compass_DisabledBrush; // 0x1a0 Size: 0x88
	    struct FVector2D MapSize; // 0x228 Size: 0x8
	    struct FVector2D CompassSize; // 0x230 Size: 0x8
	    struct FVector MeshScale; // 0x238 Size: 0xc
	    char UnknownData0[0x4];

};

struct FAthenaBroadcastKillFeedEntryInfo
{
	public:
	    char UnknownData0[0x38];

};

struct FFortCosmeticAdaptiveStatPair
{
	public:
	    struct FFortStatManagerTag StatTag; // 0x0 Size: 0x8
	    int StatValue; // 0x8 Size: 0x4

};

struct FAthenaCosmeticMaterialOverride
{
	public:
	    FName ComponentName; // 0x0 Size: 0x8
	    int MaterialOverrideIndex; // 0x8 Size: 0x4
	    char UnknownData0[0x4]; // 0xc
	    struct TSoftObjectPtr<struct UMaterialInterface*> OverrideMaterial; // 0x10 Size: 0x28

};

struct FAthenaLevelUpData : public FTableRowBase
{
	public:
	    int Level; // 0x8 Size: 0x4
	    int XpToNextLevel; // 0xc Size: 0x4
	    int XpTotal; // 0x10 Size: 0x4
	    int CurrencyReward; // 0x14 Size: 0x4
	    struct FString ChaseRewardTemplateId; // 0x18 Size: 0x10

};

struct FPetStimuliResponse
{
	public:
	    struct FGameplayTag ResponseTag; // 0x0 Size: 0x8
	    float ResponseDuration; // 0x8 Size: 0x4
	    float ResponseWeight; // 0xc Size: 0x4

};

struct FAthenaQuickChatActiveEntry
{
	public:
	    TWeakObjectPtr<UAthenaQuickChatBank*> Bank; // 0x0 Size: 0x8
	    TWeakObjectPtr<UObject*> ContextObject; // 0x8 Size: 0x8
	    int16_t ContextValue; // 0x10 Size: 0x2
	    int8_t Index; // 0x12 Size: 0x1
	    char UnknownData0[0x1];

};

struct FAthenaQuickChatLeafEntry
{
	public:
	    struct FText Label; // 0x0 Size: 0x18
	    struct FText FullChatMessage; // 0x18 Size: 0x18
	    struct FSlateBrush Brush; // 0x30 Size: 0x88
	    bool bPopulateBrushFromContextObject; // 0xb8 Size: 0x1
	    EAthenaQuickChatFilteringType FilterType; // 0xb9 Size: 0x1
	    char UnknownData0[0x6]; // 0xba
	    class UAthenaEmojiItemDefinition* EmojiItemDefinition; // 0xc0 Size: 0x8
	    ETeamMemberState TeamCommType; // 0xc8 Size: 0x1
	    char UnknownData1[0x3]; // 0xc9
	    struct FGameplayTag OptionGameplayTag; // 0xcc Size: 0x8
	    char UnknownData2[0x4];

};

struct FAthenaRewardItemReference
{
	public:
	    struct TSoftObjectPtr<struct UFortItemDefinition*> ItemDefinition; // 0x0 Size: 0x28
	    struct FString TemplateId; // 0x28 Size: 0x10
	    int Quantity; // 0x38 Size: 0x4
	    char UnknownData0[0x4]; // 0x3c
	    struct TSoftObjectPtr<struct UFortGiftBoxItemDefinition*> GiftBoxToUse; // 0x40 Size: 0x28
	    bool IsChaseReward; // 0x68 Size: 0x1
	    EAthenaRewardItemType RewardType; // 0x69 Size: 0x1
	    char UnknownData1[0x6];

};

struct FAthenaSeasonBannerLevel
{
	public:
	    struct TSoftObjectPtr<struct UTexture2D*> SurroundImage; // 0x0 Size: 0x28
	    struct TSoftObjectPtr<struct UMaterialInterface*> BannerMaterial; // 0x28 Size: 0x28

};

struct FAthenaSeasonalXPCurveEntry : public FTableRowBase
{
	public:
	    int Level; // 0x8 Size: 0x4
	    int XpToNextLevel; // 0xc Size: 0x4
	    int XpTotal; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FBacchusActionIconMapping
{
	public:
	    FName Action; // 0x0 Size: 0x8
	    class UPaperSprite* Sprite; // 0x8 Size: 0x8

};

struct FBuildingActorHotSpotDirection
{
	public:
	    class UAIHotSpotConfig* HotSpotConfig; // 0x0 Size: 0x8
	    struct FVector Offset; // 0x8 Size: 0xc
	    bool bMirrorX; // 0x14 Size: 0x1
	    bool bMirrorY; // 0x14 Size: 0x1
	    char UnknownData0[0x2]; // 0x16
	    EFortHotSpotDirection Direction; // 0x18 Size: 0x1
	    EHotspotTypeConfigMode TypeConfigUsage; // 0x19 Size: 0x1
	    char UnknownData1[0x6];

};

struct FFortSearchBounceData
{
	public:
	    struct FVector BounceNormal; // 0x0 Size: 0xc
	    uint32_t SearchAnimationCount; // 0xc Size: 0x4

};

struct FConnectivityCube
{
	public:
	    char UnknownData0[0xc0];

};

struct FAuxiliaryEditTileMeshData
{
	public:
	    class UStaticMesh* TileMesh; // 0x0 Size: 0x8
	    class UTexture2D* TileTexture; // 0x8 Size: 0x8
	    struct FRotator RelativeRot; // 0x10 Size: 0xc
	    char UnknownData0[0x4];

};

struct FEditModeState
{
	public:
	    class ABuildingSMActor* EditClass; // 0x0 Size: 0x8
	    int RotationIterations; // 0x8 Size: 0x4
	    bool bMirrored; // 0xc Size: 0x1
	    bool bCurrentlyValid; // 0xd Size: 0x1
	    char UnknownData0[0x2];

};

struct FTileCompInterpData
{
	public:
	    struct FVector InitialTranslation; // 0x0 Size: 0xc
	    struct FVector DesiredTranslation; // 0xc Size: 0xc

};

struct FFOBCoreChoice : public FFastArraySerializerItem
{
	public:
	    char UnknownData0[0x4];
	    class UFortFOBCoreDecoItemDefinition* FOBCoreDef; // 0x10 Size: 0x8
	    EFOBFileHeaderStatus FileHeaderStatus; // 0x18 Size: 0x1
	    char UnknownData1[0x7]; // 0x19
	    struct FString CoreFilename; // 0x20 Size: 0x10
	    class UFortBuildingInstructions* BuildingInstructions; // 0x30 Size: 0x8

};

struct FBuildingFoundationLODActorData
{
	public:
	    TWeakObjectPtr<ALODActor*> LODActor; // 0x0 Size: 0x8
	    char UnknownData0[0x18]; // 0x8
	    class UMaterialInstanceDynamic* VisibilityMaterial; // 0x20 Size: 0x8
	    class UTexture2DDynamic* VisibilityTexture; // 0x28 Size: 0x8

};

struct FGameplayEffectApplicationInfo
{
	public:
	    __int64/*SoftClassProperty*/ GameplayEffect; // 0x0 Size: 0x28
	    float Level; // 0x28 Size: 0x4
	    char UnknownData0[0x4];

};

struct FItemCollectorOverrideItemRow : public FTableRowBase
{
	public:
	    struct FPrimaryAssetId ItemPrimaryAssetId; // 0x8 Size: 0x10
	    int Quantity; // 0x18 Size: 0x4
	    char UnknownData0[0x4];

};

struct FItemCollectorRow : public FTableRowBase
{
	public:
	    class UDataTable* OverrideItemsTable; // 0x8 Size: 0x8
	    EFortRarity OverrideRarity; // 0x10 Size: 0x1
	    char UnknownData0[0x3]; // 0x11
	    int OverrideGoal; // 0x14 Size: 0x4
	    int bOverrideLootRules; // 0x18 Size: 0x4
	    int bUseOverrideRarity; // 0x1c Size: 0x4

};

struct FCollectorTrackedData
{
	public:
	    char Team; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class AFortPlayerState* Player; // 0x8 Size: 0x8
	    char UnknownData1[0x10];

};

struct FCollectedItemValue
{
	public:
	    class UFortWorldItemDefinition* CollectedItem; // 0x0 Size: 0x8
	    int DepositAmount; // 0x8 Size: 0x4
	    int DepositGoal; // 0xc Size: 0x4
	    int CaptureCount; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortRiftReservationHandle
{
	public:
	    int RiftReservationID; // 0x0 Size: 0x4

};

struct FFortRiftReservation
{
	public:
	    bool bDesiredVisible; // 0x0 Size: 0x1
	    bool bDesiredActive; // 0x0 Size: 0x1
	    char UnknownData0[0x2]; // 0x2
	    struct FFortRiftReservationHandle ReservationHandle; // 0x4 Size: 0x4

};

struct FFortSpawnSlotData
{
	public:
	    struct FVector SpawnSlotLocation; // 0x0 Size: 0xc
	    char UnknownData0[0x4]; // 0xc
	    class AFortAIPawn* OccupyingAI; // 0x10 Size: 0x8
	    char SlotStatus; // 0x18 Size: 0x1
	    char UnknownData1[0x7];

};

struct FProxyGameplayCueDamagePhysical
{
	public:
	    float ProxyGameplayCueDamagePhysicalMagnitude; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    struct FGameplayEffectContextHandle EffectContext; // 0x8 Size: 0x18

};

struct FQuantizedBuildingAttribute
{
	public:
	    float Value; // 0x0 Size: 0x4

};

struct FBuildingActorMinimalReplicationProxy
{
	public:
	    struct FQuantizedBuildingAttribute BuildTime; // 0x8 Size: 0x4
	    struct FQuantizedBuildingAttribute RepairTime; // 0xc Size: 0x4
	    int16_t Health; // 0x10 Size: 0x2
	    int16_t MaxHealth; // 0x12 Size: 0x2
	    char UnknownData0[0x4];

};

struct FBuildingDuplicationData
{
	public:
	    class UObject* ClassData; // 0x0 Size: 0x8
	    class UBuildingTextureData* TextureData; // 0x8 Size: 0x8
	    char UnknownData0[0x18];

};

struct FBuildingNavObstacle
{
	public:
	    struct FBox LocalBounds; // 0x0 Size: 0x1c
	    EBuildingNavObstacleType ObstacleType; // 0x1c Size: 0x1
	    char UnknownData0[0x3];

};

struct FChosenQuotaInfo
{
	public:
	    int LootTier; // 0x0 Size: 0x4
	    FName LootTierKey; // 0x4 Size: 0x8

};

struct FAnimatingMaterialPair
{
	public:
	    class UMaterialInterface* Original; // 0x0 Size: 0x8
	    class UMaterialInterface* Override; // 0x8 Size: 0x8

};

struct FMeshSet
{
	public:
	    float Weight; // 0x0 Size: 0x4
	    char ResourceType; // 0x4 Size: 0x1
	    bool bDoNotBlockBuildings; // 0x5 Size: 0x1
	    bool bDestroyOnPlayerBuildingPlacement; // 0x5 Size: 0x1
	    bool bNeedsDamageOverlay; // 0x5 Size: 0x1
	    class UStaticMesh* BaseMesh; // 0x8 Size: 0x8
	    class UParticleSystem* BreakEffect; // 0x10 Size: 0x8
	    class UParticleSystem* DeathParticles; // 0x18 Size: 0x8
	    FName DeathParticleSocketName; // 0x20 Size: 0x8
	    class USoundBase* DeathSound; // 0x28 Size: 0x8
	    class UParticleSystem* ConstructedEffect; // 0x30 Size: 0x8
	    class UStaticMesh* SearchedMesh; // 0x38 Size: 0x8
	    struct FCurveTableRowHandle SearchSpeed; // 0x40 Size: 0x10
	    float LootNoiseRange; // 0x50 Size: 0x4
	    struct FVector LootSpawnLocation; // 0x54 Size: 0xc

};

struct FLogicalBuilding
{
	public:
	    char UnknownData0[0xa8];

};

struct FBuildingNavigationCellInfo
{
	public:
	    char UnknownData0[0x1];

};

struct FBuildingSupportCellIndex
{
	public:
	    int X; // 0x0 Size: 0x4
	    int Y; // 0x4 Size: 0x4
	    int Z; // 0x8 Size: 0x4

};

struct FNeighboringCenterCellInfo
{
	public:
	    TWeakObjectPtr<ABuildingSMActor*> NeighboringActor; // 0x0 Size: 0x8
	    struct FBuildingSupportCellIndex NeighboringCellIdx; // 0x8 Size: 0xc

};

struct FNeighboringFloorInfo
{
	public:
	    TWeakObjectPtr<ABuildingSMActor*> NeighboringActor; // 0x0 Size: 0x8
	    struct FBuildingSupportCellIndex NeighboringCellIdx; // 0x8 Size: 0xc
	    EStructuralFloorPosition FloorPosition; // 0x14 Size: 0x1
	    char UnknownData0[0x3];

};

struct FNeighboringWallInfo
{
	public:
	    TWeakObjectPtr<ABuildingSMActor*> NeighboringActor; // 0x0 Size: 0x8
	    struct FBuildingSupportCellIndex NeighboringCellIdx; // 0x8 Size: 0xc
	    EStructuralWallPosition WallPosition; // 0x14 Size: 0x1
	    char UnknownData0[0x3];

};

struct FBuildingGridActorFilter
{
	public:
	    bool bIncludeWalls; // 0x0 Size: 0x1
	    bool bIncludeFloors; // 0x1 Size: 0x1
	    bool bIncludeFloorInTop; // 0x2 Size: 0x1
	    bool bIncludeCenterCell; // 0x3 Size: 0x1

};

struct FBuildingValueRules
{
	public:
	    int CellsAbove; // 0x0 Size: 0x4
	    int CellsBelow; // 0x4 Size: 0x4
	    int CellHorizontalRadius; // 0x8 Size: 0x4
	    float DistanceFromObjectiveWeight; // 0xc Size: 0x4
	    float AttackWeight; // 0x10 Size: 0x4
	    float StructuralWeight; // 0x14 Size: 0x4
	    float TrapWeight; // 0x18 Size: 0x4

};

struct FTimeOfDayBlueprintDefaultVariables
{
	public:
	    bool bDisableTODLightsAndMaterialEmissiveValues; // 0x0 Size: 0x1
	    bool bDisableStaticMeshShadowCastingWhenLightsAreActive; // 0x1 Size: 0x1
	    bool bUseAnAlternateShadowMeshWhenTheLightIsOff; // 0x2 Size: 0x1
	    char UnknownData0[0x5]; // 0x3
	    class UStaticMesh* AlternateShadowStaticMesh; // 0x8 Size: 0x8
	    float VolumetricLightScatteringIntensity; // 0x10 Size: 0x4
	    bool bCastVolumetricShadows; // 0x14 Size: 0x1
	    char UnknownData1[0x3];

};

struct FWaypointIndex
{
	public:
	    int WaypointGroup; // 0x0 Size: 0x4
	    int WaypointIndex; // 0x4 Size: 0x4

};

struct FMOBATurretPrioritySetting
{
	public:
	    int AIPriority; // 0x0 Size: 0x4
	    int PlayerPriority; // 0x4 Size: 0x4
	    int BuildingPriority; // 0x8 Size: 0x4

};

struct FFortBounceData
{
	public:
	    float StartTime; // 0x0 Size: 0x4
	    float BounceValue; // 0x4 Size: 0x4
	    float Radius; // 0x8 Size: 0x4
	    struct FLinearColor DeformationVector; // 0xc Size: 0x10
	    struct FLinearColor DeformationCenter; // 0x1c Size: 0x10
	    char BounceType; // 0x2c Size: 0x1
	    bool bLocalInstigator; // 0x2d Size: 0x1
	    char UnknownData0[0x2];

};

struct FClimbLinkData
{
	public:
	    uint32_t UniqueLinkId; // 0x20 Size: 0x4
	    char UnknownData0[0x4];

};

struct FCustomPartMaterialOverrideData
{
	public:
	    int MaterialOverrideIndex; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    struct TSoftObjectPtr<struct UMaterialInterface*> OverrideMaterial; // 0x8 Size: 0x28

};

struct FCustomPartVectorParameter
{
	public:
	    int MaterialIndexForVectorParameter; // 0x0 Size: 0x4
	    FName VectorParameterNameForMaterial; // 0x4 Size: 0x8
	    struct FLinearColor VectorOverride; // 0xc Size: 0x10

};

struct FCustomPartScalarParameter
{
	public:
	    int MaterialIndexForScalarParameter; // 0x0 Size: 0x4
	    FName ScalarParameterNameForMaterial; // 0x4 Size: 0x8
	    float ScalarOverride; // 0xc Size: 0x4

};

struct FCustomPartTextureParameter
{
	public:
	    int MaterialIndexForTextureParameter; // 0x0 Size: 0x4
	    FName TextureParameterNameForMaterial; // 0x4 Size: 0x8
	    char UnknownData0[0x4]; // 0xc
	    struct TSoftObjectPtr<struct UTexture*> TextureOverride; // 0x10 Size: 0x28

};

struct FBlackWidowLegSinAnimationScalar
{
	public:
	    bool bUseConstantValue; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float ConstantValue; // 0x4 Size: 0x4
	    float TimeOffset; // 0x8 Size: 0x4
	    float FrequencyOffset; // 0xc Size: 0x4
	    float SinOffset; // 0x10 Size: 0x4
	    float ResultMultiplier; // 0x14 Size: 0x4
	    struct FVector2D MappedRangeOutput; // 0x18 Size: 0x8

};

struct FBlackWidowLegSinAnimationRotator
{
	public:
	    struct FBlackWidowLegSinAnimationScalar RollAnimation; // 0x0 Size: 0x20
	    struct FBlackWidowLegSinAnimationScalar PitchAnimation; // 0x20 Size: 0x20
	    struct FBlackWidowLegSinAnimationScalar YawAnimation; // 0x40 Size: 0x20

};

struct FColorSwatchPair
{
	public:
	    FName ColorName; // 0x0 Size: 0x8
	    struct FLinearColor ColorValue; // 0x8 Size: 0x10

};

struct FDeferredActorData
{
	public:
	    class ABuildingActor* BuildingActor; // 0x0 Size: 0x8
	    int ActorRecordIndex; // 0x8 Size: 0x4
	    char UnknownData0[0x4]; // 0xc
	    struct FTransform BuildingTransform; // 0x10 Size: 0x30

};

struct FViewOffsetData
{
	public:
	    struct FVector OffsetHigh; // 0x0 Size: 0xc
	    struct FVector OffsetMid; // 0xc Size: 0xc
	    struct FVector OffsetLow; // 0x18 Size: 0xc

};

struct FPenetrationAvoidanceFeeler
{
	public:
	    struct FRotator AdjustmentRot; // 0x0 Size: 0xc
	    float WorldWeight; // 0xc Size: 0x4
	    float PawnWeight; // 0x10 Size: 0x4
	    float Extent; // 0x14 Size: 0x4
	    int TraceInterval; // 0x18 Size: 0x4
	    int FramesUntilNextTrace; // 0x1c Size: 0x4

};

struct FAbilityToolSpawnParameters
{
	public:
	    class ABuildingActor* SpawnClass; // 0x0 Size: 0x8
	    struct FVector Location; // 0x8 Size: 0xc
	    struct FRotator Rotation; // 0x14 Size: 0xc
	    class ABuildingSMActor* AttachedToActor; // 0x20 Size: 0x8

};

struct FAbilityKitItem
{
	public:
	    class UFortItemDefinition* Item; // 0x0 Size: 0x8
	    int Quantity; // 0x8 Size: 0x4
	    char Replenishment; // 0xc Size: 0x1
	    char UnknownData0[0x3];

};

struct FGameplayEffectApplicationInfoHard
{
	public:
	    class UGameplayEffect* GameplayEffect; // 0x0 Size: 0x8
	    float Level; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FDebugNativeActionInfo
{
	public:
	    char UnknownData0[0x18];

};

struct FGameplayAbilityRepSharedAnim_Base
{
	public:
	    EFortSharedAnimationState AnimState; // 0x0 Size: 0x1
	    char MontageSectionToPlay; // 0x1 Size: 0x1

};

struct FGameplayAbilityRepSharedAnim_Index : public FGameplayAbilityRepSharedAnim_Base
{
	public:
	    char UnknownData0[0x2];
	    int MontageIndex; // 0x4 Size: 0x4

};

struct FGameplayAbilityRepSharedAnim : public FGameplayAbilityRepSharedAnim_Base
{
	public:
	    char UnknownData0[0x6];
	    class UAnimMontage* AnimMontage; // 0x8 Size: 0x8

};

struct FReplicatedMontagePair
{
	public:
	    class UAnimMontage* Montage1; // 0x0 Size: 0x8
	    class UAnimMontage* Montage2; // 0x8 Size: 0x8
	    FName Section1; // 0x10 Size: 0x8
	    FName Section2; // 0x18 Size: 0x8
	    int8_t RepIndex; // 0x20 Size: 0x1
	    char UnknownData0[0x7];

};

struct FAttributeInfo
{
	public:
	    char UnknownData0[0x10];

};

struct FTokenAttributePair
{
	public:
	    struct FGameplayTag Token; // 0x0 Size: 0x8
	    struct FGameplayAttribute Attribute; // 0x8 Size: 0x20

};

struct FFortGameplayEffectModifierDescription
{
	public:
	    struct FGameplayAttribute ModAttribute; // 0x0 Size: 0x20
	    struct FText ModDescription; // 0x20 Size: 0x18
	    bool bIsBuff; // 0x38 Size: 0x1
	    char MagnitudeFormat; // 0x39 Size: 0x1
	    EFortStatDisplayType DisplayType; // 0x3a Size: 0x1
	    char UnknownData0[0x1]; // 0x3b
	    float Magnitude; // 0x3c Size: 0x4

};

struct FVisibilityTestPoint
{
	public:
	    struct FVector Location; // 0x0 Size: 0xc
	    char UnknownData0[0x4]; // 0xc
	    class UPrimitiveComponent* Component; // 0x10 Size: 0x8

};

struct FFortAbilityCanHitParameters
{
	public:
	    char UnknownData0[0x18];

};

struct FAbilityTrackedActorSettings
{
	public:
	    struct FScalableFloat MaximumTrackedActors; // 0x0 Size: 0x20

};

struct FAbilityTrackedActorEntry
{
	public:
	    char UnknownData0[0xc];

};

struct FFortGameplayAbilityTargetData_SingleTargetHit : public FGameplayAbilityTargetData_SingleTargetHit
{
	public:
	    int CartridgeID; // 0x90 Size: 0x4
	    int WeaponInfo; // 0x94 Size: 0x4

};

struct FAIPawnUpdateInfo
{
	public:
	    class AFortAIPawn* AIPawn; // 0x0 Size: 0x8
	    char UnknownData0[0x8];

};

struct FFortPendingStoppedEncounterData
{
	public:
	    class UFortAIEncounterInfo* Encounter; // 0x0 Size: 0x8
	    EFortObjectiveStatus ObjectiveStatus; // 0x8 Size: 0x1
	    bool bForceDestroyAI; // 0x9 Size: 0x1
	    bool bEncounterCompletedSuccessfully; // 0xa Size: 0x1
	    char UnknownData0[0x5];

};

struct FFortAIEncounterSpawnGroupCap
{
	public:
	    struct FCurveTableRowHandle MinSpawnGroupNumberCap; // 0x0 Size: 0x10
	    struct FCurveTableRowHandle MaxSpawnGroupNumberCap; // 0x10 Size: 0x10

};

struct FFortPlayerPerformanceEstimateSettings
{
	public:
	    struct FCurveTableRowHandle PlayerPerformanceEstimateTransformMin; // 0x0 Size: 0x10
	    struct FCurveTableRowHandle PlayerPerformanceEstimateTransformOrigin; // 0x10 Size: 0x10
	    struct FCurveTableRowHandle PlayerPerformanceEstimateTransformMax; // 0x20 Size: 0x10
	    float EncounterPlayerPerformanceWeight; // 0x30 Size: 0x4
	    float PreviousWavePlayerPerformanceWeight; // 0x34 Size: 0x4
	    float CampaignPlayerPerformanceWeight; // 0x38 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortAIEncounterPIDController
{
	public:
	    float ProportionalGain; // 0x0 Size: 0x4
	    float IntegralGain; // 0x4 Size: 0x4
	    float DerivativeGain; // 0x8 Size: 0x4
	    char UnknownData0[0x5c];

};

struct FFortAIEncounterPIDControllerSettings
{
	public:
	    struct FCurveTableRowHandle ProportionalGain; // 0x0 Size: 0x10
	    struct FCurveTableRowHandle IntegralGain; // 0x10 Size: 0x10
	    struct FCurveTableRowHandle DerivativeGain; // 0x20 Size: 0x10

};

struct FUtilityContribution
{
	public:
	    char ContributingFactor; // 0x0 Size: 0x1
	    EFortAIDirectorFactor ContributingAIDirectorFactor; // 0x1 Size: 0x1
	    char UnknownData0[0x2]; // 0x2
	    float MaxContribution; // 0x4 Size: 0x4
	    char ContributionType; // 0x8 Size: 0x1
	    char UnknownData1[0x3];

};

struct FUtilityTypeFloatPair
{
	public:
	    char Utility; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float Value; // 0x4 Size: 0x4

};

struct FIntensityContribution
{
	public:
	    char CombatFactor; // 0x0 Size: 0x1
	    EFortAIDirectorFactor ContributingAIDirectorFactor; // 0x1 Size: 0x1
	    char UnknownData0[0x2]; // 0x2
	    float MaxContribution; // 0x4 Size: 0x4
	    bool bModifyContributionByCompletionPercentage; // 0x8 Size: 0x1
	    char UnknownData1[0x7]; // 0x9
	    struct FCurveTableRowHandle CompletionPercentageInitialMultiplier; // 0x10 Size: 0x10
	    struct FCurveTableRowHandle CompletionPercentageToStartReducingMultiplier; // 0x20 Size: 0x10
	    struct FCurveTableRowHandle CompletionPercentageToStopReducingMultiplier; // 0x30 Size: 0x10
	    bool bModifyByNumberOfCriticalEncounterGoals; // 0x40 Size: 0x1
	    char UnknownData2[0x7];

};

struct FFortAIPawnLootDropData
{
	public:
	    float LootDropChance; // 0x0 Size: 0x4
	    FName WorldItemTierGroup; // 0x4 Size: 0x8
	    FName WorldItemInstancedTierGroup; // 0xc Size: 0x8
	    FName AccountItemTierGroup; // 0x14 Size: 0x8

};

struct FFortAISpawnGroupUpgradeUIData
{
	public:
	    bool bAlwaysDisplayHealthBar; // 0x0 Size: 0x1
	    bool bOverrideHealthBarColor; // 0x1 Size: 0x1
	    char UnknownData0[0x6]; // 0x2
	    struct FSlateBrush UpgradeIcon; // 0x8 Size: 0x88
	    struct FLinearColor HealthBarColorOverride; // 0x90 Size: 0x10
	    struct FText UpgradeName; // 0xa0 Size: 0x18

};

struct FFortAIDirectorFactorContribution
{
	public:
	    EFortAIDirectorEvent AIDirectorEvent; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float MaxContribution; // 0x4 Size: 0x4
	    char ContributionType; // 0x8 Size: 0x1
	    char UnknownData1[0x3];

};

struct FAIDirectorEventData
{
	public:
	    EFortAIDirectorEvent Event; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FCurveTableRowHandle DataMax; // 0x8 Size: 0x10
	    struct FCurveTableRowHandle CoolDownRate; // 0x18 Size: 0x10
	    EFortAIDirectorEventContribution ContributionType; // 0x28 Size: 0x1
	    EFortAIDirectorEventParticipant OwnerParticipantType; // 0x29 Size: 0x1
	    char UnknownData1[0x6];

};

struct FFortGoalActorEncounterDataManagerPair
{
	public:
	    class AActor* GoalActor; // 0x0 Size: 0x8
	    class AFortAIDirectorDataManager* EncounterDataManager; // 0x8 Size: 0x8

};

struct FFortAIEncounterWaveProgressEstimation
{
	public:
	    float SectionProgressEstimate; // 0x0 Size: 0x4
	    float SectionStartTime; // 0x4 Size: 0x4
	    float LastWaveProgressUpdateTime; // 0x8 Size: 0x4
	    float PeakAndFadeWavePercentage; // 0xc Size: 0x4
	    float MaxAdjustmentPerSecond; // 0x10 Size: 0x4
	    char CurrentSection; // 0x14 Size: 0x1
	    char UnknownData0[0x3]; // 0x15
	    int NumberOfWaveSegments; // 0x18 Size: 0x4

};

struct FFortEncounterAIDirectorFactor
{
	public:
	    float CurrentValue; // 0x0 Size: 0x4
	    float AccumulatedPeriodValue; // 0x4 Size: 0x4
	    float TotalPeriodTime; // 0x8 Size: 0x4

};

struct FFortCurveSequenceInstanceInfo
{
	public:
	    char UnknownData0[0x4];

};

struct FFortIntensityCurveSequenceInstanceInfo : public FFortCurveSequenceInstanceInfo
{
	public:
	    char UnknownData0[0x4];
	    class UFortIntensityCurveSequence* IntensityCurveSequence; // 0x8 Size: 0x8

};

struct FFortSpawnPointsPercentageCurveSequenceInstanceInfo : public FFortCurveSequenceInstanceInfo
{
	public:
	    char UnknownData0[0x4];
	    class UFortSpawnPointsPercentageCurveSequence* SpawnPointsPercentageCurveSequence; // 0x8 Size: 0x8

};

struct FCurrentIntensityAnalyticsBucket
{
	public:
	    char UnknownData0[0x38];

};

struct FFortIntensityCurve : public FTableRowBase
{
	public:
	    class UCurveTable* IntensityCurveTable; // 0x8 Size: 0x8
	    FName IntensityCurveTableRow; // 0x10 Size: 0x8
	    float LowPlayerPerformancePeakIntensityThreshold; // 0x18 Size: 0x4
	    float NormalPlayerPerformancePeakIntensityThreshold; // 0x1c Size: 0x4
	    float HighPlayerPerformancePeakIntensityThreshold; // 0x20 Size: 0x4
	    float MaxRampTime; // 0x24 Size: 0x4
	    float FadeEndIntensityThreshold; // 0x28 Size: 0x4
	    float StartIntensityOffsetFloor; // 0x2c Size: 0x4
	    float EndIntensityOffsetFloor; // 0x30 Size: 0x4
	    float StartIntensityOffsetCeiling; // 0x34 Size: 0x4
	    float EndIntensityOffsetCeiling; // 0x38 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortSpawnPointsPercentageCurve : public FTableRowBase
{
	public:
	    class UCurveTable* SpawnPointsPercentageCurveTable; // 0x8 Size: 0x8
	    FName SpawnPointsPercentageCurveTableRow; // 0x10 Size: 0x8
	    float MaxRampTime; // 0x18 Size: 0x4
	    char UnknownData0[0x4];

};

struct FAIEncounterSpawnGroupWeights
{
	public:
	    char UnknownData0[0x18];

};

struct FSpawnGroupProgression
{
	public:
	    class UFortAISpawnGroup* SpawnGroup; // 0x0 Size: 0x8

};

struct FFortAIEncounterRift
{
	public:
	    int QueryID; // 0x0 Size: 0x4
	    struct FVector RiftLocation; // 0x4 Size: 0xc
	    class ABuildingRift* RiftActor; // 0x10 Size: 0x8
	    struct FFortRiftReservationHandle RiftReservationHandle; // 0x18 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortAIGoalInfo
{
	public:
	    TWeakObjectPtr<AActor*> Actor; // 0x0 Size: 0x8
	    struct FVector Location; // 0x8 Size: 0xc
	    bool bActorAlwaysPerceived; // 0x14 Size: 0x1
	    char UnknownData0[0x3];

};

struct FAIAssignmentInfo
{
	public:
	    TWeakObjectPtr<UFortAIAssignment*> CurrentAssignment; // 0x0 Size: 0x8
	    struct FFortAIGoalInfo CurrentGoal; // 0x8 Size: 0x18
	    float TimeCurrentGoalWasChosen; // 0x20 Size: 0x4
	    float TimeExitedLastAssignmentOfType; // 0x24 Size: 0x4
	    char UnknownData0[0xc]; // 0x28
	    TWeakObjectPtr<UFortAIAssignment*> PreviousAssignment; // 0x34 Size: 0x8
	    struct FFortAIGoalInfo PreviousGoal; // 0x3c Size: 0x18
	    bool bWaitingForQueryResponse; // 0x54 Size: 0x1
	    bool bSuppressGoalUpdates; // 0x55 Size: 0x1
	    bool bReportEnemyGoalSelection; // 0x56 Size: 0x1
	    char UnknownData1[0x29];

};

struct FAIDiscouragedGoalTimer
{
	public:
	    struct FFortAIGoalInfo DiscouragedGoalInfo; // 0x0 Size: 0x18
	    double ExpirationTime; // 0x18 Size: 0x8
	    uint32_t NumberOfTimesMarkedForDiscouragement; // 0x20 Size: 0x4
	    char UnknownData0[0x4];

};

struct FGoalSelectionCriteria
{
	public:
	    class UEnvQuery* GoalSelectionQuery; // 0x0 Size: 0x8

};

struct FAutoAcquireSlot : public FAIHotSpotSlotInfo
{
	public:
	    char UnknownData0[0x20];

};

struct FFortAISharedRepMovement
{
	public:
	    struct FRepMovement RepMovement; // 0x0 Size: 0x34
	    float RepTimeStamp; // 0x34 Size: 0x4
	    char RepMovementMode; // 0x38 Size: 0x1
	    EFortAILODLevel RepCurrentFortAILODLevel; // 0x39 Size: 0x1
	    char UnknownData0[0x2]; // 0x3a
	    struct FGameplayAbilityRepSharedAnim_Index RepSharedAnimInfo; // 0x3c Size: 0x8

};

struct FFortAIBatchedDamageCues
{
	public:
	    bool bImpact; // 0x0 Size: 0x1
	    bool bImpactWeapon; // 0x1 Size: 0x1
	    bool bDamage; // 0x2 Size: 0x1
	    bool bDamageShields; // 0x3 Size: 0x1
	    bool bDamageWeapon; // 0x4 Size: 0x1
	    bool bFatal; // 0x5 Size: 0x1
	    bool bWeaponActivated; // 0x6 Size: 0x1
	    char UnknownData0[0x1]; // 0x7
	    struct FVector_NetQuantize10 HitLocation; // 0x8 Size: 0xc
	    char UnknownData1[0x4]; // 0x14
	    class AActor* TargetActor; // 0x18 Size: 0x8

};

struct FFortAIAttributeReplicationProxy
{
	public:
	    int16_t Health; // 0x0 Size: 0x2
	    int16_t MaxHealth; // 0x2 Size: 0x2

};

struct FDamagerInfoAnalytics
{
	public:
	    struct FString DamageCauser; // 0x0 Size: 0x10
	    int DamageAmount; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortPawnStats : public FTableRowBase
{
	public:
	    float MaximumHealth; // 0x8 Size: 0x4
	    float SpeedWalk; // 0xc Size: 0x4
	    float SpeedRun; // 0x10 Size: 0x4
	    float SpeedSprint; // 0x14 Size: 0x4
	    float SpeedFly; // 0x18 Size: 0x4
	    float SpeedCrouchedRun; // 0x1c Size: 0x4
	    float SpeedCrouchedSprint; // 0x20 Size: 0x4
	    float SpeedBackwardsMultiplier; // 0x24 Size: 0x4
	    float SpeedDBNO; // 0x28 Size: 0x4
	    float AccelerationStrafeMultiplierSprint; // 0x2c Size: 0x4
	    float MinAnalogWalkSpeed; // 0x30 Size: 0x4
	    float GroundFriction; // 0x34 Size: 0x4
	    float BrakingDecelerationWalking; // 0x38 Size: 0x4
	    float BrakingDecelerationFalling; // 0x3c Size: 0x4
	    float BrakingDecelerationFlying; // 0x40 Size: 0x4
	    float BrakingFrictionFactor; // 0x44 Size: 0x4
	    float MaxAcceleration; // 0x48 Size: 0x4
	    float MaxAccelerationFlying; // 0x4c Size: 0x4
	    float JumpZVelocity; // 0x50 Size: 0x4
	    char UnknownData0[0x4]; // 0x54
	    class UCurveTable* FallingDamageTable; // 0x58 Size: 0x8
	    FName FallingDamageTableRow; // 0x60 Size: 0x8
	    class UCurveTable* VehicleEjectDamageTable; // 0x68 Size: 0x8
	    float HealthRegenRate; // 0x70 Size: 0x4
	    float HealthRegenDelay; // 0x74 Size: 0x4
	    float HealthRegenThreshold; // 0x78 Size: 0x4
	    float MaxShield; // 0x7c Size: 0x4
	    float ShieldRegenRate; // 0x80 Size: 0x4
	    float ShieldRegenDelay; // 0x84 Size: 0x4
	    float ShieldRegenThreshold; // 0x88 Size: 0x4
	    float MaxControlResistance; // 0x8c Size: 0x4
	    float ControlResistanceRegenRate; // 0x90 Size: 0x4
	    float ControlResistanceRegenDelay; // 0x94 Size: 0x4
	    float ControlResistanceRegenThreshold; // 0x98 Size: 0x4
	    float KnockbackMultiplier; // 0x9c Size: 0x4
	    float KnockbackThreshold; // 0xa0 Size: 0x4
	    bool bAllowChainStun; // 0xa4 Size: 0x1
	    EFortControlRecoveryBehavior ControlRecoveryBehavior; // 0xa5 Size: 0x1
	    char UnknownData1[0x2];

};

struct FFortAIPawnStats : public FFortPawnStats
{
	public:
	    int ScoreValue; // 0xa8 Size: 0x4
	    float DormantSightRadius; // 0xac Size: 0x4
	    float DormantHearingThreshold; // 0xb0 Size: 0x4
	    float DormantLOSHearingThreshold; // 0xb4 Size: 0x4
	    float DormantPeripheralVisionAngle; // 0xb8 Size: 0x4
	    float AlertSightRadius; // 0xbc Size: 0x4
	    float AlertHearingThreshold; // 0xc0 Size: 0x4
	    float AlertLOSHearingThreshold; // 0xc4 Size: 0x4
	    float AlertPeripheralVisionAngle; // 0xc8 Size: 0x4
	    float AutoSuccessRangeFromLastSeenLocation; // 0xcc Size: 0x4
	    class UCurveTable* HealthScalingTable; // 0xd0 Size: 0x8
	    FName HealthScalingTableRow; // 0xd8 Size: 0x8
	    class UCurveTable* ControlResistanceScalingTable; // 0xe0 Size: 0x8
	    FName ControlResistanceScalingTableRow; // 0xe8 Size: 0x8
	    class UCurveTable* DifficultyRatingTable; // 0xf0 Size: 0x8
	    FName DifficultyRatingTableRow; // 0xf8 Size: 0x8

};

struct FFortAIAppearanceOverrideEntry
{
	public:
	    FName AppearanceName; // 0x0 Size: 0x8
	    bool bIsFemale; // 0x8 Size: 0x1
	    char UnknownData0[0x7]; // 0x9
	    struct TSoftObjectPtr<struct USkeletalMesh*> SkeletalMesh; // 0x10 Size: 0x28
	    struct TSoftObjectPtr<struct UFortFeedbackBank*> FeedbackBank; // 0x38 Size: 0x28

};

struct FRunVariationData
{
	public:
	    TWeakObjectPtr<AFortAIPawn*> FortAIPawn; // 0x0 Size: 0x8
	    float Distance; // 0x8 Size: 0x4

};

struct FFortVariantSpawnPoints : public FTableRowBase
{
	public:
	    int BudgetPoints; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FSpawnGroupEnemy
{
	public:
	    class UFortAIPawnVariant* EnemyVariantClass; // 0x0 Size: 0x8
	    bool bOverrideVariantSpawnPointValue; // 0x8 Size: 0x1
	    char UnknownData0[0x3]; // 0x9
	    int SpawnValue; // 0xc Size: 0x4

};

struct FFortMoveConfig
{
	public:
	    class AActor* FocusTarget; // 0x18 Size: 0x8
	    class AFortPawn* PushPawnClassOnBump; // 0x20 Size: 0x8

};

struct FAIHotSpotUseInfo : public FAIHotSpotSlotInfo
{
	public:
	    char UnknownData0[0x18];

};

struct FFortNavLinkPattern
{
	public:
	    int PatternBits; // 0x0 Size: 0x4
	    int WildcardBits; // 0x4 Size: 0x4

};

struct FBuildingActorNavArea
{
	public:
	    int AreaBits; // 0x0 Size: 0x4

};

struct FAlterationSlot
{
	public:
	    int UnlockLevel; // 0x0 Size: 0x4
	    EFortRarity UnlockRarity; // 0x4 Size: 0x1
	    char UnknownData0[0x3]; // 0x5
	    FName SlotDefinitionRow; // 0x8 Size: 0x8
	    bool bRespeccable; // 0x10 Size: 0x1
	    char UnknownData1[0x3]; // 0x11
	    FName SlotRarityInitRow; // 0x14 Size: 0x8
	    EFortRarity SlotInitMin; // 0x1c Size: 0x1
	    EFortRarity SlotInitMax; // 0x1d Size: 0x1
	    char UnknownData2[0x2]; // 0x1e
	    int SlotInitIndex; // 0x20 Size: 0x4

};

struct FAlterationSlotRarity : public FTableRowBase
{
	public:
	    __int64/*MapProperty*/ RarityWeights; // 0x8 Size: 0x50

};

struct FAlterationGroup : public FTableRowBase
{
	public:
	    __int64/*MapProperty*/ RarityMapping; // 0x8 Size: 0x50

};

struct FAlterationIntrinsicMapping : public FTableRowBase
{
	public:
	    struct FString NewAlteration; // 0x8 Size: 0x10

};

struct FAlterationMapping : public FTableRowBase
{
	public:
	    struct FString NewAlteration; // 0x8 Size: 0x10
	    struct FString AdditionalAlteration; // 0x18 Size: 0x10

};

struct FFortCosmeticModification
{
	public:
	    struct TSoftObjectPtr<struct UMaterialInterface*> CosmeticMaterial; // 0x0 Size: 0x28
	    struct TSoftObjectPtr<struct UParticleSystem*> AmbientParticleSystem; // 0x28 Size: 0x28
	    struct TSoftObjectPtr<struct UParticleSystem*> MuzzleParticleSystem; // 0x50 Size: 0x28
	    struct TSoftObjectPtr<struct UParticleSystem*> ReloadParticleSystem; // 0x78 Size: 0x28
	    struct TSoftObjectPtr<struct UParticleSystem*> BeamParticleSystem; // 0xa0 Size: 0x28
	    struct TSoftObjectPtr<struct UParticleSystem*> ImpactPhysicalSurfaceEffects; // 0xc8 Size: 0x28
	    char UnknownData0[0x3c0]; // 0xf0
	    __int64/*SoftClassProperty*/ TracerTemplate; // 0x4b0 Size: 0x28
	    bool bModifyColor; // 0x4d8 Size: 0x1
	    char UnknownData1[0x3]; // 0x4d9
	    struct FLinearColor ColorAlteration; // 0x4dc Size: 0x10
	    FName ColorParameterName; // 0x4ec Size: 0x8
	    bool bModifyDecalColour; // 0x4f4 Size: 0x1
	    char UnknownData2[0x3]; // 0x4f5
	    struct FLinearColor DecalColourAlterationStart; // 0x4f8 Size: 0x10
	    struct FLinearColor DecalColourAlterationEnd; // 0x508 Size: 0x10
	    bool bModifyShellColour; // 0x518 Size: 0x1
	    char UnknownData3[0x3]; // 0x519
	    struct FLinearColor ShellColourAlteration; // 0x51c Size: 0x10
	    char UnknownData4[0x4];

};

struct FFortAnimInput_SkydivingExternalForce
{
	public:
	    bool bUseSkydivingVectorForce; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    struct FVector SkydivingVectorForce; // 0x4 Size: 0xc
	    struct FVector HeadToPelvisDirection; // 0x10 Size: 0xc
	    struct FVector FloatingMultiplier; // 0x1c Size: 0xc
	    struct FVector FloatingAdditive; // 0x28 Size: 0xc
	    struct FVector DivingMultiplier; // 0x34 Size: 0xc
	    struct FVector DivingAdditive; // 0x40 Size: 0xc
	    struct FVector ParachutingMultiplier; // 0x4c Size: 0xc
	    struct FVector ParachutingAdditive; // 0x58 Size: 0xc
	    bool bUseNoisyClothGravity; // 0x64 Size: 0x1
	    char UnknownData1[0x3]; // 0x65
	    float PerlinRangedOutMinX; // 0x68 Size: 0x4
	    float PerlinRangedOutMaxX; // 0x6c Size: 0x4
	    float PerlinRangedOutMinY; // 0x70 Size: 0x4
	    float PerlinRangedOutMaxY; // 0x74 Size: 0x4
	    float PerlinRangedOutMinZ; // 0x78 Size: 0x4
	    float PerlinRangedOutMaxZ; // 0x7c Size: 0x4
	    char UnknownData2[0x4];

};

struct FFortAnimInput_AdjustedAimOffset
{
	public:
	    float YawOffset; // 0x0 Size: 0x4
	    float PitchOffset; // 0x4 Size: 0x4
	    float TargetingYawOffset; // 0x8 Size: 0x4
	    float TargetingPitchOffset; // 0xc Size: 0x4

};

struct FFortAnimInput_PlayerAnimAsset
{
	public:
	    bool bShouldApplyAimOffsetFullBody; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float FullBodyAimOffsetAlpha; // 0x4 Size: 0x4
	    float UpperBodyAimOffsetAlpha; // 0x8 Size: 0x4
	    char UnknownData1[0x4]; // 0xc
	    class UAnimSequence* TargetingPose; // 0x10 Size: 0x8
	    class UAimOffsetBlendSpace* TargetingAimOffset; // 0x18 Size: 0x8
	    class UAnimSequence* NonTargetingPose; // 0x20 Size: 0x8
	    class UAimOffsetBlendSpace* NonTargetingAimOffset; // 0x28 Size: 0x8
	    class UAnimSequence* RelaxedPose; // 0x30 Size: 0x8
	    class UAnimSequence* RelaxedPoseLevel2; // 0x38 Size: 0x8
	    class UAimOffsetBlendSpace* RelaxedAimOffset; // 0x40 Size: 0x8
	    class UBlendSpaceBase* JogAdditiveBlendSpace; // 0x48 Size: 0x8
	    class UBlendSpaceBase* JogAdditiveBlendSpaceRelaxed; // 0x50 Size: 0x8
	    class UBlendSpaceBase* JogAdditiveBlendSpaceRelaxedLevel2; // 0x58 Size: 0x8
	    class UAnimSequence* SprintAnimation; // 0x60 Size: 0x8
	    class UAnimSequence* CrouchTargetingPose; // 0x68 Size: 0x8
	    class UAnimSequence* CrouchNonTargetingPose; // 0x70 Size: 0x8
	    class UAnimSequence* CrouchRelaxedPose; // 0x78 Size: 0x8
	    class UBlendSpaceBase* CrouchWalkAdditiveBlendSpace; // 0x80 Size: 0x8
	    class UBlendSpaceBase* CrouchJogAdditiveBlendSpace; // 0x88 Size: 0x8
	    class UBlendSpaceBase* CrouchJogAdditiveBlendSpaceRelaxed; // 0x90 Size: 0x8
	    class UAnimSequence* CrouchSprintAnimation; // 0x98 Size: 0x8
	    class UAnimSequence* IdleNoise; // 0xa0 Size: 0x8
	    class UAnimSequence* IdleNoise_AR_DownSights; // 0xa8 Size: 0x8
	    bool bOverridePitchAndYawOffsets; // 0xb0 Size: 0x1
	    char UnknownData2[0x3]; // 0xb1
	    struct FFortAnimInput_AdjustedAimOffset AnimSetOffsets; // 0xb4 Size: 0x10
	    char UnknownData3[0x4];

};

struct FFortAnimInput_Skydiving
{
	public:
	    bool bIsSkydivingFromLaunchPad; // 0x0 Size: 0x1
	    bool bIsSkydivingFromBus; // 0x0 Size: 0x1
	    bool bIsInVortex; // 0x0 Size: 0x1
	    bool bIsUsingUmbrella; // 0x0 Size: 0x1
	    bool bIsActivelyStrafingInAir; // 0x0 Size: 0x1
	    bool bIsDiving; // 0x0 Size: 0x1
	    bool bIsDivingUpInVortex; // 0x0 Size: 0x1
	    bool bIsParachuteOpen; // 0x0 Size: 0x1
	    bool bIsSkydiving; // 0x1 Size: 0x1
	    bool bIsParachuteLeaning; // 0x1 Size: 0x1
	    bool bIsSkydiveLeaning; // 0x1 Size: 0x1
	    bool bIsLeaning; // 0x1 Size: 0x1
	    bool bIsSkydiveDiveMode; // 0x1 Size: 0x1
	    bool bParachuteLeanTransition; // 0x1 Size: 0x1
	    bool bPlayedParachuteLeanTransition; // 0x1 Size: 0x1
	    bool bPlaySkydiveDrift; // 0x1 Size: 0x1
	    bool bSkydiveDriftDelayActive; // 0x2 Size: 0x1
	    bool bSkydiveDriftAnimAllowed; // 0x2 Size: 0x1
	    Yea, we fucked up; // 0x0
	    float LocalAccelForward; // 0x4 Size: 0x4
	    float LocalAccelRight; // 0x8 Size: 0x4
	    float LocalVelocityRight; // 0xc Size: 0x4
	    float SkydiveAimPitch; // 0x10 Size: 0x4
	    float SkydiveAimPitchInterpSpeed; // 0x14 Size: 0x4
	    float SkydiveAimYaw; // 0x18 Size: 0x4
	    float DeployChuteAnimRate; // 0x1c Size: 0x4
	    float SkydiveDriftAnimRate; // 0x20 Size: 0x4
	    float SkydiveDriftAnimRateCurrent; // 0x24 Size: 0x4
	    float SkydiveFidgetAnimRate; // 0x28 Size: 0x4
	    float SkydiveFidgetAnimRateCurrent; // 0x2c Size: 0x4
	    float SkydiveAdditiveAlpha; // 0x30 Size: 0x4
	    float SkydiveDriftDelay; // 0x34 Size: 0x4
	    int SkydiveDriftAnim; // 0x38 Size: 0x4
	    int SkydiveDriftAnimMax; // 0x3c Size: 0x4
	    int LaunchpadAnim; // 0x40 Size: 0x4
	    char LocalAccelDir; // 0x44 Size: 0x1
	    char DirectionLast; // 0x45 Size: 0x1
	    char UnknownData1[0x2];

};

struct FFortAnimInput_AdjustedAim
{
	public:
	    struct FFortAnimInput_AdjustedAimOffset* WeaponOffsets; // 0x0 Size: 0x10
	    char UnknownData0[0x1d0]; // 0x10
	    float YawOffset; // 0x1e0 Size: 0x4
	    float PitchOffset; // 0x1e4 Size: 0x4
	    float YawScale; // 0x1e8 Size: 0x4
	    float PitchScale; // 0x1ec Size: 0x4
	    float ResultingYaw; // 0x1f0 Size: 0x4
	    float ResultingPitch; // 0x1f4 Size: 0x4
	    FName ZeroOutPitchWeightCurveName; // 0x1f8 Size: 0x8

};

struct FFortAnimInput_SpeedWarping
{
	public:
	    class UCurveFloat* PlayRateAdjustmentCurve; // 0x0 Size: 0x8
	    struct FVector2D SpeedWarpingLimits; // 0x8 Size: 0x8
	    struct FVector2D SpeedWarpingLimitsAddlRateScale; // 0x10 Size: 0x8
	    float SpeedWarpingAmount; // 0x18 Size: 0x4
	    float PlayRate; // 0x1c Size: 0x4

};

struct FFortAnimInput_CommonWeapon
{
	public:
	    bool bForceUpperBodyTargeting; // 0x0 Size: 0x1

};

struct FFortAnimInput_CommonVehicle
{
	public:
	    bool bIsUsingVehicle; // 0x0 Size: 0x1
	    bool bIsJumpingVehicle; // 0x1 Size: 0x1
	    bool bIsJumping; // 0x8 Size: 0x1
	    bool bIsOnGround; // 0x9 Size: 0x1
	    bool bCanDriverAimWeapon; // 0xa Size: 0x1
	    char UnknownData0[0x7];

};

struct FFortAnimInput_ShoppingCart
{
	public:
	    bool bIsUsingShoppingCart; // 0x0 Size: 0x1
	    ECoastState CoastState; // 0x1 Size: 0x1
	    bool bIsCoastStatePedaling; // 0x2 Size: 0x1
	    bool bIsCoastStateCoasting; // 0x3 Size: 0x1
	    bool bIsCoastStateDismount; // 0x4 Size: 0x1
	    bool bIsCoastStateIdle; // 0x5 Size: 0x1
	    bool bIsInAir; // 0x6 Size: 0x1
	    bool bIsCoasting; // 0x7 Size: 0x1
	    bool bIsPedaling; // 0x8 Size: 0x1
	    bool bIsReadyToPedal; // 0x9 Size: 0x1
	    char UnknownData0[0x2]; // 0xa
	    float IsReadyToPedal; // 0xc Size: 0x4
	    bool bWantsToCoast; // 0x10 Size: 0x1
	    bool bIsCoastIdling; // 0x11 Size: 0x1
	    bool bIsStartCoasting; // 0x12 Size: 0x1
	    bool bIsEndCoasting; // 0x13 Size: 0x1
	    bool bIsDismountingFromCoast; // 0x14 Size: 0x1
	    bool bIsCoastingOrDismountingFromCoast; // 0x15 Size: 0x1
	    bool bIsStandingInPlace; // 0x16 Size: 0x1
	    bool bIsSprinting; // 0x17 Size: 0x1
	    bool bIsSprintingAndMovingForward; // 0x18 Size: 0x1
	    bool bIsMovingForwardNotSprinting; // 0x19 Size: 0x1
	    bool bIsBraking; // 0x1a Size: 0x1
	    bool bIsReversing; // 0x1b Size: 0x1
	    bool bIsMoving; // 0x1c Size: 0x1
	    bool bIsMovingForward; // 0x1d Size: 0x1
	    bool bIsMovingBackwards; // 0x1e Size: 0x1
	    bool bIsMovingOrTurningInPlace; // 0x1f Size: 0x1
	    bool bIsInAirSteady; // 0x20 Size: 0x1
	    bool bIsOnSlope; // 0x21 Size: 0x1
	    bool bAimFWD; // 0x22 Size: 0x1
	    bool bAimBWD; // 0x23 Size: 0x1
	    bool bAimLFT; // 0x24 Size: 0x1
	    bool bAimRGT; // 0x25 Size: 0x1
	    char UnknownData1[0x2]; // 0x26
	    float ForwardVelocity; // 0x28 Size: 0x4
	    float ForwardSpeedKmH; // 0x2c Size: 0x4
	    float CurrentBrakeForce; // 0x30 Size: 0x4
	    float RunForwardAlpha; // 0x34 Size: 0x4
	    bool bIsAcceleratingForward; // 0x38 Size: 0x1
	    bool bIsAccelBreakingOrReversing; // 0x39 Size: 0x1
	    char UnknownData2[0x2]; // 0x3a
	    float SteerAngle; // 0x3c Size: 0x4
	    float SteerAngleInterpSpeed; // 0x40 Size: 0x4
	    float CoastSteerAngleInterpSpeed; // 0x44 Size: 0x4
	    float IsReadyToPedalInterpSpeed; // 0x48 Size: 0x4
	    float StandingInPlaceSteerAngle; // 0x4c Size: 0x4
	    float SlopePitchDegreeAngle; // 0x50 Size: 0x4
	    float SlopeRollDegreeAngle; // 0x54 Size: 0x4
	    float PawnToVehicleDeltaYawAngleDegrees; // 0x58 Size: 0x4
	    float AimCardDirDeadZoneAngleDegrees; // 0x5c Size: 0x4
	    float AimCardDirAngleOffsetDegrees; // 0x60 Size: 0x4
	    float AimFWDDeltaAngleDegrees; // 0x64 Size: 0x4
	    float AimBWDDeltaAngleDegrees; // 0x68 Size: 0x4
	    float AimLFTDeltaAngleDegrees; // 0x6c Size: 0x4
	    float AimRGTDeltaAngleDegrees; // 0x70 Size: 0x4
	    int LastCardDirIndex; // 0x74 Size: 0x4

};

struct FFortAnimInput_FerretVehicle
{
	public:
	    bool bIsUsingFerretVehicle; // 0x0 Size: 0x1
	    bool bIsDriver; // 0x1 Size: 0x1
	    bool bIsFrontPassenger; // 0x2 Size: 0x1
	    bool bIsBackLeftPassenger; // 0x3 Size: 0x1
	    bool bIsBackRightPassenger; // 0x4 Size: 0x1
	    bool bIsFrontPassengerAndLeaning; // 0x5 Size: 0x1
	    bool bIsBackPassengerAndLeaning; // 0x6 Size: 0x1
	    bool bIsDrifting; // 0x7 Size: 0x1
	    bool bIsBoosting; // 0x8 Size: 0x1
	    bool bIsReversing; // 0x9 Size: 0x1
	    bool bIsBraking; // 0xa Size: 0x1
	    bool bIsMoving; // 0xb Size: 0x1
	    bool bIsMovingForward; // 0xc Size: 0x1
	    bool bIsLeaning; // 0xd Size: 0x1
	    bool bIsLeaningOrBouncing; // 0xe Size: 0x1
	    bool bIsBounceCrouching; // 0xf Size: 0x1
	    bool bIsBounceCrouched; // 0x10 Size: 0x1
	    bool bIsBounceJumping; // 0x11 Size: 0x1
	    bool bIsBounceRecoiling; // 0x12 Size: 0x1
	    bool bIsSteeringRight; // 0x13 Size: 0x1
	    bool bIsSteeringLeft; // 0x14 Size: 0x1
	    bool bIsShooting; // 0x15 Size: 0x1
	    bool bIsFerretPassengerRotating; // 0x16 Size: 0x1
	    char UnknownData0[0x1]; // 0x17
	    float RunForwardAlpha; // 0x18 Size: 0x4
	    float BounceCompression; // 0x1c Size: 0x4
	    struct FVector LeanPosition; // 0x20 Size: 0xc
	    float LeanPositionX; // 0x2c Size: 0x4
	    float LeanPositionY; // 0x30 Size: 0x4
	    float LeanPositionZ; // 0x34 Size: 0x4
	    bool bAimFWD; // 0x38 Size: 0x1
	    bool bAimBWD; // 0x39 Size: 0x1
	    bool bAimLFT; // 0x3a Size: 0x1
	    bool bAimRGT; // 0x3b Size: 0x1
	    float PawnToVehicleDeltaYawAngleDegrees; // 0x3c Size: 0x4
	    float AimCardDirDeadZoneAngleDegrees; // 0x40 Size: 0x4
	    float AimCardDirAngleOffsetDegrees; // 0x44 Size: 0x4
	    int LastCardDirIndex; // 0x48 Size: 0x4
	    float AimFWDDeltaAngleDegrees; // 0x4c Size: 0x4
	    float AimBWDDeltaAngleDegrees; // 0x50 Size: 0x4
	    float AimLFTDeltaAngleDegrees; // 0x54 Size: 0x4
	    float AimRGTDeltaAngleDegrees; // 0x58 Size: 0x4
	    float SlopePitchDegreeAngle; // 0x5c Size: 0x4
	    float SlopeRollDegreeAngle; // 0x60 Size: 0x4
	    float SteerAngle; // 0x64 Size: 0x4
	    struct FVector SeatSwitchDirection; // 0x68 Size: 0xc

};

struct FFortAnimInput_MountedTurret
{
	public:
	    bool bIsUsingMountedTurret; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float AimingYaw; // 0x4 Size: 0x4
	    float AimingPitch; // 0x8 Size: 0x4
	    float PedalScaler; // 0xc Size: 0x4

};

struct FFortAnimInput_Quad
{
	public:
	    bool bIsUsingQuad; // 0x0 Size: 0x1
	    bool bIsDriver; // 0x1 Size: 0x1
	    bool bIsFrontPassenger; // 0x2 Size: 0x1
	    bool bIsBackPassenger; // 0x3 Size: 0x1
	    bool bIsBackPassengerAndLeaning; // 0x4 Size: 0x1
	    bool bIsDrifting; // 0x5 Size: 0x1
	    bool bIsBoosting; // 0x6 Size: 0x1
	    bool bIsReversing; // 0x7 Size: 0x1
	    bool bIsBraking; // 0x8 Size: 0x1
	    bool bIsMoving; // 0x9 Size: 0x1
	    bool bIsMovingForward; // 0xa Size: 0x1
	    bool bIsLeaning; // 0xb Size: 0x1
	    bool bIsLeaningOrBouncing; // 0xc Size: 0x1
	    bool bIsBounceCrouching; // 0xd Size: 0x1
	    bool bIsBounceCrouched; // 0xe Size: 0x1
	    bool bIsBounceJumping; // 0xf Size: 0x1
	    bool bIsBounceRecoiling; // 0x10 Size: 0x1
	    bool bIsSteeringRight; // 0x11 Size: 0x1
	    bool bIsSteeringLeft; // 0x12 Size: 0x1
	    char UnknownData0[0x1]; // 0x13
	    float RunForwardAlpha; // 0x14 Size: 0x4
	    float BounceCompression; // 0x18 Size: 0x4
	    struct FVector LeanPosition; // 0x1c Size: 0xc
	    float LeanPositionX; // 0x28 Size: 0x4
	    float LeanPositionY; // 0x2c Size: 0x4
	    float LeanPositionZ; // 0x30 Size: 0x4
	    float VerticalVelocity; // 0x34 Size: 0x4
	    float VerticalAcceleration; // 0x38 Size: 0x4
	    bool bAimFWD; // 0x3c Size: 0x1
	    bool bAimBWD; // 0x3d Size: 0x1
	    bool bAimLFT; // 0x3e Size: 0x1
	    bool bAimRGT; // 0x3f Size: 0x1
	    float PawnToVehicleDeltaYawAngleDegrees; // 0x40 Size: 0x4
	    float AimCardDirDeadZoneAngleDegrees; // 0x44 Size: 0x4
	    float AimCardDirAngleOffsetDegrees; // 0x48 Size: 0x4
	    int LastCardDirIndex; // 0x4c Size: 0x4
	    float AimFWDDeltaAngleDegrees; // 0x50 Size: 0x4
	    float AimBWDDeltaAngleDegrees; // 0x54 Size: 0x4
	    float AimLFTDeltaAngleDegrees; // 0x58 Size: 0x4
	    float AimRGTDeltaAngleDegrees; // 0x5c Size: 0x4
	    float SlopePitchDegreeAngle; // 0x60 Size: 0x4
	    float SlopeRollDegreeAngle; // 0x64 Size: 0x4
	    float SteerAngle; // 0x68 Size: 0x4
	    float SteerAlpha; // 0x6c Size: 0x4
	    float SteerAngleDeadZoneDegrees; // 0x70 Size: 0x4
	    float SteeringRotation; // 0x74 Size: 0x4
	    float VehiclePitch; // 0x78 Size: 0x4
	    float VehicleRoll; // 0x7c Size: 0x4

};

struct FFortAnimInput_GolfCart
{
	public:
	    bool bIsUsingGolfCart; // 0x0 Size: 0x1
	    bool bIsDriver; // 0x1 Size: 0x1
	    bool bIsFrontPassenger; // 0x2 Size: 0x1
	    bool bIsBackLeftPassenger; // 0x3 Size: 0x1
	    bool bIsBackRightPassenger; // 0x4 Size: 0x1
	    bool bIsFrontPassengerAndLeaning; // 0x5 Size: 0x1
	    bool bIsBackPassengerAndLeaning; // 0x6 Size: 0x1
	    bool bIsDrifting; // 0x7 Size: 0x1
	    bool bIsBoosting; // 0x8 Size: 0x1
	    bool bIsEBraking; // 0x9 Size: 0x1
	    bool bIsReversing; // 0xa Size: 0x1
	    bool bIsBraking; // 0xb Size: 0x1
	    bool bIsMoving; // 0xc Size: 0x1
	    bool bIsMovingForward; // 0xd Size: 0x1
	    bool bIsPowerSliding; // 0xe Size: 0x1
	    bool bIsLeaning; // 0xf Size: 0x1
	    bool bIsLeaningOrBouncing; // 0x10 Size: 0x1
	    bool bIsBounceCrouching; // 0x11 Size: 0x1
	    bool bIsBounceCrouched; // 0x12 Size: 0x1
	    bool bIsBounceJumping; // 0x13 Size: 0x1
	    bool bIsBounceRecoiling; // 0x14 Size: 0x1
	    bool bIsSteeringRight; // 0x15 Size: 0x1
	    bool bIsSteeringLeft; // 0x16 Size: 0x1
	    char UnknownData0[0x1]; // 0x17
	    float RunForwardAlpha; // 0x18 Size: 0x4
	    float BounceCompression; // 0x1c Size: 0x4
	    struct FVector LeanPosition; // 0x20 Size: 0xc
	    float LeanPositionX; // 0x2c Size: 0x4
	    float LeanPositionY; // 0x30 Size: 0x4
	    float LeanPositionZ; // 0x34 Size: 0x4
	    bool bAimFWD; // 0x38 Size: 0x1
	    bool bAimBWD; // 0x39 Size: 0x1
	    bool bAimLFT; // 0x3a Size: 0x1
	    bool bAimRGT; // 0x3b Size: 0x1
	    float PawnToVehicleDeltaYawAngleDegrees; // 0x3c Size: 0x4
	    float AimCardDirDeadZoneAngleDegrees; // 0x40 Size: 0x4
	    float AimCardDirAngleOffsetDegrees; // 0x44 Size: 0x4
	    int LastCardDirIndex; // 0x48 Size: 0x4
	    float AimFWDDeltaAngleDegrees; // 0x4c Size: 0x4
	    float AimBWDDeltaAngleDegrees; // 0x50 Size: 0x4
	    float AimLFTDeltaAngleDegrees; // 0x54 Size: 0x4
	    float AimRGTDeltaAngleDegrees; // 0x58 Size: 0x4
	    float SlopePitchDegreeAngle; // 0x5c Size: 0x4
	    float SlopeRollDegreeAngle; // 0x60 Size: 0x4
	    float SteerAngle; // 0x64 Size: 0x4

};

struct FFortAnimInput_VelocityImpact
{
	public:
	    struct FVector LastVelocity; // 0x0 Size: 0xc
	    struct FVector DeltaVelocityThreshold; // 0xc Size: 0xc
	    struct FVector ImpactScale; // 0x18 Size: 0xc
	    struct FInputRange ImpactLimitX; // 0x24 Size: 0x8
	    struct FInputRange ImpactLimitY; // 0x2c Size: 0x8
	    struct FInputRange ImpactLimitZ; // 0x34 Size: 0x8
	    struct FFloatRK4SpringInterpolator SpringInterpolatorX; // 0x3c Size: 0x8
	    char UnknownData0[0x1c]; // 0x44
	    struct FFloatRK4SpringInterpolator SpringInterpolatorY; // 0x60 Size: 0x8
	    char UnknownData1[0x1c]; // 0x68
	    struct FFloatRK4SpringInterpolator SpringInterpolatorZ; // 0x84 Size: 0x8
	    bool bTestVelocity; // 0xa8 Size: 0x1
	    char UnknownData2[0x1f]; // 0x8d
	    struct FVector TestVelocity; // 0xac Size: 0xc
	    bool bIsForwardImpact; // 0xb8 Size: 0x1
	    bool bIsBackwardImpact; // 0xb9 Size: 0x1
	    bool bIsLeftImpact; // 0xba Size: 0x1
	    bool bIsRightImpact; // 0xbb Size: 0x1
	    bool bIsUpImpact; // 0xbc Size: 0x1
	    bool bIsDownImpact; // 0xbd Size: 0x1
	    char UnknownData3[0x2];

};

struct FFortAnimInput_JackalVehicle
{
	public:
	    bool bIsUsingJackalVehicle; // 0x0 Size: 0x1
	    bool bIsSteeringLeft; // 0x1 Size: 0x1
	    bool bIsSteeringRight; // 0x2 Size: 0x1
	    char UnknownData0[0x1]; // 0x3
	    float SteerAngleDeadZoneDegrees; // 0x4 Size: 0x4
	    float SteerAngle; // 0x8 Size: 0x4
	    float LeanYaw; // 0xc Size: 0x4
	    float QuantizedSteerAngle; // 0x10 Size: 0x4
	    float SteerAlpha; // 0x14 Size: 0x4
	    float RunForwardAlpha; // 0x18 Size: 0x4
	    float SlopePitchDegreeAngle; // 0x1c Size: 0x4
	    float SlopeRollDegreeAngle; // 0x20 Size: 0x4
	    float DistanceFromGround; // 0x24 Size: 0x4
	    bool bIsReversing; // 0x28 Size: 0x1
	    bool bIsBraking; // 0x29 Size: 0x1
	    bool bIsMoving; // 0x2a Size: 0x1
	    bool bIsMovingForward; // 0x2b Size: 0x1
	    bool bIsSprinting; // 0x2c Size: 0x1
	    bool bInAir; // 0x2d Size: 0x1
	    bool bIsFalling; // 0x2e Size: 0x1
	    bool bIsJumping; // 0x2f Size: 0x1
	    bool bIsRelaxed; // 0x30 Size: 0x1
	    bool bIsBoosting; // 0x31 Size: 0x1
	    bool bAdjustRootForFemaleRider; // 0x32 Size: 0x1
	    bool bIsPlayingEmoteOnHoverboard; // 0x33 Size: 0x1
	    bool bShouldApplyAdditive; // 0x34 Size: 0x1
	    bool bIsOnGroundAndNotBoosting; // 0x35 Size: 0x1
	    bool bPlayPivotOnGroundAndNotBoosting; // 0x36 Size: 0x1
	    bool bIsOnLowerHill; // 0x37 Size: 0x1
	    bool bIdleToLoopTransition; // 0x38 Size: 0x1
	    bool bDefaultToJumpStartTransition; // 0x39 Size: 0x1
	    bool bLocomotionPoseToJumpTransition; // 0x3a Size: 0x1
	    bool bJumpToLocomotionPoseTransition; // 0x3b Size: 0x1
	    bool bJumpApexToJumpFallTransition; // 0x3c Size: 0x1
	    bool bIdleToMovementStartTransition; // 0x3d Size: 0x1
	    bool bIdleToMovementLoopTransition; // 0x3e Size: 0x1
	    bool bMovementLoopToMovementStopTransition; // 0x3f Size: 0x1
	    bool bMovementLoopToPivotTransition; // 0x40 Size: 0x1
	    bool bMovementLoopToIdleTransition; // 0x41 Size: 0x1
	    bool bIdleAdditiveToCollisionNTransition; // 0x42 Size: 0x1
	    bool bSplitBodyToHoverboardBRStartTransition; // 0x43 Size: 0x1
	    bool bHoverboardBRToSplitBodyTransition; // 0x44 Size: 0x1
	    bool bIdlesToJackalVehicleTransition; // 0x45 Size: 0x1
	    bool bPlayAdditiveLeans; // 0x46 Size: 0x1
	    bool bPlayJumpTrickVertical; // 0x47 Size: 0x1
	    bool bPlayJumpTrick; // 0x48 Size: 0x1
	    bool bPlayMovingFast; // 0x49 Size: 0x1
	    bool bPlayHipAdjustmentAdditive; // 0x4a Size: 0x1
	    bool bPlayDriveSouth; // 0x4b Size: 0x1
	    float JumpCombatAdditiveWeight; // 0x4c Size: 0x4
	    float MeleeTwistIdle; // 0x50 Size: 0x4
	    float MeleeTwistLocomotionLoop; // 0x54 Size: 0x4
	    struct FFortAnimInput_VelocityImpact VelocityImpact; // 0x58 Size: 0xc0
	    struct FVector ImpactDisplacement; // 0x118 Size: 0xc
	    char UnknownData1[0x8]; // 0x124
	    float SteerYaw; // 0x12c Size: 0x4
	    struct FVector EmoteHoverboardPosition; // 0x130 Size: 0xc
	    struct FRotator EmoteHoverboardRotation; // 0x13c Size: 0xc
	    bool bShouldAttachFeetToHoverboard; // 0x148 Size: 0x1
	    char UnknownData2[0x3]; // 0x149
	    struct FVector FootLeftLocationOffset; // 0x14c Size: 0xc
	    struct FRotator FootLeftRotationOffset; // 0x158 Size: 0xc
	    struct FVector FootRightLocationOffset; // 0x164 Size: 0xc
	    struct FRotator FootRightRotationOffset; // 0x170 Size: 0xc
	    float StoppedThreshold; // 0x17c Size: 0x4
	    float MovingForwardThreshold; // 0x180 Size: 0x4
	    float MovingFowardFastThreshold; // 0x184 Size: 0x4
	    float DefaultToJumpStartTransitionThreshold; // 0x188 Size: 0x4
	    float JumpTrickAngularVelocityThreshold; // 0x18c Size: 0x4
	    float JumpDistanceFromGroundThreshold; // 0x190 Size: 0x4
	    float VelocityStartThreshold; // 0x194 Size: 0x4
	    float MovingFastThreshold; // 0x198 Size: 0x4
	    float RelaxedSpeedThreshold; // 0x19c Size: 0x4
	    float RotatingAngularVelocityThreshold; // 0x1a0 Size: 0x4
	    float IdleToLoopTransitionThreshold; // 0x1a4 Size: 0x4
	    float IdleToMovementLoopTransitionThreshold; // 0x1a8 Size: 0x4
	    float MeleeTwistIdleMultiplier; // 0x1ac Size: 0x4
	    float MeleeTwistLocomotionLoopMultiplier; // 0x1b0 Size: 0x4

};

struct FFortAnimInput_HoverBoard
{
	public:
	    bool bIsUsingHoverboard; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float HoverTransformAlpha; // 0x4 Size: 0x4
	    struct FRotator HoverTransformRotation; // 0x8 Size: 0xc
	    struct FVector HoverTransformTranslation; // 0x14 Size: 0xc
	    float HoverCycle; // 0x20 Size: 0x4
	    char UnknownData1[0x4]; // 0x24
	    class UCurveFloat* HoverCycleVelocityCurve; // 0x28 Size: 0x8
	    float HoverHeight; // 0x30 Size: 0x4
	    char UnknownData2[0x4]; // 0x34
	    class UCurveFloat* HoverHeightCurve; // 0x38 Size: 0x8
	    float HoverLeanAngle; // 0x40 Size: 0x4
	    char UnknownData3[0x4]; // 0x44
	    class UCurveFloat* HoverLeanCurve; // 0x48 Size: 0x8
	    float HoverPitchAngle; // 0x50 Size: 0x4
	    float HoverYaw; // 0x54 Size: 0x4
	    float HoverYawCurrent; // 0x58 Size: 0x4
	    float HoverIdleLeanAlpha; // 0x5c Size: 0x4
	    class UCurveFloat* HoverPitchCurve; // 0x60 Size: 0x8

};

struct FFortAnimInput_Zipline
{
	public:
	    bool bIsZiplining; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    struct FVector ZiplineDirection; // 0x4 Size: 0xc

};

struct FFortAnimInput_CreativeMoveTool
{
	public:
	    bool bIsFlying; // 0x0 Size: 0x1

};

struct FFortAnimInput_WeaponCheck
{
	public:
	    float AdditiveAlpha; // 0x0 Size: 0x4
	    float MaxSecondsAfterEnteringRelaxed; // 0x4 Size: 0x4
	    float MinSecondsAfterLanding; // 0x8 Size: 0x4
	    float MinSecondsBetweenWeaponChecks; // 0xc Size: 0x4
	    float CurrentWeaponCheckWindow; // 0x10 Size: 0x4
	    float CurrentWeaponCheckIntervalDelay; // 0x14 Size: 0x4
	    float CurrentWeaponCheckLandingDelay; // 0x18 Size: 0x4
	    bool bIsWeaponCheckPlaying; // 0x1c Size: 0x1
	    char UnknownData0[0x3];

};

struct FAnimTagProperty
{
	public:
	    struct FGameplayTag BackingGameplayTag; // 0x0 Size: 0x8
	    class UProperty* PropertyToEdit; // 0x8 Size: 0x8
	    FName PropertyName; // 0x10 Size: 0x8
	    struct FGuid PropertyGuid; // 0x18 Size: 0x10

};

struct FFortAnimNode_AnimSetDrivenRandom : public FAnimNode_RandomPlayer
{
	public:
	    struct FGameplayTag RandomSlotName; // 0x68 Size: 0x8
	    class UFortAnimSet* AnimSet; // 0x70 Size: 0x8

};

struct FSourceDriver
{
	public:
	    struct FBoneReference SourceBone; // 0x0 Size: 0x10
	    char SourceComponent; // 0x10 Size: 0x1
	    bool UseQuaternion; // 0x11 Size: 0x1
	    char UnknownData0[0x6]; // 0x12
	    class UCurveFloat* DrivingCurve; // 0x18 Size: 0x8
	    float Multiplier; // 0x20 Size: 0x4
	    bool bUseRange; // 0x24 Size: 0x1
	    char UnknownData1[0x3]; // 0x25
	    float RangeMin; // 0x28 Size: 0x4
	    float RangeMax; // 0x2c Size: 0x4
	    float RemappedMin; // 0x30 Size: 0x4
	    float RemappedMax; // 0x34 Size: 0x4

};

struct FFortAnimNode_ScaleHuskBones : public FAnimNode_Base
{
	public:
	    struct FPoseLink PreScalePose; // 0x10 Size: 0x10
	    char UnknownData0[0x140];

};

struct FSlopeWarpingFootData
{
	public:
	    char UnknownData0[0xa0];

};

struct FSlopeWarpingFootDefinition
{
	public:
	    struct FBoneReference IKFootBone; // 0x0 Size: 0x10
	    struct FBoneReference FKFootBone; // 0x10 Size: 0x10
	    int NumBonesInLimb; // 0x20 Size: 0x4
	    FName ToeSocketName; // 0x24 Size: 0x8
	    FName HeelSocketName; // 0x2c Size: 0x8
	    float FootSize; // 0x34 Size: 0x4

};

struct FSpeedWarpingFootData
{
	public:
	    char UnknownData0[0x40];

};

struct FSpeedWarpingFootDefinition
{
	public:
	    struct FBoneReference IKFootBone; // 0x0 Size: 0x10
	    struct FBoneReference FKFootBone; // 0x10 Size: 0x10
	    int NumBonesInLimb; // 0x20 Size: 0x4

};

struct FEmotePropMaterialScalarParam
{
	public:
	    FName ParamName; // 0x0 Size: 0x8
	    float ParamValue; // 0x8 Size: 0x4

};

struct FAntelopeVehicleBoostLevel
{
	public:
	    float AccumulationPercent; // 0x0 Size: 0x4
	    float BoostTime; // 0x4 Size: 0x4

};

struct FFortRechargingActionTimer
{
	public:
	    MulticastDelegateProperty OnActivate; // 0x0 Size: 0x10
	    MulticastDelegateProperty OnDeactivate; // 0x10 Size: 0x10
	    MulticastDelegateProperty OnActivationFailed; // 0x20 Size: 0x10
	    float ChargeRate; // 0x30 Size: 0x4
	    float ActiveExpenseRate; // 0x34 Size: 0x4
	    float PassiveExpenseRate; // 0x38 Size: 0x4
	    float MinActivationDurationTime; // 0x3c Size: 0x4
	    float MinActivationCharge; // 0x40 Size: 0x4
	    float ActiveCooldownTime; // 0x44 Size: 0x4
	    float Charge; // 0x48 Size: 0x4
	    bool bIsActive; // 0x4c Size: 0x1
	    bool bIsCharging; // 0x4d Size: 0x1
	    bool bIsPassive; // 0x4e Size: 0x1
	    char UnknownData0[0x9];

};

struct FAileronRoll
{
	public:
	    struct FFortRechargingActionTimer Action; // 0x0 Size: 0x58
	    EAileronRollDirection Direction; // 0x58 Size: 0x1
	    char UnknownData0[0x7];

};

struct FFlightControlSurfaces
{
	public:
	    float RudderAngle; // 0x0 Size: 0x4
	    float AileronAngle; // 0x4 Size: 0x4
	    float ElevatorAngle; // 0x8 Size: 0x4
	    float FlapAngle; // 0xc Size: 0x4

};

struct FReplicatedControlState
{
	public:
	    struct FVector_NetQuantizeNormal Up; // 0x0 Size: 0xc
	    struct FVector_NetQuantizeNormal Forward; // 0xc Size: 0xc
	    bool bIsEngineOn; // 0x18 Size: 0x1
	    char UnknownData0[0x3];

};

struct FRotationLerpData
{
	public:
	    struct FQuat RotationLerp_Start; // 0x0 Size: 0x10
	    struct FQuat RotationLerp_End; // 0x10 Size: 0x10
	    struct FQuat RotationLerp_Target; // 0x20 Size: 0x10
	    float TotalLerpTime; // 0x30 Size: 0x4
	    char UnknownData0[0x1c];

};

struct FLocationLerpData
{
	public:
	    struct FVector PositionLerp_Start; // 0x0 Size: 0xc
	    struct FVector PositionLerp_End; // 0xc Size: 0xc
	    struct FVector PositionLerp_Target; // 0x18 Size: 0xc
	    float TotalLerpTime; // 0x24 Size: 0x4
	    char UnknownData0[0x10];

};

struct FExitCraftInfo
{
	public:
	    struct FGameplayTag RequiredExitCraftTag; // 0x0 Size: 0x8
	    struct FScalableFloat ExitCraftSpawnerZOffset; // 0x8 Size: 0x20
	    struct FScalableFloat ExitCraftSpawnDelay; // 0x28 Size: 0x20
	    struct FScalableFloat SpawnDestructionInitialDelay; // 0x48 Size: 0x20
	    struct FScalableFloat SpawnDestructionDelayBetweenPieces; // 0x68 Size: 0x20
	    struct FScalableFloat ExitCraftZOffset; // 0x88 Size: 0x20
	    struct FScalableFloat ExitCraftTargetZOffset; // 0xa8 Size: 0x20
	    struct FScalableFloat ExitCraftTimeToHoverLocation; // 0xc8 Size: 0x20
	    struct FScalableFloat ExitCraftTimeToHoverRotation; // 0xe8 Size: 0x20
	    struct FScalableFloat MinLandingSpeed; // 0x108 Size: 0x20
	    struct FScalableFloat ExitZOffset; // 0x128 Size: 0x20
	    struct FScalableFloat ExitTime; // 0x148 Size: 0x20
	    struct FScalableFloat InteractionTime; // 0x168 Size: 0x20

};

struct FVehicleClassDetails
{
	public:
	    class AFortAthenaVehicle* VehicleClass; // 0x0 Size: 0x8
	    struct FScalableFloat VehicleMinSpawnPercent; // 0x8 Size: 0x20
	    struct FScalableFloat VehicleMaxSpawnPercent; // 0x28 Size: 0x20

};

struct FFortRespawnLogicData
{
	public:
	    struct FScalableFloat DirectionDeviation; // 0x0 Size: 0x20
	    struct FScalableFloat MinDistFromCenterPercent; // 0x20 Size: 0x20
	    struct FScalableFloat MaxDistFromCenterPercent; // 0x40 Size: 0x20
	    struct FScalableFloat MinHeightFromGround; // 0x60 Size: 0x20
	    struct FScalableFloat MinHeightFromZero; // 0x80 Size: 0x20
	    struct FScalableFloat CameraDistance; // 0xa0 Size: 0x20
	    struct FScalableFloat RespawnTraceHeight; // 0xc0 Size: 0x20

};

struct FItemsToSpawn
{
	public:
	    class UFortWorldItemDefinition* ItemToDrop; // 0x0 Size: 0x8
	    struct FScalableFloat NumberToDrop; // 0x8 Size: 0x20

};

struct FBarrierTeamState
{
	public:
	    char TeamNum; // 0x0 Size: 0x1
	    EBarrierFoodTeam FoodTeam; // 0x1 Size: 0x1
	    char UnknownData0[0x6]; // 0x2
	    class AAthenaBarrierFlag* ObjectiveFlag; // 0x8 Size: 0x8
	    class AAthenaBarrierObjective* ObjectiveObject; // 0x10 Size: 0x8
	    bool bRespawnEnabled; // 0x18 Size: 0x1
	    char UnknownData1[0xf];

};

struct FFortAthenaMutator_SurvivalObjectiveData
{
	public:
	    class ABuildingActor* BuildingActorObjectiveClass; // 0x0 Size: 0x8
	    struct FScalableFloat SpawnDistanceFromGround; // 0x8 Size: 0x20
	    int ActivationSafezoneIndex; // 0x28 Size: 0x4
	    bool bEndMatchOnDestroy; // 0x2c Size: 0x1
	    char UnknownData0[0x3]; // 0x2d
	    class ABuildingActor* SpawnedBuildingActorObjective; // 0x30 Size: 0x8
	    bool bIsSpecialActor; // 0x38 Size: 0x1
	    char UnknownData1[0x3]; // 0x39
	    struct FGameplayTag SpecialActorTag; // 0x3c Size: 0x8
	    char UnknownData2[0x4]; // 0x44
	    struct FSlateBrush SpecialActorMinimapIconBrush; // 0x48 Size: 0x88
	    struct FVector2D SpecialActorMinimapIconScale; // 0xd0 Size: 0x8
	    struct FSlateBrush SpecialActorCompassIconBrush; // 0xd8 Size: 0x88
	    struct FVector2D SpecialActorCompassIconScale; // 0x160 Size: 0x8
	    FName SpecialActorID; // 0x168 Size: 0x8

};

struct FControlPointInstanceData
{
	public:
	    class AAthenaCapturePoint* ControlPoint; // 0x0 Size: 0x8
	    EControlPointState ControlPointState; // 0x8 Size: 0x1
	    char UnknownData0[0x3]; // 0x9
	    int SpawnDataIdx; // 0xc Size: 0x4
	    float SpawnTime; // 0x10 Size: 0x4
	    float EnableTime; // 0x14 Size: 0x4
	    float DisableTime; // 0x18 Size: 0x4
	    char PrevOwningTeam; // 0x1c Size: 0x1
	    char UnknownData1[0x3]; // 0x1d
	    class AFortTeamInfoAthena* CachedOwningTeamInfo; // 0x20 Size: 0x8
	    float PointAccrualTime; // 0x28 Size: 0x4
	    float PointsRemainder; // 0x2c Size: 0x4
	    float BonusPointAccrualTime; // 0x30 Size: 0x4
	    float BonusPointsRemainder; // 0x34 Size: 0x4
	    float CachedPointAccrualValue; // 0x38 Size: 0x4
	    float CachedBonusPointAccrualValue; // 0x3c Size: 0x4
	    bool bPointFinished; // 0x40 Size: 0x1
	    char UnknownData2[0x3]; // 0x41
	    int CachedSafeZonePhaseWhenToSpawn; // 0x44 Size: 0x4
	    bool bIgnoreForOrderMessaging; // 0x48 Size: 0x1
	    bool bAlwaysInPlay; // 0x49 Size: 0x1
	    char UnknownData3[0x2]; // 0x4a
	    float TimeOfShutdown; // 0x4c Size: 0x4

};

struct FFortPieSliceSpawnData
{
	public:
	    struct FScalableFloat SpawnDirection; // 0x0 Size: 0x20
	    struct FScalableFloat SpawnDirectionDeviation; // 0x20 Size: 0x20
	    struct FScalableFloat MinSpawnDistanceFromCenter; // 0x40 Size: 0x20
	    struct FScalableFloat MaxSpawnDistanceFromCenter; // 0x60 Size: 0x20

};

struct FControlPointSpawnData : public FFortPieSliceSpawnData
{
	public:
	    struct FScalableFloat SpawnDelayTime; // 0x80 Size: 0x20
	    struct FScalableFloat SafeZonePhaseWhenToSpawn; // 0xa0 Size: 0x20
	    struct FScalableFloat SafeZonePhaseWhereToSpawn; // 0xc0 Size: 0x20
	    struct FScalableFloat EnableDelayTime; // 0xe0 Size: 0x20
	    struct FScalableFloat EnableInSafeZonePhase; // 0x100 Size: 0x20
	    struct FScalableFloat DisableDelayTime; // 0x120 Size: 0x20
	    struct FScalableFloat DisableInSafeZonePhase; // 0x140 Size: 0x20
	    struct FScalableFloat PointsEarnedPerSecond; // 0x160 Size: 0x20
	    struct FScalableFloat BonusPointsEarnedPerSecond; // 0x180 Size: 0x20
	    struct FScalableFloat bIgnoreForOrderMessaging; // 0x1a0 Size: 0x20
	    int IconMaterialIndex; // 0x1c0 Size: 0x4
	    bool bAlwaysInPlay; // 0x1c4 Size: 0x1
	    char UnknownData0[0x3];

};

struct FControlPointAssetData
{
	public:
	    class AAthenaCapturePoint* CapturePointClass; // 0x0 Size: 0x8
	    struct FScalableFloat SpawnDistanceFromGround; // 0x8 Size: 0x20
	    struct FVector2D MiniMapIconScale; // 0x28 Size: 0x8
	    struct FVector2D CompassIconScale; // 0x30 Size: 0x8

};

struct FItemsToGive
{
	public:
	    class UFortWorldItemDefinition* ItemToDrop; // 0x0 Size: 0x8
	    struct FScalableFloat NumberToGive; // 0x8 Size: 0x20

};

struct FGravityMovementData
{
	public:
	    float GravityZScale; // 0x0 Size: 0x4
	    float VehicleGravityZScale; // 0x4 Size: 0x4
	    float JumpZVelocityOverride; // 0x8 Size: 0x4
	    float JumpHorizontalAccelerationOverride; // 0xc Size: 0x4
	    float JumpHorizontalVelocityOverride; // 0x10 Size: 0x4

};

struct FHeistTeamHoldingJewelInfo
{
	public:
	    int JewelsHeld; // 0x0 Size: 0x4
	    float TimeStartedHoldingJewel; // 0x4 Size: 0x4
	    float AccumulatedTotalTime; // 0x8 Size: 0x4

};

struct FHeistBlingDropSpawnData : public FFortPieSliceSpawnData
{
	public:
	    struct FScalableFloat SafeZonePhaseWhereToSpawn; // 0x80 Size: 0x20

};

struct FHeistExitCraftSpawnData : public FFortPieSliceSpawnData
{
	public:
	    struct FScalableFloat SpawnDelayTime; // 0x80 Size: 0x20
	    struct FScalableFloat SafeZonePhaseWhenToSpawn; // 0xa0 Size: 0x20
	    struct FScalableFloat SafeZonePhaseWhereToSpawn; // 0xc0 Size: 0x20

};

struct FItemsToDropOnDeath
{
	public:
	    class UFortWorldItemDefinition* ItemToDrop; // 0x0 Size: 0x8
	    struct FScalableFloat NumberToDrop; // 0x8 Size: 0x20

};

struct FFortItemDeliverySupplyDropMutatorData
{
	public:
	    bool bShouldApplyMutator; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FScalableFloat NumDeliveryItemsToSpawn; // 0x8 Size: 0x20
	    class UEnvQuery* SupplyDropPlacementQuery; // 0x28 Size: 0x8

};

struct FTimeOfDaySpeed
{
	public:
	    float Speed; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    struct FText DisplayName; // 0x8 Size: 0x18

};

struct FTimeOfDayPhase
{
	public:
	    float Time; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    struct FText DisplayName; // 0x8 Size: 0x18

};

struct FFortAthenaVehicleSessionTelemetryInfo
{
	public:
	    char UnknownData0[0x50];

};

struct FSeatTransitionMontage
{
	public:
	    class UAnimMontage* Montage; // 0x0 Size: 0x8
	    int FromSeatIndex; // 0x8 Size: 0x4
	    int ToSeatIndex; // 0xc Size: 0x4

};

struct FAthenaCarPlayerSlotUnreplicated
{
	public:
	    class UInputComponent* Input; // 0x0 Size: 0x8

};

struct FIgnoredPawn
{
	public:
	    class AFortPawn* Pawn; // 0x0 Size: 0x8
	    float Time; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FAthenaVehicleShootingCone
{
	public:
	    float YawConstraint; // 0x0 Size: 0x4
	    float PitchConstraint; // 0x4 Size: 0x4

};

struct FVehicleSpringInfo
{
	public:
	    FName SpringStart; // 0x0 Size: 0x8
	    struct FVector SpringStartLocalOffset; // 0x8 Size: 0xc
	    FName ForceApplicationPoint; // 0x14 Size: 0x8
	    float SpringLength; // 0x1c Size: 0x4
	    float SpringStiff; // 0x20 Size: 0x4
	    float SpringDamp; // 0x24 Size: 0x4
	    float SpringRadius; // 0x28 Size: 0x4
	    float MaxAccelChange; // 0x2c Size: 0x4
	    int8_t SeatSocketIndex; // 0x30 Size: 0x1
	    bool bIsLookAhead; // 0x31 Size: 0x1
	    bool bNormalToGroundTriangle; // 0x31 Size: 0x1
	    bool bForceAlongSpringNormal; // 0x31 Size: 0x1
	    float LookAheadMinSpeed; // 0x34 Size: 0x4
	    float LookAheadMaxSpeed; // 0x38 Size: 0x4
	    float LookAheadMinStiff; // 0x3c Size: 0x4
	    float LookAheadMaxStiff; // 0x40 Size: 0x4
	    char UnknownData0[0x11c];

};

struct FVehicleImpactBucket
{
	public:
	    char UnknownData0[0x18];

};

struct FSMVehicleGear
{
	public:
	    float TopSpeed; // 0x0 Size: 0x4
	    float MinSpeed; // 0x4 Size: 0x4
	    float PushForce; // 0x8 Size: 0x4
	    float RampTime; // 0xc Size: 0x4
	    float SteeringAngleMultiplier; // 0x10 Size: 0x4
	    bool bAutoBrake; // 0x14 Size: 0x1
	    bool bIgnoreGravity; // 0x14 Size: 0x1
	    char UnknownData0[0x2];

};

struct FVehicleTargetOrientation
{
	public:
	    struct FVector UpVector; // 0x0 Size: 0xc
	    struct FVector ForwardVector; // 0xc Size: 0xc
	    struct FVector Location; // 0x18 Size: 0xc

};

struct FReplicatedAthenaVehicleAttributes
{
	public:
	    float FrontLateralFrictionScale; // 0x0 Size: 0x4
	    float RearLateralFrictionScale; // 0x4 Size: 0x4
	    float BrakeForceTractionScale; // 0x8 Size: 0x4
	    float ForwardForceTractionScale; // 0xc Size: 0x4
	    float SlopeAntigravityScale; // 0x10 Size: 0x4

};

struct FReplicatedAthenaVehiclePhysicsState
{
	public:
	    struct FVector_NetQuantize100 Translation; // 0x0 Size: 0xc
	    char UnknownData0[0x4]; // 0xc
	    struct FQuat Rotation; // 0x10 Size: 0x10
	    struct FVector_NetQuantize10 LinearVelocity; // 0x20 Size: 0xc
	    struct FVector_NetQuantize10 AngularVelocity; // 0x2c Size: 0xc
	    __int64/*UInt16Property*/ SyncKey; // 0x38 Size: 0x2
	    char UnknownData1[0x6];

};

struct FSpringGroundTriangle
{
	public:
	    FName Socket0; // 0x0 Size: 0x8
	    FName Socket1; // 0x8 Size: 0x8
	    FName Socket2; // 0x10 Size: 0x8

};

struct FPotentiallyDestroyedBuilding
{
	public:
	    class ABuildingActor* BuildingActor; // 0x0 Size: 0x8
	    float TimeSinceCollision; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortAthenaVehicleInputState
{
	public:
	    float ForwardAlpha; // 0x0 Size: 0x4
	    float RightAlpha; // 0x4 Size: 0x4
	    float PitchAlpha; // 0x8 Size: 0x4
	    float LookUpDelta; // 0xc Size: 0x4
	    float TurnDelta; // 0x10 Size: 0x4
	    float SteerAlpha; // 0x14 Size: 0x4
	    float GravityOffset; // 0x18 Size: 0x4
	    struct FVector MovementDir; // 0x1c Size: 0xc
	    bool bIsSprinting; // 0x28 Size: 0x1
	    bool bIsJumping; // 0x28 Size: 0x1
	    bool bIsBraking; // 0x28 Size: 0x1
	    bool bIsHonking; // 0x28 Size: 0x1
	    bool bIgnoreForwardInAir; // 0x28 Size: 0x1
	    bool bMovementModifier0; // 0x28 Size: 0x1
	    bool bMovementModifier1; // 0x28 Size: 0x1
	    bool bMovementModifier2; // 0x28 Size: 0x1
	    char UnknownData0[0x-4];

};

struct FFortAthenaVehicleInputStateUnreliable
{
	public:
	    float ForwardAlpha; // 0x0 Size: 0x4
	    float RightAlpha; // 0x4 Size: 0x4
	    float PitchAlpha; // 0x8 Size: 0x4
	    float LookUpDelta; // 0xc Size: 0x4
	    float TurnDelta; // 0x10 Size: 0x4
	    float SteerAlpha; // 0x14 Size: 0x4
	    float GravityOffset; // 0x18 Size: 0x4
	    struct FVector_NetQuantize100 MovementDir; // 0x1c Size: 0xc

};

struct FFortAthenaVehicleInputStateReliable
{
	public:
	    bool bIsSprinting; // 0x0 Size: 0x1
	    bool bIsJumping; // 0x0 Size: 0x1
	    bool bIsBraking; // 0x0 Size: 0x1
	    bool bIsHonking; // 0x0 Size: 0x1
	    bool bIgnoreForwardInAir; // 0x0 Size: 0x1
	    bool bMovementModifier0; // 0x0 Size: 0x1
	    bool bMovementModifier1; // 0x0 Size: 0x1
	    bool bMovementModifier2; // 0x0 Size: 0x1
	    char UnknownData0[0x-7];

};

struct FVehicleBounceState
{
	public:
	    EBounceCompressionState CompressionState; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float CompressionValue; // 0x4 Size: 0x4
	    float StateCooldown; // 0x8 Size: 0x4

};

struct FReplicatedAthenaVehicleState
{
	public:
	    struct FVector ForwardVectorTarget; // 0x0 Size: 0xc

};

struct FAttachedInfo
{
	public:
	    struct FHitResult Hit; // 0x0 Size: 0x88
	    class AActor* AttachedToActor; // 0x88 Size: 0x8
	    struct FVector_NetQuantize10 AttachOffset; // 0x90 Size: 0xc
	    struct FVector_NetQuantizeNormal VelocityNormalized; // 0x9c Size: 0xc
	    float NarrowPlacementAgainstVelocityThreshold; // 0xa8 Size: 0x4
	    float StickyOffsetFromPhysicsMesh; // 0xac Size: 0x4
	    float StickyOffsetFromBoneCenter; // 0xb0 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortAttributeInitializationKey
{
	public:
	    FName AttributeInitCategory; // 0x0 Size: 0x8
	    FName AttributeInitSubCategory; // 0x8 Size: 0x8

};

struct FFortGameplayAttributeData : public FGameplayAttributeData
{
	public:
	    float Minimum; // 0x10 Size: 0x4
	    float Maximum; // 0x14 Size: 0x4
	    bool bIsClamped; // 0x18 Size: 0x1
	    bool bShouldClampBase; // 0x19 Size: 0x1
	    char UnknownData0[0x2]; // 0x1a
	    float UnclampedBaseValue; // 0x1c Size: 0x4
	    float UnclampedCurrentValue; // 0x20 Size: 0x4
	    char UnknownData1[0x4];

};

struct FFortBadgeScoringData : public FTableRowBase
{
	public:
	    int ScoreAwarded; // 0x8 Size: 0x4
	    int MissionPoints; // 0xc Size: 0x4
	    EStatCategory ScoreCategory; // 0x10 Size: 0x1
	    char UnknownData0[0x3]; // 0x11
	    int ScoreThreshold; // 0x14 Size: 0x4

};

struct FFortAnalyticsEventAttribute
{
	public:
	    char UnknownData0[0x20];

};

struct FFortBuildingSoundsPerAffiliation
{
	public:
	    class USoundBase* SoundFriendly; // 0x0 Size: 0x8
	    class USoundBase* SoundEnemy; // 0x8 Size: 0x8

};

struct FFortBuildingSoundsPerResourceType
{
	public:
	    struct FFortBuildingSoundsPerAffiliation* OnConstruction; // 0x0 Size: 0x10
	    char UnknownData0[0x50]; // 0x10
	    struct FFortBuildingSoundsPerAffiliation* OnGenericDestruction; // 0x60 Size: 0x10
	    char UnknownData1[0x50]; // 0x70
	    struct FFortBuildingSoundsPerAffiliation* OnPlayerBuiltDestruction; // 0xc0 Size: 0x10
	    char UnknownData2[0x50];

};

struct FRecipeDataTableRowHandleQuantityData
{
	public:
	    struct FDataTableRowHandle DataTableRowHandle; // 0x0 Size: 0x10
	    int Quantity; // 0x10 Size: 0x4
	    bool ConvertRemainderUp; // 0x14 Size: 0x1
	    char UnknownData0[0x3];

};

struct FRecipeData
{
	public:
	    char UnknownData0[0x10];

};

struct FFortUICameraFrameTargetBounds
{
	public:
	    struct FVector Origin; // 0x0 Size: 0xc
	    float CylinderHalfHeight; // 0xc Size: 0x4
	    float CylinderRadius; // 0x10 Size: 0x4

};

struct FFortUICameraFrameTargetSettings
{
	public:
	    struct FVector FocusPointToCenter; // 0x0 Size: 0xc
	    EFortUICameraFrameTargetBoundingBehavior BoundingBehavior; // 0xc Size: 0x1
	    char UnknownData0[0x3]; // 0xd
	    struct FFortUICameraFrameTargetBounds BoundsToFrame; // 0x10 Size: 0x14

};

struct FInterpOffsetData
{
	public:
	    struct FVector ViewOffset; // 0x0 Size: 0xc
	    struct FVector LargeBodyTypeAddtnlOffset; // 0xc Size: 0xc
	    float PitchAngle; // 0x18 Size: 0x4

};

struct FFilledGadgetSlot
{
	public:
	    struct FString Gadget; // 0x0 Size: 0x10
	    int slot_index; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FCarriedObjectAttachmentInfo
{
	public:
	    class AActor* AttachParent; // 0x0 Size: 0x8
	    FName SocketName; // 0x8 Size: 0x8
	    struct FVector RelativeTranslation; // 0x10 Size: 0xc
	    struct FRotator RelativeRotation; // 0x1c Size: 0xc

};

struct FFortProceduralCatalogCostPriceFactor : public FTableRowBase
{
	public:
	    float PriceFactor; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortChallengeBundleQuestEntry
{
	public:
	    struct TSoftObjectPtr<struct UFortQuestItemDefinition*> QuestDefinition; // 0x0 Size: 0x28
	    EChallengeBundleQuestUnlockType QuestUnlockType; // 0x28 Size: 0x1
	    EChallengeBundleQuestVisualStyle QuestVisualStyle; // 0x29 Size: 0x1
	    char UnknownData0[0x2]; // 0x2a
	    int UnlockValue; // 0x2c Size: 0x4
	    struct TSoftObjectPtr<struct UFortGiftBoxItemDefinition*> GiftBoxToUse; // 0x30 Size: 0x28

};

struct FFortGiftBoxFortmatData
{
	public:
	    struct FString StringAssetType; // 0x0 Size: 0x10
	    struct FString StringData; // 0x10 Size: 0x10

};

struct FFortChallengeBundleScheduleEntry
{
	public:
	    struct TSoftObjectPtr<struct UFortChallengeBundleItemDefinition*> ChallengeBundle; // 0x0 Size: 0x28
	    EChallengeScheduleUnlockType UnlockType; // 0x28 Size: 0x1
	    char UnknownData0[0x3]; // 0x29
	    int UnlockValue; // 0x2c Size: 0x4

};

struct FSpawnPickupEntry
{
	public:
	    struct FString Name; // 0x0 Size: 0x10
	    class AActor* PickupClass; // 0x10 Size: 0x8

};

struct FFortClientAnnouncementData_Conversation : public FFortClientAnnouncementData
{
	public:
	    class UFortConversation* Conversation; // 0x0 Size: 0x8
	    EFortAnnouncementDisplayPreference ConversationDisplayPreference; // 0x8 Size: 0x1
	    char UnknownData0[0x7];

};

struct FActionTextPair
{
	public:
	    FName Action; // 0x0 Size: 0x8
	    struct FText Text; // 0x8 Size: 0x18

};

struct FClientBotBuildStep
{
	public:
	    char UnknownData0[0x40];

};

struct FMovementTestDefinition
{
	public:
	    float ForwardMoveStrength; // 0x0 Size: 0x4
	    float SideMoveStrength; // 0x4 Size: 0x4
	    float Duration; // 0x8 Size: 0x4
	    char UnknownData0[0x4]; // 0xc
	    struct FString TestName; // 0x10 Size: 0x10

};

struct FConsumableTestDefinition
{
	public:
	    char UnknownData0[0x30];

};

struct FFortClientPilotConsumableTestDefinition
{
	public:
	    char UnknownData0[0x30];

};

struct FFortClientPilotMovementTestDefinition
{
	public:
	    float ForwardMoveStrength; // 0x0 Size: 0x4
	    float SideMoveStrength; // 0x4 Size: 0x4
	    float Duration; // 0x8 Size: 0x4
	    char UnknownData0[0x4]; // 0xc
	    struct FString TestName; // 0x10 Size: 0x10

};

struct FClientPilotBuildStep
{
	public:
	    char UnknownData0[0x40];

};

struct FFortActionKeyMapping
{
	public:
	    FName ActionName; // 0x0 Size: 0x8
	    EFortInputActionGroup ActionGroup; // 0x8 Size: 0x1
	    ESubGame SubGameUsedIn; // 0x9 Size: 0x1
	    char UnknownData0[0x6]; // 0xa
	    struct FText LocalizedName; // 0x10 Size: 0x18
	    struct FKey KeyBind1; // 0x28 Size: 0x18
	    struct FKey KeyBind2; // 0x40 Size: 0x18
	    float InputScale; // 0x58 Size: 0x4
	    bool bIsAxisMapping; // 0x5c Size: 0x1
	    char UnknownData1[0x3];

};

struct FFortPendingSlottedItemOperation
{
	public:
	    struct FString SlottedItemId; // 0x0 Size: 0x10
	    FName SlotRowName; // 0x10 Size: 0x8

};

struct FFortCollectionBookPageCategoryTableRow : public FTableRowBase
{
	public:
	    struct FText Name; // 0x8 Size: 0x18
	    int SortPriority; // 0x20 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortCollectionBookSlotSourceData : public FTableRowBase
{
	public:
	    struct FText Description; // 0x8 Size: 0x18

};

struct FFortCollectionBookSlotXPWeightData : public FTableRowBase
{
	public:
	    float ConstantWeight; // 0x8 Size: 0x4
	    float RarityWeight; // 0xc Size: 0x4
	    float ItemLevelWeight; // 0x10 Size: 0x4
	    float ItemRatingWeight; // 0x14 Size: 0x4

};

struct FFortCollectionBookSectionState
{
	public:
	    struct FString Section; // 0x0 Size: 0x10
	    EFortCollectionBookState State; // 0x10 Size: 0x1
	    char UnknownData0[0x7];

};

struct FFortCollisionAudioTriggerData
{
	public:
	    class USoundBase* Asset; // 0x0 Size: 0x8
	    struct FVector2D ImpulseMagnitudeRange; // 0x8 Size: 0x8
	    bool bImpulseMagnitudeLowerBound; // 0x10 Size: 0x1
	    bool bImpulseMagnitudeUpperBound; // 0x11 Size: 0x1
	    char UnknownData0[0x2]; // 0x12
	    struct FVector2D VolumeRange; // 0x14 Size: 0x8
	    struct FVector2D PitchRange; // 0x1c Size: 0x8
	    float MinRetriggerTime; // 0x24 Size: 0x4
	    float MaxTriggerDistance; // 0x28 Size: 0x4
	    char UnknownData1[0x14];

};

struct FCombatThresholdData
{
	public:
	    float HeatLevel; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    struct FString ThresholdName; // 0x8 Size: 0x10
	    struct FLinearColor DebugGraphColor; // 0x18 Size: 0x10

};

struct FCombatEventMultiplier
{
	public:
	    char CombatEvent; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float MaxContribution; // 0x4 Size: 0x4

};

struct FCombatEventData
{
	public:
	    float Heat; // 0x0 Size: 0x4
	    float MaxHeatContribution; // 0x4 Size: 0x4
	    float CoolDownRate; // 0x8 Size: 0x4
	    char UnknownData0[0x4]; // 0xc
	    struct FString EventName; // 0x10 Size: 0x10
	    struct FLinearColor DebugGraphColor; // 0x20 Size: 0x10

};

struct FFortSurfaceDamageRatioStats : public FTableRowBase
{
	public:
	    FName Default; // 0x8 Size: 0x8
	    FName Wood; // 0x10 Size: 0x8
	    FName Stone; // 0x18 Size: 0x8
	    FName Metal; // 0x20 Size: 0x8
	    FName HumanEntity; // 0x28 Size: 0x8
	    FName AIEntity; // 0x30 Size: 0x8
	    FName Explosive; // 0x38 Size: 0x8
	    FName WeakSpot; // 0x40 Size: 0x8
	    FName Objective; // 0x48 Size: 0x8
	    FName WeakSpot_Wood; // 0x50 Size: 0x8
	    FName WeakSpot_Stone; // 0x58 Size: 0x8
	    FName WeakSpot_Metal; // 0x60 Size: 0x8

};

struct FFortSurfaceDamageRatioByAffiliationStats : public FTableRowBase
{
	public:
	    float Friendly; // 0x8 Size: 0x4
	    float Neutral; // 0xc Size: 0x4
	    float Hostile; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortDamageSource
{
	public:
	    TWeakObjectPtr<AController*> InstigatorController; // 0x0 Size: 0x8
	    TWeakObjectPtr<AActor*> DamageCauser; // 0x8 Size: 0x8

};

struct FFortActiveMontageDecisionWindow
{
	public:
	    class UFortAnimNotifyState_AbilityDecisionWindow* DecisionWindow; // 0x0 Size: 0x8
	    class UAnimSequenceBase* DecisionAnimation; // 0x8 Size: 0x8
	    bool bReceivedPrimaryInput; // 0x10 Size: 0x1
	    bool bReceivedSecondaryInput; // 0x11 Size: 0x1
	    bool bAlreadyProcessedInput; // 0x12 Size: 0x1
	    char UnknownData0[0x5];

};

struct FFortMontageInputAction
{
	public:
	    struct FGameplayTag TriggerAbilityTag; // 0x0 Size: 0x8
	    FName NextSection; // 0x8 Size: 0x8
	    EFortMontageInputType InputType; // 0x10 Size: 0x1
	    char UnknownData0[0x3];

};

struct FPatternBASEEffect
{
	public:
	    class UBuildingEditModeMetadata* Pattern; // 0x0 Size: 0x8
	    class UStaticMesh* Mesh; // 0x8 Size: 0x8

};

struct FBASEGameplayEffect
{
	public:
	    class UGameplayEffect* Effect; // 0x0 Size: 0x8
	    int LevelOverride; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FConsumeEffectData
{
	public:
	    __int64/*SoftClassProperty*/ EffectClass; // 0x0 Size: 0x28
	    struct FScalableFloat Level; // 0x28 Size: 0x20

};

struct FFortFeedbackHandle
{
	public:
	    class UFortFeedbackBank* FeedbackBank; // 0x0 Size: 0x8
	    FName EventName; // 0x8 Size: 0x8
	    bool bReadOnly; // 0x10 Size: 0x1
	    bool bBankDefined; // 0x11 Size: 0x1
	    char BroadcastFilterOverride; // 0x12 Size: 0x1
	    char UnknownData0[0x5];

};

struct FFortSentenceAudio
{
	public:
	    struct TSoftObjectPtr<struct USoundBase*> Audio; // 0x0 Size: 0x28
	    struct FFortFeedbackHandle Handle; // 0x28 Size: 0x18

};

struct FFortConversationSentence
{
	public:
	    struct FFortSentenceAudio SpeechAudio; // 0x0 Size: 0x40
	    struct FText SpeechText; // 0x40 Size: 0x18
	    struct TSoftObjectPtr<struct UTexture2D*> TalkingHeadTexture; // 0x58 Size: 0x28
	    struct FText TalkingHeadTitle; // 0x80 Size: 0x18
	    struct TSoftObjectPtr<struct UAnimMontage*> AnimMontage; // 0x98 Size: 0x28
	    float PostSentenceDelay; // 0xc0 Size: 0x4
	    float DisplayDuration; // 0xc4 Size: 0x4

};

struct FFortConversionTierData
{
	public:
	    int TierCost; // 0x0 Size: 0x4
	    int RequiredItemQuantity; // 0x4 Size: 0x4

};

struct FBaseVariantDef
{
	public:
	    bool bStartUnlocked; // 0x8 Size: 0x1
	    bool bIsDefault; // 0x9 Size: 0x1
	    bool bHideIfNotOwned; // 0xa Size: 0x1
	    char UnknownData0[0x1]; // 0xb
	    struct FGameplayTag CustomizationVariantTag; // 0xc Size: 0x8
	    char UnknownData1[0x4]; // 0x14
	    struct FText VariantName; // 0x18 Size: 0x18
	    struct TSoftObjectPtr<struct UTexture2D*> PreviewImage; // 0x30 Size: 0x28
	    struct FText UnlockRequirements; // 0x58 Size: 0x18

};

struct FGameplayTagVariantDef : public FBaseVariantDef
{
	public:
	    char UnknownData0[0x70];

};

struct FCosmeticMarkupTagDataRow : public FTableRowBase
{
	public:
	    struct FGameplayTag Tag; // 0x8 Size: 0x8
	    struct FText DisplayName; // 0x10 Size: 0x18
	    struct FText HelpText; // 0x28 Size: 0x18

};

struct FCosmeticSetDataRow : public FTableRowBase
{
	public:
	    struct FGameplayTag Tag; // 0x8 Size: 0x8
	    struct FText DisplayName; // 0x10 Size: 0x18
	    struct FText Description; // 0x28 Size: 0x18

};

struct FSocketTransformVariant
{
	public:
	    FName SourceSocketName; // 0x0 Size: 0x8
	    FName OverridSocketName; // 0x8 Size: 0x8
	    struct TSoftObjectPtr<struct USkeletalMesh*> SourceObjectToModify; // 0x10 Size: 0x28

};

struct FMaterialParamName
{
	public:
	    FName ParamName; // 0x0 Size: 0x8

};

struct FMaterialFloatVariant : public FMaterialParamName
{
	public:
	    float Value; // 0x8 Size: 0x4

};

struct FVectorParamVariant : public FMaterialParamName
{
	public:
	    struct FVector Value; // 0x8 Size: 0xc

};

struct FMaterialVectorVariant : public FMaterialParamName
{
	public:
	    struct FLinearColor Value; // 0x8 Size: 0x10

};

struct FParticleVariant
{
	public:
	    struct TSoftObjectPtr<struct UParticleSystem*> ParticleSystemToAlter; // 0x0 Size: 0x28
	    FName ComponentToOverride; // 0x28 Size: 0x8
	    struct TSoftObjectPtr<struct UParticleSystem*> OverrideParticleSystem; // 0x30 Size: 0x28

};

struct FMaterialTextureVariant : public FMaterialParamName
{
	public:
	    struct TSoftObjectPtr<struct UTexture*> Value; // 0x8 Size: 0x28

};

struct FMaterialVariants
{
	public:
	    struct TSoftObjectPtr<struct UMaterialInterface*> MaterialToSwap; // 0x0 Size: 0x28
	    FName ComponentToOverride; // 0x28 Size: 0x8
	    FName CascadeMaterialName; // 0x30 Size: 0x8
	    int MaterialOverrideIndex; // 0x38 Size: 0x4
	    char UnknownData0[0x4]; // 0x3c
	    struct TSoftObjectPtr<struct UMaterialInterface*> OverrideMaterial; // 0x40 Size: 0x28

};

struct FCreativeActorMetaData
{
	public:
	    int AssetSize; // 0x0 Size: 0x4
	    int InstanceSize; // 0x4 Size: 0x4

};

struct FFortCreativeBudgetClassInstanceLimit
{
	public:
	    __int64/*SoftClassProperty*/ ActorClass; // 0x0 Size: 0x28
	    int MaxNumberOfInstances; // 0x28 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortCreativeBudgetOverride
{
	public:
	    __int64/*SoftClassProperty*/ ActorClass; // 0x0 Size: 0x28
	    int AssetCost; // 0x28 Size: 0x4
	    float AssetCostMultiplier; // 0x2c Size: 0x4
	    int InstanceCost; // 0x30 Size: 0x4
	    float InstanceCostMultiplier; // 0x34 Size: 0x4

};

struct FMemoryBudget
{
	public:
	    int TotalMemory; // 0x0 Size: 0x4
	    int AvailableMemory; // 0x4 Size: 0x4
	    int InUseMemory; // 0x8 Size: 0x4
	    char UnknownData0[0x8];

};

struct FCreativePhysicsEffectedActor
{
	public:
	    class AActor* Actor; // 0x0 Size: 0x8
	    char UnknownData0[0x8]; // 0x8
	    struct FTransform ActorToSelection; // 0x10 Size: 0x30
	    struct FBox SelectionSpaceActorsBounds; // 0x40 Size: 0x1c
	    struct FVector Velocity; // 0x5c Size: 0xc
	    float EffectStartTime; // 0x68 Size: 0x4
	    char UnknownData1[0x4];

};

struct FCreativePooledMID
{
	public:
	    class UMaterialInstanceDynamic* Mid; // 0x0 Size: 0x8
	    class UMaterialInterface* OriginalMaterial; // 0x8 Size: 0x8

};

struct FCreativeSelectedActorInfo
{
	public:
	    class AActor* Actor; // 0x0 Size: 0x8
	    char UnknownData0[0x8]; // 0x8
	    struct FTransform ActorToSelectionAtDragStart; // 0x10 Size: 0x30
	    float OriginalRelevancyDistance; // 0x40 Size: 0x4
	    bool bWasCollisionEnabled; // 0x44 Size: 0x1
	    bool bWasDormant; // 0x45 Size: 0x1
	    char UnknownData1[0xa];

};

struct FCreativeToolClasses : public FTableRowBase
{
	public:
	    __int64/*SoftClassProperty*/ ClassPath; // 0x8 Size: 0x28

};

struct FCreativeToolObjectInteractionRow : public FTableRowBase
{
	public:
	    class UDataTable* AllowedClasses; // 0x8 Size: 0x8
	    class UDataTable* ForbiddenClasses; // 0x10 Size: 0x8

};

struct FActiveRealEstatePlotInfo
{
	public:
	    class UFortCreativeRealEstatePlotItemDefinition* Plot; // 0x0 Size: 0x8
	    struct FVector Position; // 0x8 Size: 0xc
	    char UnknownData0[0x4];

};

struct FCreativePublishOptions
{
	public:
	    struct FString UserTitle; // 0x0 Size: 0x10
	    struct FString UserDescription; // 0x10 Size: 0x10
	    struct FString UserLocale; // 0x20 Size: 0x10

};

struct FSavedCustomMatchOptions
{
	public:
	    __int64/*MapProperty*/ CustomMatchOptions; // 0x0 Size: 0x50

};

struct FFortDailyRewardScheduleDisplayData
{
	public:
	    struct FText Title; // 0x0 Size: 0x18
	    struct FText Description; // 0x18 Size: 0x18
	    struct FText ItemDescription; // 0x30 Size: 0x18
	    struct FText EpicItemDescription; // 0x48 Size: 0x18

};

struct FFortDailyRewardScheduleDefinition
{
	public:
	    FName ScheduleName; // 0x0 Size: 0x8
	    struct TSoftObjectPtr<struct UFortDailyRewardScheduleTokenDefinition*> EnablingToken; // 0x8 Size: 0x28
	    class UDataTable* Rewards; // 0x30 Size: 0x8
	    struct FFortDailyRewardScheduleDisplayData DisplayData; // 0x38 Size: 0x60
	    struct FDateTime BeginDate; // 0x98 Size: 0x8
	    struct FDateTime EndDate; // 0xa0 Size: 0x8

};

struct FFortDailyLoginRewardStat
{
	public:
	    int NextDefaultReward; // 0x0 Size: 0x4
	    int TotalDaysLoggedIn; // 0x4 Size: 0x4
	    struct FDateTime LastClaimDate; // 0x8 Size: 0x8
	    __int64/*MapProperty*/ AdditionalSchedules; // 0x10 Size: 0x50

};

struct FFortDailyLoginRewardStat_ScheduleClaimed
{
	public:
	    int RewardsClaimed; // 0x0 Size: 0x4
	    bool ClaimedToday; // 0x4 Size: 0x1
	    char UnknownData0[0x3];

};

struct FLiveDamageNumberComponent
{
	public:
	    class UStaticMeshComponent* Component; // 0x0 Size: 0x8
	    char UnknownData0[0x10];

};

struct FFortTagToDeathCause
{
	public:
	    struct FGameplayTag DeathTag; // 0x0 Size: 0x8
	    EDeathCause DBNOCause; // 0x8 Size: 0x1
	    EDeathCause DeathCause; // 0x9 Size: 0x1
	    char UnknownData0[0x2];

};

struct FDecoPlacementState
{
	public:
	    struct FVector Start; // 0x0 Size: 0xc
	    struct FVector End; // 0xc Size: 0xc
	    struct FVector RawLocation; // 0x18 Size: 0xc
	    struct FVector Normal; // 0x24 Size: 0xc
	    struct FQuat AbsoluteRotation; // 0x30 Size: 0x10
	    struct FVector GridLocation; // 0x40 Size: 0xc
	    struct FVector PreviousLocation; // 0x4c Size: 0xc
	    struct FVector FallbackLocation; // 0x58 Size: 0xc
	    TWeakObjectPtr<AActor*> LastHitActor; // 0x64 Size: 0x8
	    TWeakObjectPtr<ABuildingSMActor*> CurrentBuildingActorAttachment; // 0x6c Size: 0x8
	    char CanPlaceState; // 0x74 Size: 0x1
	    char UnknownData0[0xb];

};

struct FFortTierProgressionInfo
{
	public:
	    struct FString ProgressionLayoutGuid; // 0x0 Size: 0x10
	    int HighestDefeatedTier; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FActiveTieredCollectionLayout : public FFastArraySerializerItem
{
	public:
	    char UnknownData0[0x4];
	    class UFortTieredCollectionLayout* Layout; // 0x10 Size: 0x8
	    int MaxTierUnlocked; // 0x18 Size: 0x4
	    bool bLocked; // 0x1c Size: 0x1
	    char UnknownData1[0x3];

};

struct FEnvironmentBuildingRestorationRecord
{
	public:
	    class ABuildingActor* ActorClass; // 0x0 Size: 0x8
	    char UnknownData0[0x8]; // 0x8
	    struct FTransform ActorTransform; // 0x10 Size: 0x30
	    FName QuotaSelectedLootTierKey; // 0x40 Size: 0x8
	    int QuotaSelectedLootTier; // 0x48 Size: 0x4
	    char UnknownData1[0x4];

};

struct FFortUserCloudRequestHandle
{
	public:
	    uint64_t Handle; // 0x0 Size: 0x8

};

struct FDeployableBaseInstance : public FFastArraySerializerItem
{
	public:
	    char UnknownData0[0x4];
	    class ADeployableBasePlot* DeployableBase; // 0x10 Size: 0x8

};

struct FFortTaggedUnlockBase
{
	public:
	    struct FGameplayTag RequiredTag; // 0x0 Size: 0x8

};

struct FFortTaggedDeployableBaseLootUnlock : public FFortTaggedUnlockBase
{
	public:
	    FName LootTierGroup; // 0x8 Size: 0x8

};

struct FFortTaggedDeployableBasePlotExpansionUnlock : public FFortTaggedUnlockBase
{
	public:
	    struct FIntVector CellExpansionVector; // 0x8 Size: 0xc

};

struct FDevHeroClassInfo
{
	public:
	    struct FString Name; // 0x0 Size: 0x10
	    int Level; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortMissionGenerationElementCostAndAvailabilityRow : public FTableRowBase
{
	public:
	    class UCurveTable* AvailabilityCurveTable; // 0x8 Size: 0x8
	    FName AvailabilityCurveTableRow; // 0x10 Size: 0x8
	    float MinCost; // 0x18 Size: 0x4
	    float MaxCost; // 0x1c Size: 0x4

};

struct FFortEncounterLockedUtility
{
	public:
	    char Utility; // 0x0 Size: 0x1
	    char UtilityDesire; // 0x1 Size: 0x1

};

struct FFortCriteriaRequirementData : public FTableRowBase
{
	public:
	    struct FGameplayTag RequiredTag; // 0x8 Size: 0x8
	    bool bGlobalMod; // 0x10 Size: 0x1
	    char UnknownData0[0x3]; // 0x11
	    float ModValue; // 0x14 Size: 0x4
	    bool bRequireRarity; // 0x18 Size: 0x1
	    EFortRarity RequiredRarity; // 0x19 Size: 0x1
	    char UnknownData1[0x6];

};

struct FFortSpokenLine
{
	public:
	    class USoundBase* Audio; // 0x0 Size: 0x8
	    class UAnimMontage* AnimMontage; // 0x8 Size: 0x8
	    class UAnimSequence* AnimSequence; // 0x10 Size: 0x8
	    class AFortPawn* Addressee; // 0x18 Size: 0x8
	    char BroadcastFilter; // 0x20 Size: 0x1
	    char UnknownData0[0x3]; // 0x21
	    float Delay; // 0x24 Size: 0x4
	    bool bInterruptCurrentLine; // 0x28 Size: 0x1
	    bool bCanBeInterrupted; // 0x29 Size: 0x1
	    bool bCanQue; // 0x2a Size: 0x1
	    char UnknownData1[0x5];

};

struct FFortFeedbackEvent
{
	public:
	    class AFortPawn* Instigator; // 0x0 Size: 0x8
	    class AFortPawn* Recipient; // 0x8 Size: 0x8
	    struct FFortFeedbackHandle Handle; // 0x10 Size: 0x18
	    float Delay; // 0x28 Size: 0x4
	    bool bOverriddenQueuing; // 0x2c Size: 0x1
	    char UnknownData0[0x3];

};

struct FFortFeedbackEventData
{
	public:
	    struct FFortFeedbackHandle Handle; // 0x0 Size: 0x18
	    float ChanceToPlay; // 0x18 Size: 0x4
	    float MinReplayTime; // 0x1c Size: 0x4
	    float MinReplayTimeForSpeaker; // 0x20 Size: 0x4
	    float MaxWitnessDistance; // 0x24 Size: 0x4
	    bool bInterruptCurrentLine; // 0x28 Size: 0x1
	    bool bCanBeInterrupted; // 0x29 Size: 0x1
	    bool bCanQue; // 0x2a Size: 0x1
	    char MultiplayerBroadcastFilter; // 0x2b Size: 0x1
	    char ContextSelectionMethod; // 0x2c Size: 0x1
	    char UnknownData0[0x3]; // 0x2d
	    float FeedbackDelay; // 0x30 Size: 0x4
	    float TimeLastPlayed; // 0x34 Size: 0x4

};

struct FFortFeedbackResponse
{
	public:
	    struct FFortFeedbackHandle Handle; // 0x0 Size: 0x18
	    char Context; // 0x18 Size: 0x1
	    char UnknownData0[0x7];

};

struct FFortFeedbackActionBankDefined : public FFortFeedbackAction
{
	public:
	    float MinReplayTime; // 0x30 Size: 0x4
	    float MinReplayTimeForSpeaker; // 0x34 Size: 0x4

};

struct FFerretVehicleBoostLevel
{
	public:
	    float AccumulationPercent; // 0x0 Size: 0x4
	    float BoostTime; // 0x4 Size: 0x4

};

struct FFortFlightModel
{
	public:
	    char UnknownData0[0x200];

};

struct FFlightParams
{
	public:
	    float TopSpeedKmh; // 0x0 Size: 0x4
	    float LiftoffSpeedKmh; // 0x4 Size: 0x4
	    float ControlSpeedKmh; // 0x8 Size: 0x4
	    float HeadingStabilizationRate; // 0xc Size: 0x4
	    float HeadingStabilizationMaxForwardVelocityKmh; // 0x10 Size: 0x4
	    float HeadingStabilizationMaxDegPerSecond; // 0x14 Size: 0x4
	    float VerticalStabilizationDrag; // 0x18 Size: 0x4
	    float HorizontalStabilizationDrag; // 0x1c Size: 0x4
	    float VerticalStabilizationTorque; // 0x20 Size: 0x4
	    float MaxVerticalStabilizationTorque; // 0x24 Size: 0x4
	    float HorizontalStabilizationTorque; // 0x28 Size: 0x4
	    float MaxHorizontalStabilizationTorque; // 0x2c Size: 0x4
	    float RotationalDampingCoefficient; // 0x30 Size: 0x4
	    float MaxRotationalDampingTorque; // 0x34 Size: 0x4
	    float TailLength; // 0x38 Size: 0x4
	    float LowSpeedThrust; // 0x3c Size: 0x4
	    float HighSpeedThrust; // 0x40 Size: 0x4
	    float AntigravityHorizontal; // 0x44 Size: 0x4
	    float AntigravityUp; // 0x48 Size: 0x4
	    float AntigravityDown; // 0x4c Size: 0x4
	    float ControlFrameHeight; // 0x50 Size: 0x4
	    float ControlFrameDistance; // 0x54 Size: 0x4
	    float ControlFrameDistanceInterpPerSecond; // 0x58 Size: 0x4
	    float ControlFrameOrbitInterpPerSecond; // 0x5c Size: 0x4
	    float ControlFrameRollInterpPerSecond; // 0x60 Size: 0x4
	    struct FVector ControlFrameDefaultRollUp; // 0x64 Size: 0xc
	    float ControlFrameRollUpAcceleration; // 0x70 Size: 0x4
	    float ControlFrameRollUpMaxVelocity; // 0x74 Size: 0x4
	    float ControlFrameRollUpDamping; // 0x78 Size: 0x4
	    float ControlFrameMinUpNudge; // 0x7c Size: 0x4
	    float ControlFrameMaxUpNudge; // 0x80 Size: 0x4
	    float ControlFrameUpsideDownIgnoreNudgePercent; // 0x84 Size: 0x4
	    float SteerPitchRate; // 0x88 Size: 0x4
	    float SteerYawRate; // 0x8c Size: 0x4
	    float SteerMaxHeadingDiffDegrees; // 0x90 Size: 0x4
	    float RollPerHeadingDiff; // 0x94 Size: 0x4
	    float HeadingMatchRate; // 0x98 Size: 0x4
	    float RollMatchRate; // 0x9c Size: 0x4
	    float MatchingTorqueCap; // 0xa0 Size: 0x4

};

struct FFortFootstepAudioData
{
	public:
	    class USoundBase* SoundAssets; // 0x0 Size: 0x8
	    char UnknownData0[0x30]; // 0x8
	    class USoundBase* SoundAssetsAbove; // 0x38 Size: 0x8
	    char UnknownData1[0x30]; // 0x40
	    class USoundBase* SoundAssetsBelow; // 0x70 Size: 0x8
	    char UnknownData2[0x30]; // 0x78
	    class USoundAttenuation* SoundAttenuation; // 0xa8 Size: 0x8
	    class USoundAttenuation* SoundAttenuationAbove; // 0xb0 Size: 0x8
	    class USoundAttenuation* SoundAttenuationBelow; // 0xb8 Size: 0x8
	    class USoundAttenuation* SoundAttenuationAboveOrBelowAndVisible; // 0xc0 Size: 0x8
	    float VolumeMultiplier; // 0xc8 Size: 0x4
	    char UnknownData3[0x4];

};

struct FCameraPair
{
	public:
	    EFrontEndCamera Type; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class AFortCameraBase* Camera; // 0x8 Size: 0x8

};

struct FFortFXAnimationInfoBase
{
	public:
	    class UCurveFloat* LerpCurve; // 0x0 Size: 0x8
	    char UnknownData0[0x10];

};

struct FFortFloatAnimationInfo : public FFortFXAnimationInfoBase
{
	public:
	    char UnknownData0[0x20];

};

struct FFortFloatParamAnimationInfo : public FFortFloatAnimationInfo
{
	public:
	    char UnknownData0[0x28];

};

struct FFortLinearColorCurveAnimationInfo : public FFortFXAnimationInfoBase
{
	public:
	    char UnknownData0[0x28];

};

struct FFortLinearColorCurveParamAnimationInfo : public FFortLinearColorCurveAnimationInfo
{
	public:
	    char UnknownData0[0x30];

};

struct FFortLinearColorAnimationInfo : public FFortFXAnimationInfoBase
{
	public:
	    char UnknownData0[0x38];

};

struct FFortLinearColorParamAnimationInfo : public FFortLinearColorAnimationInfo
{
	public:
	    char UnknownData0[0x40];

};

struct FFortSplineMeshSnapAnimationInfo : public FFortFXAnimationInfoBase
{
	public:
	    class USplineComponent* TargetSpline; // 0x18 Size: 0x8
	    char UnknownData0[0x8];

};

struct FFortSplineMeshScaleAnimationInfo : public FFortFXAnimationInfoBase
{
	public:
	    char UnknownData0[0x28];

};

struct FSubGameInfo
{
	public:
	    class UFortTokenType* AccessToken; // 0x0 Size: 0x8
	    bool RequiredFullInstall; // 0x8 Size: 0x1
	    bool bCanPartyWithoutFullInstall; // 0x9 Size: 0x1
	    char UnknownData0[0x6];

};

struct FTieredModifierSetData
{
	public:
	    int WaveNumber; // 0x0 Size: 0x4
	    int ModifierDuration; // 0x4 Size: 0x4
	    FName ModifierLootTierGroup; // 0x8 Size: 0x8

};

struct FTieredWaveSetCollectionData
{
	public:
	    struct FText DefenseText; // 0x0 Size: 0x18
	    struct FText LevelText; // 0x18 Size: 0x18
	    struct FText WaveText; // 0x30 Size: 0x18
	    struct FText BreatherText; // 0x48 Size: 0x18
	    int MinLvl; // 0x60 Size: 0x4
	    int MaxLvl; // 0x64 Size: 0x4
	    FName BaseWaveLengthRowName; // 0x68 Size: 0x8
	    FName BaseNumOfKillsRowName; // 0x70 Size: 0x8
	    FName BaseNumOfKillPointsRowName; // 0x78 Size: 0x8
	    FName WaveSet; // 0x80 Size: 0x8

};

struct FScoreMultiplierRow : public FTableRowBase
{
	public:
	    float CombatMultiplier; // 0x8 Size: 0x4
	    float BuildingMultiplier; // 0xc Size: 0x4
	    float UtilityMultiplier; // 0x10 Size: 0x4
	    float BadgeMultiplier; // 0x14 Size: 0x4
	    int MonsterKills; // 0x18 Size: 0x4
	    int MonsterDamagePoints; // 0x1c Size: 0x4
	    int PlayerKills; // 0x20 Size: 0x4
	    int WoodGathered; // 0x24 Size: 0x4
	    int StoneGathered; // 0x28 Size: 0x4
	    int MetalGathered; // 0x2c Size: 0x4
	    int Deaths; // 0x30 Size: 0x4
	    int BuildingsBuilt; // 0x34 Size: 0x4
	    int BuildingsBuilt_Wood; // 0x38 Size: 0x4
	    int BuildingsBuilt_Stone; // 0x3c Size: 0x4
	    int BuildingsBuilt_Metal; // 0x40 Size: 0x4
	    int BuildingsUpgraded_Wood2; // 0x44 Size: 0x4
	    int BuildingsUpgraded_Wood3; // 0x48 Size: 0x4
	    int BuildingsUpgraded_Stone2; // 0x4c Size: 0x4
	    int BuildingsUpgraded_Stone3; // 0x50 Size: 0x4
	    int BuildingsUpgraded_Metal2; // 0x54 Size: 0x4
	    int BuildingsUpgraded_Metal3; // 0x58 Size: 0x4
	    int BuildingsDestroyed; // 0x5c Size: 0x4
	    int Repair_Wood; // 0x60 Size: 0x4
	    int Repair_Stone; // 0x64 Size: 0x4
	    int Repair_Metal; // 0x68 Size: 0x4
	    int FlagsCaptured; // 0x6c Size: 0x4
	    int FlagsReturned; // 0x70 Size: 0x4
	    int ContainersLooted; // 0x74 Size: 0x4
	    int CraftingPoints; // 0x78 Size: 0x4
	    int TrapPlacementPoints; // 0x7c Size: 0x4
	    int TrapActivationPoints; // 0x80 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortReplicatedStatMapping
{
	public:
	    EStatCategory StatCategory; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FText DisplayName; // 0x8 Size: 0x18

};

struct FWorldItemAndMinMaxCount
{
	public:
	    struct FCurveTableRowHandle MinCurveTable; // 0x0 Size: 0x10
	    struct FCurveTableRowHandle MaxCurveTable; // 0x10 Size: 0x10
	    class UFortWorldItemDefinition* Item; // 0x20 Size: 0x8

};

struct FItemDefinitionAndCount
{
	public:
	    int Count; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    struct TSoftObjectPtr<struct UFortItemDefinition*> ItemDefinition; // 0x8 Size: 0x28

};

struct FSettingsHUDVisibilityAndText
{
	public:
	    struct FGameplayTag HUDVisibilityGameplayTag; // 0x0 Size: 0x8
	    ESlateVisibility DefaultHUDVisibility; // 0x8 Size: 0x1
	    char UnknownData0[0x7]; // 0x9
	    struct FText DisplayText; // 0x10 Size: 0x18
	    struct FText ToolTipText; // 0x28 Size: 0x18

};

struct FFortHighlightColors
{
	public:
	    struct FLinearColor OutlineColor; // 0x0 Size: 0x10
	    struct FLinearColor SceneModulationColor1; // 0x10 Size: 0x10
	    struct FLinearColor SceneModulationColor2; // 0x20 Size: 0x10

};

struct FFortHighlightColorsContainer
{
	public:
	    struct FFortHighlightColors ValidHighlight; // 0x0 Size: 0x30
	    struct FFortHighlightColors InvalidHighlight; // 0x30 Size: 0x30

};

struct FFortRewardQuantityPair
{
	public:
	    struct FString TemplateId; // 0x0 Size: 0x10
	    int Quantity; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FUISoundFeedback
{
	public:
	    struct TSoftObjectPtr<struct USoundBase*> UISound; // 0x0 Size: 0x28

};

struct FAttributeClamp
{
	public:
	    struct FGameplayAttribute Attribute; // 0x0 Size: 0x20
	    EClampType ClampType; // 0x20 Size: 0x1
	    char UnknownData0[0x3]; // 0x21
	    float ClampValue; // 0x24 Size: 0x4

};

struct FGameDifficultyInfo : public FTableRowBase
{
	public:
	    int ContentAccountLevel; // 0x8 Size: 0x4
	    float Difficulty; // 0xc Size: 0x4
	    float DifficultyMatchmakingMinOverride; // 0x10 Size: 0x4
	    float DifficultyMatchmakingMaxOverride; // 0x14 Size: 0x4
	    int LootLevel; // 0x18 Size: 0x4
	    int RequiredRating; // 0x1c Size: 0x4
	    int PvPRating; // 0x20 Size: 0x4
	    int RecommendedRating; // 0x24 Size: 0x4
	    float ScoreBonus; // 0x28 Size: 0x4
	    char UnknownData0[0x4]; // 0x2c
	    struct FString LootTierGroup; // 0x30 Size: 0x10
	    struct FString BonusLootTierGroup; // 0x40 Size: 0x10
	    struct FString DifficultyIncreaseLootTierGroup; // 0x50 Size: 0x10
	    int NumDifficultyIncreases; // 0x60 Size: 0x4
	    char UnknownData1[0x4]; // 0x64
	    struct FText ThreatDisplayName; // 0x68 Size: 0x18
	    FName ColorParamName; // 0x80 Size: 0x8
	    int DefaultPlayerLives; // 0x88 Size: 0x4
	    FName PlayerStatClampRowName; // 0x8c Size: 0x8
	    char UnknownData2[0x4];

};

struct FAudioDynamicSoundData
{
	public:
	    FName Name; // 0x0 Size: 0x8
	    char SoundOverrideType; // 0x8 Size: 0x1
	    char UnknownData0[0x3]; // 0x9
	    float Volume; // 0xc Size: 0x4

};

struct FPlaylistAccess
{
	public:
	    bool bForcePlaylistOff; // 0x0 Size: 0x1
	    bool bEnabled; // 0x1 Size: 0x1
	    bool bVisibleWhenDisabled; // 0x2 Size: 0x1
	    bool bIsDefaultPlaylist; // 0x3 Size: 0x1
	    EPlaylistAdvertisementType AdvertiseType; // 0x4 Size: 0x1
	    bool bDisplayAsLimitedTime; // 0x5 Size: 0x1
	    char UnknownData0[0x2]; // 0x6
	    int DisplayPriority; // 0x8 Size: 0x4

};

struct FAthenaDataTableSet
{
	public:
	    class UDataTable* LootTierData; // 0x0 Size: 0x8
	    class UDataTable* LootPackages; // 0x8 Size: 0x8
	    class UDataTable* RangedWeapons; // 0x10 Size: 0x8
	    class UCurveTable* GameData; // 0x18 Size: 0x8
	    class UCurveTable* ResourceRates; // 0x20 Size: 0x8
	    class UCurveTable* VehicleData; // 0x28 Size: 0x8

};

struct FBCActionInfo
{
	public:
	    int Type; // 0x0 Size: 0x4
	    int Action; // 0x4 Size: 0x4

};

struct FFortAbilityCost
{
	public:
	    EFortAbilityCostSource CostSource; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FScalableFloat CostValue; // 0x8 Size: 0x20
	    class UFortItemDefinition* ItemDefinition; // 0x28 Size: 0x8
	    bool bOnlyApplyCostOnHit; // 0x30 Size: 0x1
	    char UnknownData1[0x7];

};

struct FFortCharacterPartMontageInfo
{
	public:
	    char CharacterPart; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class UAnimMontage* AnimMontage; // 0x8 Size: 0x8

};

struct FTurnFloatRange
{
	public:
	    float Min; // 0x0 Size: 0x4
	    float Max; // 0x4 Size: 0x4

};

struct FFortGameplayCueAttachInfo
{
	public:
	    FName SocketName; // 0x0 Size: 0x8
	    EFortGameplayCueAttachType AttachType; // 0x8 Size: 0x1
	    bool bAttachToWeapon; // 0xc Size: 0x1
	    bool bAttachToHitResult; // 0xc Size: 0x1
	    bool bUseUnsmoothedNetworkPosition; // 0xc Size: 0x1
	    bool bIgnoreScale; // 0xc Size: 0x1
	    bool bIgnoreRotation; // 0xc Size: 0x1
	    char UnknownData0[0x2]; // 0xe
	    struct FVector OverrideScale; // 0x10 Size: 0xc
	    struct FRotator OverrideRotation; // 0x1c Size: 0xc

};

struct FFortGameplayCueForceFeedbackInfo
{
	public:
	    class UForceFeedbackEffect* ForceFeedbackEffect; // 0x0 Size: 0x8
	    float EffectRadius; // 0x8 Size: 0x4
	    char UnknownData0[0x4]; // 0xc
	    class UForceFeedbackEffect* FarForceFeedbackEffect; // 0x10 Size: 0x8
	    float FarEffectRadius; // 0x18 Size: 0x4
	    FName EffectTag; // 0x1c Size: 0x8
	    bool bAlwaysPlayOnTarget; // 0x24 Size: 0x1
	    char UnknownData1[0x3];

};

struct FFortGameplayCueAOEInfo
{
	public:
	    float InnerRadius; // 0x0 Size: 0x4
	    float OuterRadius; // 0x4 Size: 0x4

};

struct FFortGameplayCueCameraLensEffectInfo
{
	public:
	    class AEmitterCameraLensEffectBase* CameraLensEffect; // 0x0 Size: 0x8
	    struct FFortGameplayCueAOEInfo Falloff; // 0x8 Size: 0x8
	    bool bAlwaysPlayOnTarget; // 0x10 Size: 0x1
	    bool bCancelOnRemove; // 0x11 Size: 0x1
	    char UnknownData0[0x6];

};

struct FFortGameplayCueCameraShakeInfo
{
	public:
	    class UCameraShake* Shake; // 0x0 Size: 0x8
	    float Scale; // 0x8 Size: 0x4
	    char PlaySpace; // 0xc Size: 0x1
	    char UnknownData0[0x3]; // 0xd
	    struct FRotator UserPlaySpaceRotation; // 0x10 Size: 0xc
	    bool bAlwaysPlayOnTarget; // 0x1c Size: 0x1
	    bool bCalculateUserPlaySpaceRotationFromLocation; // 0x1d Size: 0x1
	    bool bCancelOnRemove; // 0x1e Size: 0x1
	    char UnknownData1[0x1]; // 0x1f
	    struct FFortGameplayCueAOEInfo Falloff; // 0x20 Size: 0x8

};

struct FFortGameplayCueAudioInfo_Looping : public FFortGameplayCueAudioInfo
{
	public:
	    float LoopingSoundFadeOutDuration; // 0x68 Size: 0x4
	    float LoopingSoundVolumeLevel; // 0x6c Size: 0x4

};

struct FOverlapRestrictions
{
	public:
	    int OverlapsPerActor; // 0x0 Size: 0x4
	    struct FGameplayTag OverlapActorTagRestrictions; // 0x4 Size: 0x8

};

struct FFortHostSessionParams
{
	public:
	    FName SessionName; // 0x0 Size: 0x8
	    int ControllerId; // 0x8 Size: 0x4

};

struct FMeshServiceMetadata
{
	public:
	    int64_t IceShellCurrentHealth; // 0x0 Size: 0x8

};

struct FPlaylistStreamedLevelData
{
	public:
	    bool bIsFinishedStreaming; // 0x10 Size: 0x1
	    char UnknownData0[0x7];

};

struct FHordeDifficultyTierInfo
{
	public:
	    FName DifficultyTierName; // 0x0 Size: 0x8
	    class UFortQuestItemDefinition* QuestPrerequisite; // 0x8 Size: 0x8

};

struct FPermaniteBoundariesInfo
{
	public:
	    int MaxPermaniteStructures; // 0x0 Size: 0x4
	    int TotalPermaniteStructures; // 0x4 Size: 0x4
	    float AveragePermaniteStructureLevel; // 0x8 Size: 0x4
	    int MinPermaniteStructureLevel; // 0xc Size: 0x4
	    int MaxPermaniteStructureLevel; // 0x10 Size: 0x4

};

struct FPlayerBuildableClassFilter
{
	public:
	    char ResourceType; // 0x0 Size: 0x1
	    char BuildingType; // 0x1 Size: 0x1
	    char UnknownData0[0x2]; // 0x2
	    int Level; // 0x4 Size: 0x4
	    class UBuildingEditModeMetadata* EditModeMetadata; // 0x8 Size: 0x8

};

struct FFortScalabilityModeSettings
{
	public:
	    char UnknownData0[0x50];

};

struct FFortSimpleGameStats
{
	public:
	    int GamesPlayed; // 0x0 Size: 0x4
	    int SecondsPlayed; // 0x4 Size: 0x4
	    int KillCount; // 0x8 Size: 0x4
	    int BestResult; // 0xc Size: 0x4
	    int LastReviewPromptDay; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FSavedCredentials
{
	public:
	    ESavedAccountType Type; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FString ID; // 0x8 Size: 0x10
	    struct FString Token; // 0x18 Size: 0x10

};

struct FSubGameAccess
{
	public:
	    ESubGame SubGame; // 0x0 Size: 0x1
	    ESubGameAccessStatus AccessStatus; // 0x1 Size: 0x1
	    ESubGameMatchmakingStatus MatchmakingStatus; // 0x2 Size: 0x1

};

struct FPartyFailureLogSubmitReason
{
	public:
	    struct FString Reason; // 0x0 Size: 0x10
	    struct FString SubReason; // 0x10 Size: 0x10

};

struct FGoatVehicleBoostLevel
{
	public:
	    float AccumulationPercent; // 0x0 Size: 0x4
	    float BoostTime; // 0x4 Size: 0x4

};

struct FFortHealthBarComponentData
{
	public:
	    struct FText DisplayText; // 0x0 Size: 0x18

};

struct FFortHelpAdditionalContent
{
	public:
	    EFortHelpContentLocation ContentLocation; // 0x0 Size: 0x1
	    bool ShowAdditionalImage; // 0x1 Size: 0x1
	    char UnknownData0[0x6]; // 0x2
	    struct FSlateBrush ImageToDisplay; // 0x8 Size: 0x88
	    bool ShowAdditionalWidget; // 0x90 Size: 0x1
	    char UnknownData1[0x7]; // 0x91
	    class UUserWidget* WidgetToDisplay; // 0x98 Size: 0x8

};

struct FHeroKeywordDisplayData
{
	public:
	    struct FGameplayTag KeyWordGameplayTag; // 0x0 Size: 0x8
	    struct FText KeywordDisplayName; // 0x8 Size: 0x18

};

struct FHeroPerkDefaultRequirements
{
	public:
	    int MinimumHeroTier; // 0x0 Size: 0x4
	    int MinimumHeroLevel; // 0x4 Size: 0x4
	    EFortRarity MinimumHeroRarity; // 0x8 Size: 0x1
	    char UnknownData0[0x3];

};

struct FFortHeroTierAbilityKit
{
	public:
	    struct TSoftObjectPtr<struct UFortAbilityKit*> GrantedAbilityKit; // 0x0 Size: 0x28
	    EFortRarity MinimumHeroRarity; // 0x28 Size: 0x1
	    char UnknownData0[0x7];

};

struct FFortHexMapCoord
{
	public:
	    int Horizontal; // 0x0 Size: 0x4
	    int Vertical; // 0x4 Size: 0x4
	    int Depth; // 0x8 Size: 0x4

};

struct FFortZoneEvent
{
	public:
	    FName EventType; // 0x0 Size: 0x8
	    class UObject* EventFocus; // 0x8 Size: 0x8
	    class UDataAsset* EventContent; // 0x10 Size: 0x8
	    class AActor* EventInstigator; // 0x18 Size: 0x8

};

struct FHomebaseNodeState
{
	public:
	    bool bIsOwned; // 0x0 Size: 0x1
	    bool bAreCostsPayable; // 0x1 Size: 0x1
	    char UnknownData0[0x2]; // 0x2
	    int Level; // 0x4 Size: 0x4

};

struct FWorkerSetBonusState
{
	public:
	    struct FGameplayTag SetBonusTag; // 0x0 Size: 0x8
	    int CurrentMatchCount; // 0x8 Size: 0x4
	    int RequiredMatchCountToActivate; // 0xc Size: 0x4

};

struct FWorkerSetBonusData
{
	public:
	    struct FGameplayTag SetBonusTypeTag; // 0x0 Size: 0x8
	    struct FText DisplayName; // 0x8 Size: 0x18
	    int RequiredWorkersCount; // 0x20 Size: 0x4
	    char UnknownData0[0x4]; // 0x24
	    class UGameplayEffect* SetBonusEffect; // 0x28 Size: 0x8
	    int SelectionWeight; // 0x30 Size: 0x4
	    int PowerPoints; // 0x34 Size: 0x4

};

struct FWorkerPortraitData
{
	public:
	    struct TSoftObjectPtr<struct UFortItemIconDefinition*> Portrait; // 0x0 Size: 0x28

};

struct FExpeditionSlot : public FTableRowBase
{
	public:
	    struct FGameplayTag SlotTag; // 0x8 Size: 0x8
	    struct FString LootTierGroup; // 0x10 Size: 0x10

};

struct FHomebaseSquadSlotId
{
	public:
	    FName SquadId; // 0x0 Size: 0x8
	    int SquadSlotIndex; // 0x8 Size: 0x4

};

struct FHomebaseBannerColorData : public FTableRowBase
{
	public:
	    FName ColorKeyName; // 0x8 Size: 0x8
	    FName CategoryRowName; // 0x10 Size: 0x8

};

struct FHomebaseBannerIconData : public FTableRowBase
{
	public:
	    struct TSoftObjectPtr<struct UTexture2D*> SmallImage; // 0x8 Size: 0x28
	    struct TSoftObjectPtr<struct UTexture2D*> LargeImage; // 0x30 Size: 0x28
	    FName CategoryRowName; // 0x58 Size: 0x8
	    struct FText DisplayName; // 0x60 Size: 0x18
	    struct FText DisplayDescription; // 0x78 Size: 0x18
	    bool bFullUsageRights; // 0x90 Size: 0x1
	    char UnknownData0[0x7];

};

struct FHomebaseBannerCategoryData : public FTableRowBase
{
	public:
	    struct FText CategoryDisplayName; // 0x8 Size: 0x18
	    int SortPriority; // 0x20 Size: 0x4
	    char UnknownData0[0x4];

};

struct FHomebaseBannerColor
{
	public:
	    struct FLinearColor PrimaryColor; // 0x0 Size: 0x10
	    struct FLinearColor SecondaryColor; // 0x10 Size: 0x10

};

struct FTeamMapExplorationEvent
{
	public:
	    char TeamId; // 0x0 Size: 0x1
	    int8_t ExplorationThreshold; // 0x1 Size: 0x1

};

struct FScreenLabelText
{
	public:
	    struct FText NormalText; // 0x0 Size: 0x18
	    struct FText RichText; // 0x18 Size: 0x18

};

struct FFortInstensityCurveSequenceProgression
{
	public:
	    class UFortIntensityCurveSequence* CurveSequence; // 0x0 Size: 0x8
	    struct FCurveTableRowHandle SelectionWeight; // 0x8 Size: 0x10

};

struct FInteractionType
{
	public:
	    char InteractionType; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    TWeakObjectPtr<AFortPlayerPawn*> RequestingPawn; // 0x4 Size: 0x8
	    TWeakObjectPtr<AFortPlayerController*> RequestingPlayerController; // 0xc Size: 0x8
	    char UnknownData1[0x8]; // 0x14
	    TWeakObjectPtr<UPrimitiveComponent*> InteractComponent; // 0x1c Size: 0x8
	    TWeakObjectPtr<UObject*> OptionalObjectData; // 0x24 Size: 0x8
	    struct FVector InteractPoint; // 0x2c Size: 0xc

};

struct FItemCategoryMappingData
{
	public:
	    EFortItemType CategoryType; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FText CategoryName; // 0x8 Size: 0x18

};

struct FFortGiftGiver : public FFortGiftingInfo
{
	public:
	    int NumItemsGiven; // 0x28 Size: 0x4
	    char UnknownData0[0x4];

};

struct FItemWrapPreviewEntry
{
	public:
	    struct TSoftObjectPtr<struct UObject*> PreviewObject; // 0x0 Size: 0x28
	    char UnknownData0[0x8]; // 0x28
	    struct FTransform PreviewTransform; // 0x30 Size: 0x30
	    int WrapSectionLimit; // 0x60 Size: 0x4
	    bool bPreviewUsingVehicleShader; // 0x64 Size: 0x1
	    char UnknownData1[0xb];

};

struct FKeepEventInfo
{
	public:
	    struct TSoftObjectPtr<struct UFortKeepEventInfo*> KeepEvent; // 0x0 Size: 0x28
	    int DifficultyLevelOffset; // 0x28 Size: 0x4
	    char UnknownData0[0x4];

};

struct FKeepEventWaveData
{
	public:
	    struct FText WaveDescription; // 0x0 Size: 0x18
	    class UFortAIEncounterInfo* EncounterTemplate; // 0x18 Size: 0x8
	    class UFortAISpawnGroupProgressionInfo* SpawnGroupProgressionInfo; // 0x20 Size: 0x8
	    float WarmupTime; // 0x28 Size: 0x4
	    float EncounterTime; // 0x2c Size: 0x4
	    int DifficultyLevel; // 0x30 Size: 0x4
	    float AliveMultiplier; // 0x34 Size: 0x4
	    int EnemySpawnBits1; // 0x38 Size: 0x4
	    int EnemySpawnBits2; // 0x3c Size: 0x4

};

struct FServerLaunchInfo
{
	public:
	    float LaunchServerTime; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    class APawn* LaunchedPawn; // 0x8 Size: 0x8

};

struct FCreativeLoadedLinkData
{
	public:
	    struct FString Mnemonic; // 0x0 Size: 0x10
	    struct FString LinkTitle; // 0x10 Size: 0x10
	    struct FString IslandType; // 0x20 Size: 0x10

};

struct FFortPSALoadingScreen
{
	public:
	    int PercentChance; // 0x0 Size: 0x4
	    int MinimumGames; // 0x4 Size: 0x4
	    __int64/*SoftClassProperty*/ WidgetClass; // 0x8 Size: 0x28

};

struct FFortLootLevelData : public FTableRowBase
{
	public:
	    FName Category; // 0x8 Size: 0x8
	    int LootLevel; // 0x10 Size: 0x4
	    int MinItemLevel; // 0x14 Size: 0x4
	    int MaxItemLevel; // 0x18 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortLootQuotaData : public FTableRowBase
{
	public:
	    FName QuotaCategory; // 0x8 Size: 0x8
	    char QuotaLevel; // 0x10 Size: 0x1
	    char UnknownData0[0x3]; // 0x11
	    int Min; // 0x14 Size: 0x4
	    int Max; // 0x18 Size: 0x4
	    float Quota; // 0x1c Size: 0x4
	    int MinWorldLevel; // 0x20 Size: 0x4
	    int MaxWorldLevel; // 0x24 Size: 0x4

};

struct FFortMatchmakingConfig
{
	public:
	    float ChanceToHostOverride; // 0x0 Size: 0x4
	    float ChanceToHostIncrease; // 0x4 Size: 0x4
	    int MaxSearchResultsOverride; // 0x8 Size: 0x4
	    int MaxProcessedSearchResults; // 0xc Size: 0x4

};

struct FFortInviteSessionParams
{
	public:
	    char State; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FText FailureReason; // 0x8 Size: 0x18
	    char LastBeaconResponse; // 0x20 Size: 0x1
	    char UnknownData1[0x17];

};

struct FFortMatchmakingErrorInfo
{
	public:
	    EMatchmakingErrorV2 Error; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    struct FString ErrorCode; // 0x8 Size: 0x10
	    struct FString ResponseStr; // 0x18 Size: 0x10

};

struct FMMSAltDomainRecord
{
	public:
	    struct FString OriginalDomain; // 0x0 Size: 0x10
	    struct FString AltDomain; // 0x10 Size: 0x10

};

struct FMtxPackage
{
	public:
	    struct FString StorefrontName; // 0x0 Size: 0x10
	    struct FString OfferId; // 0x10 Size: 0x10
	    struct FText Title; // 0x20 Size: 0x18
	    struct FText Description; // 0x38 Size: 0x18
	    int TotalAmount; // 0x50 Size: 0x4
	    int BonusAmount; // 0x54 Size: 0x4
	    struct FText Price; // 0x58 Size: 0x18
	    char UnknownData0[0x8]; // 0x70
	    struct FText SaleBasePrice; // 0x78 Size: 0x18
	    struct FString DisplayAssetPath; // 0x90 Size: 0x10
	    struct FString BannerOverride; // 0xa0 Size: 0x10

};

struct FMtxBreakdown
{
	public:
	    int AvailableTotalMtx; // 0x0 Size: 0x4
	    int AvailablePremiumMtx; // 0x4 Size: 0x4
	    int UnavailableTotalMtx; // 0x8 Size: 0x4
	    int UnavailablePremiumMtx; // 0xc Size: 0x4

};

struct FFriendCodeIssuedNotification
{
	public:
	    struct FString Code; // 0x0 Size: 0x10
	    struct FString CodeType; // 0x10 Size: 0x10

};

struct FFortCollectionBookResearchItemNotification
{
	public:
	    struct FString ResearchedItemId; // 0x0 Size: 0x10
	    struct FString ResearchedTemplateId; // 0x10 Size: 0x10

};

struct FFortCollectionBookUnslotItemNotification
{
	public:
	    struct FString UnslottedItemId; // 0x0 Size: 0x10

};

struct FFortCollectionBookSlotItemNotification
{
	public:
	    struct FString SlottedItemId; // 0x0 Size: 0x10

};

struct FFortReceivedGiftedBoostXpNotification
{
	public:
	    int AmountBoostXpGifted; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    struct FString GifterAccountId; // 0x8 Size: 0x10

};

struct FFortEndMatchScoreNotification
{
	public:
	    __int64/*MapProperty*/ scoreNotifications; // 0x0 Size: 0x50

};

struct FFortEarnScoreNotification
{
	public:
	    int BaseXPEarned; // 0x0 Size: 0x4
	    int BonusXPEarned; // 0x4 Size: 0x4
	    int BoostXPEarned; // 0x8 Size: 0x4
	    int BoostXPMissed; // 0xc Size: 0x4
	    int RestXPEarned; // 0x10 Size: 0x4
	    int GroupBoostXPEarned; // 0x14 Size: 0x4

};

struct FFortDailyQuestRerollNotification
{
	public:
	    struct FString NewQuestId; // 0x0 Size: 0x10

};

struct FFortGetMcpTimeForPlayerNotification
{
	public:
	    struct FDateTime McpTime; // 0x0 Size: 0x8

};

struct FFortAthenaLoadoutData
{
	public:
	    EAthenaCustomizationCategory SlotName; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FString ItemToSlot; // 0x8 Size: 0x10
	    int IndexWithinSlot; // 0x18 Size: 0x4
	    char UnknownData1[0x4];

};

struct FFortAthenaSeasonStats
{
	public:
	    int NumWins; // 0x0 Size: 0x4
	    int NumHighBracket; // 0x4 Size: 0x4
	    int NumLowBracket; // 0x8 Size: 0x4

};

struct FFortAthenaEmoteCacheRecord
{
	public:
	    class UFortItemDefinition* ItemDef; // 0x0 Size: 0x8
	    char UnknownData0[0x8];

};

struct FFortAthenaConsumableRecord
{
	public:
	    class UFortAccountItemDefinition* ItemType; // 0x0 Size: 0x8
	    int TotalQuantity; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FGiftHistory
{
	public:
	    char UnknownData0[0x8];

};

struct FFortCommonPublicPersona
{
	public:
	    struct FString BannerIconId; // 0x0 Size: 0x10
	    struct FString BannerColorId; // 0x10 Size: 0x10
	    struct FString HomebaseName; // 0x20 Size: 0x10

};

struct FFortCreativePlotPermissionData
{
	public:
	    EFortCreativePlotPermission Permission; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    __int64/*SetProperty*/ WhiteList; // 0x8 Size: 0x50

};

struct FItemTransferOperation
{
	public:
	    struct FString ItemId; // 0x0 Size: 0x10
	    int Quantity; // 0x10 Size: 0x4
	    bool ToStorage; // 0x14 Size: 0x1
	    char UnknownData0[0x3]; // 0x15
	    struct FString NewItemIdHint; // 0x18 Size: 0x10

};

struct FItemIdAndQuantityPair
{
	public:
	    struct FString ItemId; // 0x0 Size: 0x10
	    int Quantity; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortProfileAndQuestSaveIdPair
{
	public:
	    char UnknownData0[0x30];

};

struct FFortTwitchPendingQuestNotification
{
	public:
	    char UnknownData0[0x10];

};

struct FFortTwitchViewerNameAndAccountId
{
	public:
	    struct FString TwitchViewerName; // 0x0 Size: 0x10
	    struct FString AccountId; // 0x10 Size: 0x10

};

struct FMcpSessionSummary
{
	public:
	    struct FString SessionId; // 0x0 Size: 0x10
	    struct FString EndTime; // 0x10 Size: 0x10
	    __int64/*MapProperty*/ TrackedStats; // 0x20 Size: 0x50

};

struct FMcpMatchResults
{
	public:
	    int Placement; // 0x0 Size: 0x4
	    int Kills; // 0x4 Size: 0x4
	    int Deaths; // 0x8 Size: 0x4

};

struct FQueryXboxUserXUIDParams
{
	public:
	    struct FString UserXSTSToken; // 0x0 Size: 0x10

};

struct FIssuedFriendCode
{
	public:
	    struct FString CodeId; // 0x0 Size: 0x10
	    struct FString CodeType; // 0x10 Size: 0x10
	    struct FDateTime DateCreated; // 0x20 Size: 0x8

};

struct FPlayerToxicityReportRequest
{
	public:
	    struct FString Reason; // 0x0 Size: 0x10
	    struct FString Details; // 0x10 Size: 0x10
	    struct FString GameSessionId; // 0x20 Size: 0x10
	    struct FString CreativeIslandSharingLink; // 0x30 Size: 0x10
	    struct FString CreativeIslandGuid; // 0x40 Size: 0x10
	    struct FString CreativeIslandOwnerAccountId; // 0x50 Size: 0x10

};

struct FFortMissionAlertRequirementsInfo
{
	public:
	    FName CategoryName; // 0x0 Size: 0x8
	    struct FFortRequirementsInfo Requirements; // 0x8 Size: 0x58

};

struct FFortTheaterDifficultyWeight
{
	public:
	    struct FDataTableRowHandle DifficultyInfo; // 0x0 Size: 0x10
	    struct FString LootTierGroup; // 0x10 Size: 0x10
	    float Weight; // 0x20 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortTheaterMissionWeight
{
	public:
	    __int64/*SoftClassProperty*/ MissionGenerator; // 0x0 Size: 0x28
	    float Weight; // 0x28 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortLinkedQuest
{
	public:
	    class UFortQuestItemDefinition* QuestDefinition; // 0x0 Size: 0x8
	    struct FDataTableRowHandle ObjectiveStatHandle; // 0x8 Size: 0x10

};

struct FFortMissionAlertRuntimeData
{
	public:
	    FName MissionAlertCategoryName; // 0x0 Size: 0x8
	    bool bRespectTileRequirements; // 0x8 Size: 0x1
	    bool bAllowQuickplay; // 0x9 Size: 0x1
	    char UnknownData0[0x2];

};

struct FFortTheaterColorInfo
{
	public:
	    bool bUseDifficultyToDetermineColor; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FSlateColor Color; // 0x8 Size: 0x28

};

struct FNavAgentData
{
	public:
	    FName AgentName; // 0x0 Size: 0x8
	    struct FCurveTableRowHandle BuildingActorHealthToNavAreaStrengthHandle; // 0x8 Size: 0x10

};

struct FFortMigrationDataTableRow : public FTableRowBase
{
	public:
	    struct FString OldItemTemplate; // 0x8 Size: 0x10
	    struct FString NewItemTemplate; // 0x18 Size: 0x10

};

struct FMinigamePlayer : public FFastArraySerializerItem
{
	public:
	    char UnknownData0[0x4];
	    class AFortPlayerState* PlayerState; // 0x10 Size: 0x8
	    bool bHasValidResetData; // 0x18 Size: 0x1
	    char TeamBeforeMinigameStarted; // 0x19 Size: 0x1
	    char UnknownData1[0x2]; // 0x1a
	    struct FVector LocationBeforeMinigameStarted; // 0x1c Size: 0xc
	    struct FRotator RotationBeforeMinigameStarted; // 0x28 Size: 0xc
	    bool bWasSkydivingBeforeMinigameStarted; // 0x34 Size: 0x1
	    bool bWasFlyingBeforeMinigameStarted; // 0x35 Size: 0x1
	    bool bIsTeleportingOrRespawningForGameplay; // 0x36 Size: 0x1
	    bool bWantsToSkydive; // 0x37 Size: 0x1

};

struct FMinigameScoreData
{
	public:
	    float Score; // 0x0 Size: 0x4

};

struct FMinigameSoloScoreData : public FMinigameScoreData
{
	public:
	    char UnknownData0[0x4];
	    class AFortPlayerState* PlayerState; // 0x8 Size: 0x8

};

struct FMinigameTeamScoreData : public FMinigameScoreData
{
	public:
	    char Team; // 0x4 Size: 0x1
	    char UnknownData0[0x3];

};

struct FMinigameScoreTemplate
{
	public:
	    EMinigameScoreType ScoreType; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    int NumHighScores; // 0x4 Size: 0x4
	    bool bAscending; // 0x8 Size: 0x1
	    char UnknownData1[0x3];

};

struct FMinigameHighScoreEntryRow : public FTableRowBase
{
	public:
	    struct FString PlayerName; // 0x8 Size: 0x10
	    float Score; // 0x18 Size: 0x4
	    char UnknownData0[0x4];

};

struct FMinigameHighScoreRow : public FTableRowBase
{
	public:
	    class UDataTable* HighScoresTable; // 0x8 Size: 0x8

};

struct FMinigameSpawnerSpawnParams
{
	public:
	    struct TSoftObjectPtr<struct UFortWorldItemDefinition*> PickupToSpawn; // 0x0 Size: 0x28
	    int PickupQuantity; // 0x28 Size: 0x4
	    char UnknownData0[0x4]; // 0x2c
	    struct FTransform SpawnTransform; // 0x30 Size: 0x30

};

struct FFortMinigameStatQuery
{
	public:
	    class UFortMinigameStatFilter* Stat; // 0x0 Size: 0x8
	    EFortMinigameStatScope Scope; // 0x8 Size: 0x1
	    bool bAnyMatch; // 0x9 Size: 0x1
	    EFortMinigameStatOperation Operation; // 0xa Size: 0x1
	    char UnknownData0[0x1]; // 0xb
	    int Value; // 0xc Size: 0x4
	    bool bStaticCount; // 0x10 Size: 0x1
	    char UnknownData1[0x7];

};

struct FFortMinigameStat
{
	public:
	    class UFortMinigameStatFilter* Filter; // 0x0 Size: 0x8
	    int Count; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortMinigamePlayerStats : public FFortMinigameGroupStats
{
	public:
	    class AFortPlayerState* Player; // 0x10 Size: 0x8

};

struct FFortMinigameTeamStats : public FFortMinigameGroupStats
{
	public:
	    char Team; // 0x10 Size: 0x1
	    char UnknownData0[0x7];

};

struct FFortMiniMapData
{
	public:
	    class UTexture2D* MiniMapIcon; // 0x0 Size: 0x8
	    struct FVector2D IconScale; // 0x8 Size: 0x8
	    bool bUseIconSize; // 0x10 Size: 0x1
	    bool bIsVisible; // 0x10 Size: 0x1
	    bool bIsVisibleOnMiniMap; // 0x10 Size: 0x1
	    bool bShowVerticalOffset; // 0x10 Size: 0x1
	    bool bShowFarOffIndicator; // 0x10 Size: 0x1
	    bool bDisplayIconEvenOnFogOfWar; // 0x10 Size: 0x1
	    bool bAllowLocalOverrides; // 0x10 Size: 0x1
	    bool bUseTeamAffiliationColors; // 0x10 Size: 0x1
	    Yea, we fucked up; // 0x0
	    struct FLinearColor Color; // 0x14 Size: 0x10
	    struct FLinearColor FriendColor; // 0x24 Size: 0x10
	    struct FLinearColor EnemyColor; // 0x34 Size: 0x10
	    struct FLinearColor NeutralColor; // 0x44 Size: 0x10
	    struct FLinearColor PulseColor; // 0x54 Size: 0x10
	    float ColorPulsesPerSecond; // 0x64 Size: 0x4
	    float SizePulsesPerSecond; // 0x68 Size: 0x4
	    float ViewableDistance; // 0x6c Size: 0x4
	    struct FVector LocationOffset; // 0x70 Size: 0xc
	    int Priority; // 0x7c Size: 0x4

};

struct FFortMissionFocusDisplayData
{
	public:
	    struct FText CurrentFocusDisplayText; // 0x0 Size: 0x18
	    float CurrentFocusPercentage; // 0x18 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortBadgeCount : public FFastArraySerializerItem
{
	public:
	    char UnknownData0[0x4];
	    class UFortBadgeItemDefinition* Badge; // 0x10 Size: 0x8
	    int Count; // 0x18 Size: 0x4
	    char UnknownData1[0x4];

};

struct FFortActiveThreatPlayerData
{
	public:
	    class AFortPlayerController* PlayerController; // 0x0 Size: 0x8
	    class UFortAIEncounterInfo* Encounter; // 0x8 Size: 0x8

};

struct FFortReactiveQuestDialogue
{
	public:
	    class UFortConversation* Conversation; // 0x0 Size: 0x8
	    int PlayOnObjectiveCount; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortMissionAlertSpreadData : public FTableRowBase
{
	public:
	    float ChanceToSpread; // 0x8 Size: 0x4
	    int TotalChancesToSpread; // 0xc Size: 0x4
	    int MaxNumTilesToSpreadTo; // 0x10 Size: 0x4
	    int SpreadInterval; // 0x14 Size: 0x4
	    FName MissionAlertRowName; // 0x18 Size: 0x8

};

struct FFortAthenaLTMConfig
{
	public:
	    struct TSoftObjectPtr<struct UTexture2D*> SplashImage; // 0x0 Size: 0x28
	    struct FText FrontEndDescription; // 0x28 Size: 0x18
	    struct FText DisabledMessage; // 0x40 Size: 0x18

};

struct FZoneLoadingScreenHeadingConfig
{
	public:
	    class UTexture2D* HeadingImage; // 0x0 Size: 0x8
	    struct FText Heading; // 0x8 Size: 0x18
	    struct FText HeadingDescription; // 0x20 Size: 0x18

};

struct FFortPossibleMission
{
	public:
	    struct TSoftObjectPtr<struct UFortMissionInfo*> MissionInfo; // 0x0 Size: 0x28
	    float Weight; // 0x28 Size: 0x4
	    int MinAlwaysGenerated; // 0x2c Size: 0x4
	    bool bIsPrototype; // 0x30 Size: 0x1
	    char UnknownData0[0x7];

};

struct FFortMissionInfoOption
{
	public:
	    struct TSoftObjectPtr<struct UFortMissionInfo*> MissionInfo; // 0x0 Size: 0x28
	    float MinDifficultyLevel; // 0x28 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortWindIntensityAndDirection
{
	public:
	    float WindIntensity; // 0x0 Size: 0x4
	    float WindHeading; // 0x4 Size: 0x4

};

struct FFortMissionPopupWidgetData
{
	public:
	    struct FText DisplayName; // 0x0 Size: 0x18
	    bool bShowDescription; // 0x18 Size: 0x1
	    char UnknownData0[0x7]; // 0x19
	    struct FText Description; // 0x20 Size: 0x18
	    struct FSlateBrush DescriptionIcon; // 0x38 Size: 0x88
	    struct FSlateBrush AvailableIcon; // 0xc0 Size: 0x88
	    struct FSlateBrush UnavailableIcon; // 0x148 Size: 0x88

};

struct FFortEncounterTransitionSettings
{
	public:
	    bool bShouldMaintainEncounterState; // 0x0 Size: 0x1

};

struct FFortMissionUIActorHandle
{
	public:
	    TWeakObjectPtr<AActor*> AttachedActor; // 0x0 Size: 0x8
	    struct FVector AttachmentOffset; // 0x8 Size: 0xc
	    float MaxVisibleDistance; // 0x14 Size: 0x4
	    struct FGuid MissionGuid; // 0x18 Size: 0x10
	    TWeakObjectPtr<UFortMissionInfoIndicator*> MissionUIIndicator; // 0x28 Size: 0x8

};

struct FMissionTimeDisplayData
{
	public:
	    float LessThanTimeValue; // 0x0 Size: 0x4
	    bool bHideTimer; // 0x4 Size: 0x1
	    char UnknownData0[0x3]; // 0x5
	    struct FLinearColor BaseColor; // 0x8 Size: 0x10
	    struct FLinearColor PulseColor; // 0x18 Size: 0x10
	    float ColorPulsesPerSecond; // 0x28 Size: 0x4

};

struct FMissionTimerData
{
	public:
	    bool bTimerIsPaused; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    float OriginalTimePeriod; // 0x4 Size: 0x4
	    float ReplicatedRemainingTime; // 0x8 Size: 0x4
	    float ClientRemainingTime; // 0xc Size: 0x4
	    char UnknownData1[0x18];

};

struct FFortMissionWeightedReward
{
	public:
	    FName LootTierGroup; // 0x0 Size: 0x8
	    struct FSlateBrush LootIcon; // 0x8 Size: 0x88
	    float Weight; // 0x90 Size: 0x4
	    char UnknownData0[0x4];

};

struct FAirControlParams
{
	public:
	    struct FScalableFloat MaxAcceleration; // 0x0 Size: 0x20
	    struct FScalableFloat LateralFriction; // 0x20 Size: 0x20
	    struct FScalableFloat MaxLateralSpeed; // 0x40 Size: 0x20
	    struct FScalableFloat TerminalVelocity; // 0x60 Size: 0x20
	    struct FScalableFloat UpwardTerminalVelocity; // 0x80 Size: 0x20
	    struct FScalableFloat GravityScalar; // 0xa0 Size: 0x20
	    struct FScalableFloat CustomGravityCeiling; // 0xc0 Size: 0x20
	    struct FScalableFloat CustomGravityCeilingWidth; // 0xe0 Size: 0x20

};

struct FAthenaJumpPenalty
{
	public:
	    float JumpScalar; // 0x0 Size: 0x4
	    float MovementScalar; // 0x4 Size: 0x4

};

struct FFortMusicSection
{
	public:
	    class USoundBase* Sound; // 0x0 Size: 0x8
	    float FadeInTime; // 0x8 Size: 0x4
	    float FadeOutTime; // 0xc Size: 0x4
	    float InitialOffset; // 0x10 Size: 0x4
	    float Duration; // 0x14 Size: 0x4

};

struct FQueuedMusic
{
	public:
	    char UnknownData0[0x10];

};

struct FFortNiagaraCascadeSystemPair
{
	public:
	    class UParticleSystem* ParticleSystem; // 0x0 Size: 0x8
	    class UNiagaraSystem* NiagaraParticleSystem; // 0x8 Size: 0x8

};

struct FVerifyProfileTokenPayload
{
	public:
	    __int64/*MapProperty*/ ProfileTokens; // 0x0 Size: 0x50

};

struct FRestrictedCountry
{
	public:
	    bool bHealthWarningShown; // 0x0 Size: 0x1
	    bool bAntiAddictionMessageShown; // 0x1 Size: 0x1
	    bool bRealMoneyStoreRestriction; // 0x2 Size: 0x1
	    bool bGameplayRestrictions; // 0x3 Size: 0x1

};

struct FGeneralChatRoom
{
	public:
	    struct FString RoomName; // 0x0 Size: 0x10
	    int CurrentMembersCount; // 0x10 Size: 0x4
	    int MaxMembersCount; // 0x14 Size: 0x4
	    struct FString PublicFacingShardName; // 0x18 Size: 0x10

};

struct FOutpostBuildingData
{
	public:
	    struct TSoftObjectPtr<struct UFortOutpostItemDefinition*> ItemDefinition; // 0x0 Size: 0x28

};

struct FOutpostPOSTBoost
{
	public:
	    struct FCurveTableRowHandle PlayerStructureHealthModPerPOSTLevel; // 0x0 Size: 0x10

};

struct FOutpostPOSTPerTheaterData
{
	public:
	    int TheaterSlot; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    struct FOutpostPOSTBoost POSTData; // 0x8 Size: 0x10

};

struct FOutpostUpgradesPerTheaterData
{
	public:
	    int TheaterSlot; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    class UDataTable* OutpostUpgradesData; // 0x8 Size: 0x8

};

struct FHarvestingOptimizerBuildingData : public FOutpostBuildingData
{
	public:
	    char UnknownData0[0x28];

};

struct FCraftingTableBuildingData : public FOutpostBuildingData
{
	public:
	    class UDataTable* ActivationCostData; // 0x28 Size: 0x8
	    class UGameplayEffect* ActivationEffect; // 0x30 Size: 0x8

};

struct FOutpostFabricatorPerTheaterData
{
	public:
	    int TheaterSlot; // 0x0 Size: 0x4
	    char MaxAllowedTier; // 0x4 Size: 0x1
	    char UnknownData0[0x3];

};

struct FOutpostCraftingTableData : public FTableRowBase
{
	public:
	    int Level; // 0x8 Size: 0x4
	    int ItemCount; // 0xc Size: 0x4
	    struct FString RequiredItems; // 0x10 Size: 0x10

};

struct FOutpostDisintegrationData : public FTableRowBase
{
	public:
	    struct TSoftObjectPtr<struct UFortWorldItemDefinition*> ItemDefinition; // 0x8 Size: 0x28
	    int DisintegrationValue; // 0x30 Size: 0x4
	    char UnknownData0[0x4];

};

struct FOutpostItemUpgradeData : public FTableRowBase
{
	public:
	    struct TSoftObjectPtr<struct UFortOutpostItemDefinition*> ItemDefinition; // 0x8 Size: 0x28
	    int ItemLevel; // 0x30 Size: 0x4
	    char UnknownData0[0x4]; // 0x34
	    struct FString RequiredItems; // 0x38 Size: 0x10
	    struct FString RequiredAccountItems; // 0x48 Size: 0x10

};

struct FFortOutpostFabricatorInfo
{
	public:
	    struct FString DisintegrationStartTime; // 0x0 Size: 0x10
	    int QuantumGooCompleted; // 0x10 Size: 0x4
	    int QuantumGooStillToProcess; // 0x14 Size: 0x4

};

struct FFortDepositedResources
{
	public:
	    struct FString TemplateId; // 0x0 Size: 0x10
	    int Quantity; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FPartyMemberBattlePassInfo
{
	public:
	    bool bHasPurchasedPass; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    int PassLevel; // 0x4 Size: 0x4
	    int SelfBoostXp; // 0x8 Size: 0x4
	    int FriendBoostXp; // 0xc Size: 0x4

};

struct FPartyMemberAthenaBannerInfo
{
	public:
	    struct FString BannerIconId; // 0x0 Size: 0x10
	    struct FString BannerColorId; // 0x10 Size: 0x10
	    int SeasonLevel; // 0x20 Size: 0x4
	    char UnknownData0[0x4];

};

struct FPartyMemberFrontendEmote
{
	public:
	    class UFortMontageItemDefinitionBase* EmoteItemDef; // 0x0 Size: 0x8
	    struct FString EmoteItemDefEncryptionKey; // 0x8 Size: 0x10
	    int8_t EmoteSection; // 0x18 Size: 0x1
	    char UnknownData0[0x7];

};

struct FPartyMemberCampaignHero
{
	public:
	    struct FString HeroItemInstanceId; // 0x0 Size: 0x10
	    class UFortHeroType* HeroType; // 0x10 Size: 0x8

};

struct FAthenaBatchedDamageGameplayCues_NonShared
{
	public:
	    class AActor* HitActor; // 0x0 Size: 0x8
	    class AActor* NonPlayerHitActor; // 0x8 Size: 0x8

};

struct FAthenaBatchedDamageGameplayCues_Shared
{
	public:
	    struct FVector_NetQuantize10 Location; // 0x0 Size: 0xc
	    struct FVector_NetQuantizeNormal Normal; // 0xc Size: 0xc
	    float Magnitude; // 0x18 Size: 0x4
	    bool bWeaponActivate; // 0x1c Size: 0x1
	    bool bIsFatal; // 0x1d Size: 0x1
	    bool bIsCritical; // 0x1e Size: 0x1
	    bool bIsShield; // 0x1f Size: 0x1
	    bool bIsShieldDestroyed; // 0x20 Size: 0x1
	    bool bIsBallistic; // 0x21 Size: 0x1
	    char UnknownData0[0x2]; // 0x22
	    struct FVector_NetQuantize10 NonPlayerLocation; // 0x24 Size: 0xc
	    struct FVector_NetQuantizeNormal NonPlayerNormal; // 0x30 Size: 0xc
	    float NonPlayerMagnitude; // 0x3c Size: 0x4
	    bool NonPlayerbIsFatal; // 0x40 Size: 0x1
	    bool NonPlayerbIsCritical; // 0x41 Size: 0x1
	    bool bIsValid; // 0x42 Size: 0x1
	    char UnknownData1[0x1];

};

struct FFortPawnVocalChord
{
	public:
	    class UAudioComponent* FeedbackAudioComponent; // 0x0 Size: 0x8
	    struct FFortSpokenLine ReplicatedSpokenLine; // 0x8 Size: 0x30
	    struct FFortSpokenLine PendingSpokenLine; // 0x38 Size: 0x30
	    struct FFortSpokenLine QueuedSpokenLine; // 0x68 Size: 0x30
	    struct FFortSpokenLine CurrentSpokenLine; // 0x98 Size: 0x30
	    char UnknownData0[0x10];

};

struct FAssetAttachment
{
	public:
	    FName SocketName; // 0x0 Size: 0x8
	    class USkeletalMesh* SkeletalMeshAsset; // 0x8 Size: 0x8
	    class UStaticMesh* StaticMeshAsset; // 0x10 Size: 0x8
	    bool bSkipOnDedicatedServers; // 0x18 Size: 0x1
	    char UnknownData0[0x7]; // 0x19
	    class USkeletalMeshComponentBudgeted* SkelMeshComp; // 0x20 Size: 0x8
	    class UStaticMeshComponent* StaticMeshComp; // 0x28 Size: 0x8

};

struct FCalloutEntry
{
	public:
	    struct FGameplayTag CalloutTag; // 0x0 Size: 0x8
	    struct FSlateBrush CalloutIcon; // 0x8 Size: 0x88

};

struct FBuildingHitTime
{
	public:
	    class ABuildingActor* HitBuilding; // 0x0 Size: 0x8
	    char UnknownData0[0x10];

};

struct FFortPresenceBasicInfo
{
	public:
	    int HomeBaseRating; // 0x0 Size: 0x4

};

struct FFortZoneInstanceInfo
{
	public:
	    struct FString WorldId; // 0x0 Size: 0x10
	    struct FString TheaterId; // 0x10 Size: 0x10
	    struct FString TheaterMissionId; // 0x20 Size: 0x10
	    struct FString TheaterMissionAlertId; // 0x30 Size: 0x10
	    __int64/*SoftClassProperty*/ ZoneThemeClass; // 0x40 Size: 0x28

};

struct FPetResponseFromQuestSystem
{
	public:
	    struct FDataTableRowHandle ObjectiveStatHandle; // 0x0 Size: 0x10
	    struct FGameplayTag ResponseTag; // 0x10 Size: 0x8
	    float ResponseDuration; // 0x18 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortPickupLocationData
{
	public:
	    class AFortPawn* PickupTarget; // 0x0 Size: 0x8
	    class AFortPickup* CombineTarget; // 0x8 Size: 0x8
	    class AFortPawn* ItemOwner; // 0x10 Size: 0x8
	    struct FVector_NetQuantize10 LootInitialPosition; // 0x18 Size: 0xc
	    struct FVector_NetQuantize10 LootFinalPosition; // 0x24 Size: 0xc
	    float FlyTime; // 0x30 Size: 0x4
	    struct FVector_NetQuantizeNormal StartDirection; // 0x34 Size: 0xc
	    struct FVector_NetQuantize10 FinalTossRestLocation; // 0x40 Size: 0xc
	    EFortPickupTossState TossState; // 0x4c Size: 0x1
	    bool bPlayPickupSound; // 0x4d Size: 0x1
	    char UnknownData0[0x2]; // 0x4e
	    struct FGuid PickupGuid; // 0x50 Size: 0x10

};

struct FGolfCartHandOnWheelControl
{
	public:
	    FName SocketName; // 0x0 Size: 0x8
	    struct FVector Location; // 0x8 Size: 0xc
	    struct FRotator Rotation; // 0x14 Size: 0xc
	    FName AlphaCurveName; // 0x20 Size: 0x8
	    float Alpha; // 0x28 Size: 0x4

};

struct FFortCameraModeOverride
{
	public:
	    class UFortCameraMode* OriginalClass; // 0x0 Size: 0x8
	    class UFortCameraMode* ClassOverride; // 0x8 Size: 0x8

};

struct FFortCameraInstanceEntry
{
	public:
	    class UFortCameraMode* CameraClass; // 0x0 Size: 0x8
	    class AActor* ViewTarget; // 0x8 Size: 0x8
	    class UFortCameraMode* Camera; // 0x10 Size: 0x8

};

struct FActiveFortCamera
{
	public:
	    class UFortCameraMode* Camera; // 0x0 Size: 0x8
	    class AActor* ViewTarget; // 0x8 Size: 0x8
	    float TransitionAlpha; // 0x10 Size: 0x4
	    float TransitionUpdateRate; // 0x14 Size: 0x4
	    float BlendWeight; // 0x18 Size: 0x4
	    char UnknownData0[0x4];

};

struct FCreativeToolPersistentData
{
	public:
	    char GridSnapIndex; // 0x0 Size: 0x1
	    char RotationAxisIndex; // 0x1 Size: 0x1
	    bool bShouldUsePrecisionGridSnapping; // 0x2 Size: 0x1
	    bool bAllowGravityOnPlace; // 0x3 Size: 0x1
	    bool bShouldDestroyPropsWhenPlacing; // 0x4 Size: 0x1
	    bool bIgnoreLineOfSightBlockers; // 0x5 Size: 0x1

};

struct FVoiceChatUsageAnalytics
{
	public:
	    char UnknownData0[0x18];

};

struct FCraftingQueueInfo
{
	public:
	    char UnknownData0[0xc];

};

struct FBuildingEditAnalyticEvent
{
	public:
	    char BuildingType; // 0x0 Size: 0x1
	    char ResourceType; // 0x1 Size: 0x1

};

struct FCreativePlotSessionData
{
	public:
	    int TimesInventoryOpened; // 0x8 Size: 0x4
	    int TimesIslandMenuOpened; // 0xc Size: 0x4
	    int TimesGameStarted; // 0x10 Size: 0x4

};

struct FCreativeIslandData
{
	public:
	    struct FText IslandName; // 0x0 Size: 0x18
	    struct FString McpId; // 0x18 Size: 0x10

};

struct FPlayerStateEncryptionKey
{
	public:
	    TArray<char> Key; // 0x0 Size: 0x10

};

struct FFortInputActionGroupContext
{
	public:
	    FName ActionName; // 0x0 Size: 0x8
	    EFortInputActionGroup InputActionGroup; // 0x8 Size: 0x1
	    char UnknownData0[0x3];

};

struct FFortAxisSmoothing
{
	public:
	    float ZeroTime; // 0x0 Size: 0x4
	    struct FVector AverageValue; // 0x4 Size: 0xc
	    int Samples; // 0x10 Size: 0x4
	    float TotalSampleTime; // 0x14 Size: 0x4

};

struct FFortInputActionKeyAlias
{
	public:
	    FName ActionName; // 0x0 Size: 0x8
	    struct FKey KeyAlias; // 0x8 Size: 0x18
	    EFortInputActionType InputActionType; // 0x20 Size: 0x1
	    char UnknownData0[0x7];

};

struct FMorphValuePair
{
	public:
	    FName MorphName; // 0x0 Size: 0x8
	    float MorphValue; // 0x8 Size: 0x4

};

struct FPlayerMarkerData
{
	public:
	    class AFortPlayerControllerAthena* Owner; // 0x0 Size: 0x8
	    class AFortPlayerStateAthena* PlayerState; // 0x8 Size: 0x8
	    struct FLinearColor Color; // 0x10 Size: 0x10

};

struct FFortZiplineSessionTelemetryInfo
{
	public:
	    char UnknownData0[0x10];

};

struct FFortBallooningSessionTelemetryInfo
{
	public:
	    char UnknownData0[0x10];

};

struct FFortFootstepBankOverrideData
{
	public:
	    char UnknownData0[0xc];

};

struct FFortAnimBPOverrideData
{
	public:
	    char UnknownData0[0x10];

};

struct FFortCachedWeaponOverheatData
{
	public:
	    float TimeWeaponWasUnequipped; // 0x0 Size: 0x4
	    float OverheatValueAtUneqip; // 0x4 Size: 0x4
	    float OverheatValue; // 0x8 Size: 0x4
	    char UnknownData0[0x4]; // 0xc
	    float TimeOverheatedBegan; // 0x10 Size: 0x4
	    float TimeHeatWasLastAdded; // 0x14 Size: 0x4

};

struct FFortRedeployGliderTelemetryData
{
	public:
	    char UnknownData0[0x20];

};

struct FSlipperySlopeParams
{
	public:
	    struct FScalableFloat SlopeForceAcceleration; // 0x0 Size: 0x20
	    struct FScalableFloat MaxLateralSpeed; // 0x20 Size: 0x20
	    struct FScalableFloat MaxLateralSpeedMultiplierInWater; // 0x40 Size: 0x20
	    struct FScalableFloat BrakingDecelerationInWater; // 0x60 Size: 0x20
	    struct FScalableFloat MaxVerticalLaunchSpeed; // 0x80 Size: 0x20
	    struct FScalableFloat SlopeLandingForceScalar; // 0xa0 Size: 0x20
	    struct FScalableFloat SlopeLandingMaxHorizontalForce; // 0xc0 Size: 0x20
	    struct FScalableFloat SlopeLaunchMinRequiredSpeed; // 0xe0 Size: 0x20
	    struct FScalableFloat SlopeLaunchMinRequiredAngleChange; // 0x100 Size: 0x20
	    struct FScalableFloat SlopeLaunchVerticalVelocityBoost; // 0x120 Size: 0x20
	    struct FScalableFloat SlopeLaunchVerticalVelocityBoostMultiplierJumping; // 0x140 Size: 0x20

};

struct FVortexParams
{
	public:
	    float GravityFloorAltitude; // 0x0 Size: 0x4
	    float GravityFloorWidth; // 0x4 Size: 0x4
	    float GravityFloorGravityScalar; // 0x8 Size: 0x4
	    float GravityFloorTerminalVelocity; // 0xc Size: 0x4

};

struct FZiplinePawnState
{
	public:
	    class AFortAthenaZipline* Zipline; // 0x0 Size: 0x8
	    bool bIsZiplining; // 0x8 Size: 0x1
	    bool bJumped; // 0x9 Size: 0x1
	    char UnknownData0[0x2]; // 0xa
	    int AuthoritativeValue; // 0xc Size: 0x4
	    struct FVector SocketOffset; // 0x10 Size: 0xc
	    float TimeZipliningBegan; // 0x1c Size: 0x4
	    float TimeZipliningEndedFromJump; // 0x20 Size: 0x4
	    char UnknownData1[0x4];

};

struct FVehiclePawnState
{
	public:
	    class AFortAthenaVehicle* Vehicle; // 0x0 Size: 0x8
	    float VehicleApexZ; // 0x8 Size: 0x4
	    char SeatIndex; // 0xc Size: 0x1
	    char ExitSocketIndex; // 0xd Size: 0x1
	    bool bOverrideVehicleExit; // 0xe Size: 0x1
	    char UnknownData0[0x1]; // 0xf
	    struct FVector SeatTransitionVector; // 0x10 Size: 0xc
	    float EntryTime; // 0x1c Size: 0x4

};

struct FRepFortMeshAttachment
{
	public:
	    class USkeletalMesh* SkeletalMesh; // 0x0 Size: 0x8
	    class UAnimBlueprint* AnimBP; // 0x8 Size: 0x8

};

struct FFortPlayerPawnStats : public FFortPawnStats
{
	public:
	    float MaxJumpTime; // 0xa8 Size: 0x4
	    float MaxStamina; // 0xac Size: 0x4
	    float StaminaRegenRate; // 0xb0 Size: 0x4
	    float StaminaRegenDelay; // 0xb4 Size: 0x4
	    float SprintingStaminaExpenditureRate; // 0xb8 Size: 0x4
	    FName PersonalVehicleFallingDamageTableRow; // 0xbc Size: 0x8
	    char UnknownData0[0x4];

};

struct FFortPlayerAthenaAttributeReplicationProxy
{
	public:
	    float WalkSpeed; // 0x0 Size: 0x4
	    float RunSpeed; // 0x4 Size: 0x4
	    float SprintSpeed; // 0x8 Size: 0x4
	    float FlySpeed; // 0xc Size: 0x4
	    float CrouchedRunSpeed; // 0x10 Size: 0x4
	    float CrouchedSprintSpeed; // 0x14 Size: 0x4

};

struct FSharedRepMovement
{
	public:
	    struct FRepMovement RepMovement; // 0x0 Size: 0x34
	    float RepTimeStamp; // 0x34 Size: 0x4
	    uint32_t RemoteViewData32; // 0x38 Size: 0x4
	    __int64/*UInt16Property*/ AccelerationPack; // 0x3c Size: 0x2
	    int8_t AccelerationZPack; // 0x3e Size: 0x1
	    char RepMovementMode; // 0x3f Size: 0x1
	    char JumpFlashCountPacked; // 0x40 Size: 0x1
	    char LandingFlashCountPacked; // 0x41 Size: 0x1
	    char CurrentMovementStyle; // 0x42 Size: 0x1
	    bool bProxyIsJumpForceApplied; // 0x43 Size: 0x1
	    bool bIsCrouched; // 0x44 Size: 0x1
	    bool bIsSkydiving; // 0x45 Size: 0x1
	    bool bIsParachuteOpen; // 0x46 Size: 0x1
	    bool bIsSlopeSliding; // 0x47 Size: 0x1
	    bool bIsProxySimulationTimedOut; // 0x48 Size: 0x1
	    bool bIsTargeting; // 0x49 Size: 0x1
	    char UnknownData0[0x2];

};

struct FPetStimuliRepData
{
	public:
	    struct FGameplayTag Stimuli; // 0x0 Size: 0x8
	    float GameTimeEnd; // 0x8 Size: 0x4

};

struct FCustomCharacterParts
{
	public:
	    char WasReplicatedFlags; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class UCustomCharacterPart* Parts; // 0x8 Size: 0x8
	    bool bReplicationFailed; // 0x38 Size: 0x1
	    char UnknownData1[0x2f];

};

struct FFortPlayerAttributeSets
{
	public:
	    class UFortRegenHealthSet* HealthSet; // 0x0 Size: 0x8
	    class UFortControlResistanceSet* ControlResistanceSet; // 0x8 Size: 0x8
	    class UFortDamageSet* DamageSet; // 0x10 Size: 0x8
	    class UFortMovementSet* MovementSet; // 0x18 Size: 0x8
	    class UFortAdvancedMovementSet* AdvancedMovementSet; // 0x20 Size: 0x8
	    class UFortConstructionSet* ConstructionSet; // 0x28 Size: 0x8
	    class UFortPlayerAttrSet* PlayerAttrSet; // 0x30 Size: 0x8
	    class UFortCharacterAttrSet* CharacterAttrSet; // 0x38 Size: 0x8
	    class UFortWeaponAttrSet* WeaponAttrSet; // 0x40 Size: 0x8
	    class UFortHomebaseSet* HomebaseSet; // 0x48 Size: 0x8

};

struct FFortRespawnData
{
	public:
	    bool bRespawnDataAvailable; // 0x0 Size: 0x1
	    bool bClientIsReady; // 0x1 Size: 0x1
	    bool bServerIsReady; // 0x2 Size: 0x1
	    char UnknownData0[0x1]; // 0x3
	    struct FVector RespawnLocation; // 0x4 Size: 0xc
	    struct FRotator RespawnRotation; // 0x10 Size: 0xc
	    float RespawnCameraDistance; // 0x1c Size: 0x4

};

struct FFortVehicleUseTelemetryInfo
{
	public:
	    char UnknownData0[0x20];

};

struct FPlayerBannerInfo
{
	public:
	    struct FString IconId; // 0x0 Size: 0x10
	    struct FString ColorId; // 0x10 Size: 0x10
	    int Level; // 0x20 Size: 0x4
	    char UnknownData0[0x4];

};

struct FDeathInfo
{
	public:
	    class AActor* FinisherOrDowner; // 0x0 Size: 0x8
	    bool bDBNO; // 0x8 Size: 0x1
	    EDeathCause DeathCause; // 0x9 Size: 0x1
	    char UnknownData0[0x2]; // 0xa
	    float Distance; // 0xc Size: 0x4
	    struct FVector DeathLocation; // 0x10 Size: 0xc
	    bool bInitialized; // 0x1c Size: 0x1
	    char UnknownData1[0x3]; // 0x1d
	    int DeathCircumstance; // 0x20 Size: 0x4
	    char UnknownData2[0x4];

};

struct FFortSpectatorZoneItem : public FFastArraySerializerItem
{
	public:
	    char UnknownData0[0x4];
	    class AFortPlayerStateZone* PlayerState; // 0x10 Size: 0x8

};

struct FSimulatedAttributeEntry
{
	public:
	    struct FGameplayAttribute Attribute; // 0x0 Size: 0x20
	    float CurrentValue; // 0x20 Size: 0x4
	    char UnknownData0[0x4];

};

struct FAccumulatedItemEntry
{
	public:
	    class UFortWorldItemDefinition* ItemDefinition; // 0x0 Size: 0x8
	    int Quantity; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FVehicleTrickLocalAxisRotInfo
{
	public:
	    float Angle; // 0x0 Size: 0x4
	    int AccumulatedHalfSpinCount; // 0x4 Size: 0x4
	    float AccumulatedAngle; // 0x8 Size: 0x4
	    float AngleAtFurthestExtent; // 0xc Size: 0x4
	    int TrickOrder; // 0x10 Size: 0x4
	    int Points; // 0x14 Size: 0x4

};

struct FQueryName
{
	public:
	    FName QueryName; // 0x0 Size: 0x8

};

struct FNamedWeightTableRow : public FTableRowBase
{
	public:
	    struct FQueryName QueryName; // 0x8 Size: 0x8
	    float Weight; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FRatingExpansion
{
	public:
	    int Priority; // 0x0 Size: 0x4
	    int RatingDelta; // 0x4 Size: 0x4

};

struct FPlaylistUIExtension
{
	public:
	    EPlaylistUIExtensionSlot Slot; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    __int64/*SoftClassProperty*/ WidgetClass; // 0x8 Size: 0x28

};

struct FSupplyDropSubPhaseModifier
{
	public:
	    EAthenaGamePhase GamePhase; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    int SubPhaseIndex; // 0x4 Size: 0x4
	    float SpawnInPreviousZonePercentChance; // 0x8 Size: 0x4

};

struct FPlaylistFrontEndData
{
	public:
	    class UFortPlaylistAthena* PlaylistData; // 0x0 Size: 0x8
	    bool bIsDisabled; // 0x8 Size: 0x1
	    bool bDisplayAsDefault; // 0x9 Size: 0x1
	    EPlaylistAdvertisementType AdvertiseType; // 0xa Size: 0x1
	    bool bDisplayAsLimitedTime; // 0xb Size: 0x1
	    char UnknownData0[0x4];

};

struct FPlaylistOptionValue
{
	public:
	    struct FText DisplayName; // 0x0 Size: 0x18
	    struct FString OptionValueName; // 0x18 Size: 0x10

};

struct FPlaylistOptionFloatValue : public FPlaylistOptionValue
{
	public:
	    struct FScalableFloat Value; // 0x28 Size: 0x20

};

struct FPlaylistOptionIntValue : public FPlaylistOptionValue
{
	public:
	    int Value; // 0x28 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortPlaysetStreamingData
{
	public:
	    FName PackageName; // 0x0 Size: 0x8
	    FName UniquePackageName; // 0x8 Size: 0x8
	    struct FVector Location; // 0x10 Size: 0xc
	    struct FRotator Rotation; // 0x1c Size: 0xc
	    bool bValid; // 0x28 Size: 0x1
	    char UnknownData0[0x3];

};

struct FFortPOIAmbientAudioLoop
{
	public:
	    class USoundBase* LoopingSound; // 0x0 Size: 0x8
	    float CrossfadeTime; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortPoiGridInfo
{
	public:
	    struct FVector2D WorldGridStart; // 0x0 Size: 0x8
	    struct FVector2D WorldGridEnd; // 0x8 Size: 0x8
	    struct FVector2D WorldGridSpacing; // 0x10 Size: 0x8
	    int GridCountX; // 0x18 Size: 0x4
	    int GridCountY; // 0x1c Size: 0x4
	    struct FVector2D WorldGridTotalSize; // 0x20 Size: 0x8

};

struct FFortPoiVolumeGridCell
{
	public:
	    char UnknownData0[0x10];

};

struct FProfileGoCommand
{
	public:
	    struct FString Group; // 0x0 Size: 0x10
	    struct FString Command; // 0x10 Size: 0x10
	    float Wait; // 0x20 Size: 0x4
	    char UnknownData0[0x4]; // 0x24
	    struct FString Log; // 0x28 Size: 0x10

};

struct FProfileGoCollection
{
	public:
	    struct FString Name; // 0x0 Size: 0x10
	    struct FString Scenarios; // 0x10 Size: 0x10

};

struct FProfileGoScenario
{
	public:
	    struct FString Name; // 0x0 Size: 0x10
	    struct FVector Position; // 0x10 Size: 0xc
	    struct FRotator Orientation; // 0x1c Size: 0xc
	    struct FString OnBegin; // 0x28 Size: 0x10
	    struct FString OnEnd; // 0x38 Size: 0x10
	    bool AutoGenerated; // 0x48 Size: 0x1
	    bool UseSetupCheats; // 0x49 Size: 0x1
	    char UnknownData0[0x6];

};

struct FTeamStrategicBuildingHandle
{
	public:
	    int Handle; // 0x0 Size: 0x4

};

struct FFortPointOnCurveRange
{
	public:
	    float MinPercentage; // 0x0 Size: 0x4
	    float MaxPercentage; // 0x4 Size: 0x4

};

struct FGoalDistanceData
{
	public:
	    bool bIgnoreScreeningDistance; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FAIDataProviderFloatValue ScreeningTestMaxDistance; // 0x8 Size: 0x30
	    struct TSoftObjectPtr<struct UCurveFloat*> TestScoreCurve; // 0x38 Size: 0x28
	    struct FAIDataProviderFloatValue CurveDistanceScale; // 0x60 Size: 0x30

};

struct FFortQuestAchievementTableRow : public FTableRowBase
{
	public:
	    EFortQuestState QuestState; // 0x8 Size: 0x1
	    char UnknownData0[0x3]; // 0x9
	    int XboxAchievementID; // 0xc Size: 0x4
	    int PS4TrophyID; // 0x10 Size: 0x4
	    char UnknownData1[0x4];

};

struct FFortQuestRewardTableRow : public FTableRowBase
{
	public:
	    struct FString QuestTemplateId; // 0x8 Size: 0x10
	    FName TemplateId; // 0x18 Size: 0x8
	    int Quantity; // 0x20 Size: 0x4
	    bool Hidden; // 0x24 Size: 0x1
	    bool Selectable; // 0x25 Size: 0x1
	    char UnknownData0[0x2];

};

struct FFortCategoryTableRow : public FTableRowBase
{
	public:
	    struct FText Name; // 0x8 Size: 0x18
	    int SortPriority; // 0x20 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortQuestMapDataEntry
{
	public:
	    class UDataTable* QuestData; // 0x0 Size: 0x8
	    class UDataTable* CosmeticData; // 0x8 Size: 0x8

};

struct FFortEventQuestMapDataEntry : public FFortQuestMapDataEntry
{
	public:
	    struct FText EventCalloutTitle; // 0x10 Size: 0x18
	    struct FText EventCalloutDescription; // 0x28 Size: 0x18

};

struct FFortQuestMapNode
{
	public:
	    class UFortQuestItemDefinition* QuestItemDefinition; // 0x0 Size: 0x8
	    EFortQuestMapNodeType NodeType; // 0x8 Size: 0x1
	    EFortQuestMapNodeLabelPosition LabelPosition; // 0x9 Size: 0x1
	    bool UseHighContrastMode; // 0xa Size: 0x1
	    char UnknownData0[0x5];

};

struct FFortChallengeBundleInfoLockedReason
{
	public:
	    EFortChallengeBundleInfoLockedReasonCode ReasonCode; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    struct FString EventName; // 0x8 Size: 0x10
	    int RequiredTier; // 0x18 Size: 0x4
	    char UnknownData1[0x4]; // 0x1c
	    struct FTimespan UnlockTimespanAfterStart; // 0x20 Size: 0x8

};

struct FFortQuestManagerAttributes
{
	public:
	    struct FDateTime DailyLoginInterval; // 0x0 Size: 0x8
	    int DailyQuestRerolls; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FQuickBarAndSlot
{
	public:
	    EFortQuickBars QuickBarType; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    int QuickBarSlot; // 0x4 Size: 0x4

};

struct FFortRarityItemData
{
	public:
	    struct FText Name; // 0x0 Size: 0x18
	    struct FLinearColor Color1; // 0x18 Size: 0x10
	    struct FLinearColor Color2; // 0x28 Size: 0x10
	    struct FLinearColor Color3; // 0x38 Size: 0x10
	    struct FLinearColor Color4; // 0x48 Size: 0x10
	    struct FLinearColor Color5; // 0x58 Size: 0x10
	    float Radius; // 0x68 Size: 0x4
	    float Falloff; // 0x6c Size: 0x4
	    float Brightness; // 0x70 Size: 0x4
	    float Roughness; // 0x74 Size: 0x4
	    float Glow; // 0x78 Size: 0x4
	    char UnknownData0[0x4];

};

struct FReflectedEngineVersion
{
	public:
	    int Major; // 0x0 Size: 0x4
	    int Minor; // 0x4 Size: 0x4
	    int Patch; // 0x8 Size: 0x4
	    int Changelist; // 0xc Size: 0x4
	    struct FString Branch; // 0x10 Size: 0x10

};

struct FFortRecordVersion
{
	public:
	    int DataVersion; // 0x0 Size: 0x4
	    int PackageFileVersion; // 0x4 Size: 0x4
	    struct FReflectedEngineVersion EngineVersion; // 0x8 Size: 0x20
	    char UnknownData0[0x18];

};

struct FFortReleaseVersion
{
	public:
	    FName VersionName; // 0x0 Size: 0x8

};

struct FFortReplayPlaybackState
{
	public:
	    float StartTime; // 0x0 Size: 0x4
	    float EndTime; // 0x4 Size: 0x4
	    float TimeNow; // 0x8 Size: 0x4
	    bool bIsPaused; // 0xc Size: 0x1
	    char UnknownData0[0x3]; // 0xd
	    float PlaybackSpeedMultiplier; // 0x10 Size: 0x4
	    bool bTimelineHasInputFocus; // 0x14 Size: 0x1
	    EHudVisibilityState HUDVisibility; // 0x15 Size: 0x1
	    bool bLevelStreaming; // 0x16 Size: 0x1
	    bool bHasRelevancyZone; // 0x17 Size: 0x1

};

struct FFortReplayEvent
{
	public:
	    char UnknownData0[0x50];

};

struct FReplayEventInfo
{
	public:
	    struct FTransform EventLocation; // 0x10 Size: 0x30
	    struct FString Victim; // 0x40 Size: 0x10
	    struct FString Instigator; // 0x50 Size: 0x10
	    EDeathCause DeathCause; // 0x60 Size: 0x1
	    bool bDBNO; // 0x61 Size: 0x1
	    EFortReplayEventType EventType; // 0x62 Size: 0x1
	    char UnknownData0[0x1]; // 0x63
	    int VersionNumber; // 0x64 Size: 0x4
	    char UnknownData1[0x8];

};

struct FFortRespawnDataRow : public FTableRowBase
{
	public:
	    struct FLinearColor FadeColor; // 0x8 Size: 0x10
	    float FadeOutTime; // 0x18 Size: 0x4
	    float FadeInTime; // 0x1c Size: 0x4
	    float WaitTime; // 0x20 Size: 0x4
	    float SafetyTime; // 0x24 Size: 0x4

};

struct FRuntimeOptionPlaygroundKnobOverride
{
	public:
	    struct FString KnobID; // 0x0 Size: 0x10
	    bool bEnabled; // 0x10 Size: 0x1
	    char UnknownData0[0x7]; // 0x11
	    struct FString OverrideDefault; // 0x18 Size: 0x10

};

struct FFortSafeZoneVolumeDefinition
{
	public:
	    class AVolume* Volume; // 0x0 Size: 0x8
	    struct FScalableFloat RejectionChance; // 0x8 Size: 0x20

};

struct FFortSafeZoneDefinition
{
	public:
	    struct FScalableFloat Radius; // 0x0 Size: 0x20
	    struct FScalableFloat ForceDistanceMin; // 0x20 Size: 0x20
	    struct FScalableFloat ForceDistanceMax; // 0x40 Size: 0x20
	    struct FScalableFloat RejectRadius; // 0x60 Size: 0x20
	    struct FScalableFloat RejectOuterDistance; // 0x80 Size: 0x20
	    struct FScalableFloat WaitTime; // 0xa0 Size: 0x20
	    struct FScalableFloat ShrinkTime; // 0xc0 Size: 0x20
	    struct FScalableFloat MegaStormGridCellThickness; // 0xe0 Size: 0x20
	    struct FScalableFloat PlayerCap; // 0x100 Size: 0x20
	    char UnknownData0[0x28];

};

struct FFortDestroyedActorRecord
{
	public:
	    struct FGuid ActorGuid; // 0x0 Size: 0x10
	    class ABuildingActor* ActorClass; // 0x10 Size: 0x8
	    char UnknownData0[0x8]; // 0x18
	    struct FTransform ActorTransform; // 0x20 Size: 0x30

};

struct FFortScoreStylingInfo
{
	public:
	    struct FText Name; // 0x0 Size: 0x18
	    struct FFortMultiSizeBrush Icon; // 0x18 Size: 0x330
	    struct FLinearColor Color; // 0x348 Size: 0x10

};

struct FFortScriptedActionParams
{
	public:
	    class AFortPlayerController* Player; // 0x0 Size: 0x8
	    EFortScriptedActionSource SourceType; // 0x8 Size: 0x1
	    char UnknownData0[0x7]; // 0x9
	    class UFortItem* SourceItem; // 0x10 Size: 0x8
	    struct FDataTableRowHandle SourceData; // 0x18 Size: 0x10
	    FName SourceName; // 0x28 Size: 0x8

};

struct FFortAvailableScriptedAction
{
	public:
	    struct FFortScriptedActionParams Params; // 0x0 Size: 0x30
	    class AFortScriptedAction* ActionDefaults; // 0x30 Size: 0x8

};

struct FFortSearchPassState
{
	public:
	    int BestSessionIdx; // 0x0 Size: 0x4
	    bool bWasCanceled; // 0x4 Size: 0x1
	    EFortSessionHelperJoinResult FailureType; // 0x5 Size: 0x1
	    char MatchmakingState; // 0x6 Size: 0x1
	    char LastBeaconResponse; // 0x7 Size: 0x1
	    char UnknownData0[0x10];

};

struct FFortSearchPassParams
{
	public:
	    int ControllerId; // 0x0 Size: 0x4
	    FName SessionName; // 0x4 Size: 0x8
	    char UnknownData0[0x4]; // 0xc
	    struct FString BestDatacenterId; // 0x10 Size: 0x10
	    int MaxProcessedSearchResults; // 0x20 Size: 0x4
	    char UnknownData1[0x4];

};

struct FMMAttemptState
{
	public:
	    int BestSessionIdx; // 0x0 Size: 0x4
	    int NumSearchResults; // 0x4 Size: 0x4
	    char State; // 0x8 Size: 0x1
	    char LastBeaconResponse; // 0x9 Size: 0x1
	    char UnknownData0[0x2];

};

struct FFortMatchmakingEventsState
{
	public:
	    __int64/*MapProperty*/ Region; // 0x0 Size: 0x50

};

struct FFortMatchmakingRegionState
{
	public:
	    __int64/*SetProperty*/ EventFlagsForcedOn; // 0x0 Size: 0x50
	    __int64/*SetProperty*/ EventFlagsForcedOff; // 0x50 Size: 0x50

};

struct FFortRotationalContentEventsState
{
	public:
	    __int64/*SetProperty*/ ActiveStorefronts; // 0x0 Size: 0x50
	    __int64/*SetProperty*/ ActiveEventFlags; // 0x50 Size: 0x50
	    __int64/*MapProperty*/ EventNamedWeights; // 0xa0 Size: 0x50
	    __int64/*SetProperty*/ ExpirationTimes; // 0xf0 Size: 0x50

};

struct FFortClientEventsState : public FFortRotationalContentEventsState
{
	public:
	    int SeasonNumber; // 0x140 Size: 0x4
	    char UnknownData0[0x4]; // 0x144
	    struct FString SeasonTemplateId; // 0x148 Size: 0x10
	    float MatchXpBonusPoints; // 0x158 Size: 0x4
	    char UnknownData1[0x4]; // 0x15c
	    struct FDateTime SeasonBegin; // 0x160 Size: 0x8
	    struct FDateTime SeasonEnd; // 0x168 Size: 0x8
	    struct FDateTime SeasonDisplayedEnd; // 0x170 Size: 0x8
	    struct FDateTime WeeklyStoreEnd; // 0x178 Size: 0x8
	    struct FDateTime StwEventStoreEnd; // 0x180 Size: 0x8
	    struct FDateTime StwWeeklyStoreEnd; // 0x188 Size: 0x8

};

struct FFortQuestDrivenMission : public FFortGlobalMission
{
	public:
	    class UFortQuestItemDefinition* RequiredQuest; // 0x178 Size: 0x8

};

struct FFortChaseCameraHelper
{
	public:
	    struct FTransform PivotToViewTarget; // 0x0 Size: 0x30
	    struct FTransform PivotToViewTarget_Crouching; // 0x30 Size: 0x30
	    struct FTransform MinCameraToPivot; // 0x60 Size: 0x30
	    struct FTransform MaxCameraToPivot; // 0x90 Size: 0x30
	    char UnknownData0[0x8]; // 0xc0
	    float CameraToPivotAlphaInterpSpeed; // 0xc8 Size: 0x4
	    float CameraCollisionSphereRadius; // 0xcc Size: 0x4
	    float PivotLocationInterpSpeed; // 0xd0 Size: 0x4
	    float PivotRotationInterpSpeed; // 0xd4 Size: 0x4
	    bool bAutoFollow; // 0xd8 Size: 0x1
	    bool bLazyAutoFollow; // 0xd8 Size: 0x1
	    char UnknownData1[0x2]; // 0xda
	    float CameraTruckRate; // 0xdc Size: 0x4
	    float AutoFollowPitch; // 0xe0 Size: 0x4
	    float LazyAutoFollowPitchMin; // 0xe4 Size: 0x4
	    float LazyAutoFollowPitchMax; // 0xe8 Size: 0x4
	    char UnknownData2[0x64];

};

struct FSphericalDriveParams
{
	public:
	    float Radius; // 0x0 Size: 0x4
	    float LowSpeedAccelerationForce; // 0x4 Size: 0x4
	    float HighSpeedAccelerationForce; // 0x8 Size: 0x4
	    float MaxBrakingForce; // 0xc Size: 0x4
	    float MaxSpeed; // 0x10 Size: 0x4
	    float DampingCoefficient; // 0x14 Size: 0x4
	    float Restitution; // 0x18 Size: 0x4
	    float ContactRepulsionForce; // 0x1c Size: 0x4
	    float ContactThreshold; // 0x20 Size: 0x4

};

struct FFortLinearSpline
{
	public:
	    char UnknownData0[0x1];

};

struct FFortSplineBase
{
	public:
	    float StartTime; // 0x8 Size: 0x4
	    float Duration; // 0xc Size: 0x4

};

struct FFortSprayDecalRepPayload
{
	public:
	    class UAthenaSprayItemDefinition* SprayAsset; // 0x0 Size: 0x8
	    FName BannerName; // 0x8 Size: 0x8
	    FName BannerColor; // 0x10 Size: 0x8
	    int SavedStatValue; // 0x18 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortEventConditional
{
	public:
	    char ConditionalType; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    FName StatToCompare; // 0x4 Size: 0x8
	    EStatRecordingPeriod RelevantPeriod; // 0xc Size: 0x1
	    char ComparisonType; // 0xd Size: 0x1
	    char UnknownData1[0x2]; // 0xe
	    int Value; // 0x10 Size: 0x4
	    char UnknownData2[0x4]; // 0x14
	    class UFortSchematicItemDefinition* CraftingItem; // 0x18 Size: 0x8
	    bool bCanCraft; // 0x20 Size: 0x1
	    char UnknownData3[0x7]; // 0x21
	    class UStat* Stat; // 0x28 Size: 0x8
	    class AFortPlayerController* FPC; // 0x30 Size: 0x8

};

struct FTransformableNavLinkClass
{
	public:
	    struct FVector Translation; // 0x0 Size: 0xc
	    struct FRotator Rotation; // 0xc Size: 0xc
	    class UNavLinkDefinition* NavigationLinksClass; // 0x18 Size: 0x8

};

struct FFortSupplyDropSubPhaseData
{
	public:
	    struct FScalableFloat SupplyDropMinCount; // 0x0 Size: 0x20
	    struct FScalableFloat SupplyDropMaxCount; // 0x20 Size: 0x20
	    struct FScalableFloat SupplyDropCap; // 0x40 Size: 0x20

};

struct FFortSurfaceTypeToSurfaceTypeTag
{
	public:
	    char FootSurfaceType; // 0x0 Size: 0x1
	    char SurfaceType; // 0x1 Size: 0x1
	    char UnknownData0[0x2]; // 0x2
	    struct FGameplayTag SurfaceTypeTag; // 0x4 Size: 0x8

};

struct FFortSurvivorNameData : public FTableRowBase
{
	public:
	    struct FText Name; // 0x8 Size: 0x18

};

struct FFortTagUIData
{
	public:
	    struct FGameplayTag Tag; // 0x0 Size: 0x8
	    struct FFortMultiSizeBrush Icon; // 0x8 Size: 0x330
	    struct FText DisplayName; // 0x338 Size: 0x18
	    struct FText Description; // 0x350 Size: 0x18

};

struct FFortFinderProperty
{
	public:
	    class UProperty* Property; // 0x0 Size: 0x8
	    struct FString Value; // 0x8 Size: 0x10

};

struct FTeamSpottedActorInfo : public FFastArraySerializerItem
{
	public:
	    char UnknownData0[0x4];
	    class AFortPlayerController* Spotter; // 0x10 Size: 0x8
	    class AActor* SpottedActor; // 0x18 Size: 0x8

};

struct FTeamStrategicBuildingEntry : public FFastArraySerializerItem
{
	public:
	    struct FTeamStrategicBuildingHandle StrategicBuildingHandle; // 0xc Size: 0x4
	    class AStrategicBuildingActor* StrategicBuilding; // 0x10 Size: 0x8

};

struct FLatentRepPlayerData : public FFastArraySerializerItem
{
	public:
	    char UnknownData0[0x4];
	    class AFortPlayerStateAthena* PlayerState; // 0x10 Size: 0x8
	    float LastPawnNotRelevantTime; // 0x18 Size: 0x4
	    bool bPawnIsRelevant; // 0x1c Size: 0x1
	    bool bWasPawnRelevantLastUpdate; // 0x1d Size: 0x1
	    char UnknownData1[0x2]; // 0x1e
	    struct FVector CurrentLocation; // 0x20 Size: 0xc
	    float CurrentYaw; // 0x2c Size: 0x4
	    float LastLocationReplicationTime; // 0x30 Size: 0x4
	    float PrevLocationReplicatedTime; // 0x34 Size: 0x4
	    struct FVector_NetQuantize100 LastRepLocation; // 0x38 Size: 0xc
	    struct FVector_NetQuantize100 PrevRepLocation; // 0x44 Size: 0xc
	    struct FVector LerpStartLocation; // 0x50 Size: 0xc
	    float LastYawReplicationTime; // 0x5c Size: 0x4
	    float PrevYawReplicatedTime; // 0x60 Size: 0x4
	    float LastRepYaw; // 0x64 Size: 0x4
	    float PrevRepYaw; // 0x68 Size: 0x4
	    float LerpStartYaw; // 0x6c Size: 0x4
	    EFortPawnState PawnStateMask; // 0x70 Size: 0x1
	    EFortPawnState CurrPawnStateMask; // 0x71 Size: 0x1
	    char UnknownData2[0x6];

};

struct FSmokeTestResult
{
	public:
	    struct FString TestStep; // 0x0 Size: 0x10
	    struct FString TestSummary; // 0x10 Size: 0x10
	    bool bWasExecuted; // 0x20 Size: 0x1
	    bool bPassed; // 0x21 Size: 0x1
	    char UnknownData0[0x6]; // 0x22
	    struct FString ResultMessage; // 0x28 Size: 0x10

};

struct FFortEditorTheaterMapRegionColor
{
	public:
	    class UFortRegionInfo* Region; // 0x0 Size: 0x8
	    struct FLinearColor RegionColor; // 0x8 Size: 0x10

};

struct FFortMissionAlertAvailableData
{
	public:
	    FName MissionAlertCategoryName; // 0x0 Size: 0x8
	    int NumMissionAlertsAvailable; // 0x8 Size: 0x4

};

struct FFortWindImpulseHandle
{
	public:
	    int UID; // 0x0 Size: 0x4

};

struct FThreatLocationInfo : public FFastArraySerializerItem
{
	public:
	    struct FVector CloudLocation; // 0xc Size: 0xc
	    struct FBox ThreatVolume; // 0x18 Size: 0x1c
	    char UnknownData0[0x4]; // 0x34
	    class AFortThreatVisualsManager* ThreatVisualsManager; // 0x38 Size: 0x8
	    TWeakObjectPtr<AThreatCloud*> CloudActor; // 0x40 Size: 0x8
	    bool bThreatActivated; // 0x49 Size: 0x1
	    char UnknownData1[0x1]; // 0x49
	    EFortThreatDeactivationType DeactivationType; // 0x4a Size: 0x1
	    char UnknownData2[0x15];

};

struct FThreatGridIndex
{
	public:
	    int X; // 0x0 Size: 0x4
	    int Y; // 0x4 Size: 0x4

};

struct FTieredCollectionProgressionDataBase
{
	public:
	    ECollectionSelectionMethod SelectionMethod; // 0x0 Size: 0x1

};

struct FDifficultyRowProgression
{
	public:
	    FName DifficultyRowName; // 0x0 Size: 0x8
	    struct FScalableFloat AdditiveDifficultyMod; // 0x8 Size: 0x20

};

struct FTimeOfDayEditorViewSettings
{
	public:
	    char UnknownData0[0x1];

};

struct FExponentialHeightFogValues
{
	public:
	    float FogDensity; // 0x0 Size: 0x4
	    float FogHeightFalloff; // 0x4 Size: 0x4
	    float FogMaxOpacity; // 0x8 Size: 0x4
	    float StartDistance; // 0xc Size: 0x4
	    float DirectionalInscatteringExponent; // 0x10 Size: 0x4
	    float DirectionalInscatteringStartDistance; // 0x14 Size: 0x4
	    struct FLinearColor DirectionalInscatteringColor; // 0x18 Size: 0x10
	    struct FLinearColor FogInscatteringColor; // 0x28 Size: 0x10
	    float VolumetricFogScatteringDistribution; // 0x38 Size: 0x4
	    float VolumetricFogExtinctionScale; // 0x3c Size: 0x4
	    float VolumetricFogDistance; // 0x40 Size: 0x4
	    struct FExponentialHeightFogData SecondFogData; // 0x44 Size: 0xc

};

struct FDirectionalLightValues
{
	public:
	    struct FColor LightColor; // 0x0 Size: 0x4
	    float Brightness; // 0x4 Size: 0x4
	    float VolumetricScatteringIntensity; // 0x8 Size: 0x4

};

struct FElementalCharValues
{
	public:
	    struct FLinearColor FireCharColor; // 0x0 Size: 0x10
	    float ElectricalCharEmissive; // 0x10 Size: 0x4

};

struct FCloudColorState
{
	public:
	    struct FLinearColor BottomEmissive; // 0x0 Size: 0x10
	    struct FLinearColor TopEmissive; // 0x10 Size: 0x10
	    struct FLinearColor BottomLightning; // 0x20 Size: 0x10
	    struct FLinearColor TopLightning; // 0x30 Size: 0x10
	    struct FLinearColor InternalColor; // 0x40 Size: 0x10

};

struct FThreatCloudValues
{
	public:
	    struct FCloudColorState CloudActivated; // 0x0 Size: 0x50
	    struct FCloudColorState CloudDeactivated; // 0x50 Size: 0x50

};

struct FSkyLightValues
{
	public:
	    struct FLinearColor SkyLightColor; // 0x0 Size: 0x10
	    struct FLinearColor SkyLightOcclusionTint; // 0x10 Size: 0x10
	    float SkyLightMinOcclusion; // 0x20 Size: 0x4
	    float VolumetricScatteringIntensity; // 0x24 Size: 0x4

};

struct FDayPhaseInfo
{
	public:
	    struct FString PhaseStartAnnouncement; // 0x0 Size: 0x10
	    float TimePhaseBegins; // 0x10 Size: 0x4
	    float PhaseLengthInHours; // 0x14 Size: 0x4
	    float PercentageTransitionIn; // 0x18 Size: 0x4
	    float TransitionInTimeInMinutes; // 0x1c Size: 0x4
	    float PercentageTransitionOut; // 0x20 Size: 0x4
	    float TransitionOutTimeInMinutes; // 0x24 Size: 0x4
	    struct FSkyLightValues SkyLightValues; // 0x28 Size: 0x28
	    struct FThreatCloudValues ThreatCloudValues; // 0x50 Size: 0xa0
	    struct FElementalCharValues ElementalCharValues; // 0xf0 Size: 0x14
	    struct FDirectionalLightValues DirectionalLightValues; // 0x104 Size: 0xc
	    struct FExponentialHeightFogValues ExpHeightFogValues; // 0x110 Size: 0x50
	    class UPostProcessComponent* LowPriPostProcessComponent; // 0x160 Size: 0x8
	    class UMaterialInstance* SkyMaterialInstance; // 0x168 Size: 0x8
	    class UMaterialInstance* StarMapMaterialInstance; // 0x170 Size: 0x8

};

struct FCameraAltitudeAdjustments
{
	public:
	    float Altitude; // 0x0 Size: 0x4
	    float FogHeightFalloff; // 0x4 Size: 0x4
	    float HeightFogZOffset; // 0x8 Size: 0x4
	    float FogDensity; // 0xc Size: 0x4

};

struct FFortTooltipMapEntry
{
	public:
	    class UObject* ObjectClass; // 0x0 Size: 0x8
	    class UObject* SecondaryObjectClass; // 0x8 Size: 0x8
	    class UFortTooltip* TooltipClass; // 0x10 Size: 0x8

};

struct FFortTouchAimAssist
{
	public:
	    char UnknownData0[0x110];

};

struct FFortTouchAimAssist_Target
{
	public:
	    class AActor* Actor; // 0x0 Size: 0x8
	    char UnknownData0[0x38];

};

struct FFortTouchAimAssist_OwnerInfo
{
	public:
	    char UnknownData0[0x90];

};

struct FFortTouchAimAssist_Results
{
	public:
	    char UnknownData0[0xc];

};

struct FFortTouchAimAssist_Params
{
	public:
	    char UnknownData0[0x20];

};

struct FFortTouchAimAssistSettings
{
	public:
	    float ReticleWidth; // 0x0 Size: 0x4
	    float ReticleHeight; // 0x4 Size: 0x4
	    float ReticleDepth; // 0x8 Size: 0x4
	    float AutoFireReticleWidth; // 0xc Size: 0x4
	    float AutoFireReticleHeight; // 0x10 Size: 0x4
	    float ProjectileMinSpeedForAssist; // 0x14 Size: 0x4
	    float ProjectileMaxLookAheadTime; // 0x18 Size: 0x4
	    float TargetRange; // 0x1c Size: 0x4
	    class UCurveFloat* TargetWeightCurve; // 0x20 Size: 0x8
	    class UCurveFloat* PullStrengthYawCurve; // 0x28 Size: 0x8
	    class UCurveFloat* PullStrengthPitchCurve; // 0x30 Size: 0x8
	    float PullMaxRate; // 0x38 Size: 0x4
	    float AutoTrackDuration; // 0x3c Size: 0x4
	    float AutoTrackPullStrength; // 0x40 Size: 0x4
	    char UnknownData0[0x4];

};

struct FEventSessionSummary
{
	public:
	    struct FString SessionId; // 0x0 Size: 0x10
	    struct FDateTime EndTime; // 0x10 Size: 0x8
	    __int64/*MapProperty*/ TrackedStats; // 0x18 Size: 0x50

};

struct FEventScoreAggregation
{
	public:
	    int TimesAchieved; // 0x0 Size: 0x4
	    int PointsEarned; // 0x4 Size: 0x4

};

struct FEventRewardTier
{
	public:
	    int KeyValue; // 0x0 Size: 0x4
	    int PointsEarned; // 0x4 Size: 0x4

};

struct FEventHistoryPayloadV1
{
	public:
	    int PointsEarned; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    __int64/*MapProperty*/ PointBreakdown; // 0x8 Size: 0x50

};

struct FPlayerEventWindowHistory
{
	public:
	    int TimesAchieved; // 0x0 Size: 0x4
	    int PointsEarned; // 0x4 Size: 0x4

};

struct FScoreReward
{
	public:
	    int KeyValue; // 0x0 Size: 0x4
	    int PointsEarned; // 0x4 Size: 0x4

};

struct FTowhookParams
{
	public:
	    float MaxRopeLength; // 0x0 Size: 0x4
	    float RopeStiffness; // 0x4 Size: 0x4
	    float DetachedExtendSpeed; // 0x8 Size: 0x4
	    float AttachedExtendSpeed; // 0xc Size: 0x4
	    float AttachedContractSpeed; // 0x10 Size: 0x4
	    float DetachedContractSpeed; // 0x14 Size: 0x4
	    bool bAdditiveExtensionVelocity; // 0x18 Size: 0x1
	    bool bAllowHookForce; // 0x19 Size: 0x1
	    bool bAllowHookTorque; // 0x1a Size: 0x1
	    bool bAutoContract; // 0x1b Size: 0x1
	    char AttachCollisionChannel; // 0x1c Size: 0x1
	    char UnknownData0[0x3]; // 0x1d
	    struct FVector HookGravity; // 0x20 Size: 0xc

};

struct FTrackConnectorMeshConfig
{
	public:
	    ETrackIncline InclineSideA; // 0x0 Size: 0x1
	    ETrackIncline InclineSideB; // 0x1 Size: 0x1
	    char UnknownData0[0x6]; // 0x2
	    class UStaticMesh* Mesh; // 0x8 Size: 0x8

};

struct FTrackSplineConfig
{
	public:
	    bool bUseSpline; // 0x0 Size: 0x1
	    ETrackDirection Start; // 0x1 Size: 0x1
	    ETrackDirection End; // 0x2 Size: 0x1

};

struct FTrackPieceConfig
{
	public:
	    ETrackPieceType Type; // 0x0 Size: 0x1
	    char UnknownData0[0x3]; // 0x1
	    struct FRotator Rotation; // 0x4 Size: 0xc
	    struct FVector Scale; // 0x10 Size: 0xc

};

struct FTrackSwitchStateConfig
{
	public:
	    struct FTrackPieceConfig TrackPiece; // 0x0 Size: 0x1c
	    struct FTrackSplineConfig SplineConfig1; // 0x1c Size: 0x3
	    struct FTrackSplineConfig SplineConfig2; // 0x1f Size: 0x3
	    char UnknownData0[0x2];

};

struct FTrackMovement
{
	public:
	    class USplineComponent* CurrentSpline; // 0x0 Size: 0x8
	    float DistanceAlongSpline; // 0x8 Size: 0x4
	    bool bReverseDirectionAlongSpline; // 0xc Size: 0x1
	    char UnknownData0[0x3];

};

struct FRepTrackMovement : public FTrackMovement
{
	public:
	    float Timestamp; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FTransactionalAnalyticEvent
{
	public:
	    char UnknownData0[0x28];

};

struct FFortBaseWeaponStats : public FTableRowBase
{
	public:
	    int BaseLevel; // 0x8 Size: 0x4
	    FName NamedWeightRow; // 0xc Size: 0x8
	    float DmgPB; // 0x14 Size: 0x4
	    float DmgMid; // 0x18 Size: 0x4
	    float DmgLong; // 0x1c Size: 0x4
	    float DmgMaxRange; // 0x20 Size: 0x4
	    float EnvDmgPB; // 0x24 Size: 0x4
	    float EnvDmgMid; // 0x28 Size: 0x4
	    float EnvDmgLong; // 0x2c Size: 0x4
	    float EnvDmgMaxRange; // 0x30 Size: 0x4
	    float ImpactDmgPB; // 0x34 Size: 0x4
	    float ImpactDmgMid; // 0x38 Size: 0x4
	    float ImpactDmgLong; // 0x3c Size: 0x4
	    float ImpactDmgMaxRange; // 0x40 Size: 0x4
	    bool bForceControl; // 0x44 Size: 0x1
	    char UnknownData0[0x3]; // 0x45
	    float RngPB; // 0x48 Size: 0x4
	    float RngMid; // 0x4c Size: 0x4
	    float RngLong; // 0x50 Size: 0x4
	    float RngMax; // 0x54 Size: 0x4
	    class UCurveTable* DmgScaleTable; // 0x58 Size: 0x8
	    FName DmgScaleTableRow; // 0x60 Size: 0x8
	    float DmgScale; // 0x68 Size: 0x4
	    char UnknownData1[0x4]; // 0x6c
	    class UCurveTable* EnvDmgScaleTable; // 0x70 Size: 0x8
	    FName EnvDmgScaleTableRow; // 0x78 Size: 0x8
	    float EnvDmgScale; // 0x80 Size: 0x4
	    char UnknownData2[0x4]; // 0x84
	    class UCurveTable* ImpactDmgScaleTable; // 0x88 Size: 0x8
	    FName ImpactDmgScaleTableRow; // 0x90 Size: 0x8
	    float ImpactDmgScale; // 0x98 Size: 0x4
	    FName SurfaceRatioRowName; // 0x9c Size: 0x8
	    float DamageZone_Light; // 0xa4 Size: 0x4
	    float DamageZone_Normal; // 0xa8 Size: 0x4
	    float DamageZone_Critical; // 0xac Size: 0x4
	    float DamageZone_Vulnerability; // 0xb0 Size: 0x4
	    float KnockbackMagnitude; // 0xb4 Size: 0x4
	    float MidRangeKnockbackMagnitude; // 0xb8 Size: 0x4
	    float LongRangeKnockbackMagnitude; // 0xbc Size: 0x4
	    float KnockbackZAngle; // 0xc0 Size: 0x4
	    float StunTime; // 0xc4 Size: 0x4
	    float StunScale; // 0xc8 Size: 0x4
	    char UnknownData3[0x4]; // 0xcc
	    class UDataTable* Durability; // 0xd0 Size: 0x8
	    FName DurabilityRowName; // 0xd8 Size: 0x8
	    float DurabilityScale; // 0xe0 Size: 0x4
	    float DurabilityPerUse; // 0xe4 Size: 0x4
	    float DiceCritChance; // 0xe8 Size: 0x4
	    float DiceCritDamageMultiplier; // 0xec Size: 0x4
	    float ReloadTime; // 0xf0 Size: 0x4
	    float ReloadScale; // 0xf4 Size: 0x4
	    EFortWeaponReloadType ReloadType; // 0xf8 Size: 0x1
	    bool bAllowReloadInterrupt; // 0xf9 Size: 0x1
	    bool bReloadInterruptIsImmediate; // 0xfa Size: 0x1
	    char UnknownData4[0x1]; // 0xfb
	    int ClipSize; // 0xfc Size: 0x4
	    float ClipScale; // 0x100 Size: 0x4
	    int InitialClips; // 0x104 Size: 0x4
	    int CartridgePerFire; // 0x108 Size: 0x4
	    int AmmoCostPerFire; // 0x10c Size: 0x4
	    int MaxAmmoCostPerFire; // 0x110 Size: 0x4
	    float MinChargeTime; // 0x114 Size: 0x4
	    float MaxChargeTime; // 0x118 Size: 0x4
	    float ChargeDownTime; // 0x11c Size: 0x4
	    float MinChargeDamageMultiplier; // 0x120 Size: 0x4
	    float MaxChargeDamageMultiplier; // 0x124 Size: 0x4
	    float EquipAnimRate; // 0x128 Size: 0x4
	    float QuickBarSlotCooldownDuration; // 0x12c Size: 0x4

};

struct FFortTrapStats : public FFortBaseWeaponStats
{
	public:
	    float ArmTime; // 0x130 Size: 0x4
	    float FireDelay; // 0x134 Size: 0x4
	    float DamageDelay; // 0x138 Size: 0x4
	    int PlacementScore; // 0x13c Size: 0x4
	    int ActivationScore; // 0x140 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortCreativeItemListData : public FTableRowBase
{
	public:
	    FName CategoryName; // 0x8 Size: 0x8
	    struct FPrimaryAssetId ItemPrimaryAssetId; // 0x10 Size: 0x10
	    int Count; // 0x20 Size: 0x4
	    bool bIncluded; // 0x24 Size: 0x1
	    char UnknownData0[0x3];

};

struct FAthenaPickResult
{
	public:
	    EAthenaPickerType PickType; // 0x0 Size: 0x1
	    char UnknownData0[0x7]; // 0x1
	    class ABuildingActor* FoundBuildingActor; // 0x8 Size: 0x8
	    class AFortPlayerPawnAthena* FoundPlayer; // 0x10 Size: 0x8

};

struct FDataTableRowHandleQuantityPair
{
	public:
	    struct FDataTableRowHandle DataTableRowHandle; // 0x0 Size: 0x10
	    int Quantity; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FKeybindIcon
{
	public:
	    struct FKey Key; // 0x0 Size: 0x18
	    struct FFortMultiSizeBrush Brush; // 0x18 Size: 0x330

};

struct FFortEffectDistanceQuality
{
	public:
	    float MinDistanceCinematic; // 0x0 Size: 0x4
	    float MinDistanceEpic; // 0x4 Size: 0x4
	    float MinDistanceHigh; // 0x8 Size: 0x4
	    float MinDistanceMedium; // 0xc Size: 0x4
	    float MinDistanceLow; // 0x10 Size: 0x4
	    bool bAllowCinematic; // 0x14 Size: 0x1
	    bool bAllowEpic; // 0x14 Size: 0x1
	    bool bAllowHigh; // 0x14 Size: 0x1
	    bool bAllowMedium; // 0x14 Size: 0x1
	    bool bAllowLow; // 0x14 Size: 0x1
	    char UnknownData0[0x-1];

};

struct FFortAlterationSlotStatus
{
	public:
	    class UFortAlterationItemDefinition* Alteration; // 0x0 Size: 0x8
	    int MinRequiredLevel; // 0x8 Size: 0x4
	    EFortRarity MinHostItemRarity; // 0xc Size: 0x1
	    char UnknownData0[0x3];

};

struct FFortClientEvent
{
	public:
	    FName CategoryName; // 0x0 Size: 0x8
	    FName EventName; // 0x8 Size: 0x8
	    class UObject* EventSource; // 0x10 Size: 0x8
	    class UObject* EventFocus; // 0x18 Size: 0x8

};

struct FFortEventName
{
	public:
	    FName CategoryName; // 0x0 Size: 0x8
	    FName EventName; // 0x8 Size: 0x8

};

struct FFortClientEventName : public FFortEventName
{
	public:
	    char UnknownData0[0x10];

};

struct FFortMissionEventName : public FFortEventName
{
	public:
	    char UnknownData0[0x10];

};

struct FFortQuestPackInfo
{
	public:
	    struct FString Name; // 0x0 Size: 0x10
	    struct FString DefaultQuestPack; // 0x10 Size: 0x10
	    int MaxActiveDailyQuests; // 0x20 Size: 0x4
	    int MaxRerollsPerDay; // 0x24 Size: 0x4
	    int DaysToKeepClaimedQuests; // 0x28 Size: 0x4
	    int DaysToKeepCompletedQuests; // 0x2c Size: 0x4
	    int MaxUnclaimedQuests; // 0x30 Size: 0x4
	    bool IsStreamingQuestPack; // 0x34 Size: 0x1
	    char UnknownData0[0x3];

};

struct FFortNamedWeightRow : public FTableRowBase
{
	public:
	    __int64/*MapProperty*/ NamedWeightMap; // 0x8 Size: 0x50

};

struct FFortLoginReward : public FTableRowBase
{
	public:
	    struct TSoftObjectPtr<struct UFortAccountItemDefinition*> ItemDefinition; // 0x8 Size: 0x28
	    int ItemCount; // 0x30 Size: 0x4
	    char UnknownData0[0x4]; // 0x34
	    struct FText Description; // 0x38 Size: 0x18
	    bool bIsMajorReward; // 0x50 Size: 0x1
	    char UnknownData1[0x7];

};

struct FFortDayPhaseCallbackHandle
{
	public:
	    char UnknownData0[0x10];

};

struct FFortMultiSizeMargin
{
	public:
	    struct FMargin Margin_XXS; // 0x0 Size: 0x10
	    struct FMargin Margin_XS; // 0x10 Size: 0x10
	    struct FMargin Margin_S; // 0x20 Size: 0x10
	    struct FMargin Margin_M; // 0x30 Size: 0x10
	    struct FMargin Margin_L; // 0x40 Size: 0x10
	    struct FMargin Margin_XL; // 0x50 Size: 0x10

};

struct FFortMultiSizeFont
{
	public:
	    struct FSlateFontInfo Font_XXS; // 0x0 Size: 0x50
	    struct FSlateFontInfo Font_XS; // 0x50 Size: 0x50
	    struct FSlateFontInfo Font_S; // 0xa0 Size: 0x50
	    struct FSlateFontInfo Font_M; // 0xf0 Size: 0x50
	    struct FSlateFontInfo Font_L; // 0x140 Size: 0x50
	    struct FSlateFontInfo Font_XL; // 0x190 Size: 0x50

};

struct FPurchasedBattlePassInfo
{
	public:
	    int Count; // 0x0 Size: 0x4
	    char UnknownData0[0x4]; // 0x4
	    struct FString ID; // 0x8 Size: 0x10

};

struct FFortUIFeedback
{
	public:
	    class USoundBase* Audio; // 0x0 Size: 0x8
	    bool bLooping; // 0x8 Size: 0x1
	    char UnknownData0[0x3]; // 0x9
	    float FadeIn; // 0xc Size: 0x4
	    float FadeOut; // 0x10 Size: 0x4
	    char UnknownData1[0x4];

};

struct FFortUIFeedbackBlueprintOnly : public FFortUIFeedback
{
	public:
	    char UnknownData0[0x18];

};

struct FFortVehicleAudioOneshotGate
{
	public:
	    float GateValue; // 0x0 Size: 0x4
	    EVehicleAudioTriggerDir Direction; // 0x4 Size: 0x1
	    bool FadeWhenOutsideGate; // 0x5 Size: 0x1
	    char UnknownData0[0x2]; // 0x6
	    class USoundBase* Sound; // 0x8 Size: 0x8
	    float MinTimeSinceTrigger; // 0x10 Size: 0x4
	    float InterruptFadeTime; // 0x14 Size: 0x4
	    char UnknownData1[0x8]; // 0x18
	    class UAudioComponent* AudioComp; // 0x20 Size: 0x8

};

struct FFortVehicleAudioParam
{
	public:
	    float Value; // 0x0 Size: 0x4
	    EVehicleAudioInterpolationType InterpType; // 0x4 Size: 0x1
	    char UnknownData0[0x3]; // 0x5
	    class UCurveFloat* Curve; // 0x8 Size: 0x8
	    float AttackSpeed; // 0x10 Size: 0x4
	    float ReleaseSpeed; // 0x14 Size: 0x4
	    char UnknownData1[0x8];

};

struct FFortVehicleAudioFloatParam
{
	public:
	    FName Name; // 0x0 Size: 0x8
	    struct FFortVehicleAudioParam Data; // 0x8 Size: 0x20

};

struct FFortVehicleIncrementTrick
{
	public:
	    struct FText Name; // 0x0 Size: 0x18
	    int HalfSpinsNeeded; // 0x18 Size: 0x4
	    int BaseScore; // 0x1c Size: 0x4
	    int Repeats; // 0x20 Size: 0x4
	    int RepeatsHalfSpinsPerTrick; // 0x24 Size: 0x4
	    int MultiplierIncrement; // 0x28 Size: 0x4
	    char UnknownData0[0x4];

};

struct FVehicleTrickSequenceBasics : public FTableRowBase
{
	public:
	    float TrickStartTime; // 0x8 Size: 0x4
	    float TrickStartDistance; // 0xc Size: 0x4
	    float TrickStartHeight; // 0x10 Size: 0x4
	    float TrickPointsPerAirSecond; // 0x14 Size: 0x4
	    float TrickPointsPerAirDistance; // 0x18 Size: 0x4
	    float TrickPointsPerAirHeight; // 0x1c Size: 0x4

};

struct FVisibilityInfo : public FFastArraySerializerItem
{
	public:
	    char UnknownData0[0x4];
	    class AActor* Actor; // 0x10 Size: 0x8
	    class UFortVisibilityComponent* VisibilityComponent; // 0x18 Size: 0x8
	    __int64/*UInt16Property*/ TeamVisibilityFlag; // 0x20 Size: 0x2
	    char UnknownData1[0x6];

};

struct FVolumeActorStats
{
	public:
	    __int64/*MapProperty*/ BuildingTypeCounts; // 0x0 Size: 0x50

};

struct FFortVolumeManagerBlackListObjects : public FTableRowBase
{
	public:
	    struct TSoftObjectPtr<struct UObject*> ObjectPath; // 0x8 Size: 0x28

};

struct FFortVolumeManagerBlackListClasses : public FTableRowBase
{
	public:
	    __int64/*SoftClassProperty*/ ClassPath; // 0x8 Size: 0x28

};

struct FPendingSpawnLevelSaveRecord
{
	public:
	    char UnknownData0[0xc];

};

struct FVolume_Internal
{
	public:
	    char UnknownData0[0x1];

};

struct FFortVolumeExitingUser : public FFastArraySerializerItem
{
	public:
	    char UnknownData0[0x4];
	    class APlayerState* PlayerState; // 0x10 Size: 0x8
	    class AFortVolume* Volume; // 0x18 Size: 0x8
	    char UnknownData1[0x8];

};

struct FVolumePlayerStateInfo : public FFastArraySerializerItem
{
	public:
	    char UnknownData0[0x4];
	    class APlayerState* PlayerState; // 0x10 Size: 0x8
	    class AFortVolume* Volume; // 0x18 Size: 0x8

};

struct FPlayerWaypointContext
{
	public:
	    class APlayerState* PlayerState; // 0x0 Size: 0x8
	    class ABuildingTrapFloor_Waypoint* Waypoint; // 0x8 Size: 0x8

};

struct FWeaponHudData
{
	public:
	    FName KeyActionName; // 0x0 Size: 0x8
	    struct FText ActionDescription; // 0x8 Size: 0x18

};

struct FFortWeaponDurabilityByRarityStats : public FTableRowBase
{
	public:
	    int Handmade; // 0x8 Size: 0x4
	    int Ordinary; // 0xc Size: 0x4
	    int Sturdy; // 0x10 Size: 0x4
	    int Quality; // 0x14 Size: 0x4
	    int Fine; // 0x18 Size: 0x4
	    int Elegant; // 0x1c Size: 0x4
	    int Masterwork; // 0x20 Size: 0x4
	    int Epic; // 0x24 Size: 0x4
	    int Badass; // 0x28 Size: 0x4
	    int Legendary; // 0x2c Size: 0x4

};

struct FFortMeleeWeaponStats : public FFortBaseWeaponStats
{
	public:
	    float RangeVSEnemies; // 0x130 Size: 0x4
	    float ConeYawAngle; // 0x134 Size: 0x4
	    float ConePitchAngle; // 0x138 Size: 0x4
	    float SwingPlaySpeed; // 0x13c Size: 0x4
	    float SwingTime; // 0x140 Size: 0x4
	    float BuildingConeAngle; // 0x144 Size: 0x4
	    float BuildingConeAnglePitch; // 0x148 Size: 0x4
	    float RangeVSBuildings2D; // 0x14c Size: 0x4
	    float RangeVSBuildingsZ; // 0x150 Size: 0x4
	    float RangeVSWeakSpots; // 0x154 Size: 0x4

};

struct FFortRangedWeaponStats : public FFortBaseWeaponStats
{
	public:
	    float Spread; // 0x130 Size: 0x4
	    float SpreadDownsights; // 0x134 Size: 0x4
	    float StandingStillSpreadMultiplier; // 0x138 Size: 0x4
	    float AthenaCrouchingSpreadMultiplier; // 0x13c Size: 0x4
	    float AthenaJumpingFallingSpreadMultiplier; // 0x140 Size: 0x4
	    float AthenaSprintingSpreadMultiplier; // 0x144 Size: 0x4
	    float MinSpeedForSpreadMultiplier; // 0x148 Size: 0x4
	    float MaxSpeedForSpreadMultiplier; // 0x14c Size: 0x4
	    float SpreadDownsightsAdditionalCooldownTime; // 0x150 Size: 0x4
	    float HeatX1; // 0x154 Size: 0x4
	    float HeatY1; // 0x158 Size: 0x4
	    float HeatX2; // 0x15c Size: 0x4
	    float HeatY2; // 0x160 Size: 0x4
	    float HeatX3; // 0x164 Size: 0x4
	    float HeatY3; // 0x168 Size: 0x4
	    float HeatXScale; // 0x16c Size: 0x4
	    float HeatYScale; // 0x170 Size: 0x4
	    float CoolX1; // 0x174 Size: 0x4
	    float CoolY1; // 0x178 Size: 0x4
	    float CoolX2; // 0x17c Size: 0x4
	    float CoolY2; // 0x180 Size: 0x4
	    float CoolX3; // 0x184 Size: 0x4
	    float CoolY3; // 0x188 Size: 0x4
	    float CoolXScale; // 0x18c Size: 0x4
	    float CoolYScale; // 0x190 Size: 0x4
	    float PerfectAimCooldown; // 0x194 Size: 0x4
	    int BulletsPerCartridge; // 0x198 Size: 0x4
	    float FiringRate; // 0x19c Size: 0x4
	    float ROFScale; // 0x1a0 Size: 0x4
	    float BurstFiringRate; // 0x1a4 Size: 0x4
	    float FiringRateDownsightsMultiplier; // 0x1a8 Size: 0x4
	    float RecoilVert; // 0x1ac Size: 0x4
	    float RecoilVertScale; // 0x1b0 Size: 0x4
	    float RecoilVertScaleGamepad; // 0x1b4 Size: 0x4
	    float VertRecoilDownChance; // 0x1b8 Size: 0x4
	    float RecoilHoriz; // 0x1bc Size: 0x4
	    float RecoilHorizScale; // 0x1c0 Size: 0x4
	    float RecoilHorizScaleGamepad; // 0x1c4 Size: 0x4
	    float RecoilInterpSpeed; // 0x1c8 Size: 0x4
	    float RecoilRecoveryInterpSpeed; // 0x1cc Size: 0x4
	    float RecoilRecoveryDelay; // 0x1d0 Size: 0x4
	    float RecoilRecoveryFraction; // 0x1d4 Size: 0x4
	    float RecoilDownsightsMultiplier; // 0x1d8 Size: 0x4
	    float AthenaRecoilMagnitudeMin; // 0x1dc Size: 0x4
	    float AthenaRecoilMagnitudeMax; // 0x1e0 Size: 0x4
	    float AthenaRecoilMagnitudeScale; // 0x1e4 Size: 0x4
	    float AthenaRecoilAngleMin; // 0x1e8 Size: 0x4
	    float AthenaRecoilAngleMax; // 0x1ec Size: 0x4
	    float AthenaRecoilRollMagnitudeMin; // 0x1f0 Size: 0x4
	    float AthenaRecoilRollMagnitudeMax; // 0x1f4 Size: 0x4
	    float AthenaRecoilInterpSpeed; // 0x1f8 Size: 0x4
	    float AthenaRecoilRecoveryInterpSpeed; // 0x1fc Size: 0x4
	    float AthenaRecoilDownsightsMultiplier; // 0x200 Size: 0x4
	    float AthenaRecoilHipFireMultiplier; // 0x204 Size: 0x4
	    float AthenaAimAssistRange; // 0x208 Size: 0x4
	    float ADSTransitionInTime; // 0x20c Size: 0x4
	    float ADSTransitionOutTime; // 0x210 Size: 0x4
	    int MaxSpareAmmo; // 0x214 Size: 0x4
	    int BulletsPerTracer; // 0x218 Size: 0x4
	    float AIDelayBeforeFiringMin; // 0x21c Size: 0x4
	    float AIDelayBeforeFiringMax; // 0x220 Size: 0x4
	    float AIFireDurationMin; // 0x224 Size: 0x4
	    float AIFireDurationMax; // 0x228 Size: 0x4
	    float AIMinSpreadDuration; // 0x22c Size: 0x4
	    float AIMaxSpreadDuration; // 0x230 Size: 0x4
	    float AIDurationSpreadMultiplier; // 0x234 Size: 0x4
	    float AIAdditionalSpreadForTargetMovingLaterally; // 0x238 Size: 0x4
	    float AIAthenaHearFiringNoiseRange; // 0x23c Size: 0x4
	    float EQSDensity; // 0x240 Size: 0x4
	    float MinApproachRange; // 0x244 Size: 0x4
	    float MinActualRange; // 0x248 Size: 0x4
	    float MinPreferredRange; // 0x24c Size: 0x4
	    float MinPreferredRangeEQS; // 0x250 Size: 0x4
	    float MaxPreferredRangeEQS; // 0x254 Size: 0x4
	    float MaxPreferredRange; // 0x258 Size: 0x4
	    float MaxActualRange; // 0x25c Size: 0x4
	    float MaxApproachRange; // 0x260 Size: 0x4
	    float SweepRadius; // 0x264 Size: 0x4
	    float AutoReloadDelayOverride; // 0x268 Size: 0x4
	    float OverheatingMaxValue; // 0x26c Size: 0x4
	    float OverheatHeatingValue; // 0x270 Size: 0x4
	    float OverheatingCoolingValue; // 0x274 Size: 0x4
	    float HeatingCooldownDelay; // 0x278 Size: 0x4
	    float OverheatedCooldownDelay; // 0x27c Size: 0x4

};

struct FFortWindImpulseCylinderDelta
{
	public:
	    struct FVector DeltaCenter; // 0x0 Size: 0xc
	    bool bInitialized; // 0xc Size: 0x1
	    bool bRippleOutward; // 0xd Size: 0x1
	    char UnknownData0[0x2]; // 0xe
	    float SectionWidth; // 0x10 Size: 0x4
	    float InnerSectionRadius; // 0x14 Size: 0x4
	    float OuterSectionRadius; // 0x18 Size: 0x4
	    float MaximumRadius; // 0x1c Size: 0x4
	    float DesiredOverallBlendTime; // 0x20 Size: 0x4
	    float SectionBlendTime; // 0x24 Size: 0x4
	    float SectionCurrentBlendTime; // 0x28 Size: 0x4
	    float PreviousMagnitude; // 0x2c Size: 0x4
	    float SectionCurrentMagnitude; // 0x30 Size: 0x4
	    float DesiredMagnitude; // 0x34 Size: 0x4
	    struct FBox OuterWorldBounds; // 0x38 Size: 0x1c
	    struct FBox InnerWorldBounds; // 0x54 Size: 0x1c
	    struct FBox WindImpulseBounds; // 0x70 Size: 0x1c
	    struct FFortWindImpulseHandle WindImpulseHandleToModify; // 0x8c Size: 0x4

};

struct FFortWindImpulseRadius
{
	public:
	    struct FVector Location; // 0x0 Size: 0xc
	    float Radius; // 0xc Size: 0x4
	    float CurrentRadius; // 0x10 Size: 0x4
	    float PreviousRadius; // 0x14 Size: 0x4
	    float Magnitude; // 0x18 Size: 0x4
	    float CurrentMagnitude; // 0x1c Size: 0x4
	    float PreviousMagnitude; // 0x20 Size: 0x4
	    float BlendTime; // 0x24 Size: 0x4
	    float CurrentBlendTime; // 0x28 Size: 0x4
	    struct FBox WorldBounds; // 0x2c Size: 0x1c
	    struct FFortWindImpulseHandle Handle; // 0x48 Size: 0x4

};

struct FFortWindImpulseCylinderRadial
{
	public:
	    struct FVector Location; // 0x0 Size: 0xc
	    float InnerRadius; // 0xc Size: 0x4
	    float OuterRadius; // 0x10 Size: 0x4
	    float Magnitude; // 0x14 Size: 0x4
	    struct FBox WorldBounds; // 0x18 Size: 0x1c
	    bool bIsChanging; // 0x34 Size: 0x1
	    bool bIsChangePending; // 0x35 Size: 0x1
	    char UnknownData0[0x2]; // 0x36
	    struct FFortWindImpulseHandle Handle; // 0x38 Size: 0x4

};

struct FFortWindImpulseCylinder : public FFortWindImpulseCylinderRadial
{
	public:
	    struct FVector WindDirection; // 0x3c Size: 0xc

};

struct FFortWindResponderMaterialVariablePairData
{
	public:
	    float PreviousSpeed; // 0x0 Size: 0x4
	    float PreviousOffset; // 0x4 Size: 0x4
	    float MaterialsPreviousTime; // 0x8 Size: 0x4
	    float DeltaTimeModifiedByMaterialSpeed; // 0xc Size: 0x4
	    int MaterialVariableIndex; // 0x10 Size: 0x4
	    FName SpeedVariableName; // 0x14 Size: 0x8
	    FName TimeOffsetVariableName; // 0x1c Size: 0x8

};

struct FFortMaterialParameterID
{
	public:
	    int VariableIndex; // 0x0 Size: 0x4
	    FName VariableName; // 0x4 Size: 0x8

};

struct FFortWindMaterialParameterPairID
{
	public:
	    int PairIndex; // 0x0 Size: 0x4
	    struct FFortMaterialParameterID SpeedParameter; // 0x4 Size: 0xc
	    struct FFortMaterialParameterID OffsetParameter; // 0x10 Size: 0xc

};

struct FWindVectorMaterialInterpolationData
{
	public:
	    FName MaterialParameterName; // 0x0 Size: 0x8
	    int MaterialParameterIndex; // 0x8 Size: 0x4
	    struct FLinearColor LerpFromValue; // 0xc Size: 0x10
	    struct FLinearColor LerpToValue; // 0x1c Size: 0x10

};

struct FWindScalarMaterialInterpolationData
{
	public:
	    FName MaterialParameterName; // 0x0 Size: 0x8
	    int MaterialParameterIndex; // 0x8 Size: 0x4
	    float LerpFromValue; // 0xc Size: 0x4
	    float LerpToValue; // 0x10 Size: 0x4

};

struct FFortDeferredNewActorData
{
	public:
	    class ABuildingActor* BuildingActor; // 0x0 Size: 0x8
	    int SavedLevelIndex; // 0x8 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortLevelStreamingInfo
{
	public:
	    FName PackageName; // 0x0 Size: 0x8
	    char LevelState; // 0x8 Size: 0x1
	    bool bFailedToLoad; // 0x9 Size: 0x1
	    char UnknownData0[0x2];

};

struct FStatRecord
{
	public:
	    FName StatName; // 0x0 Size: 0x8
	    int StatValue; // 0x8 Size: 0x4

};

struct FPlayerStatsRecord
{
	public:
	    int Stats; // 0x0 Size: 0x4
	    char UnknownData0[0x84];

};

struct FMapLocationRenderData
{
	public:
	    char UnknownData0[0x90];

};

struct FMapLocation
{
	public:
	    struct FText Text; // 0x0 Size: 0x18
	    struct FVector2D Position; // 0x18 Size: 0x8
	    struct FSlateFontInfo Font; // 0x20 Size: 0x50
	    struct FLinearColor Color; // 0x70 Size: 0x10
	    struct FGameplayTag LocationTag; // 0x80 Size: 0x8

};

struct FFortZoneStats
{
	public:
	    char UnknownData0[0x190];

};

struct FContainerStatInfo
{
	public:
	    char UnknownData0[0xc];

};

struct FEnemyNpcStatInfo
{
	public:
	    char UnknownData0[0x10];

};

struct FDefenderNPCStatInfo
{
	public:
	    char UnknownData0[0xc];

};

struct FHUDLayoutUsageData
{
	public:
	    int NumOfTimesOpened; // 0x0 Size: 0x4
	    int NumOfTimesReset; // 0x4 Size: 0x4
	    int NumOfTimesSaved; // 0x8 Size: 0x4
	    int NumOfTimesPanning; // 0xc Size: 0x4

};

struct FHUDLayoutDataEntry
{
	public:
	    struct FGameplayTag VisualType; // 0x0 Size: 0x8
	    struct FAnchorData AnchroData; // 0x8 Size: 0x28
	    int ZOrder; // 0x30 Size: 0x4
	    EBacchusHUDStateType BuildVisibility; // 0x34 Size: 0x1
	    EBacchusHUDStateType CombatVisibility; // 0x35 Size: 0x1
	    EBacchusHUDStateType EditVisibility; // 0x36 Size: 0x1
	    EBacchusHUDStateType CreativeVisibility; // 0x37 Size: 0x1
	    float Property_0; // 0x38 Size: 0x4
	    float Property_1; // 0x3c Size: 0x4
	    float Property_2; // 0x40 Size: 0x4
	    float Property_3; // 0x44 Size: 0x4
	    char UnknownData0[0x98];

};

struct FFireModeData
{
	public:
	    bool bAutoFireIsEnabled; // 0x0 Size: 0x1
	    bool b3DTouchEnabled; // 0x1 Size: 0x1
	    bool bTapToShootEnabled; // 0x2 Size: 0x1
	    bool bAlwaysShowDedicatedButton; // 0x3 Size: 0x1
	    EFireModeType FireModeType; // 0x4 Size: 0x1

};

struct FFortKeepAmmoStash : public FTableRowBase
{
	public:
	    int Max1; // 0x8 Size: 0x4
	    int Cooldown1; // 0xc Size: 0x4
	    int Max2; // 0x10 Size: 0x4
	    int Cooldown2; // 0x14 Size: 0x4
	    int Max3; // 0x18 Size: 0x4
	    int Cooldown3; // 0x1c Size: 0x4
	    int Max4; // 0x20 Size: 0x4
	    int Cooldown4; // 0x24 Size: 0x4
	    int PickupTier; // 0x28 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortKeepItemGroup : public FTableRowBase
{
	public:
	    int Items; // 0x8 Size: 0x4
	    int MaxTier; // 0xc Size: 0x4
	    int BaseLevel; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortKeepResourceGroup : public FTableRowBase
{
	public:
	    FName Container; // 0x8 Size: 0x8
	    int ItemCount; // 0x10 Size: 0x4
	    char UnknownData0[0x4]; // 0x14
	    struct FString ResourceName; // 0x18 Size: 0x10
	    struct TSoftObjectPtr<struct UFortItemDefinition*> FullPath; // 0x28 Size: 0x28

};

struct FActorRecord
{
	public:
	    char UnknownData0[0xb0];

};

struct FStructRecord
{
	public:
	    char UnknownData0[0x4];

};

struct FDeleteActorRecord
{
	public:
	    uint64_t RecordID; // 0x0 Size: 0x8
	    FName ActorId; // 0x8 Size: 0x8
	    __int64/*SoftClassProperty*/ ActorClass; // 0x10 Size: 0x28

};

struct FNewActorRecord
{
	public:
	    uint64_t RecordID; // 0x0 Size: 0x8
	    uint64_t BaseRecordID; // 0x8 Size: 0x8
	    FName ActorId; // 0x10 Size: 0x8
	    char UnknownData0[0x8]; // 0x18
	    struct FTransform Transform; // 0x20 Size: 0x30
	    char UnknownData1[0x10];

};

struct FFortEncounterModeSettings
{
	public:
	    char PacingMode; // 0x0 Size: 0x1
	    EFortEncounterSpawnLocationManagementMode SpawnLocationManagementMode; // 0x1 Size: 0x1
	    char SpawnLocationMode; // 0x2 Size: 0x1
	    char UtilitiesMode; // 0x3 Size: 0x1
	    char SpawnLimitMode; // 0x4 Size: 0x1

};

struct FFortGeneratedEncounterOption
{
	public:
	    class UFortDifficultyOptionCategoryEncounter* EncounterOptionCategory; // 0x0 Size: 0x8
	    class UFortDifficultyOptionEncounter* EncounterOption; // 0x8 Size: 0x8
	    float RangeLerpValue; // 0x10 Size: 0x4
	    bool bChangedSinceLastVLog; // 0x14 Size: 0x1
	    char UnknownData0[0x3];

};

struct FFortGeneratedMissionOption
{
	public:
	    class UFortDifficultyOptionCategoryMission* MissionOptionCategory; // 0x0 Size: 0x8
	    class UFortDifficultyOptionMission* MissionOption; // 0x8 Size: 0x8
	    float RangeLerpValue; // 0x10 Size: 0x4
	    char UnknownData0[0x4];

};

struct FFortMissionInstancedConfigDataBucket
{
	public:
	    struct FGameplayTag Tag; // 0x0 Size: 0x8
	    class UFortMissionConfigData* ConfigData; // 0x8 Size: 0x8

};

struct FFortMissionConfigDataBucket
{
	public:
	    struct FGameplayTag Tag; // 0x0 Size: 0x8
	    __int64/*SoftClassProperty*/ ConfigDataClass; // 0x8 Size: 0x28

};

struct FFortConnectionData
{
	public:
	    class ABuildingSMActor* ConnectedActor; // 0x0 Size: 0x8
	    struct FGuid ConnectedActorGuid; // 0x8 Size: 0x10
	    FName MySocketName; // 0x18 Size: 0x8
	    FName TheirSocketName; // 0x20 Size: 0x8
	    char UnknownData0[0x8];

};

struct FFortPlacementDistanceRequirements
{
	public:
	    float DistanceRangeMin; // 0x0 Size: 0x4
	    float DistanceRangeMax; // 0x4 Size: 0x4

};

struct FMyTownWorkerPortraitData
{
	public:
	    struct TSoftObjectPtr<struct UFortItemIconDefinition*> Portrait; // 0x0 Size: 0x28
	    int SelectionWeight; // 0x28 Size: 0x4
	    char UnknownData0[0x4];

};

struct FHeroSlotInfo
{
	public:
	    char UnknownData0[0x90];

};

struct FStatNamesToTrack : public FTableRowBase
{
	public:
	    FName StatName; // 0x8 Size: 0x8
	    EStatRecordingPeriod Period; // 0x10 Size: 0x1
	    char UnknownData0[0x7];

};

struct FStrategicBuildingActiveConstructionInfo
{
	public:
	    float ConstructionStartTime; // 0x0 Size: 0x4
	    float ConstructionEndTime; // 0x4 Size: 0x4
	    int ConstructionLevel; // 0x8 Size: 0x4
	    bool bUnderConstruction; // 0xc Size: 0x1
	    char UnknownData0[0x3];

};

struct FStrategicBuildingLevelActiveCriteriaProgress
{
	public:
	    float CurrentProgress; // 0x0 Size: 0x4
	    float MaxProgress; // 0x4 Size: 0x4
	    bool bProgressAllowed; // 0x8 Size: 0x1
	    char UnknownData0[0x3];

};

struct FStrategicBuildingLevelCriteria
{
	public:
	    struct FText UnlockRequirementText; // 0x0 Size: 0x18
	    EFortStrategicBuildingLevelCriteriaDisplayRepresentation RequirementDisplayRepresentation; // 0x18 Size: 0x1
	    char UnknownData0[0x3]; // 0x19
	    float UnlockRequirementQuantity; // 0x1c Size: 0x4

};

struct FTileGroupInfo
{
	public:
	    class UWorldTileGroup* TileGroup; // 0x0 Size: 0x8
	    int Weight; // 0x8 Size: 0x4
	    int MinTiles; // 0xc Size: 0x4
	    int MaxTiles; // 0x10 Size: 0x4
	    bool bPlaceAdjacent; // 0x14 Size: 0x1
	    char UnknownData0[0x3];

};

struct FTileGroupMapInfo
{
	public:
	    struct TSoftObjectPtr<struct UWorld*> GroupWorld; // 0x0 Size: 0x28
	    float Weight; // 0x28 Size: 0x4
	    FName QuotaCategory; // 0x2c Size: 0x8
	    char UnknownData0[0x4];

};

struct FFortTileLootData
{
	public:
	    struct FFortLootQuotaData* LootQuotas; // 0x0 Size: 0x28
	    char UnknownData0[0x2a8]; // 0x28
	    int LootDrops; // 0x2d0 Size: 0x4
	    char UnknownData1[0x44];

};


}