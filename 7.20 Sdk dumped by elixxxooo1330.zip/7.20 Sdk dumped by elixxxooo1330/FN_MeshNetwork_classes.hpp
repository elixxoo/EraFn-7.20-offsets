#pragma once

#include "../SDK.hpp"

namespace SDK {


class AMeshBeaconClient : public AOnlineBeaconClient
{
	public:
	    char UnknownData0[0x20];
	    bool bConnectedToRoot; // 0x3d0 Size: 0x1
	    char UnknownData1[0x3d1]; // 0x3d1
	    void ServerUpdateMultipleLevelsVisibility(TArray<struct FUpdateLevelVisibilityLevelInfo> LevelVisibilities); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void ServerUpdateLevelVisibility(FName PackageName, bool bIsVisible); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void OnRep_ConnectedToRoot(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x-7bf9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MeshNetwork.MeshBeaconClient");
			return (class UClass*)ptr;
		};

};

class AMeshBeaconHost : public AOnlineBeaconHost
{
	public:
	    int MaxConnections; // 0x418 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MeshNetwork.MeshBeaconHost");
			return (class UClass*)ptr;
		};

};

class AMeshBeaconHostObject : public AOnlineBeaconHostObject
{
	public:
	    char UnknownData0[0x360];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MeshNetwork.MeshBeaconHostObject");
			return (class UClass*)ptr;
		};

};

class UMeshConnection : public UIpConnection
{
	public:
	    char UnknownData0[0x1988];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MeshNetwork.MeshConnection");
			return (class UClass*)ptr;
		};

};

class UMeshNetDriver : public UIpNetDriver
{
	public:
	    char UnknownData0[0x768];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MeshNetwork.MeshNetDriver");
			return (class UClass*)ptr;
		};

};

class UMeshNetworkComponent : public UActorComponent
{
	public:
	    EMeshNetworkRelevancy MeshRelevancy; // 0xf8 Size: 0x1
	    char UnknownData0[0x7]; // 0xf9
	    __int64/*MapProperty*/ AggregationTimeouts; // 0x100 Size: 0x50
	    __int64/*MapProperty*/ AggregatedFunctions; // 0x150 Size: 0x50
	    char UnknownData1[0x1a0]; // 0x1a0
	    EMeshNetworkNodeType GetMeshNetworkNodeType(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7e41];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MeshNetwork.MeshNetworkComponent");
			return (class UClass*)ptr;
		};

};

class UMeshNetworkSubsystem : public UGameInstanceSubsystem
{
	public:
	    MulticastDelegateProperty OnMeshNodeTypeChanged; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnConnectedToRootChanged; // 0x38 Size: 0x10
	    MulticastDelegateProperty OnGameServerNodeTypeChanged; // 0x48 Size: 0x10
	    MulticastDelegateProperty OnMeshMetaDataUpdated; // 0x58 Size: 0x10
	    char UnknownData0[0x18]; // 0x68
	    EMeshNetworkNodeType NodeType; // 0x80 Size: 0x1
	    EMeshNetworkNodeType GameServerNodeType; // 0x81 Size: 0x1
	    bool bConnectedToRoot; // 0x82 Size: 0x1
	    char UnknownData1[0x83]; // 0x83
	    void SetMetaData(struct FMeshMetaDataStruct MetaData); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void GetMetadata(struct FMeshMetaDataStruct MetaData); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    EMeshNetworkNodeType GetMeshNetworkNodeType(); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    EMeshNetworkNodeType GetGameServerNodeType(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    bool GetConnectedToRoot(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x-7f49];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MeshNetwork.MeshNetworkSubsystem");
			return (class UClass*)ptr;
		};

};

class UMeshReplicationGraph : public UReplicationGraph
{
	public:
	    class UReplicationGraphNode_ActorList* AlwaysRelevantNode; // 0x458 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/MeshNetwork.MeshReplicationGraph");
			return (class UClass*)ptr;
		};

};


}