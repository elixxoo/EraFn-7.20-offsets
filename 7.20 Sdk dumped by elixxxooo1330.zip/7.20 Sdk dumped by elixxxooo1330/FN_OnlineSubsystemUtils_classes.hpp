#pragma once

#include "../SDK.hpp"

namespace SDK {


class AOnlineBeacon : public AActor
{
	public:
	    char UnknownData0[0x8];
	    float BeaconConnectionInitialTimeout; // 0x338 Size: 0x4
	    float BeaconConnectionTimeout; // 0x33c Size: 0x4
	    class UNetDriver* NetDriver; // 0x340 Size: 0x8
	    char UnknownData1[0x18];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.OnlineBeacon");
			return (class UClass*)ptr;
		};

};

class AOnlineBeaconClient : public AOnlineBeacon
{
	public:
	    class AOnlineBeaconHostObject* BeaconOwner; // 0x360 Size: 0x8
	    class UNetConnection* BeaconConnection; // 0x368 Size: 0x8
	    EBeaconConnectionState ConnectionState; // 0x370 Size: 0x1
	    char UnknownData0[0x371]; // 0x371
	    void ClientOnConnected(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7c31];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.OnlineBeaconClient");
			return (class UClass*)ptr;
		};

};

class AOnlineBeaconHostObject : public AActor
{
	public:
	    struct FString BeaconTypeName; // 0x330 Size: 0x10
	    class AOnlineBeaconClient* ClientBeaconActorClass; // 0x340 Size: 0x8
	    TArray<class AOnlineBeaconClient*> ClientActors; // 0x348 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.OnlineBeaconHostObject");
			return (class UClass*)ptr;
		};

};

class UAchievementBlueprintLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void GetCachedAchievementProgress(class UObject* WorldContextObject, class APlayerController* PlayerController, FName AchievementID, bool bFoundID, float Progress); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void GetCachedAchievementDescription(class UObject* WorldContextObject, class APlayerController* PlayerController, FName AchievementID, bool bFoundID, struct FText Title, struct FText LockedDescription, struct FText UnlockedDescription, bool bHidden); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.AchievementBlueprintLibrary");
			return (class UClass*)ptr;
		};

};

class UAchievementQueryCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	public:
	    MulticastDelegateProperty OnSuccess; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnFailure; // 0x38 Size: 0x10
	    char UnknownData0[0x48]; // 0x48
	    static class UAchievementQueryCallbackProxy* CacheAchievements(class UObject* WorldContextObject, class APlayerController* PlayerController); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static class UAchievementQueryCallbackProxy* CacheAchievementDescriptions(class UObject* WorldContextObject, class APlayerController* PlayerController); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.AchievementQueryCallbackProxy");
			return (class UClass*)ptr;
		};

};

class UAchievementWriteCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	public:
	    MulticastDelegateProperty OnSuccess; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnFailure; // 0x38 Size: 0x10
	    char UnknownData0[0x48]; // 0x48
	    static class UAchievementWriteCallbackProxy* WriteAchievementProgress(class UObject* WorldContextObject, class APlayerController* PlayerController, FName AchievementName, float Progress, int UserTag); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.AchievementWriteCallbackProxy");
			return (class UClass*)ptr;
		};

};

class UConnectionCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	public:
	    MulticastDelegateProperty OnSuccess; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnFailure; // 0x38 Size: 0x10
	    char UnknownData0[0x48]; // 0x48
	    static class UConnectionCallbackProxy* ConnectToService(class UObject* WorldContextObject, class APlayerController* PlayerController); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.ConnectionCallbackProxy");
			return (class UClass*)ptr;
		};

};

class UCreateSessionCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	public:
	    MulticastDelegateProperty OnSuccess; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnFailure; // 0x38 Size: 0x10
	    char UnknownData0[0x48]; // 0x48
	    static class UCreateSessionCallbackProxy* CreateSession(class UObject* WorldContextObject, class APlayerController* PlayerController, int PublicConnections, bool bUseLAN); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.CreateSessionCallbackProxy");
			return (class UClass*)ptr;
		};

};

class UDestroySessionCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	public:
	    MulticastDelegateProperty OnSuccess; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnFailure; // 0x38 Size: 0x10
	    char UnknownData0[0x48]; // 0x48
	    static class UDestroySessionCallbackProxy* DestroySession(class UObject* WorldContextObject, class APlayerController* PlayerController); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.DestroySessionCallbackProxy");
			return (class UClass*)ptr;
		};

};

class UEndMatchCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	public:
	    MulticastDelegateProperty OnSuccess; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnFailure; // 0x38 Size: 0x10
	    char UnknownData0[0x48]; // 0x48
	    static class UEndMatchCallbackProxy* EndMatch(class UObject* WorldContextObject, class APlayerController* PlayerController, __int64/*InterfaceProperty*/ MatchActor, struct FString MatchID, char LocalPlayerOutcome, char OtherPlayersOutcome); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f69];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.EndMatchCallbackProxy");
			return (class UClass*)ptr;
		};

};

class UEndTurnCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	public:
	    MulticastDelegateProperty OnSuccess; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnFailure; // 0x38 Size: 0x10
	    char UnknownData0[0x48]; // 0x48
	    static class UEndTurnCallbackProxy* EndTurn(class UObject* WorldContextObject, class APlayerController* PlayerController, struct FString MatchID, __int64/*InterfaceProperty*/ TurnBasedMatchInterface); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.EndTurnCallbackProxy");
			return (class UClass*)ptr;
		};

};

class UFindSessionsCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	public:
	    MulticastDelegateProperty OnSuccess; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnFailure; // 0x38 Size: 0x10
	    char UnknownData0[0x48]; // 0x48
	    static struct FString GetServerName(struct FBlueprintSessionResult Result); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static int GetPingInMs(struct FBlueprintSessionResult Result); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static int GetMaxPlayers(struct FBlueprintSessionResult Result); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static int GetCurrentPlayers(struct FBlueprintSessionResult Result); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static class UFindSessionsCallbackProxy* FindSessions(class UObject* WorldContextObject, class APlayerController* PlayerController, int MaxResults, bool bUseLAN); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7f59];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.FindSessionsCallbackProxy");
			return (class UClass*)ptr;
		};

};

class UFindTurnBasedMatchCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	public:
	    MulticastDelegateProperty OnSuccess; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnFailure; // 0x38 Size: 0x10
	    char UnknownData0[0x48]; // 0x48
	    static class UFindTurnBasedMatchCallbackProxy* FindTurnBasedMatch(class UObject* WorldContextObject, class APlayerController* PlayerController, __int64/*InterfaceProperty*/ MatchActor, int MinPlayers, int MaxPlayers, int PlayerGroup, bool ShowExistingMatches); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.FindTurnBasedMatchCallbackProxy");
			return (class UClass*)ptr;
		};

};

class UInAppPurchaseCallbackProxy : public UObject
{
	public:
	    MulticastDelegateProperty OnSuccess; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnFailure; // 0x38 Size: 0x10
	    char UnknownData0[0x48]; // 0x48
	    static class UInAppPurchaseCallbackProxy* CreateProxyObjectForInAppPurchase(class APlayerController* PlayerController, struct FInAppPurchaseProductRequest ProductRequest); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f61];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.InAppPurchaseCallbackProxy");
			return (class UClass*)ptr;
		};

};

class UInAppPurchaseQueryCallbackProxy : public UObject
{
	public:
	    MulticastDelegateProperty OnSuccess; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnFailure; // 0x38 Size: 0x10
	    char UnknownData0[0x48]; // 0x48
	    static class UInAppPurchaseQueryCallbackProxy* CreateProxyObjectForInAppPurchaseQuery(class APlayerController* PlayerController, TArray<struct FString> ProductIdentifiers); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.InAppPurchaseQueryCallbackProxy");
			return (class UClass*)ptr;
		};

};

class UInAppPurchaseRestoreCallbackProxy : public UObject
{
	public:
	    MulticastDelegateProperty OnSuccess; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnFailure; // 0x38 Size: 0x10
	    char UnknownData0[0x48]; // 0x48
	    static class UInAppPurchaseRestoreCallbackProxy* CreateProxyObjectForInAppPurchaseRestore(TArray<struct FInAppPurchaseProductRequest> ConsumableProductFlags, class APlayerController* PlayerController); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f51];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.InAppPurchaseRestoreCallbackProxy");
			return (class UClass*)ptr;
		};

};

class UIpConnection : public UNetConnection
{
	public:
	    char UnknownData0[0x1988];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.IpConnection");
			return (class UClass*)ptr;
		};

};

class UIpNetDriver : public UNetDriver
{
	public:
	    bool LogPortUnreach; // 0x720 Size: 0x1
	    bool AllowPlayerPortUnreach; // 0x720 Size: 0x1
	    char UnknownData0[0x2]; // 0x722
	    uint32_t MaxPortCountToTry; // 0x724 Size: 0x4
	    char UnknownData1[0x1c]; // 0x728
	    uint32_t ServerDesiredSocketReceiveBufferBytes; // 0x744 Size: 0x4
	    uint32_t ServerDesiredSocketSendBufferBytes; // 0x748 Size: 0x4
	    uint32_t ClientDesiredSocketReceiveBufferBytes; // 0x74c Size: 0x4
	    uint32_t ClientDesiredSocketSendBufferBytes; // 0x750 Size: 0x4
	    char UnknownData2[0x14];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.IpNetDriver");
			return (class UClass*)ptr;
		};

};

class UJoinSessionCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	public:
	    MulticastDelegateProperty OnSuccess; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnFailure; // 0x38 Size: 0x10
	    char UnknownData0[0x48]; // 0x48
	    static class UJoinSessionCallbackProxy* JoinSession(class UObject* WorldContextObject, class APlayerController* PlayerController, struct FBlueprintSessionResult SearchResult); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7eb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.JoinSessionCallbackProxy");
			return (class UClass*)ptr;
		};

};

class ULeaderboardBlueprintLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static bool WriteLeaderboardInteger(class APlayerController* PlayerController, FName StatName, int StatValue); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.LeaderboardBlueprintLibrary");
			return (class UClass*)ptr;
		};

};

class ULeaderboardFlushCallbackProxy : public UObject
{
	public:
	    MulticastDelegateProperty OnSuccess; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnFailure; // 0x38 Size: 0x10
	    char UnknownData0[0x48]; // 0x48
	    static class ULeaderboardFlushCallbackProxy* CreateProxyObjectForFlush(class APlayerController* PlayerController, FName SessionName); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.LeaderboardFlushCallbackProxy");
			return (class UClass*)ptr;
		};

};

class ULeaderboardQueryCallbackProxy : public UObject
{
	public:
	    MulticastDelegateProperty OnSuccess; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnFailure; // 0x38 Size: 0x10
	    char UnknownData0[0x48]; // 0x48
	    static class ULeaderboardQueryCallbackProxy* CreateProxyObjectForIntQuery(class APlayerController* PlayerController, FName StatName); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f49];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.LeaderboardQueryCallbackProxy");
			return (class UClass*)ptr;
		};

};

class ULogoutCallbackProxy : public UBlueprintAsyncActionBase
{
	public:
	    MulticastDelegateProperty OnSuccess; // 0x30 Size: 0x10
	    MulticastDelegateProperty OnFailure; // 0x40 Size: 0x10
	    char UnknownData0[0x50]; // 0x50
	    static class ULogoutCallbackProxy* Logout(class UObject* WorldContextObject, class APlayerController* PlayerController); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f79];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.LogoutCallbackProxy");
			return (class UClass*)ptr;
		};

};

class AOnlineBeaconHost : public AOnlineBeacon
{
	public:
	    int ListenPort; // 0x360 Size: 0x4
	    char UnknownData0[0x4]; // 0x364
	    TArray<class AOnlineBeaconClient*> ClientActors; // 0x368 Size: 0x10
	    char UnknownData1[0xa0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.OnlineBeaconHost");
			return (class UClass*)ptr;
		};

};

class UOnlineEngineInterfaceImpl : public UOnlineEngineInterface
{
	public:
	    FName VoiceSubsystemNameOverride; // 0x28 Size: 0x8
	    char UnknownData0[0xf8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.OnlineEngineInterfaceImpl");
			return (class UClass*)ptr;
		};

};

class UOnlinePIESettings : public UDeveloperSettings
{
	public:
	    bool bOnlinePIEEnabled; // 0x38 Size: 0x1
	    char UnknownData0[0x7]; // 0x39
	    TArray<struct FPIELoginSettingsInternal> Logins; // 0x40 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.OnlinePIESettings");
			return (class UClass*)ptr;
		};

};

class UOnlineSessionClient : public UOnlineSession
{
	public:
	    char UnknownData0[0x160];
	    bool bIsFromInvite; // 0x188 Size: 0x1
	    bool bHandlingDisconnect; // 0x189 Size: 0x1
	    char UnknownData1[0x6];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.OnlineSessionClient");
			return (class UClass*)ptr;
		};

};

class APartyBeaconClient : public AOnlineBeaconClient
{
	public:
	    char UnknownData0[0x30];
	    struct FString DestSessionId; // 0x3e0 Size: 0x10
	    struct FPartyReservation PendingReservation; // 0x3f0 Size: 0x40
	    EClientRequestType RequestType; // 0x430 Size: 0x1
	    bool bPendingReservationSent; // 0x431 Size: 0x1
	    bool bCancelReservation; // 0x432 Size: 0x1
	    char UnknownData1[0x433]; // 0x433
	    void ServerUpdateReservationRequest(struct FString SessionId, struct FPartyReservation ReservationUpdate); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void ServerReservationRequest(struct FString SessionId, struct FPartyReservation Reservation); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void ServerCancelReservationRequest(struct FUniqueNetIdRepl PartyLeader); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void ClientSendReservationUpdates(int NumRemainingReservations); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void ClientSendReservationFull(); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void ClientReservationResponse(char ReservationResponse); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void ClientCancelReservationResponse(char ReservationResponse); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x-7b81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.PartyBeaconClient");
			return (class UClass*)ptr;
		};

};

class APartyBeaconHost : public AOnlineBeaconHostObject
{
	public:
	    class UPartyBeaconState* State; // 0x358 Size: 0x8
	    bool bLogoutOnSessionTimeout; // 0x3c0 Size: 0x1
	    char UnknownData0[0x63]; // 0x361
	    float SessionTimeoutSecs; // 0x3c4 Size: 0x4
	    float TravelSessionTimeoutSecs; // 0x3c8 Size: 0x4
	    char UnknownData1[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.PartyBeaconHost");
			return (class UClass*)ptr;
		};

};

class UPartyBeaconState : public UObject
{
	public:
	    FName SessionName; // 0x28 Size: 0x8
	    int NumConsumedReservations; // 0x30 Size: 0x4
	    int MaxReservations; // 0x34 Size: 0x4
	    int NumTeams; // 0x38 Size: 0x4
	    int NumPlayersPerTeam; // 0x3c Size: 0x4
	    FName TeamAssignmentMethod; // 0x40 Size: 0x8
	    int ReservedHostTeamNum; // 0x48 Size: 0x4
	    int ForceTeamNum; // 0x4c Size: 0x4
	    bool bRestrictCrossConsole; // 0x50 Size: 0x1
	    char UnknownData0[0x7]; // 0x51
	    TArray<struct FPartyReservation> Reservations; // 0x58 Size: 0x10
	    char UnknownData1[0x10];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.PartyBeaconState");
			return (class UClass*)ptr;
		};

};

class UQuitMatchCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	public:
	    MulticastDelegateProperty OnSuccess; // 0x28 Size: 0x10
	    MulticastDelegateProperty OnFailure; // 0x38 Size: 0x10
	    char UnknownData0[0x48]; // 0x48
	    static class UQuitMatchCallbackProxy* QuitMatch(class UObject* WorldContextObject, class APlayerController* PlayerController, struct FString MatchID, char Outcome, int TurnTimeoutInSeconds); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f71];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.QuitMatchCallbackProxy");
			return (class UClass*)ptr;
		};

};

class UShowLoginUICallbackProxy : public UBlueprintAsyncActionBase
{
	public:
	    MulticastDelegateProperty OnSuccess; // 0x30 Size: 0x10
	    MulticastDelegateProperty OnFailure; // 0x40 Size: 0x10
	    char UnknownData0[0x50]; // 0x50
	    static class UShowLoginUICallbackProxy* ShowExternalLoginUI(class UObject* WorldContextObject, class APlayerController* InPlayerController); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7f81];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.ShowLoginUICallbackProxy");
			return (class UClass*)ptr;
		};

};

class ATestBeaconClient : public AOnlineBeaconClient
{
	public:
	    void ServerPong(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void ClientPing(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x-7c31];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.TestBeaconClient");
			return (class UClass*)ptr;
		};

};

class ATestBeaconHost : public AOnlineBeaconHostObject
{
	public:
	    char UnknownData0[0x358];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.TestBeaconHost");
			return (class UClass*)ptr;
		};

};

class UTurnBasedBlueprintLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void RegisterTurnBasedMatchInterfaceObject(class UObject* WorldContextObject, class APlayerController* PlayerController, class UObject* Object); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void GetPlayerDisplayName(class UObject* WorldContextObject, class APlayerController* PlayerController, struct FString MatchID, int PlayerIndex, struct FString PlayerDisplayName); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static void GetMyPlayerIndex(class UObject* WorldContextObject, class APlayerController* PlayerController, struct FString MatchID, int PlayerIndex); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static void GetIsMyTurn(class UObject* WorldContextObject, class APlayerController* PlayerController, struct FString MatchID, bool bIsMyTurn); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.TurnBasedBlueprintLibrary");
			return (class UClass*)ptr;
		};

};

class UVoipListenerSynthComponent : public USynthComponent
{
	public:
	    bool IsIdling(); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x-79c1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/OnlineSubsystemUtils.VoipListenerSynthComponent");
			return (class UClass*)ptr;
		};

};


}