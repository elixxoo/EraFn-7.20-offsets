#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FAssetData
{
	public:
	    FName ObjectPath; // 0x0 Size: 0x8
	    FName PackageName; // 0x8 Size: 0x8
	    FName PackagePath; // 0x10 Size: 0x8
	    FName AssetName; // 0x18 Size: 0x8
	    FName AssetClass; // 0x20 Size: 0x8
	    char UnknownData0[0x28];

};

struct FTagAndValue
{
	public:
	    FName Tag; // 0x0 Size: 0x8
	    struct FString Value; // 0x8 Size: 0x10

};


}