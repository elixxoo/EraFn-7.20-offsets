#include "../SDK.hpp"

void AQosBeaconClient::ServerQosRequest(struct FString InSessionId)
{
	struct {
            struct FString InSessionId;
	} params{ InSessionId };

    static auto fn = UObject::FindObject("/Script/Qos.QosBeaconClient:ServerQosRequest");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void AQosBeaconClient::ClientQosResponse(EQosResponseType Response)
{
	struct {
            EQosResponseType Response;
	} params{ Response };

    static auto fn = UObject::FindObject("/Script/Qos.QosBeaconClient:ClientQosResponse");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

