#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FEngineServiceNotification
{
	public:
	    struct FString Text; // 0x0 Size: 0x10
	    double TimeSeconds; // 0x10 Size: 0x8

};

struct FEngineServiceTerminate
{
	public:
	    struct FString UserName; // 0x0 Size: 0x10

};

struct FEngineServiceExecuteCommand
{
	public:
	    struct FString Command; // 0x0 Size: 0x10
	    struct FString UserName; // 0x10 Size: 0x10

};

struct FEngineServiceAuthGrant
{
	public:
	    struct FString UserName; // 0x0 Size: 0x10
	    struct FString UserToGrant; // 0x10 Size: 0x10

};

struct FEngineServiceAuthDeny
{
	public:
	    struct FString UserName; // 0x0 Size: 0x10
	    struct FString UserToDeny; // 0x10 Size: 0x10

};

struct FEngineServicePong
{
	public:
	    struct FString CurrentLevel; // 0x0 Size: 0x10
	    int EngineVersion; // 0x10 Size: 0x4
	    bool HasBegunPlay; // 0x14 Size: 0x1
	    char UnknownData0[0x3]; // 0x15
	    struct FGuid InstanceId; // 0x18 Size: 0x10
	    struct FString InstanceType; // 0x28 Size: 0x10
	    struct FGuid SessionId; // 0x38 Size: 0x10
	    float WorldTimeSeconds; // 0x48 Size: 0x4
	    char UnknownData1[0x4];

};

struct FEngineServicePing
{
	public:
	    char UnknownData0[0x1];

};


}