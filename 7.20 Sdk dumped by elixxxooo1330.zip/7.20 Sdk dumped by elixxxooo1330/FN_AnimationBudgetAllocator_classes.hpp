#pragma once

#include "../SDK.hpp"

namespace SDK {


class USkeletalMeshComponentBudgeted : public USkeletalMeshComponent
{
	public:
	    char UnknownData0[0x20];
	    bool bAutoRegisterWithBudgetAllocator; // 0xbe0 Size: 0x1
	    bool bAutoCalculateSignificance; // 0xbe0 Size: 0x1
	    char UnknownData1[0xbe2]; // 0xbe2
	    void SetAutoRegisterWithBudgetAllocator(bool bInAutoRegisterWithBudgetAllocator); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-73f1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/AnimationBudgetAllocator.SkeletalMeshComponentBudgeted");
			return (class UClass*)ptr;
		};

};


}