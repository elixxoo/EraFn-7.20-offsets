#pragma once

#include "../SDK.hpp"

namespace SDK {


class UKismetProceduralMeshLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static void SliceProceduralMesh(class UProceduralMeshComponent* InProcMesh, struct FVector PlanePosition, struct FVector PlaneNormal, bool bCreateOtherHalf, class UProceduralMeshComponent* OutOtherHalfProcMesh, EProcMeshSliceCapOption CapOption, class UMaterialInterface* CapMaterial); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static void GetSectionFromStaticMesh(class UStaticMesh* InMesh, int LODIndex, int SectionIndex, TArray<struct FVector> Vertices, TArray<int> Triangles, TArray<struct FVector> Normals, TArray<struct FVector2D> UVs, TArray<struct FProcMeshTangent> Tangents); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static void GetSectionFromProceduralMesh(class UProceduralMeshComponent* InProcMesh, int SectionIndex, TArray<struct FVector> Vertices, TArray<int> Triangles, TArray<struct FVector> Normals, TArray<struct FVector2D> UVs, TArray<struct FProcMeshTangent> Tangents); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    static void GenerateBoxMesh(struct FVector BoxRadius, TArray<struct FVector> Vertices, TArray<int> Triangles, TArray<struct FVector> Normals, TArray<struct FVector2D> UVs, TArray<struct FProcMeshTangent> Tangents); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    static void CreateGridMeshWelded(int NumX, int NumY, TArray<int> Triangles, TArray<struct FVector> Vertices, TArray<struct FVector2D> UVs, float GridSpacing); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    static void CreateGridMeshTriangles(int NumX, int NumY, bool bWinding, TArray<int> Triangles); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    static void CreateGridMeshSplit(int NumX, int NumY, TArray<int> Triangles, TArray<struct FVector> Vertices, TArray<struct FVector2D> UVs, TArray<struct FVector2D> UV1s, float GridSpacing); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    static void CopyProceduralMeshFromStaticMeshComponent(class UStaticMeshComponent* StaticMeshComponent, int LODIndex, class UProceduralMeshComponent* ProcMeshComponent, bool bCreateCollision); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    static void ConvertQuadToTriangles(TArray<int> Triangles, int Vert0, int Vert1, int Vert2, int Vert3); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    static void CalculateTangentsForMesh(TArray<struct FVector> Vertices, TArray<int> Triangles, TArray<struct FVector2D> UVs, TArray<struct FVector> Normals, TArray<struct FProcMeshTangent> Tangents); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ProceduralMeshComponent.KismetProceduralMeshLibrary");
			return (class UClass*)ptr;
		};

};

class UProceduralMeshComponent : public UMeshComponent
{
	public:
	    char UnknownData0[0x8];
	    bool bUseComplexAsSimpleCollision; // 0x5a8 Size: 0x1
	    bool bUseAsyncCooking; // 0x5a9 Size: 0x1
	    char UnknownData1[0x6]; // 0x5aa
	    class UBodySetup* ProcMeshBodySetup; // 0x5b0 Size: 0x8
	    TArray<struct FProcMeshSection> ProcMeshSections; // 0x5b8 Size: 0x10
	    TArray<struct FKConvexElem> CollisionConvexElems; // 0x5c8 Size: 0x10
	    struct FBoxSphereBounds LocalBounds; // 0x5d8 Size: 0x1c
	    char UnknownData2[0x4]; // 0x5f4
	    TArray<class UBodySetup*> AsyncBodySetupQueue; // 0x5f8 Size: 0x10
	    char UnknownData3[0x608]; // 0x608
	    void UpdateMeshSection_LinearColor(int SectionIndex, TArray<struct FVector> Vertices, TArray<struct FVector> Normals, TArray<struct FVector2D> UV0, TArray<struct FVector2D> UV1, TArray<struct FVector2D> UV2, TArray<struct FVector2D> UV3, TArray<struct FLinearColor> VertexColors, TArray<struct FProcMeshTangent> Tangents); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void UpdateMeshSection(int SectionIndex, TArray<struct FVector> Vertices, TArray<struct FVector> Normals, TArray<struct FVector2D> UV0, TArray<struct FColor> VertexColors, TArray<struct FProcMeshTangent> Tangents); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetMeshSectionVisible(int SectionIndex, bool bNewVisibility); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    bool IsMeshSectionVisible(int SectionIndex); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    int GetNumSections(); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void CreateMeshSection_LinearColor(int SectionIndex, TArray<struct FVector> Vertices, TArray<int> Triangles, TArray<struct FVector> Normals, TArray<struct FVector2D> UV0, TArray<struct FVector2D> UV1, TArray<struct FVector2D> UV2, TArray<struct FVector2D> UV3, TArray<struct FLinearColor> VertexColors, TArray<struct FProcMeshTangent> Tangents, bool bCreateCollision); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void CreateMeshSection(int SectionIndex, TArray<struct FVector> Vertices, TArray<int> Triangles, TArray<struct FVector> Normals, TArray<struct FVector2D> UV0, TArray<struct FColor> VertexColors, TArray<struct FProcMeshTangent> Tangents, bool bCreateCollision); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void ClearMeshSection(int SectionIndex); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void ClearCollisionConvexMeshes(); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void ClearAllMeshSections(); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void AddCollisionConvexMesh(TArray<struct FVector> ConvexVerts); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x-79d1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ProceduralMeshComponent.ProceduralMeshComponent");
			return (class UClass*)ptr;
		};

};


}