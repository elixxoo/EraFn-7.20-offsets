#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FSidecarFileInfo
{
	public:
	    __int64/*MapProperty*/ Meta; // 0x0 Size: 0x50
	    bool bIsCheckedOut; // 0x50 Size: 0x1
	    bool bOperationPending; // 0x51 Size: 0x1
	    char UnknownData0[0x6]; // 0x52
	    struct FString CheckoutGuid; // 0x58 Size: 0x10

};


}