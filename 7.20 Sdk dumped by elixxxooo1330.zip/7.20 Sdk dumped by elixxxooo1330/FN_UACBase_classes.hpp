#pragma once

#include "../SDK.hpp"

namespace SDK {


class UUACNetworkComponent : public UActorComponent
{
	public:
	    int PlayerID; // 0xf8 Size: 0x4
	    char UnknownData0[0xfc]; // 0xfc
	    void SendPacketToServer(char Type, TArray<char> Packet); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SendPacketToClient(char Type, TArray<char> Packet); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SendClientHello(uint32_t SessionKey); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7de9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/UACBase.UACNetworkComponent");
			return (class UClass*)ptr;
		};

};


}