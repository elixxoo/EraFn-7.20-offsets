#pragma once

#include "../SDK.hpp"

namespace SDK {


class UNetDebugWidget : public UUserWidget
{
	public:
	    class UCommonTextBlock* PingUI; // 0x228 Size: 0x8
	    class UCommonTextBlock* PacketInRateUI; // 0x230 Size: 0x8
	    class UCommonTextBlock* PacketOutRateUI; // 0x238 Size: 0x8
	    class UCommonTextBlock* PacketInLossUI; // 0x240 Size: 0x8
	    class UCommonTextBlock* PacketOutLossUI; // 0x248 Size: 0x8
	    class UCommonTextBlock* UpBandwidthUI; // 0x250 Size: 0x8
	    class UCommonTextBlock* DownBandwidthUI; // 0x258 Size: 0x8
	    class UHorizontalBox* TimeoutUI; // 0x260 Size: 0x8
	    char UnknownData0[0x268]; // 0x268
	    void StopTimer(); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void StartTimer(); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7ca9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/NetUI.NetDebugWidget");
			return (class UClass*)ptr;
		};

};


}