#include "../SDK.hpp"

void AEsportsCameraClient::SetDynamicMaterial(class UMaterialInstanceDynamic* MaterialInstanceDynamic)
{
	struct {
            class UMaterialInstanceDynamic* MaterialInstanceDynamic;
	} params{ MaterialInstanceDynamic };

    static auto fn = UObject::FindObject("/Script/EsportsCameraClient.EsportsCameraClient:SetDynamicMaterial");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


bool AEsportsCameraClient::IsPlayingWebMovie()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/EsportsCameraClient.EsportsCameraClient:IsPlayingWebMovie");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool AEsportsCameraClient::IsPlatformEnabled()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/EsportsCameraClient.EsportsCameraClient:IsPlatformEnabled");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}


bool AEsportsCameraClient::HasDynamicMaterial()
{
	struct {
            bool ReturnValue;
	} params{ };

    static auto fn = UObject::FindObject("/Script/EsportsCameraClient.EsportsCameraClient:HasDynamicMaterial");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, nullptr);

    return params.ReturnValue; 
}

void UEsportsCameraStatusBase::FollowedPlayerChanged(class AEsportsCameraClient* InEsportsCameraClient)
{
	struct {
            class AEsportsCameraClient* InEsportsCameraClient;
	} params{ InEsportsCameraClient };

    static auto fn = UObject::FindObject("/Script/EsportsCameraClient.EsportsCameraStatusBase:FollowedPlayerChanged");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

