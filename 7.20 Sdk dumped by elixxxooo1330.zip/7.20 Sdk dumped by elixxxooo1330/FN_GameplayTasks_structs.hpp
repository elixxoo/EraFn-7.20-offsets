#pragma once

#include "../SDK.hpp"

namespace SDK {




enum class ETaskResourceOverlapPolicy : uint8_t
{
    StartOnTop = 0,
    StartAtEnd = 1,
    ETaskResourceOverlapPolicy_MAX = 2
};struct FGameplayResourceSet
{
	public:
	    char UnknownData0[0x2];

};

struct FOnClaimedResourcesChangeSignature__DelegateSignature
{
	public:
	    struct FGameplayResourceSet NewlyClaimed; // 0x0 Size: 0x2
	    struct FGameplayResourceSet FreshlyReleased; // 0x2 Size: 0x2

};

struct FGameplayTaskSpawnActorDelegate__DelegateSignature
{
	public:
	    class AActor* SpawnedActor; // 0x0 Size: 0x8

};



enum class EGameplayTaskRunResult : uint8_t
{
    Error = 0,
    Failed = 1,
    Success_Paused = 2,
    Success_Active = 3,
    Success_Finished = 4,
    EGameplayTaskRunResult_MAX = 5
};

enum class EGameplayTaskState : uint8_t
{
    Uninitialized = 0,
    AwaitingActivation = 1,
    Paused = 2,
    Active = 3,
    Finished = 4,
    EGameplayTaskState_MAX = 5
};
}