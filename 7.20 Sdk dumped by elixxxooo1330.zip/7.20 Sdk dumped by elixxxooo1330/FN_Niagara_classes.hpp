#pragma once

#include "../SDK.hpp"

namespace SDK {


class UMovieSceneNiagaraTrack : public UMovieSceneNameableTrack
{
	public:
	    TArray<class UMovieSceneSection*> Sections; // 0x58 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.MovieSceneNiagaraTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneNiagaraParameterTrack : public UMovieSceneNiagaraTrack
{
	public:
	    struct FNiagaraVariable Parameter; // 0x68 Size: 0x30

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.MovieSceneNiagaraParameterTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneNiagaraBoolParameterTrack : public UMovieSceneNiagaraParameterTrack
{
	public:
	    char UnknownData0[0x98];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.MovieSceneNiagaraBoolParameterTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneNiagaraColorParameterTrack : public UMovieSceneNiagaraParameterTrack
{
	public:
	    char UnknownData0[0x98];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.MovieSceneNiagaraColorParameterTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneNiagaraFloatParameterTrack : public UMovieSceneNiagaraParameterTrack
{
	public:
	    char UnknownData0[0x98];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.MovieSceneNiagaraFloatParameterTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneNiagaraIntegerParameterTrack : public UMovieSceneNiagaraParameterTrack
{
	public:
	    char UnknownData0[0x98];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.MovieSceneNiagaraIntegerParameterTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneNiagaraSystemSpawnSection : public UMovieSceneSection
{
	public:
	    char UnknownData0[0xe0];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.MovieSceneNiagaraSystemSpawnSection");
			return (class UClass*)ptr;
		};

};

class UMovieSceneNiagaraSystemTrack : public UMovieSceneNiagaraTrack
{
	public:
	    char UnknownData0[0x68];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.MovieSceneNiagaraSystemTrack");
			return (class UClass*)ptr;
		};

};

class UMovieSceneNiagaraVectorParameterTrack : public UMovieSceneNiagaraParameterTrack
{
	public:
	    int ChannelsUsed; // 0x98 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.MovieSceneNiagaraVectorParameterTrack");
			return (class UClass*)ptr;
		};

};

class ANiagaraActor : public AActor
{
	public:
	    class UNiagaraComponent* NiagaraComponent; // 0x330 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraActor");
			return (class UClass*)ptr;
		};

};

class UNiagaraComponent : public UPrimitiveComponent
{
	public:
	    class UNiagaraSystem* Asset; // 0x570 Size: 0x8
	    struct FNiagaraParameterStore OverrideParameters; // 0x578 Size: 0xe0
	    bool bForceSolo; // 0x658 Size: 0x1
	    bool bAutoDestroy; // 0x680 Size: 0x1
	    bool bRenderingEnabled; // 0x680 Size: 0x1
	    bool bAutoManageAttachment; // 0x680 Size: 0x1
	    char UnknownData0[0x44]; // 0x65c
	    TWeakObjectPtr<USceneComponent*> AutoAttachParent; // 0x6a0 Size: 0x8
	    FName AutoAttachSocketName; // 0x6a8 Size: 0x8
	    EAttachmentRule AutoAttachLocationRule; // 0x6b0 Size: 0x1
	    EAttachmentRule AutoAttachRotationRule; // 0x6b1 Size: 0x1
	    EAttachmentRule AutoAttachScaleRule; // 0x6b2 Size: 0x1
	    char UnknownData1[0x6b3]; // 0x6b3
	    void SetSeekDelta(float InSeekDelta); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetRenderingEnabled(bool bInRenderingEnabled); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetPaused(bool bInPaused); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetNiagaraVariableVec4(struct FString InVariableName, struct FVector4 InValue); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetNiagaraVariableVec3(struct FString InVariableName, struct FVector InValue); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetNiagaraVariableVec2(struct FString InVariableName, struct FVector2D InValue); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetNiagaraVariableQuat(struct FString InVariableName, struct FQuat InValue); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    void SetNiagaraVariableLinearColor(struct FString InVariableName, struct FLinearColor InValue); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    void SetNiagaraVariableInt(struct FString InVariableName, int InValue); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    void SetNiagaraVariableFloat(struct FString InVariableName, float InValue); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    void SetNiagaraVariableBool(struct FString InVariableName, bool InValue); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    void SetNiagaraVariableActor(struct FString InVariableName, class AActor* Actor); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    void SetMaxSimTime(float InMaxTime); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    void SetForceSolo(bool bInForceSolo); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    void SetDesiredAge(float InDesiredAge); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x7fe1]; // 0x7fe1
	    void SetCanRenderWhileSeeking(bool bInCanRenderWhileSeeking); // 0x0 Size: 0x7fe1
	    char UnknownData17[0x7fe1]; // 0x7fe1
	    void SetAutoDestroy(bool bInAutoDestroy); // 0x0 Size: 0x7fe1
	    char UnknownData18[0x7fe1]; // 0x7fe1
	    void SetAutoAttachmentParameters(class USceneComponent* Parent, FName SocketName, EAttachmentRule LocationRule, EAttachmentRule RotationRule, EAttachmentRule ScaleRule); // 0x0 Size: 0x7fe1
	    char UnknownData19[0x7fe1]; // 0x7fe1
	    void SetAsset(class UNiagaraSystem* InAsset); // 0x0 Size: 0x7fe1
	    char UnknownData20[0x7fe1]; // 0x7fe1
	    void SetAgeUpdateMode(ENiagaraAgeUpdateMode InAgeUpdateMode); // 0x0 Size: 0x7fe1
	    char UnknownData21[0x7fe1]; // 0x7fe1
	    void SeekToDesiredAge(float InDesiredAge); // 0x0 Size: 0x7fe1
	    char UnknownData22[0x7fe1]; // 0x7fe1
	    void ResetSystem(); // 0x0 Size: 0x7fe1
	    char UnknownData23[0x7fe1]; // 0x7fe1
	    void ReinitializeSystem(); // 0x0 Size: 0x7fe1
	    char UnknownData24[0x7fe1]; // 0x7fe1
	    bool IsPaused(); // 0x0 Size: 0x7fe1
	    char UnknownData25[0x7fe1]; // 0x7fe1
	    float GetSeekDelta(); // 0x0 Size: 0x7fe1
	    char UnknownData26[0x7fe1]; // 0x7fe1
	    TArray<struct FVector> GetNiagaraParticleValueVec3_DebugOnly(struct FString InEmitterName, struct FString InValueName); // 0x0 Size: 0x7fe1
	    char UnknownData27[0x7fe1]; // 0x7fe1
	    TArray<float> GetNiagaraParticleValues_DebugOnly(struct FString InEmitterName, struct FString InValueName); // 0x0 Size: 0x7fe1
	    char UnknownData28[0x7fe1]; // 0x7fe1
	    TArray<struct FVector> GetNiagaraParticlePositions_DebugOnly(struct FString InEmitterName); // 0x0 Size: 0x7fe1
	    char UnknownData29[0x7fe1]; // 0x7fe1
	    float GetMaxSimTime(); // 0x0 Size: 0x7fe1
	    char UnknownData30[0x7fe1]; // 0x7fe1
	    bool GetForceSolo(); // 0x0 Size: 0x7fe1
	    char UnknownData31[0x7fe1]; // 0x7fe1
	    float GetDesiredAge(); // 0x0 Size: 0x7fe1
	    char UnknownData32[0x7fe1]; // 0x7fe1
	    class UNiagaraSystem* GetAsset(); // 0x0 Size: 0x7fe1
	    char UnknownData33[0x7fe1]; // 0x7fe1
	    ENiagaraAgeUpdateMode GetAgeUpdateMode(); // 0x0 Size: 0x7fe1
	    char UnknownData34[0x7fe1]; // 0x7fe1
	    void AdvanceSimulationByTime(float SimulateTime, float TickDeltaSeconds); // 0x0 Size: 0x7fe1
	    char UnknownData35[0x7fe1]; // 0x7fe1
	    void AdvanceSimulation(int TickCount, float TickDeltaSeconds); // 0x0 Size: 0x7fe1
	    char UnknownData36[0x-78f1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraComponent");
			return (class UClass*)ptr;
		};

};

class UNiagaraDataInterface : public UNiagaraDataInterfaceBase
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraDataInterface");
			return (class UClass*)ptr;
		};

};

class UNiagaraDataInterfaceCurveBase : public UNiagaraDataInterface
{
	public:
	    bool GPUBufferDirty; // 0x28 Size: 0x1
	    char UnknownData0[0x7]; // 0x29
	    TArray<float> ShaderLUT; // 0x30 Size: 0x10
	    float LUTMinTime; // 0x40 Size: 0x4
	    float LUTMaxTime; // 0x44 Size: 0x4
	    float LUTInvTimeRange; // 0x48 Size: 0x4
	    bool bUseLUT; // 0x4c Size: 0x1
	    char UnknownData1[0x1b];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraDataInterfaceCurveBase");
			return (class UClass*)ptr;
		};

};

class UNiagaraDataInterfaceCollisionQuery : public UNiagaraDataInterface
{
	public:
	    char UnknownData0[0x30];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraDataInterfaceCollisionQuery");
			return (class UClass*)ptr;
		};

};

class UNiagaraDataInterfaceColorCurve : public UNiagaraDataInterfaceCurveBase
{
	public:
	    struct FRichCurve RedCurve; // 0x68 Size: 0x80
	    struct FRichCurve GreenCurve; // 0xe8 Size: 0x80
	    struct FRichCurve BlueCurve; // 0x168 Size: 0x80
	    struct FRichCurve AlphaCurve; // 0x1e8 Size: 0x80

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraDataInterfaceColorCurve");
			return (class UClass*)ptr;
		};

};

class UNiagaraDataInterfaceCurlNoise : public UNiagaraDataInterface
{
	public:
	    char UnknownData0[0x4];
	    uint32_t Seed; // 0x2c Size: 0x4
	    char UnknownData1[0x13330];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraDataInterfaceCurlNoise");
			return (class UClass*)ptr;
		};

};

class UNiagaraDataInterfaceCurve : public UNiagaraDataInterfaceCurveBase
{
	public:
	    struct FRichCurve Curve; // 0x68 Size: 0x80

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraDataInterfaceCurve");
			return (class UClass*)ptr;
		};

};

class UNiagaraDataInterfaceSimpleCounter : public UNiagaraDataInterface
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraDataInterfaceSimpleCounter");
			return (class UClass*)ptr;
		};

};

class UNiagaraDataInterfaceSkeletalMesh : public UNiagaraDataInterface
{
	public:
	    class USkeletalMesh* DefaultMesh; // 0x28 Size: 0x8
	    class AActor* Source; // 0x30 Size: 0x8
	    ENDISkeletalMesh_SkinningMode SkinningMode; // 0x38 Size: 0x1
	    char UnknownData0[0x7]; // 0x39
	    TArray<FName> SamplingRegions; // 0x40 Size: 0x10
	    int WholeMeshLOD; // 0x50 Size: 0x4
	    char UnknownData1[0x4]; // 0x54
	    TArray<FName> SpecificBones; // 0x58 Size: 0x10
	    TArray<FName> SpecificSockets; // 0x68 Size: 0x10
	    bool bUseTriangleSampling; // 0x78 Size: 0x1
	    bool bUseVertexSampling; // 0x79 Size: 0x1
	    bool bUseSkeletonSampling; // 0x7a Size: 0x1
	    char UnknownData2[0x5];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraDataInterfaceSkeletalMesh");
			return (class UClass*)ptr;
		};

};

class UNiagaraDataInterfaceSpline : public UNiagaraDataInterface
{
	public:
	    class AActor* Source; // 0x28 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraDataInterfaceSpline");
			return (class UClass*)ptr;
		};

};

class UNiagaraDataInterfaceStaticMesh : public UNiagaraDataInterface
{
	public:
	    class UStaticMesh* DefaultMesh; // 0x28 Size: 0x8
	    class AActor* Source; // 0x30 Size: 0x8
	    struct FNDIStaticMeshSectionFilter SectionFilter; // 0x38 Size: 0x10
	    char UnknownData0[0x8];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraDataInterfaceStaticMesh");
			return (class UClass*)ptr;
		};

};

class UNiagaraDataInterfaceTexture : public UNiagaraDataInterface
{
	public:
	    char UnknownData0[0x8];
	    class UTexture* Texture; // 0x30 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraDataInterfaceTexture");
			return (class UClass*)ptr;
		};

};

class UNiagaraDataInterfaceVector2DCurve : public UNiagaraDataInterfaceCurveBase
{
	public:
	    struct FRichCurve XCurve; // 0x68 Size: 0x80
	    struct FRichCurve YCurve; // 0xe8 Size: 0x80

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraDataInterfaceVector2DCurve");
			return (class UClass*)ptr;
		};

};

class UNiagaraDataInterfaceVector4Curve : public UNiagaraDataInterfaceCurveBase
{
	public:
	    struct FRichCurve XCurve; // 0x68 Size: 0x80
	    struct FRichCurve YCurve; // 0xe8 Size: 0x80
	    struct FRichCurve ZCurve; // 0x168 Size: 0x80
	    struct FRichCurve WCurve; // 0x1e8 Size: 0x80

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraDataInterfaceVector4Curve");
			return (class UClass*)ptr;
		};

};

class UNiagaraDataInterfaceVectorCurve : public UNiagaraDataInterfaceCurveBase
{
	public:
	    struct FRichCurve XCurve; // 0x68 Size: 0x80
	    struct FRichCurve YCurve; // 0xe8 Size: 0x80
	    struct FRichCurve ZCurve; // 0x168 Size: 0x80

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraDataInterfaceVectorCurve");
			return (class UClass*)ptr;
		};

};

class UNiagaraDataInterfaceVectorField : public UNiagaraDataInterface
{
	public:
	    class UVectorField* Field; // 0x28 Size: 0x8
	    bool bTileX; // 0x30 Size: 0x1
	    bool bTileY; // 0x31 Size: 0x1
	    bool bTileZ; // 0x32 Size: 0x1
	    char UnknownData0[0x55];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraDataInterfaceVectorField");
			return (class UClass*)ptr;
		};

};

class UNiagaraEditorDataBase : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraEditorDataBase");
			return (class UClass*)ptr;
		};

};

class UNiagaraEmitter : public UObject
{
	public:
	    bool bLocalSpace; // 0x28 Size: 0x1
	    char UnknownData0[0x7]; // 0x29
	    struct FNiagaraEmitterScriptProperties UpdateScriptProps; // 0x30 Size: 0x28
	    struct FNiagaraEmitterScriptProperties SpawnScriptProps; // 0x58 Size: 0x28
	    struct FNiagaraEmitterScriptProperties EmitterSpawnScriptProps; // 0x80 Size: 0x28
	    struct FNiagaraEmitterScriptProperties EmitterUpdateScriptProps; // 0xa8 Size: 0x28
	    ENiagaraSimTarget SimTarget; // 0xd0 Size: 0x1
	    char UnknownData1[0x3]; // 0xd1
	    struct FBox FixedBounds; // 0xd4 Size: 0x1c
	    int MinDetailLevel; // 0xf0 Size: 0x4
	    int MaxDetailLevel; // 0xf4 Size: 0x4
	    bool bInterpolatedSpawning; // 0xf8 Size: 0x1
	    bool bFixedBounds; // 0xf8 Size: 0x1
	    bool bUseMinDetailLevel; // 0xf8 Size: 0x1
	    bool bUseMaxDetailLevel; // 0xf8 Size: 0x1
	    bool bRequiresPersistentIDs; // 0xf8 Size: 0x1
	    char UnknownData2[0x3]; // 0xfd
	    struct FString UniqueEmitterName; // 0x100 Size: 0x10
	    TArray<class UNiagaraRendererProperties*> RendererProperties; // 0x110 Size: 0x10
	    TArray<struct FNiagaraEventScriptProperties> EventHandlerScriptProps; // 0x120 Size: 0x10
	    class UNiagaraScript* GPUComputeScript; // 0x130 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraEmitter");
			return (class UClass*)ptr;
		};

};

class UNiagaraEventReceiverEmitterAction : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraEventReceiverEmitterAction");
			return (class UClass*)ptr;
		};

};

class UNiagaraEventReceiverEmitterAction_SpawnParticles : public UNiagaraEventReceiverEmitterAction
{
	public:
	    uint32_t NumParticles; // 0x28 Size: 0x4
	    char UnknownData0[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraEventReceiverEmitterAction_SpawnParticles");
			return (class UClass*)ptr;
		};

};

class UNiagaraFunctionLibrary : public UBlueprintFunctionLibrary
{
	public:
	    static class UNiagaraComponent* SpawnSystemAttached(class UNiagaraSystem* SystemTemplate, class USceneComponent* AttachToComponent, FName AttachPointName, struct FVector Location, struct FRotator Rotation, char LocationType, bool bAutoDestroy); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    static class UNiagaraComponent* SpawnSystemAtLocation(class UObject* WorldContextObject, class UNiagaraSystem* SystemTemplate, struct FVector Location, struct FRotator Rotation, bool bAutoDestroy); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    static class UNiagaraParameterCollectionInstance* GetNiagaraParameterCollection(class UObject* WorldContextObject, class UNiagaraParameterCollection* Collection); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x-7fb9];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraFunctionLibrary");
			return (class UClass*)ptr;
		};

};

class UNiagaraRendererProperties : public UNiagaraMergeable
{
	public:
	    int SortOrderHint; // 0x28 Size: 0x4
	    bool bIsEnabled; // 0x2c Size: 0x1
	    char UnknownData0[0x3];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraRendererProperties");
			return (class UClass*)ptr;
		};

};

class UNiagaraLightRendererProperties : public UNiagaraRendererProperties
{
	public:
	    float RadiusScale; // 0x30 Size: 0x4
	    struct FVector ColorAdd; // 0x34 Size: 0xc
	    struct FNiagaraVariableAttributeBinding PositionBinding; // 0x40 Size: 0x90
	    struct FNiagaraVariableAttributeBinding ColorBinding; // 0xd0 Size: 0x90
	    struct FNiagaraVariableAttributeBinding RadiusBinding; // 0x160 Size: 0x90

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraLightRendererProperties");
			return (class UClass*)ptr;
		};

};

class UNiagaraMeshRendererProperties : public UNiagaraRendererProperties
{
	public:
	    class UStaticMesh* ParticleMesh; // 0x30 Size: 0x8
	    ENiagaraSortMode SortMode; // 0x38 Size: 0x1
	    bool bOverrideMaterials; // 0x3c Size: 0x1
	    bool bSortOnlyWhenTranslucent; // 0x3c Size: 0x1
	    char UnknownData0[0x5]; // 0x3b
	    TArray<class UMaterialInterface*> OverrideMaterials; // 0x40 Size: 0x10
	    ENiagaraMeshFacingMode FacingMode; // 0x50 Size: 0x1
	    char UnknownData1[0x7]; // 0x51
	    struct FNiagaraVariableAttributeBinding PositionBinding; // 0x58 Size: 0x90
	    struct FNiagaraVariableAttributeBinding ColorBinding; // 0xe8 Size: 0x90
	    struct FNiagaraVariableAttributeBinding VelocityBinding; // 0x178 Size: 0x90
	    struct FNiagaraVariableAttributeBinding MeshOrientationBinding; // 0x208 Size: 0x90
	    struct FNiagaraVariableAttributeBinding ScaleBinding; // 0x298 Size: 0x90
	    struct FNiagaraVariableAttributeBinding DynamicMaterialBinding; // 0x328 Size: 0x90
	    struct FNiagaraVariableAttributeBinding DynamicMaterial1Binding; // 0x3b8 Size: 0x90
	    struct FNiagaraVariableAttributeBinding DynamicMaterial2Binding; // 0x448 Size: 0x90
	    struct FNiagaraVariableAttributeBinding DynamicMaterial3Binding; // 0x4d8 Size: 0x90
	    struct FNiagaraVariableAttributeBinding MaterialRandomBinding; // 0x568 Size: 0x90
	    struct FNiagaraVariableAttributeBinding CustomSortingBinding; // 0x5f8 Size: 0x90
	    struct FNiagaraVariableAttributeBinding NormalizedAgeBinding; // 0x688 Size: 0x90
	    int SyncId; // 0x718 Size: 0x4
	    char UnknownData2[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraMeshRendererProperties");
			return (class UClass*)ptr;
		};

};

class UNiagaraParameterCollectionInstance : public UObject
{
	public:
	    class UNiagaraParameterCollection* Collection; // 0x28 Size: 0x8
	    TArray<struct FNiagaraVariable> OverridenParameters; // 0x30 Size: 0x10
	    struct FNiagaraParameterStore ParameterStorage; // 0x40 Size: 0xe0
	    char UnknownData0[0x120]; // 0x120
	    void SetVectorParameter(struct FString InVariableName, struct FVector InValue); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void SetVector4Parameter(struct FString InVariableName, struct FVector4 InValue); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void SetVector2DParameter(struct FString InVariableName, struct FVector2D InValue); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x7fe1]; // 0x7fe1
	    void SetQuatParameter(struct FString InVariableName, struct FQuat InValue); // 0x0 Size: 0x7fe1
	    char UnknownData4[0x7fe1]; // 0x7fe1
	    void SetIntParameter(struct FString InVariableName, int InValue); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x7fe1]; // 0x7fe1
	    void SetFloatParameter(struct FString InVariableName, float InValue); // 0x0 Size: 0x7fe1
	    char UnknownData6[0x7fe1]; // 0x7fe1
	    void SetColorParameter(struct FString InVariableName, struct FLinearColor InValue); // 0x0 Size: 0x7fe1
	    char UnknownData7[0x7fe1]; // 0x7fe1
	    void SetBoolParameter(struct FString InVariableName, bool InValue); // 0x0 Size: 0x7fe1
	    char UnknownData8[0x7fe1]; // 0x7fe1
	    struct FVector GetVectorParameter(struct FString InVariableName); // 0x0 Size: 0x7fe1
	    char UnknownData9[0x7fe1]; // 0x7fe1
	    struct FVector4 GetVector4Parameter(struct FString InVariableName); // 0x0 Size: 0x7fe1
	    char UnknownData10[0x7fe1]; // 0x7fe1
	    struct FVector2D GetVector2DParameter(struct FString InVariableName); // 0x0 Size: 0x7fe1
	    char UnknownData11[0x7fe1]; // 0x7fe1
	    struct FQuat GetQuatParameter(struct FString InVariableName); // 0x0 Size: 0x7fe1
	    char UnknownData12[0x7fe1]; // 0x7fe1
	    int GetIntParameter(struct FString InVariableName); // 0x0 Size: 0x7fe1
	    char UnknownData13[0x7fe1]; // 0x7fe1
	    float GetFloatParameter(struct FString InVariableName); // 0x0 Size: 0x7fe1
	    char UnknownData14[0x7fe1]; // 0x7fe1
	    struct FLinearColor GetColorParameter(struct FString InVariableName); // 0x0 Size: 0x7fe1
	    char UnknownData15[0x7fe1]; // 0x7fe1
	    bool GetBoolParameter(struct FString InVariableName); // 0x0 Size: 0x7fe1
	    char UnknownData16[0x-7ec1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraParameterCollectionInstance");
			return (class UClass*)ptr;
		};

};

class UNiagaraParameterCollection : public UObject
{
	public:
	    FName Namespace; // 0x28 Size: 0x8
	    TArray<struct FNiagaraVariable> Parameters; // 0x30 Size: 0x10
	    class UNiagaraParameterCollectionInstance* DefaultInstance; // 0x40 Size: 0x8
	    struct FGuid CompileId; // 0x48 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraParameterCollection");
			return (class UClass*)ptr;
		};

};

class UNiagaraRibbonRendererProperties : public UNiagaraRendererProperties
{
	public:
	    class UMaterialInterface* Material; // 0x30 Size: 0x8
	    ENiagaraRibbonFacingMode FacingMode; // 0x38 Size: 0x1
	    char UnknownData0[0x3]; // 0x39
	    float UV0TilingDistance; // 0x3c Size: 0x4
	    struct FVector2D UV0Scale; // 0x40 Size: 0x8
	    struct FVector2D UV0Offset; // 0x48 Size: 0x8
	    ENiagaraRibbonAgeOffsetMode UV0AgeOffsetMode; // 0x50 Size: 0x1
	    char UnknownData1[0x3]; // 0x51
	    float UV1TilingDistance; // 0x54 Size: 0x4
	    struct FVector2D UV1Scale; // 0x58 Size: 0x8
	    struct FVector2D UV1Offset; // 0x60 Size: 0x8
	    ENiagaraRibbonAgeOffsetMode UV1AgeOffsetMode; // 0x68 Size: 0x1
	    ENiagaraRibbonDrawDirection DrawDirection; // 0x69 Size: 0x1
	    char UnknownData2[0x6]; // 0x6a
	    struct FNiagaraVariableAttributeBinding PositionBinding; // 0x70 Size: 0x90
	    struct FNiagaraVariableAttributeBinding ColorBinding; // 0x100 Size: 0x90
	    struct FNiagaraVariableAttributeBinding VelocityBinding; // 0x190 Size: 0x90
	    struct FNiagaraVariableAttributeBinding NormalizedAgeBinding; // 0x220 Size: 0x90
	    struct FNiagaraVariableAttributeBinding RibbonTwistBinding; // 0x2b0 Size: 0x90
	    struct FNiagaraVariableAttributeBinding RibbonWidthBinding; // 0x340 Size: 0x90
	    struct FNiagaraVariableAttributeBinding RibbonFacingBinding; // 0x3d0 Size: 0x90
	    struct FNiagaraVariableAttributeBinding RibbonIdBinding; // 0x460 Size: 0x90
	    struct FNiagaraVariableAttributeBinding RibbonLinkOrderBinding; // 0x4f0 Size: 0x90
	    struct FNiagaraVariableAttributeBinding MaterialRandomBinding; // 0x580 Size: 0x90
	    struct FNiagaraVariableAttributeBinding DynamicMaterialBinding; // 0x610 Size: 0x90
	    struct FNiagaraVariableAttributeBinding DynamicMaterial1Binding; // 0x6a0 Size: 0x90
	    struct FNiagaraVariableAttributeBinding DynamicMaterial2Binding; // 0x730 Size: 0x90
	    struct FNiagaraVariableAttributeBinding DynamicMaterial3Binding; // 0x7c0 Size: 0x90
	    int SyncId; // 0x850 Size: 0x4
	    char UnknownData3[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraRibbonRendererProperties");
			return (class UClass*)ptr;
		};

};

class UNiagaraScript : public UObject
{
	public:
	    ENiagaraScriptUsage Usage; // 0x28 Size: 0x1
	    char UnknownData0[0x3]; // 0x29
	    int UsageIndex; // 0x2c Size: 0x4
	    struct FGuid UsageId; // 0x30 Size: 0x10
	    int ModuleUsageBitmask; // 0x40 Size: 0x4
	    char UnknownData1[0x4]; // 0x44
	    struct FNiagaraParameterStore RapidIterationParameters; // 0x48 Size: 0xe0
	    ENiagaraNumericOutputTypeSelectionMode NumericOutputTypeSelectionMode; // 0x128 Size: 0x1
	    char UnknownData2[0x7]; // 0x129
	    struct FNiagaraScriptExecutionParameterStore ScriptExecutionParamStoreCPU; // 0x130 Size: 0x100
	    struct FNiagaraScriptExecutionParameterStore ScriptExecutionParamStoreGPU; // 0x230 Size: 0x100
	    struct FNiagaraVMExecutableDataId CachedScriptVMId; // 0x330 Size: 0x68
	    struct FNiagaraVMExecutableDataId LastGeneratedVMId; // 0x398 Size: 0x68
	    char UnknownData3[0x148]; // 0x400
	    struct FNiagaraVMExecutableData CachedScriptVM; // 0x548 Size: 0x168
	    TArray<class UNiagaraParameterCollection*> CachedParameterCollectionReferences; // 0x6b0 Size: 0x10
	    TArray<struct FNiagaraScriptDataInterfaceInfo> CachedDefaultDataInterfaces; // 0x6c0 Size: 0x10
	    char UnknownData4[0x6d0]; // 0x6d0
	    void OnCompilationComplete(); // 0x0 Size: 0x7fe1
	    char UnknownData5[0x-7911];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraScript");
			return (class UClass*)ptr;
		};

};

class UNiagaraScriptSourceBase : public UObject
{
	public:
	    char UnknownData0[0x48];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraScriptSourceBase");
			return (class UClass*)ptr;
		};

};

class UNiagaraSettings : public UDeveloperSettings
{
	public:
	    TArray<struct FSoftObjectPath> AdditionalParameterTypes; // 0x38 Size: 0x10
	    TArray<struct FSoftObjectPath> AdditionalPayloadTypes; // 0x48 Size: 0x10
	    TArray<struct FSoftObjectPath> AdditionalParameterEnums; // 0x58 Size: 0x10

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraSettings");
			return (class UClass*)ptr;
		};

};

class UNiagaraSpriteRendererProperties : public UNiagaraRendererProperties
{
	public:
	    class UMaterialInterface* Material; // 0x30 Size: 0x8
	    ENiagaraSpriteAlignment Alignment; // 0x38 Size: 0x1
	    ENiagaraSpriteFacingMode FacingMode; // 0x39 Size: 0x1
	    char UnknownData0[0x2]; // 0x3a
	    struct FVector CustomFacingVectorMask; // 0x3c Size: 0xc
	    struct FVector2D PivotInUVSpace; // 0x48 Size: 0x8
	    ENiagaraSortMode SortMode; // 0x50 Size: 0x1
	    char UnknownData1[0x3]; // 0x51
	    struct FVector2D SubImageSize; // 0x54 Size: 0x8
	    bool bSubImageBlend; // 0x5c Size: 0x1
	    bool bRemoveHMDRollInVR; // 0x5c Size: 0x1
	    bool bSortOnlyWhenTranslucent; // 0x5c Size: 0x1
	    char UnknownData2[0x1]; // 0x5f
	    float MinFacingCameraBlendDistance; // 0x60 Size: 0x4
	    float MaxFacingCameraBlendDistance; // 0x64 Size: 0x4
	    struct FNiagaraVariableAttributeBinding PositionBinding; // 0x68 Size: 0x90
	    struct FNiagaraVariableAttributeBinding ColorBinding; // 0xf8 Size: 0x90
	    struct FNiagaraVariableAttributeBinding VelocityBinding; // 0x188 Size: 0x90
	    struct FNiagaraVariableAttributeBinding SpriteRotationBinding; // 0x218 Size: 0x90
	    struct FNiagaraVariableAttributeBinding SpriteSizeBinding; // 0x2a8 Size: 0x90
	    struct FNiagaraVariableAttributeBinding SpriteFacingBinding; // 0x338 Size: 0x90
	    struct FNiagaraVariableAttributeBinding SpriteAlignmentBinding; // 0x3c8 Size: 0x90
	    struct FNiagaraVariableAttributeBinding SubImageIndexBinding; // 0x458 Size: 0x90
	    struct FNiagaraVariableAttributeBinding DynamicMaterialBinding; // 0x4e8 Size: 0x90
	    struct FNiagaraVariableAttributeBinding DynamicMaterial1Binding; // 0x578 Size: 0x90
	    struct FNiagaraVariableAttributeBinding DynamicMaterial2Binding; // 0x608 Size: 0x90
	    struct FNiagaraVariableAttributeBinding DynamicMaterial3Binding; // 0x698 Size: 0x90
	    struct FNiagaraVariableAttributeBinding CameraOffsetBinding; // 0x728 Size: 0x90
	    struct FNiagaraVariableAttributeBinding UVScaleBinding; // 0x7b8 Size: 0x90
	    struct FNiagaraVariableAttributeBinding MaterialRandomBinding; // 0x848 Size: 0x90
	    struct FNiagaraVariableAttributeBinding CustomSortingBinding; // 0x8d8 Size: 0x90
	    struct FNiagaraVariableAttributeBinding NormalizedAgeBinding; // 0x968 Size: 0x90
	    int SyncId; // 0x9f8 Size: 0x4
	    char UnknownData3[0x4];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraSpriteRendererProperties");
			return (class UClass*)ptr;
		};

};

class UNiagaraSystem : public UObject
{
	public:
	    bool bDumpDebugSystemInfo; // 0x28 Size: 0x1
	    bool bDumpDebugEmitterInfo; // 0x29 Size: 0x1
	    char UnknownData0[0x6]; // 0x2a
	    TArray<struct FNiagaraEmitterHandle> EmitterHandles; // 0x30 Size: 0x10
	    TArray<class UNiagaraParameterCollectionInstance*> ParameterCollectionOverrides; // 0x40 Size: 0x10
	    TArray<struct FNiagaraSystemCompileRequest> ActiveCompilations; // 0x50 Size: 0x10
	    class UNiagaraScript* SystemSpawnScript; // 0x60 Size: 0x8
	    class UNiagaraScript* SystemUpdateScript; // 0x68 Size: 0x8
	    TArray<struct FNiagaraEmitterSpawnAttributes> EmitterSpawnAttributes; // 0x70 Size: 0x10
	    struct FNiagaraParameterStore ExposedParameters; // 0x80 Size: 0xe0
	    bool bAutoDeactivate; // 0x160 Size: 0x1
	    char UnknownData1[0x3]; // 0x161
	    float WarmupTime; // 0x164 Size: 0x4
	    int WarmupTickCount; // 0x168 Size: 0x4
	    float WarmupTickDelta; // 0x16c Size: 0x4
	    bool bSolo; // 0x170 Size: 0x1
	    char UnknownData2[0x7];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/Niagara.NiagaraSystem");
			return (class UClass*)ptr;
		};

};


}