#include "../SDK.hpp"

void UTurnBasedMatchInterface::OnMatchReceivedTurn(struct FString Match, bool bDidBecomeActive)
{
	struct {
            struct FString Match;
            bool bDidBecomeActive;
	} params{ Match, bDidBecomeActive };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystem.TurnBasedMatchInterface:OnMatchReceivedTurn");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}


void UTurnBasedMatchInterface::OnMatchEnded(struct FString Match)
{
	struct {
            struct FString Match;
	} params{ Match };

    static auto fn = UObject::FindObject("/Script/OnlineSubsystem.TurnBasedMatchInterface:OnMatchEnded");
    _ProcessEvent((uintptr_t*)this, (uintptr_t*)fn, &params);
}

