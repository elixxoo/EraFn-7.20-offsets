#pragma once

#include "../SDK.hpp"

namespace SDK {


struct FWebJSCallbackBase
{
	public:
	    char UnknownData0[0x20];

};

struct FWebJSResponse : public FWebJSCallbackBase
{
	public:
	    char UnknownData0[0x20];

};

struct FWebJSFunction : public FWebJSCallbackBase
{
	public:
	    char UnknownData0[0x20];

};


}