#pragma once

#include "../SDK.hpp"

namespace SDK {


class UClothingAssetCustomData : public UObject
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ClothingSystemRuntime.ClothingAssetCustomData");
			return (class UClass*)ptr;
		};

};

class UClothingAsset : public UClothingAssetBase
{
	public:
	    class UPhysicsAsset* PhysicsAsset; // 0x48 Size: 0x8
	    struct FClothConfig ClothConfig; // 0x50 Size: 0xd4
	    char UnknownData0[0x4]; // 0x124
	    TArray<struct FClothLODData> LODData; // 0x128 Size: 0x10
	    TArray<int> LodMap; // 0x138 Size: 0x10
	    TArray<FName> UsedBoneNames; // 0x148 Size: 0x10
	    TArray<int> UsedBoneIndices; // 0x158 Size: 0x10
	    int ReferenceBoneIndex; // 0x168 Size: 0x4
	    char UnknownData1[0x4]; // 0x16c
	    class UClothingAssetCustomData* CustomData; // 0x170 Size: 0x8

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ClothingSystemRuntime.ClothingAsset");
			return (class UClass*)ptr;
		};

};

class UClothingSimulationFactoryNv : public UClothingSimulationFactory
{
	public:
	    char UnknownData0[0x28];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ClothingSystemRuntime.ClothingSimulationFactoryNv");
			return (class UClass*)ptr;
		};

};

class UClothingSimulationInteractorNv : public UClothingSimulationInteractor
{
	public:
	    void SetAnimDriveSpringStiffness(float InStiffness); // 0x0 Size: 0x7fe1
	    char UnknownData0[0x7fe1]; // 0x7fe1
	    void SetAnimDriveDamperStiffness(float InStiffness); // 0x0 Size: 0x7fe1
	    char UnknownData1[0x7fe1]; // 0x7fe1
	    void EnableGravityOverride(struct FVector InVector); // 0x0 Size: 0x7fe1
	    char UnknownData2[0x7fe1]; // 0x7fe1
	    void DisableGravityOverride(); // 0x0 Size: 0x7fe1
	    char UnknownData3[0x-7fa1];

		static class UClass* StaticClass()
	    {
			static auto ptr = UObject::FindObject("/Script/ClothingSystemRuntime.ClothingSimulationInteractorNv");
			return (class UClass*)ptr;
		};

};


}